"""Repack the surviving GNU ARM64 initramfs with one trial group."""
import hashlib
import json
import stat
import sys
import zlib
from pathlib import Path
import os

HERE = Path(__file__).resolve().parent
SIBLING = HERE.parents[3] / "t3-45996d9a/target/jobs-parity"
GUEST = SIBLING / "linux-arm-ownership-guest"
BASE = GUEST / "named-effect-thp-witness/run-02/guest.cpio"
PG = "jobs-parity/postgres-17.11"
sys.path.insert(0, str(GUEST))
sys.dont_write_bytecode = True
from pack_gnu import add


def members(data):
    offset = 0
    while offset < len(data):
        if data[offset] == 0:
            offset = (offset + 4) & ~3
            continue
        if data[offset:offset+3] == b"\x1f\x8b\x08":
            stream = zlib.decompressobj(31)
            yield from members(stream.decompress(data[offset:]))
            return
        assert data[offset:offset+6] == b"070701", offset
        mode = int(data[offset+14:offset+22], 16)
        size = int(data[offset+54:offset+62], 16)
        namesize = int(data[offset+94:offset+102], 16)
        name = data[offset+110:offset+110+namesize-1].decode()
        start = (offset+110+namesize+3) & ~3
        offset = (start+size+3) & ~3
        if name != "TRAILER!!!":
            yield name, mode, data[start:start+size]


def main():
    output, profile, *arms = sys.argv[1:]
    assert profile in {"noop", "slow"}
    assert arms and all(a in {"control", "layout", "layout-v2", "integrated", "pipeline", "pipeline-control", "current", "oban"} for a in arms)
    base = BASE.read_bytes()
    old = {name: (mode, data) for name, mode, data in members(base)}
    overlay = bytearray()
    directories = {name for name, (mode, _) in old.items() if stat.S_ISDIR(mode)}
    manifest = {}

    def add_file(name, data, mode=0o644):
        for parent in reversed(list(Path(name).parents)[:-1]):
            directory = parent.as_posix()
            if directory not in directories:
                add(overlay, directory, stat.S_IFDIR | 0o755)
                directories.add(directory)
        add(overlay, name, stat.S_IFREG | mode, data)
        manifest[name] = hashlib.sha256(data).hexdigest()

    def copy(name, path, mode=0o644):
        add_file(name, Path(path).read_bytes(), mode)

    shell = GUEST / "stock-jobs-smoke/init"
    copy("init", shell, 0o755)
    copy("proof/run.sh", HERE/"run.sh")
    copy("proof/jobs-parity.py", HERE/"harness-source.py")
    copy("proof/jobs-parity-profiles.json", HERE/"profiles.json")
    for file in ("trial.py", "fence.sql", "application.sql", "fixture.exs", "proof_transport.py"):
        copy(f"proof/{file}", HERE/file)
    copy("proof/oban", HERE/"oban.sh", 0o755)
    for arm in set(arms) - {"oban"}:
        binary = HERE/("mesh-"+arm)
        if arm == "integrated":
            stock = HERE.parent/"jobs-perf-work"
            binary = stock/"mesh-frozen-integrated"
            want, pinned = (stock/"link-frozen.log").read_text().splitlines()[-1].split()
            assert Path(pinned).resolve() == binary.resolve()
            assert hashlib.sha256(binary.read_bytes()).hexdigest() == want
            for name in ("main.mpl", "worker_identity.mpl", "mesh.toml", "libworker_identity.a"):
                assert (stock/"frozen-fixture"/name).read_bytes() == (HERE/"fixture"/name).read_bytes(), name
        if arm == "current":
            owner = HERE.parent
            want, pinned = (owner/"link-frozen-final.log").read_text().splitlines()[-1].split()
            assert Path(pinned).resolve() == binary.resolve()
            assert hashlib.sha256(binary.read_bytes()).hexdigest() == want
        copy("proof/mesh-"+arm, binary, 0o755)
    if "oban" in arms:
        beam = HERE/"beam/usr/local/lib/erlang"
        elixir = Path("/opt/homebrew/Cellar/elixir/1.20.4/lib/elixir/lib")
        deps = SIBLING/"build/oban/build/lib"
        for root, target, selected in (
            (beam, "opt/otp", (p for p in beam.rglob("*") if p.is_file()
                             and ("ebin" in p.parts or "priv" in p.parts
                                  or "bin" in p.parts or "releases" in p.parts))),
            (elixir, "opt/elixir", elixir.glob("*/ebin/*")),
            (deps, "opt/fixtures", (p for p in deps.glob("*/ebin/*")
                                    if p.parent.parent.name != "jobs_parity_oban")),
            (HERE/"oban-build", "opt/fixtures/jobs_parity_oban", (HERE/"oban-build/ebin").glob("*")),
        ):
            for path in sorted(selected):
                copy(f"{target}/{path.relative_to(root)}", path,
                     0o755 if path.stat().st_mode & 0o111 else 0o644)
        for lib in ("libstdc++.so.6", "libtinfo.so.6"):
            copy(f"lib/aarch64-linux-gnu/{lib}", HERE/"beam/usr/lib/aarch64-linux-gnu"/lib)
    trace = os.environ.get("QUEUE_PERF_TRACE") == "1"
    warmup = os.environ.get("QUEUE_PERF_WARMUP") == "1"
    assert not (trace and warmup), "use the separate trace proof before timed groups"
    if trace:
        add_file("proof/fault.so", old["proof/fault.so"][1])
    add_file("proof/config.json", json.dumps({"profile": profile, "arms": arms, "hashes": manifest,
                                              "trace": trace, "full_input_warmup": warmup}).encode())
    add(overlay, "TRAILER!!!", 0)
    output = HERE / output
    with output.open("xb") as stream:
        stream.write(base)
        stream.write(b"\0" * (-len(base) % 4))
        stream.write(overlay)


if __name__ == "__main__":
    main()
