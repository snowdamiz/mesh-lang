from pathlib import Path
import fcntl
import subprocess
import sys

with Path("target/queue-performance.lock").open("a") as lock:
    fcntl.flock(lock, fcntl.LOCK_EX)
    raise SystemExit(subprocess.call(sys.argv[1:]))
