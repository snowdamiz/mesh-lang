#!/usr/bin/env bash
set -euo pipefail
work="$PWD/target/jobs-perf-work"
linux="$PWD/target/linux-queue-perf"
historical="$(cd ../t3-45996d9a/target/jobs-parity && pwd -P)"
guest="$historical/linux-arm-ownership-guest"
compiler="$historical/current-stock-verification/8526a5bd70a1cb37f8fc27611021c90a44a89590/cargo/debug/meshc"
target=aarch64-unknown-linux-gnu
export JOBS_LINUX_CROSS_ZIG="$work/tooling/zig-aarch64-macos-0.15.2/zig"
export JOBS_LINUX_PROOF_LIBGCC="$guest/stock-jobs-smoke/dso-audit/libgcc_s.so.1"
export ZIG_LOCAL_CACHE_DIR="$work/zig-local" ZIG_GLOBAL_CACHE_DIR="$work/zig-global"
export TMPDIR="$work/tmp/"
export PATH="$guest/stock-jobs-smoke/bin:$PATH"
mkdir -p "$work/frozen-fixture"
cp "$linux/fixture/"{main.mpl,worker_identity.mpl,mesh.toml,libworker_identity.a} "$work/frozen-fixture/"
export MESH_RT_LIB_PATH="$work/linux-target/$target/release/libmesh_rt.a"
"$compiler" build "$work/frozen-fixture" --target "$target" --opt-level 2 \
    --output "$work/mesh-frozen-tuned"
shasum -a 256 "$compiler" "$MESH_RT_LIB_PATH" "$work/mesh-frozen-tuned"
