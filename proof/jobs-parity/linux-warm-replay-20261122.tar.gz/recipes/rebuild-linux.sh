#!/usr/bin/env bash
set -euo pipefail
work="$PWD/target/jobs-perf-work"
historical="$(cd ../t3-45996d9a/target/jobs-parity && pwd -P)"
guest="$historical/linux-arm-ownership-guest"
target=aarch64-unknown-linux-gnu
release="$work/tooling/rust-std-1.99.0-$target/rust-std-$target"
host_toolchain="/Users/andreyyurlov/.rustup/toolchains/1.99.0-aarch64-apple-darwin"
mkdir -p "$work/sysroot/lib/rustlib" "$work/tmp" "$work/linux-cargo"
ln -sfh "$release/lib/rustlib/$target" "$work/sysroot/lib/rustlib/$target"
if [[ ! -d "$work/linux-target" ]]; then
    cp -cR "$historical/stock-linux/linux/8526a5bd70a1cb37f8fc27611021c90a44a89590/cargo-target" "$work/linux-target"
fi
export PATH="$host_toolchain/bin:/opt/homebrew/bin:$PATH"
export CARGO_TARGET_DIR="$work/linux-target"
export CARGO_TARGET_AARCH64_UNKNOWN_LINUX_GNU_RUSTFLAGS="--sysroot $work/sysroot"
export CARGO_TARGET_AARCH64_UNKNOWN_LINUX_GNU_LINKER="$guest/gnu-pg-linux-default/bin/rust-linker"
export CC_aarch64_unknown_linux_gnu="$guest/gnu-release/bin/linux-cc"
export AR_aarch64_unknown_linux_gnu=/opt/homebrew/opt/llvm@21/bin/llvm-ar
export JOBS_LINUX_CROSS_ZIG="$work/tooling/zig-aarch64-macos-0.15.2/zig"
export JOBS_LINUX_PROOF_LIBGCC="$guest/stock-jobs-smoke/dso-audit/libgcc_s.so.1"
export CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=4 LLVM_SYS_211_PREFIX=/opt/homebrew/opt/llvm@21
export TMPDIR="$work/tmp/"
export ZIG_LOCAL_CACHE_DIR="$work/zig-local" ZIG_GLOBAL_CACHE_DIR="$work/zig-global"
git diff --cached --check
cargo build --locked --offline --release --target "$target" -p mesh-rt --lib
shasum -a 256 "$work/linux-target/$target/release/libmesh_rt.a"
