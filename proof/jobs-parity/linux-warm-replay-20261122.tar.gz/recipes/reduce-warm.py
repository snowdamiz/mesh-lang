import json
from pathlib import Path
import statistics
import sys

directories = [Path(arg) for arg in sys.argv[1:]]
column_keys = (
    "arm", "completed", "jobs_per_second", "runner_cpu_ms_per_job", "pickup_p99_ms",
    "peak_rss_mib", "peak_executing", "estimated_peak_executing", "peak_sampled_jobs_and_producer_connections",
    "peak_processes", "peak_threads", "peak_queued_context_bytes", "ordered_write_pairs",
    "minimum_hold_ms", "host_start_load_1m", "peak_guest_load_1m",
)
groups = []
for directory in directories:
    for group in sorted(directory.glob("*.evidence")):
        cfg = json.loads((group/"config.json").read_text())
        assert cfg["full_input_warmup"] and not cfg["trace"], group
        run_path = group.with_suffix(".load.jsonl")
        host = [json.loads(line) for line in run_path.read_text().splitlines()]
        inputs = {row["input_sha256"] for row in json.loads((group/"metrics.json").read_text())}
        assert len(inputs) == 1
        arms = cfg["arms"]
        evidence = {
            "name": group.name.removesuffix(".evidence"),
            "profile": cfg["profile"],
            "input_sha256": inputs.pop(),
            "arm_hashes": {arm: cfg["hashes"]["proof/mesh-"+arm] for arm in arms if arm != "oban"},
            "host_load_at_boot": host[0]["load"],
            "configured_mesh_app_connections": 8 if cfg["profile"] == "slow" else 32,
            "postgres_physical_max_connections": 68 if cfg["profile"] == "slow" else 96,
            "arms": [],
        }
        samples = [row for row in host if " measured " in row["event"]]
        assert [row["event"].split()[-1] for row in samples] == arms
        for arm, sample in zip(arms, samples, strict=True):
            metrics = json.loads((group/arm/"metrics.json").read_text())
            proof = json.loads((group/arm/"ordered-writes.json").read_text())
            assert metrics["completed"] == proof["jobs"] == proof["ordered"], (group, arm)
            assert metrics["peak_executing"] <= 64
            cells = [
                arm, metrics["completed"], metrics["jobs_per_second"],
                metrics["cpu_seconds_per_job"] * 1000, metrics["pickup_p99_ms"],
                metrics["peak_rss_bytes"]/1024**2, metrics["peak_executing"],
                metrics["estimated_peak_executing"], metrics["peak_connections"],
                metrics["peak_processes"], metrics["peak_threads"],
                metrics["peak_queued_context_bytes"], proof["ordered"],
                proof["minimum_hold_ms"], sample["load"][0],
                metrics["peak_host_load_average_1m"],
            ]
            evidence["arms"].append([round(v,4) if isinstance(v,float) else v for v in cells])
        groups.append(evidence)
print(json.dumps({"trial_columns": column_keys, "groups": groups}, indent=2, sort_keys=True))
