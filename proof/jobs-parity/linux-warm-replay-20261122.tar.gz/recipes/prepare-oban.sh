#!/bin/bash
# Called from run-group.py while holding the shared lock.
set -euo pipefail
cd "$(dirname "$0")"
phase="$PWD/oban-build"
sibling="$(cd ../../../t3-45996d9a/target/jobs-parity && pwd)"
source_path=scripts/fixtures/jobs-parity-oban/lib
mkdir -p "$phase/src" "$phase/ebin"
git show "8526a5bd:$source_path/jobs_parity_oban.ex" > "$phase/src/jobs_parity_oban.ex"
git show "8526a5bd:$source_path/worker.ex" > "$phase/src/worker.ex"
python3 -B - "$phase/src/jobs_parity_oban.ex" <<'PY'
from pathlib import Path
import sys
p = Path(sys.argv[1])
code = p.read_text()
old = "pool_size = if slots, do: slots + 2, else: 2"
assert code.count(old) == 1
p.write_text(code.replace(old, """
    pool_size =
      cond do
        slots -> slots + 2
        action == "enqueue" -> 1
        true -> 2
      end
""".strip("\n")))
PY
args=()
for ebin in "$sibling"/build/oban/build/lib/*/ebin; do
    [[ "$ebin" == */jobs_parity_oban/* ]] || args+=(-pa "$ebin")
done
export PATH="/opt/homebrew/bin:$PATH" TMPDIR="$PWD/tmp/"
ELIXIR_ERL_OPTIONS='+S 2:2' elixirc "${args[@]}" -o "$phase/ebin" "$phase/src/"*.ex
cp "$sibling/build/oban/build/lib/jobs_parity_oban/ebin/jobs_parity_oban.app" "$phase/ebin/"
shasum -a 256 "$phase/src/"*.ex "$phase/ebin/"* > "$phase/sha256.txt"
touch "$phase/complete"
