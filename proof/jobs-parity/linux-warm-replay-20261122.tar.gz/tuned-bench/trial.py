"""Unscored reconstruction of the frozen PostgreSQL 17.11 workload pair."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import traceback

import proof_transport

PROOF = Path("/proof")
spec = importlib.util.spec_from_file_location("harness", PROOF/"jobs-parity.py")
h = importlib.util.module_from_spec(spec)
source = spec.origin and Path(spec.origin).read_text()
splice = "if sparse else lambda path, log: subject.enqueue_receipt(env, path, log))"
assert source.count(splice) == 1
source = source.replace(splice, "if sparse or getattr(subject, 'warm_dense', False) else lambda path, log: subject.enqueue_receipt(env, path, log))")
exec(compile(source, spec.origin, "exec"), h.__dict__)
h.CONFIG = PROOF/"jobs-parity-profiles.json"


def process_table():
    rows = {}
    for d in Path("/proc").iterdir():
        if not d.name.isdecimal():
            continue
        try:
            f = (d/"stat").read_text().rsplit(")", 1)[1].split()
        except (FileNotFoundError, ProcessLookupError):
            continue
        if f[0] != "Z":
            rows[int(d.name)] = (int(f[1]), int(f[21]) * 4, f[19])
    return rows


h.process_table = process_table


class Cluster(h.Cluster):
    previous_database = None
    observer_lock = threading.Lock()

    def sql(self, database, query):
        with self.observer_lock:
            return super().sql(database, query)

    def configure_tls(self):
        super().configure_tls()
        with (self.data/"postgresql.conf").open("a") as stream:
            stream.write(f"max_connections = {self.connection_cap}\n"
                         "superuser_reserved_connections = 0\nreserved_connections = 0\n")

    def prepare_database(self, engine):
        if self.previous_database and self.previous_database != engine:
            self.sql("postgres", f"DROP DATABASE {self.previous_database}")
        self.previous_database = engine
        super().prepare_database(engine)
        self.sql(engine, "CREATE EXTENSION pg_stat_statements")
        if engine == "mesh":
            self.sql("postgres", f"""
              ALTER ROLE parity_subject CONNECTION LIMIT {RUNNERS * 4};
              ALTER ROLE parity_producer CONNECTION LIMIT 1;
              DO $$ BEGIN
                IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'compiled_definer') THEN
                  CREATE ROLE compiled_definer NOLOGIN;
                  CREATE ROLE compiled_caller LOGIN;
                END IF;
              END $$;
              ALTER ROLE compiled_caller CONNECTION LIMIT {LANES * RUNNERS}
                PASSWORD '{self.password}';
            """)
            self.sql(engine, """
              REVOKE CONNECT, TEMPORARY ON DATABASE mesh FROM PUBLIC;
              GRANT CONNECT ON DATABASE mesh TO parity_subject, parity_producer, compiled_caller;
            """)
        else:
            self.sql("postgres", f"""
              ALTER ROLE parity_subject CONNECTION LIMIT {64 + RUNNERS * 2};
              ALTER ROLE parity_producer CONNECTION LIMIT 1;
            """)

    def reconcile_trial(self, engine, namespace, enqueued_ids, handler_attempts, commits):
        result = super().reconcile_trial(engine, namespace, enqueued_ids, handler_attempts, commits)
        context = f"'{namespace}'"
        relation, _ = h.job_relation(engine, namespace)
        scope = f"j.namespace = {context}" if engine == "mesh" else "true"
        expected = len(enqueued_ids)
        witness = json.loads(self.sql(engine, f"""
          SELECT json_build_object(
            'jobs', count(*),
            'pids', count(DISTINCT worker_pid),
            'worker_pids', json_agg(DISTINCT worker_pid),
            'ordered', count(*) FILTER (WHERE a.xmin <> e.xmin
               AND pg_xact_commit_timestamp(a.xmin) < pg_xact_commit_timestamp(e.xmin)
               AND pg_xact_commit_timestamp(e.xmin) <= pg_xact_commit_timestamp(j.xmin)),
            'minimum_hold_ms', min(extract(epoch FROM
                (pg_xact_commit_timestamp(e.xmin) - pg_xact_commit_timestamp(a.xmin))) * 1000))
          FROM {relation} j
          JOIN public.mesh_jobs_parity_attempts a ON (a.job_key = j.args->>'key')
          JOIN public.mesh_jobs_parity_effects e ON
             (e.engine, e.namespace, e.job_key) = (a.engine, a.namespace, a.job_key)
          WHERE a.engine = '{engine}' AND a.namespace = {context} AND {scope}
        """))
        assert witness["ordered"] == expected == witness["jobs"], witness
        assert witness["pids"] == (expected if engine == "mesh" else RUNNERS), witness
        assert witness["minimum_hold_ms"] >= HOLD_MS - 1, witness
        if TRACE and engine == "mesh":
            spawned = {}
            waited = {}
            for path in sorted(self.evidence.glob("trace-*/events")):
                trace = [line.split() for line in path.read_text().splitlines()]
                parents = [int(pid) for _, tag, pid, _, _ in trace if tag == "loaded"]
                assert len(parents) == 1
                for stamp, tag, pid, status, code in trace:
                    stamp, pid, status, code = map(int, (stamp, pid, status, code))
                    if tag == "spawn":
                        assert status == 0 and code == parents[0] and pid not in spawned
                        spawned[pid] = stamp
                    elif tag == "reaped":
                        assert (status, code) == (0, 1) and pid not in waited
                        waited[pid] = stamp
            assert spawned.keys() == waited.keys() == set(witness["worker_pids"]), (
                len(spawned), len(waited), len(witness["worker_pids"]))
            assert all(spawned[pid] <= waited[pid] and not Path(f"/proc/{pid}").exists()
                       for pid in waited)
            witness["exact_consuming_waits"] = len(waited)
        h.write_json(self.evidence/"ordered-writes.json", witness)
        return result


class Subject(h.Subject):
    warm_dense = True

    def run(self, env, index, log):
        if TRACE and self.engine == "mesh":
            trace = log.parent/f"trace-{index}"
            trace.mkdir()
            env = dict(env, LD_PRELOAD="/proof/fault.so", MESH_FAULT_TRACE=str(trace),
                       MESH_FAULT_MODE="timing")
        return super().run(env, index, log)

    def call(self, action, env, log):
        result = super().call(action, env, log)
        if action == "migrate" and self.engine == "mesh":
            self.cluster.sql("mesh", "SET ROLE parity_subject;\n" + (PROOF/"fence.sql").read_text())
            self.cluster.sql("mesh", (PROOF/"application.sql").read_text())
        return result


def run(config, root, evidence):
    global RUNNERS, LANES, HOLD_MS, TRACE
    TRACE = config.get("trace", False)
    assert os.uname().machine == "aarch64" and os.getuid() == 65534
    profile = config["profile"]
    RUNNERS, LANES, cap = (1, 8, 68) if profile == "slow" else (8, 4, 96)
    settings = json.loads(h.CONFIG.read_text())
    workload = settings["workloads"][profile]
    HOLD_MS = workload["hold_ms"]
    batches = h.inputs(workload, 64, settings["seed"])
    if "oban" in config["arms"]:
        versions = h.checked([str(PROOF/"oban"), "versions"], log=evidence/"oban-versions.log")
        assert json.loads(versions.splitlines()[-1]) == {"oban":"2.24.2","erlang":"29.1.1","elixir":"1.20.4"}
    def measure(arm, phase, cluster):
        label = f"warmup-{arm}" if phase == "warmup" else arm
        print(f"FROZEN_DIAGNOSTIC_ARM {profile} {phase} {arm}", flush=True)
        engine = "oban" if arm == "oban" else "mesh"
        scratch, out = root/label, evidence/label
        scratch.mkdir()
        out.mkdir()
        cluster.evidence = out
        env = dict(cluster.env, TMPDIR=str(scratch),
                   MESH_SCHEDULER_MIN_WORKERS="2", MESH_SCHEDULER_MAX_WORKERS="2")
        if engine == "mesh":
            env.update(JOBS_PARITY_MESH_BATCH="1", JOBS_PARITY_MESH_LISTEN="1",
                       MESH_EFFECT_LANES=str(LANES), MESH_EFFECT_APP_URL=cluster.url("mesh", "compiled_caller"),
                       MESH_DIAGNOSTIC_JOB_DISABLE_THP="1",
                       MESH_DIAGNOSTIC_DEFER_JOB_SCHEDULER="1",
                       MESH_DIAGNOSTIC_TIMERFD_JOB_WATCHDOG="1")
        command = str(PROOF/("oban" if arm == "oban" else f"mesh-{arm}"))
        subject = Subject(engine, [command], PROOF, cluster, env, variant=arm)
        result = h.run_trial(subject, h.allocate_slots(RUNNERS, 64), workload,
                             batches, scratch, out, settings, 0)
        assert result["input_sha256"] == ({
            "noop": "9afb598e8e80b56fc96689cfbe7a7061d82f8e5e3c33a2c534d680ce3db2528a",
            "slow": "42bb9e2be94c17b36110081430faf2647a04f3a3e0f2decf00e7c216fed462fd",
        }[profile])
        h.write_json(out/"metrics.json", result)
        return result

    arms = config["arms"]
    if config.get("full_input_warmup"):
        scratch, out = root/"cluster", evidence/"cluster"
        scratch.mkdir()
        out.mkdir()
        cluster = Cluster(scratch, out, cap, "17.11")
        try:
            cluster.start()
            warmups = [measure(arm, "warmup", cluster) for arm in arms]
            metrics = [measure(arm, "measured", cluster) for arm in arms]
        finally:
            cluster.stop()
        h.write_json(evidence/"warmups.json", warmups)
    else:
        metrics = []
        for arm in arms:
            scratch, out = root/f"cluster-{arm}", evidence/f"cluster-{arm}"
            scratch.mkdir()
            out.mkdir()
            cluster = Cluster(scratch, out, cap, "17.11")
            try:
                cluster.start()
                metrics.append(measure(arm, "pilot", cluster))
            finally:
                cluster.stop()
    h.write_json(evidence/"metrics.json", metrics)


def main():
    config = json.loads((PROOF/"config.json").read_text())
    with tempfile.TemporaryDirectory(dir="/tmp", prefix="queue-perf-") as temp:
        root = Path(temp)
        evidence = root/"evidence"
        evidence.mkdir()
        h.write_json(evidence/"config.json", config)
        status = 0
        try:
            for name, checksum in config["hashes"].items():
                assert h.digest(Path("/")/name) == checksum, name
            run(config, root, evidence)
        except Exception:
            (evidence/"failure.log").write_text(traceback.format_exc())
            status = 1
        proof_transport.emit(evidence, root/"proof.tar.gz", None, sys.stdout.buffer)
        return status


if __name__ == "__main__":
    sys.exit(main())
