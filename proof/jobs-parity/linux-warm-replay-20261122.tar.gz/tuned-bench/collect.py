import sys
from pathlib import Path
from proof_transport import read_serial, unpack

serial = Path(sys.argv[1])
with serial.open("rb") as stream:
    data, status = read_serial(stream)
out = serial.with_suffix(".evidence")
out.mkdir()
unpack(data, out)
print(out)
sys.exit(status)
