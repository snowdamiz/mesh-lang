"""Run one fresh guest group under the shared host lock."""
import fcntl
import json
import os
from pathlib import Path
import subprocess
import sys
import time

d = Path(__file__).resolve().parent
group, profile, *arms = sys.argv[1:]
assert group.isascii() and group.replace("-", "").isalnum()
image = d / f"{group}.cpio"
serial_path = d / f"{group}.serial"
with (d.parents[1] / "queue-performance.lock").open("a") as lock:
    fcntl.flock(lock, fcntl.LOCK_EX)
    print(f"acquired lock for {group}", flush=True)
    if "oban" in arms and not (d/"oban-build/complete").is_file():
        subprocess.run(["bash", d/"prepare-oban.sh"], check=True)
    if "layout-v2" in arms and not (d/"mesh-layout-v2").is_file():
        subprocess.run([sys.executable, "-B", d/"relink.py", "--worker-entry"], check=True)
    subprocess.run([sys.executable, "-B", d/"pack.py", image.name, profile, *arms], check=True)
    with serial_path.open("xb") as serial, image.with_suffix(".vm.log").open("xb") as vm:
        with image.with_suffix(".load.jsonl").open("x") as receipt, serial_path.open("rb") as observer:
            def record(event):
                print(json.dumps({"event": event, "time": time.time(),
                                  "load": os.getloadavg(), "cores": os.cpu_count()}),
                      file=receipt, flush=True)
            record("boot_start")
            with subprocess.Popen([d/"boot", d/"kernel.Image", image], stdout=serial, stderr=vm) as process:
                deadline = time.monotonic() + 95
                while process.poll() is None:
                    if time.monotonic() > deadline:
                        process.kill()
                        raise TimeoutError(group)
                    for line in observer:
                        if line.startswith(b"FROZEN_DIAGNOSTIC_ARM "):
                            record(line.decode().strip())
                    time.sleep(0.05)
                for line in observer:
                    if line.startswith(b"FROZEN_DIAGNOSTIC_ARM "):
                        record(line.decode().strip())
                record("boot_end")
                if process.returncode:
                    raise subprocess.CalledProcessError(process.returncode, process.args)
subprocess.run([sys.executable, "-B", d/"collect.py", serial_path], check=True)
