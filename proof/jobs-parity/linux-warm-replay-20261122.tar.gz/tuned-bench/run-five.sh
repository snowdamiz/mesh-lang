#!/usr/bin/env bash
set -u
cd "$(dirname "$0")"
export QUEUE_PERF_TRACE=0 QUEUE_PERF_WARMUP=1
orders=("current tuned oban" "oban tuned current" "tuned oban current" "current oban tuned" "oban current tuned")
for pair in 0 1 2 3 4; do
    for profile in noop slow; do
        read -r -a arms <<< "${orders[$pair]}"
        python3 -Bu run-group.py "tuned-$profile-$pair" "$profile" "${arms[@]}" > "tuned-$profile-$pair.log" 2>&1
        printf '%s %s %s\n' "$profile" "$pair" "$?"
    done
done
