#!/usr/bin/env bash
set -euo pipefail
work=target/jobs-perf-work
out="$work/canonical"
digest=fe719b77c033f0c08e61138291eb119487c796476e23fe9fb544711dd50233c8
for pair in 1 2 3 4 5; do
    for profile in noop slow sparse short large; do
        order=()
        if (( pair % 2 == 0 )); then order=(--oban-first); fi
        printf -v stamp '%02d' "$pair"
        name="$profile-$stamp"
        group="$out/$name"
        if [[ -f "$group/evidence/metrics.json" ]]; then
            python3 -B "$work/canonical-source/summarize.py" "$group" >/dev/null
            printf 'verified and skipped %s\n' "$name"
            continue
        fi
        if [[ -e "$group" ]]; then
            printf 'Preserved a partial group at %s. Use a new retry name and retain its receipt.\n' "$group" >&2
            exit 1
        fi
        python3 -B "$work/canonical-recovery/run.py" "$profile" "$group" \
            --mesh "$work/mesh-frozen-final" --mesh-sha256 "$digest" "${order[@]}" > "$out/$name.log" 2>&1
        printf '%s %s 0\n' "$profile" "$pair" | tee -a "$out/runs.log"
    done
done
