"""Recheck the canonical guest transports and summarize paired observations."""

import ast
import hashlib
import json
import math
from pathlib import Path
import sys
import tempfile

work = Path("target/jobs-perf-work")
canonical = work / "canonical"
source = Path("proof/jobs-parity/linux-regression")
sys.path.insert(0, str(source.resolve()))
from proof_transport import read_serial, unpack
from summarize import summarize

settings = json.loads(Path("scripts/jobs-parity-profiles.json").read_text())
profiles = ast.literal_eval(next(
    node.value for node in ast.parse((source / "trial.py").read_text()).body
    if isinstance(node, ast.Assign) and any(
        isinstance(target, ast.Name) and target.id == "PROFILES" for target in node.targets)
))
reference = json.loads((canonical / "sparse-01/evidence/config.json").read_text())
previous = json.loads((canonical / "checkpoint-receipt.json").read_text())
previous = {group["name"]: group for group in previous["groups"]}
result = {"measured_jobs": 0, "warmup_jobs": 0, "measured_oban_runners": 0, "profiles": {}}
for profile, (runners, slots, app_sessions, cap, gib, input_digest) in profiles.items():
    pairs = []
    result["profiles"][profile] = pairs
    for pair in range(1, settings["trial_pairs"] + 1):
        path = canonical / f"{profile}-{pair:02d}"
        output = path / "evidence"
        if "--partial" in sys.argv and not (output / "metrics.json").is_file():
            continue
        group = summarize(path)
        if path.name in previous:
            assert group == previous[path.name], path
        order = ["mesh", "oban"] if pair % 2 else ["oban", "mesh"]
        warm = profile in {"noop", "slow", "large"}
        config = json.loads((output / "config.json").read_text())
        assert config == dict(reference, profile=profile, arms=order, full_input_warmup=warm)
        assert group["input_sha256"] == input_digest
        with (path / "guest.serial").open("rb") as serial:
            flags = [line.decode().strip() for line in serial if line.startswith(b"FROZEN_DIAGNOSTIC_ARM ")]
            serial.seek(0)
            data, status = read_serial(serial)
        assert status == 0, path
        with tempfile.TemporaryDirectory(dir=work / "canonical-recovery") as tmp:
            unpack(data, Path(tmp))
            decoded = {f.relative_to(tmp) for f in Path(tmp).rglob("*") if f.is_file()}
            recorded = {f.relative_to(output) for f in output.rglob("*") if f.is_file()}
            assert decoded == recorded and all(
                (Path(tmp) / f).read_bytes() == (output / f).read_bytes() for f in decoded), path
        points = group["host_load"]
        phases = [point["event"] for point in points]
        assert phases == ["boot_start", *flags, "boot_end"], path
        assert len(points) == (6 if warm else 4)
        assert all(point["cores"] == 15 and len(point["load"]) == 3 for point in points), path
        assert all(a["time"] <= b["time"] for a, b in zip(points, points[1:])), path
        versions = json.loads((output / "oban-versions.log").read_text().splitlines()[0])
        assert versions == {"oban": "2.24.2", "erlang": "29.1.1", "elixir": "1.20.4"}, path
        for arm in group["arms"]:
            m = arm["metrics"]
            engine = m["engine"]
            label = engine if arm["phase"] == "measured" else f"warmup-{engine}"
            raw = json.loads((output / label / "raw.json").read_text())
            jobs = {job["job_key"]: job for job in raw["attempts"]}
            assert len(jobs) == m["completed"] == len(raw["enqueued_ids"])
            assert set(jobs) == set(raw["enqueued_ids"])
            rows = raw["namespace_writes"]
            assert {row[2] for row in rows["jobs"]} == set(jobs)
            assert {tuple(row[:3]) + (row[4],) for row in rows["attempts"]} == {
                tuple(row) for row in rows["effects"]
            }
            assert {row[2] for row in rows["effects"]} == set(jobs)
            assert all(job["recorded_ms"] < job["effected_ms"] <= job["settled_ms"]
                       and job["attempt"] == job["first_handler_attempt"] == job["effect_keys"] == 1
                       and job["hold_ms"] == settings["workloads"][profile]["hold_ms"]
                       for job in jobs.values())
            elapsed_ms = (max(job["settled_ms"] for job in jobs.values())
                          - min(raw["transactions"].values()))
            assert math.isclose(m["jobs_per_second"], 1000 * len(jobs) / elapsed_ms)
            assert math.isclose(m["cpu_seconds_per_job"],
                                raw["runner_cpu_seconds_including_startup_and_idle"] / len(jobs))
            for metric in ("connections", "executing", "processes", "threads", "rss_bytes"):
                assert m[f"peak_{metric}"] == max(sample[metric] for sample in
                                                  raw["samples"] + raw["idle_samples"])
            assert arm["database_and_broker"] == dict(
                user="parity_producer", tls=True, durable=True, commit_timestamps=True,
                max_connections=cap, database_connection_limit=cap, reserve=0, superuser_reserve=0)
            assert m["peak_connections"] <= cap and m["peak_executing"] <= slots
            assert m["events_dropped"] == m["event_logs_dropped"] == 0
            assert len(arm["runner_shutdown_sha256"]) == runners
            if engine == "oban":
                actual = arm["oban_emulator"]
                assert len(actual) == runners
                for runner in actual:
                    assert all(runner[k] == v for k, v in {
                        "schedulers": 2, "schedulers_online": 2, "dirty_cpu_schedulers": 1,
                        "dirty_cpu_schedulers_online": 1, "dirty_io_schedulers": 1, "async_threads": 2,
                        "erl_flags": settings["oban_erl_flags"],
                    }.items())
                    for flag, value in zip(settings["oban_erl_flags"].split()[::2],
                                           settings["oban_erl_flags"].split()[1::2]):
                        argv = runner["argv"]
                        assert [arg for index, arg in enumerate(argv[1:], 1)
                                if argv[index-1] in (flag, "-" + flag[1:])] == [value]
                if arm["phase"] == "measured":
                    result["measured_oban_runners"] += runners
            result[f"{arm['phase']}_jobs"] += m["completed"]
        measured = {arm["metrics"]["engine"]: arm["metrics"] for arm in group["arms"]
                    if arm["phase"] == "measured"}
        record = {
            "name": path.name,
            "order": order,
            "serial_sha256": hashlib.sha256((path / "guest.serial").read_bytes()).hexdigest(),
            "proof_status": status,
            "host_load_1m": {point["event"].split()[-1]: point["load"][0]
                             for point in points if " measured " in point["event"]},
            "host_load_1m_boot_max": max(point["load"][0] for point in points),
        }
        for metric in ("jobs_per_second", "pickup_p99_ms", "cpu_seconds_per_job", "peak_rss_bytes",
                       "peak_connections", "peak_processes", "peak_threads", "peak_executing",
                       "peak_queued_context_bytes", "claim_p99_ms"):
            record[metric] = {engine: m[metric] for engine, m in measured.items()}
        pairs.append(record)
print(json.dumps(result, indent=2))
