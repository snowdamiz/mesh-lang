"""Run the frozen canonical driver using guest assets recovered by hash."""

import json
from hashlib import sha256
from pathlib import Path
import runpy
import stat
import sys
import types

here = Path(__file__).resolve().parent
work = here.parent
source = work / "canonical-source"
sys.path.insert(0, str(source))
import pack

reference = json.loads((work / "canonical/sparse-01/evidence/config.json").read_text())
source_image = work.parent / "large-claim-perf/canonical-01/guest.cpio"
base_size = 78_740_046
guest = here / "guest-inputs"
base_path = guest / "base.cpio"
init_path = guest / "stock-jobs-smoke/init"

if not base_path.exists() or not init_path.exists():
    with source_image.open("rb") as image:
        base = image.read(base_size)
    assert sha256(base).hexdigest() == reference["base_cpio_sha256"]
    init = next(data for name, mode, data in pack.members(base)
                if name == "init" and stat.S_ISREG(mode)
                and sha256(data).hexdigest() == reference["hashes"]["init"])
    init_path.parent.mkdir(parents=True, exist_ok=True)
    base_path.write_bytes(base)
    init_path.write_bytes(init)


def add(archive, name, mode, data=b""):
    encoded_name = name.encode() + b"\0"
    fields = (len(archive) + 1, mode, 0, 0, 1, 0, len(data), 0, 0, 0, 0, len(encoded_name), 0)
    archive.extend(("070701" + "".join(f"{field:08x}" for field in fields)).encode())
    archive.extend(encoded_name)
    archive.extend(b"\0" * (-len(archive) % 4))
    archive.extend(data)
    archive.extend(b"\0" * (-len(archive) % 4))


pack_gnu = types.ModuleType("pack_gnu")
pack_gnu.add = add
sys.modules["pack_gnu"] = pack_gnu
pack.GUEST = guest
pack.BASE = base_path

original_pack = pack.pack


def verified_pack(image, profile, arms, mesh, mesh_sha, assets):
    original_pack(image, profile, arms, mesh, mesh_sha, assets)
    with image.open("rb") as stream:
        stream.seek((base_size + 3) & ~3)
        overlay = stream.read()
    config = None
    for name, _, data in pack.members(overlay):
        if name == "proof/config.json":
            config = json.loads(data)
            break
    expected = dict(reference, profile=profile, arms=arms,
                    full_input_warmup=profile in ("noop", "slow", "large"))
    assert config == expected, "Packed manifest differs from the frozen canonical checkpoint"


pack.pack = verified_pack
runpy.run_path(str(source / "run.py"), run_name="__main__")
