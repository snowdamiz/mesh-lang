"""Independently verify archived baseline ledgers and published budget decisions."""

import argparse
import hashlib
import json
import math
from pathlib import Path
import random
from statistics import median
import tarfile


ROOT = Path.cwd()
PROOF = ROOT / "proof/jobs-parity"
SETTINGS = json.loads((ROOT / "scripts/jobs-parity-profiles.json").read_text())
TOPOLOGY = {"noop": (8, 64), "slow": (1, 64), "sparse": (1, 1),
            "short": (1, 16), "large": (8, 64)}
INETRC = "ea95be6f379d135ab873d2da91daeb4d6fcbb593e27db22914bf52aca8543a9c"
CHANGED = {"proof/fixture.exs", "proof/oban", "proof/trial.py",
           "proof/oban.inetrc", "proof/oban_runtime.py"}


def read(path):
    return json.loads(path.read_bytes())


def sha(data):
    return hashlib.sha256(data).hexdigest()


def fixture(profile, slots):
    workload = SETTINGS["workloads"][profile]
    count = max(workload["minimum_jobs"], slots * workload["jobs_per_slot"])
    rng = random.Random(SETTINGS["seed"])
    step = 1 if profile == "sparse" else count
    width = workload["payload_bytes"]
    hold = workload["hold_ms"]
    expected = {}
    digests = []
    for start in range(0, count, step):
        request_id = f"batch_{start:06d}"
        jobs = []
        for index in range(start, start + step):
            key = f"job_{index:06d}"
            payload = rng.randbytes((width + 1) // 2).hex()[:width]
            jobs.append({"key": key, "payload": payload, "hold_ms": hold, "fail_first": False})
            expected[key] = (request_id, sha(payload.encode()))
        batch = dict(request_id=request_id, jobs=jobs, rollback=False)
        digests.append(sha((json.dumps(batch, indent=2, sort_keys=True) + "\n").encode()))
    return sha("".join(digests).encode()), expected, hold


def verify_arm(path, entry, expected, hold, digest, runners):
    raw = read(path / "raw.json")
    metrics = read(path / "metrics.json")
    engine, namespace = metrics["engine"], raw["namespace"]
    assert raw["engine"] == engine and metrics == entry["metrics"], path
    assert sha((path / "raw.json").read_bytes()) == entry["raw_ledger_and_samples_sha256"], path
    assert [sha(log.read_bytes()) for log in sorted(path.glob("runner-*.log"))] == entry["runner_shutdown_sha256"], path
    assert len(entry["runner_shutdown_sha256"]) == runners
    assert raw["case_sha256"] == metrics["input_sha256"] == digest, path
    assert read(path / "database.json") == entry["database_and_broker"], path
    writes = read(path / "ordered-writes.json")
    assert writes == entry["ordered_write_pairs"], path
    assert writes["ordered"] == writes["jobs"] == metrics["completed"] == len(expected), path
    assert writes["minimum_hold_ms"] >= hold - 1, path
    if engine == "mesh":
        assert writes["worker_pids"] == len(expected)
    else:
        assert 0 < writes["worker_pids"] <= runners

    ids, commits = raw["enqueued_ids"], raw["transactions"]
    assert set(ids) == set(expected) and len(set(ids.values())) == len(expected), path
    assert set(commits) == {batch for batch, _ in expected.values()}, path
    rows = raw["attempts"]
    assert {row["job_key"] for row in rows} == set(expected) and len(rows) == len(expected), path
    jobs, attempts, effects = [], [], []
    pickups, claims = [], []
    for row in rows:
        key = row["job_key"]
        batch, payload = expected[key]
        job_id = ids[key]
        effect = f"{job_id}/1" if engine == "mesh" else key
        assert str(row["id"]) == job_id and row["effect_key"] == effect, path
        assert row["payload_sha256"] == payload and row["hold_ms"] == hold and row["fail_first"] is False, path
        assert row["state"] == "completed", path
        assert all(row[k] == 1 for k in ("attempt", "attempts", "first_handler_attempt", "effects", "effect_keys")), path
        assert row["recorded_ms"] < row["effected_ms"] <= row["settled_ms"], path
        assert row["commit_ms"] == commits[batch], path
        pickups.append(max(0, row["entered_ms"] - commits[batch]))
        claims.append(max(0, row["claimed_ms"] - commits[batch]))
        jobs.append([namespace, job_id, key])
        attempts.append([engine, namespace, key, 1, effect])
        effects.append([engine, namespace, key, effect])
    ledger = raw["namespace_writes"]
    assert sorted(ledger["jobs"]) == sorted(jobs), path
    assert sorted(ledger["attempts"]) == sorted(attempts), path
    assert sorted(ledger["effects"]) == sorted(effects), path
    assert sorted(ledger["business"]) == [[engine, namespace, batch] for batch in sorted(commits)], path

    index = (99 * len(rows) + 99) // 100 - 1
    assert metrics["pickup_p99_ms"] == sorted(pickups)[index], path
    assert metrics["claim_p99_ms"] == sorted(claims)[index], path
    elapsed = max(row["settled_ms"] for row in rows) - min(commits.values())
    assert math.isclose(metrics["jobs_per_second"], len(rows) * 1000 / elapsed), path
    assert math.isclose(metrics["cpu_seconds_per_job"], raw["runner_cpu_seconds_including_startup_and_idle"] / len(rows)), path
    for key in ("connections", "processes", "threads", "executing", "rss_bytes"):
        assert metrics[f"peak_{key}"] == max(row[key] for row in raw["samples"] + raw["idle_samples"]), path
    peaks = raw["runner_peak_queued_context_bytes"]
    assert metrics["peak_queued_context_bytes"] == (max(peaks) if peaks and None not in peaks else None), path
    return metrics


def verify_score(profile, groups, score, runners, slots):
    engines = ("mesh", "oban")
    rows = {engine: [pair[engine] for _, pair in groups] for engine in engines}
    summary = score["summary"]
    assert score["pairs"] == [name for name, _ in groups]
    assert score["scored_jobs"] == sum(row["completed"] for trials in rows.values() for row in trials)
    assert score["throughput_pair_wins"] == sum(
        pair["mesh"]["jobs_per_second"] > pair["oban"]["jobs_per_second"] for _, pair in groups
    )
    rules = {
        "jobs_per_second": ("comparison", "core_throughput_ratio_min"),
        "pickup_p99_ms": ("comparison", "core_pickup_p99_ratio_max"),
        "cpu_seconds_per_job": ("budgets", "relative_cpu_seconds_per_job"),
        "peak_rss_bytes": ("budgets", "relative_peak_rss"),
    }
    failures = set()
    for metric, (scope, rule) in rules.items():
        values = [[row[metric] for row in rows[engine]] for engine in engines]
        for engine, series in zip(engines, values):
            assert {name: summary[engine][metric][name] for name in ("min", "median", "max")} == {
                "min": min(series), "median": median(series), "max": max(series)
            }, (profile, engine, metric)
        mesh, oban = map(median, values)
        limit = SETTINGS[rule]
        verdict = summary[scope][metric]
        reference = "oban_median" if scope == "budgets" else "reference_median"
        limit_key = "relative_limit" if scope == "budgets" else "ratio_limit"
        assert (verdict["mesh_median"], verdict[reference], verdict[limit_key]) == (mesh, oban, limit)
        within = mesh > oban * limit if metric == "jobs_per_second" else mesh <= oban * limit
        assert verdict["within_limit"] is within, (profile, scope, metric)
        if not within:
            failures.add(f"{scope}.{metric}")

    caps = {
        "peak_connections": slots + runners * SETTINGS["connection_slots_per_runner"],
        "peak_processes": slots * SETTINGS["processes_per_slot"],
        "peak_threads": (slots * SETTINGS["threads_per_slot"] + runners * SETTINGS["threads_per_runner"]
                         + SETTINGS["threads_per_host"]),
    }
    for engine, trials in rows.items():
        for metric, limit in caps.items():
            observed = max(row[metric] for row in trials)
            within = observed <= limit
            assert summary[engine][metric] == dict(observed=observed, limit=limit, within_limit=within)
            assert summary["budgets"][metric] == limit
            if not within:
                failures.add(f"{engine}.{metric}")
        if profile == "sparse":
            limit = SETTINGS["workloads"][profile]["pickup_p99_budget_ms"]
            within = max(row["pickup_p99_ms"] for row in trials) <= limit
            assert summary[engine]["pickup_p99_ms"]["budget"] == limit
            assert summary[engine]["pickup_p99_ms"]["within_budget"] is within
            if not within:
                failures.add(f"{engine}.pickup_p99_ms")

    mesh_peak = max(row["peak_queued_context_bytes"] for row in rows["mesh"])
    limit = SETTINGS["batch_queued_context_bytes_max"]
    within = 0 < mesh_peak <= limit
    assert summary["mesh"]["peak_queued_context_bytes"] == dict(observed=mesh_peak, limit=limit, within_limit=within)
    if not within:
        failures.add("mesh.peak_queued_context_bytes")
    if profile == "sparse":
        observed = max(row["claim_p99_ms"] for row in rows["mesh"])
        limit = SETTINGS["listener_claim_p99_ms_max"]
        within = observed <= limit
        assert summary["comparison"]["listener_claim_p99_ms"] == dict(observed=observed, limit=limit, within_limit=within)
        if not within:
            failures.add("comparison.listener_claim_p99_ms")
    assert failures == set(score["budget_breaches"]), profile


def verify(root, receipt, score):
    with tarfile.open(PROOF / "linux-canonical-raw-20261122.tar.gz") as old:
        original = json.load(old.extractfile("sparse-01/evidence/config.json"))
    groups = receipt["groups"]
    rounds = SETTINGS["trial_pairs"] if score is not None else 1
    names = [f"{profile}-{pair:02d}" for profile in TOPOLOGY for pair in range(1, rounds + 1)]
    assert [group["name"] for group in groups] == names
    assert sorted(path.name for path in root.iterdir() if path.name != "recovery") == sorted(names)
    if score is not None:
        assert score.keys() == TOPOLOGY.keys()
    jobs = {"measured": 0, "warmup": 0}
    for profile, (runners, slots) in TOPOLOGY.items():
        digest, expected, hold = fixture(profile, slots)
        observations = []
        for group in [group for group in groups if group["profile"] == profile]:
            name = group["name"]
            path = root / name / "evidence"
            config = read(path / "config.json")
            proof_hashes = config["hashes"]
            original_hashes = original["hashes"]
            assert all(proof_hashes[k] == original_hashes[k] for k in original_hashes.keys() - CHANGED), name
            assert proof_hashes.keys() == original_hashes.keys() | {
                "proof/oban.inetrc", "proof/oban_runtime.py"
            }, name
            assert {key for key, value in proof_hashes.items() if original_hashes.get(key) != value} == CHANGED, name
            assert proof_hashes["proof/oban.inetrc"] == INETRC, name
            for pin in ("base_cpio_sha256", "kernel_sha256", "oban_revision", "oban_erl_flags"):
                assert original[pin] == config[pin], (name, pin)
            assert config["profile"] == profile and config["series"] == "canonical-oban-flags-inetrc", name
            assert config["oban_erl_inetrc"] == "/proof/oban.inetrc", name
            assert sha((path / "config.json").read_bytes()) == group["manifest_sha256"], name
            assert group["input_sha256"] == digest
            order = ["mesh", "oban"] if int(name.split("-")[1]) % 2 else ["oban", "mesh"]
            warm = profile in {"noop", "slow", "large"}
            assert config["arms"] == order and config["full_input_warmup"] is warm, name
            phases = ["warmup", "measured"] if warm else ["measured"]
            assert len(group["arms"]) == 2 * len(phases)
            measured = {}
            for phase in phases:
                entries = [arm for arm in group["arms"] if arm["phase"] == phase]
                assert [arm["metrics"]["engine"] for arm in entries] == order
                raw_metrics = []
                for entry in entries:
                    engine = entry["metrics"]["engine"]
                    label = engine if phase == "measured" else f"warmup-{engine}"
                    metrics = verify_arm(path / label, entry, expected, hold, digest, runners)
                    raw_metrics.append(metrics)
                    jobs[phase] += metrics["completed"]
                    if phase == "measured":
                        measured[engine] = metrics
                assert read(path / ("metrics.json" if phase == "measured" else "warmups.json")) == raw_metrics, name
            observations.append((name, measured))
        assert len(observations) == rounds
        if score is not None:
            verify_score(profile, observations, score[profile], runners, slots)
    assert jobs == {"measured": 3504 * rounds, "warmup": 3200 * rounds}, jobs
    print(f"Verified {len(groups)} pairs, {jobs['measured']} measured jobs and {jobs['warmup']} warmup jobs.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("extracted", type=Path)
    parser.add_argument("receipt", type=Path)
    parser.add_argument("score", type=Path, nargs="?")
    args = parser.parse_args()
    verify(args.extracted, read(args.receipt), read(args.score) if args.score else None)
