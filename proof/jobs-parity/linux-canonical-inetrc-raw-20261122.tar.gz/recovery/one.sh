#!/usr/bin/env bash
set -euo pipefail
work=target/jobs-perf-work
guest="$work/canonical-recovery/guest-inputs"
p=proof/jobs-parity/linux-regression
export TMPDIR="$PWD/$work/tmp/"
profile="$1"
group="$2"
shift 2
validate() {
    python3 -B - "$p" "$group" <<'PY'
from pathlib import Path
import sys

sys.path.insert(0, str(Path(sys.argv[1]).resolve()))
from proof_transport import read_serial
from summarize import summarize

path = Path(sys.argv[2])
with (path / "guest.serial").open("rb") as serial:
    assert read_serial(serial)[1] == 0, path
summarize(path)
PY
}
if [[ -f "$group/evidence/metrics.json" ]]; then
    validate
    printf 'verified and skipped %s\n' "$group"
    exit
fi
if [[ -e "$group" ]]; then
    printf 'Preserved incomplete group %s\n' "$group" >&2
    exit 1
fi
python3 -B "$p/run.py" "$profile" "$group" \
    --mesh "$work/mesh-frozen-final" \
    --mesh-sha256 fe719b77c033f0c08e61138291eb119487c796476e23fe9fb544711dd50233c8 \
    --guest-base "$guest/base.cpio" --guest-init "$guest/stock-jobs-smoke/init" \
    "$@" > "$group.log" 2>&1
validate
printf 'verified %s\n' "$group"
