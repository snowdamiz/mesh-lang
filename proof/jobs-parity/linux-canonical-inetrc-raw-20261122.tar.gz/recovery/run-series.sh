#!/usr/bin/env bash
set -euo pipefail
work=target/jobs-perf-work/canonical-inetrc
mkdir -p "$work/series"
for pair in 1 2 3 4 5; do
    order=()
    if (( pair % 2 == 0 )); then order=(--oban-first); fi
    printf -v stamp '%02d' "$pair"
    for profile in noop slow sparse short large; do
        bash "$work/one.sh" "$profile" "$work/series/$profile-$stamp" "${order[@]}"
    done
done
