//! Wadler-Lindig printer for the Mesh format IR.
//!
//! The printer converts a `FormatIR` tree into a formatted string by deciding
//! at each `Group` boundary whether to render flat (all on one line) or broken
//! (with line breaks and indentation). This approach produces optimal layouts
//! that respect the configured line width.

use crate::ir::FormatIR;

/// Configuration for the formatter output.
#[derive(Debug, Clone)]
pub struct FormatConfig {
    /// Number of spaces per indentation level. Default: 2.
    pub indent_size: usize,
    /// Maximum line width before groups break. Default: 100.
    pub max_width: usize,
}

impl Default for FormatConfig {
    fn default() -> Self {
        Self {
            indent_size: 2,
            max_width: 100,
        }
    }
}

/// Whether the current context is rendering flat or broken.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum Mode {
    /// Everything on one line; `Space` renders as " ".
    Flat,
    /// Line breaks at `Space` positions; `Space` renders as newline + indent.
    Break,
}

/// A command on the printer's work stack.
#[derive(Debug)]
struct PrintCmd<'a> {
    indent: usize,
    mode: Mode,
    ir: &'a FormatIR,
}

fn group_fits_on_line(col: usize, flat_width: usize, max_width: usize) -> bool {
    if flat_width == usize::MAX || col > max_width {
        return false;
    }

    flat_width <= max_width.saturating_sub(col)
}

fn trim_line_end(out: &mut String) {
    while matches!(out.as_bytes().last(), Some(b' ' | b'\t')) {
        out.pop();
    }
}

/// Render a `FormatIR` tree as a formatted string respecting the given config.
///
/// The algorithm uses a stack-based approach: at each `Group`, it measures
/// whether the flat rendering fits on the remaining line. If so, the group
/// is rendered flat; otherwise, it switches to broken mode.
pub fn print(ir: &FormatIR, config: &FormatConfig) -> String {
    let mut out = String::new();
    let mut col: usize = 0;
    // Set by `LineEnd`: the next text must start on a new line.
    let mut line_ended = false;
    // Where the current line's text starts, and whether the last text began
    // the line (a comment on a line of its own) rather than followed code.
    let mut line_indent: usize = 0;
    let mut last_text_began_line = false;
    let mut stack: Vec<PrintCmd> = vec![PrintCmd {
        indent: 0,
        mode: Mode::Break,
        ir,
    }];

    while let Some(cmd) = stack.pop() {
        match cmd.ir {
            FormatIR::Empty => {}

            FormatIR::Text(s) => {
                if line_ended {
                    if s.trim().is_empty() {
                        continue; // a separator space; the pending newline replaces it
                    }
                    // Code that a comment ending a line of code cut off continues
                    // its statement, one level in; a closing bracket or `end`
                    // lines up with its opening.
                    let closes = s.starts_with([')', ']', '}']) || s == "end";
                    let continues = !last_text_began_line && !closes;
                    let indent = cmd.indent + if continues { config.indent_size } else { 0 };
                    line_ended = false;
                    trim_line_end(&mut out);
                    out.push('\n');
                    out.push_str(&" ".repeat(indent));
                    col = indent;
                    line_indent = indent;
                }
                // A block comment keeps a space from the code after it
                // (`#= why =# x`); nothing else ends in `=#`.
                if out.ends_with("=#") && !s.starts_with([' ', ')', ']', '}', ',']) {
                    out.push(' ');
                    col += 1;
                }
                last_text_began_line = col == line_indent;
                out.push_str(s);
                col += s.len();
            }

            FormatIR::LineEnd => line_ended = true,

            FormatIR::Space => match cmd.mode {
                Mode::Flat if !line_ended => {
                    out.push(' ');
                    col += 1;
                }
                _ => {
                    line_ended = false;
                    trim_line_end(&mut out);
                    out.push('\n');
                    let indent_str = " ".repeat(cmd.indent);
                    out.push_str(&indent_str);
                    col = cmd.indent;
                    line_indent = cmd.indent;
                }
            },

            FormatIR::Hardline => {
                line_ended = false;
                trim_line_end(&mut out);
                out.push('\n');
                let indent_str = " ".repeat(cmd.indent);
                out.push_str(&indent_str);
                col = cmd.indent;
                line_indent = cmd.indent;
            }

            FormatIR::Indent(child) => {
                stack.push(PrintCmd {
                    indent: cmd.indent + config.indent_size,
                    mode: cmd.mode,
                    ir: child,
                });
            }

            FormatIR::Group(child) => {
                // The group fits when it and what follows it on the line do:
                // `f(a, b) -> Result<(A, B), E> do` breaks the parameters.
                let flat_width = measure_flat(child);
                let limit = config.max_width.saturating_sub(col);
                let width = match flat_width {
                    usize::MAX => usize::MAX,
                    w => w.saturating_add(rest_of_line_width(&stack, limit)),
                };
                if group_fits_on_line(col, width, config.max_width) {
                    // Fits on one line: render flat.
                    stack.push(PrintCmd {
                        indent: cmd.indent,
                        mode: Mode::Flat,
                        ir: child,
                    });
                } else {
                    // Doesn't fit: render broken.
                    stack.push(PrintCmd {
                        indent: cmd.indent,
                        mode: Mode::Break,
                        ir: child,
                    });
                }
            }

            FormatIR::IfBreak { flat, broken } => match cmd.mode {
                Mode::Flat => {
                    stack.push(PrintCmd {
                        indent: cmd.indent,
                        mode: cmd.mode,
                        ir: flat,
                    });
                }
                Mode::Break => {
                    stack.push(PrintCmd {
                        indent: cmd.indent,
                        mode: cmd.mode,
                        ir: broken,
                    });
                }
            },

            FormatIR::Concat(parts) => {
                // Push in reverse order so the first element is processed first.
                for part in parts.iter().rev() {
                    stack.push(PrintCmd {
                        indent: cmd.indent,
                        mode: cmd.mode,
                        ir: part,
                    });
                }
            }
        }
    }

    // Ensure output ends with a newline (canonical formatting).
    trim_line_end(&mut out);
    if !out.is_empty() && !out.ends_with('\n') {
        out.push('\n');
    }

    out
}

/// Width of what the stack prints after the current group before the line can
/// end, each command in its own mode. A later group counts as broken, since it
/// can still break itself when reached. Stops early once past `limit`.
fn rest_of_line_width(stack: &[PrintCmd], limit: usize) -> usize {
    let mut width = 0usize;
    let mut todo: Vec<(Mode, &FormatIR)> = Vec::new();
    for cmd in stack.iter().rev() {
        todo.push((cmd.mode, cmd.ir));
        while let Some((mode, ir)) = todo.pop() {
            match ir {
                FormatIR::Empty => {}
                FormatIR::Text(s) => {
                    width += s.len();
                    if width > limit {
                        return width;
                    }
                }
                FormatIR::Space if mode == Mode::Flat => width += 1,
                FormatIR::Space | FormatIR::Hardline | FormatIR::LineEnd => return width,
                FormatIR::Indent(child) | FormatIR::Group(child) => todo.push((mode, child)),
                FormatIR::IfBreak { flat, broken } => {
                    todo.push((mode, if mode == Mode::Flat { flat } else { broken }))
                }
                FormatIR::Concat(parts) => todo.extend(parts.iter().rev().map(|p| (mode, p))),
            }
        }
    }
    width
}

/// Measure the width of an IR node when rendered flat (all on one line).
///
/// Returns `usize::MAX` if the node contains a `Hardline` (which forces a break
/// and thus can never fit flat on a single line).
fn measure_flat(ir: &FormatIR) -> usize {
    match ir {
        FormatIR::Empty => 0,
        FormatIR::Text(s) => s.len(),
        FormatIR::Space => 1,
        FormatIR::Hardline | FormatIR::LineEnd => usize::MAX, // Forces a break
        FormatIR::Indent(child) => measure_flat(child),
        FormatIR::Group(child) => measure_flat(child),
        FormatIR::IfBreak { flat, .. } => measure_flat(flat),
        // A forced break anywhere ends the measuring.
        FormatIR::Concat(parts) => parts
            .iter()
            .try_fold(0usize, |total, part| match measure_flat(part) {
                usize::MAX => None,
                width => Some(total.saturating_add(width)),
            })
            .unwrap_or(usize::MAX),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::ir::*;

    fn default_config() -> FormatConfig {
        FormatConfig::default()
    }

    #[test]
    fn group_fits_renders_flat() {
        // Group(Concat([Text("a"), Space, Text("b")])) should render as "a b\n"
        let ir = group(concat(vec![text("a"), space(), text("b")]));
        let result = print(&ir, &default_config());
        assert_eq!(result, "a b\n");
    }

    #[test]
    fn group_exceeds_width_breaks() {
        // With max_width=10, a group with 15 chars of text should break.
        let config = FormatConfig {
            indent_size: 2,
            max_width: 10,
        };
        let ir = group(concat(vec![
            text("hello"),
            space(),
            text("beautiful"),
            space(),
            text("world"),
        ]));
        let result = print(&ir, &config);
        assert_eq!(result, "hello\nbeautiful\nworld\n");
    }

    #[test]
    fn hardline_always_breaks() {
        let ir = concat(vec![text("a"), hardline(), text("b")]);
        let result = print(&ir, &default_config());
        assert_eq!(result, "a\nb\n");
    }

    #[test]
    fn indent_adds_spaces() {
        let ir = concat(vec![
            text("fn foo() do"),
            indent(concat(vec![hardline(), text("body")])),
            hardline(),
            text("end"),
        ]);
        let result = print(&ir, &default_config());
        assert_eq!(result, "fn foo() do\n  body\nend\n");
    }

    #[test]
    fn nested_indent() {
        let ir = concat(vec![
            text("a"),
            indent(concat(vec![
                hardline(),
                text("b"),
                indent(concat(vec![hardline(), text("c")])),
            ])),
            hardline(),
            text("d"),
        ]);
        let result = print(&ir, &default_config());
        assert_eq!(result, "a\n  b\n    c\nd\n");
    }

    #[test]
    fn if_break_flat_mode() {
        // Group that fits => flat mode => if_break selects flat variant.
        let ir = group(concat(vec![
            text("("),
            if_break(
                text("x, y"),
                concat(vec![text("x,"), hardline(), text("y")]),
            ),
            text(")"),
        ]));
        let result = print(&ir, &default_config());
        assert_eq!(result, "(x, y)\n");
    }

    #[test]
    fn if_break_broken_mode() {
        // Group that doesn't fit => broken mode => if_break selects broken variant.
        let config = FormatConfig {
            indent_size: 2,
            max_width: 5,
        };
        let ir = group(concat(vec![
            text("("),
            if_break(
                text("x, y, z"),
                concat(vec![
                    hardline(),
                    text("x,"),
                    hardline(),
                    text("y,"),
                    hardline(),
                    text("z"),
                ]),
            ),
            text(")"),
        ]));
        let result = print(&ir, &config);
        assert_eq!(result, "(\nx,\ny,\nz)\n");
    }

    #[test]
    fn empty_produces_nothing() {
        let ir = concat(vec![text("a"), FormatIR::Empty, text("b")]);
        let result = print(&ir, &default_config());
        assert_eq!(result, "ab\n");
    }

    #[test]
    fn nested_groups() {
        // Inner group fits flat, outer group might break.
        let config = FormatConfig {
            indent_size: 2,
            max_width: 20,
        };
        let ir = group(concat(vec![
            text("let x ="),
            space(),
            group(concat(vec![
                text("a"),
                space(),
                text("+"),
                space(),
                text("b"),
            ])),
        ]));
        let result = print(&ir, &config);
        assert_eq!(result, "let x = a + b\n");
    }

    #[test]
    fn space_in_broken_mode_uses_indent() {
        let config = FormatConfig {
            indent_size: 4,
            max_width: 5,
        };
        // "aaaa bbbb" is 9 chars, exceeds max_width=5 => group breaks.
        // Indent applies to the Space -> newline transition.
        let ir = group(indent(concat(vec![text("aaaa"), space(), text("bbbb")])));
        let result = print(&ir, &config);
        assert_eq!(result, "aaaa\n    bbbb\n");
    }

    #[test]
    fn measure_flat_hardline_returns_max() {
        let ir = concat(vec![text("a"), hardline(), text("b")]);
        assert_eq!(measure_flat(&ir), usize::MAX);
    }

    #[test]
    fn grouped_hardline_breaks_instead_of_overflowing() {
        let ir = group(concat(vec![text("a"), hardline(), text("b")]));
        let result = print(&ir, &default_config());
        assert_eq!(result, "a\nb\n");
    }
}
