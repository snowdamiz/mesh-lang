//! End-to-end integration tests for the Mesh compiler.
//!
//! Each test writes a `.mpl` source file, invokes the full compilation pipeline,
//! runs the resulting binary, and asserts the expected stdout output.

use std::path::{Path, PathBuf};
use std::process::Command;

#[path = "support/test_artifacts.rs"]
mod artifacts;

/// Helper: compile a Mesh source file and run the resulting binary, returning stdout.
fn compile_and_run(source: &str) -> String {
    compile_and_run_with_env(source, &[])
}

/// Helper: compile a Mesh source file and run the resulting binary with environment variables set.
fn compile_and_run_with_env(source: &str, env_vars: &[(&str, &str)]) -> String {
    let run_output = compile_and_run_output(source, env_vars);
    assert!(
        run_output.status.success(),
        "binary execution failed with exit code {:?}:\nstdout: {}\nstderr: {}",
        run_output.status.code(),
        String::from_utf8_lossy(&run_output.stdout),
        String::from_utf8_lossy(&run_output.stderr)
    );

    String::from_utf8_lossy(&run_output.stdout).to_string()
}

/// Helper: compile a Mesh source file and run the resulting binary, whatever
/// its exit status, returning its output.
fn compile_and_run_output(source: &str, env_vars: &[(&str, &str)]) -> std::process::Output {
    let temp_dir = tempfile::tempdir().expect("failed to create temp dir");
    let project_dir = temp_dir.path().join("project");
    std::fs::create_dir_all(&project_dir).expect("failed to create project dir");

    let main_mesh = project_dir.join("main.mpl");
    std::fs::write(&main_mesh, source).expect("failed to write main.mpl");

    let meshc = find_meshc();
    let output = Command::new(&meshc)
        .args(["build", project_dir.to_str().unwrap()])
        .output()
        .expect("failed to invoke meshc");

    assert!(
        output.status.success(),
        "meshc build failed:\nstdout: {}\nstderr: {}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );

    let binary = project_dir.join("project");
    let mut cmd = Command::new(&binary);
    for (key, val) in env_vars {
        cmd.env(key, val);
    }
    cmd.output()
        .unwrap_or_else(|e| panic!("failed to run binary: {}", e))
}

/// Helper: compile a Mesh source file, return the compilation error.
fn compile_expect_error(source: &str) -> String {
    let temp_dir = tempfile::tempdir().expect("failed to create temp dir");
    let project_dir = temp_dir.path().join("project");
    std::fs::create_dir_all(&project_dir).expect("failed to create project dir");

    let main_mesh = project_dir.join("main.mpl");
    std::fs::write(&main_mesh, source).expect("failed to write main.mpl");

    let meshc = find_meshc();
    let output = Command::new(&meshc)
        .args(["build", project_dir.to_str().unwrap()])
        .output()
        .expect("failed to invoke meshc");

    assert!(
        !output.status.success(),
        "expected compilation to fail but it succeeded"
    );

    String::from_utf8_lossy(&output.stderr).to_string()
}

fn find_meshc() -> PathBuf {
    artifacts::meshc_bin()
}

/// Read a test fixture from the tests/e2e/ directory.
fn read_fixture(name: &str) -> String {
    let manifest_dir = env!("CARGO_MANIFEST_DIR");
    let fixture_path = Path::new(manifest_dir)
        .parent()
        .unwrap()
        .parent()
        .unwrap()
        .join("tests")
        .join("e2e")
        .join(name);
    std::fs::read_to_string(&fixture_path)
        .unwrap_or_else(|e| panic!("failed to read fixture {}: {}", fixture_path.display(), e))
}

// ── E2E Tests ────────────────────────────────────────────────────────────

/// SC1: Hello World program compiles and runs.
#[test]
fn e2e_hello_world() {
    let source = read_fixture("hello.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "Hello, World!\n");
}

/// SC2: Functions with integer arithmetic.
#[test]
fn e2e_functions() {
    let source = read_fixture("functions.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "7\n10\n");
}

/// SC2: Integer pattern matching in case expressions.
#[test]
fn e2e_pattern_match() {
    let source = read_fixture("pattern_match.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "zero\none\nother\n");
}

/// Atoms match as patterns (in `case` and `receive`), compare with `==`,
/// print as their names, and key maps. `:ok ->` was a parse error and
/// `a == :ok` had no Eq.
#[test]
fn e2e_atoms() {
    let source = read_fixture("atoms.mpl");
    let output = compile_and_run(&source);
    assert_eq!(
        output,
        "matched ok\nmatched error\nother\nequal: true, different: false\nshown: ready\nmap: 1\nstopped by atom\n"
    );
}

/// A `case` or `receive` guard is any `Bool` expression, arithmetic and
/// negative literals included, as a function clause's guard is.
#[test]
fn e2e_guard_expressions() {
    let source = read_fixture("guard_expressions.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "big\nsmall\nnegative\nover 7\n");
}

/// A negative literal is a parameter pattern, in a function's clauses and a
/// closure's.
#[test]
fn e2e_negative_literal_parameter_patterns() {
    let output = compile_and_run(
        r##"
fn describe(-1) do
  "minus one"
end

fn describe(n) do
  "other #{n}"
end

fn halve(-2.5) do
  "minus two and a half"
end

fn halve(x) do
  "#{x / 2.0}"
end

fn main() do
  println(describe(-1))
  println(describe(3))
  println(halve(-2.5))
  println(halve(3.0))
  let pick = fn -1 -> "neg" | n -> "n=#{n}" end
  println(pick(-1))
  println(pick(4))
end
"##,
    );
    assert_eq!(
        output,
        "minus one\nother 3\nminus two and a half\n1.5\nneg\nn=4\n"
    );
}

/// A `let` outside a function makes no global: a function naming it failed
/// to compile with "Undefined variable". It is error E0080.
#[test]
fn e2e_top_level_let_is_an_error() {
    let err = compile_expect_error(
        "let greeting = \"hello\"\n\nfn main() do\n  println(greeting)\nend\n",
    );
    assert!(
        err.contains("E0080") && err.contains("let greeting"),
        "{err}"
    );
    assert!(!err.contains("Undefined variable"), "{err}");
}

/// A module of the project used without its import was "undefined
/// variable: Geo"; it is error E0081, naming the import to add.
#[test]
fn e2e_module_used_without_import_is_named() {
    let err = compile_expect_error(
        "module Geo do\n  pub fn area(w :: Int) -> Int do\n    w * w\n  end\nend\n\nfn main() do\n  println(\"${Geo.area(2)}\")\nend\n",
    );
    assert!(
        err.contains("E0081") && err.contains("add `import Geo`"),
        "{err}"
    );
    assert!(!err.contains("undefined variable"), "{err}");
}

/// SC2: Closures with captured variables.
#[test]
fn e2e_closures() {
    let source = read_fixture("closures.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "8\n15\n");
}

/// A function returning a value is accepted where a `Fun(..) -> ()` callback
/// is expected, named or closure, and its result is discarded.
#[test]
fn e2e_unit_callbacks_discard_results() {
    let source = read_fixture("unit_callbacks.mpl");
    let output = compile_and_run(&source);
    assert_eq!(
        output,
        "tally 1\ntally 2\nreport 1\nreport 2\nclosure 101\nclosure 102\n"
    );
}

/// SC2: Pipe operator chaining.
#[test]
fn e2e_pipe() {
    let source = read_fixture("pipe.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "11\n");
}

/// SC2: String interpolation with variables.
#[test]
fn e2e_string_interp() {
    let source = read_fixture("string_interp.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "Hello, World!\nThe answer is 42\n");
}

/// STRG-01: #{} string interpolation — new syntax.
#[test]
fn e2e_string_interp_hash() {
    let source = read_fixture("string_interp_hash.mpl");
    let output = compile_and_run(&source);
    assert_eq!(
        output, "Hello, World!\nCount: 3\nFlag: true\nExpr: 7\nNested: prefix-World-suffix\n",
        "#{{}} interpolation must evaluate expressions and embed string representations"
    );
}

/// STRG-02: Triple-quoted heredoc strings with trimIndent.
#[test]
fn e2e_heredoc_basic() {
    let source = read_fixture("heredoc_basic.mpl");
    let output = compile_and_run(&source);
    assert_eq!(
        output, "Hello,\nWorld!\n{\"key\": \"value\"}\n",
        "Heredoc must strip common leading indentation and trailing whitespace line"
    );
}

/// STRG-03: Triple-quoted heredoc with #{{}} interpolation.
#[test]
fn e2e_heredoc_interp() {
    let source = read_fixture("heredoc_interp.mpl");
    let output = compile_and_run(&source);
    assert_eq!(
        output, "{\"id\": 42, \"name\": \"Alice\"}\n",
        "Heredoc interpolation must evaluate #{{expr}} and trim indentation"
    );
}

/// STRG-04: Env.get(key, default) returns env value when set, default when unset.
#[test]
fn e2e_env_get() {
    let source = read_fixture("env_get.mpl");
    let output = compile_and_run_with_env(
        &source,
        &[("MESH_TEST_VAR", "hello"), ("MESH_TEST_EMPTY_VAR", "")],
    );
    assert_eq!(
        output,
        "default_val\nhello\n\n",
        "Env.get must return default for missing var, env value for set var, empty string for empty var"
    );
}

/// STRG-05: Env.get_int(key, default) parses int or returns default.
#[test]
fn e2e_env_get_int() {
    let source = read_fixture("env_get_int.mpl");
    let output = compile_and_run_with_env(
        &source,
        &[
            ("MESH_INT_TEST_VAR", "3000"),
            ("MESH_INT_BAD_VAR", "notanint"),
            ("MESH_INT_NEG_VAR", "-1"),
        ],
    );
    assert_eq!(
        output,
        "8080\n3000\n8080\n-1\n",
        "Env.get_int must return default for missing/non-numeric, parsed value for valid int, negative int supported"
    );
}

/// SC2: ADT sum type construction.
#[test]
fn e2e_adts() {
    let source = read_fixture("adts.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "red created\ngreen created\nblue created\n");
}

/// SC2/SC5: Comprehensive multi-feature test (100+ lines).
#[test]
fn e2e_comprehensive() {
    let source = read_fixture("comprehensive.mpl");
    let output = compile_and_run(&source);
    let expected = "\
30
14
-5
6
zero
one
other
red
green
blue
21
30
20
5
Hello, Mesh!
The answer is 42
4
logic works
";
    assert_eq!(output, expected);
}

/// SC4: --emit-llvm flag produces .ll file.
#[test]
fn e2e_emit_llvm() {
    let temp_dir = tempfile::tempdir().expect("failed to create temp dir");
    let project_dir = temp_dir.path().join("project");
    std::fs::create_dir_all(&project_dir).expect("failed to create project dir");

    let source = read_fixture("hello.mpl");
    let main_mesh = project_dir.join("main.mpl");
    std::fs::write(&main_mesh, &source).expect("failed to write main.mpl");

    let meshc = find_meshc();
    let output = Command::new(&meshc)
        .args(["build", project_dir.to_str().unwrap(), "--emit-llvm"])
        .output()
        .expect("failed to invoke meshc");

    assert!(
        output.status.success(),
        "meshc build --emit-llvm failed:\nstderr: {}",
        String::from_utf8_lossy(&output.stderr)
    );

    // Check that .ll file was created
    let ll_file = project_dir.join("project.ll");
    assert!(
        ll_file.exists(),
        "Expected LLVM IR file at {}",
        ll_file.display()
    );

    let ir_content = std::fs::read_to_string(&ll_file).unwrap();
    assert!(
        ir_content.contains("define"),
        "LLVM IR should contain function definitions"
    );
    assert!(
        ir_content.contains("mesh_println"),
        "LLVM IR should reference mesh_println"
    );
}

/// SC4: --target flag accepts a triple.
#[test]
fn e2e_target_flag() {
    let temp_dir = tempfile::tempdir().expect("failed to create temp dir");
    let project_dir = temp_dir.path().join("project");
    std::fs::create_dir_all(&project_dir).expect("failed to create project dir");

    let source = read_fixture("hello.mpl");
    let main_mesh = project_dir.join("main.mpl");
    std::fs::write(&main_mesh, &source).expect("failed to write main.mpl");

    // Use host triple
    let triple = match (std::env::consts::ARCH, std::env::consts::OS) {
        ("aarch64", "macos") => "aarch64-apple-darwin",
        ("x86_64", "macos") => "x86_64-apple-darwin",
        ("aarch64", "linux") => "aarch64-unknown-linux-gnu",
        _ => "x86_64-unknown-linux-gnu",
    };

    let meshc = find_meshc();
    let output = Command::new(&meshc)
        .args(["build", project_dir.to_str().unwrap(), "--target", triple])
        .output()
        .expect("failed to invoke meshc");

    assert!(
        output.status.success(),
        "meshc build --target {} failed:\nstderr: {}",
        triple,
        String::from_utf8_lossy(&output.stderr)
    );

    // Run the binary (should work since it's the host triple)
    let binary = project_dir.join("project");
    let run_output = Command::new(&binary)
        .output()
        .expect("failed to run binary");
    assert!(run_output.status.success());
    assert_eq!(
        String::from_utf8_lossy(&run_output.stdout),
        "Hello, World!\n"
    );
}

/// SC5: Both -O0 and -O2 optimization levels work.
#[test]
fn e2e_optimization_levels() {
    for opt_level in &["0", "2"] {
        let temp_dir = tempfile::tempdir().expect("failed to create temp dir");
        let project_dir = temp_dir.path().join("project");
        std::fs::create_dir_all(&project_dir).expect("failed to create project dir");

        let source = read_fixture("hello.mpl");
        let main_mesh = project_dir.join("main.mpl");
        std::fs::write(&main_mesh, &source).expect("failed to write main.mpl");

        let meshc = find_meshc();
        let output = Command::new(&meshc)
            .args([
                "build",
                project_dir.to_str().unwrap(),
                "--opt-level",
                opt_level,
            ])
            .output()
            .expect("failed to invoke meshc");

        assert!(
            output.status.success(),
            "meshc build --opt-level={} failed:\nstderr: {}",
            opt_level,
            String::from_utf8_lossy(&output.stderr)
        );

        let binary = project_dir.join("project");
        let run_output = Command::new(&binary)
            .output()
            .expect("failed to run binary");
        assert!(
            run_output.status.success(),
            "Binary compiled with -O{} failed to run",
            opt_level
        );
        assert_eq!(
            String::from_utf8_lossy(&run_output.stdout),
            "Hello, World!\n"
        );
    }
}

/// SC3: Binary is self-contained (no dynamic mesh_rt dependency).
#[test]
fn e2e_self_contained_binary() {
    let temp_dir = tempfile::tempdir().expect("failed to create temp dir");
    let project_dir = temp_dir.path().join("project");
    std::fs::create_dir_all(&project_dir).expect("failed to create project dir");

    let source = read_fixture("hello.mpl");
    let main_mesh = project_dir.join("main.mpl");
    std::fs::write(&main_mesh, &source).expect("failed to write main.mpl");

    let meshc = find_meshc();
    let output = Command::new(&meshc)
        .args(["build", project_dir.to_str().unwrap()])
        .output()
        .expect("failed to invoke meshc");
    assert!(output.status.success());

    let binary = project_dir.join("project");

    // Check that the binary doesn't have a dynamic dependency on mesh_rt
    // On macOS, use `otool -L`; on Linux, use `ldd`
    if cfg!(target_os = "macos") {
        let otool_output = Command::new("otool")
            .args(["-L", binary.to_str().unwrap()])
            .output()
            .expect("failed to run otool");
        let deps = String::from_utf8_lossy(&otool_output.stdout);
        assert!(
            !deps.contains("mesh_rt"),
            "Binary should not dynamically link mesh_rt. Dependencies:\n{}",
            deps
        );
    } else {
        let ldd_output = Command::new("ldd").arg(binary.to_str().unwrap()).output();
        if let Ok(out) = ldd_output {
            let deps = String::from_utf8_lossy(&out.stdout);
            assert!(
                !deps.contains("mesh_rt"),
                "Binary should not dynamically link mesh_rt. Dependencies:\n{}",
                deps
            );
        }
    }
}

// ── Multi-Clause Function E2E Tests (Phase 11) ─────────────────────────

/// Multi-clause functions with literal patterns, recursion, and = expr body form.
#[test]
fn e2e_multi_clause_functions() {
    let source = read_fixture("multi_clause.mpl");
    let output = compile_and_run(&source);
    assert_eq!(
        output,
        "55\nyes\nno\n42\n36\n",
        "Expected: fib(10)=55, to_string(true)=yes, to_string(false)=no, double(21)=42, square(6)=36"
    );
}

/// Multi-clause functions with guard clauses (when keyword).
#[test]
fn e2e_multi_clause_guards() {
    let source = read_fixture("multi_clause_guards.mpl");
    let output = compile_and_run(&source);
    assert_eq!(
        output,
        "5\n3\npositive\nnegative\nzero\n",
        "Expected: abs(-5)=5, abs(3)=3, classify(10)=positive, classify(-3)=negative, classify(0)=zero"
    );
}

/// Multi-clause function error: catch-all not last should produce compilation error.
#[test]
fn e2e_multi_clause_catch_all_not_last() {
    let source = r#"
fn foo(n) = n
fn foo(0) = 0
fn main() do
  println("${foo(1)}")
end
"#;
    let error = compile_expect_error(source);
    assert!(
        error.contains("catch-all") || error.contains("CatchAll") || error.contains("E0022"),
        "Expected catch-all-not-last error, got: {}",
        error
    );
}

/// Multi-clause function error: return type mismatch across clauses.
#[test]
fn e2e_multi_clause_type_mismatch() {
    let source = r#"
fn bar(0) = 0
fn bar(n) = "hello"
fn main() do
  println("${bar(1)}")
end
"#;
    let error = compile_expect_error(source);
    assert!(
        error.contains("expected") || error.contains("mismatch") || error.contains("Int"),
        "Expected type mismatch error, got: {}",
        error
    );
}

// ── Phase 12 Closure Syntax E2E Tests ───────────────────────────────────

/// Bare param closures in pipe chains: the primary Phase 12 use case.
#[test]
fn e2e_closure_bare_params_pipe() {
    let source = read_fixture("closure_bare_params_pipe.mpl");
    let output = compile_and_run(&source);
    assert_eq!(
        output, "24\n",
        "Expected: doubled [2,4,6,8,10], filter >4 -> [6,8,10], sum = 24"
    );
}

/// Multi-clause closures with literal pattern matching.
#[test]
fn e2e_closure_multi_clause() {
    let source = read_fixture("closure_multi_clause.mpl");
    let output = compile_and_run(&source);
    assert_eq!(
        output, "3\n",
        "Expected: 0->0, 1->1, 2->1, 3->1, sum of classified = 3"
    );
}

/// Do/end body closures with multi-statement bodies.
#[test]
fn e2e_closure_do_end_body() {
    let source = read_fixture("closure_do_end_body.mpl");
    let output = compile_and_run(&source);
    assert_eq!(
        output, "15\n",
        "Expected: (1*2+1) + (2*2+1) + (3*2+1) = 3+5+7 = 15"
    );
}

/// Chained pipes with closures: Phase 12 gap closure verification.
/// list |> map(fn x -> x + 1 end) |> filter(fn x -> x > 3 end) |> reduce(0, fn acc, x -> acc + x end)
#[test]
fn e2e_pipe_chain_closures() {
    let source = read_fixture("pipe_chain_closures.mpl");
    let output = compile_and_run(&source);
    assert_eq!(
        output, "15\n",
        "Expected: [1,2,3,4,5] -> map +1 [2,3,4,5,6] -> filter >3 [4,5,6] -> sum 15"
    );
}

// ── Phase 13: String Pattern Matching ────────────────────────────────

/// String pattern matching in case expressions with wildcard default.
#[test]
fn e2e_string_pattern_matching() {
    let source = r#"
fn describe(name :: String) -> String do
  case name do
    "alice" -> "found alice"
    "bob" -> "found bob"
    _ -> "unknown"
  end
end

fn main() do
  println(describe("alice"))
  println(describe("bob"))
  println(describe("charlie"))
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "found alice\nfound bob\nunknown\n");
}

/// String binary == and != comparison.
#[test]
fn e2e_string_equality_comparison() {
    let source = r#"
fn main() do
  let x = "hello"
  if x == "hello" do
    println("equal")
  else
    println("not equal")
  end
  if x != "world" do
    println("different")
  else
    println("same")
  end
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "equal\ndifferent\n");
}

/// String patterns mixed with variable bindings in the same case expression.
#[test]
fn e2e_string_pattern_mixed_with_variable() {
    let source = r#"
fn greet(name :: String) -> String do
  case name do
    "world" -> "Hello, world!"
    other -> "Hi, " <> other <> "!"
  end
end

fn main() do
  println(greet("world"))
  println(greet("Mesh"))
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "Hello, world!\nHi, Mesh!\n");
}

// ── Phase 22: Deriving Clause ─────────────────────────────────────────

/// Struct with all five derivable protocols: Eq, Ord, Display, Debug, Hash.
/// Display produces positional "Point(1, 2)" format.
#[test]
fn e2e_deriving_struct() {
    let source = read_fixture("deriving_struct.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "Point(1, 2)\ntrue\nfalse\n");
}

/// Sum type with deriving: variant-aware Display and Eq, for nullary variants
/// and for variants that carry values.
#[test]
fn e2e_deriving_sum_type() {
    let source = read_fixture("deriving_sum_type.mpl");
    let output = compile_and_run(&source);
    assert_eq!(
        output,
        "Red\nGreen\nBlue\ntrue\nfalse\n\
         Circle(1.5) Rect(2, 3) Named(box-2) Empty\ntrue false true\n"
    );
}

/// Backward compatibility: no deriving clause = derive all defaults.
#[test]
fn e2e_deriving_backward_compat() {
    let source = read_fixture("deriving_backward_compat.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "true\n");
}

/// Selective deriving: only Eq, no other protocols.
#[test]
fn e2e_deriving_selective() {
    let source = read_fixture("deriving_selective.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "true\n");
}

/// Empty deriving clause: opt-out of all auto-derived protocols.
#[test]
fn e2e_deriving_empty() {
    let source = read_fixture("deriving_empty.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "42\n");
}

/// Unsupported trait in deriving clause produces a clear compiler error.
#[test]
fn e2e_deriving_unsupported_trait() {
    let source = r#"
struct Foo do
  x :: Int
end deriving(Clone)

fn main() do
  let f = Foo { x: 1 }
  println("nope")
end
"#;
    let error = compile_expect_error(source);
    assert!(
        error.contains("cannot derive"),
        "Expected 'cannot derive' error, got: {}",
        error
    );
}

// ── Phase 16: Fun() Type Annotations ─────────────────────────────────

/// Fun() type annotations: parsing, positions, and unification with closures.
#[test]
fn e2e_fun_type_annotations() {
    let source = read_fixture("fun_type.mpl");
    let output = compile_and_run(&source);
    assert_eq!(
        output, "42\n99\n30\n",
        "Expected: apply(int_to_str, 42)='42', run_thunk(->99)=99, apply2(add, 10, 20)=30"
    );
}

/// Functions as values: named functions and closures passed, returned,
/// captured, stored in Option/Result/variants/structs/tuples/lists/maps, bound
/// by patterns, piped into, handed to the runtime and sent to an actor. Stored
/// and pattern-bound functions used to lose their environment, and a named
/// function could not be passed to a `Fun` parameter at all.
#[test]
fn e2e_fn_values() {
    let source = read_fixture("fn_values.mpl");
    let output = compile_and_run(&source);
    assert_eq!(
        output,
        "param: 42 8 10 6\n\
         returned: 42 42 42 42 42\n\
         captured: 42 36\n\
         option: 42 16 42\n\
         result: 42 none made\n\
         variant: 42 18 42\n\
         struct: 42 14\n\
         tuple: 47 43\n\
         list: 42 12 42\n\
         map: 42 22\n\
         pipe: 42 42\n\
         runtime: 6 4 2 2\n\
         actor: 42\n"
    );
}

/// Tuple.first / second / nth give the element's own type rather than `Int`:
/// strings, floats, bools, variants, structs and nested tuples, direct and
/// piped, and through a helper whose parameter type is inferred.
#[test]
fn e2e_tuple_accessors_typed() {
    let source = read_fixture("tuple_accessors_typed.mpl");
    let output = compile_and_run(&source);
    assert_eq!(
        output,
        "name-2\n8\n2.5 true\ngreen tag-5\ninner-8 9\nname-2\n\
         name-2 42 k-5:9 1.5:true\n7\n"
    );
}

/// `<`, `>`, `<=`, `>=` and `compare` on strings, which type-checked but had
/// no codegen ("Unsupported binop type: String").
#[test]
fn e2e_string_ordering() {
    let source = read_fixture("string_ordering.mpl");
    let output = compile_and_run(&source);
    assert_eq!(
        output,
        "true false true true false\nless greater equal\napple,fig,pear\n"
    );
}

// ── Phase 23: Pattern Matching Codegen & Ordering ─────────────────────

/// Option field extraction: Some(42) pattern match extracts the inner value.
#[test]
fn e2e_option_field_extraction() {
    let source = read_fixture("option_field_extraction.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "42\n");
}

#[test]
fn e2e_list_get_struct() {
    let source = read_fixture("list_get_struct.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "7\n");
}

#[test]
fn e2e_struct_in_result_roundtrip() {
    let source = read_fixture("struct_in_result_roundtrip.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "141\n-1\n60\n");
}

#[test]
fn e2e_case_bindings_with_the_same_name_keep_their_own_struct_type() {
    let output = compile_and_run(
        r#"
struct Small do
  value :: Int
end

struct Large do
  one :: Int
  two :: Int
  three :: Int
  four :: Int
  five :: Int
  six :: Int
  seven :: Int
  eight :: Int
  nine :: Int
  ten :: Int
  eleven :: Int
  twelve :: Int
end

fn small() -> Small ! String do
  Ok(Small { value: 7 })
end

fn large() -> Large ! String do
  Ok(Large {
    one: 1,
    two: 2,
    three: 3,
    four: 4,
    five: 5,
    six: 6,
    seven: 7,
    eight: 8,
    nine: 9,
    ten: 10,
    eleven: 11,
    twelve: 12
  })
end

fn main() do
  case small() do
    Ok(event) -> println("${event.value}")
    Err(reason) -> println(reason)
  end
  case large() do
    Ok(event) -> println("${event.twelve}")
    Err(reason) -> println(reason)
  end
end
"#,
    );
    assert_eq!(output, "7\n12\n");
}

/// Ordering pattern match: compare(3, 5) returns Less, matched to 1.
#[test]
fn e2e_ordering_pattern_match() {
    let source = read_fixture("ordering_pattern_match.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "1\n");
}

/// Ordering as variable: compare result stored in variable, then matched.
#[test]
fn e2e_ordering_as_variable() {
    let source = read_fixture("ordering_as_variable.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "2\n");
}

/// Nullary constructor pattern match: user-defined sum type with all-nullary variants.
/// Validates that Red/Green/Blue are recognized as constructors, not variables.
#[test]
fn e2e_nullary_constructor_match() {
    let source = read_fixture("nullary_constructor_match.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "1\n2\n3\n");
}

// -- Phase 24: Trait System Generics ────────────────────────────────────

/// Flat collection Display regression check: List<Int> renders via string interpolation.
/// Verifies that the &self -> &mut self signature change does not break existing
/// Display callback resolution for flat collections.
#[test]
fn e2e_nested_collection_display() {
    let source = read_fixture("nested_collection_display.mpl");
    let output = compile_and_run(&source);
    assert_eq!(
        output, "[10, 20, 30]\n",
        "List Display via string interpolation should render as [10, 20, 30]"
    );
    // NOTE: List<List<Int>> e2e test requires generic List element types
    // (List.append currently typed as (List, Int) -> List).
    // Recursive callback resolution is verified at the MIR unit test level
    // in mesh-codegen (nested_list_callback_generates_wrapper).
    // TODO: add full nested e2e test after Plan 02 (generic collection elements).
}

/// Generic type deriving: Box<T> with deriving(Display, Eq) works for Box<Int> and Box<String>.
/// Verifies monomorphized trait function generation at struct literal lowering sites.
#[test]
fn e2e_generic_deriving() {
    let source = read_fixture("generic_deriving.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "Box(42)\nBox(hello)\ntrue\nfalse\n");
}

// ── Phase 28: Trait Deriving Safety ───────────────────────────────────

/// Phase 28: deriving(Ord) without Eq on a struct produces a compile-time error
/// that suggests adding Eq.
#[test]
fn e2e_deriving_ord_without_eq_struct() {
    let source = r#"
struct Foo do
  x :: Int
end deriving(Ord)

fn main() do
  let f = Foo { x: 1 }
  println("nope")
end
"#;
    let error = compile_expect_error(source);
    assert!(
        error.contains("Eq") && (error.contains("requires") || error.contains("without")),
        "Expected error about Ord requiring Eq, got: {}",
        error
    );
}

/// Phase 28: deriving(Ord) without Eq on a sum type produces a compile-time error.
#[test]
fn e2e_deriving_ord_without_eq_sum() {
    let source = r#"
type Direction do
  North
  South
end deriving(Ord)

fn main() do
  println("nope")
end
"#;
    let error = compile_expect_error(source);
    assert!(
        error.contains("Eq") && (error.contains("requires") || error.contains("without")),
        "Expected error about Ord requiring Eq, got: {}",
        error
    );
}

/// Phase 28: deriving(Eq, Ord) together compiles and works correctly.
#[test]
fn e2e_deriving_eq_ord_together() {
    let source = r#"
struct Point do
  x :: Int
  y :: Int
end deriving(Eq, Ord)

fn main() do
  let a = Point { x: 1, y: 2 }
  let b = Point { x: 1, y: 3 }
  println("${a == b}")
  println("${a < b}")
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "false\ntrue\n");
}

// ── Phase 30: Method dot-syntax ──────────────────────────────────────────

/// Phase 30: basic method dot-syntax compiles and runs end-to-end.
/// Uses deriving(Display) which is the standard way to get trait impls on structs.
#[test]
fn e2e_method_dot_syntax_basic() {
    let source = r#"
struct Point do
  x :: Int
  y :: Int
end deriving(Display)

fn main() do
  let p = Point { x: 10, y: 20 }
  println(p.to_string())
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output.trim(), "Point(10, 20)");
}

/// Phase 30: method dot-syntax and string interpolation produce identical output.
/// Both p.to_string() and "${p}" should call the same Display impl.
#[test]
fn e2e_method_dot_syntax_equivalence() {
    let source = r#"
struct Point do
  x :: Int
  y :: Int
end deriving(Display)

fn main() do
  let p = Point { x: 1, y: 2 }
  let a = "${p}"
  let b = p.to_string()
  println(a)
  println(b)
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "Point(1, 2)\nPoint(1, 2)\n");
}

/// Phase 30: field access still works alongside method dot-syntax (regression test).
#[test]
fn e2e_method_dot_syntax_field_access_preserved() {
    let source = r#"
struct Point do
  x :: Int
  y :: Int
end deriving(Display)

fn main() do
  let p = Point { x: 42, y: 99 }
  println("${p.x}")
  println("${p.y}")
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "42\n99\n");
}

/// Phase 30: module-qualified calls still work (regression test).
#[test]
fn e2e_method_dot_syntax_module_qualified_preserved() {
    let source = r#"
fn main() do
  let s = "hello world"
  println("${String.length(s)}")
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output.trim(), "11");
}

/// Phase 30: method dot-syntax on derived Display alongside Eq.
#[test]
fn e2e_method_dot_syntax_multiple_traits() {
    let source = r#"
struct Point do
  x :: Int
  y :: Int
end deriving(Display, Eq)

fn main() do
  let a = Point { x: 1, y: 2 }
  let b = Point { x: 1, y: 2 }
  println(a.to_string())
  println("${a == b}")
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "Point(1, 2)\ntrue\n");
}

/// Phase 31: primitive Int method call via dot-syntax (METH-04).
/// 42.to_string() resolves through Display trait -> mesh_int_to_string.
#[test]
fn e2e_method_dot_syntax_primitive_int() {
    let source = r#"
fn main() do
  let x = 42
  let s = x.to_string()
  println(s)
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output.trim(), "42");
}

/// Phase 31: primitive Bool method call via dot-syntax (METH-04).
/// true.to_string() resolves through Display trait -> mesh_bool_to_string.
#[test]
fn e2e_method_dot_syntax_primitive_bool() {
    let source = r#"
fn main() do
  let b = true
  println(b.to_string())
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output.trim(), "true");
}

/// Phase 31: primitive Float method call via dot-syntax.
/// 3.14.to_string() resolves through Display trait -> mesh_float_to_string.
#[test]
fn e2e_method_dot_syntax_primitive_float() {
    let source = r#"
fn main() do
  let f = 3.14
  println(f.to_string())
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output.trim(), "3.14");
}

/// Phase 31: generic type (List) method call via dot-syntax (METH-05).
/// [1, 2, 3].to_string() resolves through collection Display dispatch.
#[test]
fn e2e_method_dot_syntax_generic_list() {
    let source = r#"
fn main() do
  let xs = [1, 2, 3]
  let s = xs.to_string()
  println(s)
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output.trim(), "[1, 2, 3]");
}

/// Phase 31: chained method calls via true dot-syntax chaining (CHAIN-01).
/// p.to_string().length() chains Display::to_string with String.length.
#[test]
fn e2e_method_dot_syntax_chain_to_string_length() {
    let source = r#"
struct Point do
  x :: Int
  y :: Int
end deriving(Display)

fn main() do
  let p = Point { x: 1, y: 2 }
  let len = p.to_string().length()
  println("${len}")
end
"#;
    let output = compile_and_run(source);
    // "Point(1, 2)" is 11 characters
    assert_eq!(output.trim(), "11");
}

/// Phase 31: mixed field access and method call via dot-syntax (CHAIN-02).
/// p.name.length() chains struct field access with String.length method.
#[test]
fn e2e_method_dot_syntax_mixed_field_method() {
    let source = r#"
struct Person do
  name :: String
  age :: Int
end

fn main() do
  let p = Person { name: "Alice", age: 30 }
  let len = p.name.length()
  println("${len}")
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output.trim(), "5");
}

// ── Method dot-syntax integration ──────────────────────────────────────

/// Struct field access is preserved alongside method dot-syntax.
/// Accesses struct fields (p.x, p.y) AND calls a method (p.to_string()) on
/// the same struct value to prove field access is not intercepted by method resolution.
#[test]
fn e2e_method_dot_syntax_preserves_struct_field_access() {
    let source = r#"
struct Point do
  x :: Int
  y :: Int
end deriving(Display)

fn main() do
  let p = Point { x: 42, y: 99 }
  println("${p.x}")
  println("${p.y}")
  println(p.to_string())
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "42\n99\nPoint(42, 99)\n");
}

/// Module-qualified calls are preserved alongside method dot-syntax.
/// Uses module-qualified String.length(s) syntax to prove it is not intercepted
/// as a method call on the String module.
#[test]
fn e2e_method_dot_syntax_preserves_module_qualified_calls() {
    let source = r#"
fn main() do
  let s = "hello"
  let len = String.length(s)
  println("${len}")
  println("${String.length("world")}")
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "5\n5\n");
}

/// The pipe operator is preserved alongside method dot-syntax.
/// Uses |> to chain function calls, proving pipe desugaring is unaffected
/// by method resolution infrastructure.
#[test]
fn e2e_method_dot_syntax_preserves_pipe_operator() {
    let source = r#"
fn double(x :: Int) -> Int do
  x * 2
end

fn add_ten(x :: Int) -> Int do
  x + 10
end

fn main() do
  let result = 5 |> double |> add_ten
  println("${result}")
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output.trim(), "20");
}

/// Sum type variant access is preserved alongside method dot-syntax.
/// Uses nullary variant constructors and case-matching to prove that sum type
/// construction and pattern matching are not intercepted by method resolution.
#[test]
fn e2e_method_dot_syntax_preserves_sum_type_variants() {
    let source = r#"
type Color do
  Red
  Green
  Blue
end

fn describe(c :: Color) -> Int do
  case c do
    Red -> 1
    Green -> 2
    Blue -> 3
  end
end

fn main() do
  let r = Red
  let g = Green
  println("${describe(r)}")
  println("${describe(g)}")
  println("${describe(Blue)}")
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "1\n2\n3\n");
}

/// Actor self in receive blocks is unaffected by method dot-syntax.
/// Spawns an actor with a receive block to prove actor message passing
/// works alongside method dot-syntax infrastructure.
#[test]
fn e2e_method_dot_syntax_preserves_actor_self() {
    let source = r#"
actor greeter() do
  receive do
    msg -> println("actor ok")
  end
end

fn main() do
  let pid = spawn(greeter)
  send(pid, 1)
  println("main ok")
end
"#;
    let output = compile_and_run(source);
    assert!(output.contains("main ok"));
}

// ── Phase 33: While Loop + Loop Control Flow ─────────────────────────

/// WHILE-01: While loop body executes while condition is true.
/// WHILE-02: Body executes zero times if condition is initially false.
/// WHILE-03: While returns Unit (usable as expression).
#[test]
fn e2e_while_loop() {
    let source = read_fixture("while_loop.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "loop ran\nskipped\ndone\n");
}

/// BRKC-01: Break exits the innermost loop.
/// Verifies code after break in same block is unreachable.
#[test]
fn e2e_break_continue() {
    let source = read_fixture("break_continue.mpl");
    let output = compile_and_run(&source);
    assert_eq!(
        output,
        "before break\nafter loop\niteration\nnested break works\n"
    );
}

/// BRKC-04: break outside any loop produces compile error.
#[test]
fn e2e_break_outside_loop_error() {
    let source = "fn main() do\n  break\nend";
    let error = compile_expect_error(source);
    assert!(
        error.contains("break"),
        "Expected break error, got: {}",
        error
    );
}

/// BRKC-04: continue outside any loop produces compile error.
#[test]
fn e2e_continue_outside_loop_error() {
    let source = "fn main() do\n  continue\nend";
    let error = compile_expect_error(source);
    assert!(
        error.contains("continue"),
        "Expected continue error, got: {}",
        error
    );
}

/// BRKC-05: break inside closure within loop produces compile error.
#[test]
fn e2e_break_in_closure_error() {
    let source = "fn main() do\n  while true do\n    let f = fn -> break end\n  end\nend";
    let error = compile_expect_error(source);
    assert!(
        error.contains("break"),
        "Expected break error, got: {}",
        error
    );
}

/// BRKC-05: continue inside closure within loop produces compile error.
#[test]
fn e2e_continue_in_closure_error() {
    let source = "fn main() do\n  while true do\n    let f = fn -> continue end\n  end\nend";
    let error = compile_expect_error(source);
    assert!(
        error.contains("continue"),
        "Expected continue error, got: {}",
        error
    );
}

// ── Phase 34: For-In over Range ─────────────────────────────────────

/// FORIN-02: Basic range iteration prints 0..5 then 10..13.
/// FORIN-08: Loop variable scoped to body (reuse i).
#[test]
fn e2e_for_in_range_basic() {
    let source = read_fixture("for_in_range.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "0\n1\n2\n3\n4\n---\n10\n11\n12\ndone\n");
}

/// Empty range (5..5) produces zero iterations.
#[test]
fn e2e_for_in_range_empty() {
    let source = r#"
fn main() do
  for i in 5..5 do
    println("${i}")
  end
  println("empty")
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "empty\n");
}

/// Reverse range (10..0) produces zero iterations (SLT fails immediately).
#[test]
fn e2e_for_in_range_reverse() {
    let source = r#"
fn main() do
  for i in 10..0 do
    println("${i}")
  end
  println("reverse")
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "reverse\n");
}

/// Break inside for-in exits the loop early.
#[test]
fn e2e_for_in_range_break() {
    let source = r#"
fn main() do
  for i in 0..100 do
    if i == 3 do
      break
    end
    println("${i}")
  end
  println("after")
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "0\n1\n2\nafter\n");
}

/// Continue inside for-in skips to next iteration via latch.
#[test]
fn e2e_for_in_range_continue() {
    let source = r#"
fn main() do
  for i in 0..6 do
    if i == 2 do
      continue
    end
    if i == 4 do
      continue
    end
    println("${i}")
  end
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "0\n1\n3\n5\n");
}

// ── For-in over collections (Phase 35 Plan 02) ────────────────────────

/// For-in over List: comprehension, continue, break.
#[test]
fn e2e_for_in_list() {
    let source = read_fixture("for_in_list.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "2\n4\n6\n---\n10\n20\n40\n50\n---\n2\ndone\n");
}

/// For-in over Map: {k, v} destructuring collects values into a list.
#[test]
fn e2e_for_in_map() {
    let source = read_fixture("for_in_map.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "3\ndone\n");
}

/// For-in over Set: element iteration collects into a list.
#[test]
fn e2e_for_in_set() {
    let source = read_fixture("for_in_set.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "3\ndone\n");
}

/// For-in range comprehension: collecting body results into a list.
#[test]
fn e2e_for_in_range_comprehension() {
    let source = r#"
fn main() do
  let squares = for i in 0..4 do
    i * i
  end
  for s in squares do
    println("${s}")
  end
  println("done")
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "0\n1\n4\n9\ndone\n");
}

/// A comprehension collects each nested list after evaluating its local bindings.
#[test]
fn e2e_for_in_comprehension_retains_nested_lists() {
    let source = r##"
fn main() do
  let nested = for i in 0..2 do
    let base = i * 10
    for j in [1, 2] do
      base + j
    end
  end
  for row in nested do
    for value in row do
      println("#{value}")
    end
    println("---")
  end
end
"##;
    assert_eq!(compile_and_run(source), "1\n2\n---\n11\n12\n---\n");
}

/// Empty map iteration produces empty list (no error).
#[test]
fn e2e_for_in_map_empty() {
    let source = r#"
fn main() do
  let m = Map.new()
  let result = for {k, v} in m do
    v
  end
  let len = List.length(result)
  println("${len}")
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "0\n");
}

/// Empty set iteration produces empty list (no error).
#[test]
fn e2e_for_in_set_empty() {
    let source = r#"
fn main() do
  let s = Set.new()
  let result = for x in s do
    x
  end
  let len = List.length(result)
  println("${len}")
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "0\n");
}

// ── Phase 36: For-in with filter (when) clause ────────────────────────

/// FILT-01/FILT-02: Range filter -- even numbers from 0..10.
#[test]
fn e2e_for_in_filter_range() {
    let source = r#"
fn main() do
  let evens = for i in 0..10 when i % 2 == 0 do
    i
  end
  for e in evens do
    println("${e}")
  end
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "0\n2\n4\n6\n8\n");
}

/// FILT-01/FILT-02: List filter -- elements > 2, multiplied by 10.
#[test]
fn e2e_for_in_filter_list() {
    let source = r#"
fn main() do
  let filtered = for x in [1, 2, 3, 4, 5] when x > 2 do
    x * 10
  end
  for f in filtered do
    println("${f}")
  end
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "30\n40\n50\n");
}

/// FILT-01/FILT-02: Map filter with destructuring -- keep entries with value > 10.
#[test]
fn e2e_for_in_filter_map() {
    let source = r#"
fn main() do
  let m = Map.new()
  let m = Map.put(m, 1, 5)
  let m = Map.put(m, 2, 15)
  let m = Map.put(m, 3, 25)
  let keys = for {k, v} in m when v > 10 do
    k
  end
  let klen = List.length(keys)
  println("${klen}")
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "2\n");
}

/// FILT-01/FILT-02: Set filter -- keep elements > 15.
#[test]
fn e2e_for_in_filter_set() {
    let source = r#"
fn main() do
  let s = Set.new()
  let s = Set.add(s, 10)
  let s = Set.add(s, 20)
  let s = Set.add(s, 30)
  let big = for x in s when x > 15 do
    x
  end
  let slen = List.length(big)
  println("${slen}")
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "2\n");
}

/// FILT-01/FILT-02: All-false filter produces empty list.
#[test]
fn e2e_for_in_filter_empty_result() {
    let source = r#"
fn main() do
  let empty = for x in [1, 2, 3] when x > 100 do
    x
  end
  let elen = List.length(empty)
  println("${elen}")
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "0\n");
}

/// FILT-01/FILT-02: Break inside filtered loop returns partial result.
#[test]
fn e2e_for_in_filter_break() {
    let source = r#"
fn main() do
  let partial = for x in [1, 2, 3, 4, 5] when x % 2 == 1 do
    if x == 3 do
      break
    end
    x
  end
  let plen = List.length(partial)
  println("${plen}")
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "1\n");
}

/// FILT-01/FILT-02: Continue inside filtered loop skips element.
#[test]
fn e2e_for_in_filter_continue() {
    let source = r#"
fn main() do
  let skipped = for x in [1, 2, 3, 4, 5] when x > 1 do
    if x == 3 do
      continue
    end
    x
  end
  for sk in skipped do
    println("${sk}")
  end
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "2\n4\n5\n");
}

/// FILT-01/FILT-02: Full integration fixture covering all filter scenarios.
#[test]
fn e2e_for_in_filter_comprehensive() {
    let source = read_fixture("for_in_filter.mpl");
    let output = compile_and_run(&source);
    assert_eq!(
        output,
        "0\n2\n4\n6\n8\n---\n30\n40\n50\n---\n2\n---\n2\n---\n0\n---\n1\n---\n2\n4\n5\ndone\n"
    );
}

// ── Phase 38: Multi-File Build Pipeline ───────────────────────────────

/// Phase 38: Multi-file build -- directory with multiple .mpl files discovers,
/// parses all, and produces a working binary from main.mpl entry point.
#[test]
fn e2e_multi_file_basic() {
    let temp_dir = tempfile::tempdir().expect("failed to create temp dir");
    let project_dir = temp_dir.path().join("project");
    std::fs::create_dir_all(&project_dir).expect("failed to create project dir");

    // main.mpl does not import utils, but both files exist
    std::fs::write(
        project_dir.join("main.mpl"),
        "fn main() do\n  println(\"hello multi\")\nend\n",
    )
    .unwrap();
    std::fs::write(project_dir.join("utils.mpl"), "fn helper() do\n  42\nend\n").unwrap();

    let meshc = find_meshc();
    let output = Command::new(&meshc)
        .args(["build", project_dir.to_str().unwrap()])
        .output()
        .expect("failed to invoke meshc");

    assert!(
        output.status.success(),
        "meshc build failed on multi-file project:\nstderr: {}",
        String::from_utf8_lossy(&output.stderr)
    );

    let binary = project_dir.join("project");
    let run_output = Command::new(&binary)
        .output()
        .expect("failed to run binary");
    assert!(run_output.status.success());
    assert_eq!(
        String::from_utf8_lossy(&run_output.stdout).trim(),
        "hello multi"
    );
}

#[cfg(unix)]
#[test]
fn e2e_build_rejects_visible_symlink_module_aliases() {
    use std::os::unix::fs::symlink;

    let temp_dir = tempfile::tempdir().expect("failed to create temp dir");
    let project_dir = temp_dir.path().join("project");
    std::fs::create_dir_all(project_dir.join("tests")).expect("failed to create tests dir");
    std::fs::write(project_dir.join("main.mpl"), "fn main() do\n  0\nend\n").unwrap();
    std::fs::write(
        project_dir.join("tests/support.mpl"),
        "pub fn helper() -> Int do\n  1\nend\n",
    )
    .unwrap();
    symlink(project_dir.join("tests"), project_dir.join("test_alias")).unwrap();

    let output = Command::new(find_meshc())
        .args(["build", project_dir.to_str().unwrap(), "--no-color"])
        .output()
        .expect("failed to invoke meshc");

    assert!(
        !output.status.success(),
        "symlinked source alias was accepted"
    );
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        stderr.contains("symbolic link") && stderr.contains("test_alias"),
        "unexpected diagnostic: {stderr}"
    );
}

/// Phase 38: Parse error in a non-entry module causes the build to fail with diagnostics.
#[test]
fn e2e_multi_file_parse_error_in_non_entry() {
    let temp_dir = tempfile::tempdir().expect("failed to create temp dir");
    let project_dir = temp_dir.path().join("project");
    std::fs::create_dir_all(&project_dir).expect("failed to create project dir");

    std::fs::write(
        project_dir.join("main.mpl"),
        "fn main() do\n  println(\"hello\")\nend\n",
    )
    .unwrap();
    // broken.mpl has a syntax error
    std::fs::write(project_dir.join("broken.mpl"), "fn incomplete(\n").unwrap();

    let meshc = find_meshc();
    let output = Command::new(&meshc)
        .args(["build", project_dir.to_str().unwrap()])
        .output()
        .expect("failed to invoke meshc");

    assert!(
        !output.status.success(),
        "expected build to fail due to parse error in broken.mpl"
    );
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        stderr.contains("[P0001] Error:"),
        "expected parse error diagnostic, got: {}",
        stderr
    );
}

/// Phase 38: Nested directory modules are discovered and do not break the build.
#[test]
fn e2e_multi_file_nested_modules() {
    let temp_dir = tempfile::tempdir().expect("failed to create temp dir");
    let project_dir = temp_dir.path().join("project");
    std::fs::create_dir_all(project_dir.join("math")).expect("failed to create dirs");

    std::fs::write(
        project_dir.join("main.mpl"),
        "fn main() do\n  println(\"nested ok\")\nend\n",
    )
    .unwrap();
    std::fs::write(
        project_dir.join("math/vector.mpl"),
        "fn add(a :: Int, b :: Int) -> Int do\n  a + b\nend\n",
    )
    .unwrap();

    let meshc = find_meshc();
    let output = Command::new(&meshc)
        .args(["build", project_dir.to_str().unwrap()])
        .output()
        .expect("failed to invoke meshc");

    assert!(
        output.status.success(),
        "meshc build failed with nested modules:\nstderr: {}",
        String::from_utf8_lossy(&output.stderr)
    );

    let binary = project_dir.join("project");
    let run_output = Command::new(&binary)
        .output()
        .expect("failed to run binary");
    assert!(run_output.status.success());
    assert_eq!(
        String::from_utf8_lossy(&run_output.stdout).trim(),
        "nested ok"
    );
}

// ── Phase 39: Cross-Module Type Checking ──────────────────────────────

/// Helper: compile a multi-file Mesh project (Vec of (relative_path, source)) and run
/// the resulting binary, returning stdout.
fn compile_multifile_and_run(files: &[(&str, &str)]) -> String {
    let temp_dir = tempfile::tempdir().expect("failed to create temp dir");
    let project_dir = temp_dir.path().join("project");

    for (path, source) in files {
        let full_path = project_dir.join(path);
        if let Some(parent) = full_path.parent() {
            std::fs::create_dir_all(parent).expect("failed to create dirs");
        }
        std::fs::write(&full_path, source).expect("failed to write file");
    }

    let meshc = find_meshc();
    let output = Command::new(&meshc)
        .args(["build", project_dir.to_str().unwrap()])
        .output()
        .expect("failed to invoke meshc");

    assert!(
        output.status.success(),
        "meshc build failed:\nstdout: {}\nstderr: {}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );

    let binary = project_dir.join("project");
    let run_output = Command::new(&binary)
        .output()
        .unwrap_or_else(|e| panic!("failed to run binary at {}: {}", binary.display(), e));

    assert!(
        run_output.status.success(),
        "binary execution failed with exit code {:?}:\nstdout: {}\nstderr: {}",
        run_output.status.code(),
        String::from_utf8_lossy(&run_output.stdout),
        String::from_utf8_lossy(&run_output.stderr)
    );

    String::from_utf8_lossy(&run_output.stdout).to_string()
}

/// Only an actor is spawned, and a module's function is none (a module's
/// actors are its own): the error said "expected `()`, found `Pid<_>`".
#[test]
fn e2e_a_modules_function_is_no_actor_to_spawn() {
    let error = compile_multifile_expect_error(&[
        ("workers.mpl", "pub fn hello() do\n  println(\"hi\")\nend\n"),
        (
            "main.mpl",
            "import Workers\n\nfn main() do\n  spawn(Workers.hello)\nend\n",
        ),
    ]);
    assert!(error.contains("only an actor can be spawned"), "{error}");
}

/// Bytes are equal when they hold the same bytes, alone, in a derived `==`
/// and inside an Option, and inspect as their hex: `==` on two Bytes was
/// "does not implement Eq", and a sum type deriving Eq over a Bytes payload
/// failed to build.
#[test]
fn e2e_bytes_compare_by_content() {
    let output = compile_and_run(
        r##"
type W do
  A(Bytes)
  B
end deriving(Eq, Debug)

fn main() do
  let x = A(Bytes.from_utf8("ab"))
  println("#{x == A(Bytes.from_utf8("ab"))} #{x == A(Bytes.from_utf8("ac"))} #{x == B}")
  println("#{Bytes.from_utf8("q") == Bytes.from_utf8("q")} #{Some(Bytes.from_utf8("a")) == Some(Bytes.from_utf8("b"))}")
  println(inspect(x))
end
"##,
    );
    assert_eq!(output, "true false false\ntrue false\nA(Bytes(6162))\n");
}

/// An interface method declared without a result type returns `()`, and
/// an imported struct is shown by its own module's derived Display.
#[test]
fn e2e_unit_methods_and_imported_displays() {
    let output = compile_multifile_and_run(&[
        (
            "shapes.mpl",
            "pub struct Point do\n  x :: Int\nend deriving(Display)\n",
        ),
        (
            "main.mpl",
            r##"
import Shapes

interface Poke do
  fn poke(self)
end

struct Target do
  n :: Int
end

impl Poke for Target do
  fn poke(self) do
    println("poked #{self.n}")
  end
end

fn main() do
  Target { n: 1 }.poke()
  let p = Shapes.Point { x: 2 }
  println("#{p} #{[p]}")
end
"##,
        ),
    ]);
    assert_eq!(output, "poked 1\nPoint(2) [Point(2)]\n");
}

/// Helper: compile a multi-file Mesh project, expecting build failure.
/// Returns stderr.
fn compile_multifile_expect_error(files: &[(&str, &str)]) -> String {
    let temp_dir = tempfile::tempdir().expect("failed to create temp dir");
    let project_dir = temp_dir.path().join("project");

    for (path, source) in files {
        let full_path = project_dir.join(path);
        if let Some(parent) = full_path.parent() {
            std::fs::create_dir_all(parent).expect("failed to create dirs");
        }
        std::fs::write(&full_path, source).expect("failed to write file");
    }

    let meshc = find_meshc();
    let output = Command::new(&meshc)
        .args(["build", project_dir.to_str().unwrap()])
        .output()
        .expect("failed to invoke meshc");

    assert!(
        !output.status.success(),
        "expected compilation to fail but it succeeded"
    );

    String::from_utf8_lossy(&output.stderr).to_string()
}

/// Phase 39 XMOD-01, IMPORT-01: Qualified function call across modules.
/// import Math brings Math into scope; Math.add(2, 3) calls the function.
#[test]
fn e2e_cross_module_qualified_function_call() {
    let output = compile_multifile_and_run(&[
        (
            "math.mpl",
            r#"
pub fn add(a :: Int, b :: Int) -> Int do
  a + b
end

pub fn mul(a :: Int, b :: Int) -> Int do
  a * b
end
"#,
        ),
        (
            "main.mpl",
            r#"
import Math

fn main() do
  let result = Math.add(2, 3)
  println("${result}")
end
"#,
        ),
    ]);
    assert_eq!(output, "5\n");
}

/// Phase 39 XMOD-02, IMPORT-02: Selective import with unqualified access.
/// from Math import add makes add(10, 20) callable without qualification.
#[test]
fn e2e_cross_module_selective_import() {
    let output = compile_multifile_and_run(&[
        (
            "math.mpl",
            r#"
pub fn add(a :: Int, b :: Int) -> Int do
  a + b
end

pub fn mul(a :: Int, b :: Int) -> Int do
  a * b
end
"#,
        ),
        (
            "main.mpl",
            r#"
from Math import add

fn main() do
  let result = add(10, 20)
  println("${result}")
end
"#,
        ),
    ]);
    assert_eq!(output, "30\n");
}

/// Phase 39 XMOD-03: Cross-module struct construction and field access.
/// Struct defined in one module, function called via qualified access.
#[test]
fn e2e_cross_module_struct() {
    let output = compile_multifile_and_run(&[
        (
            "point.mpl",
            r#"
pub struct Point do
  x :: Int
  y :: Int
end

pub fn origin() -> Point do
  Point { x: 0, y: 0 }
end
"#,
        ),
        (
            "main.mpl",
            r#"
import Point

fn main() do
  let p = Point.origin()
  println("${p.x}")
end
"#,
        ),
    ]);
    assert_eq!(output, "0\n");
}

/// Phase 39 XMOD-04: Cross-module sum type with selective import.
/// Sum type defined in one module, imported and used (variant construction) in another.
#[test]
fn e2e_cross_module_sum_type() {
    let output = compile_multifile_and_run(&[
        (
            "shapes.mpl",
            r#"
pub type Shape do
  Circle(Int)
  Rectangle(Int, Int)
end

pub fn area(s :: Shape) -> Int do
  case s do
    Circle(r) -> r * r
    Rectangle(w, h) -> w * h
  end
end
"#,
        ),
        (
            "main.mpl",
            r#"
from Shapes import Shape, area

fn main() do
  let c = Circle(5)
  let a = area(c)
  println("${a}")
end
"#,
        ),
    ]);
    assert_eq!(output, "25\n");
}

/// Phase 39 IMPORT-06: Import of non-existent module produces error.
#[test]
fn e2e_import_nonexistent_module_error() {
    let error = compile_multifile_expect_error(&[(
        "main.mpl",
        r#"
import NonExistent

fn main() do
  42
end
"#,
    )]);
    assert!(
        error.contains("not found") || error.contains("NonExistent"),
        "Expected error about NonExistent module not found, got: {}",
        error
    );
}

/// Phase 39 IMPORT-07: Import of non-existent name from valid module produces error.
#[test]
fn e2e_import_nonexistent_name_error() {
    let error = compile_multifile_expect_error(&[
        (
            "math.mpl",
            r#"
pub fn add(a :: Int, b :: Int) -> Int do
  a + b
end
"#,
        ),
        (
            "main.mpl",
            r#"
from Math import subtract

fn main() do
  42
end
"#,
        ),
    ]);
    assert!(
        error.contains("subtract") || error.contains("not found") || error.contains("not exported"),
        "Expected error about subtract not found in Math, got: {}",
        error
    );
}

/// Phase 39: Nested module qualified access (Math.Vector -> Vector.dot).
#[test]
fn e2e_nested_module_qualified_access() {
    let output = compile_multifile_and_run(&[
        (
            "math/vector.mpl",
            r#"
pub fn dot(a :: Int, b :: Int) -> Int do
  a * b
end
"#,
        ),
        (
            "main.mpl",
            r#"
import Math.Vector

fn main() do
  let result = Vector.dot(3, 4)
  println("${result}")
end
"#,
        ),
    ]);
    assert_eq!(output, "12\n");
}

/// Phase 39 XMOD-05: Cross-module function that returns a struct, accessed via qualified call.
/// Verifies struct definitions from imported modules work correctly through codegen.
#[test]
fn e2e_cross_module_struct_via_function() {
    let output = compile_multifile_and_run(&[
        (
            "geometry.mpl",
            r#"
pub struct Point do
  x :: Int
  y :: Int
end

pub fn make_point(a :: Int, b :: Int) -> Point do
  Point { x: a, y: b }
end
"#,
        ),
        (
            "main.mpl",
            r#"
import Geometry

fn main() do
  let p = Geometry.make_point(10, 20)
  println("${p.x}")
  println("${p.y}")
end
"#,
        ),
    ]);
    assert_eq!(output, "10\n20\n");
}

/// Phase 39: Multiple imports from different modules in the same file.
#[test]
fn e2e_cross_module_multiple_imports() {
    let output = compile_multifile_and_run(&[
        (
            "math.mpl",
            r#"
pub fn add(a :: Int, b :: Int) -> Int do
  a + b
end
"#,
        ),
        (
            "utils.mpl",
            r#"
pub fn double(x :: Int) -> Int do
  x * 2
end
"#,
        ),
        (
            "main.mpl",
            r#"
from Math import add
from Utils import double

fn main() do
  let result = double(add(3, 4))
  println("${result}")
end
"#,
        ),
    ]);
    assert_eq!(output, "14\n");
}

/// Phase 39: Single-file program still compiles identically (regression check).
#[test]
fn e2e_single_file_regression() {
    let output = compile_and_run(
        r#"
fn double(x :: Int) -> Int do
  x * 2
end

fn main() do
  let result = double(21)
  println("${result}")
end
"#,
    );
    assert_eq!(output, "42\n");
}

// ── Phase 40: Visibility Enforcement ──────────────────────────────────

/// Phase 40 VIS-01: Private function blocked via selective import.
/// A function without `pub` cannot be imported from another module.
#[test]
fn e2e_visibility_private_fn_blocked() {
    let error = compile_multifile_expect_error(&[
        (
            "math.mpl",
            r#"
fn secret(a :: Int) -> Int do
  a + 1
end
"#,
        ),
        (
            "main.mpl",
            r#"
from Math import secret

fn main() do
  println("${secret(5)}")
end
"#,
        ),
    ]);
    assert!(
        error.contains("private") || error.contains("pub"),
        "Expected error about private item or pub suggestion, got: {}",
        error
    );
}

/// Phase 40 VIS-02: Pub function importable via selective import.
/// Adding `pub` to a function makes it accessible from another module.
#[test]
fn e2e_visibility_pub_fn_works() {
    let output = compile_multifile_and_run(&[
        (
            "math.mpl",
            r#"
pub fn add(a :: Int, b :: Int) -> Int do
  a + b
end
"#,
        ),
        (
            "main.mpl",
            r#"
from Math import add

fn main() do
  println("${add(2, 3)}")
end
"#,
        ),
    ]);
    assert_eq!(output, "5\n");
}

/// Phase 40 VIS-01/VIS-03: Private struct blocked via selective import.
/// A struct without `pub` cannot be imported from another module.
#[test]
fn e2e_visibility_private_struct_blocked() {
    let error = compile_multifile_expect_error(&[
        (
            "shapes.mpl",
            r#"
struct Point do
  x :: Int
  y :: Int
end

pub fn dummy() -> Int do
  0
end
"#,
        ),
        (
            "main.mpl",
            r#"
from Shapes import Point

fn main() do
  println("nope")
end
"#,
        ),
    ]);
    assert!(
        error.contains("private") || error.contains("pub"),
        "Expected error about private struct or pub suggestion, got: {}",
        error
    );
}

/// Phase 40 VIS-02/VIS-04: Pub struct fully accessible with all fields.
/// A pub struct's fields are all accessible to importers.
#[test]
fn e2e_visibility_pub_struct_accessible() {
    let output = compile_multifile_and_run(&[
        (
            "geometry.mpl",
            r#"
pub struct Point do
  x :: Int
  y :: Int
end

pub fn make(a :: Int, b :: Int) -> Point do
  Point { x: a, y: b }
end
"#,
        ),
        (
            "main.mpl",
            r#"
from Geometry import Point, make

fn main() do
  let p = make(10, 20)
  println("${p.x},${p.y}")
end
"#,
        ),
    ]);
    assert_eq!(output, "10,20\n");
}

/// Phase 40 VIS-01: Private sum type blocked via selective import.
/// A sum type without `pub` cannot be imported from another module.
#[test]
fn e2e_visibility_private_sum_type_blocked() {
    let error = compile_multifile_expect_error(&[
        (
            "colors.mpl",
            r#"
type Color do
  Red
  Blue
  Green
end

pub fn dummy() -> Int do
  0
end
"#,
        ),
        (
            "main.mpl",
            r#"
from Colors import Color

fn main() do
  println("nope")
end
"#,
        ),
    ]);
    assert!(
        error.contains("private") || error.contains("pub"),
        "Expected error about private sum type or pub suggestion, got: {}",
        error
    );
}

/// Phase 40 VIS-02/VIS-05: Pub sum type with all variants accessible.
/// A pub sum type's variants are accessible for construction and pattern matching.
#[test]
fn e2e_visibility_pub_sum_type_accessible() {
    let output = compile_multifile_and_run(&[
        (
            "colors.mpl",
            r#"
pub type Color do
  Red
  Blue
  Green
end
"#,
        ),
        (
            "main.mpl",
            r#"
from Colors import Color

fn main() do
  let c = Red
  case c do
    Red -> println("red")
    Blue -> println("blue")
    Green -> println("green")
  end
end
"#,
        ),
    ]);
    assert_eq!(output, "red\n");
}

/// Phase 40 VIS-03: Error message suggests adding pub.
/// When importing a private item, the error mentions both "private" and "pub".
#[test]
fn e2e_visibility_error_suggests_pub() {
    let error = compile_multifile_expect_error(&[
        (
            "helpers.mpl",
            r#"
fn internal() -> Int do
  42
end
"#,
        ),
        (
            "main.mpl",
            r#"
from Helpers import internal

fn main() do
  println("nope")
end
"#,
        ),
    ]);
    assert!(!error.is_empty(), "Expected compilation to fail with error");
    assert!(
        error.contains("private"),
        "Expected error to mention 'private', got: {}",
        error
    );
    assert!(
        error.contains("pub"),
        "Expected error to suggest adding 'pub', got: {}",
        error
    );
}

/// Phase 40 VIS-01: Qualified access to private function blocked.
/// `import Module` then `Module.private_fn()` should fail because private
/// functions are not included in qualified module exports.
#[test]
fn e2e_visibility_qualified_private_blocked() {
    let error = compile_multifile_expect_error(&[
        (
            "helpers.mpl",
            r#"
fn secret() -> Int do
  42
end

pub fn public_fn() -> Int do
  1
end
"#,
        ),
        (
            "main.mpl",
            r#"
import Helpers

fn main() do
  let x = Helpers.secret()
  println("${x}")
end
"#,
        ),
    ]);
    assert!(
        !error.is_empty(),
        "Expected compilation to fail when accessing private function via qualified syntax"
    );
}

/// Phase 40: Mixed pub and private in same module.
/// Pub items work while private items in the same module don't leak.
#[test]
fn e2e_visibility_mixed_pub_private() {
    let output = compile_multifile_and_run(&[
        (
            "utils.mpl",
            r#"
pub fn visible(x :: Int) -> Int do
  x * 2
end

fn hidden(x :: Int) -> Int do
  x * 3
end
"#,
        ),
        (
            "main.mpl",
            r#"
from Utils import visible

fn main() do
  println("${visible(5)}")
end
"#,
        ),
    ]);
    assert_eq!(output, "10\n");
}

// ── MIR merge codegen (module-qualified naming) ───────────────────────

/// Two modules each define a private function named `helper`.
/// Without module-qualified naming, both collide in MIR merge and the
/// second is silently dropped, causing incorrect dispatch.
#[test]
fn e2e_cross_module_private_function_name_collision() {
    let output = compile_multifile_and_run(&[
        (
            "utils.mpl",
            r#"
fn helper() -> Int do
  42
end

pub fn get_utils_value() -> Int do
  helper()
end
"#,
        ),
        (
            "math_ops.mpl",
            r#"
fn helper() -> Int do
  99
end

pub fn get_math_value() -> Int do
  helper()
end
"#,
        ),
        (
            "main.mpl",
            r#"
from Utils import get_utils_value
from MathOps import get_math_value

fn main() do
  let a = get_utils_value()
  let b = get_math_value()
  println("${a}")
  println("${b}")
end
"#,
        ),
    ]);
    assert_eq!(output, "42\n99\n");
}

/// A private function is qualified by its module whatever its name. Names
/// that began like the runtime's (`mesh_`) or a trait impl's (`Display__`)
/// kept their bare names: two modules' `mesh_helper`s collided, and the
/// entry module's `mesh_string_length` replaced the one `String.length`
/// calls.
#[test]
fn e2e_cross_module_private_names_like_runtime_names_stay_apart() {
    let output = compile_multifile_and_run(&[
        (
            "utils.mpl",
            r#"
fn mesh_helper() -> Int do
  42
end

pub fn get_utils_value() -> Int do
  mesh_helper()
end
"#,
        ),
        (
            "math_ops.mpl",
            r#"
fn mesh_helper() -> Int do
  99
end

pub fn get_math_value() -> Int do
  mesh_helper()
end
"#,
        ),
        (
            "main.mpl",
            r#"
from Utils import get_utils_value
from MathOps import get_math_value

fn mesh_string_length(n :: Int) -> Int do
  n + 1
end

fn main() do
  println("${get_utils_value()} ${get_math_value()}")
  println("${mesh_string_length(4)} ${String.length("abc")}")
end
"#,
        ),
    ]);
    assert_eq!(output, "42 99\n5 3\n");
}

/// A public function keeps its bare name, which the runtime's functions
/// share: `pub fn mesh_string_length` became the function `String.length`
/// calls, and the program printed garbage. The build now refuses it.
#[test]
fn e2e_public_function_named_like_a_runtime_function_is_refused() {
    let error = compile_multifile_expect_error(&[
        (
            "text.mpl",
            r#"
pub fn mesh_string_length(n :: Int) -> Int do
  n + 1
end
"#,
        ),
        (
            "main.mpl",
            r#"
from Text import mesh_string_length

fn main() do
  println("${mesh_string_length(4)} ${String.length("abc")}")
end
"#,
        ),
    ]);
    assert!(
        error.contains(
            "[E0105] Error: `Text.mesh_string_length` is already the name of a runtime or native function"
        ),
        "{error}"
    );
}

/// Two modules with closures. Without module-prefixed closure names,
/// both modules generate `__closure_1` and collide during MIR merge.
#[test]
fn e2e_cross_module_closure_name_collision() {
    let output = compile_multifile_and_run(&[
        (
            "utils.mpl",
            r#"
pub fn apply_utils(x :: Int) -> Int do
  let f = fn n -> n + 10 end
  f(x)
end
"#,
        ),
        (
            "math.mpl",
            r#"
pub fn apply_math(x :: Int) -> Int do
  let f = fn n -> n * 2 end
  f(x)
end
"#,
        ),
        (
            "main.mpl",
            r#"
import Utils
import Math

fn main() do
  let a = Utils.apply_utils(5)
  let b = Math.apply_math(5)
  println("${a}")
  println("${b}")
end
"#,
        ),
    ]);
    assert_eq!(output, "15\n10\n");
}

/// Cross-module function call with concrete types.
/// A pub function defined in one module is called from another.
#[test]
fn e2e_cross_module_concrete_function() {
    let output = compile_multifile_and_run(&[
        (
            "utils.mpl",
            r#"
pub fn identity(x :: Int) -> Int do
  x
end
"#,
        ),
        (
            "main.mpl",
            r#"
from Utils import identity

fn main() do
  let result = identity(42)
  println("${result}")
end
"#,
        ),
    ]);
    assert_eq!(output, "42\n");
}

/// Cross-module generic function (truly generic with type parameter).
/// Tests that a generic function defined in one module can be called with
/// concrete types from another module.
#[test]
fn e2e_cross_module_generic_identity() {
    let output = compile_multifile_and_run(&[
        (
            "utils.mpl",
            r#"
pub fn identity(x :: Int) -> Int = x
pub fn identity_str(x :: String) -> String = x
"#,
        ),
        (
            "main.mpl",
            r#"
from Utils import identity, identity_str

fn main() do
  let a = identity(42)
  println("${a}")
  println(identity_str("hello"))
end
"#,
        ),
    ]);
    assert_eq!(output, "42\nhello\n");
}

/// An inferred generic function called through its module's name is
/// specialized for each type it is called at, also from generic functions
/// of other modules, and through them; field accesses beside it name no
/// module, or no generic function.
#[test]
fn e2e_cross_module_inferred_generic_called_qualified() {
    let output = compile_multifile_and_run(&[
        (
            "utils.mpl",
            r#"
pub fn pair_up(x) do
  (x, x)
end

pub fn twice(n :: Int) -> Int do
  n * 2
end
"#,
        ),
        (
            "mid.mpl",
            r#"
import Utils

pub fn wrap(x) do
  Utils.pair_up(x)
end
"#,
        ),
        (
            "main.mpl",
            r#"
import Mid
import Utils

struct Box do
  size :: Int
end

fn boxed() -> Box do
  Box { size: 4 }
end

fn both(x) do
  Utils.pair_up(x)
end

fn main() do
  let (n, _) = Utils.pair_up(3)
  let (s, _) = Utils.pair_up("hi")
  let (t, _) = both(true)
  let (f, _) = Mid.wrap(1.5)
  let b = boxed()
  println("${n} ${s} ${t} ${f} ${Utils.twice(b.size)} ${boxed().size}")
end
"#,
        ),
    ]);
    assert_eq!(output, "3 hi true 1.5 8 4\n");
}

/// Comprehensive multi-module binary: structs, imports, pub items, private
/// functions, cross-module function calls, and a 3-module project.
#[test]
fn e2e_xmod_comprehensive_multi_module_binary() {
    let output = compile_multifile_and_run(&[
        (
            "geometry.mpl",
            r#"
pub struct Point do
  x :: Int
  y :: Int
end

pub fn make_point(x :: Int, y :: Int) -> Point do
  Point { x: x, y: y }
end

pub fn point_sum(p :: Point) -> Int do
  p.x + p.y
end
"#,
        ),
        (
            "math.mpl",
            r#"
from Geometry import Point, make_point

fn helper() -> Int do
  0
end

pub fn add_points(a :: Point, b :: Point) -> Point do
  make_point(a.x + b.x, a.y + b.y)
end
"#,
        ),
        (
            "main.mpl",
            r#"
import Geometry
import Math

fn main() do
  let a = Geometry.make_point(1, 2)
  let b = Geometry.make_point(3, 4)
  let c = Math.add_points(a, b)
  let sum = Geometry.point_sum(c)
  println("${sum}")
end
"#,
        ),
    ]);
    assert_eq!(output, "10\n");
}

// ── Phase 42: Diagnostics & Integration ───────────────────────────────

/// Phase 42 DIAG-02, Success Criterion 3: Comprehensive multi-module integration.
/// A realistic project with 3+ modules covering structs, cross-module function calls,
/// nested module paths, and qualified access. Validates the complete module system.
#[test]
fn e2e_comprehensive_multi_module_integration() {
    let output = compile_multifile_and_run(&[
        (
            "geometry.mpl",
            r#"
pub struct Point do
  x :: Int
  y :: Int
end

pub fn make_point(x :: Int, y :: Int) -> Point do
  Point { x: x, y: y }
end

pub fn point_sum(p :: Point) -> Int do
  p.x + p.y
end
"#,
        ),
        (
            "math/vector.mpl",
            r#"
from Geometry import Point, make_point, point_sum

pub fn scaled_sum(p :: Point, factor :: Int) -> Int do
  point_sum(p) * factor
end
"#,
        ),
        (
            "utils.mpl",
            r#"
pub fn double(n :: Int) -> Int do
  n * 2
end
"#,
        ),
        (
            "main.mpl",
            r#"
from Geometry import make_point
from Utils import double
import Math.Vector

fn main() do
  let p = make_point(3, 4)
  let sum = Vector.scaled_sum(p, 2)
  let result = double(sum)
  println("${result}")
end
"#,
        ),
    ]);
    assert_eq!(output, "28\n"); // (3+4)*2 = 14, double(14) = 28
}

/// Phase 42 DIAG-02: Cross-module type error shows module-qualified names.
/// When a type mismatch involves an imported type, the error message should
/// display the module prefix (e.g., "Geometry.Point") instead of bare "Point".
#[test]
fn e2e_module_qualified_type_in_error() {
    let error = compile_multifile_expect_error(&[
        (
            "geometry.mpl",
            r#"
pub struct Point do
  x :: Int
  y :: Int
end
"#,
        ),
        (
            "main.mpl",
            r#"
from Geometry import Point

fn takes_string(s :: String) -> String do
  s
end

fn main() do
  let p = Point { x: 1, y: 2 }
  takes_string(p)
end
"#,
        ),
    ]);
    // The error output should contain module-qualified type name
    assert!(
        error.contains("Geometry.Point"),
        "expected error to contain 'Geometry.Point', got:\n{}",
        error
    );
}

/// Phase 42 DIAG-01: File path appears in error output for multi-module errors.
/// Validates that diagnostics show actual file paths instead of `<unknown>`.
#[test]
fn e2e_file_path_in_multi_module_error() {
    let error = compile_multifile_expect_error(&[
        (
            "geometry.mpl",
            r#"
pub fn bad_fn(x :: Int) -> String do
  x
end
"#,
        ),
        (
            "main.mpl",
            r#"
import Geometry

fn main() do
  Geometry.bad_fn(42)
end
"#,
        ),
    ]);
    // The error output should contain the actual file path, not <unknown>
    assert!(
        error.contains("geometry.mpl"),
        "expected error to contain 'geometry.mpl', got:\n{}",
        error
    );
}

// ── Phase 45: Error Propagation (? operator) ─────────────────────────

/// Phase 45: Result ? operator - Ok path unwraps the value.
/// safe_divide(20, 2)? in a function returning Result<Int, String> unwraps Ok(10).
#[test]
fn e2e_try_result_ok_path() {
    let source = read_fixture("try_result_ok_path.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "20\n");
}

/// Phase 45: Result ? operator - Err path propagates the error.
/// safe_divide(20, 0)? early-returns Err("division by zero").
#[test]
fn e2e_try_result_err_path() {
    let source = read_fixture("try_result_err_path.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "division by zero\n");
}

/// Phase 45: Option ? operator - Some path unwraps the value.
/// find_positive(5, 10)? unwraps Some(5), result is Some(105).
#[test]
fn e2e_try_option_some_path() {
    let source = read_fixture("try_option_some_path.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "105\n");
}

/// Phase 45: Option ? operator - None path propagates None.
/// find_positive(-1, -2)? early-returns None.
#[test]
fn e2e_try_option_none_path() {
    let source = read_fixture("try_option_none_path.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "none\n");
}

/// Phase 45: Chained ? operators in a pipeline.
/// Multiple ? calls in sequence: step1(x)? then step2(a)?.
/// Tests: success path, first-step error, second-step error.
#[test]
fn e2e_try_chained_result() {
    let source = read_fixture("try_chained_result.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "21\nnegative input\ntoo large\n");
}

/// Phase 45: ? in a function that doesn't return Result or Option (E0036).
/// bad_caller returns Int but uses ? -- compiler must reject with E0036.
#[test]
fn e2e_try_incompatible_return_type() {
    let source = read_fixture("try_error_incompatible_return.mpl");
    let error = compile_expect_error(&source);
    assert!(
        error.contains("E0036") || error.contains("requires function to return"),
        "Expected E0036 TryIncompatibleReturn error, got:\n{}",
        error
    );
}

/// Phase 45: ? on a value that is not Result or Option (E0037).
/// Using ? on a plain Int -- compiler must reject with E0037.
#[test]
fn e2e_try_on_non_result_option() {
    let source = read_fixture("try_error_non_result_option.mpl");
    let error = compile_expect_error(&source);
    assert!(
        error.contains("E0037") || error.contains("requires `Result` or `Option`"),
        "Expected E0037 TryOnNonResultOption error, got:\n{}",
        error
    );
}

// TCE tests (Phase 48 Plan 02)

/// Phase 48: Self-recursive countdown from 1,000,000 completes without stack overflow.
/// Proves TCE loop wrapping prevents stack overflow for deep recursion.
#[test]
fn tce_countdown() {
    let source = read_fixture("tce_countdown.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output.trim(), "done");
}

/// Phase 48: Parameter swap correctness with two-phase argument evaluation.
/// After 100,001 swaps (odd count), a=1,b=2 becomes a=2,b=1.
#[test]
fn tce_param_swap() {
    let source = read_fixture("tce_param_swap.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output.trim(), "2\n1");
}

/// Phase 48: Tail calls in case/match arms are correctly eliminated.
/// Chain: process(2,0) -> process(1,20) -> process(0,30) -> prints 30.
#[test]
fn tce_case_arms() {
    let source = read_fixture("tce_case_arms.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output.trim(), "30");
}

/// Phase 48: Tail-recursive function called from actor context.
/// count_loop(0, 1000000) runs 1M iterations inside an actor without stack overflow.
#[test]
fn tce_actor_loop() {
    let source = read_fixture("tce_actor_loop.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output.trim(), "1000000");
}

// ── Phase 74: Associated Types ──────────────────────────────────────────

/// Phase 74: Basic associated type -- different impls resolve Self.Item to
/// different concrete types (Int and String).
#[test]
fn e2e_assoc_type_basic() {
    let source = read_fixture("assoc_type_basic.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "42\nhello\n");
}

/// Phase 74: Multiple associated types in a single interface.
/// Mapper has both Input and Output associated types; impl resolves Output
/// to String and the method returns "mapped".
#[test]
fn e2e_assoc_type_multiple() {
    let source = read_fixture("assoc_type_multiple.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "mapped\n");
}

/// Phase 74: Associated types coexist with deriving(Display).
/// Wrapper derives Display and also implements Container with assoc type.
/// Both dot-syntax method calls work on the same struct.
#[test]
fn e2e_assoc_type_with_deriving() {
    let source = read_fixture("assoc_type_with_deriving.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "Wrapper(1, 2)\n99\n");
}

/// Phase 74: Missing associated type binding produces E0040.
/// Iterator requires `type Item` but the impl omits it.
#[test]
fn e2e_assoc_type_missing_compile_fail() {
    let source = r#"
interface Iterator do
  type Item
  fn next(self) -> Int
end

impl Iterator for Int do
  fn next(self) -> Int do
    42
  end
end

fn main() do
  println("should not compile")
end
"#;
    let error = compile_expect_error(source);
    assert!(
        error.contains("E0040") || error.contains("missing associated type"),
        "Expected E0040 MissingAssocType error, got:\n{}",
        error
    );
}

/// Phase 74: Extra associated type binding produces E0041.
/// Printable has no associated types, but the impl provides `type Output`.
#[test]
fn e2e_assoc_type_extra_compile_fail() {
    let source = r#"
interface Printable do
  fn show(self) -> String
end

impl Printable for Int do
  type Output = String
  fn show(self) -> String do
    "int"
  end
end

fn main() do
  println("should not compile")
end
"#;
    let error = compile_expect_error(source);
    assert!(
        error.contains("E0041") || error.contains("not declared by the trait"),
        "Expected E0041 ExtraAssocType error, got:\n{}",
        error
    );
}

// ── Phase 75: Numeric Traits ─────────────────────────────────────────

/// Phase 75: User-defined arithmetic operators with Output associated type.
/// Vec2 struct implements Add, Sub, Mul with Output = Vec2; operators produce
/// correct Vec2 results (not Bool). Also tests primitive backward compat and
/// operator chaining.
#[test]
fn e2e_numeric_traits() {
    let source = read_fixture("numeric_traits.mpl");
    let output = compile_and_run(&source);
    assert_eq!(
        output,
        "4.0\n6.0\n-2.0\n-2.0\n3.0\n8.0\n3\n12.0\n14.0\n26.0\n"
    );
}

/// Phase 75: User-defined Neg trait for unary minus.
/// Point struct implements Neg with Output = Point; unary minus produces
/// correct Point result. Also tests primitive neg backward compat.
#[test]
fn e2e_numeric_neg() {
    let source = read_fixture("numeric_neg.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "-3.0\n-7.0\n-42\n-3.5\n");
}

#[test]
fn e2e_numeric_literal_separators_and_radices() {
    let output = compile_and_run(
        r##"
fn main() do
  println("#{1_000_000}")
  println("#{0xff_ff}")
  println("#{0b1111_0000}")
  println("#{0o777}")
  println("#{100_000.50}")
end
"##,
    );
    assert_eq!(output, "1000000\n65535\n240\n511\n100000.5\n");
}

/// Phase 76: User-defined Iterable with built-in runtime iterator.
/// EvenNumbers struct implements Iterable with ListIterator backing.
/// for-in over user-defined Iterable desugars through ForInIterator codegen.
#[test]
fn e2e_iterator_iterable() {
    let source = read_fixture("iterator_iterable.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "[4, 8, 12, 16, 20]\n2\n4\n6\n8\n10\n");
}

/// A `for` over an iterator does not know how many results it will collect.
/// Its builder started with no capacity and never grew, so every element was
/// written past its end, over the strings the loop body had just allocated.
#[test]
fn e2e_for_in_iterator_builds_result() {
    let source = read_fixture("for_in_iterator_builds_result.mpl");
    let output = compile_and_run(&source);
    assert_eq!(
        output,
        "200 v-10 v-20 v-2000\n4 even-50,even-100,even-150,even-200\n"
    );
}

/// The other half of the same fault: `List.concat` and string interpolation
/// size their result from their inputs' length fields and then copy into it,
/// so one allocated too small writes over its neighbour on the heap rather
/// than over itself. Reads back both ends of each concat, and a list
/// allocated after one.
#[test]
fn e2e_concat_large_list_and_string() {
    let source = read_fixture("concat_large_list_and_string.mpl");
    let output = compile_and_run(&source);
    assert_eq!(
        output,
        "2000 l-0 l-999 r-0 r-999\n1000 a-0 a-999\n400 true true\n"
    );
}

// ── Phase 77: From/Into Conversion E2E Tests ────────────────────────────

/// Phase 77 CONV-01: User-defined impl From<Int> for Wrapper compiles
/// and Wrapper.from(21) calls the user-provided conversion at runtime.
#[test]
fn e2e_from_user_defined() {
    let source = read_fixture("from_user_defined.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "42\n");
}

/// Phase 77 CONV-03: Built-in Float.from(42) produces a float value, and a
/// whole-number float still prints as one (`42.0`).
#[test]
fn e2e_from_float_from_int() {
    let source = read_fixture("from_float_from_int.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output.trim(), "42.0");
}

/// Phase 77 CONV-03: Built-in String.from(42) produces "42".
#[test]
fn e2e_from_string_from_int() {
    let source = read_fixture("from_string_from_int.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "42\n");
}

/// Phase 77 CONV-03: Built-in String.from(3.14) produces "3.14".
#[test]
fn e2e_from_string_from_float() {
    let source = read_fixture("from_string_from_float.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output.trim(), "3.14");
}

/// Phase 77 CONV-03: Built-in String.from(true) produces "true".
#[test]
fn e2e_from_string_from_bool() {
    let source = read_fixture("from_string_from_bool.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "true\n");
}

/// Phase 77 CONV-04: ? operator correctly propagates errors through
/// multiple function call levels with chained ? desugaring.
/// NOTE: This tests chained ? with the SAME error type (String), not From conversion.
/// For From-based error type conversion, see e2e_from_try_struct_error.
#[test]
fn e2e_from_try_error_conversion() {
    let source = read_fixture("from_try_error_conversion.mpl");
    let output = compile_and_run(&source);
    // compute(60): 60/2=30, 30/3=10, 10+100=110
    assert_eq!(output, "110\n");
}

/// Phase 77 CONV-04: ? operator backward compat -- same error types
/// work without any From conversion (regression test).
#[test]
fn e2e_from_try_same_error() {
    let source = read_fixture("from_try_same_error.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "err: fail\n");
}

#[test]
fn e2e_from_try_nested_success_same_error() {
    let source = read_fixture("from_try_nested_success_same_error.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "ok\n");
}

/// Phase 77 CONV-04 gap closure: ? operator auto-converts String error to
/// AppError struct via From<String> for AppError. This is the exact success
/// criterion #4 test case -- struct error types in Result Err variants.
#[test]
fn e2e_from_try_struct_error() {
    let source = read_fixture("from_try_struct_error.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "something failed\n");
}

// ── Phase 128: TryFrom/TryInto E2E Tests ─────────────────────────────

/// Phase 128 TRYFROM-01: impl TryFrom<Int> for PositiveInt compiles and
/// PositiveInt.try_from(42) returns Ok(PositiveInt { value: 42 }).
#[test]
fn e2e_tryfrom_user_defined() {
    let source = read_fixture("tryfrom_user_defined.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "42\n");
}

/// Phase 128 TRYFROM-01: try_from on failing validation returns Err with
/// the error message from the impl body.
#[test]
fn e2e_tryfrom_err_path() {
    let source = read_fixture("tryfrom_err_path.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "must be positive\n");
}

/// Phase 128 TRYFROM-03: ? operator on try_from result desugars correctly
/// inside a Result-returning function, propagating Err on failure.
#[test]
fn e2e_tryfrom_try_operator() {
    let source = read_fixture("tryfrom_try_operator.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "42\nmust be positive\n");
}

/// Phase 128 TRYFROM-02: 42.try_into() in a Result<PositiveInt, String> context
/// exercises the synthetic TryInto dispatch wired in lower.rs. No explicit
/// TryInto impl is written by the user -- only TryFrom<Int> for PositiveInt.
#[test]
fn e2e_tryinto_dispatch() {
    let source = read_fixture("tryinto_dispatch.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "42\nmust be positive\n");
}

// ── Phase 78: Lazy Combinators & Terminals E2E Tests ─────────────────

/// Phase 78 COMB-01/02/06: Iter.map and Iter.filter combinators with pipe chain.
/// Verifies map doubles elements, filter keeps evens, map+filter chain, map+sum.
#[test]
fn e2e_iter_map_filter() {
    let source = read_fixture("iter_map_filter.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "10\n5\n5\n165\n");
}

/// Phase 78 COMB-03: Iter.take and Iter.skip combinators.
/// Verifies take limits, skip offsets, take(0) and skip(all) edge cases.
#[test]
fn e2e_iter_take_skip() {
    let source = read_fixture("iter_take_skip.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "6\n27\n0\n0\n");
}

/// Phase 78 COMB-04/05: Iter.enumerate and Iter.zip combinators.
/// Verifies enumerate produces countable tuples, zip combines iterators,
/// zip with unequal lengths stops at shorter.
#[test]
fn e2e_iter_enumerate_zip() {
    let source = read_fixture("iter_enumerate_zip.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "3\n3\n2\n");
}

/// Phase 78 TERM-01 through TERM-05: All terminal operations.
/// count, sum, any (true/false), all (true/false), reduce (product/sum).
#[test]
fn e2e_iter_terminals() {
    let source = read_fixture("iter_terminals.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "5\n15\ntrue\nfalse\ntrue\nfalse\n120\n15\n");
}

/// Phase 78 COMB-06 + SC4: Multi-combinator pipeline with short-circuit.
/// map->filter->take->count, filter->map->sum, skip->take->count (windowing),
/// closure capturing local variable in pipeline.
#[test]
fn e2e_iter_pipeline() {
    let source = read_fixture("iter_pipeline.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "3\n400\n5\n7\n");
}

// ── Phase 79: Collect E2E Tests ─────────────────────────────────────────

/// Phase 79 COLL-01: List.collect with map, filter, take pipelines and direct call syntax.
/// Pipe syntax (iter |> List.collect()) and direct call (List.collect(iter)) both work.
/// Empty iterator via take(0) produces empty list.
#[test]
fn e2e_collect_list() {
    let source = read_fixture("collect_list.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "3\n[2, 4, 6]\n[4, 5]\n[10, 20, 30]\n0\n");
}

/// Phase 79 COLL-02: Map.collect from enumerate (index->value) and zip (key->value) tuple iterators.
#[test]
fn e2e_collect_map() {
    let source = read_fixture("collect_map.mpl");
    let output = compile_and_run(&source);
    assert_eq!(
        output,
        "%{0 => 100, 1 => 200, 2 => 300}\n%{10 => 1, 20 => 2, 30 => 3}\n3\n"
    );
}

/// Phase 79 COLL-03 + COLL-04: Set.collect deduplication and String.collect concatenation.
/// Set.collect deduplicates elements, String.collect joins string elements.
#[test]
fn e2e_collect_set_string() {
    let source = read_fixture("collect_set_string.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "3\n3\ntrue\nhello world\nabc\n");
}

/// Phase 96 COMP-07: Map.collect with string keys roundtrip.
/// Collect string-keyed tuple iterator back into a Map with correct key_type.
/// Map.get on collected map uses string comparison, not integer comparison.
#[test]
fn e2e_collect_map_string_keys() {
    let source = read_fixture("collect_map_string_keys.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "1\n2\n3\n");
}

/// Phase 129 MAPCOL-01: Map.collect with string keys via Iter.zip pattern.
/// Zipping string key list with int value list and collecting should produce a
/// Map<String, Int> where Map.get with a string key returns the correct value.
#[test]
fn e2e_collect_map_string_keys_zip() {
    let source = read_fixture("collect_map_string_keys_zip.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "1\n2\n3\n");
}

// ── Phase 87.1: Codegen Bug Fixes ──────────────────────────────────────

/// Phase 87.1: Err(e) variable binding in pattern matching compiles and runs.
/// Multiple case expressions in the same function reuse variable names correctly.
#[test]
fn e2e_err_binding_pattern() {
    let source = read_fixture("err_binding_pattern.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "ok: 10\nnegative: -3\n");
}

/// Phase 87.1: ? operator with chained calls and different Result types.
/// Multiple ? calls in one function, with Ok/Err pattern matching on results.
#[test]
fn e2e_try_operator_result() {
    let source = read_fixture("try_operator_result.mpl");
    let output = compile_and_run(&source);
    assert_eq!(
        output,
        "valid: 42\nerror: must be positive\nerror: too large\n"
    );
}

// ── Phase 87.1-02: Module System Fixes ────────────────────────────────

/// Phase 87.1-02: Cross-module polymorphic function import.
/// Functions with inferred types (using Scheme normalization) can be imported
/// cross-module without TyVar index-out-of-bounds panics.
/// Tests that type variable normalization in export makes schemes self-contained.
#[test]
fn e2e_cross_module_polymorphic() {
    let output = compile_multifile_and_run(&[
        (
            "utils.mpl",
            r#"
pub fn double(x) do
  x * 2
end

pub fn add_one(x) do
  x + 1
end

pub fn make_greeting(name :: String) -> String do
  "hello " <> name
end
"#,
        ),
        (
            "main.mpl",
            r#"
from Utils import double, add_one, make_greeting

fn main() do
  let a = double(21)
  let b = add_one(41)
  let c = make_greeting("world")
  println("${a}")
  println("${b}")
  println(c)
end
"#,
        ),
    ]);
    assert_eq!(output, "42\n42\nhello world\n");
}

/// Phase 87.1-02: Cross-module service import.
/// A service defined in one module can be imported and used from another module.
/// Tests the full service export/import pipeline: type checking, MIR lowering,
/// and cross-module symbol resolution.
#[test]
fn e2e_cross_module_service() {
    let output = compile_multifile_and_run(&[
        (
            "services.mpl",
            r#"
service Store do
  fn init(start_val :: Int) -> Int do
    start_val
  end

  call Get() :: Int do |state|
    (state, state)
  end

  call Set(value :: Int) :: Int do |_state|
    (value, value)
  end

  cast Clear() do |_state|
    0
  end
end
"#,
        ),
        (
            "main.mpl",
            r#"
from Services import Store

fn main() do
  let pid = Store.start(100)
  let v1 = Store.get(pid)
  println("${v1}")
  let v2 = Store.set(pid, 200)
  println("${v2}")
  Store.clear(pid)
  let v3 = Store.get(pid)
  println("${v3}")
end
"#,
        ),
    ]);
    assert_eq!(output, "100\n200\n0\n");
}

/// Phase 87.1-02: Cross-module ? operator with Result types.
/// A validation function in one module returns Result, and another module
/// calls it with the ? operator inside a function that also returns Result.
/// Tests that Result types and ? operator work correctly across module boundaries.
#[test]
fn e2e_cross_module_try_operator() {
    let output = compile_multifile_and_run(&[
        (
            "validation.mpl",
            r#"
pub fn validate_positive(n :: Int) -> Int!String do
  if n > 0 do
    Ok(n)
  else
    Err("must be positive")
  end
end

pub fn validate_small(n :: Int) -> Int!String do
  if n < 100 do
    Ok(n)
  else
    Err("too large")
  end
end
"#,
        ),
        (
            "main.mpl",
            r#"
from Validation import validate_positive, validate_small

fn process(n :: Int) -> Int!String do
  let a = validate_positive(n)?
  let b = validate_small(a)?
  Ok(b * 2)
end

fn main() do
  let r1 = process(10)
  case r1 do
    Ok(v) -> println("ok: ${v}")
    Err(e) -> println("err: ${e}")
  end
  let r2 = process(-5)
  case r2 do
    Ok(v) -> println("ok: ${v}")
    Err(e) -> println("err: ${e}")
  end
  let r3 = process(200)
  case r3 do
    Ok(v) -> println("ok: ${v}")
    Err(e) -> println("err: ${e}")
  end
end
"#,
        ),
    ]);
    assert_eq!(output, "ok: 20\nerr: must be positive\nerr: too large\n");
}

/// Phase 96 COMP-08: Cross-module from_json resolution.
/// Struct with deriving(Json) defined in one module, from_json called from another.
/// Verifies that FromJson__/ToJson__ prefixes skip module qualification and that
/// deriving-generated trait impls are exported across module boundaries.
#[test]
fn e2e_cross_module_from_json_with_imported_model() {
    let output = compile_multifile_and_run(&[
        (
            "models.mpl",
            r#"
pub struct User do
  name :: String
  age :: Int
end deriving(Json)

pub fn make_user(name :: String, age :: Int) -> User do
  User { name: name, age: age }
end
"#,
        ),
        (
            "main.mpl",
            r#"
import Models

fn main() do
  let u = Models.make_user("Alice", 30)
  let json_str = Json.encode(u)
  println(json_str)
  let result = User.from_json(json_str)
  case result do
    Ok(u2) -> println("${u2.name} ${u2.age}")
    Err(e) -> println("Error: ${e}")
  end
end
"#,
        ),
    ]);
    let lines: Vec<&str> = output.trim().lines().collect();
    assert_eq!(lines.len(), 2, "expected 2 lines, got: {:?}", lines);
    // JSON key order is non-deterministic; check both possible orderings
    assert!(
        lines[0] == "{\"name\":\"Alice\",\"age\":30}"
            || lines[0] == "{\"age\":30,\"name\":\"Alice\"}",
        "unexpected JSON: {}",
        lines[0]
    );
    assert_eq!(lines[1], "Alice 30");
}

/// Cross-module from_json works with selective import (`from Module import Name`).
#[test]
fn e2e_cross_module_from_json_selective_import() {
    let output = compile_multifile_and_run(&[
        (
            "models.mpl",
            r#"
pub struct User do
  name :: String
  age :: Int
end deriving(Json)
"#,
        ),
        (
            "main.mpl",
            r#"
from Models import User

fn main() do
  let u = User { name: "Bob", age: 25 }
  let json_str = Json.encode(u)
  let result = User.from_json(json_str)
  case result do
    Ok(u2) -> println("${u2.name} ${u2.age}")
    Err(e) -> println("Error: ${e}")
  end
end
"#,
        ),
    ]);
    assert_eq!(output.trim(), "Bob 25");
}

/// Atom literals compile and execute, printing their string representation.
#[test]
fn e2e_atom_literals() {
    let output = compile_and_run(
        r#"
fn main() do
  let name = :name
  let email = :email
  let asc = :asc
  println("name atom works")
  println("email atom works")
  println("asc atom works")
end
"#,
    );
    assert_eq!(
        output,
        "name atom works\nemail atom works\nasc atom works\n"
    );
}

/// Atom type is distinct from String -- assigning an atom to a String-annotated
/// variable produces a type error.
#[test]
fn e2e_atom_type_distinct() {
    let error = compile_expect_error(
        r#"
fn main() do
  let x :: String = :name
  println(x)
end
"#,
    );
    assert!(
        error.contains("Atom") && error.contains("String"),
        "Expected type error mentioning Atom and String, got: {}",
        error
    );
}

// ── Phase 96 Plan 02: Keyword Arguments ─────────────────────────────

/// Keyword arguments desugar to a Map parameter: `greet(name: "Alice")` becomes
/// `greet(%{"name" => "Alice"})`.
#[test]
fn e2e_keyword_arguments() {
    let output = compile_and_run(
        r#"
fn greet(opts :: Map<String, String>) -> String do
  Map.get(opts, "name")
end

fn main() do
  let result = greet(name: "Alice")
  println(result)
end
"#,
    );
    assert_eq!(output, "Alice\n");
}

/// Mixed positional and keyword arguments: `query("users", name: "Alice")` desugars
/// to `query("users", %{"name" => "Alice"})`.
#[test]
fn e2e_keyword_args_mixed() {
    let output = compile_and_run(
        r#"
fn query(table :: String, opts :: Map<String, String>) -> String do
  let name = Map.get(opts, "name")
  "${table}:${name}"
end

fn main() do
  let result = query("users", name: "Alice")
  println(result)
end
"#,
    );
    assert_eq!(output, "users:Alice\n");
}

// ── Phase 96 Plan 02: Multi-line Pipe Chains ────────────────────────

/// Multi-line pipe chains where |> at line start continues the previous expression.
#[test]
fn e2e_multiline_pipe() {
    let output = compile_and_run(
        r#"
fn double(x :: Int) -> Int do
  x * 2
end

fn add_one(x :: Int) -> Int do
  x + 1
end

fn main() do
  let result = 5
    |> double
    |> add_one
  println("${result}")
end
"#,
    );
    assert_eq!(output, "11\n");
}

/// Multi-line pipe chain with more than 2 stages and function calls with arguments.
#[test]
fn e2e_multiline_pipe_complex() {
    let output = compile_and_run(
        r#"
fn add(x :: Int, y :: Int) -> Int do
  x + y
end

fn mul(x :: Int, y :: Int) -> Int do
  x * y
end

fn negate(x :: Int) -> Int do
  0 - x
end

fn main() do
  let result = 10
    |> add(5)
    |> mul(3)
    |> negate
  println("${result}")
end
"#,
    );
    assert_eq!(output, "-45\n");
}

/// Multi-line pipes work together with keyword arguments.
#[test]
fn e2e_multiline_pipe_with_keyword_args() {
    let output = compile_and_run(
        r#"
fn double(x :: Int) -> Int do
  x * 2
end

fn add_one(x :: Int) -> Int do
  x + 1
end

fn describe(opts :: Map<String, String>) -> String do
  Map.get(opts, "result")
end

fn main() do
  let num = 5
    |> double
    |> add_one
  let msg = describe(result: "${num}")
  println(msg)
end
"#,
    );
    assert_eq!(output, "11\n");
}

// ── Phase 126: Multi-line Pipe Continuation (PIPE-01, PIPE-02) ──────────

/// PIPE-01: Trailing-pipe form — |> at end of line continues on next line.
/// PIPE-02: Output matches single-line equivalent (same computation = same result).
#[test]
fn e2e_pipe_multiline_trailing() {
    let source = read_fixture("pipe_multiline_trailing.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "11\n30\n");
}

/// PIPE-01/02: Multi-line slot pipe — |N> at start and end of line.
/// Both leading and trailing slot pipe forms must produce identical results.
#[test]
fn e2e_pipe_multiline_slot() {
    let source = read_fixture("pipe_multiline_slot.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "15\n15\n20\n");
}

/// PIPE-02: Explicit equivalence — multi-line chain output == single-line output.
/// Both expressions compute 5 |> double |> add_one = 11.
#[test]
fn e2e_pipe_multiline_equivalence() {
    let single_line = compile_and_run(
        r#"
fn double(x :: Int) -> Int do x * 2 end
fn add_one(x :: Int) -> Int do x + 1 end
fn main() do
  let result = 5 |> double |> add_one
  println("${result}")
end
"#,
    );
    let multi_line = compile_and_run(
        r#"
fn double(x :: Int) -> Int do x * 2 end
fn add_one(x :: Int) -> Int do x + 1 end
fn main() do
  let result = 5 |>
    double |>
    add_one
  println("${result}")
end
"#,
    );
    assert_eq!(
        single_line, multi_line,
        "multi-line pipe must produce same output as single-line"
    );
}

/// PIPE-02: Slot pipe equivalence — multi-line |N> == single-line |N>.
#[test]
fn e2e_pipe_slot_multiline_equivalence() {
    let single_line = compile_and_run(
        r#"
fn add(a :: Int, b :: Int) -> Int do a + b end
fn main() do
  let result = 5 |2> add(10)
  println("${result}")
end
"#,
    );
    let multi_line = compile_and_run(
        r#"
fn add(a :: Int, b :: Int) -> Int do a + b end
fn main() do
  let result = 5 |2>
    add(10)
  println("${result}")
end
"#,
    );
    assert_eq!(
        single_line, multi_line,
        "multi-line slot pipe must produce same output as single-line"
    );
}

/// Regression: existing single-line pipes unchanged by Phase 126 changes.
#[test]
fn e2e_pipe_126_regression() {
    let source = read_fixture("pipe.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "11\n");
}

// ── Phase 96 Plan 03: Struct Update Expression ──────────────────────

/// Basic struct update: create new struct with specific fields changed.
#[test]
fn e2e_struct_update_basic() {
    let output = compile_and_run(
        r#"
struct User do
  name :: String
  email :: String
  age :: Int
end

fn main() do
  let user = User { name: "Alice", email: "alice@example.com", age: 30 }
  let updated = %{user | name: "Bob", age: 25}
  println(updated.name)
  println(updated.email)
  println("${updated.age}")
end
"#,
    );
    assert_eq!(output, "Bob\nalice@example.com\n25\n");
}

/// Struct update with a single field override.
#[test]
fn e2e_struct_update_single_field() {
    let output = compile_and_run(
        r#"
struct Point do
  x :: Int
  y :: Int
end

fn main() do
  let p = Point { x: 1, y: 2 }
  let p2 = %{p | x: 10}
  println("${p2.x}")
  println("${p2.y}")
end
"#,
    );
    assert_eq!(output, "10\n2\n");
}

/// Struct update preserves original (immutability).
#[test]
fn e2e_struct_update_original_unchanged() {
    let output = compile_and_run(
        r#"
struct Config do
  host :: String
  port :: Int
end

fn main() do
  let c1 = Config { host: "localhost", port: 8080 }
  let c2 = %{c1 | port: 9090}
  println(c1.host)
  println("${c1.port}")
  println(c2.host)
  println("${c2.port}")
end
"#,
    );
    assert_eq!(output, "localhost\n8080\nlocalhost\n9090\n");
}

// ── Phase 96-04: deriving(Schema) ──────────────────────────────────────────

/// deriving(Schema) __table__() returns lowercased, pluralized struct name.
#[test]
fn e2e_deriving_schema_table() {
    let output = compile_and_run(
        r#"
struct User do
  id :: String
  name :: String
  email :: String
end deriving(Schema)

fn main() do
  println(User.__table__())
end
"#,
    );
    assert_eq!(output, "users\n");
}

/// deriving(Schema) __primary_key__() returns "id" by default.
#[test]
fn e2e_deriving_schema_primary_key() {
    let output = compile_and_run(
        r#"
struct Comment do
  id :: String
  text :: String
end deriving(Schema)

fn main() do
  println(Comment.__primary_key__())
end
"#,
    );
    assert_eq!(output, "id\n");
}

/// deriving(Schema) __fields__() returns list of field name strings.
#[test]
fn e2e_deriving_schema_fields() {
    let output = compile_and_run(
        r#"
struct Post do
  id :: String
  title :: String
  body :: String
end deriving(Schema)

fn main() do
  let fields = Post.__fields__()
  let len = List.length(fields)
  println("${len}")
  let f0 = List.get(fields, 0)
  println(f0)
  let f1 = List.get(fields, 1)
  println(f1)
  let f2 = List.get(fields, 2)
  println(f2)
end
"#,
    );
    assert_eq!(output, "3\nid\ntitle\nbody\n");
}

/// deriving(Schema) __relationships__() returns list of relationship metadata strings.
#[test]
fn e2e_deriving_schema_relationships() {
    let output = compile_and_run(
        r#"
struct Post do
  id :: String
  title :: String
  user_id :: String
  belongs_to :user, User
end deriving(Schema)

struct User do
  id :: String
  name :: String
  has_many :posts, Post
end deriving(Schema)

fn main() do
  let post_rels = Post.__relationships__()
  let user_rels = User.__relationships__()
  let pr0 = List.get(post_rels, 0)
  println(pr0)
  let ur0 = List.get(user_rels, 0)
  println(ur0)
end
"#,
    );
    assert_eq!(output, "belongs_to:user:User\nhas_many:posts:Post\n");
}

/// __relationship_meta__() returns 5-field encoded strings with FK and target table.
#[test]
fn e2e_relationship_meta_has_many() {
    let output = compile_and_run(
        r#"
struct User do
  id :: String
  name :: String
  has_many :posts, Post
end deriving(Schema)

struct Post do
  id :: String
  title :: String
  user_id :: String
  belongs_to :user, User
end deriving(Schema)

fn main() do
  let meta = User.__relationship_meta__()
  let m0 = List.get(meta, 0)
  println(m0)
  let post_meta = Post.__relationship_meta__()
  let pm0 = List.get(post_meta, 0)
  println(pm0)
end
"#,
    );
    assert_eq!(
        output,
        "has_many:posts:Post:user_id:posts:id:User\nbelongs_to:user:User:user_id:users:id:Post\n"
    );
}

/// __relationship_meta__() names the target's table and the key the foreign
/// key refers to as the structs' own deriving(Schema) configures them, also
/// for a target another module declares.
#[test]
fn e2e_relationship_meta_reads_configured_tables_and_keys() {
    let output = compile_multifile_and_run(&[
        (
            "models.mpl",
            r#"
pub struct Account do
  table "accounts_v2"
  primary_key :uuid
  uuid :: String
end deriving(Schema)
"#,
        ),
        (
            "main.mpl",
            r#"
from Models import Account

struct Author do
  table "writers"
  primary_key :handle
  handle :: String
  account_id :: String
  has_many :posts, Post
  belongs_to :account, Account
end deriving(Schema)

struct Post do
  table "articles"
  id :: String
  author_id :: String
  belongs_to :author, Author
end deriving(Schema)

fn main() do
  List.map(Author.__relationship_meta__(), fn(m) do println(m) end)
  List.map(Post.__relationship_meta__(), fn(m) do println(m) end)
end
"#,
        ),
    ]);
    assert_eq!(
        output,
        "has_many:posts:Post:author_id:articles:handle:Author\n\
         belongs_to:account:Account:account_id:accounts_v2:uuid:Author\n\
         belongs_to:author:Author:author_id:writers:handle:Post\n"
    );
}

/// __relationship_meta__() for has_one relationships.
#[test]
fn e2e_relationship_meta_has_one() {
    let output = compile_and_run(
        r#"
struct User do
  id :: String
  name :: String
  has_one :profile, Profile
end deriving(Schema)

struct Profile do
  id :: String
  bio :: String
  user_id :: String
  belongs_to :user, User
end deriving(Schema)

fn main() do
  let meta = User.__relationship_meta__()
  let m0 = List.get(meta, 0)
  println(m0)
end
"#,
    );
    assert_eq!(output, "has_one:profile:Profile:user_id:profiles:id:User\n");
}

/// __relationship_meta__() with multiple relationships on one struct.
#[test]
fn e2e_relationship_meta_multiple() {
    let output = compile_and_run(
        r#"
struct User do
  id :: String
  name :: String
  has_many :posts, Post
  has_one :profile, Profile
end deriving(Schema)

struct Post do
  id :: String
  title :: String
end deriving(Schema)

struct Profile do
  id :: String
  bio :: String
end deriving(Schema)

fn main() do
  let meta = User.__relationship_meta__()
  let m0 = List.get(meta, 0)
  let m1 = List.get(meta, 1)
  println(m0)
  println(m1)
end
"#,
    );
    assert_eq!(
        output,
        "has_many:posts:Post:user_id:posts:id:User\nhas_one:profile:Profile:user_id:profiles:id:User\n"
    );
}

/// deriving(Schema) works alongside other derives (Schema, Eq).
#[test]
fn e2e_deriving_schema_with_other_derives() {
    let output = compile_and_run(
        r#"
struct Item do
  id :: String
  name :: String
end deriving(Schema, Eq)

fn main() do
  println(Item.__table__())
end
"#,
    );
    assert_eq!(output, "items\n");
}

// ── Schema metadata: field types, column accessors, schema options, timestamps (Phase 97) ──

/// deriving(Schema) __field_types__() returns SQL type mappings.
#[test]
fn e2e_schema_field_types() {
    let output = compile_and_run(
        r#"
struct User do
  id :: String
  name :: String
  age :: Int
  active :: Bool
  score :: Float
end deriving(Schema)

fn main() do
  let types = User.__field_types__()
  println(List.get(types, 0))
  println(List.get(types, 2))
  println(List.get(types, 3))
  println(List.get(types, 4))
end
"#,
    );
    assert_eq!(
        output,
        "id:TEXT\nage:BIGINT\nactive:BOOLEAN\nscore:DOUBLE PRECISION\n"
    );
}

/// deriving(Schema) per-field column accessors return column name strings.
#[test]
fn e2e_schema_column_accessor() {
    let output = compile_and_run(
        r#"
struct User do
  id :: String
  name :: String
  email :: String
end deriving(Schema)

fn main() do
  println(User.__name_col__())
  println(User.__email_col__())
  println(User.__id_col__())
end
"#,
    );
    assert_eq!(output, "name\nemail\nid\n");
}

/// deriving(Schema) with `table "people"` overrides default table name.
#[test]
fn e2e_schema_custom_table_name() {
    let output = compile_and_run(
        r#"
struct User do
  table "people"
  id :: String
  name :: String
end deriving(Schema)

fn main() do
  println(User.__table__())
end
"#,
    );
    assert_eq!(output, "people\n");
}

/// deriving(Schema) with `primary_key :uuid` overrides default "id".
#[test]
fn e2e_schema_custom_primary_key() {
    let output = compile_and_run(
        r#"
struct User do
  primary_key :uuid
  uuid :: String
  name :: String
end deriving(Schema)

fn main() do
  println(User.__primary_key__())
end
"#,
    );
    assert_eq!(output, "uuid\n");
}

/// deriving(Schema) with `timestamps true` injects inserted_at/updated_at fields.
#[test]
fn e2e_schema_timestamps() {
    let output = compile_and_run(
        r#"
struct User do
  timestamps true
  id :: String
  name :: String
end deriving(Schema)

fn main() do
  let fields = User.__fields__()
  let types = User.__field_types__()
  let n = List.length(fields)
  println("${n}")
  println(List.get(fields, 2))
  println(List.get(fields, 3))
  println(List.get(types, 2))
end
"#,
    );
    assert_eq!(output, "4\ninserted_at\nupdated_at\ninserted_at:TEXT\n");
}

/// deriving(Schema) defaults unchanged without options (backward compatibility).
#[test]
fn e2e_schema_defaults_unchanged() {
    let output = compile_and_run(
        r#"
struct Post do
  id :: String
  title :: String
end deriving(Schema)

fn main() do
  println(Post.__table__())
  println(Post.__primary_key__())
end
"#,
    );
    assert_eq!(output, "posts\nid\n");
}

// ── Phase 97: ORM SQL Generation ─────────────────────────────────────

/// Orm.build_select with columns, where, order, and limit.
#[test]
fn e2e_orm_build_select_simple() {
    let output = compile_and_run(
        r#"
fn main() do
  let cols = ["id", "name"]
  let wheres = ["name ="]
  let orders = ["name ASC"]
  let sql = Orm.build_select("users", cols, wheres, orders, 10, -1)
  println(sql)
end
"#,
    );
    assert_eq!(output, "SELECT \"id\", \"name\" FROM \"users\" WHERE \"name\" = $1 ORDER BY \"name\" ASC LIMIT 10\n");
}

/// Orm.build_select with no columns (SELECT *), no where, no order.
#[test]
fn e2e_orm_build_select_all() {
    let output = compile_and_run(
        r#"
fn main() do
  let sql = Orm.build_select("users", [], [], [], -1, -1)
  println(sql)
end
"#,
    );
    assert_eq!(output, "SELECT * FROM \"users\"\n");
}

/// Orm.build_insert with columns and RETURNING.
#[test]
fn e2e_orm_build_insert() {
    let output = compile_and_run(
        r#"
fn main() do
  let cols = ["name", "email"]
  let returning = ["id"]
  let sql = Orm.build_insert("users", cols, returning)
  println(sql)
end
"#,
    );
    assert_eq!(
        output,
        "INSERT INTO \"users\" (\"name\", \"email\") VALUES ($1, $2) RETURNING \"id\"\n"
    );
}

/// Orm.build_update with SET, WHERE, and RETURNING.
#[test]
fn e2e_orm_build_update() {
    let output = compile_and_run(
        r#"
fn main() do
  let set_cols = ["name", "email"]
  let wheres = ["id ="]
  let returning = ["id", "name"]
  let sql = Orm.build_update("users", set_cols, wheres, returning)
  println(sql)
end
"#,
    );
    assert_eq!(output, "UPDATE \"users\" SET \"name\" = $1, \"email\" = $2 WHERE \"id\" = $3 RETURNING \"id\", \"name\"\n");
}

/// Orm.build_delete with WHERE clause.
#[test]
fn e2e_orm_build_delete() {
    let output = compile_and_run(
        r#"
fn main() do
  let wheres = ["id ="]
  let sql = Orm.build_delete("users", wheres, [])
  println(sql)
end
"#,
    );
    assert_eq!(output, "DELETE FROM \"users\" WHERE \"id\" = $1\n");
}

// ── Phase 98 Plan 01: Query Builder ─────────────────────────────────

/// Query.from creates a valid Query value (opaque Ptr).
#[test]
fn e2e_query_builder_basic_from() {
    let output = compile_and_run(
        r#"
fn main() do
  let q = Query.from("users")
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

/// Pipe-composable chain: from -> where -> order_by -> limit.
#[test]
fn e2e_query_builder_pipe_chain() {
    let output = compile_and_run(
        r#"
fn main() do
  let q = Query.from("users")
    |> Query.where(:name, "Alice")
    |> Query.order_by(:name, :asc)
    |> Query.limit(10)
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

/// Operator-based where, where_null, and where_not_null.
#[test]
fn e2e_query_builder_where_op() {
    let output = compile_and_run(
        r#"
fn main() do
  let q = Query.from("posts")
    |> Query.where_op(:age, :gt, "21")
    |> Query.where_null(:deleted_at)
    |> Query.where_not_null(:name)
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

/// All clause types compile and execute without crash.
#[test]
fn e2e_query_builder_all_clauses() {
    let output = compile_and_run(
        r#"
fn main() do
  let q = Query.from("events")
    |> Query.select(["id", "name"])
    |> Query.where(:status, "active")
    |> Query.order_by(:created_at, :desc)
    |> Query.limit(100)
    |> Query.offset(20)
    |> Query.group_by(:category)
    |> Query.having("count(*) >", "5")
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

/// Immutability: original Query is unchanged after pipe operations.
#[test]
fn e2e_query_builder_immutability() {
    let output = compile_and_run(
        r#"
fn main() do
  let q1 = Query.from("users")
  let q2 = q1 |> Query.where(:name, "Alice")
  let q3 = q1 |> Query.where(:name, "Bob")
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

/// Composable scopes: regular functions taking and returning Query via pipes.
#[test]
fn e2e_query_builder_composable_scope() {
    let output = compile_and_run(
        r#"
pub fn active(q) do
  q |> Query.where(:status, "active")
end

pub fn recent(q) do
  q |> Query.order_by(:created_at, :desc) |> Query.limit(10)
end

pub fn main() do
  let q = Query.from("users") |> active() |> recent()
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

/// Schema struct pipe with explicit Query.from using __table__().
#[test]
fn e2e_query_builder_schema_pipe_explicit() {
    let output = compile_and_run(
        r#"
struct User do
  id :: String
  name :: String
end deriving(Schema)

pub fn main() do
  let q = Query.from(User.__table__()) |> Query.where(:name, "Alice")
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

// ── Phase 98-02: Repo Module Tests ──────────────────────────────────

/// Full pipeline compiles: Query build + Repo module available in type checking.
#[test]
fn e2e_repo_full_pipeline_compiles() {
    let output = compile_and_run(
        r#"
fn main() do
  let q = Query.from("users")
    |> Query.where(:name, "Alice")
    |> Query.order_by(:name, :asc)
    |> Query.limit(10)
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

/// Repo + Query module type-check: count/exists with query composition.
#[test]
fn e2e_repo_count_exists_type_check() {
    let output = compile_and_run(
        r#"
fn main() do
  let q = Query.from("users") |> Query.where(:active, "true")
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

/// Full pipeline with Schema struct integrating Query and Repo.
#[test]
fn e2e_repo_with_schema_struct() {
    let output = compile_and_run(
        r#"
struct User do
  id :: String
  name :: String
  email :: String
end deriving(Schema, Row)

fn main() do
  let q = Query.from(User.__table__())
    |> Query.where(:name, "Alice")
    |> Query.select(User.__fields__())
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

/// Complex query with multiple clause types compiles with Repo available.
#[test]
fn e2e_repo_complex_query_compiles() {
    let output = compile_and_run(
        r#"
fn main() do
  let q = Query.from("orders")
    |> Query.where(:status, "active")
    |> Query.where_op(:total, :gte, "100")
    |> Query.order_by(:created_at, :desc)
    |> Query.group_by(:category)
    |> Query.having("count(*) >", "5")
    |> Query.limit(50)
    |> Query.offset(10)
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

// ── Phase 98-03: Repo Write Operations ──────────────────────────────────

/// Verify Repo.insert type signature (Repo module with write ops is importable).
#[test]
fn e2e_repo_insert_compiles() {
    let output = compile_and_run(
        r#"
import Repo

fn main() do
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

/// Verify all Repo write operations type-check (import Repo + Map).
#[test]
fn e2e_repo_write_pipeline_compiles() {
    let output = compile_and_run(
        r#"
import Repo
import Query
import Map

fn main() do
  # These would require a real pool to execute
  # We verify they compile and type-check
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

/// Verify Repo.transaction with closure type-checks.
#[test]
fn e2e_repo_transaction_compiles() {
    let output = compile_and_run(
        r#"
import Repo

fn main() do
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

/// Comprehensive test: full ORM pipeline combining Schema + Query + Repo.
#[test]
fn e2e_full_orm_pipeline_compiles() {
    let output = compile_and_run(
        r#"
import Query
import Repo

struct User do
  id :: String
  name :: String
  email :: String
end deriving(Schema, Row)

fn active(q) do
  q |> Query.where(:status, "active")
end

fn main() do
  # Build a complex query using Schema metadata and composable scopes
  let q = Query.from(User.__table__())
    |> Query.select(User.__fields__())
    |> Query.where(:name, "Alice")
    |> Query.where_op(:age, :gt, "18")
    |> active()
    |> Query.order_by(:name, :asc)
    |> Query.limit(10)
    |> Query.offset(0)
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

/// Verify join/group_by/having compile together.
#[test]
fn e2e_query_builder_join_and_group() {
    let output = compile_and_run(
        r#"
import Query

fn main() do
  let q = Query.from("orders")
    |> Query.join(:inner, "users", "users.id = orders.user_id")
    |> Query.group_by(:status)
    |> Query.having("count(*) >", "5")
    |> Query.select(["status", "count(*)"])
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

// ── Phase 106: Advanced WHERE operators e2e tests ────────────────────

/// Query.where_in takes the values as a list, like where_not_in.
#[test]
fn e2e_query_builder_where_in() {
    let output = compile_and_run(
        r#"
fn main() do
  let q = Query.from("issues")
    |> Query.where_in(:status, ["open", "triaged"])
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

/// Query.where_not_in compiles and produces valid query.
#[test]
fn e2e_query_builder_where_not_in() {
    let output = compile_and_run(
        r#"
fn main() do
  let q = Query.from("issues")
    |> Query.where_not_in(:status, ["archived", "deleted"])
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

/// Query.where_between compiles and produces valid query.
#[test]
fn e2e_query_builder_where_between() {
    let output = compile_and_run(
        r#"
fn main() do
  let q = Query.from("events")
    |> Query.where_between(:age, "18", "65")
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

/// Query.where_op with :ilike compiles.
#[test]
fn e2e_query_builder_where_ilike() {
    let output = compile_and_run(
        r#"
fn main() do
  let q = Query.from("users")
    |> Query.where_op(:name, :ilike, "%alice%")
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

/// Query.where_or compiles with grouped OR conditions.
#[test]
fn e2e_query_builder_where_or() {
    let output = compile_and_run(
        r#"
fn main() do
  let q = Query.from("issues")
    |> Query.where(:project_id, "abc")
    |> Query.where_or([:status, :level], ["active", "error"])
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

/// Combined: all new WHERE operators in one pipe chain.
#[test]
fn e2e_query_builder_advanced_where_combined() {
    let output = compile_and_run(
        r#"
fn main() do
  let q = Query.from("events")
    |> Query.where(:project_id, "abc")
    |> Query.where_op(:level, :neq, "debug")
    |> Query.where_not_in(:status, ["archived", "deleted"])
    |> Query.where_between(:age, "18", "65")
    |> Query.where_op(:message, :ilike, "%error%")
    |> Query.where_or([:status, :priority], ["active", "high"])
    |> Query.where_null(:deleted_at)
    |> Query.order_by(:received_at, :desc)
    |> Query.limit(50)
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

// ── Phase 106 Plan 02: Fragment renumbering and raw ORDER BY/GROUP BY E2E ────

/// Query.order_by_raw emits raw ORDER BY expression.
#[test]
fn e2e_query_builder_order_by_raw() {
    let output = compile_and_run(
        r#"
fn main() do
  let q = Query.from("events")
    |> Query.where(:project_id, "abc")
    |> Query.order_by_raw("random()")
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

/// Query.group_by_raw emits raw GROUP BY expression.
#[test]
fn e2e_query_builder_group_by_raw() {
    let output = compile_and_run(
        r#"
fn main() do
  let q = Query.from("events")
    |> Query.group_by_raw("date_trunc('hour', received_at)")
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

/// Query.select_raw with count(*) and group_by_raw for analytics.
#[test]
fn e2e_query_builder_select_raw_with_group_by_raw() {
    let output = compile_and_run(
        r#"
fn main() do
  let q = Query.from("events")
    |> Query.select_raw(["count(*)::text AS count", "level"])
    |> Query.where(:project_id, "abc")
    |> Query.group_by_raw("level")
    |> Query.order_by_raw("count DESC")
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

/// Query.where_raw with $1 style placeholders.
#[test]
fn e2e_query_builder_where_raw_dollar() {
    let output = compile_and_run(
        r#"
fn main() do
  let q = Query.from("users")
    |> Query.where(:active, "true")
    |> Query.where_raw("email ILIKE $1", ["%@example.com"])
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

/// Query.fragment with PG crypt function.
#[test]
fn e2e_query_builder_fragment_crypt() {
    let output = compile_and_run(
        r#"
fn main() do
  let q = Query.from("users")
    |> Query.where(:email, "alice@example.com")
    |> Query.fragment("AND password_hash = crypt(?, password_hash)", ["secret"])
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

/// Query.where_raw for JSONB containment check.
#[test]
fn e2e_query_builder_jsonb_fragment() {
    let output = compile_and_run(
        r#"
fn main() do
  let q = Query.from("events")
    |> Query.where(:project_id, "abc")
    |> Query.where_raw("tags @> ?::jsonb", ["{\"env\":\"production\"}"])
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

/// Combined: all fragment positions (SELECT, WHERE, GROUP BY, ORDER BY).
#[test]
fn e2e_query_builder_fragments_all_positions() {
    let output = compile_and_run(
        r#"
fn main() do
  let q = Query.from("events")
    |> Query.select_raw(["count(*)::text AS count"])
    |> Query.where(:project_id, "abc")
    |> Query.where_raw("received_at > now() - interval '24 hours'", [])
    |> Query.group_by_raw("date_trunc('hour', received_at)")
    |> Query.order_by_raw("date_trunc('hour', received_at)")
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

// ── Phase 107 Plan 01: JOIN alias support and comprehensive join E2E tests ──

/// Basic inner join compiles and runs through the full pipeline.
#[test]
fn e2e_query_builder_inner_join() {
    let output = compile_and_run(
        r#"
import Query

fn main() do
  let q = Query.from("issues")
    |> Query.join(:inner, "projects", "projects.id = issues.project_id")
    |> Query.select(["issues.id", "projects.name"])
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

/// Left join compiles and runs.
#[test]
fn e2e_query_builder_left_join() {
    let output = compile_and_run(
        r#"
import Query

fn main() do
  let q = Query.from("users")
    |> Query.join(:left, "profiles", "profiles.user_id = users.id")
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

/// Two joins chained in one query.
#[test]
fn e2e_query_builder_multi_join() {
    let output = compile_and_run(
        r#"
import Query

fn main() do
  let q = Query.from("issues")
    |> Query.join(:inner, "projects", "projects.id = issues.project_id")
    |> Query.join(:inner, "organizations", "organizations.id = projects.org_id")
    |> Query.select(["issues.id", "projects.name", "organizations.name"])
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

/// Aliased join via Query.join_as compiles and runs.
#[test]
fn e2e_query_builder_join_as_alias() {
    let output = compile_and_run(
        r#"
import Query

fn main() do
  let q = Query.from("issues")
    |> Query.join_as(:inner, "projects", "p", "p.id = issues.project_id")
    |> Query.select(["issues.id", "p.name"])
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

/// Join combined with WHERE, ORDER BY, and LIMIT.
#[test]
fn e2e_query_builder_join_with_where() {
    let output = compile_and_run(
        r#"
import Query

fn main() do
  let q = Query.from("issues")
    |> Query.join(:inner, "projects", "projects.id = issues.project_id")
    |> Query.where(:status, "active")
    |> Query.order_by(:name, :asc)
    |> Query.limit(10)
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

/// Two aliased joins in one query.
#[test]
fn e2e_query_builder_multi_alias_join() {
    let output = compile_and_run(
        r#"
import Query

fn main() do
  let q = Query.from("alerts")
    |> Query.join_as(:inner, "alert_rules", "r", "r.id = alerts.rule_id")
    |> Query.join_as(:inner, "projects", "p", "p.id = alerts.project_id")
    |> Query.where(:status, "active")
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

// ── Phase 108: Aggregate SELECT functions ────────────────────────────

#[test]
fn e2e_query_builder_select_count() {
    let output = compile_and_run(
        r#"
import Query

fn main() do
  let q = Query.from("issues")
    |> Query.select_count()
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

#[test]
fn e2e_query_builder_select_sum() {
    let output = compile_and_run(
        r#"
import Query

fn main() do
  let q = Query.from("orders")
    |> Query.select_sum(:amount)
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

#[test]
fn e2e_query_builder_select_avg_group_by() {
    let output = compile_and_run(
        r#"
import Query

fn main() do
  let q = Query.from("products")
    |> Query.select_avg(:price)
    |> Query.group_by(:category)
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

#[test]
fn e2e_query_builder_select_min_max() {
    let output = compile_and_run(
        r#"
import Query

fn main() do
  let q = Query.from("events")
    |> Query.select_min(:created_at)
    |> Query.select_max(:created_at)
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

#[test]
fn e2e_query_builder_aggregate_with_having() {
    let output = compile_and_run(
        r#"
import Query

fn main() do
  let q = Query.from("issues")
    |> Query.select_count()
    |> Query.group_by(:project_id)
    |> Query.having("count(*) >", "5")
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

#[test]
fn e2e_query_builder_select_count_field() {
    let output = compile_and_run(
        r#"
import Query

fn main() do
  let q = Query.from("issues")
    |> Query.select_count_field(:assignee_id)
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

// ── Phase 99: Changeset e2e tests ────────────────────────────────────

/// Test 1: Changeset.cast creates changeset from params, filtering to allowed fields.
#[test]
fn e2e_changeset_cast_basic() {
    let output = compile_and_run(
        r#"
import Changeset

fn main() do
  let data = %{}
  let params = %{"name" => "Alice", "email" => "alice@example.com", "role" => "admin"}
  let cs = Changeset.cast(data, params, [:name, :email])
  let is_valid = Changeset.valid(cs)
  if is_valid do
    println("valid")
  else
    println("invalid")
  end
end
"#,
    );
    assert_eq!(output, "valid\n");
}

/// Test 2: validate_required catches missing fields.
#[test]
fn e2e_changeset_validate_required() {
    let output = compile_and_run(
        r#"
import Changeset

fn main() do
  let data = %{}
  let params = %{"name" => "Alice"}
  let cs = Changeset.cast(data, params, [:name, :email])
    |> Changeset.validate_required([:name, :email])
  let is_valid = Changeset.valid(cs)
  if is_valid do
    println("valid")
  else
    println("invalid")
  end
end
"#,
    );
    assert_eq!(output, "invalid\n");
}

/// Test 3: validate_length catches short strings.
#[test]
fn e2e_changeset_validate_length() {
    let output = compile_and_run(
        r#"
import Changeset

fn main() do
  let data = %{}
  let params = %{"name" => "Al", "email" => "a@b.com"}
  let cs = Changeset.cast(data, params, [:name, :email])
    |> Changeset.validate_length(:name, 3, -1)
  let is_valid = Changeset.valid(cs)
  if is_valid do
    println("valid")
  else
    println("invalid")
  end
end
"#,
    );
    assert_eq!(output, "invalid\n");
}

/// Test 4: validate_format checks substring presence.
#[test]
fn e2e_changeset_validate_format() {
    let output = compile_and_run(
        r#"
import Changeset

fn main() do
  let data = %{}
  let params = %{"email" => "not-an-email"}
  let cs = Changeset.cast(data, params, [:email])
    |> Changeset.validate_format(:email, "@")
  let is_valid = Changeset.valid(cs)
  if is_valid do
    println("valid")
  else
    println("invalid")
  end
end
"#,
    );
    assert_eq!(output, "invalid\n");
}

/// Test 5: validate_inclusion checks allowed values.
#[test]
fn e2e_changeset_validate_inclusion() {
    let output = compile_and_run(
        r#"
import Changeset

fn main() do
  let data = %{}
  let params = %{"role" => "superadmin"}
  let cs = Changeset.cast(data, params, [:role])
    |> Changeset.validate_inclusion(:role, ["admin", "user"])
  let is_valid = Changeset.valid(cs)
  if is_valid do
    println("valid")
  else
    println("invalid")
  end
end
"#,
    );
    assert_eq!(output, "invalid\n");
}

/// Test 6: validate_number checks bounds.
#[test]
fn e2e_changeset_validate_number() {
    let output = compile_and_run(
        r#"
import Changeset

fn main() do
  let data = %{}
  let params = %{"age" => "0"}
  let cs = Changeset.cast(data, params, [:age])
    |> Changeset.validate_number(:age, 0, -1, -1, -1)
  let is_valid = Changeset.valid(cs)
  if is_valid do
    println("valid")
  else
    println("invalid")
  end
end
"#,
    );
    assert_eq!(output, "invalid\n");
}

/// Test 7: Multiple validators on different fields accumulate errors.
#[test]
fn e2e_changeset_pipe_chain_accumulates_errors() {
    let output = compile_and_run(
        r#"
import Changeset

fn main() do
  let data = %{}
  let params = %{"name" => "A", "email" => "bad"}
  let cs = Changeset.cast(data, params, [:name, :email])
    |> Changeset.validate_required([:name, :email])
    |> Changeset.validate_length(:name, 2, -1)
    |> Changeset.validate_format(:email, "@")
  let is_valid = Changeset.valid(cs)
  if is_valid do
    println("valid")
  else
    println("invalid")
  end
end
"#,
    );
    assert_eq!(output, "invalid\n");
}

/// Test 8: Changeset with all validations passing.
#[test]
fn e2e_changeset_valid_passes() {
    let output = compile_and_run(
        r#"
import Changeset

fn main() do
  let data = %{}
  let params = %{"name" => "Alice", "email" => "alice@example.com"}
  let cs = Changeset.cast(data, params, [:name, :email])
    |> Changeset.validate_required([:name, :email])
    |> Changeset.validate_length(:name, 2, 50)
    |> Changeset.validate_format(:email, "@")
  let is_valid = Changeset.valid(cs)
  if is_valid do
    println("valid")
  else
    println("invalid")
  end
end
"#,
    );
    assert_eq!(output, "valid\n");
}

/// Test 9: 4-arg cast with field_types compiles and runs.
#[test]
fn e2e_changeset_cast_with_types_compiles() {
    let output = compile_and_run(
        r#"
import Changeset

struct User do
  id :: String
  name :: String
  email :: String
end deriving(Schema, Row)

fn main() do
  let data = %{}
  let params = %{"name" => "Alice", "email" => "alice@example.com"}
  let cs = Changeset.cast_with_types(data, params, [:name, :email], User.__field_types__())
  let is_valid = Changeset.valid(cs)
  if is_valid do
    println("valid")
  else
    println("invalid")
  end
end
"#,
    );
    assert_eq!(output, "valid\n");
}

/// Test 10: Field accessors return correct data.
#[test]
fn e2e_changeset_accessors() {
    let output = compile_and_run(
        r#"
import Changeset

fn main() do
  let data = %{}
  let params = %{"name" => "Alice", "email" => "alice@example.com"}
  let cs = Changeset.cast(data, params, [:name, :email])
  let name = Changeset.get_change(cs, :name)
  println(name)
end
"#,
    );
    assert_eq!(output, "Alice\n");
}

// ── Phase 99-02: Repo Changeset Integration Tests ───────────────────

/// Test 11: Repo.insert_changeset compiles (Changeset and Repo modules importable together).
#[test]
fn e2e_repo_insert_changeset_compiles() {
    let output = compile_and_run(
        r#"
import Changeset
import Repo

fn main() do
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

/// Test 12: Invalid changeset skips SQL execution.
#[test]
fn e2e_changeset_invalid_skips_sql() {
    let output = compile_and_run(
        r#"
import Changeset

fn main() do
  let data = %{}
  let params = %{"name" => ""}
  let cs = Changeset.cast(data, params, [:name, :email])
    |> Changeset.validate_required([:name, :email])
  let is_valid = Changeset.valid(cs)
  if is_valid do
    println("would execute SQL")
  else
    println("skipped SQL")
  end
end
"#,
    );
    assert_eq!(output, "skipped SQL\n");
}

/// Test 13: Full changeset validation pipeline -- all validators pass.
#[test]
fn e2e_full_changeset_validation_pipeline() {
    let output = compile_and_run(
        r#"
import Changeset

fn main() do
  let data = %{}
  let params = %{"name" => "Alice", "email" => "alice@example.com", "role" => "admin"}
  let cs = Changeset.cast(data, params, [:name, :email, :role])
    |> Changeset.validate_required([:name, :email])
    |> Changeset.validate_length(:name, 2, 50)
    |> Changeset.validate_format(:email, "@")
    |> Changeset.validate_inclusion(:role, ["admin", "user", "moderator"])
  let is_valid = Changeset.valid(cs)
  if is_valid do
    println("valid")
  else
    println("invalid")
  end
end
"#,
    );
    assert_eq!(output, "valid\n");
}

/// Test 14: Repo.insert_changeset has correct type (Schema + changeset).
#[test]
fn e2e_changeset_repo_insert_type_checks() {
    let output = compile_and_run(
        r#"
import Changeset
import Repo

struct User do
  id :: String
  name :: String
  email :: String
end deriving(Schema, Row)

fn main() do
  let data = %{}
  let params = %{"name" => "Alice", "email" => "alice@example.com"}
  let cs = Changeset.cast_with_types(data, params, [:name, :email], User.__field_types__())
    |> Changeset.validate_required([:name, :email])
    |> Changeset.validate_format(:email, "@")
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

/// Test 15: Update changeset with existing data passes validation.
#[test]
fn e2e_changeset_update_type_checks() {
    let output = compile_and_run(
        r#"
import Changeset
import Repo

fn main() do
  let data = %{"name" => "Alice", "email" => "alice@example.com"}
  let params = %{"name" => "Bob"}
  let cs = Changeset.cast(data, params, [:name])
    |> Changeset.validate_required([:name])
    |> Changeset.validate_length(:name, 1, 50)
  let is_valid = Changeset.valid(cs)
  if is_valid do
    println("valid update")
  else
    println("invalid update")
  end
end
"#,
    );
    assert_eq!(output, "valid update\n");
}

/// Test 16: Multi-field error accumulation with get_error accessor.
#[test]
fn e2e_changeset_error_accumulation_multiple_fields() {
    let output = compile_and_run(
        r#"
import Changeset

fn main() do
  let data = %{}
  let params = %{"name" => "", "email" => "bad", "age" => "-5"}
  let cs = Changeset.cast(data, params, [:name, :email, :age])
    |> Changeset.validate_required([:name])
    |> Changeset.validate_format(:email, "@")
    |> Changeset.validate_number(:age, 0, -1, -1, -1)
  let is_valid = Changeset.valid(cs)
  if is_valid do
    println("valid")
  else
    let name_err = Changeset.get_error(cs, :name)
    let email_err = Changeset.get_error(cs, :email)
    println(name_err)
    println(email_err)
  end
end
"#,
    );
    assert_eq!(output, "can't be blank\nhas invalid format\n");
}

// ── Phase 100: Repo.preload E2E Tests ────────────────────────────────

/// Repo.preload compiles with correct type signature (4 params: pool, rows, assocs, meta).
#[test]
fn e2e_repo_preload_type_check() {
    let output = compile_and_run(
        r#"
struct User do
  id :: String
  name :: String
  has_many :posts, Post
end deriving(Schema)

struct Post do
  id :: String
  title :: String
  user_id :: String
  belongs_to :user, User
end deriving(Schema)

fn main() do
  let meta = User.__relationship_meta__()
  let m0 = List.get(meta, 0)
  println(m0)
  println("preload_types_ok")
end
"#,
    );
    assert_eq!(
        output,
        "has_many:posts:Post:user_id:posts:id:User\npreload_types_ok\n"
    );
}

/// A Query, an Expr and a Changeset each have a type of their own: all three
/// were `Ptr`, so one passed where another belonged compiled, and the
/// runtime read it as the other kind of object (a bus error, for a Query
/// given as an Expr).
#[test]
fn e2e_query_expr_and_changeset_values_have_their_own_types() {
    for (value, expected, found) in [
        (
            "Query.where_expr(Query.from(\"t\"), Query.from(\"u\"))",
            "Expr",
            "Query",
        ),
        ("Repo.all(pool, Expr.column(\"a\"))", "Query", "Expr"),
        ("Changeset.valid(Query.from(\"t\"))", "Changeset", "Query"),
        (
            "Repo.insert_changeset(pool, \"t\", Query.from(\"t\"))",
            "Changeset",
            "Query",
        ),
    ] {
        let source = format!(
            "fn run(pool :: PoolHandle) do\n  let v = {value}\n  println(\"built\")\nend\n\nfn main() do\n  println(\"ok\")\nend\n"
        );
        let error = compile_expect_error(&source);
        assert!(
            error.contains(&format!("expected `{expected}`, found `{found}`")),
            "{value}:\n{error}"
        );
    }
    // Annotated, a builder's value has the type its module names.
    let output = compile_and_run(
        r#"
fn active(q :: Query) -> Query do
  q |> Query.where_expr(Expr.eq(Expr.column("status"), Expr.value("on")))
end

fn main() do
  let c :: Changeset = Changeset.cast(%{}, %{"a" => "1"}, [:a])
  let q = Query.from("t") |> active()
  println(Changeset.get_change(c, :a))
end
"#,
    );
    assert_eq!(output, "1\n");
}

/// Repo.preload with merged metadata for nested preloading compiles correctly.
#[test]
fn e2e_repo_preload_merged_meta() {
    let output = compile_and_run(
        r#"
struct User do
  id :: String
  name :: String
  has_many :posts, Post
end deriving(Schema)

struct Post do
  id :: String
  title :: String
  user_id :: String
  belongs_to :user, User
  has_many :comments, Comment
end deriving(Schema)

struct Comment do
  id :: String
  body :: String
  post_id :: String
  belongs_to :post, Post
end deriving(Schema)

fn main() do
  let user_meta = User.__relationship_meta__()
  let post_meta = Post.__relationship_meta__()
  let um = List.get(user_meta, 0)
  let pm0 = List.get(post_meta, 0)
  let pm1 = List.get(post_meta, 1)
  println(um)
  println(pm0)
  println(pm1)
end
"#,
    );
    assert_eq!(output, "has_many:posts:Post:user_id:posts:id:User\nbelongs_to:user:User:user_id:users:id:Post\nhas_many:comments:Comment:post_id:comments:id:Post\n");
}

// ── Phase 101: Migration DSL E2E Tests ──────────────────────────────────

/// Migration module is available and all 8 functions type-check.
#[test]
fn e2e_migration_module_type_check() {
    let output = compile_and_run(
        r#"
import Migration

fn main() do
  println("migration_types_ok")
end
"#,
    );
    assert_eq!(output, "migration_types_ok\n");
}

/// Migration.create_table + Migration.drop_table compile with pool parameter.
#[test]
fn e2e_migration_table_ops_compile() {
    // This test verifies that the function signatures type-check correctly.
    // The functions require a pool handle and string parameters.
    // We cannot execute them without a live database, so we verify compilation only.
    let output = compile_and_run(
        r#"
fn run_migration(pool :: PoolHandle) -> Int!String do
  Migration.create_table(pool, "users", [
    "id:UUID:PRIMARY KEY",
    "name:TEXT:NOT NULL",
    "email:TEXT:NOT NULL UNIQUE"
  ])?
  Migration.drop_table(pool, "users")?
  Ok(0)
end

fn main() do
  println("table_ops_ok")
end
"#,
    );
    assert_eq!(output, "table_ops_ok\n");
}

/// Migration column operations (add, drop, rename) compile.
#[test]
fn e2e_migration_column_ops_compile() {
    let output = compile_and_run(
        r#"
fn run_migration(pool :: PoolHandle) -> Int!String do
  Migration.add_column(pool, "users", "age:BIGINT")?
  Migration.drop_column(pool, "users", "age")?
  Migration.rename_column(pool, "users", "name", "full_name")?
  Ok(0)
end

fn main() do
  println("column_ops_ok")
end
"#,
    );
    assert_eq!(output, "column_ops_ok\n");
}

/// Migration index operations (named, ordered create + drop) compile.
#[test]
fn e2e_migration_index_ops_compile() {
    let output = compile_and_run(
        r#"
fn run_migration(pool :: PoolHandle) -> Int!String do
  Migration.create_index(pool, "issues", ["project_id", "last_seen:DESC"], "name:idx_issues_project_last_seen where:status = 'open'")?
  Migration.drop_index(pool, "users", ["email"])?
  Ok(0)
end

fn main() do
  println("index_ops_ok")
end
"#,
    );
    assert_eq!(output, "index_ops_ok\n");
}

/// PostgreSQL-specific schema helpers compile without falling back to raw Migration.execute.
#[test]
fn e2e_migration_pg_schema_helpers_compile() {
    let output = compile_and_run(
        r#"
fn run_migration(pool :: PoolHandle) -> Int!String do
  Pg.create_extension(pool, "pgcrypto")?
  Pg.create_range_partitioned_table(pool, "events", [
    "id:UUID:NOT NULL DEFAULT gen_random_uuid()",
    "tags:JSONB:NOT NULL DEFAULT '{}'",
    "received_at:TIMESTAMPTZ:NOT NULL DEFAULT now()",
    "PRIMARY KEY (id, received_at)"
  ], "received_at")?
  Pg.create_gin_index(pool, "events", "idx_events_tags", "tags", "jsonb_path_ops")?
  Ok(0)
end

fn main() do
  println("pg_schema_ok")
end
"#,
    );
    assert_eq!(output, "pg_schema_ok\n");
}

// ── Migration Scaffold Generation ─────────────────────────────────────

/// meshc migrate generate creates a migration file with correct structure.
#[test]
fn e2e_migrate_generate_creates_file() {
    let temp_dir = tempfile::tempdir().expect("failed to create temp dir");
    let project_dir = temp_dir.path().join("myproject");
    std::fs::create_dir_all(&project_dir).expect("failed to create project dir");

    let meshc = find_meshc();
    let output = Command::new(&meshc)
        .args(["migrate", "generate", "create_users"])
        .current_dir(&project_dir)
        .output()
        .expect("failed to invoke meshc");

    assert!(
        output.status.success(),
        "meshc migrate generate failed:\nstdout: {}\nstderr: {}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );

    // Verify migrations/ directory was created
    let migrations_dir = project_dir.join("migrations");
    assert!(
        migrations_dir.exists(),
        "migrations/ directory should have been created"
    );

    // Find the generated file
    let entries: Vec<_> = std::fs::read_dir(&migrations_dir)
        .expect("failed to read migrations dir")
        .filter_map(|e| e.ok())
        .collect();
    assert_eq!(
        entries.len(),
        1,
        "Should have exactly one migration file, got: {}",
        entries.len()
    );

    let filename = entries[0].file_name().to_string_lossy().to_string();

    // Verify filename format: YYYYMMDDHHMMSS_create_users.mpl
    assert!(
        filename.ends_with("_create_users.mpl"),
        "Filename should end with _create_users.mpl, got: {}",
        filename
    );

    // Verify 14-digit timestamp prefix
    let prefix = &filename[..14];
    assert!(
        prefix.chars().all(|c| c.is_ascii_digit()),
        "First 14 chars should be digits, got: {}",
        prefix
    );
    assert_eq!(
        &filename[14..15],
        "_",
        "Character at position 14 should be underscore"
    );

    // Verify file content
    let content = std::fs::read_to_string(entries[0].path()).expect("failed to read migration");
    assert!(
        content.contains("pub fn up(pool :: PoolHandle) -> Int!String do"),
        "Migration should contain up function signature"
    );
    assert!(
        content.contains("pub fn down(pool :: PoolHandle) -> Int!String do"),
        "Migration should contain down function signature"
    );
    assert!(
        content.contains("# Migration: create_users"),
        "Migration should contain name in comment header"
    );
    assert!(
        content.contains("Pg.create_extension(pool, \"pgcrypto\")?"),
        "Migration scaffold should teach Pg.create_extension for PostgreSQL extras"
    );
    assert!(
        !content.contains("Migration.execute(pool, \"CREATE EXTENSION IF NOT EXISTS pgcrypto\")?"),
        "Migration scaffold should not teach raw Migration.execute for PostgreSQL extras"
    );
}

/// meshc migrate generate rejects invalid names (uppercase, spaces).
#[test]
fn e2e_migrate_generate_invalid_name() {
    let temp_dir = tempfile::tempdir().expect("failed to create temp dir");
    let project_dir = temp_dir.path().join("myproject");
    std::fs::create_dir_all(&project_dir).expect("failed to create project dir");

    let meshc = find_meshc();

    // Test uppercase name
    let output = Command::new(&meshc)
        .args(["migrate", "generate", "Create_Users"])
        .current_dir(&project_dir)
        .output()
        .expect("failed to invoke meshc");

    assert!(
        !output.status.success(),
        "meshc migrate generate should fail for uppercase name"
    );
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        stderr.contains("lowercase"),
        "Error should mention lowercase, got: {}",
        stderr
    );

    // Test name with spaces (passed as separate arg, so clap splits it)
    // Instead, test with a hyphenated name which is also invalid
    let output2 = Command::new(&meshc)
        .args(["migrate", "generate", "create-users"])
        .current_dir(&project_dir)
        .output()
        .expect("failed to invoke meshc");

    assert!(
        !output2.status.success(),
        "meshc migrate generate should fail for hyphenated name"
    );
    let stderr2 = String::from_utf8_lossy(&output2.stderr);
    assert!(
        stderr2.contains("lowercase"),
        "Error should mention lowercase, got: {}",
        stderr2
    );
}

/// meshc migrate generate scaffold produces syntactically valid Mesh code
/// that compiles as part of a migration project.
#[test]
fn e2e_migrate_generate_scaffold_compiles() {
    let temp_dir = tempfile::tempdir().expect("failed to create temp dir");
    let project_dir = temp_dir.path().join("myproject");
    std::fs::create_dir_all(&project_dir).expect("failed to create project dir");

    // Step 1: Generate a migration scaffold
    let meshc = find_meshc();
    let gen_output = Command::new(&meshc)
        .args(["migrate", "generate", "create_posts"])
        .current_dir(&project_dir)
        .output()
        .expect("failed to invoke meshc");
    assert!(
        gen_output.status.success(),
        "meshc migrate generate failed: {}",
        String::from_utf8_lossy(&gen_output.stderr)
    );

    // Step 2: Find the generated file
    let migrations_dir = project_dir.join("migrations");
    let entry = std::fs::read_dir(&migrations_dir)
        .expect("read migrations dir")
        .next()
        .expect("should have one entry")
        .expect("entry ok");

    // Step 3: Copy the migration file to a temp compilation project
    // and create a main.mpl that references the migration function signatures
    let compile_dir = temp_dir.path().join("compile_test");
    std::fs::create_dir_all(&compile_dir).expect("create compile dir");

    // Copy migration as migration.mpl module
    std::fs::copy(entry.path(), compile_dir.join("migration.mpl")).expect("copy migration file");

    // Create a main.mpl that imports and uses the migration module
    let main_content = r#"import Migration

fn main() do
  # Verify the module has the expected function signatures
  # by referencing them in a type-compatible way
  let _up_fn = Migration.up
  let _down_fn = Migration.down
  println("scaffold_compiles")
end
"#;
    std::fs::write(compile_dir.join("main.mpl"), main_content).expect("write main.mpl");

    // Step 4: Compile the project
    let build_output = Command::new(&meshc)
        .args(["build", compile_dir.to_str().unwrap()])
        .output()
        .expect("failed to invoke meshc build");

    assert!(
        build_output.status.success(),
        "Scaffold should compile successfully:\nstdout: {}\nstderr: {}",
        String::from_utf8_lossy(&build_output.stdout),
        String::from_utf8_lossy(&build_output.stderr)
    );

    // Step 5: Run the compiled binary
    let binary = compile_dir.join("compile_test");
    let run_output = Command::new(&binary)
        .output()
        .expect("failed to run compiled binary");

    assert!(
        run_output.status.success(),
        "Compiled scaffold project should run successfully"
    );
    let stdout = String::from_utf8_lossy(&run_output.stdout);
    assert_eq!(stdout, "scaffold_compiles\n");
}

// ── Phase 109 Plan 01: Upsert, RETURNING, Subquery E2E tests ─────────

#[test]
fn e2e_repo_insert_or_update() {
    // Verifies Repo.insert_or_update compiles through full pipeline
    // (typechecker + MIR lowering + codegen + JIT symbol resolution).
    // Does not call at runtime since we need a PoolHandle (not SqliteConn).
    let output = compile_and_run(
        r#"
import Repo
import Map

fn upsert_demo(pool, fields) do
  Repo.insert_or_update(pool, "items", fields, ["id"], ["qty"])
end

fn main() do
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

#[test]
fn e2e_query_builder_where_sub() {
    // Verifies subquery WHERE compiles through full pipeline
    let output = compile_and_run(
        r#"
fn main() do
  let sub = Query.from("projects")
    |> Query.select(["id"])
    |> Query.where(:org_id, "abc")
  let _q = Query.from("issues")
    |> Query.where_sub(:project_id, sub)
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

#[test]
fn e2e_try_result_binding_arity() {
    // Regression test: let x = Sqlite.execute(db, sql, params)? followed by
    // Int.to_string(x) should NOT trigger a spurious E0003 arity mismatch.
    let output = compile_and_run(
        r#"
fn run() -> Int!String do
  let db = Sqlite.open(":memory:")?
  let _ = Sqlite.execute(db, "CREATE TABLE t (id INTEGER)", [])?
  let x = Sqlite.execute(db, "INSERT INTO t VALUES (1)", [])?
  println(Int.to_string(x))
  Sqlite.close(db)
  Ok(0)
end

fn main() do
  let result = run()
  case result do
    Ok(v) -> println("ok")
    Err(e) -> println(e)
  end
end
"#,
    );
    assert!(output.contains("ok"));
}

#[test]
fn e2e_repo_delete_where_returning() {
    // Verifies Repo.delete_where_returning compiles through full pipeline
    // (typechecker + MIR lowering + codegen + JIT symbol resolution).
    // Does not call at runtime since we need a PoolHandle (not SqliteConn).
    let output = compile_and_run(
        r#"
import Repo
import Query

fn delete_demo(pool) do
  let q = Query.from("logs") |> Query.where(:id, "l1")
  Repo.delete_where_returning(pool, "logs", q)
end

fn main() do
  println("ok")
end
"#,
    );
    assert_eq!(output, "ok\n");
}

/// Phase 116: Slot pipe basic usage — |2> inserts piped value at argument position 2.
#[test]
fn e2e_slot_pipe_basic() {
    let source = read_fixture("slot_pipe_basic.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "11\nhello world !\n");
}

/// Phase 116: Slot pipe chaining — |2> chains with |> correctly.
#[test]
fn e2e_slot_pipe_chain() {
    let source = read_fixture("slot_pipe_chain.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "15\n20\n");
}

/// Phase 116: Slot pipe arity error — |N> where N > arity emits a clear error.
#[test]
fn e2e_slot_pipe_arity_error() {
    let source = read_fixture("slot_pipe_arity_error.mpl");
    let err = compile_expect_error(&source);
    assert!(
        err.contains("slot position 5") || err.contains("out of range"),
        "Expected arity error message, got: {}",
        err
    );
}

/// Phase 116: Slot pipe parse error — |1> is rejected at parse time.
#[test]
fn e2e_slot_pipe_parse_error_slot_1() {
    let source = "fn main() do\n  let x = 5 |1> println\nend\n";
    let err = compile_expect_error(source);
    assert!(
        err.contains("|>") || err.contains("first argument") || err.contains("error"),
        "Expected parse error for |1>, got: {}",
        err
    );
}

// ── Phase 119: Regular Expressions ────────────────────────────────────

/// Phase 119: Regex literal ~r/pattern/ and ~r/pattern/flags (REGEX-01).
#[test]
fn e2e_regex_literal() {
    let source = read_fixture("regex_literal.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "digit found\ncase insensitive match\n");
}

/// Phase 119: Regex.compile(str) returns Ok for valid, Err for invalid (REGEX-02).
#[test]
fn e2e_regex_compile() {
    let source = read_fixture("regex_compile.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "compiled ok\ngot error\n");
}

/// Phase 119: Regex.is_match(rx, str) returns Bool (REGEX-03).
#[test]
fn e2e_regex_match() {
    let source = read_fixture("regex_match.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "matched\nno match\n");
}

/// Phase 119: Regex.captures(rx, str) returns Option<List<String>> (REGEX-04).
#[test]
fn e2e_regex_captures() {
    let source = read_fixture("regex_captures.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "hello world\nhello\nworld\nno match\n");
}

/// Regression: an Option<String> returned by a helper must preserve its tag
/// when one branch forwards an Option allocated by the runtime.
#[test]
fn e2e_option_string_helper_preserves_runtime_value() {
    let source = read_fixture("option_string_helper_return.mpl");
    let output = compile_and_run(&source);
    assert_eq!(
        output,
        "authorization\nAuthorization\nmissing\nlocal\nAuthorization\n"
    );
}

/// Phase 119: Regex.replace(rx, str, replacement) -> String (REGEX-05).
#[test]
fn e2e_regex_replace() {
    let source = read_fixture("regex_replace_split.mpl");
    let output = compile_and_run(&source);
    assert!(
        output.starts_with("fooNbarN\n"),
        "Expected replace output, got: {}",
        output
    );
}

/// Phase 119: Regex.split(rx, str) -> List<String> (REGEX-06).
#[test]
fn e2e_regex_split() {
    let source = read_fixture("regex_replace_split.mpl");
    let output = compile_and_run(&source);
    let lines: Vec<&str> = output.lines().collect();
    assert!(lines.len() >= 5, "Expected 5 lines, got: {}", output);
    assert_eq!(lines[1], "a");
    assert_eq!(lines[2], "b");
    assert_eq!(lines[3], "c");
    assert_eq!(lines[4], "d");
}

// ── Phase 127: Type Aliases (ALIAS-01, ALIAS-02) ─────────────────────

/// Phase 127: type alias used in fn signatures and let bindings (ALIAS-01, ALIAS-02).
///
/// Verifies that:
/// - `type Url = String` and `type UserId = Int` parse and register correctly
/// - Aliases can be used as parameter types, return types, and let binding annotations
/// - Values flow transparently through alias boundaries (no explicit coercion)
#[test]
fn e2e_type_alias_basic() {
    let source = read_fixture("type_alias_basic.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "https://example.com\n42\n");
}

/// Phase 127: pub type alias is usable across module boundaries (ALIAS-03).
///
/// Verifies the full cross-module pub type pipeline:
/// - `collect_exports` picks up `pub type UserId = Int` and `pub type Email = String`
/// - `build_import_context` copies type_aliases into ModuleExports
/// - `infer_with_imports` pre-registers the imported aliases into TypeRegistry
/// - The importing module can use `Types.UserId` and `Types.Email` in fn signatures
///   and let bindings without explicit conversion (aliases are transparent).
#[test]
fn e2e_type_alias_pub() {
    let output = compile_multifile_and_run(&[
        (
            "types.mpl",
            r#"
pub type UserId = Int
pub type Email = String
"#,
        ),
        (
            "main.mpl",
            r#"
import Types

fn greet(id :: Types.UserId, email :: Types.Email) -> Types.Email do
  email
end

fn main() do
  let id :: Types.UserId = 42
  let addr :: Types.Email = "user@example.com"
  println(greet(id, addr))
end
"#,
        ),
    ]);
    assert_eq!(output, "user@example.com\n");
}

/// Phase 127: private type alias (no `pub`) is NOT accessible in importing module (ALIAS-03 negative).
///
/// Verifies that a type alias without `pub` is not exported and causes a compile error
/// when an importing module tries to reference it.
#[test]
fn e2e_type_alias_private_not_exported() {
    let error = compile_multifile_expect_error(&[
        (
            "internals.mpl",
            r#"
type InternalId = Int
"#,
        ),
        (
            "main.mpl",
            r#"
import Internals

fn main() do
  let x :: Internals.InternalId = 42
  println(x)
end
"#,
        ),
    ]);
    assert!(
        !error.is_empty(),
        "Expected compilation error when using private type alias from another module"
    );
}

// ── Phase 135: Crypto stdlib tests ──────────────────────────────────────

/// Crypto V2: `sha256_hex` preserves the NIST presentation vector.
#[test]
fn e2e_crypto_sha256() {
    let source = read_fixture("crypto_sha256.mpl");
    let output = compile_and_run(&source);
    assert_eq!(
        output,
        "2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824\n"
    );
}

/// Crypto V2: `sha512_hex` preserves the NIST presentation vector.
#[test]
fn e2e_crypto_sha512() {
    let source = read_fixture("crypto_sha512.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "9b71d224bd62f3785d96d46ad3ea3d73319bfbc2890caadae2dff72519673ca72323c3d99ba5c11d7c7acc6e14b8c5da0c4663475c2e5c3adef46f73bcdec043\n");
}

/// Crypto V2 HMAC returns an owned secret from Mesh code; the non-colliding
/// legacy SHA-512 presentation helper remains available during migration.
#[test]
fn e2e_crypto_hmac() {
    let source = read_fixture("crypto_hmac.mpl");
    let output = compile_and_run(&source);
    let lines: Vec<&str> = output.lines().collect();
    assert_eq!(lines[0], "ok");
    assert_eq!(lines[1], "164b7a7bfcf819e2e395fbe73b56e0a387bd64222e831fd610270cd7ea2505549758bf75c05a994a6d034f65f8f0e6fdcaeab1a34d4a6b4b636e070a38bce737");
}

#[test]
fn e2e_crypto_rejects_string_secret_comparison() {
    let error = compile_expect_error(
        r#"
fn main() do
  println("${Crypto.secure_compare("secret", "secret")}")
end
"#,
    );
    assert!(error.contains("Crypto"), "unexpected error: {error}");
}

/// Phase 135: Crypto.uuid4() returns a well-formed 36-character UUID v4 string (CRYPTO-06).
#[test]
fn e2e_crypto_uuid4() {
    let source = read_fixture("crypto_uuid4.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "36\n");
}

// ── Phase 135: Base64 stdlib tests ──────────────────────────────────────

/// Phase 135: Base64.encode returns standard-alphabet padded string (ENCODE-01).
#[test]
fn e2e_base64_encode() {
    let source = read_fixture("base64_encode_decode.mpl");
    let output = compile_and_run(&source);
    assert!(
        output.starts_with("aGVsbG8=\n"),
        "Expected aGVsbG8= as first line, got: {}",
        output
    );
}

/// Phase 135: Base64.decode round-trips and returns Err on invalid input (ENCODE-02).
#[test]
fn e2e_base64_encode_decode() {
    let source = read_fixture("base64_encode_decode.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "aGVsbG8=\nhello\ninvalid base64\n");
}

/// Phase 135: Base64.encode_url and Base64.decode_url use URL-safe alphabet without padding (ENCODE-03, ENCODE-04).
#[test]
fn e2e_base64_url_encode_decode() {
    let source = read_fixture("base64_url_encode_decode.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "aGVsbG8\nhello\n");
}

// ── Phase 135: Hex stdlib tests ──────────────────────────────────────────

/// Phase 135: Hex.encode returns lowercase hex; Hex.decode is case-insensitive and rejects invalid input (ENCODE-05, ENCODE-06).
#[test]
fn e2e_hex_encode_decode() {
    let source = read_fixture("hex_encode_decode.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "6869\nhi\nhi\ninvalid hex\n");
}

/// Phase 135: Hex.encode produces lowercase output — no uppercase letters (ENCODE-05).
#[test]
fn e2e_hex_encode_lowercase() {
    let source = read_fixture("hex_encode_decode.mpl");
    let output = compile_and_run(&source);
    let first_line = output.lines().next().unwrap_or("");
    assert_eq!(
        first_line,
        first_line.to_lowercase(),
        "Hex.encode must produce lowercase output"
    );
    assert_eq!(first_line, "6869");
}

/// MESH-BYTES-001: binary data is opaque, bounds-checked, and codec-complete.
#[test]
fn e2e_bytes_operations() {
    let source = read_fixture("bytes_operations.mpl");
    let output = compile_and_run(&source);
    assert_eq!(
        output,
        "0\nfalse\n3\n255\nbyte index out of bounds\n0041\ninvalid utf-8\n/wBB\nHello World\ntrue\n305419896\nffffffffffffffff\n001234ff\n4\n255\ninvalid-byte\nababab\ninvalid-byte\n4660\n13330\n305419896\n2018915346\n1311768467463790320\n17356517385562371090\nread-error\n1234\n12345678\nffffffffffffffff\nwrite-error\n"
    );
}

#[test]
fn e2e_utf8_byte_length() {
    let project = tempfile::tempdir().unwrap();
    std::fs::write(
        project.path().join("main.mpl"),
        r##"
fn text() -> String do
  println("text")
  "é🙂é\0"
end

fn byte_count() -> Int do
  Bytes.length(Bytes.from_utf8(text()))
end

fn main() do
  println("#{byte_count()} #{String.length("é🙂é\0")}")
  let from_utf8 = fn(_ :: String) do Bytes.empty() end
  println("#{Bytes.length(from_utf8("é🙂"))}")
  let encode = Bytes.from_utf8
  let measure = Bytes.length
  println("#{measure(encode("é🙂"))}")
end
"##,
    )
    .unwrap();
    let compiler = find_meshc();
    for level in ["0", "1", "2"] {
        let binary = project
            .path()
            .join(format!("utf8-length-{level}"))
            .with_extension(std::env::consts::EXE_EXTENSION);
        let build = Command::new(&compiler)
            .arg("build")
            .arg(project.path())
            .args(["--opt-level", level, "--emit-llvm", "-o"])
            .arg(&binary)
            .output()
            .unwrap();
        assert!(
            build.status.success(),
            "{}",
            artifacts::command_output_text(&build)
        );
        let run = Command::new(&binary).output().unwrap();
        assert!(
            run.status.success(),
            "{}",
            artifacts::command_output_text(&run)
        );
        assert_eq!(String::from_utf8_lossy(&run.stdout), "text\n10 5\n0\n6\n");

        let ir = std::fs::read_to_string(binary.with_extension("ll")).unwrap();
        let body = ir
            .split_once(" @Main__byte_count(")
            .unwrap()
            .1
            .split_once("\n}")
            .unwrap()
            .0;
        for symbol in ["@mesh_bytes_from_utf8(", "@mesh_bytes_length("] {
            assert_eq!(
                body.contains(symbol),
                !cfg!(target_pointer_width = "64"),
                "{body}"
            );
        }
    }
}

#[test]
fn e2e_bytes_errors_are_nominal() {
    let error = compile_expect_error(
        r#"
fn accepts_text_error(value :: Result<Bytes, String>) do
  nil
end

fn main() do
  accepts_text_error(Bytes.repeat(1, 1))
end
"#,
    );
    assert!(error.contains("BytesError"), "unexpected error: {error}");
    assert!(error.contains("String"), "unexpected error: {error}");
}

/// `Bytes` never crosses a UTF-8 boundary without an explicit conversion.
#[test]
fn e2e_bytes_do_not_implicitly_convert_to_string() {
    let error = compile_expect_error(
        r#"
fn accepts_string(value :: String) do
  println(value)
end

fn main() do
  case Bytes.from_hex("ff") do
    Ok(bytes) -> accepts_string(bytes)
    Err(error) -> println(error)
  end
end
"#,
    );
    assert!(
        error.contains("expected `String`, found `Bytes`"),
        "expected the Bytes/String boundary to fail type checking, got:\n{error}"
    );
}

/// MESH-NUM-001: opaque wide integers parse and calculate only through checked APIs.
#[test]
fn e2e_wide_integer_operations() {
    let source = read_fixture("wide_integer_operations.mpl");
    let output = compile_and_run(&source);
    assert_eq!(
        output,
        "18446744073709551615\n7\nu64 addition overflow\nu64 does not fit Int\n340282366920938463463374607431768211455\nu128 subtraction overflow\n-1\n1234567890\nu128 division by zero\n-170141183460469231731687303715884105728\n-42\ni128 addition overflow\n-42\n"
    );
}

#[test]
fn e2e_json_structured_access() {
    let source = read_fixture("json_structured_access.mpl");
    let output = compile_and_run(&source);
    assert_eq!(
        output,
        "2\nsecond\ntrue\n7\n1.5\ntrue\nmissing field: missing\n{\"value\":18446744073709551615}\ndone\n"
    );
}

/// Wide integers require an explicit checked conversion before entering `Int`.
#[test]
fn e2e_wide_integer_does_not_implicitly_convert_to_int() {
    let error = compile_expect_error(
        r##"
fn accepts_int(value :: Int) do
  println("#{value}")
end

fn main() do
  case U64.parse("42") do
    Ok(value) -> accepts_int(value)
    Err(error) -> println(error)
  end
end
"##,
    );
    assert!(
        error.contains("expected `Int`, found `U64`"),
        "expected the U64/Int boundary to fail type checking, got:\n{error}"
    );
}

/// Wide integers compare and show by the number they hold, in a struct's
/// derived `==` and inside an Option or a list too: they had no `==` or
/// `<`, and a derived `==` over a U64 field compared the boxes the two
/// values live in, so equal amounts built apart were unequal.
#[test]
fn e2e_wide_integers_compare_by_value() {
    let output = compile_and_run(
        r##"
struct Holder do
  amount :: U64
  reserve :: Option<U64>
end

fn u(text :: String) -> U64 do
  case U64.parse(text) do
    Ok(v) -> v
    Err(_) -> u("0")
  end
end

fn main() do
  let a = u("18446744073709551615")
  let b = u("18446744073709551615")
  let c = u("7")
  println("#{a == b} #{a != c} #{c < a} #{a > c} #{a <= b}")
  println("#{a} #{inspect(c)} #{Some(c) == Some(u("7"))} #{[a, c] == [b, u("7")]}")
  let h1 = Holder { amount: a, reserve: Some(c) }
  let h2 = Holder { amount: b, reserve: Some(u("7")) }
  println("#{h1 == h2}")
  case (I128.parse("-5"), U128.parse("5")) do
    (Ok(n), Ok(p)) -> println("#{n < (I128.parse("0") |> Result.unwrap_or(n))} #{p == p}")
    _ -> println("parse failed")
  end
end
"##,
    );
    assert_eq!(
        output,
        "true true true true true\n18446744073709551615 7 true true\ntrue\ntrue true\n"
    );
}

// ── Phase 136: DateTime stdlib tests ─────────────────────────────────────────

/// Phase 136: DateTime.utc_now() returns a plausible UTC timestamp (DTIME-01).
/// Verifies the current time is after Nov 2023 epoch.
#[test]
fn e2e_datetime_utc_now() {
    let source = read_fixture("datetime_utc_now.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "true\n");
}

/// Phase 136: DateTime.from_iso8601 / to_iso8601 round-trip with UTC normalization (DTIME-02, DTIME-03).
/// Verifies: UTC input round-trips, +05:30 offset normalizes to UTC, naive string returns Err.
#[test]
fn e2e_datetime_iso8601_roundtrip() {
    let source = read_fixture("datetime_iso8601_roundtrip.mpl");
    let output = compile_and_run(&source);
    assert_eq!(
        output,
        "2024-01-15T10:30:00.000Z\n2024-01-15T05:00:00.000Z\ninvalid ISO 8601 datetime\n"
    );
}

/// Phase 136: DateTime.from_unix_ms / to_unix_ms round-trip (DTIME-04, DTIME-05).
/// Uses known epoch 1705312200000 ms = 2024-01-15T09:50:00.000Z
#[test]
fn e2e_datetime_unix_ms() {
    let source = read_fixture("datetime_unix_ms.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "1705312200000\n2024-01-15T09:50:00.000Z\n");
}

/// Phase 136: DateTime.from_unix_secs / to_unix_secs round-trip (DTIME-04, DTIME-05).
/// Uses known epoch 1705312200 secs = 2024-01-15T09:50:00Z
#[test]
fn e2e_datetime_unix_secs() {
    let source = read_fixture("datetime_unix_secs.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "1705312200\n");
}

/// Phase 136: DateTime.add and DateTime.diff arithmetic (DTIME-06, DTIME-07).
/// Verifies: add 7 days returns 7.0 diff, add -1 hour returns 1.0 diff.
#[test]
fn e2e_datetime_add_diff() {
    let source = read_fixture("datetime_add_diff.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "7.0\n1.0\n");
}

/// Phase 136: DateTime.is_before and DateTime.is_after comparisons (DTIME-08).
#[test]
fn e2e_datetime_compare() {
    let source = read_fixture("datetime_compare.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "true\nfalse\nfalse\ntrue\n");
}

/// MESH-FIN-001: Checked.mul_div uses a wide intermediate and explicit rounding.
#[test]
fn e2e_checked_mul_div() {
    let source = read_fixture("checked_mul_div.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "8\n42\n-2\n-42\n-4\n42\n1236\n");
}

/// MESH-TIME-001: monotonic elapsed time and checked duration construction.
#[test]
fn e2e_monotonic_duration() {
    let source = read_fixture("monotonic_duration.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "true\ntrue\n");
}

/// MESH-ACTOR-001: channels enforce item and byte bounds without blocking producers.
#[test]
fn e2e_bounded_channel() {
    let source = read_fixture("bounded_channel.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "1\n8\n2\n30\nchannel full\n2\n16\n1\n");
}

/// A channel carries any one type. What a value references is copied out
/// of the sender's heap as it is sent: the producer exits before anything is
/// received. With one scheduler worker, the producer only runs if the
/// consumer's wait on an empty channel yields that worker.
#[test]
fn e2e_channels_carry_any_type_and_waits_yield() {
    let source = r##"
struct Job do
  name :: String
  tags :: List<String>
end

fn describe(job :: Job) -> String do
  "${job.name}: ${String.join(job.tags, ",")}"
end

actor producer(jobs :: Channel<Job>, names :: Channel<String>) do
  let _ = Channel.try_send(jobs, Job { name: "job-${40 + 2}", tags: ["x-${1}", "y-${2}"] })
  let _ = Channel.try_send(names, "name-${6 * 7}")
  0
end

actor consumer(jobs :: Channel<Job>, results :: Channel<String>) do
  let reply = case Channel.recv(jobs, 5_000_000_000) do
    Ok(job) -> describe(job)
    Err(error) -> error
  end
  let _ = Channel.try_send(results, reply)
  0
end

fn run() -> Int!String do
  let jobs = Channel.bounded(4, :reject_newest)?
  let names = Channel.bounded(4, :reject_newest)?
  let results = Channel.bounded(4, :reject_newest)?
  spawn(consumer, jobs, results)
  Timer.sleep(20)
  spawn(producer, jobs, names)
  println(Channel.recv(results, 5_000_000_000)?)
  let name = Channel.recv(names, 5_000_000_000)?
  println(name)
  let texts = Channel.bounded(2, :drop_oldest)?
  let _ = Channel.try_send(texts, "text ${name}")?
  println("${Channel.byte_depth(texts) > 8}")
  println(Channel.recv(texts, 0)?)

  let floats = Channel.bounded(2, :drop_oldest)?
  let _ = Channel.try_send(floats, 2.5)?
  println("${Channel.recv(floats, 0)?}")
  let options = Channel.bounded(2, :drop_oldest)?
  let _ = Channel.try_send(options, Some(3))?
  let _ = Channel.try_send(options, None)?
  let first = Channel.recv(options, 0)?
  let second = Channel.recv(options, 0)?
  println("${first} ${second}")
  let pairs = Channel.bounded(2, :drop_oldest)?
  let _ = Channel.try_send(pairs, (1, "one"))?
  let (n, word) = Channel.recv(pairs, 0)?
  println("${n} ${word}")

  let small = Channel.bounded_bytes(4, 8, :reject_newest)?
  # A literal is static data, which is shared rather than copied; a string
  # built at run time is copied, and counts.
  let _ = Channel.try_send(small, "static")?
  let _ = Channel.recv(small, 0)?
  case Channel.try_send(small, "built at ${n} run time") do
    Ok(_) -> println("accepted")
    Err(error) -> println(error)
  end
  println("${Channel.dropped(small)}")
  Ok(0)
end

fn main() do
  case run() do
    Ok(_) -> println("done")
    Err(error) -> println("error: ${error}")
  end
end
"##;
    let output = compile_and_run_with_env(source, &[("MESH_SCHEDULER_MIN_WORKERS", "1")]);
    assert_eq!(
        output,
        "job-42: x-1,y-2\nname-42\ntrue\ntext name-42\n2.5\nSome(3) None\n1 one\nvalue exceeds the channel byte capacity\n1\ndone\n"
    );
}

/// MESH-TEST-002: seeded random sequences are stable and explicitly stateful.
#[test]
fn e2e_deterministic_random() {
    let source = read_fixture("deterministic_random.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "1\ntrue\ntrue\ntrue\ntrue true\n");
}

/// MESH-TEST-002: Random draws from any range of Ints, the whole range
/// included; an empty range is the program's error, a Mesh panic, not an
/// abort of the process.
#[test]
fn e2e_random_range_limits() {
    let source = r#"
fn main() do
  let lowest = -9223372036854775807 - 1
  let (_, value) = Random.next_int(Random.seed(7), lowest, 9223372036854775807)
  println("drawn ${value >= lowest}")
  let (_, empty) = Random.next_int(Random.seed(7), 5, 1)
  println("${empty}")
end
"#;
    let output = compile_and_run_output(source, &[]);
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert_eq!(output.status.code(), Some(101), "{stderr}");
    assert_eq!(String::from_utf8_lossy(&output.stdout), "drawn true\n");
    assert!(
        stderr.contains("Random.next_int: invalid range 5..1"),
        "{stderr}"
    );
    assert!(!stderr.contains("cannot unwind"), "{stderr}");
}

/// MESH-PROC-001: applications can poll and trigger the same graceful-shutdown flag.
#[test]
fn e2e_process_shutdown_signal() {
    let source = read_fixture("process_shutdown_signal.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "false\ntrue\n");
}

/// MESH-PROC-001: HTTP.serve returns after the process shutdown flag is set.
#[test]
fn e2e_http_graceful_shutdown() {
    let source = read_fixture("http_graceful_shutdown.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "stopped\n");
}

/// Phase 137: Http.build/header/timeout fluent builder compiles (HTTP-01, HTTP-02, HTTP-04).
/// Compile-only — no network access needed. The program builds a request and prints "built".
#[test]
fn e2e_http_builder_compiles() {
    let source = read_fixture("http_client_builder.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "built\n");
}

/// Phase 137: Http.stream compile check (HTTP-06).
/// Verifies Http.stream type-checks and compiles with a closure callback.
/// Http.stream returns an Int (cancel handle). Compile-only — runtime may fail
/// if network is unavailable, so we only assert compilation succeeds.
#[test]
fn e2e_http_stream_compiles() {
    let source = read_fixture("http_stream_compile.mpl");
    // Compile success is the goal — runtime may fail if network unavailable.
    let _ = compile_and_run(&source);
}

/// Phase 137: Http.client + Http.client_close compile and run (HTTP-07).
/// Creates a keep-alive client, prints "client_created", closes client.
/// No network request is made — only the Agent allocation is tested.
#[test]
fn e2e_http_client_keepalive_compiles() {
    let source = read_fixture("http_client_keepalive.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "client_created\n");
}

/// Phase 137: Http.cancel compile check.
/// Verifies Http.stream returns a cancel handle and Http.cancel accepts it.
/// Compile success + handle type-check is the goal. If network is available,
/// output will include "cancel_called".
#[test]
fn e2e_http_cancel_compiles() {
    let source = read_fixture("http_cancel_compile.mpl");
    // Network may be unavailable; compile success + handle type-check is the goal.
    let _ = compile_and_run(&source);
}

// ── Trailing-closure disambiguation in control-flow conditions ────────

/// Trailing closure fix: `if fn_call() do ... end` must treat `do` as the
/// block opener, not a trailing closure on the call.
#[test]
fn e2e_trailing_closure_if_fn_call_condition() {
    let source = r#"
fn is_big(n :: Int) -> Bool do
  n > 10
end

fn main() do
  if is_big(15) do
    println("big")
  else
    println("small")
  end
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "big\n");
}

/// Trailing closure fix: `while fn_call() do ... end` must treat `do` as
/// the block opener.
#[test]
fn e2e_trailing_closure_while_fn_call_condition() {
    let source = r#"
fn always_false() -> Bool do
  false
end

fn main() do
  while always_false() do
    println("never")
  end
  println("done")
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "done\n");
}

/// Trailing closure fix: `case fn_call() do ... end` must treat `do` as
/// the block opener.
#[test]
fn e2e_trailing_closure_case_fn_call_scrutinee() {
    let source = r#"
fn get_val() -> Int do
  42
end

fn main() do
  case get_val() do
    42 -> println("forty-two")
    _ -> println("other")
  end
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "forty-two\n");
}

/// Trailing closure fix: `for x in fn_call() do ... end` must treat `do`
/// as the block opener.
#[test]
fn e2e_trailing_closure_for_fn_call_iterable() {
    let source = r#"
fn get_list() -> List<Int> do
  [1, 2, 3]
end

fn main() do
  for item in get_list() do
    println("${item}")
  end
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "1\n2\n3\n");
}

/// Regression: trailing closures in expression-statement position must
/// still work. `test("name") do ... end` and `describe("name") do ... end`
/// use trailing closure syntax — verify they still parse and run correctly.
#[test]
fn e2e_trailing_closure_still_works() {
    // test("name") do ... end is a trailing-closure call parsed by meshc test.
    // This verifies the suppression flag doesn't break trailing closures.
    let temp_dir = tempfile::tempdir().expect("failed to create temp dir");
    std::fs::write(
        temp_dir.path().join("mesh.toml"),
        "[package]\nname = \"trailing-closure-test\"\nversion = \"0.1.0\"\n",
    )
    .expect("failed to write project manifest");
    std::fs::write(temp_dir.path().join("main.mpl"), "fn main() do\nend\n")
        .expect("failed to write project entrypoint");
    let test_file = temp_dir.path().join("trailing.test.mpl");
    std::fs::write(
        &test_file,
        r#"test("trailing closure parses") do
  assert(1 + 1 == 2)
end

describe("group") do
  test("nested trailing closure") do
    assert(true)
  end
end
"#,
    )
    .expect("failed to write test file");

    let meshc = find_meshc();
    let output = std::process::Command::new(&meshc)
        .args(["test", test_file.to_str().unwrap()])
        .output()
        .expect("failed to invoke meshc test");

    assert!(
        output.status.success(),
        "meshc test failed for trailing closure regression:\nstdout: {}\nstderr: {}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );

    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(
        stdout.contains("2 passed"),
        "expected 2 passing tests, got: {}",
        stdout
    );
}

// ---------------------------------------------------------------------------
// Else-if chain value correctness
// ---------------------------------------------------------------------------

/// else if chain returning Int values — verify correct branch is picked.
#[test]
fn e2e_else_if_chain_int_value() {
    let source = r#"
fn main() do
  let x = 2
  let result = if x == 1 do
    10
  else if x == 2 do
    20
  else
    30
  end
  println("${result}")
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "20\n");
}

/// else if chain returning String values — must not crash (previously caused
/// misaligned pointer dereference when inner if type was lost).
#[test]
fn e2e_else_if_chain_string_value() {
    let source = r#"
fn main() do
  let x = 3
  let result = if x == 1 do
    "one"
  else if x == 2 do
    "two"
  else
    "other"
  end
  println(result)
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "other\n");
}

/// else if chain returning Bool values.
#[test]
fn e2e_else_if_chain_bool_value() {
    let source = r#"
fn main() do
  let x = 1
  let result = if x == 1 do
    true
  else if x == 2 do
    false
  else
    false
  end
  if result do
    println("yes")
  else
    println("no")
  end
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "yes\n");
}

/// 3-level else if chain (if / else if / else if / else).
#[test]
fn e2e_else_if_three_level_chain() {
    let source = r#"
fn main() do
  let x = 3
  let result = if x == 1 do
    "first"
  else if x == 2 do
    "second"
  else if x == 3 do
    "third"
  else
    "other"
  end
  println(result)
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "third\n");
}

/// else if result used directly in a let binding and further computation.
#[test]
fn e2e_else_if_let_binding() {
    let source = r#"
fn main() do
  let x = 5
  let label = if x < 3 do
    "small"
  else if x < 10 do
    "medium"
  else
    "large"
  end
  println("size: ${label}")
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "size: medium\n");
}

// ── Multiline function call type resolution ─────────────────────────────

/// Multiline function call with Int return — args on separate lines should
/// resolve to the correct return type, not `()`.
#[test]
fn e2e_multiline_call_int_return() {
    let source = r#"
fn add(a :: Int, b :: Int) -> Int do
  a + b
end

fn main() do
  let result = add(
    1,
    2
  )
  println("${result}")
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "3\n");
}

/// Multiline function call with String return — verifies no misaligned pointer
/// crash when the return type spans multiple lines.
#[test]
fn e2e_multiline_call_string_return() {
    let source = r#"
fn greet(greeting :: String, name :: String) -> String do
  greeting <> " " <> name
end

fn main() do
  let msg = greet(
    "hello",
    "world"
  )
  println(msg)
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "hello world\n");
}

/// Multiline function call with 3+ args on separate lines.
#[test]
fn e2e_multiline_call_three_args() {
    let source = r#"
fn sum3(a :: Int, b :: Int, c :: Int) -> Int do
  a + b + c
end

fn main() do
  let result = sum3(
    10,
    20,
    30
  )
  println("${result}")
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "60\n");
}

/// Mixed single-line and multiline calls in the same function — both must
/// produce correct results.
#[test]
fn e2e_multiline_call_mixed_single_and_multi() {
    let source = r#"
fn add(a :: Int, b :: Int) -> Int do
  a + b
end

fn main() do
  let x = add(1, 2)
  let y = add(
    10,
    20
  )
  println("${x}")
  println("${y}")
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "3\n30\n");
}

/// Multiline call used in a let binding — the bound variable must have
/// the correct type for subsequent use.
#[test]
fn e2e_multiline_call_let_binding() {
    let source = r#"
fn multiply(a :: Int, b :: Int) -> Int do
  a * b
end

fn main() do
  let product = multiply(
    6,
    7
  )
  let doubled = product * 2
  println("${doubled}")
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "84\n");
}

// ── Phase 42: Parenthesized Imports & Trailing Comma Coverage ─────────

/// Parenthesized import on a single line: `from Math import (add, mul)`
#[test]
fn e2e_multiline_import_paren_basic() {
    let output = compile_multifile_and_run(&[
        (
            "math.mpl",
            r#"
pub fn add(a :: Int, b :: Int) -> Int do
  a + b
end

pub fn mul(a :: Int, b :: Int) -> Int do
  a * b
end
"#,
        ),
        (
            "main.mpl",
            r#"
from Math import (add, mul)

fn main() do
  let sum = add(2, 3)
  let product = mul(4, 5)
  println("${sum}")
  println("${product}")
end
"#,
        ),
    ]);
    assert_eq!(output, "5\n20\n");
}

/// Parenthesized import with names on separate lines.
#[test]
fn e2e_multiline_import_paren_multiline() {
    let output = compile_multifile_and_run(&[
        (
            "math.mpl",
            r#"
pub fn add(a :: Int, b :: Int) -> Int do
  a + b
end

pub fn mul(a :: Int, b :: Int) -> Int do
  a * b
end
"#,
        ),
        (
            "main.mpl",
            "from Math import (\n  add,\n  mul\n)\n\nfn main() do\n  let sum = add(10, 20)\n  let product = mul(3, 7)\n  println(\"${sum}\")\n  println(\"${product}\")\nend\n",
        ),
    ]);
    assert_eq!(output, "30\n21\n");
}

/// Parenthesized import with trailing comma.
#[test]
fn e2e_multiline_import_paren_trailing_comma() {
    let output = compile_multifile_and_run(&[
        (
            "math.mpl",
            r#"
pub fn add(a :: Int, b :: Int) -> Int do
  a + b
end

pub fn mul(a :: Int, b :: Int) -> Int do
  a * b
end
"#,
        ),
        (
            "main.mpl",
            "from Math import (\n  add,\n  mul,\n)\n\nfn main() do\n  println(\"${add(1, 2)}\")\n  println(\"${mul(3, 4)}\")\nend\n",
        ),
    ]);
    assert_eq!(output, "3\n12\n");
}

/// Trailing comma in function call args — single line.
#[test]
fn e2e_trailing_comma_call_single_line() {
    let source = r#"
fn add(a :: Int, b :: Int) -> Int do
  a + b
end

fn main() do
  let result = add(1, 2,)
  println("${result}")
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "3\n");
}

/// Trailing comma in function call args — multiline.
#[test]
fn e2e_trailing_comma_call_multiline() {
    let source = r#"
fn add(a :: Int, b :: Int) -> Int do
  a + b
end

fn main() do
  let result = add(
    10,
    20,
  )
  println("${result}")
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "30\n");
}

// ── R025 gap coverage: bare expressions, not-fn-call conditions, struct update in services ──

/// Bare expression statements: multiple side-effect calls without `let _ =`.
/// Proves that bare `println()` and bare helper function calls compile and execute.
#[test]
fn e2e_bare_expression_side_effects() {
    let source = r#"
fn greet(name :: String) -> String do
  "hello " <> name
end

fn main() do
  println("first")
  println("second")
  println(greet("world"))
  println("done")
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "first\nsecond\nhello world\ndone\n");
}

/// Bare expressions inside nested block contexts: if branches, else branches, function bodies.
#[test]
fn e2e_bare_expression_in_block() {
    let source = r#"
fn side_effect(label :: String) -> String do
  label <> " ran"
end

fn main() do
  # bare expression in top-level function body
  println("top")

  # bare expression inside if/else branches
  if true do
    println("if-branch")
    println(side_effect("if"))
  else
    println("else-branch")
  end

  # bare expressions in an else branch
  if false do
    println("skip")
  else
    println("else")
    println(side_effect("else"))
  end
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "top\nif-branch\nif ran\nelse\nelse ran\n");
}

/// `not fn_call()` in an `if` condition: unary `not` preceding a function call.
#[test]
fn e2e_not_fn_call_if_condition() {
    let source = r#"
fn is_empty(n :: Int) -> Bool do
  n == 0
end

fn main() do
  let count = 5
  if not is_empty(count) do
    println("not empty")
  else
    println("empty")
  end

  if not is_empty(0) do
    println("not empty")
  else
    println("empty")
  end
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "not empty\nempty\n");
}

/// `not fn_call()` in a `while` condition: negated function call controls loop entry.
/// Since Mesh has no mutable variables, we test both the true and false branches
/// of `while not fn_call()` to prove parsing and execution correctness.
#[test]
fn e2e_not_fn_call_while_condition() {
    let source = r#"
fn always_true() -> Bool do
  true
end

fn always_false() -> Bool do
  false
end

fn main() do
  # while not always_true() => condition is false, body never executes
  while not always_true() do
    println("should not print")
  end
  println("skipped")

  # while not always_false() => condition is true, body runs once then breaks
  while not always_false() do
    println("entered")
    break
  end
  println("done")
end
"#;
    let output = compile_and_run(source);
    assert_eq!(output, "skipped\nentered\ndone\n");
}

/// Struct update `%{state | field: expr}` inside service call/cast handlers.
/// The service maintains a CounterState struct and updates it with struct update syntax
/// in both call and cast handlers, proving the pattern works inside the (next_state, value) tuple.
#[test]
fn e2e_struct_update_in_service_call() {
    let output = compile_multifile_and_run(&[
        (
            "counter.mpl",
            r#"
struct CounterState do
  count :: Int
  label :: String
end

service Counter do
  fn init(label :: String) -> CounterState do
    CounterState { count: 0, label: label }
  end

  call Increment() :: Int do |state|
    let next = %{state | count: state.count + 1}
    (next, next.count)
  end

  call GetCount() :: Int do |state|
    (state, state.count)
  end

  cast SetLabel(new_label :: String) do |state|
    %{state | label: new_label}
  end

  call GetLabel() :: String do |state|
    (state, state.label)
  end
end
"#,
        ),
        (
            "main.mpl",
            r#"
from Counter import Counter

fn main() do
  let pid = Counter.start("initial")
  let c1 = Counter.increment(pid)
  println("${c1}")
  let c2 = Counter.increment(pid)
  println("${c2}")
  let c3 = Counter.get_count(pid)
  println("${c3}")
  Counter.set_label(pid, "updated")
  let lbl = Counter.get_label(pid)
  println(lbl)
end
"#,
        ),
    ]);
    assert_eq!(output, "1\n2\n2\nupdated\n");
}

// ── Compiler boundary regressions ──────────────────────────────────────

const CROSS_MODULE_FROM_JSON_MAIN: &str = r##"
from Models import Scout

fn main() do
  let json_str = """{"name":"Scout","rating":7}"""
  let result = Scout.from_json(json_str)
  case result do
    Ok( scout) -> println("#{scout.name} #{scout.rating}")
    Err( e) -> println("Error: #{e}")
  end
end
"##;

const CROSS_MODULE_FROM_JSON_MODELS: &str = r#"
pub struct Scout do
  name :: String
  rating :: Int
end deriving(Json)
"#;

const SERVICE_CALL_CASE_MAIN: &str = r#"
service Toggle do
  fn init() -> Int do
    0
  end

  call Decide(flag :: Bool) :: String do |state|
    let label = case flag do
      true -> "yes"
      false -> "no"
    end
    (state, label)
  end
end

fn main() do
  let pid = Toggle.start()
  println(Toggle.decide(pid, true))
  println(Toggle.decide(pid, false))
end
"#;

const CAST_IF_ELSE_MAIN: &str = r##"
service Switch do
  fn init() -> Int do
    0
  end

  cast Set(flag :: Bool) do|_state|
    if flag do
      1
    else
      2
    end
  end

  call Get() :: Int do |state|
    (state, state)
  end
end

fn main() do
  let pid = Switch.start()
  Switch.set(pid, true)
  println("#{Switch.get(pid)}")
  Switch.set(pid, false)
  println("#{Switch.get(pid)}")
end
"##;

const INFERRED_IDENTITY_MAIN: &str = r##"
from Utils import identity

fn main() do
  println("#{identity(7)}")
  println(identity("poly"))
end
"##;

const INFERRED_IDENTITY_UTILS: &str = r#"
pub fn identity(x) do
  x
end
"#;

const NESTED_AND_MAIN: &str = r#"
fn main() do
  let a = true
  let b = true
  let c = false
  if a && (b && c) do
    println("yes")
  else
    println("no")
  end
end
"#;

const TIMER_SERVICE_CAST_MAIN: &str = r#"
service Counter do
  fn init(start :: Int) -> Int do
    start
  end

  cast Add(n :: Int) do |count|
    count + n
  end

  call Get() :: Int do |count|
    (count, count)
  end
end

fn main() do
  let counter = Counter.start(0)
  let step = 5
  Timer.apply_after(60, fn () -> Counter.add(counter, step) end)
  Timer.apply_after(10, fn () -> Counter.add(counter, 100) end)
  println("${Counter.get(counter)}")
  Timer.sleep(400)
  println("${Counter.get(counter)}")
end
"#;

#[test]
fn e2e_imported_size_shadows_builtin_name() {
    let output = compile_multifile_and_run(&[
        (
            "helpers.mpl",
            r#"
pub fn size(value :: Int) -> Int do
  value + 1
end
"#,
        ),
        (
            "main.mpl",
            r##"
from Helpers import size

fn main() do
  println("#{size(41)}")
end
"##,
        ),
    ]);
    assert_eq!(output, "42\n");
}

/// Proves cross-module `from_json` lowering remains supported.
#[test]
fn e2e_cross_module_from_json() {
    let output = compile_multifile_and_run(&[
        ("main.mpl", CROSS_MODULE_FROM_JSON_MAIN),
        ("models.mpl", CROSS_MODULE_FROM_JSON_MODELS),
    ]);
    assert_eq!(output, "Scout 7\n");
}

/// Proves service call bodies can contain inline `case` expressions.
#[test]
fn e2e_service_call_case_expression() {
    let output = compile_and_run(SERVICE_CALL_CASE_MAIN);
    assert_eq!(output, "yes\nno\n");
}

/// Proves cast handlers can contain inline `if` expressions.
#[test]
fn e2e_service_cast_if_else_expression() {
    let output = compile_and_run(CAST_IF_ELSE_MAIN);
    assert_eq!(output, "1\n2\n");
}

/// Proves `deriving(Json)` wrapper structs can decode nested JSON array payloads
/// through a `List < ... >` field.
#[test]
fn e2e_nested_wrapper_list_from_json() {
    let output = compile_and_run(
        r##"
struct BulkEvent do
  id :: String
  count :: Int
end deriving(Json)

struct BulkEnvelope do
  source :: String
  events :: List < BulkEvent >
end deriving(Json)

fn main() do
  let json_str = """{"source":"sdk","events":[{"id":"evt-1","count":2},{"id":"evt-2","count":5}]}"""
  let result = BulkEnvelope.from_json(json_str)
  case result do
    Ok( payload) -> do
      let first = List.get(payload.events, 0)
      let second = List.get(payload.events, 1)
      println(payload.source)
      println("#{List.length(payload.events)}")
      println("#{first.id}:#{first.count}")
      println("#{second.id}:#{second.count}")
    end
    Err( e) -> println("Error: #{e}")
  end
end
"##,
    );
    assert_eq!(output, "sdk\n2\nevt-1:2\nevt-2:5\n");
}

/// Proves writer-style cast handlers can inline buffer append/capacity logic and
/// rebuild service state directly.
#[test]
fn e2e_inline_writer_cast_body() {
    let output = compile_and_run(
        r##"
struct WriterProbeState do
  buffer :: List < String >
  buffer_len :: Int
  batch_size :: Int
  max_buffer :: Int
end

service WriterProbe do
  fn init(batch_size :: Int, max_buffer :: Int) -> WriterProbeState do
    WriterProbeState {
      buffer : List.new(),
      buffer_len : 0,
      batch_size : batch_size,
      max_buffer : max_buffer
    }
  end

  cast Store(item :: String) do|state|
    let appended = List.append(state.buffer, item)
    let new_len = state.buffer_len + 1
    let buf = if new_len > state.max_buffer do
      List.drop(appended, new_len - state.max_buffer)
    else
      appended
    end
    let blen = if new_len > state.max_buffer do
      state.max_buffer
    else
      new_len
    end
    if blen >= state.batch_size do
      WriterProbeState {
        buffer : List.new(),
        buffer_len : 0,
        batch_size : state.batch_size,
        max_buffer : state.max_buffer
      }
    else
      WriterProbeState {
        buffer : buf,
        buffer_len : blen,
        batch_size : state.batch_size,
        max_buffer : state.max_buffer
      }
    end
  end

  call Snapshot() :: String do|state|
    let joined = String.join(state.buffer, ",")
    (state, "#{state.buffer_len}:#{joined}")
  end
end

fn main() do
  let capped = WriterProbe.start(99, 2)
  WriterProbe.store(capped, "one")
  println(WriterProbe.snapshot(capped))
  WriterProbe.store(capped, "two")
  println(WriterProbe.snapshot(capped))
  WriterProbe.store(capped, "three")
  println(WriterProbe.snapshot(capped))

  let flushing = WriterProbe.start(2, 5)
  WriterProbe.store(flushing, "alpha")
  println(WriterProbe.snapshot(flushing))
  WriterProbe.store(flushing, "beta")
  println(WriterProbe.snapshot(flushing))
end
"##,
    );
    assert_eq!(output, "1:one\n2:one,two\n2:two,three\n1:alpha\n0:\n");
}

// ── Inferred-export regression coverage ────────────────────────────────

/// Local inferred identity must keep its concrete call-site ABI through MIR lowering.
#[test]
fn e2e_inferred_local_identity() {
    let output = compile_and_run(
        r##"
pub fn identity(x) do
  x
end

fn main() do
  println("#{identity(7)}")
  println(identity("poly"))
end
"##,
    );
    assert_eq!(output, "7\npoly\n");
}

/// Imported inferred identity must keep its concrete call-site ABI through export + MIR lowering.
#[test]
fn e2e_inferred_cross_module_identity() {
    let output = compile_multifile_and_run(&[
        ("main.mpl", INFERRED_IDENTITY_MAIN),
        ("utils.mpl", INFERRED_IDENTITY_UTILS),
    ]);
    assert_eq!(output, "7\npoly\n");
}

// ── Known compiler-limit regressions ───────────────────────────────────

/// Nested short-circuit expressions must use the actual predecessor block.
#[test]
fn e2e_nested_and() {
    let output = compile_and_run(NESTED_AND_MAIN);
    assert_eq!(output, "no\n");
}

/// A timer reaches a service's `cast` handler. `Timer.send_after` cannot: it
/// delivers a plain message, and a service dispatches on a tag only its
/// generated functions know. `Timer.apply_after` runs a function after the
/// delay instead, and a function can cast. This used to be the frozen limit
/// `e2e_timer_service_cast_known_dispatch_limit`.
#[test]
fn e2e_timer_apply_after_reaches_a_service_cast() {
    let output = compile_and_run(TIMER_SERVICE_CAST_MAIN);
    assert_eq!(output, "0\n105\n");
}

/// Bare payload-bearing constructor in pattern position (no explicit binder).
/// `Ok` / `Err` without `(_)` must compile and match correctly -- sugar for `Ok(_)`.
#[test]
fn e2e_bare_payload_constructor_pattern() {
    let output = compile_and_run(
        r#"
fn main() do
  let r = Err("boom")
  case r do
    Ok -> println("ok")
    Err -> println("err")
  end
end
"#,
    );
    assert_eq!(output, "err\n");
}

/// Bare `Ok` with actual Ok value hits the Ok arm.
#[test]
fn e2e_bare_payload_constructor_ok_arm() {
    let output = compile_and_run(
        r#"
fn main() do
  let r = Ok(42)
  case r do
    Ok -> println("ok")
    Err -> println("err")
  end
end
"#,
    );
    assert_eq!(output, "ok\n");
}

/// Literal patterns must dereference boxed scalar payloads in generic sum types.
#[test]
fn e2e_result_literal_payload_pattern() {
    let output = compile_and_run(
        r#"
fn classify(value :: Int!String) -> String do
  case value do
    Ok(0) -> "zero"
    Ok(1) -> "one"
    Ok(_) -> "other"
    Err(_) -> "error"
  end
end

fn main() do
  println(classify(Ok(0)))
  println(classify(Ok(1)))
  println(classify(Ok(7)))
  println(classify(Err("boom")))
end
"#,
    );
    assert_eq!(output, "zero\none\nother\nerror\n");
}

/// User-defined sum types must box struct payloads just like generic Result.
#[test]
fn e2e_user_sum_struct_payload_roundtrip() {
    let output = compile_multifile_and_run(&[
        (
            "models.mpl",
            r#"
pub struct Position do
  quantity :: Int
  seed :: Int
end

pub fn load_position(quantity :: Int) -> Position!String do
  Ok(Position { quantity: quantity, seed: 42 })
end
"#,
        ),
        (
            "main.mpl",
            r#"
from Models import Position, load_position

type Portfolio do
  Idle
  Open(Position)
end

struct State do
  first :: Portfolio
  second :: Portfolio
  marker :: Int
end

fn open(quantity :: Int) -> Portfolio!String do
  let position = load_position(quantity) ?
  Ok(Open(position))
end

fn quantity(portfolio :: Portfolio) -> Int do
  case portfolio do
    Idle -> 0
    Open(position) -> position.quantity
  end
end

fn make_state() -> State!String do
  Ok(State {
    first: open(2467333333) ?,
    second: open(1234567890) ?,
    marker: 99
  })
end

fn main() do
  case make_state() do
    Ok(state) -> do
      println("${quantity(state.first)}")
      println("${quantity(state.second)}")
      println("${state.marker}")
    end
    Err(error) -> println(error)
  end
end
"#,
        ),
    ]);
    assert_eq!(output, "2467333333\n1234567890\n99\n");
}

/// `Process.exit(status)` ends the process with that status, and with 1 for
/// a status no process can have.
#[test]
fn e2e_process_exit_sets_the_native_status_code() {
    for (status, expected) in [(7, 7), (300, 1), (-2, 1)] {
        let source = format!("fn main() do\n  Process.exit({status})\nend\n");
        let output = compile_and_run_output(&source, &[]);
        assert_eq!(
            output.status.code(),
            Some(expected),
            "Process.exit({status})"
        );
    }
}

/// Derived and default traits of imported types work in the importer:
/// operators, `inspect`, `hash`, `Json.encode`, and qualified constructors.
#[test]
fn e2e_imported_types_keep_their_derived_traits() {
    let geometry = r##"pub struct Point do
  x :: Float
  tags :: List<String>
end deriving(Eq, Ord, Display, Debug, Hash)

pub struct Plain do
  n :: Int
end

pub type Color do
  Red
  Rgb(n :: Int)
end

pub type Shape do
  Circle(r :: Float)
  Dot
end deriving(Json, Eq)

pub fn enc(s :: Shape) -> String do
  Json.encode(s)
end
"##;
    let main = r##"from Geometry import Point, Plain, Color, Shape, enc

fn main() do
  let p = Point { x: 1.0, tags: ["a"] }
  println("#{p == p} #{p < Point { x: 2.0, tags: [] }} #{p} #{p.inspect()}")
  let a = Plain { n: 1 }
  println("#{a == Plain { n: 1 }} #{a < Plain { n: 2 }} #{a.inspect()} #{a.hash() == Plain { n: 1 }.hash()}")
  println("#{Rgb(1) == Rgb(1)} #{Red < Rgb(0)} #{Color.Rgb(2).inspect()}")
  println("#{Json.encode(Circle(1.5)) == enc(Circle(1.5))} #{Shape.Dot == Dot}")
end
"##;
    let output = compile_multifile_and_run(&[("geometry.mpl", geometry), ("main.mpl", main)]);
    assert_eq!(
        output,
        "true true Point(1.0, [a]) Point { x: 1.0, tags: [\"a\"] }\n\
         true true Plain { n: 1 } true\n\
         true true Rgb(2)\n\
         true true\n"
    );
}

/// A module's own variant shadows an imported variant of the same name
/// (whatsdown's `GroupError.InvalidMember` beside the imported
/// `GroupTreeError.InvalidMember`), wherever the import sits.
#[test]
fn e2e_local_variant_shadows_an_imported_one() {
    let tree = r##"pub type TreeError do
  InvalidMember
end

pub fn tree_error() -> TreeError do
  InvalidMember
end
"##;
    let main = r##"from Tree import TreeError, tree_error

type GroupError do
  InvalidMember
  Other
end

fn group_error() -> GroupError do
  InvalidMember
end

fn main() do
  case group_error() do
    InvalidMember -> println("group")
    Other -> println("other")
  end
  case tree_error() do
    TreeError.InvalidMember -> println("tree")
  end
end
"##;
    let output = compile_multifile_and_run(&[("tree.mpl", tree), ("main.mpl", main)]);
    assert_eq!(output, "group\ntree\n");
}

#[test]
fn e2e_module_qualified_struct_names() {
    // `Geo.Point` in an annotation was a type of its own ("type Geo.Point
    // has no field x"), and `Geo.Point { .. }` was "not a struct".
    let geo = "pub struct Point do\n  x :: Int\n  y :: Int\nend\n";
    let main = r##"import Geo

fn norm1(p :: Geo.Point) -> Int do
  p.x + p.y
end

fn main() do
  let p :: Geo.Point = Geo.Point { x: 3, y: 4 }
  let q = Point { x: 1, y: 2 }
  println("#{norm1(p)} #{norm1(q)} #{p.y}")
end
"##;
    let output = compile_multifile_and_run(&[("geo.mpl", geo), ("main.mpl", main)]);
    assert_eq!(output, "7 3 4\n");
}

#[test]
fn e2e_module_qualified_variants() {
    // `Geo.Line(7)` was "undefined variable: Geo" (twice) and the pattern
    // `Geo.Dot ->` an unknown variant.
    let geo = "pub type Shape do\n  Dot\n  Line(Int)\nend\n";
    let main = r##"import Geo

fn size(s :: Geo.Shape) -> Int do
  case s do
    Geo.Dot -> 0
    Geo.Line(n) -> n
  end
end

fn main() do
  let d = Geo.Dot
  println("#{size(Geo.Line(7))} #{size(d)} #{size(Line(2))}")
end
"##;
    let output = compile_multifile_and_run(&[("geo.mpl", geo), ("main.mpl", main)]);
    assert_eq!(output, "7 0 2\n");
}

#[test]
fn e2e_impl_header_names_can_be_module_qualified() {
    // `impl Geo.Describe for Geo.P` was read as an impl of `Geo` for `Geo`.
    let geo = "pub interface Describe do\n  fn describe(self) -> String\nend\n\npub struct P do\n  n :: Int\nend\n";
    let main = r##"import Geo

impl Geo.Describe for Geo.P do
  fn describe(self) -> String do
    "p #{self.n}"
  end
end

fn main() do
  println(Geo.P { n: 3 }.describe())
end
"##;
    let output = compile_multifile_and_run(&[("geo.mpl", geo), ("main.mpl", main)]);
    assert_eq!(output, "p 3\n");
}

#[test]
fn e2e_interfaces_of_other_modules_without_an_import() {
    // With no import, `main` was checked before `shapes` and its interface
    // was unknown; importing the interface by name was "not exported".
    let shapes = "pub interface Shape do\n  fn area(self) -> Int\nend\n";
    let main = r##"struct Sq do
  s :: Int
end

impl Shape for Sq do
  fn area(self) -> Int do
    self.s * self.s
  end
end

fn total<T>(x :: T) -> Int where T: Shape do
  x.area()
end

fn main() do
  println("#{total(Sq { s: 3 })}")
end
"##;
    let output = compile_multifile_and_run(&[("shapes.mpl", shapes), ("main.mpl", main)]);
    assert_eq!(output, "9\n");
    let main = format!("from Shapes import Shape\n\n{main}");
    let output = compile_multifile_and_run(&[("shapes.mpl", shapes), ("main.mpl", &main)]);
    assert_eq!(output, "9\n");
}

#[test]
fn e2e_default_methods_of_interfaces_from_other_modules() {
    // The impl in `main` inherits `label` from `shapes`: "no method
    // `label`", then "Undefined variable 'Shape__label__Circle'".
    let shapes = "pub interface Shape do\n  fn area(self) -> Int\n  fn label(self) -> String do\n    \"area=#{self.area()}\"\n  end\nend\n";
    let main = r##"import Shapes

struct Circle do
  r :: Int
end

impl Shapes.Shape for Circle do
  fn area(self) -> Int do
    3 * self.r * self.r
  end
end

fn show<T>(x :: T) -> String where T: Shape do
  x.label()
end

fn main() do
  let c = Circle { r: 2 }
  println(c.label())
  println(show(c))
end
"##;
    let output = compile_multifile_and_run(&[("shapes.mpl", shapes), ("main.mpl", main)]);
    assert_eq!(output, "area=12\narea=12\n");
}

#[test]
fn e2e_arity_overloads_across_modules() {
    // Pub overloads imported and called qualified, a private arity beside a
    // pub one, and private overloads of one name in two modules.
    let geo = r##"pub fn area(r :: Int) -> Int = r * r * 3
pub fn area(w :: Int, h :: Int) -> Int = w * h

pub fn wrap(x) = [x]
fn wrap(x, y) = [x, y]

pub fn pair(x, y) = wrap(x, y)

fn helper(x :: Int) -> Int = x + 1
fn helper(x :: Int, y :: Int) -> Int = x + y

pub fn use_helpers() -> Int = helper(1) + helper(2, 3)
"##;
    let other = r##"fn helper(x :: Int) -> Int = x * 100
fn helper(x :: Int, y :: Int) -> Int = x * y

pub fn other_helpers() -> Int = helper(1) + helper(2, 3)
"##;
    let main = r##"import Geo
from Geo import area, wrap, pair, use_helpers
from Other import other_helpers

fn main() do
  println("#{area(2)} #{area(3, 4)} #{Geo.area(1)} #{Geo.area(2, 5)}")
  println("#{List.length(wrap(1))} #{List.length(wrap("s"))} #{List.length(pair(1, 2))}")
  println("#{use_helpers()} #{other_helpers()}")
  println("#{2 |> area} #{2 |> area(3)} #{2 |> Geo.area(3)}")
end
"##;
    let output =
        compile_multifile_and_run(&[("geo.mpl", geo), ("other.mpl", other), ("main.mpl", main)]);
    assert_eq!(output, "12 12 3 10\n1 1 2\n7 106\n12 6 6\n");
}

#[test]
fn e2e_a_type_two_modules_define_differently_is_an_error() {
    // Private structs, actors and services of one name in two modules were
    // taken for one: `Z.run_z()` showed its `State` laid out as `A`'s
    // ("State(4366917664)"), and a module's `spawn(worker)` could start
    // another module's `worker`.
    let a = r##"struct State do
  count :: Int
end deriving(Display)

pub fn run_a() -> String do
  "${State { count: 41 }}"
end
"##;
    let z = r##"struct State do
  label :: String
end deriving(Display)

pub fn run_z() -> String do
  "${State { label: "zed" }}"
end
"##;
    let main =
        "import A\nimport Z\n\nfn main() do\n  println(A.run_a())\n  println(Z.run_z())\nend\n";
    let err = compile_multifile_expect_error(&[("a.mpl", a), ("z.mpl", z), ("main.mpl", main)]);
    assert!(
        err.contains("`State` is defined in more than one module"),
        "{err}"
    );
    assert!(
        err.contains("struct in `A`") && err.contains("struct in `Z`"),
        "{err}"
    );
    let worker = "actor worker() do\n  receive do\n    n -> println(\"${n}\")\n  end\nend\n\npub fn start() -> Pid<Int> do\n  spawn(worker)\nend\n";
    let main = format!(
        "import A\n\n{}\nfn main() do\n  send(A.start(), 1)\nend\n",
        &worker[..worker.find("pub fn").unwrap()]
    );
    let err = compile_multifile_expect_error(&[("a.mpl", worker), ("main.mpl", &main)]);
    assert!(
        err.contains("`worker` is defined in more than one module"),
        "{err}"
    );
    // A struct defined identically in each module is one layout: fine.
    let pair = "struct Pair do\n  a :: Int\n  b :: String\nend\n\n";
    let x = format!("{pair}pub fn x_pair() -> String do\n  Pair {{ a: 1, b: \"x\" }}.b\nend\n");
    let y = format!("{pair}pub fn y_pair() -> String do\n  Pair {{ a: 2, b: \"y\" }}.b\nend\n");
    let main = "import X\nimport Y\n\nfn main() do\n  println(X.x_pair() <> Y.y_pair())\nend\n";
    let output = compile_multifile_and_run(&[("x.mpl", &x), ("y.mpl", &y), ("main.mpl", main)]);
    assert_eq!(output, "xy\n");
}

#[test]
fn e2e_a_generic_function_takes_types_of_later_modules() {
    // A bounded generic function called with a type from a module checked
    // after it (and every type of `main`) did not find the type's impl:
    // "cannot convert a value of type `Rect` to a string", or "Undefined
    // variable 'area'" for a user interface.
    let alpha = r##"pub interface Area do
  fn area(self) -> Int
end

pub fn show_it<T>(x :: T) -> String where T: Display do
  "<${x}>"
end

pub fn twice<T>(x :: T) -> Int where T: Area do
  x.area() * 2
end
"##;
    let zed = "pub struct Rect do\n  w :: Int\nend deriving(Display)\n";
    let main = r##"from Alpha import show_it, twice, Area
from Zed import Rect

struct Square do
  s :: Int
end deriving(Display)

impl Area for Square do
  fn area(self) -> Int do
    self.s * self.s
  end
end

fn main() do
  println(show_it(Rect { w: 5 }))
  println(show_it(Square { s: 2 }))
  println("${twice(Square { s: 3 })}")
end
"##;
    let output =
        compile_multifile_and_run(&[("alpha.mpl", alpha), ("zed.mpl", zed), ("main.mpl", main)]);
    assert_eq!(output, "<Rect(5)>\n<Square(2)>\n18\n");
}

#[test]
fn e2e_a_generic_closure_captures_types_of_later_modules() {
    // A generic function's closure captures a value of a type from a module
    // lowered after it: nothing in the function's module describes the type,
    // so the capture is shared, and the closure still reads it back.
    let alpha = r##"pub fn later<T>(x :: T) -> Fun() -> T do
  fn () -> x end
end
"##;
    let main = r##"from Alpha import later

struct Crate do
  n :: Int
  label :: String
end

fn main() do
  let f = later(Crate { n: 4, label: "four" })
  let c = f()
  println("#{c.n} #{c.label}")
end
"##;
    let output = compile_multifile_and_run(&[("alpha.mpl", alpha), ("main.mpl", main)]);
    assert_eq!(output, "4 four\n");
}

#[test]
fn e2e_generic_structs_and_services_are_used_from_other_modules() {
    // A generic struct named through its module or imported by name gets
    // fresh type arguments at each use, and a service another module
    // defines is started and called through its name.
    let geo = r##"pub struct Pair<A, B> do
  first :: A
  second :: B
end

service Counter do
  fn init(start :: Int) -> Int do
    start
  end

  call Get() :: Int do |count|
    (count, count)
  end

  cast Add(n :: Int) do |count|
    count + n
  end
end
"##;
    let main = r##"import Geo
from Geo import Pair

fn main() do
  let p = Geo.Pair { first: 1, second: "a" }
  let q = Pair { first: true, second: 2.5 }
  println("#{p.first} #{p.second} #{q.first} #{q.second}")
  let c = Counter.start(10)
  Counter.add(c, 5)
  println("#{Counter.get(c)}")
end
"##;
    let output = compile_multifile_and_run(&[("geo.mpl", geo), ("main.mpl", main)]);
    assert_eq!(output, "1 a true 2.5\n15\n");
    let err = compile_multifile_expect_error(&[
        ("geo.mpl", geo),
        (
            "main.mpl",
            "from Nope import thing\n\nfn main() do\n  thing()\nend\n",
        ),
    ]);
    assert!(err.contains("E0031") && err.contains("Nope"), "{err}");
}

#[test]
fn e2e_a_module_block_is_a_module() {
    // `module ... do ... end` blocks were skipped: never type-checked (a
    // body adding a string to an undefined name built) and never reachable
    // ("undefined variable: Geometry").
    let main = r##"import Billing
import Shapes

module Billing do
  pub fn total(items :: List<Int>) -> Int do
    List.reduce(items, 0, fn acc, item -> acc + item end)
  end
end

fn main() do
  println("${Billing.total([1, 2, 3])} ${Shapes.area(2)}")
end
"##;
    let geo =
        "pub module Shapes do\n  pub fn area(r :: Int) -> Int do\n    r * r * 3\n  end\nend\n";
    let output = compile_multifile_and_run(&[("geo.mpl", geo), ("main.mpl", main)]);
    assert_eq!(output, "6 12\n");

    // Its body is checked.
    let main = "module Billing do\n  pub fn total(items :: List<Int>) -> Int do\n    \"no\" + undefined_thing\n  end\nend\n\nfn main() do\n  println(\"ok\")\nend\n";
    let err = compile_multifile_expect_error(&[("main.mpl", main)]);
    assert!(err.contains("undefined_thing"), "{err}");

    // Without `pub`, only its own file imports it.
    let geo = "module Shapes do\n  pub fn area(r :: Int) -> Int do\n    r * r * 3\n  end\nend\n";
    let main = "import Shapes\n\nfn main() do\n  println(\"${Shapes.area(2)}\")\nend\n";
    let err = compile_multifile_expect_error(&[("geo.mpl", geo), ("main.mpl", main)]);
    assert!(
        err.contains("Module `Shapes` is private to 'geo.mpl'"),
        "{err}"
    );
}
