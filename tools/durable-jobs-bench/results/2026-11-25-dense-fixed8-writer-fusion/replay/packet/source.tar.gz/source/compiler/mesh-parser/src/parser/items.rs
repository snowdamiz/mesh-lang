//! Item/declaration parsers for Mesh.
//!
//! Parses top-level and nested declarations: function definitions, module
//! definitions, import declarations, and struct definitions. Handles visibility
//! (pub keyword) and type annotations.

use crate::syntax_kind::SyntaxKind;
use mesh_common::span::Span;
use mesh_diagnostics::Code;

use super::expressions::{parse_fn_clause_param_list, parse_param_list};
use super::{MarkOpened, Parser};

// ── Visibility ───────────────────────────────────────────────────────────

/// If the current token is `pub`, parse it as a VISIBILITY node.
fn parse_optional_visibility(p: &mut Parser) {
    if p.at(SyntaxKind::PUB_KW) {
        let m = p.open();
        p.advance(); // pub
        p.close(m, SyntaxKind::VISIBILITY);
    }
}

// ── Function Definition ──────────────────────────────────────────────────

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum FnDeclPrefixState {
    Absent,
    ClusterDecoratorValid,
    ClusterDecoratorInvalid,
    NativeDecoratorValid,
    NativeDecoratorInvalid,
    ExportDecoratorValid,
    ExportDecoratorInvalid,
    RemovedSyntaxInvalid,
}

impl FnDeclPrefixState {
    fn missing_fn_message(self) -> Option<&'static str> {
        match self {
            Self::ClusterDecoratorValid | Self::ClusterDecoratorInvalid => {
                Some("expected `fn` or `def` after `@cluster`")
            }
            Self::NativeDecoratorValid | Self::NativeDecoratorInvalid => {
                Some("expected `fn` or `def` after `@native`")
            }
            Self::ExportDecoratorValid | Self::ExportDecoratorInvalid => {
                Some("expected `fn` or `def` after `@export`")
            }
            // The removed spelling is reported where it is, and a function
            // without a prefix is only started at its `fn` or `def`.
            Self::RemovedSyntaxInvalid | Self::Absent => None,
        }
    }

    fn is_native(self) -> bool {
        matches!(
            self,
            Self::NativeDecoratorValid | Self::NativeDecoratorInvalid
        )
    }

    fn is_export(self) -> bool {
        matches!(
            self,
            Self::ExportDecoratorValid | Self::ExportDecoratorInvalid
        )
    }
}

pub(crate) fn starts_clustered_fn_def(p: &Parser) -> bool {
    p.at(SyntaxKind::AT)
        || (p.at(SyntaxKind::IDENT)
            && p.current_text() == "clustered"
            && matches!(
                p.nth(1),
                SyntaxKind::L_PAREN
                    | SyntaxKind::PUB_KW
                    | SyntaxKind::FN_KW
                    | SyntaxKind::DEF_KW
                    | SyntaxKind::IDENT
            ))
}

fn recover_cluster_decorator_args(p: &mut Parser) {
    while !matches!(
        p.current(),
        SyntaxKind::R_PAREN
            | SyntaxKind::EOF
            | SyntaxKind::NEWLINE
            | SyntaxKind::PUB_KW
            | SyntaxKind::FN_KW
            | SyntaxKind::DEF_KW
    ) {
        p.advance();
    }
}

/// `@cluster` or `@cluster(N)`, the `@` already seen.
fn parse_cluster_decorator_decl(p: &mut Parser) -> FnDeclPrefixState {
    let m = p.open();
    let start_span = p.current_span();
    let mut valid = true;

    p.advance(); // @

    if p.at(SyntaxKind::IDENT) && p.current_text() == "cluster" {
        p.advance();
    } else {
        p.error("expected `cluster` after `@`");
        if p.at(SyntaxKind::IDENT) {
            p.advance();
        }
        p.close(m, SyntaxKind::ERROR_NODE);
        return FnDeclPrefixState::ClusterDecoratorInvalid;
    }

    if p.eat(SyntaxKind::L_PAREN) {
        if p.at(SyntaxKind::INT_LITERAL) {
            p.advance();
            // A second argument; anything else is a missing `)`, below.
            if p.at(SyntaxKind::COMMA) || p.at(SyntaxKind::INT_LITERAL) {
                p.error("expected exactly one replication count in `@cluster(N)`");
                recover_cluster_decorator_args(p);
                valid = false;
            }
        } else {
            p.error("expected integer replication count inside `@cluster(...)`");
            recover_cluster_decorator_args(p);
            valid = false;
        }

        if !p.eat(SyntaxKind::R_PAREN) {
            let found = p.found();
            p.error_with_related(
                Code::UnclosedDelimiter,
                &format!("expected `)` to close `@cluster(...)`, found {found}"),
                start_span,
                "opened here",
            );
            valid = false;
        }
    }

    p.close(
        m,
        if valid {
            SyntaxKind::CLUSTER_DECORATOR_DECL
        } else {
            SyntaxKind::ERROR_NODE
        },
    );

    if valid {
        FnDeclPrefixState::ClusterDecoratorValid
    } else {
        FnDeclPrefixState::ClusterDecoratorInvalid
    }
}

fn parse_native_decorator_decl(p: &mut Parser) -> FnDeclPrefixState {
    parse_abi_symbol_decorator_decl(
        p,
        "native",
        SyntaxKind::NATIVE_DECORATOR_DECL,
        FnDeclPrefixState::NativeDecoratorValid,
        FnDeclPrefixState::NativeDecoratorInvalid,
    )
}

fn parse_export_decorator_decl(p: &mut Parser) -> FnDeclPrefixState {
    parse_abi_symbol_decorator_decl(
        p,
        "export",
        SyntaxKind::EXPORT_DECORATOR_DECL,
        FnDeclPrefixState::ExportDecoratorValid,
        FnDeclPrefixState::ExportDecoratorInvalid,
    )
}

fn parse_abi_symbol_decorator_decl(
    p: &mut Parser,
    decorator: &str,
    syntax_kind: SyntaxKind,
    valid_state: FnDeclPrefixState,
    invalid_state: FnDeclPrefixState,
) -> FnDeclPrefixState {
    let marker = p.open();
    let start_span = p.current_span();
    let mut valid = true;
    p.advance(); // @
    p.advance(); // decorator name

    if !p.eat(SyntaxKind::L_PAREN) {
        p.error(&format!(
            "expected `(` and one literal {decorator} symbol after `@{decorator}`"
        ));
        valid = false;
    } else if p.at(SyntaxKind::STRING_START) {
        p.advance();
        let mut has_content = false;
        while p.at(SyntaxKind::STRING_CONTENT) {
            has_content = true;
            p.advance();
        }
        if !has_content {
            p.error(&format!(
                "expected one non-empty literal {decorator} symbol"
            ));
            valid = false;
        }
        if !p.eat(SyntaxKind::STRING_END) {
            p.error(&format!(
                "expected one literal {decorator} symbol without interpolation"
            ));
            valid = false;
        }
        if p.at(SyntaxKind::COMMA) {
            p.error(&format!("expected exactly one literal {decorator} symbol"));
            recover_cluster_decorator_args(p);
            valid = false;
        }
    } else {
        p.error(&format!("expected one literal {decorator} symbol"));
        recover_cluster_decorator_args(p);
        valid = false;
    }

    // A missing `)` after a malformed argument is already reported.
    if !p.eat(SyntaxKind::R_PAREN) && valid {
        let found = p.found();
        p.error_with_related(
            Code::UnclosedDelimiter,
            &format!("expected `)` to close `@{decorator}(...)`, found {found}"),
            start_span,
            "opened here",
        );
        valid = false;
    }

    p.close(
        marker,
        if valid {
            syntax_kind
        } else {
            SyntaxKind::ERROR_NODE
        },
    );
    if valid {
        valid_state
    } else {
        invalid_state
    }
}

/// `@display`, which takes no arguments, and the newlines after it;
/// whether it was there.
fn parse_display_decorator_decl(p: &mut Parser) -> bool {
    if !(p.at(SyntaxKind::AT) && p.nth(1) == SyntaxKind::IDENT && p.nth_text(1) == "display") {
        return false;
    }
    let marker = p.open();
    p.advance(); // @
    p.advance(); // display
    p.close(marker, SyntaxKind::DISPLAY_DECORATOR_DECL);
    p.eat_newlines();
    true
}

fn reject_removed_clustered_work_decl(p: &mut Parser) -> FnDeclPrefixState {
    if !(p.at(SyntaxKind::IDENT) && p.current_text() == "clustered") {
        return FnDeclPrefixState::Absent;
    }

    let m = p.open();
    let start_span = p.current_span();
    p.advance(); // clustered

    let has_parens = p.eat(SyntaxKind::L_PAREN);
    while !matches!(
        p.current(),
        SyntaxKind::EOF
            | SyntaxKind::NEWLINE
            | SyntaxKind::PUB_KW
            | SyntaxKind::FN_KW
            | SyntaxKind::DEF_KW
    ) {
        if has_parens && p.at(SyntaxKind::R_PAREN) {
            break;
        }
        p.advance();
    }
    if has_parens {
        p.eat(SyntaxKind::R_PAREN);
    }

    p.error_with_related(
        Code::UnexpectedToken,
        "`clustered(work)` declarations are not supported; use `@cluster` or `@cluster(N)` before `fn`/`def`",
        start_span,
        "unsupported clustered declaration started here",
    );
    p.close(m, SyntaxKind::ERROR_NODE);
    FnDeclPrefixState::RemovedSyntaxInvalid
}

fn parse_optional_fn_decl(p: &mut Parser) -> FnDeclPrefixState {
    if p.at(SyntaxKind::AT) {
        if p.nth(1) == SyntaxKind::IDENT && p.nth_text(1) == "native" {
            parse_native_decorator_decl(p)
        } else if p.nth(1) == SyntaxKind::IDENT && p.nth_text(1) == "export" {
            parse_export_decorator_decl(p)
        } else {
            parse_cluster_decorator_decl(p)
        }
    } else {
        reject_removed_clustered_work_decl(p)
    }
}

/// Parse a function definition.
///
/// Supports two body forms:
/// - Block body: `[@cluster] [@cluster(N)] [pub] fn|def name(params) [-> ReturnType] [where ...] do body end`
/// - Expression body: `[@cluster] [@cluster(N)] [pub] fn|def name(pattern_params) [when guard] = expr`
///
/// Pattern parameters (literals, wildcards, constructors, tuples) are supported
/// alongside regular named parameters in both forms.
pub(crate) fn parse_fn_def(p: &mut Parser) {
    let m = p.open();

    // `@display` goes with an `@export`, before or after it.
    let displayed = parse_display_decorator_decl(p);
    let declaration_prefix = parse_optional_fn_decl(p);
    if !matches!(declaration_prefix, FnDeclPrefixState::Absent) {
        p.eat_newlines();
    }
    let displayed = parse_display_decorator_decl(p) || displayed;

    // Optional visibility.
    parse_optional_visibility(p);

    // Consume fn or def keyword.
    if p.at(SyntaxKind::FN_KW) || p.at(SyntaxKind::DEF_KW) {
        p.advance();
    } else {
        if let Some(message) = declaration_prefix.missing_fn_message() {
            p.error(message);
        } else if displayed {
            p.error("expected `fn` or `def` after `@display`");
        }
        p.close(m, SyntaxKind::FN_DEF);
        return;
    }

    // Function name.
    if p.at(SyntaxKind::IDENT) {
        let name = p.open();
        p.advance();
        p.close(name, SyntaxKind::NAME);
    } else {
        p.error("expected function name");
        p.close(m, SyntaxKind::FN_DEF);
        return;
    }

    // Optional type parameters: <T, U>
    if p.at(SyntaxKind::LT) {
        parse_generic_param_list(p);
    }

    // Parameter list -- use clause-aware parsing to support patterns.
    if p.at(SyntaxKind::L_PAREN) {
        parse_fn_clause_param_list(p);
    }

    // Optional return type: -> Type
    if p.at(SyntaxKind::ARROW) {
        let ann = p.open();
        p.advance(); // ->
        parse_type(p);
        p.close(ann, SyntaxKind::TYPE_ANNOTATION);
    }

    // Optional where clause: where T: Trait
    if p.at(SyntaxKind::WHERE_KW) {
        parse_where_clause(p);
    }

    // Optional guard clause: when <expr>
    if p.at(SyntaxKind::WHEN_KW) {
        let guard = p.open();
        p.advance(); // WHEN_KW
        super::expressions::expr(p);
        p.close(guard, SyntaxKind::GUARD_CLAUSE);
    }

    // Native ABI declarations are signatures; their implementation comes from
    // a checksummed static archive selected by the package manifest.
    if declaration_prefix.is_native() {
        if p.at(SyntaxKind::EQ) || p.at(SyntaxKind::DO_KW) {
            p.error("native function declarations must not have a Mesh body");
        }
    } else if declaration_prefix.is_export() && !p.at(SyntaxKind::EQ) && !p.at(SyntaxKind::DO_KW) {
        p.error("exported functions require a Mesh body");
    } else if p.at(SyntaxKind::EQ) {
        // Expression body form: fn name(pattern) = expr, the expression
        // on the same line or the next.
        p.advance(); // EQ
        p.skip_newlines_for_continuation();

        let body = p.open();
        super::expressions::expr(p);
        p.close(body, SyntaxKind::FN_EXPR_BODY);
    } else if p.at(SyntaxKind::DO_KW) {
        // Block body form: fn name(params) do ... end
        let do_span = p.current_span();
        p.advance(); // DO_KW

        super::expressions::parse_block_body(p);

        p.expect_end("function body", do_span);
    } else {
        p.error("expected `=` or `do` for function body");
    }

    p.close(m, SyntaxKind::FN_DEF);
}

// ── Module Definition ────────────────────────────────────────────────────

/// Parse a module definition: `[pub] module Name do items end`
pub(crate) fn parse_module_def(p: &mut Parser) {
    let m = p.open();

    // Optional visibility.
    parse_optional_visibility(p);

    p.advance(); // MODULE_KW

    // Module name.
    if p.at(SyntaxKind::IDENT) {
        let name = p.open();
        p.advance();
        p.close(name, SyntaxKind::NAME);
    } else {
        p.error("expected module name");
        p.close(m, SyntaxKind::MODULE_DEF);
        return;
    }

    // Expect `do`.
    let do_span = p.current_span();
    p.expect(SyntaxKind::DO_KW);

    // Parse module items.
    if !p.has_error() {
        super::expressions::parse_block_body(p);
    }

    // Expect `end`.
    p.expect_end("module body", do_span);

    p.close(m, SyntaxKind::MODULE_DEF);
}

// ── Import Declarations ──────────────────────────────────────────────────

/// Parse an import declaration: `import ModulePath`
///
/// Module path is dot-separated: `import Foo.Bar.Baz`
pub(crate) fn parse_import_decl(p: &mut Parser) {
    let m = p.open();
    p.advance(); // IMPORT_KW

    // Parse module path.
    parse_module_path(p);

    p.close(m, SyntaxKind::IMPORT_DECL);
}

/// Parse a from-import declaration: `from ModulePath import name1, name2`
///
/// Glob imports (`from Module import *`) are rejected.
pub(crate) fn parse_from_import_decl(p: &mut Parser) {
    let m = p.open();

    // "from" is an identifier (not a keyword), advance it.
    p.advance(); // "from" IDENT

    // Parse module path.
    parse_module_path(p);

    // Expect `import`.
    p.expect(SyntaxKind::IMPORT_KW);

    // Parse import list.
    if !p.has_error() {
        let list = p.open();

        // Optional parenthesized form: `from Module import (a, b)`
        // Advancing past L_PAREN bumps paren_depth, making newlines
        // insignificant inside the parens automatically.
        let has_parens = p.at(SyntaxKind::L_PAREN);
        if has_parens {
            p.advance(); // L_PAREN
        }

        // Reject glob import: `from Module import *`
        if p.at(SyntaxKind::STAR) {
            p.error("glob imports are not allowed; import names explicitly");
            p.close(list, SyntaxKind::IMPORT_LIST);
            p.close(m, SyntaxKind::FROM_IMPORT_DECL);
            return;
        }

        if p.at(SyntaxKind::IDENT) {
            let name = p.open();
            p.advance();
            p.close(name, SyntaxKind::NAME);

            while p.eat(SyntaxKind::COMMA) {
                if p.at(SyntaxKind::NEWLINE) || p.at(SyntaxKind::EOF) || p.at(SyntaxKind::R_PAREN) {
                    break;
                }
                let name = p.open();
                p.expect(SyntaxKind::IDENT);
                p.close(name, SyntaxKind::NAME);
            }
        } else {
            p.error("expected import name");
        }

        if has_parens {
            p.expect(SyntaxKind::R_PAREN);
        }

        p.close(list, SyntaxKind::IMPORT_LIST);
    }

    p.close(m, SyntaxKind::FROM_IMPORT_DECL);
}

/// Parse a dot-separated module path: `Foo.Bar.Baz`
fn parse_module_path(p: &mut Parser) {
    let m = p.open();

    if p.at(SyntaxKind::IDENT) {
        p.advance(); // first segment

        while p.at(SyntaxKind::DOT) {
            p.advance(); // .
            p.expect(SyntaxKind::IDENT);
        }
    } else {
        p.error("expected module name");
    }

    p.close(m, SyntaxKind::PATH);
}

// ── Struct Definition ────────────────────────────────────────────────────

/// Whether the current contextual `resource` identifier starts one of the
/// supported declaration forms. Calls and ordinary references named
/// `resource` remain expressions.
pub(crate) fn starts_resource_def(p: &Parser) -> bool {
    p.at(SyntaxKind::IDENT)
        && p.current_text() == "resource"
        && matches!(p.nth(1), SyntaxKind::IDENT | SyntaxKind::STRUCT_KW)
}

/// Parse a resource declaration: `resource Name` or
/// `resource struct Name do ... end`.
///
/// `resource` is intentionally contextual rather than a lexer keyword. The
/// declaration reuses STRUCT_DEF so existing item traversal can treat opaque
/// and aggregate resources as nominal type definitions.
pub(crate) fn parse_resource_def(p: &mut Parser) {
    let m = p.open();

    parse_optional_visibility(p);

    let modifier = p.open();
    p.advance(); // contextual `resource` IDENT
    p.close(modifier, SyntaxKind::RESOURCE_MODIFIER);

    if p.at(SyntaxKind::STRUCT_KW) {
        p.advance();
        parse_struct_def_tail(p, m);
        return;
    }

    if p.at(SyntaxKind::IDENT) {
        let name = p.open();
        p.advance();
        p.close(name, SyntaxKind::NAME);
    } else {
        p.error("expected resource name");
    }

    p.close(m, SyntaxKind::STRUCT_DEF);
}

/// Parse a struct definition: `[pub] struct Name [TypeParams] do fields end`
pub(crate) fn parse_struct_def(p: &mut Parser) {
    let m = p.open();

    // Optional visibility.
    parse_optional_visibility(p);

    p.advance(); // STRUCT_KW

    parse_struct_def_tail(p, m);
}

/// Parse the shared portion of an ordinary or resource struct after the
/// `struct` token has been consumed.
fn parse_struct_def_tail(p: &mut Parser, m: MarkOpened) {
    // Struct name.
    if p.at(SyntaxKind::IDENT) {
        let name = p.open();
        p.advance();
        p.close(name, SyntaxKind::NAME);
    } else {
        p.error("expected struct name");
        p.close(m, SyntaxKind::STRUCT_DEF);
        return;
    }

    // Optional type parameters: <A, B>
    if p.at(SyntaxKind::LT) {
        parse_generic_param_list(p);
    }

    // Expect `do`.
    let do_span = p.current_span();
    p.expect(SyntaxKind::DO_KW);

    // Parse fields and relationship declarations.
    if !p.has_error() {
        loop {
            p.eat_separators();

            if p.at_item_boundary() || p.at(SyntaxKind::END_KW) || p.at(SyntaxKind::EOF) {
                break;
            }

            // A schema option (`table "people"`, `primary_key :uuid`,
            // `timestamps true`), a relationship (`has_many :posts, Post`),
            // or a field, which may have one of their names: `table :: Int`.
            let parse_member: fn(&mut Parser) = if p.nth(1) == SyntaxKind::COLON_COLON {
                parse_struct_field
            } else {
                match p.current_text() {
                    "table" | "primary_key" | "timestamps" => parse_schema_option,
                    "belongs_to" | "has_many" | "has_one" => parse_relationship_decl,
                    _ => parse_struct_field,
                }
            };
            parse_member(p);

            if p.has_error() {
                break;
            }
        }
    }

    // Expect `end`.
    p.expect_end("struct body", do_span);

    // Optional deriving clause: end deriving(Trait1, Trait2, ...)
    if p.at(SyntaxKind::IDENT) && p.current_text() == "deriving" {
        parse_deriving_clause(p);
    }

    p.close(m, SyntaxKind::STRUCT_DEF);
}

/// Parse a struct field: `name :: Type`
fn parse_struct_field(p: &mut Parser) {
    let m = p.open();

    // Field name.
    if p.at(SyntaxKind::IDENT) {
        let name = p.open();
        p.advance();
        p.close(name, SyntaxKind::NAME);
    } else {
        p.error("expected field name");
        p.close(m, SyntaxKind::STRUCT_FIELD);
        return;
    }

    // Type annotation: :: Type
    if p.at(SyntaxKind::COLON_COLON) {
        let ann = p.open();
        p.advance(); // ::
        parse_type(p);
        p.close(ann, SyntaxKind::TYPE_ANNOTATION);
    }

    p.close(m, SyntaxKind::STRUCT_FIELD);
}

/// Parse a relationship declaration inside a struct body.
///
/// Syntax: `belongs_to :name, Type` / `has_many :name, Type` / `has_one :name, Type`
///
/// These are contextual identifiers (not keywords) recognized only inside struct bodies.
/// They produce RELATIONSHIP_DECL nodes containing the relationship kind identifier,
/// atom literal (association name), and type identifier (target type).
fn parse_relationship_decl(p: &mut Parser) {
    let m = p.open();

    // Bump the relationship kind identifier (belongs_to, has_many, has_one).
    p.advance(); // IDENT

    // Expect atom literal: :name
    if p.at(SyntaxKind::ATOM_LITERAL) {
        p.advance();
    } else {
        p.error("expected atom literal (e.g., :user) after relationship kind");
        p.close(m, SyntaxKind::RELATIONSHIP_DECL);
        return;
    }

    // Expect comma separator.
    p.expect(SyntaxKind::COMMA);

    // Expect target type name.
    if !p.has_error() {
        if p.at(SyntaxKind::IDENT) {
            p.advance();
        } else {
            p.error("expected target type name after comma in relationship declaration");
        }
    }

    p.close(m, SyntaxKind::RELATIONSHIP_DECL);
}

/// Parse a schema option declaration inside a struct body.
///
/// Syntax:
/// - `table "custom_table_name"` (STRING value)
/// - `primary_key :custom_pk` (ATOM value)
/// - `timestamps true` or `timestamps false`
///
/// These are contextual identifiers (not keywords) recognized only inside struct bodies.
/// They produce SCHEMA_OPTION nodes containing the option name identifier and its value.
fn parse_schema_option(p: &mut Parser) {
    let m = p.open();

    // Read the option name (table, primary_key, timestamps).
    let option_name = p.current_text().to_string();
    p.advance(); // IDENT (option name)

    match option_name.as_str() {
        "table" => {
            // Expect a string value: "custom_table_name"
            if p.at(SyntaxKind::STRING_START) {
                // Consume STRING_START, STRING_CONTENT, STRING_END
                p.advance(); // STRING_START
                if p.at(SyntaxKind::STRING_CONTENT) {
                    p.advance(); // STRING_CONTENT
                }
                if p.at(SyntaxKind::STRING_END) {
                    p.advance(); // STRING_END
                } else {
                    p.error("unterminated string in table option");
                }
            } else {
                p.error("expected string literal after `table` (e.g., table \"people\")");
            }
        }
        "primary_key" => {
            // Expect an atom literal: :custom_pk
            if p.at(SyntaxKind::ATOM_LITERAL) {
                p.advance(); // ATOM_LITERAL
            } else {
                p.error("expected atom literal after `primary_key` (e.g., primary_key :uuid)");
            }
        }
        // `timestamps`, the one option left.
        _ => {
            if !p.eat(SyntaxKind::TRUE_KW) && !p.eat(SyntaxKind::FALSE_KW) {
                p.error("expected `true` or `false` after `timestamps`");
            }
        }
    }

    p.close(m, SyntaxKind::SCHEMA_OPTION);

    // Skip optional newline after the option.
    p.eat(SyntaxKind::NEWLINE);
}

/// Parse a deriving clause: `deriving(Trait1, Trait2, ...)`
///
/// Called after `end` in struct and sum type definitions. The `deriving` identifier
/// is parsed as a contextual keyword (regular IDENT whose text is "deriving").
fn parse_deriving_clause(p: &mut Parser) {
    let dc = p.open();
    p.advance(); // "deriving" IDENT
    p.expect(SyntaxKind::L_PAREN);
    loop {
        if p.at(SyntaxKind::R_PAREN) || p.at(SyntaxKind::EOF) {
            break;
        }
        if p.at(SyntaxKind::IDENT) {
            p.advance(); // trait name
        } else {
            p.error("expected trait name in deriving clause");
            break;
        }
        if !p.eat(SyntaxKind::COMMA) {
            break;
        }
    }
    p.expect(SyntaxKind::R_PAREN);
    p.close(dc, SyntaxKind::DERIVING_CLAUSE);
}

/// Parse a generic parameter list such as `<T, n :: Nat>`, at least one.
fn parse_generic_param_list(p: &mut Parser) {
    let m = p.open();
    p.advance(); // <

    parse_generic_param(p);
    while p.eat(SyntaxKind::COMMA) {
        if p.at(SyntaxKind::GT) {
            break;
        }
        parse_generic_param(p);
    }

    p.expect(SyntaxKind::GT);
    p.close(m, SyntaxKind::GENERIC_PARAM_LIST);
}

fn parse_generic_param(p: &mut Parser) {
    if !p.at(SyntaxKind::IDENT) || p.nth(1) != SyntaxKind::COLON_COLON {
        p.expect(SyntaxKind::IDENT);
        return;
    }

    let index = p.open();
    let name = p.open();
    p.advance(); // name
    p.close(name, SyntaxKind::NAME);
    let kind = p.open();
    p.advance(); // ::
    parse_type(p);
    p.close(kind, SyntaxKind::TYPE_ANNOTATION);
    p.close(index, SyntaxKind::INDEX_PARAM);
}

// ── Type Parsing ─────────────────────────────────────────────────────────

/// Parse a type expression: `Ident`, `Ident<A, B>`, `Mod.Type`, `Int?`, `T!E`
///
/// Supports:
/// - Simple types: `Int`, `String`
/// - Qualified types: `Foo.Bar`
/// - Generic applications: `List<Int>`, `Result<String, Error>`
/// - Option sugar: `Int?` (desugars to `Option<Int>`)
/// - Result sugar: `T!E` (desugars to `Result<T, E>`)
pub(crate) fn parse_type(p: &mut Parser) {
    p.with_nesting(parse_type_inner);
}

fn parse_type_inner(p: &mut Parser) {
    // Tuple type: (A, B, C)
    if p.at(SyntaxKind::L_PAREN) {
        p.advance(); // (
        if !p.at(SyntaxKind::R_PAREN) {
            parse_type(p);
            while p.eat(SyntaxKind::COMMA) {
                if p.at(SyntaxKind::R_PAREN) {
                    break;
                }
                parse_type(p);
            }
        }
        p.expect(SyntaxKind::R_PAREN);
        parse_type_sugar(p);
        return;
    }

    // Function type: Fun(ParamTypes) -> ReturnType
    if p.at(SyntaxKind::IDENT) && p.current_text() == "Fun" && p.nth(1) == SyntaxKind::L_PAREN {
        let m = p.open();
        p.advance(); // Fun
        p.advance(); // (
                     // Parse comma-separated parameter types (may be empty for Fun() -> T)
        if !p.at(SyntaxKind::R_PAREN) {
            parse_type(p);
            while p.eat(SyntaxKind::COMMA) {
                if p.at(SyntaxKind::R_PAREN) {
                    break;
                }
                parse_type(p);
            }
        }
        p.expect(SyntaxKind::R_PAREN);
        p.expect(SyntaxKind::ARROW);
        if !p.has_error() {
            parse_type(p); // return type
        }
        p.close(m, SyntaxKind::FUN_TYPE);
        return;
    }

    if !p.at(SyntaxKind::IDENT) {
        p.error("expected type name");
        return;
    }

    // Parse the base type: Ident possibly with dots and generic args.
    // We emit the tokens directly (no wrapping node for simple types).
    p.advance(); // type name IDENT

    // Optional dot-separated path: Foo.Bar
    while p.at(SyntaxKind::DOT) {
        p.advance(); // .
        p.expect(SyntaxKind::IDENT);
    }

    // Optional generic arguments: <A, B>
    if p.at(SyntaxKind::LT) {
        parse_generic_arg_list(p);
    }

    parse_type_sugar(p);
}

fn parse_generic_arg_list(p: &mut Parser) {
    let args = p.open();
    p.advance(); // <
    parse_type_arg(p);
    while p.eat(SyntaxKind::COMMA) {
        if p.at(SyntaxKind::GT) {
            break;
        }
        parse_type_arg(p);
    }
    p.expect(SyntaxKind::GT);
    p.close(args, SyntaxKind::GENERIC_ARG_LIST);
}

fn parse_type_arg(p: &mut Parser) {
    if p.at(SyntaxKind::INT_LITERAL) {
        let index = p.open();
        p.advance();
        p.close(index, SyntaxKind::NAT_INDEX);
    } else {
        parse_type(p);
    }
}

/// The `?` (Option) or `!Error` (Result) suffix of a type.
fn parse_type_sugar(p: &mut Parser) {
    // Option sugar: Type? => OPTION_TYPE wrapping the base type
    if p.at(SyntaxKind::QUESTION) {
        p.advance(); // ?
                     // The QUESTION token is emitted; the type checker will interpret
                     // the preceding type + QUESTION as Option<Type>.
    }

    // Result sugar: Type!ErrorType => RESULT_TYPE wrapping both types
    if p.at(SyntaxKind::BANG) {
        p.advance(); // !
        parse_type(p); // error type
                       // The BANG token followed by another type is emitted; the type checker
                       // will interpret this as Result<Type, ErrorType>.
    }
}

// ── Interface Definition ─────────────────────────────────────────────────

/// Parse an interface definition: `[pub] interface Name [<T>] do method_sigs end`
pub(crate) fn parse_interface_def(p: &mut Parser) {
    let m = p.open();

    // Optional visibility.
    parse_optional_visibility(p);

    p.advance(); // INTERFACE_KW

    // Interface name.
    if p.at(SyntaxKind::IDENT) {
        let name = p.open();
        p.advance();
        p.close(name, SyntaxKind::NAME);
    } else {
        p.error("expected interface name");
        p.close(m, SyntaxKind::INTERFACE_DEF);
        return;
    }

    // Optional type parameters: <T>
    if p.at(SyntaxKind::LT) {
        parse_generic_param_list(p);
    }

    // Expect `do`.
    let do_span = p.current_span();
    p.expect(SyntaxKind::DO_KW);

    // Parse method signatures and associated type declarations.
    if !p.has_error() {
        loop {
            p.eat_separators();

            if p.at_item_boundary() || p.at(SyntaxKind::END_KW) || p.at(SyntaxKind::EOF) {
                break;
            }

            if p.at(SyntaxKind::TYPE_KW) {
                parse_assoc_type_decl(p);
            } else {
                parse_interface_method(p);
            }

            if p.has_error() {
                break;
            }
        }
    }

    // Expect `end`.
    p.expect_end("interface body", do_span);

    p.close(m, SyntaxKind::INTERFACE_DEF);
}

/// Parse a method signature inside an interface: `fn name(params) [-> ReturnType] [do body end]`
///
/// The body is optional. Methods without `do ... end` are signature-only.
/// Methods with `do ... end` provide a default implementation.
fn parse_interface_method(p: &mut Parser) {
    let m = p.open();

    if !p.at(SyntaxKind::FN_KW) && !p.at(SyntaxKind::DEF_KW) {
        p.error("expected method signature (fn)");
        p.close(m, SyntaxKind::INTERFACE_METHOD);
        return;
    }

    p.advance(); // FN_KW or DEF_KW

    // Method name.
    if p.at(SyntaxKind::IDENT) {
        let name = p.open();
        p.advance();
        p.close(name, SyntaxKind::NAME);
    } else {
        p.error("expected method name");
        p.close(m, SyntaxKind::INTERFACE_METHOD);
        return;
    }

    // Parameter list.
    if p.at(SyntaxKind::L_PAREN) {
        parse_param_list(p);
    }

    // Optional return type: -> Type
    if p.at(SyntaxKind::ARROW) {
        let ann = p.open();
        p.advance(); // ->
        parse_type(p);
        p.close(ann, SyntaxKind::TYPE_ANNOTATION);
    }

    // Optional default body: do ... end
    if p.at(SyntaxKind::DO_KW) {
        let do_span = p.current_span();
        p.advance(); // DO_KW

        super::expressions::parse_block_body(p);

        p.expect_end("default method body", do_span);
    }

    p.close(m, SyntaxKind::INTERFACE_METHOD);
}

/// Parse an associated type declaration inside an interface: `type Item`
fn parse_assoc_type_decl(p: &mut Parser) {
    let m = p.open();
    p.advance(); // TYPE_KW

    if p.at(SyntaxKind::IDENT) {
        let name = p.open();
        p.advance();
        p.close(name, SyntaxKind::NAME);
    } else {
        p.error("expected associated type name");
    }

    p.close(m, SyntaxKind::ASSOC_TYPE_DEF);
}

/// Parse an associated type binding inside an impl: `type Item = ConcreteType`
fn parse_assoc_type_binding(p: &mut Parser) {
    let m = p.open();
    p.advance(); // TYPE_KW

    if p.at(SyntaxKind::IDENT) {
        let name = p.open();
        p.advance();
        p.close(name, SyntaxKind::NAME);
    } else {
        p.error("expected associated type name");
        p.close(m, SyntaxKind::ASSOC_TYPE_BINDING);
        return;
    }

    p.expect(SyntaxKind::EQ); // =

    if !p.has_error() {
        parse_type(p); // The concrete type
    }

    p.close(m, SyntaxKind::ASSOC_TYPE_BINDING);
}

// ── Impl Definition ─────────────────────────────────────────────────────

/// Parse an impl block: `impl TraitName for TypeName [where ...] do fn_defs end`
pub(crate) fn parse_impl_def(p: &mut Parser) {
    let m = p.open();

    p.advance(); // IMPL_KW

    // Trait name (possibly qualified: Foo.Bar).
    if p.at(SyntaxKind::IDENT) {
        parse_module_path(p);
    } else {
        p.error("expected trait name");
        p.close(m, SyntaxKind::IMPL_DEF);
        return;
    }

    // Optional generic arguments on the trait: impl Trait<T> for ...
    if p.at(SyntaxKind::LT) {
        parse_generic_arg_list(p);
    }

    // Expect `for`.
    p.expect(SyntaxKind::FOR_KW);

    // Type name (possibly qualified).
    if !p.has_error() {
        if p.at(SyntaxKind::IDENT) {
            parse_module_path(p);
        } else {
            p.error("expected type name");
        }
    }

    // `impl Show for List<Int>`: an impl for a generic type is not
    // supported. Say so at the type arguments, and read on (it said
    // "expected `do`", then that the impl body was not closed).
    if !p.has_error() && p.at(SyntaxKind::LT) {
        let start = p.current_span().start;
        let args = p.open();
        p.advance(); // <
        while !matches!(
            p.current(),
            SyntaxKind::GT | SyntaxKind::DO_KW | SyntaxKind::EOF
        ) {
            parse_type(p);
            if !p.eat(SyntaxKind::COMMA) {
                break;
            }
        }
        let end = p.current_span().end;
        p.eat(SyntaxKind::GT);
        p.close(args, SyntaxKind::ERROR_NODE);
        p.token_error_at(
            "an `impl` for a type with type arguments is not supported",
            Span::new(start, end),
        );
    }

    // Optional where clause.
    if p.at(SyntaxKind::WHERE_KW) {
        parse_where_clause(p);
    }

    // Expect `do`.
    let do_span = p.current_span();
    p.expect(SyntaxKind::DO_KW);

    // Parse method definitions and associated type bindings.
    if !p.has_error() {
        parse_impl_body(p);
    }

    // Expect `end`.
    p.expect_end("impl body", do_span);

    p.close(m, SyntaxKind::IMPL_DEF);
}

/// Parse the body of an impl block: associated type bindings and method definitions.
///
/// Unlike a block body, this specifically handles `type Item = T`
/// as associated type bindings rather than top-level type aliases/sum types.
fn parse_impl_body(p: &mut Parser) {
    let m = p.open();

    loop {
        p.eat_separators();
        if p.at_item_boundary() {
            break;
        }

        match p.current() {
            SyntaxKind::END_KW | SyntaxKind::EOF => break,
            SyntaxKind::TYPE_KW => {
                parse_assoc_type_binding(p);
            }
            SyntaxKind::FN_KW | SyntaxKind::DEF_KW => {
                parse_fn_def(p);
            }
            SyntaxKind::PUB_KW => {
                // pub fn ...
                match p.nth(1) {
                    SyntaxKind::FN_KW | SyntaxKind::DEF_KW => {
                        parse_fn_def(p);
                    }
                    _ => {
                        p.error("expected `fn` or `type` in impl body");
                        break;
                    }
                }
            }
            _ => {
                p.error("expected `fn`, `type`, or `end` in impl body");
                break;
            }
        }

        if !p.has_error() {
            super::expect_statement_end(p);
        }
        if p.has_error() {
            break;
        }
    }

    p.close(m, SyntaxKind::BLOCK);
}

// ── Sum Type Definition ──────────────────────────────────────────────────

/// A `type` declaration, `type` at lookahead `at` (after an optional `pub`):
/// `type Name[<...>] do ... end` is a sum type, anything else (`= ...`) an
/// alias. A missing name is reported by the declaration it would be.
pub(crate) fn parse_type_decl(p: &mut Parser, at: usize) {
    let head = {
        let mut kinds = p.significant_kinds().skip(at + 1).peekable();
        if kinds.peek() == Some(&SyntaxKind::IDENT) {
            kinds.next();
        }
        if kinds.peek() == Some(&SyntaxKind::LT) {
            let mut depth = 0;
            for kind in kinds.by_ref() {
                match kind {
                    SyntaxKind::LT => depth += 1,
                    SyntaxKind::GT => depth -= 1,
                    SyntaxKind::EOF => break,
                    _ => {}
                }
                if depth == 0 {
                    break;
                }
            }
        }
        kinds.next()
    };
    if head == Some(SyntaxKind::DO_KW) {
        parse_sum_type_def(p);
    } else {
        parse_type_alias(p);
    }
}

/// Parse a sum type definition: `[pub] type Name [<T>] do Variant1(Type) ... end`
///
/// Each variant is either:
/// - Nullary: `Point` (no fields)
/// - Positional: `Circle(Float)` or `Pair(Int, Int)`
/// - Named: `Rectangle(width :: Float, height :: Float)`
pub(crate) fn parse_sum_type_def(p: &mut Parser) {
    let m = p.open();

    // Optional visibility.
    parse_optional_visibility(p);

    p.advance(); // TYPE_KW

    // Type name.
    if p.at(SyntaxKind::IDENT) {
        let name = p.open();
        p.advance();
        p.close(name, SyntaxKind::NAME);
    } else {
        p.error("expected sum type name");
        p.close(m, SyntaxKind::SUM_TYPE_DEF);
        return;
    }

    // Optional type parameters: <T, U>
    if p.at(SyntaxKind::LT) {
        parse_generic_param_list(p);
    }

    // Expect `do`.
    let do_span = p.current_span();
    p.expect(SyntaxKind::DO_KW);

    // Parse variant definitions.
    if !p.has_error() {
        loop {
            p.eat_separators();

            if p.at_item_boundary() || p.at(SyntaxKind::END_KW) || p.at(SyntaxKind::EOF) {
                break;
            }

            parse_variant_def(p);

            if p.has_error() {
                break;
            }
        }
    }

    // Expect `end`.
    p.expect_end("sum type body", do_span);

    // Optional deriving clause: end deriving(Trait1, Trait2, ...)
    if p.at(SyntaxKind::IDENT) && p.current_text() == "deriving" {
        parse_deriving_clause(p);
    }

    p.close(m, SyntaxKind::SUM_TYPE_DEF);
}

/// Parse a single variant definition inside a sum type.
///
/// Variants:
/// - `VariantName` (nullary)
/// - `VariantName(Type1, Type2)` (positional)
/// - `VariantName(name1 :: Type1, name2 :: Type2)` (named fields)
/// - `Push<k :: Nat>(T, Vec<T, k>) -> Vec<T, Succ<k>>` (indexed result)
fn parse_variant_def(p: &mut Parser) {
    let m = p.open();

    // Variant name.
    if p.at(SyntaxKind::IDENT) {
        p.advance(); // variant name IDENT
    } else {
        p.error("expected variant name");
        p.close(m, SyntaxKind::VARIANT_DEF);
        return;
    }

    if p.at(SyntaxKind::LT) {
        parse_generic_param_list(p);
    }

    // Optional field list: (fields...)
    if p.at(SyntaxKind::L_PAREN) {
        p.advance(); // (

        if !p.at(SyntaxKind::R_PAREN) {
            parse_variant_field_or_type(p);
            while p.eat(SyntaxKind::COMMA) {
                if p.at(SyntaxKind::R_PAREN) {
                    break; // trailing comma
                }
                parse_variant_field_or_type(p);
            }
        }

        p.expect(SyntaxKind::R_PAREN);
    }

    if p.eat(SyntaxKind::ARROW) {
        let result = p.open();
        let ann = p.open();
        parse_type(p);
        p.close(ann, SyntaxKind::TYPE_ANNOTATION);
        p.close(result, SyntaxKind::VARIANT_RESULT);
    }

    p.close(m, SyntaxKind::VARIANT_DEF);
}

/// Parse either a named field (`name :: Type`) or a positional type in a variant.
///
/// Distinguishes by checking if IDENT is followed by COLON_COLON (named field)
/// or something else (positional type).
fn parse_variant_field_or_type(p: &mut Parser) {
    // If IDENT followed by ::, it's a named field
    if p.at(SyntaxKind::IDENT) && p.nth(1) == SyntaxKind::COLON_COLON {
        let field = p.open();
        let name = p.open();
        p.advance(); // field name
        p.close(name, SyntaxKind::NAME);
        let ann = p.open();
        p.advance(); // ::
        parse_type(p);
        p.close(ann, SyntaxKind::TYPE_ANNOTATION);
        p.close(field, SyntaxKind::VARIANT_FIELD);
    } else {
        // Positional type
        let ann = p.open();
        parse_type(p);
        p.close(ann, SyntaxKind::TYPE_ANNOTATION);
    }
}

// ── Type Alias ──────────────────────────────────────────────────────────

/// Parse a type alias: `[pub] type Name [<T>] = Type`
pub(crate) fn parse_type_alias(p: &mut Parser) {
    let m = p.open();

    // Optional visibility (handles `pub type Alias = T`).
    parse_optional_visibility(p);

    p.advance(); // TYPE_KW

    // Type name.
    if p.at(SyntaxKind::IDENT) {
        let name = p.open();
        p.advance();
        p.close(name, SyntaxKind::NAME);
    } else {
        p.error("expected type alias name");
        p.close(m, SyntaxKind::TYPE_ALIAS_DEF);
        return;
    }

    // Optional type parameters: <T>
    if p.at(SyntaxKind::LT) {
        parse_generic_param_list(p);
    }

    // Expect `=`.
    p.expect(SyntaxKind::EQ);

    // Parse the aliased type.
    if !p.has_error() {
        parse_type(p);
    }

    p.close(m, SyntaxKind::TYPE_ALIAS_DEF);
}

// ── Where Clause ────────────────────────────────────────────────────────

/// Parse a where clause: `where T: Trait, U: OtherTrait`
fn parse_where_clause(p: &mut Parser) {
    let m = p.open();
    p.advance(); // WHERE_KW

    // Parse comma-separated trait bounds: T: Trait
    parse_trait_bound(p);
    while p.eat(SyntaxKind::COMMA) {
        parse_trait_bound(p);
    }

    p.close(m, SyntaxKind::WHERE_CLAUSE);
}

/// Parse a single trait bound: `T: TraitName`
fn parse_trait_bound(p: &mut Parser) {
    let m = p.open();

    // Type parameter name.
    p.expect(SyntaxKind::IDENT);

    // Colon.
    p.expect(SyntaxKind::COLON);

    // Trait name (possibly qualified).
    if !p.has_error() {
        if p.at(SyntaxKind::IDENT) {
            p.advance();
            while p.at(SyntaxKind::DOT) {
                p.advance(); // .
                p.expect(SyntaxKind::IDENT);
            }
        } else {
            p.error("expected trait name");
        }
    }

    p.close(m, SyntaxKind::TRAIT_BOUND);
}

// ── Actor Definition ────────────────────────────────────────────────────

/// Parse an actor block definition: `actor Name(params) do body [terminate do ... end] end`
///
/// The actor block is a first-class language construct. Inside the body,
/// expressions can include receive blocks, send calls, spawn calls, and
/// a self() expression. An optional `terminate do ... end` clause defines
/// cleanup logic that runs before the actor fully terminates.
pub(crate) fn parse_actor_def(p: &mut Parser) {
    let m = p.open();

    p.advance(); // ACTOR_KW

    // Actor name.
    if p.at(SyntaxKind::IDENT) {
        let name = p.open();
        p.advance();
        p.close(name, SyntaxKind::NAME);
    } else {
        p.error("expected actor name");
        p.close(m, SyntaxKind::ACTOR_DEF);
        return;
    }

    // Optional parameter list (state arguments).
    if p.at(SyntaxKind::L_PAREN) {
        parse_param_list(p);
    }

    // Expect `do`.
    let do_span = p.current_span();
    p.expect(SyntaxKind::DO_KW);

    // Parse actor body (statements and expressions).
    if !p.has_error() {
        parse_actor_body(p);
    }

    // Expect `end`.
    p.expect_end("actor body", do_span);

    p.close(m, SyntaxKind::ACTOR_DEF);
}

/// Parse the body of an actor block.
///
/// The body can contain statements/expressions and an optional
/// `terminate do ... end` clause. Only one terminate clause is allowed.
fn parse_actor_body(p: &mut Parser) {
    let m = p.open();
    let mut seen_terminate = false;

    loop {
        p.eat_separators();
        if p.at_item_boundary() {
            break;
        }

        match p.current() {
            SyntaxKind::END_KW | SyntaxKind::EOF => break,
            SyntaxKind::TERMINATE_KW => {
                if seen_terminate {
                    p.error("only one `terminate` clause is allowed per actor block");
                    break;
                }
                seen_terminate = true;
                parse_terminate_clause(p);
            }
            _ => {
                super::parse_item_or_stmt(p);
            }
        }

        if !p.has_error() {
            super::expect_statement_end(p);
        }
        if p.has_error() {
            break;
        }
    }

    p.close(m, SyntaxKind::BLOCK);
}

/// Parse a terminate clause: `terminate do body end`
///
/// Defines cleanup logic that runs before the actor fully terminates.
fn parse_terminate_clause(p: &mut Parser) {
    let m = p.open();
    p.advance(); // TERMINATE_KW

    let do_span = p.current_span();
    p.expect(SyntaxKind::DO_KW);

    if !p.has_error() {
        super::expressions::parse_block_body(p);
    }

    p.expect_end("`terminate` block", do_span);

    p.close(m, SyntaxKind::TERMINATE_CLAUSE);
}

// ── Supervisor Definition ─────────────────────────────────────────────

/// Parse a supervisor block definition: `[pub] supervisor Name do body end`
///
/// The supervisor body contains:
/// - `strategy:` clause (one_for_one, one_for_all, rest_for_one, simple_one_for_one)
/// - `max_restarts:` clause (integer)
/// - `max_seconds:` clause (integer)
/// - `child Name do ... end` blocks with start, restart, shutdown settings
pub(crate) fn parse_supervisor_def(p: &mut Parser) {
    let m = p.open();

    // Optional visibility.
    parse_optional_visibility(p);

    p.advance(); // SUPERVISOR_KW

    // Supervisor name.
    if p.at(SyntaxKind::IDENT) {
        let name = p.open();
        p.advance();
        p.close(name, SyntaxKind::NAME);
    } else {
        p.error("expected supervisor name");
        p.close(m, SyntaxKind::SUPERVISOR_DEF);
        return;
    }

    // Expect `do`.
    let do_span = p.current_span();
    p.expect(SyntaxKind::DO_KW);

    // Parse supervisor body.
    if !p.has_error() {
        parse_supervisor_body(p);
    }

    // Expect `end`.
    p.expect_end("supervisor body", do_span);

    p.close(m, SyntaxKind::SUPERVISOR_DEF);
}

/// Parse the body of a supervisor block.
///
/// Parses key-value clauses (strategy, max_restarts, max_seconds) and
/// child spec blocks (`child Name do ... end`).
fn parse_supervisor_body(p: &mut Parser) {
    let m = p.open();

    loop {
        p.eat_separators();
        if p.at_item_boundary() {
            break;
        }

        match p.current() {
            SyntaxKind::END_KW | SyntaxKind::EOF => break,
            SyntaxKind::IDENT => {
                let text = p.current_text().to_string();
                match text.as_str() {
                    "strategy" => parse_strategy_clause(p),
                    "max_restarts" => parse_restart_limit(p),
                    "max_seconds" => parse_seconds_limit(p),
                    "child" => parse_child_spec(p),
                    _ => {
                        p.error(&format!("unexpected `{}` in supervisor body", text));
                        break;
                    }
                }
            }
            _ => {
                p.error("expected `strategy`, `max_restarts`, `max_seconds`, `child`, or `end` in supervisor body");
                break;
            }
        }

        if !p.has_error() {
            super::expect_statement_end(p);
        }
        if p.has_error() {
            break;
        }
    }

    p.close(m, SyntaxKind::BLOCK);
}

/// Parse `strategy: one_for_one` (or one_for_all, rest_for_one, simple_one_for_one).
fn parse_strategy_clause(p: &mut Parser) {
    let m = p.open();
    p.advance(); // "strategy" IDENT

    p.expect(SyntaxKind::COLON);

    // Strategy value must be a known identifier.
    if p.at(SyntaxKind::IDENT) {
        p.advance();
    } else {
        p.error(
            "expected strategy name (one_for_one, one_for_all, rest_for_one, simple_one_for_one)",
        );
    }

    p.close(m, SyntaxKind::STRATEGY_CLAUSE);
}

/// Parse `max_restarts: 3`.
fn parse_restart_limit(p: &mut Parser) {
    let m = p.open();
    p.advance(); // "max_restarts" IDENT

    p.expect(SyntaxKind::COLON);

    if p.at(SyntaxKind::INT_LITERAL) {
        p.advance();
    } else {
        p.error("expected integer for max_restarts");
    }

    p.close(m, SyntaxKind::RESTART_LIMIT);
}

/// Parse `max_seconds: 5`.
fn parse_seconds_limit(p: &mut Parser) {
    let m = p.open();
    p.advance(); // "max_seconds" IDENT

    p.expect(SyntaxKind::COLON);

    if p.at(SyntaxKind::INT_LITERAL) {
        p.advance();
    } else {
        p.error("expected integer for max_seconds");
    }

    p.close(m, SyntaxKind::SECONDS_LIMIT);
}

/// Parse a child spec: `child Name do ... end`
///
/// The child body contains key-value pairs:
/// - `start: fn -> spawn(Actor, args) end`
/// - `restart: permanent | transient | temporary`
/// - `shutdown: 5000 | brutal_kill`
fn parse_child_spec(p: &mut Parser) {
    let m = p.open();
    p.advance(); // "child" IDENT

    // Child name.
    if p.at(SyntaxKind::IDENT) {
        let name = p.open();
        p.advance();
        p.close(name, SyntaxKind::NAME);
    } else {
        p.error("expected child spec name");
        p.close(m, SyntaxKind::CHILD_SPEC_DEF);
        return;
    }

    // Expect `do`.
    let do_span = p.current_span();
    p.expect(SyntaxKind::DO_KW);

    // Parse child body key-value pairs.
    if !p.has_error() {
        parse_child_spec_body(p);
    }

    // Expect `end`.
    p.expect_end("child spec body", do_span);

    p.close(m, SyntaxKind::CHILD_SPEC_DEF);
}

/// Parse child spec body key-value pairs.
///
/// Keys: `start`, `restart`, `shutdown`.
fn parse_child_spec_body(p: &mut Parser) {
    let m = p.open();

    loop {
        p.eat_separators();

        match p.current() {
            SyntaxKind::END_KW | SyntaxKind::EOF => break,
            SyntaxKind::IDENT => {
                let text = p.current_text().to_string();
                match text.as_str() {
                    "start" | "restart" | "shutdown" => {
                        // Key: value pair. Advance key, expect colon.
                        p.advance(); // key IDENT
                        p.expect(SyntaxKind::COLON);

                        if p.has_error() {
                            break;
                        }

                        // Parse the value: could be an expression (fn -> ... end),
                        // an identifier (permanent, brutal_kill), or an integer (5000).
                        match text.as_str() {
                            "start" => {
                                // Parse as an expression (typically a closure).
                                super::expressions::expr(p);
                            }
                            "restart" => {
                                // Expect an identifier: permanent, transient, temporary.
                                if p.at(SyntaxKind::IDENT) {
                                    p.advance();
                                } else {
                                    p.error("expected restart strategy (permanent, transient, temporary)");
                                }
                            }
                            // `shutdown`: an integer or `brutal_kill`.
                            _ => {
                                if !p.eat(SyntaxKind::INT_LITERAL) && !p.eat(SyntaxKind::IDENT) {
                                    p.error("expected shutdown timeout (integer or brutal_kill)");
                                }
                            }
                        }
                    }
                    _ => {
                        p.error(&format!("unexpected `{}` in child spec body", text));
                        break;
                    }
                }
            }
            _ => {
                p.error("expected `start`, `restart`, `shutdown`, or `end` in child spec body");
                break;
            }
        }

        if !p.has_error() {
            super::expect_statement_end(p);
        }
        if p.has_error() {
            break;
        }
    }

    p.close(m, SyntaxKind::BLOCK);
}

// ── Service Definition ─────────────────────────────────────────────

/// Parse a service block definition: `service Name do ... end`
///
/// The service body contains:
/// - `fn init(params) :: ReturnType do ... end` (initialization function)
/// - `call Name(params) :: ReturnType do |state| ... end` (synchronous handlers)
/// - `cast Name(params) do |state| ... end` (asynchronous handlers)
pub(crate) fn parse_service_def(p: &mut Parser) {
    let m = p.open();

    p.advance(); // SERVICE_KW

    // Service name.
    if p.at(SyntaxKind::IDENT) {
        let name = p.open();
        p.advance();
        p.close(name, SyntaxKind::NAME);
    } else {
        p.error("expected service name");
        p.close(m, SyntaxKind::SERVICE_DEF);
        return;
    }

    // Expect `do`.
    let do_span = p.current_span();
    p.expect(SyntaxKind::DO_KW);

    // Parse service body.
    if !p.has_error() {
        parse_service_body(p);
    }

    // Expect `end`.
    p.expect_end("service body", do_span);

    p.close(m, SyntaxKind::SERVICE_DEF);
}

/// Parse the body of a service block.
///
/// Parses `fn` definitions (init), `call` handlers, and `cast` handlers.
fn parse_service_body(p: &mut Parser) {
    let m = p.open();

    loop {
        p.eat_separators();
        if p.at_item_boundary() {
            break;
        }

        match p.current() {
            SyntaxKind::END_KW | SyntaxKind::EOF => break,
            SyntaxKind::FN_KW | SyntaxKind::DEF_KW => {
                // Parse fn init(...) as a regular function definition.
                super::parse_item_or_stmt(p);
            }
            SyntaxKind::CALL_KW => {
                parse_call_handler(p);
            }
            SyntaxKind::CAST_KW => {
                parse_cast_handler(p);
            }
            _ => {
                p.error("expected `fn`, `call`, `cast`, or `end` in service body");
                break;
            }
        }

        if !p.has_error() {
            super::expect_statement_end(p);
        }
        if p.has_error() {
            break;
        }
    }

    p.close(m, SyntaxKind::BLOCK);
}

/// Parse a call handler: `call Name(params) :: ReturnType do |state| body end`
///
/// Call handlers are synchronous request handlers in a service. They receive
/// the current state and must return a tuple of `{new_state, reply}`.
fn parse_call_handler(p: &mut Parser) {
    let m = p.open();
    p.advance(); // CALL_KW

    // Handler name (variant name, e.g., GetCount).
    if p.at(SyntaxKind::IDENT) {
        let name = p.open();
        p.advance();
        p.close(name, SyntaxKind::NAME);
    } else {
        p.error("expected call handler name");
        p.close(m, SyntaxKind::CALL_HANDLER);
        return;
    }

    // Optional parameter list: (params)
    if p.at(SyntaxKind::L_PAREN) {
        parse_param_list(p);
    }

    // Return type annotation: :: Type
    if p.at(SyntaxKind::COLON_COLON) {
        let ann = p.open();
        p.advance(); // ::
        parse_type(p);
        p.close(ann, SyntaxKind::TYPE_ANNOTATION);
    }

    // Expect `do`.
    let do_span = p.current_span();
    p.expect(SyntaxKind::DO_KW);

    if p.has_error() {
        p.close(m, SyntaxKind::CALL_HANDLER);
        return;
    }

    // Parse |state| parameter.
    if p.at(SyntaxKind::BAR) {
        p.advance(); // |
        if p.at(SyntaxKind::IDENT) {
            let name = p.open();
            p.advance();
            p.close(name, SyntaxKind::NAME);
        } else {
            p.error("expected state parameter name");
        }
        p.expect(SyntaxKind::BAR);
    }

    // Parse handler body.
    if !p.has_error() {
        super::expressions::parse_block_body(p);
    }

    // Expect `end`.
    p.expect_end("call handler body", do_span);

    p.close(m, SyntaxKind::CALL_HANDLER);
}

/// Parse a cast handler: `cast Name(params) do |state| body end`
///
/// Cast handlers are asynchronous (fire-and-forget) handlers in a service.
/// They receive the current state and must return the new state.
fn parse_cast_handler(p: &mut Parser) {
    let m = p.open();
    p.advance(); // CAST_KW

    // Handler name (variant name, e.g., Reset).
    if p.at(SyntaxKind::IDENT) {
        let name = p.open();
        p.advance();
        p.close(name, SyntaxKind::NAME);
    } else {
        p.error("expected cast handler name");
        p.close(m, SyntaxKind::CAST_HANDLER);
        return;
    }

    // Optional parameter list: (params)
    if p.at(SyntaxKind::L_PAREN) {
        parse_param_list(p);
    }

    // No return type for cast (fire-and-forget, returns Unit).

    // Expect `do`.
    let do_span = p.current_span();
    p.expect(SyntaxKind::DO_KW);

    if p.has_error() {
        p.close(m, SyntaxKind::CAST_HANDLER);
        return;
    }

    // Parse |state| parameter.
    if p.at(SyntaxKind::BAR) {
        p.advance(); // |
        if p.at(SyntaxKind::IDENT) {
            let name = p.open();
            p.advance();
            p.close(name, SyntaxKind::NAME);
        } else {
            p.error("expected state parameter name");
        }
        p.expect(SyntaxKind::BAR);
    }

    // Parse handler body.
    if !p.has_error() {
        super::expressions::parse_block_body(p);
    }

    // Expect `end`.
    p.expect_end("cast handler body", do_span);

    p.close(m, SyntaxKind::CAST_HANDLER);
}

#[cfg(test)]
mod tests {
    use crate::ast::item::Item;
    use crate::{AstNode, SyntaxKind, SyntaxNode};
    use rowan::{TextRange, TextSize};

    fn child_kinds(node: &SyntaxNode) -> Vec<SyntaxKind> {
        node.children_with_tokens()
            .map(|child| child.kind())
            .filter(|kind| *kind != SyntaxKind::WHITESPACE)
            .collect()
    }

    fn source_range(source: &str, text: &str) -> TextRange {
        let start = TextSize::try_from(source.find(text).unwrap()).unwrap();
        TextRange::at(start, TextSize::of(text))
    }

    #[test]
    fn indexed_sum_type_preserves_constructor_shapes_and_spans() {
        use SyntaxKind::*;

        let source = "pub type Vec<T, n :: Nat> do\n \
                      Empty -> Vec<T, 0>\n \
                      Push<k :: Nat>(T, Vec<T, k>) -> Vec<T, Succ<k>>\nend\n";
        let parsed = crate::parse(source);
        assert!(parsed.ok(), "{:?}", parsed.errors());
        assert_eq!(parsed.syntax().text().to_string(), source);
        let tree = parsed.tree();
        let Item::SumTypeDef(sum) = tree.items().next().unwrap() else {
            panic!("expected sum type declaration");
        };
        let params = sum
            .syntax()
            .children()
            .find(|node| node.kind() == GENERIC_PARAM_LIST)
            .unwrap();
        assert_eq!(child_kinds(&params), [LT, IDENT, COMMA, INDEX_PARAM, GT]);
        let index = sum.index_params().next().unwrap();
        assert_eq!(child_kinds(index.syntax()), [NAME, TYPE_ANNOTATION]);
        assert_eq!(index.name().unwrap().text().as_deref(), Some("n"));
        assert_eq!(
            child_kinds(index.kind_annotation().unwrap().syntax()),
            [COLON_COLON, IDENT]
        );
        assert_eq!(
            index.syntax().text_range(),
            source_range(source, "n :: Nat")
        );

        let variants: Vec<_> = sum.variants().collect();
        let [empty, push] = variants.as_slice() else {
            panic!("expected two variants");
        };
        assert_eq!(child_kinds(empty.syntax()), [IDENT, ARROW, VARIANT_RESULT]);
        assert_eq!(empty.positional_types().count(), 0);
        assert_eq!(empty.fields().count(), 0);
        let result = empty.result_type().unwrap();
        assert_eq!(result.syntax().parent().unwrap().kind(), VARIANT_RESULT);
        assert_eq!(child_kinds(result.syntax()), [IDENT, GENERIC_ARG_LIST]);
        let args = result.syntax().first_child().unwrap();
        assert_eq!(child_kinds(&args), [LT, IDENT, COMMA, NAT_INDEX, GT]);
        let zero = args.first_child().unwrap();
        assert_eq!(child_kinds(&zero), [INT_LITERAL]);
        assert_eq!(zero.first_token().unwrap().text(), "0");
        assert_eq!(zero.text_range(), source_range(source, "0"));

        assert_eq!(
            child_kinds(push.syntax()),
            [
                IDENT,
                GENERIC_PARAM_LIST,
                L_PAREN,
                TYPE_ANNOTATION,
                COMMA,
                TYPE_ANNOTATION,
                R_PAREN,
                ARROW,
                VARIANT_RESULT
            ]
        );
        assert_eq!(
            push.index_params()
                .next()
                .unwrap()
                .name()
                .unwrap()
                .text()
                .as_deref(),
            Some("k")
        );
        assert_eq!(push.positional_types().count(), 2);
        let result = push.result_type().unwrap();
        assert_eq!(
            result.syntax().text_range(),
            source_range(source, "Vec<T, Succ<k>>")
        );
        let args = result.syntax().first_child().unwrap();
        assert_eq!(
            child_kinds(&args),
            [LT, IDENT, COMMA, IDENT, GENERIC_ARG_LIST, GT]
        );
        assert_eq!(child_kinds(&args.first_child().unwrap()), [LT, IDENT, GT]);
    }

    #[test]
    fn kinded_parameters_share_function_and_struct_generic_syntax() {
        use SyntaxKind::*;

        let source = "struct Buffer<T, n :: Nat,> do\n data :: Vec<T, n>\nend\n\
                      fn id<T, n :: Nat,>(x :: Vec<T, n>) -> Vec<T, n> = x\n";
        let parsed = crate::parse(source);
        assert!(parsed.ok(), "{:?}", parsed.errors());
        let declarations: Vec<_> = parsed.syntax().children().collect();
        let [structure, function] = declarations.as_slice() else {
            panic!("expected two declarations");
        };
        assert_eq!(structure.kind(), STRUCT_DEF);
        assert_eq!(function.kind(), FN_DEF);
        for decl in declarations {
            let params = decl
                .children()
                .find(|node| node.kind() == GENERIC_PARAM_LIST)
                .unwrap();
            assert_eq!(
                child_kinds(&params),
                [LT, IDENT, COMMA, INDEX_PARAM, COMMA, GT]
            );
        }
    }
}
