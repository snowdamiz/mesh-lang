-- Apply as the Jobs object owner after Jobs.migrate on the new runtime.
-- Set worker with psql -v to the scoped role running the opted-in worker.
GRANT EXECUTE ON FUNCTION mesh_jobs.complete_batch_v1(text,uuid[],uuid[]) TO :"worker";
