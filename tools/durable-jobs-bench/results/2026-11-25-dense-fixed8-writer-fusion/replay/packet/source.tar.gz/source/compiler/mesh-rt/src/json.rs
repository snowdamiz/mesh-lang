//! JSON encoding and decoding runtime functions for the Mesh standard library.
//!
//! Uses `serde_json` for parsing and serialization. Provides:
//! - `mesh_json_parse`: parse a JSON string into a MeshJson tagged union
//! - `mesh_json_encode`: convert a MeshJson back to a JSON string
//! - Convenience encode functions for primitives and collections
//! - ToJSON/FromJSON support functions for building Json values from Mesh types
//!
//! ## MeshJson representation
//!
//! At the runtime level, JSON values are represented as GC-allocated tagged unions:
//! ```text
//! MeshJson { tag: u8, value: u64 }
//! ```
//! Tags: 0=Null, 1=Bool, 2=Int(i64), 3=Str(*MeshString), 4=Array(*MeshList),
//! 5=Object(*MeshMap), 6=Float(f64), 7=UInt(u64)
//!
//! Every value of type `Json` is such a tree: a `json { }` literal builds
//! one, and a `Json` passed where a `String` is expected is encoded there by
//! the compiler.

use crate::collections::list;
use crate::collections::map;
use crate::gc::mesh_gc_alloc_actor;
use crate::io::{alloc_result, box_scalar, err_result, MeshResult};
use crate::string::{mesh_str, text_of, MeshString};

/// Tag constants for MeshJson variants.
const JSON_NULL: u8 = 0;
const JSON_BOOL: u8 = 1;
const JSON_INT: u8 = 2;
const JSON_STR: u8 = 3;
const JSON_ARRAY: u8 = 4;
const JSON_OBJECT: u8 = 5;
const JSON_FLOAT: u8 = 6;
const JSON_UINT: u8 = 7;

/// GC-allocated JSON value.
///
/// Layout: `{ tag: u8, _pad: [u8; 7], value: u64 }` -- 16 bytes total.
/// The padding ensures 8-byte alignment for the value field.
#[repr(C)]
pub struct MeshJson {
    pub tag: u8,
    _pad: [u8; 7],
    pub value: u64,
}

// ── Allocation helpers ──────────────────────────────────────────────

fn alloc_json(tag: u8, value: u64) -> *mut MeshJson {
    unsafe {
        let ptr = mesh_gc_alloc_actor(
            std::mem::size_of::<MeshJson>() as u64,
            std::mem::align_of::<MeshJson>() as u64,
        ) as *mut MeshJson;
        (*ptr).tag = tag;
        (*ptr)._pad = [0; 7];
        (*ptr).value = value;
        ptr
    }
}

// ── Conversion: JSON text <-> MeshJson ────────────────────────────

/// A `MeshJson` read from JSON text, built as it is parsed: an object keeps
/// its keys in the order the text has them, a repeated key its last value.
struct Parsed(*mut MeshJson);

impl<'de> serde::Deserialize<'de> for Parsed {
    fn deserialize<D: serde::Deserializer<'de>>(deserializer: D) -> Result<Self, D::Error> {
        deserializer.deserialize_any(ParsedVisitor)
    }
}

struct ParsedVisitor;

struct ObjectKey(*const MeshString);

impl<'de> serde::Deserialize<'de> for ObjectKey {
    fn deserialize<D: serde::Deserializer<'de>>(deserializer: D) -> Result<Self, D::Error> {
        deserializer.deserialize_str(ObjectKeyVisitor)
    }
}

struct ObjectKeyVisitor;

impl<'de> serde::de::Visitor<'de> for ObjectKeyVisitor {
    type Value = ObjectKey;

    fn expecting(&self, f: &mut std::fmt::Formatter) -> std::fmt::Result {
        f.write_str("a string")
    }

    fn visit_str<E>(self, key: &str) -> Result<ObjectKey, E> {
        // Escaped keys may borrow the deserializer's scratch buffer.
        Ok(ObjectKey(mesh_str(key)))
    }
}

impl<'de> serde::de::Visitor<'de> for ParsedVisitor {
    type Value = Parsed;

    fn expecting(&self, f: &mut std::fmt::Formatter) -> std::fmt::Result {
        f.write_str("a JSON value")
    }

    fn visit_unit<E>(self) -> Result<Parsed, E> {
        Ok(Parsed(alloc_json(JSON_NULL, 0)))
    }

    fn visit_bool<E>(self, b: bool) -> Result<Parsed, E> {
        Ok(Parsed(alloc_json(JSON_BOOL, b as u64)))
    }

    // Int and Float are separate tags for round-trip fidelity; an integer
    // past Int's range is a UInt.
    fn visit_i64<E>(self, i: i64) -> Result<Parsed, E> {
        Ok(Parsed(alloc_json(JSON_INT, i as u64)))
    }

    fn visit_u64<E>(self, u: u64) -> Result<Parsed, E> {
        let tag = if i64::try_from(u).is_ok() {
            JSON_INT
        } else {
            JSON_UINT
        };
        Ok(Parsed(alloc_json(tag, u)))
    }

    fn visit_f64<E>(self, f: f64) -> Result<Parsed, E> {
        Ok(Parsed(alloc_json(JSON_FLOAT, f.to_bits())))
    }

    fn visit_str<E>(self, s: &str) -> Result<Parsed, E> {
        Ok(Parsed(alloc_json(JSON_STR, mesh_str(s) as u64)))
    }

    fn visit_seq<A: serde::de::SeqAccess<'de>>(self, mut seq: A) -> Result<Parsed, A::Error> {
        let mut items = Vec::new();
        while let Some(Parsed(item)) = seq.next_element()? {
            items.push(item as u64);
        }
        let list = list::mesh_list_from_array(items.as_ptr(), items.len() as i64);
        Ok(Parsed(alloc_json(JSON_ARRAY, list as u64)))
    }

    fn visit_map<A: serde::de::MapAccess<'de>>(self, mut map: A) -> Result<Parsed, A::Error> {
        let mut entries = Vec::new();
        while let Some((ObjectKey(key), Parsed(value))) = map.next_entry()? {
            entries.push([key as u64, value as u64]);
        }
        let object = map::mesh_map_from_string_entries(&mut entries);
        Ok(Parsed(alloc_json(JSON_OBJECT, object as u64)))
    }
}

/// A `MeshJson` written as JSON text: an object's keys in its map's order
/// (a literal's as written, a parsed object's as the text had them). A float
/// that is not finite, and a node of no known tag, is `null`.
struct Tree(*const MeshJson, usize);

impl Tree {
    fn child(&self, pointer: u64) -> Self {
        Self(pointer as *const MeshJson, self.1 - 1)
    }
}

impl serde::Serialize for Tree {
    fn serialize<S: serde::Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
        use serde::ser::{Error, SerializeMap, SerializeSeq};
        if self.1 == 0 {
            return Err(S::Error::custom("JSON exceeds its depth limit"));
        }
        let (tag, value) = unsafe { ((*self.0).tag, (*self.0).value) };
        match tag {
            JSON_BOOL => serializer.serialize_bool(value != 0),
            JSON_INT => serializer.serialize_i64(value as i64),
            JSON_UINT => serializer.serialize_u64(value),
            JSON_FLOAT => serializer.serialize_f64(f64::from_bits(value)),
            JSON_STR => serializer.serialize_str(unsafe { text_of(value as *const MeshString) }),
            JSON_ARRAY => {
                let items = value as *mut u8;
                let len = list::mesh_list_length(items);
                let mut seq = serializer.serialize_seq(Some(len as usize))?;
                for i in 0..len {
                    seq.serialize_element(&self.child(list::mesh_list_get(items, i)))?;
                }
                seq.end()
            }
            JSON_OBJECT => {
                // A persistent view may need compacting once. Serialization
                // only reads those ordered entries and cannot run Mesh code.
                let (entries, len) = unsafe { map::entries(value as *mut u8) };
                let mut object = serializer.serialize_map(Some(len))?;
                for i in 0..len {
                    let [key, value] = unsafe { *entries.add(i) };
                    let key = unsafe { text_of(key as *const MeshString) };
                    object.serialize_entry(key, &self.child(value))?;
                }
                object.end()
            }
            _ => serializer.serialize_unit(),
        }
    }
}

// ── Public API: Parse ───────────────────────────────────────────────

/// Parse a JSON string into a MeshJson value.
///
/// Returns MeshResult:
/// - tag 0 (Ok): value = pointer to MeshJson
/// - tag 1 (Err): value = pointer to MeshString error message
#[no_mangle]
pub extern "C-unwind" fn mesh_json_parse(input: *const MeshString) -> *mut MeshResult {
    unsafe {
        let text = (*input).as_str();
        match serde_json::from_str::<Parsed>(text) {
            Ok(Parsed(json)) => alloc_result(0, json as *mut u8),
            Err(e) => err_result(&e.to_string()),
        }
    }
}

// ── Public API: Encode ──────────────────────────────────────────────

/// Encode a MeshJson value to a JSON string.
#[no_mangle]
pub extern "C-unwind" fn mesh_json_encode(json: *mut u8) -> *mut MeshString {
    // Keys are strings and a float that is not finite is `null`: nothing
    // fails to encode.
    let text = serde_json::to_string(&Tree(json.cast(), usize::MAX)).expect("a Json tree encodes");
    mesh_str(&text)
}

#[cfg(mesh_jobs_effects)]
pub(crate) unsafe fn bounded_json(
    value: *const MeshJson,
    max_depth: usize,
    max_bytes: usize,
) -> Result<Vec<u8>, String> {
    use std::io::{self, Write};

    struct Bounded {
        bytes: Vec<u8>,
        max: usize,
    }

    impl Write for Bounded {
        fn write(&mut self, bytes: &[u8]) -> io::Result<usize> {
            if bytes.len() > self.max - self.bytes.len() {
                return Err(io::Error::other("JSON exceeds its byte limit"));
            }
            self.bytes.extend_from_slice(bytes);
            Ok(bytes.len())
        }

        fn flush(&mut self) -> io::Result<()> {
            Ok(())
        }
    }

    let mut output = Bounded {
        bytes: Vec::new(),
        max: max_bytes,
    };
    serde_json::to_writer(&mut output, &Tree(value, max_depth))
        .map_err(|error| error.to_string())?;
    Ok(output.bytes)
}

// ── Convenience encode functions ────────────────────────────────────

/// Encode a Mesh string directly to a JSON string (with quotes).
#[no_mangle]
pub extern "C-unwind" fn mesh_json_encode_string(s: *const MeshString) -> *mut MeshString {
    unsafe {
        let json_text = serde_json::to_string((*s).as_str()).expect("a string encodes");
        mesh_str(&json_text)
    }
}

/// Encode an integer to a JSON string.
#[no_mangle]
pub extern "C-unwind" fn mesh_json_encode_int(val: i64) -> *mut MeshString {
    let text = val.to_string();
    mesh_str(&text)
}

/// Encode a boolean to a JSON string.
#[no_mangle]
pub extern "C-unwind" fn mesh_json_encode_bool(val: i8) -> *mut MeshString {
    let text = if val != 0 { "true" } else { "false" };
    mesh_str(text)
}

/// Encode a MeshMap to a JSON string.
///
/// Assumes map keys are MeshString pointers and values are MeshString pointers.
/// Produces a JSON object like `{"key1":"val1","key2":"val2"}`.
#[no_mangle]
pub extern "C-unwind" fn mesh_json_encode_map(map_ptr: *mut u8) -> *mut MeshString {
    unsafe {
        let keys = map::mesh_map_keys(map_ptr);
        let vals = map::mesh_map_values(map_ptr);
        let len = list::mesh_list_length(keys);
        let mut obj = serde_json::Map::new();
        for i in 0..len {
            let key = list::mesh_list_get(keys, i) as *const MeshString;
            let val = list::mesh_list_get(vals, i) as *const MeshString;
            let key_str = (*key).as_str().to_string();
            let val_str = (*val).as_str().to_string();
            obj.insert(key_str, serde_json::Value::String(val_str));
        }
        let text = serde_json::to_string(&serde_json::Value::Object(obj))
            .unwrap_or_else(|_| "{}".to_string());
        mesh_str(&text)
    }
}

/// Encode a MeshList of strings to a JSON array string.
///
/// Assumes list elements are MeshString pointers.
/// Produces a JSON array like `["a","b","c"]`.
#[no_mangle]
pub extern "C-unwind" fn mesh_json_encode_list(list_ptr: *mut u8) -> *mut MeshString {
    unsafe {
        let len = list::mesh_list_length(list_ptr);
        let mut arr = Vec::with_capacity(len as usize);
        for i in 0..len {
            let elem = list::mesh_list_get(list_ptr, i) as *const MeshString;
            let text = (*elem).as_str().to_string();
            arr.push(serde_json::Value::String(text));
        }
        let text = serde_json::to_string(&serde_json::Value::Array(arr))
            .unwrap_or_else(|_| "[]".to_string());
        mesh_str(&text)
    }
}

// ── ToJSON/FromJSON support ─────────────────────────────────────────

/// Create a MeshJson Int from an i64.
#[no_mangle]
pub extern "C-unwind" fn mesh_json_from_int(val: i64) -> *mut u8 {
    alloc_json(JSON_INT, val as u64) as *mut u8
}

/// Create a MeshJson Float from an f64.
#[no_mangle]
pub extern "C-unwind" fn mesh_json_from_float(val: f64) -> *mut u8 {
    alloc_json(JSON_FLOAT, val.to_bits()) as *mut u8
}

/// Create a MeshJson Bool from an i8 (0 = false, non-zero = true).
#[no_mangle]
pub extern "C-unwind" fn mesh_json_from_bool(val: i8) -> *mut u8 {
    alloc_json(JSON_BOOL, if val != 0 { 1 } else { 0 }) as *mut u8
}

/// Create a MeshJson Str from a MeshString.
#[no_mangle]
pub extern "C-unwind" fn mesh_json_from_string(s: *const MeshString) -> *mut u8 {
    alloc_json(JSON_STR, s as u64) as *mut u8
}

// ── Structured JSON object/array functions (Phase 49) ───────────────

/// Create an empty JSON object.
/// Uses string-typed map (KEY_TYPE_STR) so key lookups use content comparison.
#[no_mangle]
pub extern "C-unwind" fn mesh_json_object_new() -> *mut u8 {
    let m = map::mesh_map_new_typed(1);
    alloc_json(JSON_OBJECT, m as u64) as *mut u8
}

/// Add a key-value pair to a JSON object. Returns a new JSON object.
#[no_mangle]
pub extern "C-unwind" fn mesh_json_object_put(obj: *mut u8, key: *mut u8, val: *mut u8) -> *mut u8 {
    unsafe {
        let j = obj as *mut MeshJson;
        let m = (*j).value as *mut u8;
        let new_map = map::mesh_map_put(m, key as u64, val as u64);
        alloc_json(JSON_OBJECT, new_map as u64) as *mut u8
    }
}

/// Get a value from a JSON object by key. Returns MeshResult (Ok/Err).
#[no_mangle]
pub extern "C-unwind" fn mesh_json_object_get(obj: *mut u8, key: *mut u8) -> *mut u8 {
    unsafe {
        let j = obj.cast::<MeshJson>();
        if (*j).tag != JSON_OBJECT {
            return err_result("expected Object");
        }
        let m = (*j).value as *mut u8;
        // JSON null is itself a nonzero node pointer.
        let val = map::mesh_map_get(m, key as u64);
        if val != 0 {
            alloc_result(0, val as *mut u8) as *mut u8
        } else {
            let key_str = key as *const MeshString;
            err_result(&format!("missing field: {}", (*key_str).as_str()))
        }
    }
}

/// Create an empty JSON array.
#[no_mangle]
pub extern "C-unwind" fn mesh_json_array_new() -> *mut u8 {
    let l = list::mesh_list_new();
    alloc_json(JSON_ARRAY, l as u64) as *mut u8
}

/// Append a value to a JSON array. Returns a new JSON array.
#[no_mangle]
pub extern "C-unwind" fn mesh_json_array_push(arr: *mut u8, val: *mut u8) -> *mut u8 {
    unsafe {
        let j = arr as *mut MeshJson;
        let l = (*j).value as *mut u8;
        let new_list = list::mesh_list_append(l, val as u64);
        alloc_json(JSON_ARRAY, new_list as u64) as *mut u8
    }
}

/// Extract an Int from a MeshJson value. Returns MeshResult.
/// Coerces Float to Int if needed.
#[no_mangle]
pub extern "C-unwind" fn mesh_json_as_int(json: *mut u8) -> *mut u8 {
    unsafe {
        let j = json.cast::<MeshJson>();
        match (*j).tag {
            JSON_INT => alloc_result(0, (*j).value as i64 as *mut u8) as *mut u8,
            // A number written with a fraction or exponent is an Int only when
            // it is a whole number an Int can hold (not 1.9, not 1e30).
            JSON_FLOAT => {
                let f = f64::from_bits((*j).value);
                if f.fract() == 0.0
                    && (-9.223_372_036_854_776e18..9.223_372_036_854_776e18).contains(&f)
                {
                    alloc_result(0, f as i64 as *mut u8) as *mut u8
                } else {
                    err_result("expected Int")
                }
            }
            _ => err_result("expected Int"),
        }
    }
}

/// Extract a Float from a MeshJson value. Returns MeshResult.
/// Promotes Int to Float if needed.
#[no_mangle]
pub extern "C-unwind" fn mesh_json_as_float(json: *mut u8) -> *mut u8 {
    unsafe {
        let j = json.cast::<MeshJson>();
        match (*j).tag {
            JSON_FLOAT => alloc_result(0, (*j).value as *mut u8) as *mut u8,
            JSON_INT => {
                let i = (*j).value as i64;
                let f = (i as f64).to_bits();
                alloc_result(0, f as *mut u8) as *mut u8
            }
            JSON_UINT => {
                let f = ((*j).value as f64).to_bits();
                alloc_result(0, f as *mut u8) as *mut u8
            }
            _ => err_result("expected Float"),
        }
    }
}

/// Extract a String from a MeshJson value. Returns MeshResult.
#[no_mangle]
pub extern "C-unwind" fn mesh_json_as_string(json: *mut u8) -> *mut u8 {
    unsafe {
        let j = json.cast::<MeshJson>();
        if (*j).tag == JSON_STR {
            alloc_result(0, (*j).value as *mut u8) as *mut u8
        } else {
            err_result("expected String")
        }
    }
}

/// Extract a Bool from a MeshJson value. Returns MeshResult.
#[no_mangle]
pub extern "C-unwind" fn mesh_json_as_bool(json: *mut u8) -> *mut u8 {
    unsafe {
        let j = json.cast::<MeshJson>();
        if (*j).tag == JSON_BOOL {
            alloc_result(0, (*j).value as *mut u8) as *mut u8
        } else {
            err_result("expected Bool")
        }
    }
}

fn boxed_scalar_result<T: Copy>(value: T) -> *mut u8 {
    alloc_result(0, box_scalar(value)).cast()
}

/// Public `Json.as_int` ABI. Unlike the internal deriving helper above, this
/// boxes the scalar payload for ordinary Mesh `Result` pattern matching.
#[no_mangle]
pub extern "C-unwind" fn mesh_json_value_as_int(json: *mut u8) -> *mut u8 {
    unsafe {
        let result = mesh_json_as_int(json) as *mut MeshResult;
        if (*result).tag == 0 {
            boxed_scalar_result((*result).value as i64)
        } else {
            result.cast()
        }
    }
}

/// Public `Json.as_float` ABI.
#[no_mangle]
pub extern "C-unwind" fn mesh_json_value_as_float(json: *mut u8) -> *mut u8 {
    unsafe {
        let result = mesh_json_as_float(json) as *mut MeshResult;
        if (*result).tag == 0 {
            boxed_scalar_result(f64::from_bits((*result).value as u64))
        } else {
            result.cast()
        }
    }
}

/// Public `Json.as_bool` ABI.
#[no_mangle]
pub extern "C-unwind" fn mesh_json_value_as_bool(json: *mut u8) -> *mut u8 {
    unsafe {
        let result = mesh_json_as_bool(json) as *mut MeshResult;
        if (*result).tag == 0 {
            boxed_scalar_result(!(*result).value.is_null())
        } else {
            result.cast()
        }
    }
}

#[no_mangle]
pub extern "C-unwind" fn mesh_json_array_length(json: *mut u8) -> *mut u8 {
    unsafe {
        let json = json.cast::<MeshJson>();
        if (*json).tag != JSON_ARRAY {
            return err_result("expected Array");
        }
        boxed_scalar_result(list::mesh_list_length((*json).value as *mut u8))
    }
}

/// `a == b` for two `Json` values: the same kind holding equal contents, an
/// object's keys in any order. `1` and `1.0` differ, as `Json.parse` tells
/// them apart.
#[no_mangle]
pub extern "C-unwind" fn mesh_json_eq(a: *mut u8, b: *mut u8) -> i8 {
    unsafe { json_eq(a.cast(), b.cast()) as i8 }
}

unsafe fn json_eq(a: *const MeshJson, b: *const MeshJson) -> bool {
    let ((tag, x), (other_tag, y)) = (((*a).tag, (*a).value), ((*b).tag, (*b).value));
    if tag != other_tag {
        return false;
    }
    match tag {
        JSON_FLOAT => f64::from_bits(x) == f64::from_bits(y),
        JSON_STR => text_of(x as *const MeshString) == text_of(y as *const MeshString),
        JSON_ARRAY => {
            let (x, y) = (x as *mut u8, y as *mut u8);
            let len = list::mesh_list_length(x);
            len == list::mesh_list_length(y)
                && (0..len).all(|i| {
                    json_eq(
                        list::mesh_list_get(x, i) as *const MeshJson,
                        list::mesh_list_get(y, i) as *const MeshJson,
                    )
                })
        }
        JSON_OBJECT => map::mesh_map_eq(x as *mut u8, y as *mut u8, json_slot_eq as *mut u8) != 0,
        // null, Bool, Int and UInt are their word.
        _ => x == y,
    }
}

/// `json_eq` over two map value slots, for `mesh_map_eq`.
extern "C-unwind" fn json_slot_eq(a: u64, b: u64) -> i8 {
    unsafe { json_eq(a as *const MeshJson, b as *const MeshJson) as i8 }
}

#[no_mangle]
pub extern "C-unwind" fn mesh_json_is_null(json: *mut u8) -> i8 {
    unsafe { ((*json.cast::<MeshJson>()).tag == JSON_NULL) as i8 }
}

/// Return a MeshJson null value. Used for Option::None encoding.
#[no_mangle]
pub extern "C-unwind" fn mesh_json_null() -> *mut u8 {
    alloc_json(JSON_NULL, 0) as *mut u8
}

/// Extract an element at the given index from a JSON array. Returns MeshResult.
/// Ok(element) on success, Err(message) if not an array or index out of bounds.
#[no_mangle]
pub extern "C-unwind" fn mesh_json_array_get(json_arr: *mut u8, index: i64) -> *mut u8 {
    unsafe {
        let j = json_arr.cast::<MeshJson>();
        if (*j).tag != JSON_ARRAY {
            return err_result("expected Array");
        }
        let inner_list = (*j).value as *mut u8;
        let len = list::mesh_list_length(inner_list);
        if index < 0 || index >= len {
            return err_result(&format!(
                "array index {} out of bounds (length {})",
                index, len
            ));
        }
        let elem = list::mesh_list_get(inner_list, index);
        alloc_result(0, elem as *mut u8) as *mut u8
    }
}

// ── Collection helpers (Phase 49) ───────────────────────────────────

/// Convert a MeshList to a JSON array using a per-element callback.
/// `elem_fn` converts each list element (u64) to a *mut MeshJson.
#[no_mangle]
pub extern "C-unwind" fn mesh_json_from_list(
    list_ptr: *mut u8,
    elem_fn: extern "C-unwind" fn(u64) -> *mut u8,
) -> *mut u8 {
    let len = list::mesh_list_length(list_ptr);
    let mut arr = list::mesh_list_builder_new(len);
    for i in 0..len {
        let elem = list::mesh_list_get(list_ptr, i);
        let json_elem = elem_fn(elem);
        arr = list::mesh_list_builder_push(arr, json_elem as u64);
    }
    alloc_json(JSON_ARRAY, arr as u64).cast()
}

/// Convert a MeshMap to a JSON object using a per-value callback.
/// Keys must be MeshString pointers. `val_fn` converts each value (u64) to a *mut MeshJson.
#[no_mangle]
pub extern "C-unwind" fn mesh_json_from_map(
    map_ptr: *mut u8,
    val_fn: extern "C-unwind" fn(u64) -> *mut u8,
) -> *mut u8 {
    let keys_list = map::mesh_map_keys(map_ptr);
    let vals_list = map::mesh_map_values(map_ptr);
    let len = list::mesh_list_length(keys_list);
    let mut obj = mesh_json_object_new();
    for i in 0..len {
        let key = list::mesh_list_get(keys_list, i);
        let val = list::mesh_list_get(vals_list, i);
        let json_key = key as *mut u8; // MeshString pointer used as map key
        let json_val = val_fn(val);
        obj = mesh_json_object_put(obj, json_key, json_val);
    }
    obj
}

/// Decode a JSON array into a MeshList using a per-element callback.
/// `elem_fn` converts each *mut MeshJson to a *mut MeshResult.
/// Returns MeshResult: Ok(MeshList) or Err on first element failure.
#[no_mangle]
pub extern "C-unwind" fn mesh_json_to_list(
    json_arr: *mut u8,
    elem_fn: extern "C-unwind" fn(*mut u8) -> *mut u8,
) -> *mut u8 {
    unsafe {
        let j = json_arr.cast::<MeshJson>();
        if (*j).tag != JSON_ARRAY {
            return err_result("expected Array");
        }
        let inner_list = (*j).value as *mut u8;
        let len = list::mesh_list_length(inner_list);
        let mut result_list = list::mesh_list_builder_new(len);
        for i in 0..len {
            let elem = list::mesh_list_get(inner_list, i);
            let decoded = elem_fn(elem as *mut u8);
            let res = decoded as *mut MeshResult;
            if (*res).tag != 0 {
                return located(decoded, &format!("[{i}]"));
            }
            result_list = list::mesh_list_builder_push(result_list, (*res).value as u64);
        }
        alloc_result(0, result_list) as *mut u8
    }
}

/// Decode a JSON object into a MeshMap using a per-value callback.
/// Keys remain as MeshStrings. `val_fn` converts each *mut MeshJson to a *mut MeshResult.
/// Returns MeshResult: Ok(MeshMap) or Err on first value failure.
#[no_mangle]
pub extern "C-unwind" fn mesh_json_to_map(
    json_obj: *mut u8,
    val_fn: extern "C-unwind" fn(*mut u8) -> *mut u8,
) -> *mut u8 {
    unsafe {
        let j = json_obj.cast::<MeshJson>();
        if (*j).tag != JSON_OBJECT {
            return err_result("expected Object");
        }
        let inner_map = (*j).value as *mut u8;
        let keys_list = map::mesh_map_keys(inner_map);
        let vals_list = map::mesh_map_values(inner_map);
        let len = list::mesh_list_length(keys_list);
        // JSON object keys are strings: compare them by content.
        let mut result_map = map::mesh_map_new_typed(1);
        for i in 0..len {
            let key = list::mesh_list_get(keys_list, i);
            let val = list::mesh_list_get(vals_list, i);
            let decoded = val_fn(val as *mut u8);
            let res = decoded as *mut MeshResult;
            if (*res).tag != 0 {
                return located(decoded, &format!(".{}", text_of(key as *const MeshString)));
            }
            result_map = map::mesh_map_put(result_map, key, (*res).value as u64);
        }
        alloc_result(0, result_map) as *mut u8
    }
}

/// `decoded`, a decoding's Result, with `step` (a struct field's `.name`,
/// a tuple element's `[index]`) put at the front of the path its error
/// names: `$.home.zip: expected String`.
#[no_mangle]
pub extern "C-unwind" fn mesh_json_error_at(decoded: *mut u8, step: *const MeshString) -> *mut u8 {
    unsafe { located(decoded, text_of(step)) }
}

/// `decoded`, with `step` (`.name` or `[index]`) put at the front of the
/// path an error names; an error with no path yet gets one. Ok passes.
unsafe fn located(decoded: *mut u8, step: &str) -> *mut u8 {
    let result = decoded as *mut MeshResult;
    if (*result).tag == 0 {
        return decoded;
    }
    let message = text_of((*result).value as *const MeshString);
    match message.strip_prefix('$') {
        Some(path) => err_result(&format!("${step}{path}")),
        None => err_result(&format!("${step}: {message}")),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::gc::mesh_rt_init;

    /// The text of a failed `MeshResult`, or `None` for an `Ok`.
    fn error_of(result: *mut u8) -> Option<String> {
        let result = unsafe { &*(result as *const MeshResult) };
        (result.tag == 1)
            .then(|| unsafe { (*(result.value as *const MeshString)).as_str() }.to_string())
    }

    extern "C-unwind" fn never_called(_json: *mut u8) -> *mut u8 {
        unreachable!("no element to decode")
    }

    /// Each accessor refuses a value of another kind, by name.
    #[test]
    fn accessors_refuse_values_of_another_kind() {
        mesh_rt_init();
        let null = mesh_json_null();
        let key = mesh_str("k") as *mut u8;
        for (result, expected) in [
            (mesh_json_object_get(null, key), "expected Object"),
            (mesh_json_value_as_int(null), "expected Int"),
            (mesh_json_value_as_float(null), "expected Float"),
            (mesh_json_value_as_bool(null), "expected Bool"),
            (mesh_json_array_length(null), "expected Array"),
            (mesh_json_to_list(null, never_called), "expected Array"),
            (mesh_json_to_map(null, never_called), "expected Object"),
        ] {
            assert_eq!(error_of(result).as_deref(), Some(expected));
        }
    }

    /// An integer above i64::MAX is read as a Float too; a value of no known
    /// kind encodes as null.
    #[test]
    fn a_large_integer_as_a_float_and_an_unknown_value_as_null() {
        mesh_rt_init();
        let parsed = mesh_json_parse(mesh_str("18446744073709551615"));
        let big = unsafe { (*parsed).value };
        let float = mesh_json_value_as_float(big) as *const MeshResult;
        assert_eq!(unsafe { *((*float).value as *const f64) }, u64::MAX as f64);
        let unknown = alloc_json(99, 0) as *mut u8;
        assert_eq!(unsafe { (*mesh_json_encode(unknown)).as_str() }, "null");
        let infinite = alloc_json(JSON_FLOAT, f64::INFINITY.to_bits()) as *mut u8;
        assert_eq!(unsafe { (*mesh_json_encode(infinite)).as_str() }, "null");
    }

    /// Negative numbers (serde's `visit_i64`), floats compared, and what a
    /// parse expects when handed something no JSON text holds.
    #[test]
    fn negative_numbers_and_floats_read_and_compare() {
        use serde::Deserialize;
        mesh_rt_init();
        let parsed = |text: &str| unsafe { (*mesh_json_parse(mesh_str(text))).value };
        let negative = parsed("-5");
        assert_eq!(
            unsafe {
                (
                    (*(negative as *const MeshJson)).tag,
                    (*(negative as *const MeshJson)).value as i64,
                )
            },
            (JSON_INT, -5)
        );
        assert_eq!(mesh_json_eq(parsed("1.5"), parsed("1.5")), 1);
        assert_eq!(mesh_json_eq(parsed("1.5"), parsed("2.5")), 0);
        let bytes = serde::de::value::BytesDeserializer::<serde::de::value::Error>::new(b"x");
        let error = Parsed::deserialize(bytes).err().unwrap();
        assert!(
            error.to_string().contains("expected a JSON value"),
            "{error}"
        );
    }

    #[test]
    fn test_json_parse_object() {
        mesh_rt_init();
        let input = mesh_str(r#"{"name":"Mesh","version":1}"#);
        let result = mesh_json_parse(input);
        unsafe {
            assert_eq!((*result).tag, 0, "parse should succeed");
            let json = (*result).value as *const MeshJson;
            assert_eq!((*json).tag, JSON_OBJECT, "should be an object");
        }
    }

    #[test]
    fn test_json_parse_array() {
        mesh_rt_init();
        let input = mesh_str(r#"[1, 2, 3]"#);
        let result = mesh_json_parse(input);
        unsafe {
            assert_eq!((*result).tag, 0, "parse should succeed");
            let json = (*result).value as *const MeshJson;
            assert_eq!((*json).tag, JSON_ARRAY, "should be an array");
        }
    }

    #[test]
    fn test_json_parse_primitives() {
        mesh_rt_init();

        // null
        let result = mesh_json_parse(mesh_str("null"));
        unsafe {
            assert_eq!((*result).tag, 0);
            let json = (*result).value as *const MeshJson;
            assert_eq!((*json).tag, JSON_NULL);
        }

        // boolean
        let result = mesh_json_parse(mesh_str("true"));
        unsafe {
            assert_eq!((*result).tag, 0);
            let json = (*result).value as *const MeshJson;
            assert_eq!((*json).tag, JSON_BOOL);
            assert_eq!((*json).value, 1);
        }

        // number (integer)
        let result = mesh_json_parse(mesh_str("42"));
        unsafe {
            assert_eq!((*result).tag, 0);
            let json = (*result).value as *const MeshJson;
            assert_eq!((*json).tag, JSON_INT);
            assert_eq!((*json).value as i64, 42);
        }

        // unsigned number outside the signed range
        let result = mesh_json_parse(mesh_str("18446744073709551615"));
        unsafe {
            assert_eq!((*result).tag, 0);
            let json = (*result).value as *const MeshJson;
            assert_eq!((*json).tag, JSON_UINT);
            assert_eq!((*json).value, u64::MAX);
            let encoded = mesh_json_encode(json.cast_mut().cast());
            assert_eq!((*encoded).as_str(), "18446744073709551615");
        }

        // string
        let result = mesh_json_parse(mesh_str(r#""hello""#));
        unsafe {
            assert_eq!((*result).tag, 0);
            let json = (*result).value as *const MeshJson;
            assert_eq!((*json).tag, JSON_STR);
            let s = (*json).value as *const MeshString;
            assert_eq!((*s).as_str(), "hello");
        }
    }

    #[test]
    fn test_json_parse_invalid() {
        mesh_rt_init();
        let input = mesh_str("{invalid json}");
        let result = mesh_json_parse(input);
        unsafe {
            assert_eq!((*result).tag, 1, "parse should fail");
            let err_msg = (*result).value as *const MeshString;
            assert!(!err_msg.is_null());
            // Should contain some error message
            let msg = (*err_msg).as_str();
            assert!(!msg.is_empty(), "error message should not be empty");
        }
    }

    #[test]
    fn test_json_encode_roundtrip() {
        mesh_rt_init();
        let input = mesh_str(r#"{"a":1,"b":"hello","c":true}"#);
        let result = mesh_json_parse(input);
        unsafe {
            assert_eq!((*result).tag, 0);
            let json = (*result).value;
            let encoded = mesh_json_encode(json);
            let text = (*encoded).as_str();
            // Parse again to verify valid JSON
            let reparsed: serde_json::Value = serde_json::from_str(text).unwrap();
            assert_eq!(reparsed["a"], 1);
            assert_eq!(reparsed["b"], "hello");
            assert_eq!(reparsed["c"], true);
        }
    }

    #[test]
    fn test_json_parse_nested_collections_and_duplicate_keys() {
        for text in [
            "[]",
            "{}",
            r#"[1,{"a":[null,true,"雪"]},[]]"#,
            r#"{"z":0,"a":1,"a":2}"#,
        ] {
            let expected: serde_json::Value = serde_json::from_str(text).unwrap();
            let result = mesh_json_parse(mesh_str(text));
            unsafe {
                assert_eq!((*result).tag, 0);
                let encoded = mesh_json_encode((*result).value);
                assert_eq!(
                    serde_json::from_str::<serde_json::Value>((*encoded).as_str()).unwrap(),
                    expected
                );
                if expected.get("a").is_some() {
                    let field = mesh_json_object_get((*result).value, mesh_str("a").cast());
                    let field = &*(field as *const MeshResult);
                    assert_eq!(field.tag, 0);
                    assert_eq!((*(field.value as *const MeshJson)).value, 2);
                }
            }
        }
    }

    #[test]
    fn parsed_keys_keep_their_first_position_after_unescaping() {
        mesh_rt_init();
        for count in [0, 4, 8, 24] {
            let mut members = String::new();
            for i in 0..count {
                members.push_str(&format!(r#","k{i}":{i}"#));
            }
            let input = format!(
                r#"{{"雪":0{members},"\u96ea":[-9223372036854775808,18446744073709551615,-0.0,{{"\ud83d\ude03":"\u0000"}}]}}"#
            );
            let expected = format!(
                r#"{{"雪":[-9223372036854775808,18446744073709551615,-0.0,{{"😃":"\u0000"}}]{members}}}"#
            );
            unsafe {
                let result = &*mesh_json_parse(mesh_str(&input));
                assert_eq!(result.tag, 0);
                assert_eq!((*mesh_json_encode(result.value)).as_str(), expected);
                let field = &*mesh_json_object_get(result.value, mesh_str("雪").cast())
                    .cast::<MeshResult>();
                assert_eq!(field.tag, 0);
                assert_eq!((*field.value.cast::<MeshJson>()).tag, JSON_ARRAY);
            }
        }
    }

    #[test]
    fn object_encoding_reads_each_persistent_version_in_order() {
        mesh_rt_init();
        let members: Vec<_> = (0..12).map(|i| format!(r#""k{i}":{i}"#)).collect();
        let input = format!("{{{}}}", members.join(","));
        unsafe {
            let parsed = &*mesh_json_parse(mesh_str(&input));
            assert_eq!(parsed.tag, 0);
            // The first update may append to the parsed map's table. The
            // second starts again from the older value.
            let replaced =
                mesh_json_object_put(parsed.value, mesh_str("k0").cast(), mesh_json_null());
            let added =
                mesh_json_object_put(parsed.value, mesh_str("new").cast(), mesh_json_from_int(42));
            let null = &*mesh_json_object_get(replaced, mesh_str("k0").cast()).cast::<MeshResult>();
            assert_eq!(null.tag, 0);
            assert_eq!((*null.value.cast::<MeshJson>()).tag, JSON_NULL);
            assert_eq!(
                (*mesh_json_encode(replaced)).as_str(),
                input.replacen(r#""k0":0"#, r#""k0":null"#, 1)
            );
            assert_eq!(
                (*mesh_json_encode(added)).as_str(),
                format!(r#"{},"new":42}}"#, &input[..input.len() - 1])
            );
            assert_eq!((*mesh_json_encode(parsed.value)).as_str(), input);
        }
    }

    #[cfg(mesh_jobs_effects)]
    #[test]
    fn bounded_object_encoding_checks_nested_depth_and_bytes() {
        mesh_rt_init();
        let input = r#"{"雪":[1]}"#;
        unsafe {
            let parsed = &*mesh_json_parse(mesh_str(input));
            assert_eq!(parsed.tag, 0);
            let tree = parsed.value.cast::<MeshJson>();
            assert_eq!(
                bounded_json(tree, 3, input.len()).unwrap(),
                input.as_bytes()
            );
            assert!(bounded_json(tree, 3, input.len() - 1)
                .unwrap_err()
                .contains("byte limit"));
            assert!(bounded_json(tree, 2, input.len())
                .unwrap_err()
                .contains("depth limit"));
        }
    }

    #[test]
    fn test_json_encode_string() {
        mesh_rt_init();
        let s = mesh_str("hello world");
        let encoded = mesh_json_encode_string(s);
        unsafe {
            assert_eq!((*encoded).as_str(), r#""hello world""#);
        }
    }

    #[test]
    fn test_json_encode_int() {
        mesh_rt_init();
        let encoded = mesh_json_encode_int(42);
        unsafe {
            assert_eq!((*encoded).as_str(), "42");
        }
    }

    #[test]
    fn test_json_encode_bool() {
        mesh_rt_init();
        let t = mesh_json_encode_bool(1);
        let f = mesh_json_encode_bool(0);
        unsafe {
            assert_eq!((*t).as_str(), "true");
            assert_eq!((*f).as_str(), "false");
        }
    }

    #[test]
    fn test_json_encode_map() {
        mesh_rt_init();
        let key1 = mesh_str("name");
        let val1 = mesh_str("Mesh");
        let key2 = mesh_str("lang");
        let val2 = mesh_str("rust");

        let mut m = map::mesh_map_new();
        m = map::mesh_map_put(m, key1 as u64, val1 as u64);
        m = map::mesh_map_put(m, key2 as u64, val2 as u64);

        let encoded = mesh_json_encode_map(m);
        unsafe {
            let text = (*encoded).as_str();
            let parsed: serde_json::Value = serde_json::from_str(text).unwrap();
            assert_eq!(parsed["name"], "Mesh");
            assert_eq!(parsed["lang"], "rust");
        }
    }

    #[test]
    fn test_json_from_int() {
        mesh_rt_init();
        let json = mesh_json_from_int(99) as *const MeshJson;
        unsafe {
            assert_eq!((*json).tag, JSON_INT);
            assert_eq!((*json).value as i64, 99);
        }
    }

    #[test]
    fn test_json_from_bool() {
        mesh_rt_init();
        let json_true = mesh_json_from_bool(1) as *const MeshJson;
        let json_false = mesh_json_from_bool(0) as *const MeshJson;
        unsafe {
            assert_eq!((*json_true).tag, JSON_BOOL);
            assert_eq!((*json_true).value, 1);
            assert_eq!((*json_false).tag, JSON_BOOL);
            assert_eq!((*json_false).value, 0);
        }
    }

    #[test]
    fn test_json_from_string() {
        mesh_rt_init();
        let s = mesh_str("hello");
        let json = mesh_json_from_string(s) as *const MeshJson;
        unsafe {
            assert_eq!((*json).tag, JSON_STR);
            let str_ptr = (*json).value as *const MeshString;
            assert_eq!((*str_ptr).as_str(), "hello");
        }
    }

    #[test]
    fn test_json_encode_list() {
        mesh_rt_init();
        let s1 = mesh_str("a");
        let s2 = mesh_str("b");
        let s3 = mesh_str("c");

        let mut l = list::mesh_list_new();
        l = list::mesh_list_append(l, s1 as u64);
        l = list::mesh_list_append(l, s2 as u64);
        l = list::mesh_list_append(l, s3 as u64);

        let encoded = mesh_json_encode_list(l);
        unsafe {
            let text = (*encoded).as_str();
            assert_eq!(text, r#"["a","b","c"]"#);
        }
    }

    // ── Phase 49 structured JSON tests ──────────────────────────────

    #[test]
    fn test_json_object_new_put_get_roundtrip() {
        mesh_rt_init();
        let mut obj = mesh_json_object_new();
        let key = mesh_str("name") as *mut u8;
        let val = mesh_json_from_string(mesh_str("Mesh"));
        obj = mesh_json_object_put(obj, key, val);

        // Get the value back
        let result = mesh_json_object_get(obj, key);
        unsafe {
            let res = result as *mut MeshResult;
            assert_eq!((*res).tag, 0, "should be Ok");
            let got_json = (*res).value as *const MeshJson;
            assert_eq!((*got_json).tag, JSON_STR);
            let s = (*got_json).value as *const MeshString;
            assert_eq!((*s).as_str(), "Mesh");
        }
    }

    #[test]
    fn test_json_object_get_missing_key() {
        mesh_rt_init();
        let obj = mesh_json_object_new();
        let key = mesh_str("nonexistent") as *mut u8;
        let result = mesh_json_object_get(obj, key);
        unsafe {
            let res = result as *mut MeshResult;
            assert_eq!((*res).tag, 1, "should be Err for missing key");
        }
    }

    #[test]
    fn test_json_array_new_push() {
        mesh_rt_init();
        let mut arr = mesh_json_array_new();
        arr = mesh_json_array_push(arr, mesh_json_from_int(1));
        arr = mesh_json_array_push(arr, mesh_json_from_int(2));

        // Encode and verify
        let encoded = mesh_json_encode(arr);
        unsafe {
            let text = (*encoded).as_str();
            assert_eq!(text, "[1,2]");
        }
    }

    #[test]
    fn test_json_as_int_from_int() {
        mesh_rt_init();
        let json = mesh_json_from_int(42);
        let result = mesh_json_as_int(json);
        unsafe {
            let res = result as *mut MeshResult;
            assert_eq!((*res).tag, 0);
            assert_eq!((*res).value as i64, 42);
        }
    }

    #[test]
    fn test_json_as_int_from_float() {
        mesh_rt_init();
        // A whole number is an Int; a fraction or an out-of-range number is not.
        let result = mesh_json_as_int(mesh_json_from_float(3.0));
        unsafe {
            let res = result as *mut MeshResult;
            assert_eq!((*res).tag, 0);
            assert_eq!((*res).value as i64, 3);
        }
        for f in [3.7, 1e30, -1e30, f64::NAN] {
            let result = mesh_json_as_int(mesh_json_from_float(f));
            unsafe {
                assert_eq!((*(result as *mut MeshResult)).tag, 1, "{f}");
            }
        }
    }

    #[test]
    fn test_json_as_int_from_string_error() {
        mesh_rt_init();
        let json = mesh_json_from_string(mesh_str("hello"));
        let result = mesh_json_as_int(json);
        unsafe {
            let res = result as *mut MeshResult;
            assert_eq!((*res).tag, 1, "should be Err");
        }
    }

    #[test]
    fn test_json_as_float_from_float() {
        mesh_rt_init();
        let json = mesh_json_from_float(2.5);
        let result = mesh_json_as_float(json);
        unsafe {
            let res = result as *mut MeshResult;
            assert_eq!((*res).tag, 0);
            let bits = (*res).value as u64;
            let f = f64::from_bits(bits);
            assert!((f - 2.5).abs() < f64::EPSILON);
        }
    }

    #[test]
    fn test_json_as_float_from_int() {
        mesh_rt_init();
        let json = mesh_json_from_int(5);
        let result = mesh_json_as_float(json);
        unsafe {
            let res = result as *mut MeshResult;
            assert_eq!((*res).tag, 0);
            let bits = (*res).value as u64;
            let f = f64::from_bits(bits);
            assert!((f - 5.0).abs() < f64::EPSILON);
        }
    }

    #[test]
    fn test_json_as_string_happy() {
        mesh_rt_init();
        let json = mesh_json_from_string(mesh_str("world"));
        let result = mesh_json_as_string(json);
        unsafe {
            let res = result as *mut MeshResult;
            assert_eq!((*res).tag, 0);
            let s = (*res).value as *const MeshString;
            assert_eq!((*s).as_str(), "world");
        }
    }

    #[test]
    fn test_json_as_string_error() {
        mesh_rt_init();
        let json = mesh_json_from_int(42);
        let result = mesh_json_as_string(json);
        unsafe {
            let res = result as *mut MeshResult;
            assert_eq!((*res).tag, 1, "should be Err for non-string");
        }
    }

    #[test]
    fn test_json_as_bool() {
        mesh_rt_init();
        let json = mesh_json_from_bool(1);
        let result = mesh_json_as_bool(json);
        unsafe {
            let res = result as *mut MeshResult;
            assert_eq!((*res).tag, 0);
            assert_eq!((*res).value as u64, 1);
        }
    }

    #[test]
    fn test_json_as_bool_error() {
        mesh_rt_init();
        let json = mesh_json_from_int(1);
        let result = mesh_json_as_bool(json);
        unsafe {
            let res = result as *mut MeshResult;
            assert_eq!((*res).tag, 1, "should be Err for non-bool");
        }
    }

    #[test]
    fn test_json_null() {
        mesh_rt_init();
        let json = mesh_json_null() as *const MeshJson;
        unsafe {
            assert_eq!((*json).tag, JSON_NULL);
            assert_eq!((*json).value, 0);
        }
    }

    extern "C-unwind" fn int_to_json(val: u64) -> *mut u8 {
        mesh_json_from_int(val as i64)
    }

    #[test]
    fn test_json_from_list() {
        mesh_rt_init();
        let mut l = list::mesh_list_new();
        l = list::mesh_list_append(l, 10u64);
        l = list::mesh_list_append(l, 20u64);
        l = list::mesh_list_append(l, 30u64);

        let json_arr = mesh_json_from_list(l, int_to_json);
        let encoded = mesh_json_encode(json_arr);
        unsafe {
            assert_eq!((*encoded).as_str(), "[10,20,30]");
        }
    }

    extern "C-unwind" fn json_to_int_result(json: *mut u8) -> *mut u8 {
        mesh_json_as_int(json)
    }

    #[test]
    fn test_json_list_conversion_empty_and_large() {
        for size in [0, 256] {
            let values: Vec<u64> = (0..size).collect();
            let source = list::mesh_list_from_array(values.as_ptr(), size as i64);
            let json = mesh_json_from_list(source, int_to_json);
            let result = mesh_json_to_list(json, json_to_int_result) as *const MeshResult;
            unsafe {
                assert_eq!((*result).tag, 0);
                assert_eq!(list::mesh_list_length((*result).value), size as i64);
                for i in 0..size {
                    assert_eq!(list::mesh_list_get((*result).value, i as i64), i);
                    assert_eq!(list::mesh_list_get(source, i as i64), i);
                }
            }
        }
    }

    #[test]
    fn test_json_to_list_roundtrip() {
        mesh_rt_init();
        // Build a JSON array [1, 2, 3]
        let mut arr = mesh_json_array_new();
        arr = mesh_json_array_push(arr, mesh_json_from_int(1));
        arr = mesh_json_array_push(arr, mesh_json_from_int(2));
        arr = mesh_json_array_push(arr, mesh_json_from_int(3));

        let result = mesh_json_to_list(arr, json_to_int_result);
        unsafe {
            let res = result as *mut MeshResult;
            assert_eq!((*res).tag, 0, "should be Ok");
            let decoded_list = (*res).value;
            assert_eq!(list::mesh_list_length(decoded_list), 3);
            assert_eq!(list::mesh_list_get(decoded_list, 0) as i64, 1);
            assert_eq!(list::mesh_list_get(decoded_list, 1) as i64, 2);
            assert_eq!(list::mesh_list_get(decoded_list, 2) as i64, 3);
        }
    }

    #[test]
    fn test_json_to_list_error_propagation() {
        mesh_rt_init();
        // Build a JSON array with a string element -- int decode should fail
        let mut arr = mesh_json_array_new();
        arr = mesh_json_array_push(arr, mesh_json_from_int(1));
        arr = mesh_json_array_push(arr, mesh_json_from_string(mesh_str("oops")));

        let result = mesh_json_to_list(arr, json_to_int_result);
        unsafe {
            let res = result as *mut MeshResult;
            assert_eq!((*res).tag, 1, "should propagate Err from element decode");
        }
    }

    #[test]
    fn test_json_float_roundtrip() {
        mesh_rt_init();
        // Create a float, encode it, re-parse, verify it comes back as float
        let json = mesh_json_from_float(2.75);
        let encoded = mesh_json_encode(json);
        unsafe {
            let text = (*encoded).as_str();
            let parsed: f64 = text.parse().unwrap();
            assert!((parsed - 2.75).abs() < 0.001);
        }
    }

    // ── Phase 50: mesh_json_array_get tests ──────────────────────────

    #[test]
    fn test_json_array_get_valid() {
        mesh_rt_init();
        let mut arr = mesh_json_array_new();
        arr = mesh_json_array_push(arr, mesh_json_from_int(10));
        arr = mesh_json_array_push(arr, mesh_json_from_int(20));
        arr = mesh_json_array_push(arr, mesh_json_from_int(30));

        // Get element at index 0
        let result = mesh_json_array_get(arr, 0);
        unsafe {
            let res = result as *mut MeshResult;
            assert_eq!((*res).tag, 0, "should be Ok for valid index 0");
            let elem = (*res).value as *const MeshJson;
            assert_eq!((*elem).tag, JSON_INT);
            assert_eq!((*elem).value as i64, 10);
        }

        // Get element at index 2
        let result2 = mesh_json_array_get(arr, 2);
        unsafe {
            let res = result2 as *mut MeshResult;
            assert_eq!((*res).tag, 0, "should be Ok for valid index 2");
            let elem = (*res).value as *const MeshJson;
            assert_eq!((*elem).value as i64, 30);
        }
    }

    #[test]
    fn test_json_array_get_out_of_bounds() {
        mesh_rt_init();
        let mut arr = mesh_json_array_new();
        arr = mesh_json_array_push(arr, mesh_json_from_int(1));

        // Index too large
        let result = mesh_json_array_get(arr, 5);
        unsafe {
            let res = result as *mut MeshResult;
            assert_eq!((*res).tag, 1, "should be Err for out of bounds");
        }

        // Negative index
        let result2 = mesh_json_array_get(arr, -1);
        unsafe {
            let res = result2 as *mut MeshResult;
            assert_eq!((*res).tag, 1, "should be Err for negative index");
        }
    }

    #[test]
    fn test_json_array_get_wrong_type() {
        mesh_rt_init();
        let obj = mesh_json_object_new();

        // Passing an object instead of array
        let result = mesh_json_array_get(obj, 0);
        unsafe {
            let res = result as *mut MeshResult;
            assert_eq!((*res).tag, 1, "should be Err for non-array");
        }
    }
}
