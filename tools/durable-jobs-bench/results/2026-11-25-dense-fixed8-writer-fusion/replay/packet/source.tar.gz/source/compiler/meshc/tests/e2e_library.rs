use std::path::Path;
use std::process::{Command, Output};

#[path = "support/test_artifacts.rs"]
mod artifacts;

#[test]
#[cfg(windows)]
fn builds_hosted_windows_dynamic_library() {
    let fixture = Path::new(env!("CARGO_MANIFEST_DIR")).join("tests/fixtures/library");
    let temp = tempfile::tempdir().expect("temporary artifact directory");
    let dynamic = temp.path().join("libmesh_library.dll");
    assert_success(build(&fixture, &dynamic, "cdylib"), "Windows DLL build");
    let host = temp.path().join("mesh-library-host.exe");
    let llvm = std::env::var_os("LLVM_SYS_211_PREFIX").expect("LLVM prefix");
    let clang = Path::new(&llvm).join("bin/clang.exe");
    assert_success(
        Command::new(clang)
            .arg(fixture.join("host.c"))
            .arg("-I")
            .arg(temp.path())
            .arg(dynamic.with_extension("lib"))
            .arg("-o")
            .arg(&host)
            .output()
            .expect("C host compiler"),
        "Windows C host link",
    );
    assert_success(
        Command::new(host).output().expect("C host run"),
        "Windows C host run",
    );
}

#[test]
#[cfg(unix)]
fn builds_hosted_dynamic_and_static_libraries() {
    let fixture = Path::new(env!("CARGO_MANIFEST_DIR")).join("tests/fixtures/library");
    let temp = tempfile::tempdir().expect("temporary artifact directory");
    let dynamic = temp.path().join(if cfg!(target_os = "macos") {
        "libmesh_library.dylib"
    } else {
        "libmesh_library.so"
    });

    assert_success(build(&fixture, &dynamic, "cdylib"), "dynamic build");
    assert_no_test_fixtures(&dynamic, true, "ordinary cdylib");
    for extension in ["h", "swift", "kt", "jni.c", "ts", "abi.json"] {
        assert!(
            dynamic.with_extension(extension).is_file(),
            "missing generated {extension} binding"
        );
    }

    let host = temp.path().join("mesh-library-host");
    let mut cc = Command::new("cc");
    cc.arg(fixture.join("host.c"))
        .arg("-I")
        .arg(temp.path())
        .arg("-L")
        .arg(temp.path())
        .arg("-lmesh_library")
        .arg(format!("-Wl,-rpath,{}", temp.path().display()))
        .arg("-o")
        .arg(&host);
    if cfg!(target_os = "macos") {
        cc.args(["-framework", "Security", "-framework", "CoreFoundation"]);
    }
    assert_success(cc.output().expect("C host compiler"), "C host link");
    let run = Command::new(&host).output().expect("C host run");
    assert_success(run, "C host run");

    #[cfg(target_os = "macos")]
    {
        let swift_host = temp.path().join("mesh-swift-host");
        let compile = Command::new("xcrun")
            .args(["swiftc", "-import-objc-header"])
            .arg(dynamic.with_extension("h"))
            .arg(dynamic.with_extension("swift"))
            .arg(fixture.join("host.swift"))
            .arg("-L")
            .arg(temp.path())
            .arg("-lmesh_library")
            .args(["-Xlinker", "-rpath", "-Xlinker"])
            .arg(temp.path())
            .arg("-o")
            .arg(&swift_host)
            .output()
            .expect("Swift host compiler");
        assert_success(compile, "Swift host link");
        assert_success(
            Command::new(swift_host).output().expect("Swift host run"),
            "Swift host run",
        );
    }

    let static_library = temp.path().join("libmesh_library.a");
    assert_success(
        build(&fixture, &static_library, "staticlib"),
        "static build",
    );
    assert!(
        static_library.metadata().expect("static artifact").len() > 0,
        "static library is empty"
    );
    assert_no_test_fixtures(&static_library, false, "ordinary staticlib");

    let executable_project = temp.path().join("ordinary-project");
    std::fs::create_dir(&executable_project).expect("ordinary executable project");
    std::fs::write(
        executable_project.join("main.mpl"),
        "fn main() do\n  0\nend\n",
    )
    .expect("ordinary executable fixture");
    let executable = temp.path().join("ordinary");
    assert_success(
        build(&executable_project, &executable, "executable"),
        "executable build",
    );
    assert_no_test_fixtures(&executable, false, "ordinary executable");
}

#[cfg(unix)]
fn assert_no_test_fixtures(artifact: &Path, dynamic: bool, description: &str) {
    let mut nm = Command::new("nm");
    if cfg!(target_os = "macos") {
        // Apple's llvm-nm prefers an object's embedded bitcode over its Mach-O
        // symbol table, and the Rust standard library ships bitcode from a
        // newer LLVM than Xcode can read. Exported symbols live in the symbol
        // table, so disable the bitcode reader.
        nm.args(["-gU", "--no-llvm-bc"]);
    } else if dynamic {
        nm.args(["-D", "--defined-only"]);
    } else {
        nm.args(["-g", "--defined-only"]);
    }
    let symbols = nm.arg(artifact).output().expect("artifact symbols");
    assert_success(symbols.clone(), &format!("{description} symbols"));
    let symbols = String::from_utf8_lossy(&symbols.stdout);
    for fixture in [
        "mesh_test_install_in_memory_secure_store",
        "mesh_test_set_push_token",
    ] {
        assert!(
            !symbols.contains(fixture),
            "{description} exported test-only fixture {fixture}"
        );
    }
}

fn build(fixture: &Path, output: &Path, artifact: &str) -> Output {
    let mut command = Command::new(artifacts::meshc_bin());
    command.args(["build", fixture.to_str().unwrap(), "--artifact", artifact]);
    // The compatibility runner builds its runtime in target/<triple>/release.
    #[cfg(windows)]
    command.args(["--target", "x86_64-pc-windows-msvc"]);
    command
        .arg("--output")
        .arg(output)
        .output()
        .expect("meshc build")
}

fn assert_success(output: Output, operation: &str) {
    assert!(
        output.status.success(),
        "{operation} failed ({})\nstdout:\n{}\nstderr:\n{}",
        output.status,
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
}
