//! End-to-end integration tests for Mesh standard library functions (Phase 8).
//!
//! Tests string operations, module-qualified access (String.length),
//! from/import resolution, IO operations, and HTTP server/client compilation.

// 3.14 here is the fixtures' sample float, not an approximation of π.
#![allow(clippy::approx_constant)]

use std::io::{BufRead, BufReader, Read, Write};
use std::path::{Path, PathBuf};
use std::process::{Command, Output, Stdio};
use std::sync::{Mutex, MutexGuard};
use ws_client::TestWsClient;

#[path = "support/test_artifacts.rs"]
mod artifacts;
#[path = "support/ws_client.rs"]
mod ws_client;

fn meshc_build_guard() -> MutexGuard<'static, ()> {
    static BUILD_LOCK: Mutex<()> = Mutex::new(());
    BUILD_LOCK
        .lock()
        .unwrap_or_else(std::sync::PoisonError::into_inner)
}

/// Helper: compile a Mesh source file and run the resulting binary, returning stdout.
fn compile_and_run(source: &str) -> String {
    let temp_dir = tempfile::tempdir().expect("failed to create temp dir");
    let project_dir = temp_dir.path().join("project");
    std::fs::create_dir_all(&project_dir).expect("failed to create project dir");

    let main_mesh = project_dir.join("main.mpl");
    std::fs::write(&main_mesh, source).expect("failed to write main.mpl");

    let meshc = find_meshc();
    let _execution_guard = meshc_build_guard();
    let output = Command::new(&meshc)
        .args(["build", project_dir.to_str().unwrap()])
        .output()
        .expect("failed to invoke meshc");

    assert!(
        output.status.success(),
        "meshc build failed:\nstdout: {}\nstderr: {}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );

    let binary = project_dir.join("project");
    let run_output = Command::new(&binary)
        .output()
        .unwrap_or_else(|e| panic!("failed to run binary at {}: {}", binary.display(), e));

    assert!(
        run_output.status.success(),
        "binary execution failed with exit code {:?}:\nstdout: {}\nstderr: {}",
        run_output.status.code(),
        String::from_utf8_lossy(&run_output.stdout),
        String::from_utf8_lossy(&run_output.stderr)
    );

    String::from_utf8_lossy(&run_output.stdout).to_string()
}

fn find_meshc() -> PathBuf {
    artifacts::meshc_bin()
}

/// Helper: compile a Mesh source file without running it. Returns compilation output.
fn compile_only(source: &str) -> Output {
    let temp_dir = tempfile::tempdir().expect("failed to create temp dir");
    let project_dir = temp_dir.path().join("project");
    std::fs::create_dir_all(&project_dir).expect("failed to create project dir");

    let main_mesh = project_dir.join("main.mpl");
    std::fs::write(&main_mesh, source).expect("failed to write main.mpl");

    let meshc = find_meshc();
    let _build_guard = meshc_build_guard();
    Command::new(&meshc)
        .args(["build", project_dir.to_str().unwrap()])
        .output()
        .expect("failed to invoke meshc")
}

/// Helper: compile a Mesh source file and run the binary with piped stdin input.
/// Useful for testing interactive I/O functions like IO.read_line().
fn compile_and_run_with_stdin(source: &str, stdin_input: &str) -> String {
    let temp_dir = tempfile::tempdir().expect("failed to create temp dir");
    let project_dir = temp_dir.path().join("project");
    std::fs::create_dir_all(&project_dir).expect("failed to create project dir");

    let main_mesh = project_dir.join("main.mpl");
    std::fs::write(&main_mesh, source).expect("failed to write main.mpl");

    let meshc = find_meshc();
    let _execution_guard = meshc_build_guard();
    let output = Command::new(&meshc)
        .args(["build", project_dir.to_str().unwrap()])
        .output()
        .expect("failed to invoke meshc");

    assert!(
        output.status.success(),
        "meshc build failed:\nstdout: {}\nstderr: {}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );

    let binary = project_dir.join("project");
    let mut child = Command::new(&binary)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .unwrap_or_else(|e| panic!("failed to spawn binary at {}: {}", binary.display(), e));

    // Write stdin input and drop to signal EOF
    if let Some(mut stdin) = child.stdin.take() {
        stdin
            .write_all(stdin_input.as_bytes())
            .expect("failed to write stdin");
        // stdin is dropped here, closing the pipe
    }

    let run_output = child.wait_with_output().expect("failed to wait for child");

    assert!(
        run_output.status.success(),
        "binary execution failed with exit code {:?}:\nstdout: {}\nstderr: {}",
        run_output.status.code(),
        String::from_utf8_lossy(&run_output.stdout),
        String::from_utf8_lossy(&run_output.stderr)
    );

    String::from_utf8_lossy(&run_output.stdout).to_string()
}

/// Read a test fixture from the tests/e2e/ directory.
fn read_fixture(name: &str) -> String {
    let manifest_dir = env!("CARGO_MANIFEST_DIR");
    let fixture_path = Path::new(manifest_dir)
        .parent()
        .unwrap()
        .parent()
        .unwrap()
        .join("tests")
        .join("e2e")
        .join(name);
    std::fs::read_to_string(&fixture_path)
        .unwrap_or_else(|e| panic!("failed to read fixture {}: {}", fixture_path.display(), e))
}

// ── String Operation E2E Tests ──────────────────────────────────────────

#[test]
fn e2e_string_length() {
    let source = read_fixture("stdlib_string_length.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "5\n");
}

#[test]
fn e2e_string_contains() {
    let source = read_fixture("stdlib_string_contains.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "true\nfalse\n");
}

#[test]
fn e2e_cluster_telemetry_is_available_as_a_typed_map() {
    let output = compile_and_run(
        r#"
fn verify(metrics :: Map<String, Int>) do
  println("${Map.has_key(metrics, "mailbox_messages")}")
  println("${Map.has_key(metrics, "scheduler_busy_nanoseconds_total")}")
  println("${Map.has_key(metrics, "process_resident_memory_bytes")}")
  println("${Map.get(metrics, "cpu_available_parallelism") > 0}")
end

fn main() do
  Cluster.telemetry()
    |> verify
end
"#,
    );
    assert_eq!(output, "true\ntrue\ntrue\ntrue\n");
}

/// A program that is no cluster's node still answers the cluster
/// introspection calls: itself as the only node, its scheduler's bounds and
/// pressure, the default roles and its state.
#[test]
fn e2e_cluster_introspection_describes_a_standalone_program() {
    let output = compile_and_run(
        r#"
fn main() do
  let capacity = Cluster.capacity()
  println("nodes=${Map.get(capacity, "desired_nodes")},${Map.get(capacity, "observed_nodes")},${Map.get(capacity, "ready_nodes")},${Map.get(capacity, "draining_nodes")}")
  println("workers=${Map.get(capacity, "local_min_workers") <= Map.get(capacity, "local_active_workers")},${Map.get(capacity, "local_active_workers") <= Map.get(capacity, "local_max_workers")}")
  let pressure = Cluster.pressure()
  println("pressure=${String.length(Map.get(pressure, "score")) > 0},${Map.get(pressure, "telemetry_complete")}")
  println("signal=${String.length(Map.get(pressure, "dominant_signal")) > 0}")
  println("role=${Cluster.role()}")
  println("state=${Cluster.state()}")
end
"#,
    );
    assert_eq!(
        output,
        "nodes=1,1,1,0\nworkers=true,true\npressure=true,false\nsignal=true\nrole=gateway,worker\nstate=ready\n"
    );
}

#[test]
fn e2e_string_trim() {
    let source = read_fixture("stdlib_string_trim.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "hello\n");
}

#[test]
fn e2e_string_case_conversion() {
    let source = read_fixture("stdlib_string_case.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "HELLO\nworld\n");
}

#[test]
fn e2e_string_replace() {
    let source = read_fixture("stdlib_string_replace.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "hello mesh\n");
}

// ── Module Resolution E2E Tests ─────────────────────────────────────────

#[test]
fn e2e_module_qualified_access() {
    let source = read_fixture("stdlib_module_qualified.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "4\n");
}

#[test]
fn e2e_from_import_resolution() {
    let source = read_fixture("stdlib_from_import.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "4\n");
}

// ── File I/O E2E Tests ──────────────────────────────────────────────────

#[test]
fn e2e_file_write_and_read() {
    let source = read_fixture("stdlib_file_write_read.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "Hello, Mesh!\n");
}

#[test]
fn e2e_file_exists() {
    let source = read_fixture("stdlib_file_exists.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "false\ntrue\n\n");
}

#[test]
fn e2e_file_read_process_write() {
    let source = read_fixture("stdlib_file_process.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "HELLO WORLD\n");
}

#[test]
fn e2e_file_error_handling() {
    let source = read_fixture("stdlib_file_error.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "error\n");
}

#[test]
fn e2e_file_binary_ranges_are_bounded() {
    let source = read_fixture("stdlib_file_binary_ranges.mpl");
    let output = compile_and_run(&source);
    assert_eq!(
        output,
        "5\n010203\nbounded\nrange bounded\ntruncate bounded\n"
    );
}

#[test]
fn e2e_file_sync_then_rename_replaces_the_target() {
    let source = read_fixture("stdlib_file_rename_sync.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "new\nfalse\nmissing source\nmissing sync\n");
}

// ── IO E2E Tests ────────────────────────────────────────────────────────

#[test]
fn e2e_io_eprintln_does_not_crash() {
    let source = read_fixture("stdlib_io_eprintln.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "done\n");
}

#[test]
fn e2e_io_read_line() {
    // Verify IO.read_line() compiles and runs through the full pipeline with piped stdin.
    let source = read_fixture("stdlib_io_read_line.mpl");
    let output = compile_and_run_with_stdin(&source, "hello world\n");
    assert_eq!(output, "hello world\n");
}

/// A program reading to the end of its input stops there: the end is an
/// error, where it was an empty line (and the program read on forever).
#[test]
fn e2e_io_read_line_ends_with_the_input() {
    let source = r#"
fn count_lines(count :: Int) -> Int do
  case IO.read_line() do
    Ok(_) -> count_lines(count + 1)
    Err(reason) -> do
      println(reason)
      count
    end
  end
end

fn main() do
  println("${count_lines(0)}")
end
"#;
    let output = compile_and_run_with_stdin(source, "one\n\nthree");
    assert_eq!(output, "end of input\n3\n");
}

// ── Collection E2E Tests (Phase 8 Plan 02) ────────────────────────────

#[test]
fn e2e_list_basic() {
    let source = read_fixture("stdlib_list_basic.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "3\n1\n");
}

#[test]
fn e2e_list_map_preserves_typed_callback_abi() {
    let source = read_fixture("stdlib_list_map_struct.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "true\n");
}

// ── List Literal E2E Tests (Phase 26 Plan 02) ────────────────────────────

#[test]
fn e2e_list_literal_int() {
    let source = read_fixture("list_literal_int.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "3\n1\n3\n");
}

#[test]
fn e2e_list_literal_string() {
    let source = read_fixture("list_literal_string.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "2\nhello\nworld\n");
}

#[test]
fn e2e_list_literal_bool() {
    let source = read_fixture("list_literal_bool.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "3\ntrue\nfalse\n");
}

#[test]
fn e2e_list_concat() {
    let source = read_fixture("list_concat.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "4\n1\n4\n");
}

#[test]
fn e2e_list_nested() {
    let source = read_fixture("list_nested.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "2\n2\n2\n");
}

#[test]
fn e2e_list_append_string() {
    let source = read_fixture("list_append_string.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "2\nworld\n");
}

// ── List Trait Integration E2E Tests (Phase 27 Plan 01) ───────────────

#[test]
fn e2e_list_display_string() {
    let source = read_fixture("list_display_string.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "[hello, world]\n");
}

#[test]
fn e2e_list_debug() {
    let source = read_fixture("list_debug.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "[1, 2, 3]\n");
}

#[test]
fn e2e_list_eq() {
    let source = read_fixture("list_eq.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "equal\nnot equal\n");
}

#[test]
fn e2e_list_ord() {
    let source = read_fixture("list_ord.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "less\ngreater\n");
}

// ── List Cons Pattern E2E Tests (Phase 27 Plan 02) ────────────────────

#[test]
fn e2e_list_cons_int() {
    let source = read_fixture("list_cons_int.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "15\n");
}

#[test]
fn e2e_list_cons_string() {
    let source = read_fixture("list_cons_string.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "hello\nempty\n");
}

#[test]
fn e2e_map_basic() {
    let source = read_fixture("stdlib_map_basic.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "10\n2\n");
}

#[test]
fn e2e_map_string_keys() {
    let source = read_fixture("stdlib_map_string_keys.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "Alice\n2\ntrue\nBob\n");
}

#[test]
fn e2e_map_literal() {
    let source = read_fixture("map_literal.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "Alice\n30\n2\n");
}

#[test]
fn e2e_map_literal_int() {
    let source = read_fixture("map_literal_int.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "20\n3\n");
}

#[test]
fn e2e_set_basic() {
    let source = read_fixture("stdlib_set_basic.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "2\n");
}

#[test]
fn e2e_range_basic() {
    let source = read_fixture("stdlib_range_basic.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "3\n3\n1\n");
}

#[test]
fn e2e_queue_basic() {
    let source = read_fixture("stdlib_queue_basic.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "2\n10\n");
}

// ── JSON E2E Tests (Phase 8 Plan 04) ──────────────────────────────────

#[test]
fn e2e_json_encode_int() {
    let source = read_fixture("stdlib_json_encode_int.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "42\n");
}

#[test]
fn e2e_json_encode_string() {
    let source = read_fixture("stdlib_json_encode_string.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "\"hello\"\n");
}

#[test]
fn e2e_json_encode_bool() {
    let source = read_fixture("stdlib_json_encode_bool.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "true\nfalse\n");
}

#[test]
fn e2e_json_encode_map() {
    // Tests multiple JSON encode functions together (encode_int, encode_string, encode_bool)
    let source = read_fixture("stdlib_json_encode_map.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "100\n\"test\"\ntrue\n");
}

#[test]
fn e2e_json_parse_roundtrip() {
    let source = read_fixture("stdlib_json_parse_roundtrip.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "99\n");
}

#[test]
fn e2e_json_is_string() {
    let source = read_fixture("json_is_string.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "true\nfalse\ntrue\n");
}

/// A `json { }` literal is a Json like a parsed one: it encodes as itself,
/// its fields read back, and either kind nests in another literal. (The
/// literal is JSON text at run time, which encoded as `null` and was not an
/// object to `object_get`; a parsed value nested in a literal became `null`.)
#[test]
fn e2e_json_literals_and_parsed_values_mix() {
    let source = r#"
fn main() do
  let lit = json { a: 1, bb: 2 }
  println(Json.encode(lit))
  case Json.object_get(lit, "a") do
    Ok(v) -> println("a=#{Json.encode(v)}")
    Err(e) -> println(e)
  end
  case Json.parse("{\"x\": [1, 2]}") do
    Ok(parsed) -> println(Json.encode(json { inner: parsed, outer: lit }))
    Err(e) -> println(e)
  end
end
"#;
    let output = compile_and_run(source);
    assert_eq!(
        output,
        "{\"a\":1,\"bb\":2}\na=1\n{\"inner\":{\"x\":[1,2]},\"outer\":{\"a\":1,\"bb\":2}}\n"
    );
}

/// A Json passed where a String is expected is its JSON text: written or
/// piped, to a stdlib or a user function, parsed or a literal; interpolated
/// and inspected it shows the same text. (A parsed value was a tree read as
/// a string's bytes.)
#[test]
fn e2e_json_passed_where_a_string_is_expected() {
    let source = r##"
fn shout(s :: String) -> String do
  String.to_upper(s)
end

fn show(j :: Json) -> String do
  "#{j}|#{String.length(j)}|#{shout(j)}"
end

fn main() do
  case Json.parse("{\"b\": [1, 2]}") do
    Ok(parsed) -> do
      println(parsed)
      parsed |> println
      println(show(parsed))
      let lit = json { nested: parsed, n: 1 }
      println(show(lit))
      println(inspect(lit))
    end
    Err(e) -> println(e)
  end
end
"##;
    let output = compile_and_run(source);
    assert_eq!(
        output,
        "{\"b\":[1,2]}\n{\"b\":[1,2]}\n{\"b\":[1,2]}|11|{\"B\":[1,2]}\n\
         {\"nested\":{\"b\":[1,2]},\"n\":1}|28|{\"NESTED\":{\"B\":[1,2]},\"N\":1}\n\
         {\"nested\":{\"b\":[1,2]},\"n\":1}\n"
    );
}

/// An object's keys are written in its own order: a literal's as written,
/// a struct's fields as declared, a Map's as it was built, and a parsed
/// object's as the text had them, a repeated key in its first place with its
/// last value. (Every object came out with its keys sorted.)
#[test]
fn e2e_json_keeps_key_order() {
    let source = r#"
struct Point do
  y :: Int
  x :: Int
end deriving(Json)

fn main() do
  println(json { zebra: 1, apple: 2, mango: 3 })
  println(Json.encode(Point { y: 1, x: 2 }))
  println(Json.encode(Map.put(Map.put(Map.new(), "b", 1), "a", 2)))
  case Json.parse("{\"z\": 0, \"a\": 1, \"z\": 2}") do
    Ok(parsed) -> println(parsed)
    Err(e) -> println(e)
  end
end
"#;
    let output = compile_and_run(source);
    assert_eq!(
        output,
        "{\"zebra\":1,\"apple\":2,\"mango\":3}\n{\"y\":1,\"x\":2}\n{\"b\":1,\"a\":2}\n{\"z\":2,\"a\":1}\n"
    );
}

/// Two Json values are equal when they hold the same: an object's keys in
/// any order, `1` and `1.0` apart, and so inside a list or an Option. (Json
/// compared as a String, which a tree is not.)
#[test]
fn e2e_json_values_compare_by_contents() {
    let source = r##"
fn parsed(text :: String) -> Json do
  case Json.parse(text) do
    Ok(j) -> j
    Err(_) -> json { failed: true }
  end
end

fn main() do
  let a = json { x: 1, y: [1, 2], z: "s" }
  let b = parsed("{\"z\": \"s\", \"y\": [1, 2], \"x\": 1}")
  println("#{a == b} #{a != b}")
  println("#{parsed("1") == parsed("1.0")} #{parsed("[1, 2]") == parsed("[2, 1]")}")
  println("#{parsed("{\"a\": null}") == parsed("{\"a\": null, \"b\": 1}")}")
  println("#{[a] == [b]} #{Some(a) == Some(b)}")
end
"##;
    let output = compile_and_run(source);
    assert_eq!(output, "true false\nfalse false\nfalse\ntrue true\n");
}

// ── JSON Struct Serde E2E Tests (Phase 49) ──────────────────────────────

#[test]
fn e2e_deriving_json_basic() {
    let source = read_fixture("deriving_json_basic.mpl");
    let output = compile_and_run(&source);
    // First line: JSON encode (field order may vary since JSON objects are unordered).
    // Second line: decoded fields.
    let lines: Vec<&str> = output.trim().lines().collect();
    assert_eq!(lines.len(), 2, "expected 2 lines, got: {}", output);
    let json: serde_json::Value = serde_json::from_str(lines[0]).expect("valid JSON");
    assert_eq!(json["name"], "Alice");
    assert_eq!(json["age"], 30);
    assert_eq!(json["score"], 95.5);
    assert_eq!(json["active"], true);
    assert_eq!(lines[1], "Alice 30 true");
}

#[test]
fn e2e_deriving_json_nested() {
    let source = read_fixture("deriving_json_nested.mpl");
    let output = compile_and_run(&source);
    let lines: Vec<&str> = output.trim().lines().collect();
    assert_eq!(lines.len(), 4, "expected 4 lines, got: {}", output);
    let json: serde_json::Value = serde_json::from_str(lines[0]).expect("valid JSON");
    assert_eq!(json["name"], "Bob");
    assert_eq!(json["addr"]["city"], "NYC");
    assert_eq!(json["addr"]["zip"], 10001);
    assert_eq!(lines[1], "Bob");
    assert_eq!(lines[2], "NYC");
    assert_eq!(lines[3], "10001");
}

#[test]
fn e2e_deriving_json_option() {
    let source = read_fixture("deriving_json_option.mpl");
    let output = compile_and_run(&source);
    let lines: Vec<&str> = output.trim().lines().collect();
    assert_eq!(lines.len(), 5, "expected 5 lines, got: {}", output);
    let json1: serde_json::Value = serde_json::from_str(lines[0]).expect("valid JSON line 1");
    assert_eq!(json1["bio"], "Hello!");
    assert_eq!(json1["age"], 30);
    let json2: serde_json::Value = serde_json::from_str(lines[1]).expect("valid JSON line 2");
    assert_eq!(json2["name"], "Bob");
    assert!(json2["bio"].is_null());
    // Decoding round-trips both, and a wrong payload type is an error.
    assert_eq!(lines[2], lines[0]);
    assert_eq!(lines[3], lines[1]);
    assert_eq!(lines[4], "err $.bio: expected String");
}

#[test]
fn e2e_deriving_json_number_types() {
    let source = read_fixture("deriving_json_number_types.mpl");
    let output = compile_and_run(&source);
    let lines: Vec<&str> = output.trim().lines().collect();
    assert_eq!(lines.len(), 5, "expected 5 lines, got: {}", output);
    let json: serde_json::Value = serde_json::from_str(lines[0]).expect("valid JSON");
    assert_eq!(json["i"], 42);
    assert_eq!(json["f"], 3.14);
    assert_eq!(lines[1], "42");
    assert_eq!(lines[2], "3.14");
    assert_eq!(lines[3], "43");
    assert_eq!(lines[4], "3.15");
}

#[test]
fn e2e_deriving_json_collections() {
    let source = read_fixture("deriving_json_collections.mpl");
    let output = compile_and_run(&source);
    let lines: Vec<&str> = output.trim().lines().collect();
    assert_eq!(lines.len(), 3, "expected 3 lines, got: {}", output);
    let json: serde_json::Value = serde_json::from_str(lines[0]).expect("valid JSON");
    assert!(json["tags"].is_array(), "tags should be array");
    assert_eq!(json["tags"].as_array().unwrap().len(), 3);
    assert!(json["settings"].is_object(), "settings should be object");
    assert_eq!(lines[1], "3");
    assert_eq!(lines[2], "2");
}

/// A function imported by name from any standard module runs as the
/// qualified call does. Only a hand-kept list of names (String, IO, File
/// and a few List ones) did: `from Math import sqrt` type-checked and then
/// failed in code generation with "Undefined variable 'sqrt'". And an
/// imported `Map.put` stored a tuple key where `Map.get` could not find it.
#[test]
fn e2e_stdlib_functions_import_by_name() {
    let output = compile_and_run(
        r##"
from Math import sqrt
from Int import to_float
from Bytes import from_utf8
from Env import get
from Process import demonitor
from Json import encode
from File import exists
from Map import put

fn main() do
  println("#{sqrt(to_float(9))} #{Bytes.length(from_utf8("abc"))} #{get("MESH_NO_SUCH_VAR", "fallback")}")
  println("#{demonitor(12345)} #{exists("/no/such/file/at/all")}")
  let m = put(Map.new(), (1, 2), "tuple key")
  println(Map.get(m, (1, 2)))
end
"##,
    );
    assert_eq!(output, "3.0 3 fallback\n1 false\ntuple key\n");
}

/// `Option` and `Result` functions, over payloads of each shape (a word, a
/// float, a string, a struct, a tuple, a list, `()`, another `Option`), by
/// module, through a pipe, as methods, imported by name and as a value,
/// with named functions and closures that capture.
#[test]
fn e2e_option_and_result_functions() {
    let output = compile_and_run(
        r##"
from Result import map_err

struct User do
  name :: String
  age :: Int
end

fn double(x :: Int) -> Int do
  x * 2
end

fn parse(text :: String) -> Result<Int, String> do
  case String.to_int(text) do
    Some(n) -> Ok(n)
    None -> Err("not a number: #{text}")
  end
end

fn describe(o :: Option<Int>) -> String do
  "#{Option.unwrap_or(o, -1)}"
end

fn main() do
  let some = Some(20)
  let none :: Option<Int> = None
  println(describe(Option.map(some, fn x -> x + 1 end)) <> " " <> describe(Option.map(none, double)))
  println(describe(some |> Option.and_then(fn x -> if x > 10 do Some(x) else None end end)))
  println("#{Option.is_some(some)} #{Option.is_none(some)} #{Option.is_none(none)}")
  println(Option.unwrap_or(Some("ada") |> Option.map(fn n -> String.to_upper(n) end), "?"))
  println(describe(Some(User { name: "Ada", age: 36 }) |> Option.map(fn u -> u.age end)))
  let pair = Some((1, "one")) |> Option.map(fn p -> case p do (n, s) -> "#{n}:#{s}" end end)
  println(Option.unwrap_or(pair, "none"))
  println("#{Option.ok_or(none, "missing") |> Result.is_err}")
  let offset = 5
  let r = parse("37") |> Result.map(fn n -> n + offset end)
  println("#{Result.unwrap_or(r, 0)} #{Result.unwrap_or(parse("x"), 0)}")
  case parse("x") |> map_err(fn msg -> "input: " <> msg end) do
    Ok(_) -> println("ok?")
    Err(msg) -> println(msg)
  end
  let chained = parse("4") |> Result.and_then(fn n -> if n > 3 do Ok(n * 10) else Err("small") end end)
  println("#{Result.unwrap_or(chained, 0)} #{Result.is_ok(chained)} #{Result.is_err(chained)}")
  println(describe(Result.ok(parse("9"))) <> " " <> describe(Result.ok(parse("z"))))
  println("#{Option.unwrap_or(Some(1.5) |> Option.map(fn f -> f * 2.0 end), 0.0)}")
  let unit_result :: Result<Unit, String> = Ok(())
  println("#{Result.is_ok(unit_result)}")
  println(describe(Some(Some(3)) |> Option.and_then(fn inner -> inner end)))
  println("#{Result.unwrap_or(Ok([1, 2, 3]) |> Result.map(fn xs -> List.length(xs) end), 0)}")
  let mapper = Option.map
  println(describe(mapper(Some(4), double)))
  println(describe(some.map(double)) <> " " <> "#{parse("x").map_err(fn e -> String.length(e) end).is_err()}")
end
"##,
    );
    assert_eq!(
        output,
        "21 -1\n20\ntrue false true\nADA\n36\n1:one\ntrue\n42 0\ninput: not a number: x\n\
         40 true false\n9 -1\n3.0\ntrue\n3\n3\n8\n40 true\n"
    );
}

/// `String.repeat`, called through its module and imported by name, and
/// the one-sided trims.
#[test]
fn e2e_string_repeat_and_trims() {
    let output = compile_and_run(
        r##"
from String import repeat

fn main() do
  println("[#{String.repeat("ab", 3)}][#{String.repeat("ab", 0)}][#{repeat("x", -1)}]")
  println("[#{String.trim_start("  a b  ")}][#{String.trim_end("  a b  ")}]")
  println("#{5.to_float()} #{3.7.to_int()} #{Bytes.from_utf8("abc").length()}")
end
"##,
    );
    assert_eq!(output, "[ababab][][]\n[a b  ][  a b]\n5.0 3 3\n");
}

#[test]
fn e2e_deriving_json_roundtrip() {
    let source = read_fixture("deriving_json_roundtrip.mpl");
    let output = compile_and_run(&source);
    let lines: Vec<&str> = output.trim().lines().collect();
    assert_eq!(lines.len(), 2, "expected 2 lines, got: {}", output);
    assert_eq!(lines[0], "round-trip: ok");
    assert_eq!(lines[1], "zero-values: ok");
}

#[test]
fn e2e_deriving_json_error() {
    let source = read_fixture("deriving_json_error.mpl");
    let output = compile_and_run(&source);
    let lines: Vec<&str> = output.trim().lines().collect();
    assert_eq!(lines.len(), 3, "expected 3 lines, got: {}", output);
    assert_eq!(lines[0], "parse error: ok");
    assert_eq!(lines[1], "missing field: ok");
    assert_eq!(lines[2], "wrong type: ok");
}

#[test]
fn e2e_deriving_json_non_serializable_compile_fail() {
    // Verify that deriving(Json) on a struct with a non-serializable field (Pid)
    // produces a compile error containing E0038.
    let source = r#"
struct BadStruct do
  name :: String
  worker :: Pid
end deriving(Json)

fn main() do
  println("should not compile")
end
"#;
    let result = compile_only(source);
    assert!(
        !result.status.success(),
        "Expected compilation failure for non-serializable field, but it succeeded"
    );
    let stderr = String::from_utf8_lossy(&result.stderr);
    assert!(
        stderr.contains("E0038") || stderr.contains("not JSON-serializable"),
        "Expected E0038 error, got stderr: {}",
        stderr
    );
}

// ── Row (Struct-to-Row Mapping) E2E Tests (Phase 58) ────────────────────

#[test]
fn e2e_deriving_row_basic() {
    let source = read_fixture("deriving_row_basic.mpl");
    let output = compile_and_run(&source);
    let lines: Vec<&str> = output.trim().lines().collect();
    assert_eq!(lines.len(), 1, "expected 1 line, got: {}", output);
    assert_eq!(lines[0], "Alice 30 95.5 true");
}

#[test]
fn e2e_deriving_row_option() {
    let source = read_fixture("deriving_row_option.mpl");
    let output = compile_and_run(&source);
    let lines: Vec<&str> = output.trim().lines().collect();
    assert_eq!(lines.len(), 1, "expected 1 line, got: {}", output);
    // Struct with Option fields: empty string bio -> None, "25" age -> Some(25)
    // from_row returns Ok(Profile) and we print the name
    assert_eq!(lines[0], "Bob");
}

#[test]
fn e2e_deriving_row_error() {
    let source = read_fixture("deriving_row_error.mpl");
    let output = compile_and_run(&source);
    let trimmed = output.trim();
    // Should report missing column "count"
    assert!(
        trimmed.contains("count"),
        "Expected error mentioning missing column 'count', got: {}",
        trimmed
    );
}

#[test]
fn e2e_deriving_row_non_mappable_compile_fail() {
    // Verify that deriving(Row) on a struct with a non-mappable field (List<Int>)
    // produces a compile error containing E0039.
    let source = r#"
struct Bad do
  name :: String
  tags :: List<Int>
end deriving(Row)

fn main() do
  println("should not compile")
end
"#;
    let result = compile_only(source);
    assert!(
        !result.status.success(),
        "Expected compile failure, but it succeeded"
    );
    let stderr = String::from_utf8_lossy(&result.stderr);
    assert!(
        stderr.contains("E0039") || stderr.contains("cannot be mapped from a database row"),
        "Expected E0039 error, got stderr: {}",
        stderr
    );
}

// ── HTTP E2E Tests (Phase 8 Plan 05, updated Phase 15) ────────────────
//
// The HTTP server uses actor-per-connection (Phase 15) with crash isolation
// via catch_unwind. Each incoming connection is handled by a lightweight
// actor on the M:N scheduler.

#[test]
fn e2e_http_server_compiles() {
    // Verify a server program compiles (cannot run because it blocks on serve).
    let source = read_fixture("stdlib_http_response.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "compiled\n");
}

#[test]
fn e2e_http_full_server_compile_only() {
    // Verify a full server program with handler and serve compiles.
    let source = r#"
fn handler(request) do
  let m = Request.method(request)
  HTTP.response(200, m)
end

fn main() do
  let r = HTTP.router()
  let r = HTTP.route(r, "/", handler)
  HTTP.serve(r, 0)
end
"#;
    let result = compile_only(source);
    assert!(
        result.status.success(),
        "HTTP server with Request accessors should compile:\nstdout: {}\nstderr: {}",
        String::from_utf8_lossy(&result.stdout),
        String::from_utf8_lossy(&result.stderr)
    );
}

#[test]
fn e2e_http_serve_tls_compile_only() {
    // Verify HTTP.serve_tls(router, port, cert, key) compiles.
    // Phase 56 Plan 02: HTTPS TLS layer.
    let source = r#"
fn handler(request) do
  HTTP.response(200, "ok")
end

fn main() do
  let r = HTTP.router()
  let r = HTTP.route(r, "/", handler)
  HTTP.serve_tls(r, 8443, "cert.pem", "key.pem")
end
"#;
    let result = compile_only(source);
    assert!(
        result.status.success(),
        "HTTP.serve_tls should compile:\nstdout: {}\nstderr: {}",
        String::from_utf8_lossy(&result.stdout),
        String::from_utf8_lossy(&result.stderr)
    );
}

// ── List Pipe Chain E2E Tests (Phase 8 Plan 06 - Gap Closure) ─────────

#[test]
fn e2e_list_pipe_chain() {
    // Verify map/filter/reduce with closures through the full compiler pipeline.
    // Input: [1..10], map(x*2) -> [2..20], filter(x>10) -> [12,14,16,18,20], reduce(sum) -> 80.
    let source = read_fixture("stdlib_list_pipe_chain.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "80\n");
}

// ── HTTP Runtime E2E Tests (Phase 8 Plan 07 - Gap Closure) ────────────
//
// These tests start a REAL HTTP server and make actual HTTP requests,
// verifying that the Mesh HTTP server works end-to-end at runtime.

/// RAII guard that stops the server child process on drop, then removes the
/// project it was built in.
struct ServerGuard {
    child: std::process::Child,
    _execution_guard: MutexGuard<'static, ()>,
    _project: tempfile::TempDir,
}

impl Drop for ServerGuard {
    fn drop(&mut self) {
        artifacts::stop_child(&mut self.child);
    }
}

/// Compile a Mesh source file and spawn the resulting binary as a server.
/// Returns a ServerGuard that kills the process on drop.
///
/// The caller is responsible for waiting on the stderr readiness signal before
/// sending requests.
fn compile_and_start_server(source: &str) -> ServerGuard {
    compile_and_start_server_with(source, |binary| Command::new(binary))
}

/// `compile_and_start_server`, the binary started by the command `launch`
/// makes of its path.
fn compile_and_start_server_with(
    source: &str,
    launch: impl FnOnce(&Path) -> Command,
) -> ServerGuard {
    let temp_dir = tempfile::tempdir().expect("failed to create temp dir");
    let project_dir = temp_dir.path().join("project");
    std::fs::create_dir_all(&project_dir).expect("failed to create project dir");

    let main_mesh = project_dir.join("main.mpl");
    std::fs::write(&main_mesh, source).expect("failed to write main.mpl");

    let meshc = find_meshc();
    let build_guard = meshc_build_guard();
    let output = Command::new(&meshc)
        .args(["build", project_dir.to_str().unwrap()])
        .output()
        .expect("failed to invoke meshc");

    assert!(
        output.status.success(),
        "meshc build failed:\nstdout: {}\nstderr: {}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );

    let binary = project_dir.join("project");
    assert!(
        binary.exists(),
        "compiled binary not found at {}",
        binary.display()
    );

    // Spawn the server binary with stderr piped so we can detect readiness.
    let child = launch(&binary)
        .stderr(Stdio::piped())
        .spawn()
        .unwrap_or_else(|e| panic!("failed to spawn server binary: {}", e));

    ServerGuard {
        child,
        _execution_guard: build_guard,
        _project: temp_dir,
    }
}

/// Wait for a spawned Mesh HTTP or HTTPS server to emit its runtime
/// listening log. Generous: a host that assesses each new process before it
/// starts (macOS, under cargo) can hold the server for many seconds.
fn wait_for_server_ready(guard: &mut ServerGuard) {
    let stderr = guard.child.stderr.take().expect("no stderr pipe");
    let stderr_reader = BufReader::new(stderr);
    let (tx, rx) = std::sync::mpsc::channel();
    std::thread::spawn(move || {
        let mut said = String::new();
        let mut lines = stderr_reader.lines().map_while(Result::ok);
        for line in lines.by_ref() {
            if line.contains("server listening on") {
                let _ = tx.send(Ok(()));
                // Keep reading so the server never blocks on a full pipe.
                lines.for_each(drop);
                return;
            }
            said.push_str(&line);
            said.push('\n');
        }
        let _ = tx.send(Err(said));
    });

    match rx.recv_timeout(artifacts::LAUNCH_ALLOWANCE) {
        Ok(Ok(())) => {}
        Ok(Err(said)) => panic!("the server exited without listening:\n{said}"),
        Err(_) => panic!(
            "the server did not start within {:?}",
            artifacts::LAUNCH_ALLOWANCE
        ),
    }
}

/// A port nothing listens on now.
fn free_port() -> u16 {
    std::net::TcpListener::bind("127.0.0.1:0")
        .and_then(|listener| listener.local_addr())
        .expect("no free port")
        .port()
}

/// Build and start `source` with its fixed `port` replaced by a free one, and
/// wait until it listens: a fixed port another server holds fails the bind.
fn serve_on_free_port(source: &str, port: u16) -> (ServerGuard, u16) {
    let free = free_port();
    let mut guard = compile_and_start_server(&source.replace(&port.to_string(), &free.to_string()));
    wait_for_server_ready(&mut guard);
    (guard, free)
}

/// Start the server in `fixture` on a free port and GET each of `paths`.
///
/// The server binds the wildcard address, so a process already listening on
/// 127.0.0.1 at the fixture's own port (18080) would answer instead.
fn get_from_served_fixture(fixture: &str, paths: &[&str]) -> Vec<String> {
    let (_guard, port) = serve_on_free_port(&read_fixture(fixture), 18080);

    // Make HTTP GET requests to the server using raw TcpStream.
    // Retry up to 5 times with 200ms between attempts for robustness.
    paths
        .iter()
        .map(|path| {
            for attempt in 0..5 {
                if attempt > 0 {
                    std::thread::sleep(std::time::Duration::from_millis(200));
                }
                let Ok(mut stream) = std::net::TcpStream::connect(("127.0.0.1", port)) else {
                    continue;
                };
                stream
                    .set_read_timeout(Some(std::time::Duration::from_secs(5)))
                    .unwrap();
                let request =
                    format!("GET {path} HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n");
                stream
                    .write_all(request.as_bytes())
                    .expect("failed to write HTTP request");
                let mut response = String::new();
                stream
                    .read_to_string(&mut response)
                    .expect("failed to read HTTP response");
                return response;
            }
            panic!("Failed to connect to server after 5 attempts");
        })
        .collect()
    // ServerGuard Drop stops the server process.
}

/// A CA and a certificate it signs for localhost and 127.0.0.1, as PEM
/// files in `directory`: (ca, certificate, key).
fn localhost_certificate(directory: &Path) -> (PathBuf, PathBuf, PathBuf) {
    let file = |name: &str| directory.join(name).to_str().unwrap().to_string();
    let (ca_key, ca, key, request, cert) = (
        file("ca.key.pem"),
        file("ca.pem"),
        file("key.pem"),
        file("server.csr"),
        file("cert.pem"),
    );
    #[rustfmt::skip]
    let steps: [&[&str]; 3] = [
        &["req", "-x509", "-newkey", "rsa:2048", "-nodes", "-days", "1",
          "-subj", "/CN=mesh-test-ca", "-keyout", &ca_key, "-out", &ca],
        &["req", "-newkey", "rsa:2048", "-nodes", "-subj", "/CN=localhost",
          "-addext", "subjectAltName=DNS:localhost,IP:127.0.0.1",
          "-keyout", &key, "-out", &request],
        &["x509", "-req", "-in", &request, "-CA", &ca, "-CAkey", &ca_key,
          "-CAcreateserial", "-days", "1", "-copy_extensions", "copy", "-out", &cert],
    ];
    for step in steps {
        let output = Command::new("openssl")
            .args(step)
            .output()
            .expect("openssl runs");
        assert!(
            output.status.success(),
            "{}",
            String::from_utf8_lossy(&output.stderr)
        );
    }
    (ca.into(), cert.into(), key.into())
}

/// HTTP.serve_tls answers over TLS with a PEM certificate a client trusts
/// through its CA, and a client without that CA refuses it.
#[test]
fn e2e_https_server_serves_with_a_pem_certificate() {
    let certificates = tempfile::tempdir().unwrap();
    let (ca, cert, key) = localhost_certificate(certificates.path());
    let port = free_port();
    let source = format!(
        r#"
fn hello(request) do
  HTTP.response(200, "hello over tls")
end

fn main() do
  let r = HTTP.router()
  let r = HTTP.on_get(r, "/hello", hello)
  HTTP.serve_tls(r, {port}, "{cert}", "{key}")
end
"#,
        cert = cert.display(),
        key = key.display(),
    );
    let mut guard = compile_and_start_server(&source);
    wait_for_server_ready(&mut guard);
    let url = format!("https://127.0.0.1:{port}/hello");
    let trusted = Command::new("curl")
        .args(["--silent", "--show-error", "--max-time", "30", "--cacert"])
        .arg(&ca)
        .arg(&url)
        .output()
        .expect("curl runs");
    assert!(
        trusted.status.success(),
        "{}",
        String::from_utf8_lossy(&trusted.stderr)
    );
    assert_eq!(String::from_utf8_lossy(&trusted.stdout), "hello over tls");
    let untrusted = Command::new("curl")
        .args(["--silent", "--max-time", "30", &url])
        .output()
        .expect("curl runs");
    assert!(
        !untrusted.status.success(),
        "a client without the CA connected"
    );
}

/// HTTP.serve_tls with certificate or key files it cannot load says so and
/// returns without serving.
#[test]
fn e2e_https_server_refuses_certificates_it_cannot_load() {
    let certificates = tempfile::tempdir().unwrap();
    let (_, cert, key) = localhost_certificate(certificates.path());
    let missing = certificates.path().join("missing.pem");
    // A key of a kind TLS here cannot sign with.
    let ed448 = certificates.path().join("ed448.pem");
    let output = Command::new("openssl")
        .args(["genpkey", "-algorithm", "ed448", "-out"])
        .arg(&ed448)
        .output()
        .expect("openssl runs");
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
    for (cert, key, error) in [
        (&missing, &key, "open cert file"),
        (&cert, &missing, "load key"),
        (&cert, &ed448, "TLS config"),
    ] {
        let source = format!(
            r#"
fn main() do
  HTTP.serve_tls(HTTP.router(), 0, "{cert}", "{key}")
  println("returned")
end
"#,
            cert = cert.display(),
            key = key.display(),
        );
        let mut guard = compile_and_start_server(&source);
        let mut stderr = String::new();
        guard
            .child
            .stderr
            .take()
            .expect("no stderr pipe")
            .read_to_string(&mut stderr)
            .unwrap();
        assert!(
            stderr.contains(&format!(
                "[mesh-rt] Failed to load TLS certificates: {error}"
            )),
            "{error}: {stderr}"
        );
    }
}

impl<S: Read + Write> TestWsClient<S> {
    /// Welcome, echo and close: what the server below does.
    fn converse(&mut self) {
        assert_eq!(self.receive(), (1, b"welcome /chat".to_vec()));
        self.send(1, b"hi");
        assert_eq!(self.receive(), (1, b"echo hi".to_vec()));
        self.send(8, &1000u16.to_be_bytes());
        assert_eq!(self.receive().0, 8, "the server answers a close");
    }
}

/// A WebSocket server that welcomes each client with its path and echoes
/// what it sends, over `serve` (Ws.serve, or Ws.serve_tls with its files).
fn websocket_server_source(serve: &str) -> String {
    format!(
        r#"
fn on_connect(conn, path, headers) do
  Ws.send(conn, "welcome " <> path)
  1
end

fn on_message(conn, msg) do
  Ws.send(conn, "echo " <> msg)
end

fn on_close(conn, code, reason) do
  println("closed")
end

fn main() do
  {serve}
  Timer.sleep(600000)
end
"#
    )
}

/// Ws.serve and Ws.serve_tls: the upgrade, a welcome, an echo and a close,
/// in the clear and over TLS a client trusts through its CA.
#[test]
fn e2e_websocket_server_talks_ws_and_wss() {
    let port = free_port();
    let source = websocket_server_source(&format!(
        "Ws.serve(on_connect, on_message, on_close, {port})"
    ));
    let mut guard = compile_and_start_server(&source);
    wait_for_server_ready(&mut guard);
    let tcp = std::net::TcpStream::connect(("127.0.0.1", port)).unwrap();
    tcp.set_read_timeout(Some(std::time::Duration::from_secs(30)))
        .unwrap();
    TestWsClient::open(tcp, "/chat").converse();
    drop(guard);

    let certificates = tempfile::tempdir().unwrap();
    let (ca, cert, key) = localhost_certificate(certificates.path());
    let port = free_port();
    let source = websocket_server_source(&format!(
        "Ws.serve_tls(on_connect, on_message, on_close, {port}, \"{}\", \"{}\")",
        cert.display(),
        key.display()
    ));
    let mut guard = compile_and_start_server(&source);
    wait_for_server_ready(&mut guard);
    let mut roots = rustls::RootCertStore::empty();
    use rustls::pki_types::pem::PemObject as _;
    for certificate in rustls::pki_types::CertificateDer::pem_file_iter(&ca).unwrap() {
        roots.add(certificate.unwrap()).unwrap();
    }
    let config = rustls::ClientConfig::builder_with_provider(std::sync::Arc::new(
        rustls::crypto::ring::default_provider(),
    ))
    .with_safe_default_protocol_versions()
    .unwrap()
    .with_root_certificates(roots)
    .with_no_client_auth();
    let connection = rustls::ClientConnection::new(
        std::sync::Arc::new(config),
        rustls::pki_types::ServerName::try_from("localhost").unwrap(),
    )
    .unwrap();
    let tcp = std::net::TcpStream::connect(("127.0.0.1", port)).unwrap();
    tcp.set_read_timeout(Some(std::time::Duration::from_secs(30)))
        .unwrap();
    TestWsClient::open(rustls::StreamOwned::new(connection, tcp), "/chat").converse();
}

/// Ws.serve_tls with certificate files it cannot load says so and returns.
#[test]
fn e2e_websocket_tls_server_refuses_certificates_it_cannot_load() {
    let certificates = tempfile::tempdir().unwrap();
    let missing = certificates.path().join("missing.pem");
    let source = format!(
        r#"
fn on_connect(conn, path, headers) do
  1
end

fn on_message(conn, msg) do
  Ws.send(conn, msg)
end

fn on_close(conn, code, reason) do
  println("closed")
end

fn main() do
  Ws.serve_tls(on_connect, on_message, on_close, 0, "{missing}", "{missing}")
  println("returned")
end
"#,
        missing = missing.display()
    );
    let mut guard = compile_and_start_server(&source);
    let mut stderr = String::new();
    guard
        .child
        .stderr
        .take()
        .expect("no stderr pipe")
        .read_to_string(&mut stderr)
        .unwrap();
    assert!(
        stderr.contains("[mesh-rt] Failed to load TLS certificates: open cert file"),
        "{stderr}"
    );
}

#[test]
fn e2e_http_server_runtime() {
    // This test starts a real HTTP server from a compiled Mesh program,
    // makes an HTTP request, and verifies the response body.
    let responses = get_from_served_fixture("stdlib_http_server_runtime.mpl", &["/health"]);
    let response = &responses[0];
    assert!(
        response.contains("200"),
        "Expected HTTP 200 in response, got: {}",
        response
    );
    // The Mesh string literal "{\"status\":\"ok\"}" is unescaped by the
    // compiler to {"status":"ok"} — Mesh processes standard escape sequences.
    assert!(
        response.contains(r#"{"status":"ok"}"#),
        "Expected JSON body in response, got: {}",
        response
    );
}

/// A closure, with what it captured, as a route handler and as middleware.
/// Registration used to drop the environment and pass a box as the function.
#[test]
fn e2e_http_closure_handler_and_middleware() {
    let responses =
        get_from_served_fixture("stdlib_http_closure_handler.mpl", &["/closure", "/stamp"]);
    assert!(
        responses[0].contains("200") && responses[0].contains(r#"{"from":"closure-42"}"#),
        "handler closure: {}",
        responses[0]
    );
    assert!(
        responses[1].contains("200") && responses[1].contains("stamped-7"),
        "middleware closure: {}",
        responses[1]
    );
}

#[test]
fn e2e_http_server_preserves_binary_request_and_response_bodies() {
    artifacts::ensure_mesh_rt_staticlib();
    let source = r#"
fn echo(request :: Request) -> Response do
  HTTP.response_bytes_with_headers(200,
  Request.body_bytes(request),
  Map.put(Map.new(), "Cache-Control", "no-store"))
end

fn main() do
  HTTP.router()
    |> HTTP.on_post("/binary", echo)
    |> HTTP.serve(18085)
end
"#;
    let (_guard, port) = serve_on_free_port(source, 18085);

    let mut stream = std::net::TcpStream::connect(("127.0.0.1", port)).unwrap();
    stream
        .set_read_timeout(Some(std::time::Duration::from_secs(5)))
        .unwrap();
    stream
        .write_all(
            b"POST /binary HTTP/1.1\r\nHost: localhost\r\nContent-Type: application/octet-stream\r\nContent-Length: 3\r\nConnection: close\r\n\r\n\x00\xff\x80",
        )
        .unwrap();
    let mut response = Vec::new();
    stream.read_to_end(&mut response).unwrap();
    let separator = response
        .windows(4)
        .position(|window| window == b"\r\n\r\n")
        .expect("HTTP response separator");
    let headers = String::from_utf8(response[..separator].to_vec()).unwrap();
    assert!(headers.starts_with("HTTP/1.1 200 OK\r\n"), "{headers}");
    assert!(headers
        .lines()
        .any(|line| line.eq_ignore_ascii_case("content-type: application/octet-stream")));
    assert!(headers
        .lines()
        .any(|line| line.eq_ignore_ascii_case("cache-control: no-store")));
    assert_eq!(&response[separator + 4..], &[0x00, 0xff, 0x80]);
}

#[test]
fn e2e_http_server_drains_accepted_requests_before_returning() {
    let markers = tempfile::tempdir().expect("failed to create marker directory");
    let started = markers.path().join("started");
    let stopped = markers.path().join("stopped");
    let source = r#"
fn slow(_request) do
  File.write("__STARTED__", "started")
  Timer.sleep(500)
  HTTP.response(200, "done")
end

fn main() do
  Process.install_shutdown_signals()
  HTTP.router()
    |> HTTP.on_get("/slow", slow)
    |> HTTP.serve(18084)
  File.write("__STOPPED__", "stopped")
end
"#
    .replace("__STARTED__", started.to_str().unwrap())
    .replace("__STOPPED__", stopped.to_str().unwrap());
    let (guard, port) = serve_on_free_port(&source, 18084);

    let request = std::thread::spawn(move || {
        let mut stream =
            std::net::TcpStream::connect(("127.0.0.1", port)).expect("failed to connect");
        stream
            .set_read_timeout(Some(std::time::Duration::from_secs(2)))
            .unwrap();
        stream
            .write_all(b"GET /slow HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n")
            .expect("failed to write request");
        let mut response = String::new();
        stream
            .read_to_string(&mut response)
            .expect("failed to read response");
        response
    });

    let deadline = std::time::Instant::now() + std::time::Duration::from_secs(2);
    while !started.exists() && std::time::Instant::now() < deadline {
        std::thread::sleep(std::time::Duration::from_millis(10));
    }
    assert!(started.exists(), "slow handler did not start");
    assert!(Command::new("kill")
        .args(["-TERM", &guard.child.id().to_string()])
        .status()
        .expect("failed to send SIGTERM")
        .success());
    std::thread::sleep(std::time::Duration::from_millis(100));
    assert!(
        !stopped.exists(),
        "HTTP.serve returned before the accepted request completed"
    );

    assert!(request.join().unwrap().contains("200"));
    let deadline = std::time::Instant::now() + std::time::Duration::from_secs(1);
    while !stopped.exists() && std::time::Instant::now() < deadline {
        std::thread::sleep(std::time::Duration::from_millis(10));
    }
    assert!(stopped.exists(), "HTTP.serve did not return after draining");
}

/// A server out of file descriptors cannot accept: it waits a moment and
/// tries again, where it used to fail again at once, spinning a thread and
/// its log.
#[test]
fn e2e_http_server_pauses_when_accept_fails() {
    let port = free_port();
    let source = format!(
        r#"
fn hello(request) do
  HTTP.response(200, "hello")
end

fn main() do
  HTTP.router() |> HTTP.on_get("/", hello) |> HTTP.serve({port})
end
"#
    );
    let mut guard = compile_and_start_server_with(&source, |binary| {
        let mut command = Command::new("sh");
        command
            .arg("-c")
            .arg(format!("ulimit -n 64 && exec '{}'", binary.display()));
        command
    });
    let stderr = guard.child.stderr.take().expect("no stderr pipe");
    let (listening, ready) = std::sync::mpsc::channel();
    let errors = std::thread::spawn(move || {
        let mut errors = 0;
        for line in BufReader::new(stderr).lines().map_while(Result::ok) {
            if line.contains("server listening on") {
                let _ = listening.send(());
            }
            errors += usize::from(line.contains("accept error"));
        }
        errors
    });
    ready
        .recv_timeout(artifacts::LAUNCH_ALLOWANCE)
        .expect("the server did not start");
    // More idle connections than the server has descriptors: each one it
    // accepts holds one, waiting for a request.
    let address = std::net::SocketAddr::from(([127, 0, 0, 1], port));
    let mut clients = (0..100)
        .map(|_| {
            std::net::TcpStream::connect_timeout(&address, std::time::Duration::from_secs(2))
                .unwrap()
        })
        .collect::<Vec<_>>();
    let mut queued = clients.pop().unwrap();
    std::thread::sleep(std::time::Duration::from_secs(1));
    queued
        .set_read_timeout(Some(std::time::Duration::from_secs(5)))
        .unwrap();
    queued
        .write_all(b"GET / HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n")
        .unwrap();
    // Free descriptors while this request is already queued. No later
    // connection should be needed to wake up the listener.
    drop(clients);
    let mut response = String::new();
    queued.read_to_string(&mut response).unwrap();
    assert!(response.starts_with("HTTP/1.1 200 OK\r\n"), "{response}");
    assert!(response.ends_with("\r\n\r\nhello"), "{response}");

    drop(guard);
    let errors = errors.join().unwrap();
    assert!(errors > 0, "the server never ran out of descriptors");
    assert!(errors < 200, "{errors} accept errors in about a second");
}

// ── HTTP Crash Isolation E2E Tests (Phase 15) ─────────────────────────
//
// Verifies that a panic in one HTTP connection handler does not affect
// other connections, thanks to catch_unwind in connection_handler_entry.

#[test]
fn e2e_http_crash_isolation() {
    let source = read_fixture("stdlib_http_crash_isolation.mpl");
    let (_guard, port) = serve_on_free_port(&source, 18081);

    // Step 1: Hit the /crash endpoint to trigger a panic in the handler actor.
    let _ = std::net::TcpStream::connect(("127.0.0.1", port)).map(|mut stream| {
        stream
            .set_read_timeout(Some(std::time::Duration::from_secs(2)))
            .ok();
        stream
            .write_all(b"GET /crash HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n")
            .ok();
        let mut buf = String::new();
        let _ = stream.read_to_string(&mut buf);
    });

    std::thread::sleep(std::time::Duration::from_millis(500));

    // Step 2: Hit the /health endpoint -- must still work after the crash.
    let mut response = String::new();
    let mut connected = false;
    for attempt in 0..5 {
        if attempt > 0 {
            std::thread::sleep(std::time::Duration::from_millis(200));
        }
        match std::net::TcpStream::connect(("127.0.0.1", port)) {
            Ok(mut stream) => {
                stream
                    .set_read_timeout(Some(std::time::Duration::from_secs(5)))
                    .unwrap();
                stream
                    .write_all(
                        b"GET /health HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n",
                    )
                    .expect("failed to write HTTP request");
                stream
                    .read_to_string(&mut response)
                    .expect("failed to read HTTP response");
                connected = true;
                break;
            }
            Err(_) => continue,
        }
    }

    assert!(connected, "Failed to connect to server after crash");
    assert!(
        response.contains("200"),
        "Expected HTTP 200 after crash isolation, got: {}",
        response
    );
    // The Mesh string literal "{\"status\":\"ok\"}" is unescaped by the
    // compiler to {"status":"ok"} — Mesh processes standard escape sequences.
    assert!(
        response.contains(r#"{"status":"ok"}"#),
        "Expected JSON body after crash isolation, got: {}",
        response
    );
}

// ── Math/Int/Float E2E Tests (Phase 43 Plan 01) ───────────────────────

#[test]
fn math_abs_int() {
    let out = compile_and_run(
        r#"
fn main() do
  println("${Math.abs(-42)}")
  println("${Math.abs(42)}")
  println("${Math.abs(0)}")
end
"#,
    );
    assert_eq!(out.trim(), "42\n42\n0");
}

#[test]
fn math_abs_float() {
    let out = compile_and_run(
        r#"
fn main() do
  println("${Math.abs(-3.14)}")
  println("${Math.abs(3.14)}")
end
"#,
    );
    assert!(out.contains("3.14"));
}

#[test]
fn math_min_max_int() {
    let out = compile_and_run(
        r#"
fn main() do
  println("${Math.min(10, 20)}")
  println("${Math.max(10, 20)}")
  println("${Math.min(-5, 3)}")
  println("${Math.max(-5, 3)}")
end
"#,
    );
    assert_eq!(out.trim(), "10\n20\n-5\n3");
}

#[test]
fn math_min_max_float() {
    let out = compile_and_run(
        r#"
fn main() do
  println("${Math.min(1.5, 2.5)}")
  println("${Math.max(1.5, 2.5)}")
end
"#,
    );
    assert!(out.contains("1.5"));
    assert!(out.contains("2.5"));
}

#[test]
fn math_pi_constant() {
    let out = compile_and_run(
        r#"
fn main() do
  let pi = Math.pi
  println("${pi}")
end
"#,
    );
    assert!(out.contains("3.14159"));
}

#[test]
fn int_to_float_conversion() {
    let out = compile_and_run(
        r#"
fn main() do
  let f = Int.to_float(42)
  println("${f}")
end
"#,
    );
    assert!(out.contains("42"));
}

#[test]
fn float_to_int_conversion() {
    let out = compile_and_run(
        r#"
fn main() do
  println("${Float.to_int(3.14)}")
  println("${Float.to_int(3.99)}")
  println("${Float.to_int(-2.7)}")
end
"#,
    );
    // fptosi truncates toward zero
    assert_eq!(out.trim(), "3\n3\n-2");
}

#[test]
fn math_abs_with_variable() {
    let out = compile_and_run(
        r#"
fn main() do
  let x = -99
  println("${Math.abs(x)}")
end
"#,
    );
    assert_eq!(out.trim(), "99");
}

#[test]
fn int_float_module_no_conflict_with_types() {
    // Verify Int/Float work as modules (Int.to_float, Float.to_int) while
    // Int and Float literals still work correctly (Pitfall 7: no name collision).
    let out = compile_and_run(
        r#"
fn main() do
  let x = 42
  let f = Int.to_float(x)
  let i = Float.to_int(f)
  println("${x}")
  println("${i}")
end
"#,
    );
    assert_eq!(out.trim(), "42\n42");
}

// ── Math pow/sqrt/floor/ceil/round E2E Tests (Phase 43 Plan 02) ───────

#[test]
fn math_pow() {
    let out = compile_and_run(
        r#"
fn main() do
  println("${Math.pow(2.0, 10.0)}")
  println("${Math.pow(3.0, 2.0)}")
  println("${Math.pow(10.0, 0.0)}")
end
"#,
    );
    assert!(out.contains("1024"));
    assert!(out.contains("9"));
    // 10^0 = 1
    assert!(out.lines().nth(2).unwrap().contains("1"));
}

#[test]
fn math_sqrt() {
    let out = compile_and_run(
        r#"
fn main() do
  println("${Math.sqrt(144.0)}")
  println("${Math.sqrt(2.0)}")
  println("${Math.sqrt(0.0)}")
end
"#,
    );
    assert!(out.contains("12"));
    assert!(out.contains("1.41421"));
    assert!(out.contains("0"));
}

#[test]
fn math_floor() {
    let out = compile_and_run(
        r#"
fn main() do
  println("${Math.floor(3.7)}")
  println("${Math.floor(3.0)}")
  println("${Math.floor(-2.3)}")
end
"#,
    );
    assert_eq!(out.trim(), "3\n3\n-3");
}

#[test]
fn math_ceil() {
    let out = compile_and_run(
        r#"
fn main() do
  println("${Math.ceil(3.2)}")
  println("${Math.ceil(3.0)}")
  println("${Math.ceil(-2.7)}")
end
"#,
    );
    assert_eq!(out.trim(), "4\n3\n-2");
}

#[test]
fn math_round() {
    let out = compile_and_run(
        r#"
fn main() do
  println("${Math.round(3.5)}")
  println("${Math.round(3.4)}")
  println("${Math.round(-2.5)}")
  println("${Math.round(0.5)}")
end
"#,
    );
    // llvm.round uses "round half away from zero"
    assert_eq!(out.trim(), "4\n3\n-3\n1");
}

#[test]
fn math_combined_usage() {
    let out = compile_and_run(
        r#"
fn main() do
  let radius = 5.0
  let area = Math.pow(radius, 2.0)
  println("${area}")
  let side = Math.sqrt(area)
  println("${side}")
  let pi_approx = Math.round(Math.pi)
  println("${pi_approx}")
  let converted = Float.to_int(Math.sqrt(Int.to_float(16)))
  println("${converted}")
end
"#,
    );
    assert!(out.contains("25"));
    assert!(out.contains("5"));
    assert!(out.contains("3")); // round(pi) = 3
    assert!(out.contains("4")); // sqrt(16) = 4
}

#[test]
fn math_pow_with_conversion() {
    let out = compile_and_run(
        r#"
fn main() do
  let result = Math.pow(Int.to_float(2), Int.to_float(8))
  println("${Float.to_int(result)}")
end
"#,
    );
    assert_eq!(out.trim(), "256");
}

// ── List Collection Operations E2E Tests (Phase 46 Plan 01) ────────────

#[test]
fn e2e_list_sort() {
    let source = read_fixture("stdlib_list_sort.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "1\n9\n8\n");
}

#[test]
fn e2e_list_find() {
    // NOTE: List.find returns Option<T> (MeshOption ptr from runtime).
    // Pattern matching on the result via `case` hits a codegen domination
    // issue in FFI Option return handling.
    // This test verifies the function compiles, links, and runs without crash.
    let source = read_fixture("stdlib_list_find.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "ok\n");
}

#[test]
fn e2e_list_any_all() {
    let source = read_fixture("stdlib_list_any_all.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "true\ntrue\nfalse\nfalse\n");
}

#[test]
fn e2e_list_contains() {
    let source = read_fixture("stdlib_list_contains.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "true\nfalse\nfalse\ntrue\ntrue\n");
}

// ── String Split/Join/Parse E2E Tests (Phase 46 Plan 02) ───────────────

#[test]
fn e2e_string_split_join() {
    let source = read_fixture("stdlib_string_split_join.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "3\nhello\nhello - world - foo\none,two,three\n");
}

#[test]
fn e2e_string_parse() {
    let source = read_fixture("stdlib_string_parse.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "42\nnone\n3.14\nnone\n-100\n");
}

// ── Extended List Collection Operations E2E Tests (Phase 47 Plan 01) ────

#[test]
fn e2e_stdlib_list_zip() {
    let source = read_fixture("stdlib_list_zip.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "1\n10\n3\n2\n");
}

#[test]
fn e2e_stdlib_list_flat_map() {
    let source = read_fixture("stdlib_list_flat_map.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "6\n1\n10\n2\n5\n1\n5\n");
}

#[test]
fn e2e_stdlib_list_enumerate() {
    let source = read_fixture("stdlib_list_enumerate.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "3\n0\n10\n");
}

#[test]
fn e2e_stdlib_list_take_drop() {
    let source = read_fixture("stdlib_list_take_drop.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "3\n10\n30\n2\n40\n5\n0\n");
}

// ── JSON Sum Type & Generic E2E Tests (Phase 50) ──────────────────────

#[test]
fn e2e_deriving_json_sum_type() {
    let source = read_fixture("deriving_json_sum_type.mpl");
    let output = compile_and_run(&source);
    let lines: Vec<&str> = output.trim().lines().collect();
    assert_eq!(lines.len(), 5, "expected 5 lines, got: {}", output);
    // Line 0: Circle encode
    let json1: serde_json::Value = serde_json::from_str(lines[0]).expect("valid JSON line 0");
    assert_eq!(json1["tag"], "Circle");
    assert!(json1["fields"].is_array());
    assert_eq!(json1["fields"].as_array().unwrap().len(), 1);
    assert!((json1["fields"][0].as_f64().unwrap() - 3.14).abs() < 0.01);
    // Line 1: Rectangle encode
    let json2: serde_json::Value = serde_json::from_str(lines[1]).expect("valid JSON line 1");
    assert_eq!(json2["tag"], "Rectangle");
    assert_eq!(json2["fields"].as_array().unwrap().len(), 2);
    assert!((json2["fields"][0].as_f64().unwrap() - 2.0).abs() < 0.01);
    assert!((json2["fields"][1].as_f64().unwrap() - 5.0).abs() < 0.01);
    // Line 2: Point encode
    let json3: serde_json::Value = serde_json::from_str(lines[2]).expect("valid JSON line 2");
    assert_eq!(json3["tag"], "Point");
    assert_eq!(json3["fields"].as_array().unwrap().len(), 0);
    // Line 3: Circle decode verification
    assert_eq!(lines[3], "circle: 3.14");
    // Line 4: Point decode verification
    assert_eq!(lines[4], "point: ok");
}

#[test]
fn e2e_deriving_json_generic() {
    let source = read_fixture("deriving_json_generic.mpl");
    let output = compile_and_run(&source);
    let lines: Vec<&str> = output.trim().lines().collect();
    assert_eq!(lines.len(), 2, "expected 2 lines, got: {}", output);
    // Line 0: Wrapper<Int> encode
    let json1: serde_json::Value = serde_json::from_str(lines[0]).expect("valid JSON line 0");
    assert_eq!(json1["value"], 42);
    // Line 1: Wrapper<String> encode
    let json2: serde_json::Value = serde_json::from_str(lines[1]).expect("valid JSON line 1");
    assert_eq!(json2["value"], "hello");
}

#[test]
fn e2e_deriving_json_nested_sum() {
    let source = read_fixture("deriving_json_nested_sum.mpl");
    let output = compile_and_run(&source);
    let lines: Vec<&str> = output.trim().lines().collect();
    assert_eq!(lines.len(), 1, "expected 1 line, got: {}", output);
    let json: serde_json::Value = serde_json::from_str(lines[0]).expect("valid JSON");
    // Verify Drawing struct has name and shapes fields
    assert_eq!(json["name"], "test");
    assert!(json["shapes"].is_array(), "shapes should be array");
    let shapes = json["shapes"].as_array().unwrap();
    assert_eq!(shapes.len(), 3, "expected 3 shapes");
    // First shape: Circle(1.0)
    assert_eq!(shapes[0]["tag"], "Circle");
    assert_eq!(shapes[0]["fields"].as_array().unwrap().len(), 1);
    assert!((shapes[0]["fields"][0].as_f64().unwrap() - 1.0).abs() < 0.01);
    // Second shape: Point
    assert_eq!(shapes[1]["tag"], "Point");
    assert_eq!(shapes[1]["fields"].as_array().unwrap().len(), 0);
    // Third shape: Circle(2.5)
    assert_eq!(shapes[2]["tag"], "Circle");
    assert!((shapes[2]["fields"][0].as_f64().unwrap() - 2.5).abs() < 0.01);
}

#[test]
fn e2e_deriving_json_sum_non_serializable_compile_fail() {
    // Verify that deriving(Json) on a sum type with a non-serializable variant field (Pid)
    // produces a compile error containing E0038.
    let source = r#"
type BadSum do
  HasPid(Pid)
end deriving(Json)

fn main() do
  0
end
"#;
    let result = compile_only(source);
    assert!(
        !result.status.success(),
        "Expected compilation failure for non-serializable variant field, but it succeeded"
    );
    let stderr = String::from_utf8_lossy(&result.stderr);
    assert!(
        stderr.contains("E0038") || stderr.contains("not JSON-serializable"),
        "Expected E0038 error for sum type variant field, got stderr: {}",
        stderr
    );
}

// ── json { } literal tests (Phase 132) ────────────────────────────────

#[test]
fn e2e_json_literal_basic() {
    let source = read_fixture("json_literal_basic.mpl");
    let output = compile_and_run(&source);
    let lines: Vec<&str> = output.trim().lines().collect();
    assert!(lines.len() >= 3, "expected 3 output lines, got: {}", output);
    let line0: serde_json::Value =
        serde_json::from_str(lines[0]).expect("line 0 must be valid JSON");
    assert_eq!(line0["status"], "ok");
    let line1: serde_json::Value =
        serde_json::from_str(lines[1]).expect("line 1 must be valid JSON");
    assert_eq!(line1["count"], 42);
    assert_eq!(line1["active"], true);
    let line2: serde_json::Value =
        serde_json::from_str(lines[2]).expect("line 2 must be valid JSON");
    assert!(line2["value"].is_null());
}

#[test]
fn e2e_json_literal_nested() {
    let source = read_fixture("json_literal_nested.mpl");
    let output = compile_and_run(&source);
    let parsed: serde_json::Value =
        serde_json::from_str(output.trim()).expect("output must be valid JSON");
    // result field must be an object (not a quoted string -- that would be double-encoding)
    assert!(
        parsed["result"].is_object(),
        "nested json must be embedded raw, not double-encoded"
    );
    assert_eq!(parsed["result"]["code"], 200);
    assert_eq!(parsed["ok"], true);
}

#[test]
fn e2e_json_literal_list() {
    let source = read_fixture("json_literal_list.mpl");
    let output = compile_and_run(&source);
    let parsed: serde_json::Value =
        serde_json::from_str(output.trim()).expect("output must be valid JSON");
    assert!(
        parsed["tags"].is_array(),
        "List<String> must serialize as JSON array"
    );
    let tags = parsed["tags"].as_array().unwrap();
    assert_eq!(tags.len(), 2);
    assert_eq!(tags[0], "error");
    assert_eq!(tags[1], "critical");
    assert_eq!(parsed["count"], 2);
}

#[test]
fn e2e_json_literal_option() {
    let source = read_fixture("json_literal_option.mpl");
    let output = compile_and_run(&source);
    let lines: Vec<&str> = output.trim().lines().collect();
    assert!(lines.len() >= 2, "expected 2 output lines, got: {}", output);
    let r1: serde_json::Value = serde_json::from_str(lines[0]).expect("line 0 must be valid JSON");
    assert_eq!(r1["data"], "value", "Some(v) must serialize as the value");
    let r2: serde_json::Value = serde_json::from_str(lines[1]).expect("line 1 must be valid JSON");
    assert!(r2["data"].is_null(), "None must serialize as null");
}

#[test]
fn e2e_json_literal_struct() {
    let source = read_fixture("json_literal_struct.mpl");
    let output = compile_and_run(&source);
    let parsed: serde_json::Value =
        serde_json::from_str(output.trim()).expect("output must be valid JSON");
    assert!(
        parsed["point"].is_object(),
        "deriving(Json) struct must embed as nested object"
    );
    assert_eq!(parsed["point"]["x"], 3);
    assert_eq!(parsed["point"]["y"], 4);
    assert_eq!(parsed["label"], "origin");
}

// ── Phase 47 Plan 02: Map/Set Conversion E2E Tests ────────────────────

#[test]
fn e2e_stdlib_map_conversions() {
    let map_conv_source = read_fixture("stdlib_map_conversions.mpl");
    let map_conv_output = compile_and_run(&map_conv_source);
    assert_eq!(map_conv_output, "3\n10\n200\n30\n2\n2\n10\n20\n");
}

#[test]
fn e2e_stdlib_set_conversions() {
    let set_conv_source = read_fixture("stdlib_set_conversions.mpl");
    let set_conv_output = compile_and_run(&set_conv_source);
    assert_eq!(set_conv_output, "1\ntrue\nfalse\n3\n3\ntrue\ntrue\n");
}

// ── HTTP Path Parameters E2E Tests (Phase 51 Plan 02) ──────────────────
//
// Verifies the full Phase 51 stack: Mesh source -> typeck -> MIR -> LLVM ->
// runtime HTTP server with path parameter extraction, method-specific routing,
// exact-before-parameterized priority, and backward-compatible fallback.

/// Send an HTTP request to `127.0.0.1:{port}` with retries.
/// Returns the raw HTTP response as a string. Panics after 5 failed attempts.
fn send_request(port: u16, request: &str) -> String {
    let mut response = String::new();
    for attempt in 0..5 {
        if attempt > 0 {
            std::thread::sleep(std::time::Duration::from_millis(200));
        }
        match std::net::TcpStream::connect(format!("127.0.0.1:{}", port)) {
            Ok(mut stream) => {
                stream
                    .set_read_timeout(Some(std::time::Duration::from_secs(5)))
                    .unwrap();
                stream
                    .write_all(request.as_bytes())
                    .expect("failed to write HTTP request");
                stream
                    .read_to_string(&mut response)
                    .expect("failed to read HTTP response");
                return response;
            }
            Err(_) => continue,
        }
    }
    panic!("Failed to connect to 127.0.0.1:{} after 5 attempts", port);
}

/// A handler reads everything a request carries: its method, path,
/// headers (by name, whatever their case), query parameters, body as text
/// and bytes, idempotency key and correlation ID; a name the request lacks
/// reads as None.
#[test]
fn e2e_http_request_accessors() {
    let (_guard, port) =
        serve_on_free_port(&read_fixture("stdlib_http_request_accessors.mpl"), 18083);
    let body = |request: &str| {
        let response = send_request(port, request);
        assert!(response.starts_with("HTTP/1.1 200"), "{response}");
        response.split("\r\n\r\n").nth(1).unwrap_or("").to_string()
    };
    assert_eq!(
        body("POST /echo?page=3&x=y HTTP/1.1\r\nHost: localhost\r\nX-Agent: probe\r\nIdempotency-Key: once-1\r\nContent-Length: 5\r\nConnection: close\r\n\r\nhello"),
        "POST /echo agent=probe page=3 missing=none key=once-1 id=true body=hello bytes=5"
    );
    assert_eq!(
        body("GET /plain HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n"),
        "GET /plain agent=none page=none missing=none key=none id=true body= bytes=0"
    );
}

#[test]
fn e2e_http_path_params() {
    let source = read_fixture("stdlib_http_path_params.mpl");
    let (_guard, port) = serve_on_free_port(&source, 18082);

    // Test A: Path parameter extraction (HTTP-01 + HTTP-02)
    let resp_a = send_request(
        port,
        "GET /users/42 HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n",
    );
    assert!(
        resp_a.contains("200"),
        "Test A: Expected 200, got: {}",
        resp_a
    );
    assert!(
        resp_a.contains("42"),
        "Test A: Expected body '42', got: {}",
        resp_a
    );

    std::thread::sleep(std::time::Duration::from_millis(50));

    // Test B: Exact route priority (SC-4) -- /users/me beats /users/:id
    let resp_b = send_request(
        port,
        "GET /users/me HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n",
    );
    assert!(
        resp_b.contains("200"),
        "Test B: Expected 200, got: {}",
        resp_b
    );
    // The body must be "me" from the exact route handler, not the param handler.
    // Split on the HTTP headers to get the body.
    let body_b = resp_b.split("\r\n\r\n").nth(1).unwrap_or("");
    assert_eq!(
        body_b.trim(),
        "me",
        "Test B: Expected exact route 'me', got body: '{}'",
        body_b
    );

    std::thread::sleep(std::time::Duration::from_millis(50));

    // Test C: Method-specific routing (HTTP-03) -- POST /data
    let resp_c = send_request(
        port,
        "POST /data HTTP/1.1\r\nHost: localhost\r\nContent-Length: 0\r\nConnection: close\r\n\r\n",
    );
    assert!(
        resp_c.contains("200"),
        "Test C: Expected 200, got: {}",
        resp_c
    );
    assert!(
        resp_c.contains("posted"),
        "Test C: Expected body 'posted', got: {}",
        resp_c
    );

    std::thread::sleep(std::time::Duration::from_millis(50));

    // Test D: Method filtering -- POST /users/42 should hit fallback (not the GET-only route)
    let resp_d = send_request(
        port,
        "POST /users/42 HTTP/1.1\r\nHost: localhost\r\nContent-Length: 0\r\nConnection: close\r\n\r\n",
    );
    assert!(
        resp_d.contains("200"),
        "Test D: Expected 200 (fallback), got: {}",
        resp_d
    );
    assert!(
        resp_d.contains("fallback"),
        "Test D: Expected fallback body, got: {}",
        resp_d
    );

    std::thread::sleep(std::time::Duration::from_millis(50));

    // Test E: Fallback route (backward compat) -- GET /unknown/path
    let resp_e = send_request(
        port,
        "GET /unknown/path HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n",
    );
    assert!(
        resp_e.contains("200"),
        "Test E: Expected 200 (fallback), got: {}",
        resp_e
    );
    assert!(
        resp_e.contains("fallback"),
        "Test E: Expected fallback body, got: {}",
        resp_e
    );

    // ServerGuard Drop stops the server process (path params).
}

// ── HTTP Middleware E2E Tests (Phase 52 Plan 02) ────────────────────────
//
// Verifies the full Phase 52 middleware stack: Mesh source -> typeck -> MIR ->
// LLVM -> runtime HTTP server with middleware interception. Tests passthrough
// middleware, short-circuit (auth), and middleware on unmatched routes (404).

#[test]
fn e2e_http_middleware() {
    let source = read_fixture("stdlib_http_middleware.mpl");
    let (_guard, port) = serve_on_free_port(&source, 18083);

    // Test A: Normal request passes through middleware chain.
    // logger passes through, auth_check allows (path doesn't start with /secret),
    // handler returns "hello-world".
    let resp_a = send_request(
        port,
        "GET /hello HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n",
    );
    assert!(
        resp_a.contains("200"),
        "Test A: Expected 200, got: {}",
        resp_a
    );
    assert!(
        resp_a.contains("hello-world"),
        "Test A: Expected body 'hello-world', got: {}",
        resp_a
    );

    std::thread::sleep(std::time::Duration::from_millis(50));

    // Test B: Auth middleware short-circuits for /secret path.
    // logger passes through, auth_check sees /secret and returns 401 without calling next.
    let resp_b = send_request(
        port,
        "GET /secret HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n",
    );
    assert!(
        resp_b.contains("401"),
        "Test B: Expected 401, got: {}",
        resp_b
    );
    assert!(
        resp_b.contains("Unauthorized"),
        "Test B: Expected body 'Unauthorized', got: {}",
        resp_b
    );

    std::thread::sleep(std::time::Duration::from_millis(50));

    // Test C: Middleware runs on requests with no matching route (404).
    // Middleware chain executes (logger, auth_check), auth_check passes through
    // (path doesn't start with /secret), synthetic 404 handler returns 404.
    let resp_c = send_request(
        port,
        "GET /nonexistent HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n",
    );
    assert!(
        resp_c.contains("404"),
        "Test C: Expected 404, got: {}",
        resp_c
    );

    // ServerGuard Drop stops the server process (middleware).
}

/// QUAL-02: Handler parameter type is inferred without explicit :: Request annotation
/// when the handler body uses Request.* accessors (e.g., Request.path). This works
/// because the accessor calls constrain the type variable to Request during body
/// inference, before generalization occurs.
///
/// Note: Passthrough middleware (fn pass(request, next) do next(request) end) still
/// requires :: Request annotation because the body does not directly constrain request.
#[test]
fn e2e_http_middleware_inferred() {
    let source = read_fixture("stdlib_http_middleware_inferred.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "middleware_inferred_ok\n");
}

// ── SQLite E2E Tests (Phase 53 Plan 02) ─────────────────────────────────
//
// Verifies the full SQLite driver pipeline: Mesh source -> compiler ->
// linked binary -> in-memory SQLite CRUD operations. Tests open, execute
// (DDL + DML with params), query with column names, parameterized WHERE,
// and close.

#[test]
fn e2e_sqlite() {
    let source = read_fixture("stdlib_sqlite.mpl");
    let output = compile_and_run(&source);
    // Verify insert counts
    assert!(output.contains("1"), "First insert should affect 1 row");
    // Verify query results
    assert!(output.contains("Alice:30"), "Should find Alice with age 30");
    assert!(output.contains("Bob:25"), "Should find Bob with age 25");
    // Verify parameterized query
    assert!(
        output.contains("filtered:Alice"),
        "Filtered query should find Alice"
    );
    // Verify completion
    assert!(
        output.contains("done"),
        "Program should complete successfully"
    );
}

// ── Phase 107 Gap Closure: SQLite JOIN Runtime Tests ────────────────────
//
// Verifies JOIN queries return correct row data at runtime against a real
// SQLite database. Tests INNER JOIN (both tables' columns), LEFT JOIN (NULL
// for unmatched rows), and multi-table JOIN (3+ tables).
// Proves ROADMAP SC2 (NULL handling) and SC4 (multi-table field mapping).

#[test]
fn e2e_sqlite_join_runtime() {
    let source = read_fixture("sqlite_join_runtime.mpl");
    let output = compile_and_run(&source);
    // INNER JOIN: 2 rows with fields from both tables
    assert!(
        output.contains("inner_join"),
        "Should have inner_join section"
    );
    assert!(
        output.contains("Alice:Engineer"),
        "Inner join should return Alice with Engineer bio"
    );
    assert!(
        output.contains("Bob:Designer"),
        "Inner join should return Bob with Designer bio"
    );
    // LEFT JOIN: 3 rows, Charlie's bio is empty (NULL mapped to empty string)
    assert!(
        output.contains("left_join"),
        "Should have left_join section"
    );
    assert!(
        output.contains("Charlie:"),
        "Left join should return Charlie with empty bio (NULL)"
    );
    // Multi-table JOIN: columns from users, profiles, and departments
    assert!(
        output.contains("multi_join"),
        "Should have multi_join section"
    );
    assert!(
        output.contains("Alice:Engineer:Engineering"),
        "Multi-join should return Alice with bio and dept"
    );
    assert!(
        output.contains("Bob:Designer:Design"),
        "Multi-join should return Bob with bio and dept"
    );
    // Success
    assert!(
        output.contains("done"),
        "Program should complete successfully"
    );
}

// ── Phase 108: SQLite Aggregate Runtime Tests ───────────────────────────
//
// Verifies aggregate queries (count/sum/avg/min/max, GROUP BY, HAVING)
// execute correctly against a real SQLite database with correct results.
// Proves AGG-01 through AGG-04 at runtime.

#[test]
fn e2e_sqlite_aggregate_runtime() {
    let source = read_fixture("sqlite_aggregate_runtime.mpl");
    let output = compile_and_run(&source);
    let lines: Vec<&str> = output.trim().split('\n').collect();

    // AGG-01: count(*) = 6 total orders
    assert_eq!(lines[0], "count_all");
    assert_eq!(lines[1], "6");

    // AGG-02: sum=710, avg=118.333..., min=25, max=300
    assert_eq!(lines[2], "sum_avg_min_max");
    let agg_parts: Vec<&str> = lines[3].split(':').collect();
    assert_eq!(agg_parts[0], "710"); // sum
                                     // avg may be 118.333... or 118 depending on SQLite integer division
    assert!(agg_parts[1].starts_with("118")); // avg (118 or 118.333...)
    assert_eq!(agg_parts[2], "25"); // min
    assert_eq!(agg_parts[3], "300"); // max

    // AGG-03: GROUP BY -- 3 groups
    assert_eq!(lines[4], "group_by");
    assert_eq!(lines[5], "books:2:60"); // books: 2 orders, sum=60
    assert_eq!(lines[6], "clothing:1:50"); // clothing: 1 order, sum=50
    assert_eq!(lines[7], "electronics:3:600"); // electronics: 3 orders, sum=600

    // AGG-04: HAVING count > 1 -- only books and electronics
    assert_eq!(lines[8], "having");
    assert_eq!(lines[9], "books:2");
    assert_eq!(lines[10], "electronics:3");

    assert_eq!(lines[11], "done");
}

// ── Phase 109: SQLite Upsert, DELETE RETURNING, Subquery WHERE Runtime Tests ──
//
// Verifies ON CONFLICT DO UPDATE SET RETURNING, DELETE ... RETURNING *,
// and WHERE IN (subquery) execute correctly against real SQLite data.
// Uses raw SQL matching build_upsert_sql_pure and delete_where_returning output.
// Proves UPS-01 through UPS-03 at runtime.

#[test]
fn e2e_sqlite_upsert_subquery_runtime() {
    let source = read_fixture("sqlite_upsert_subquery_runtime.mpl");
    let output = compile_and_run(&source);
    // UPS-01: Upsert via ON CONFLICT DO UPDATE SET RETURNING
    assert!(
        output.contains("upsert_insert:Delta"),
        "upsert insert failed: {}",
        output
    );
    assert!(
        output.contains("upsert_update:Delta-Updated"),
        "upsert update failed: {}",
        output
    );
    assert!(
        output.contains("upsert_count:4"),
        "upsert count should be 4 (no duplicate): {}",
        output
    );
    // UPS-02: DELETE with RETURNING
    assert!(
        output.contains("delete_ret_name:Gamma"),
        "deleted row should be Gamma: {}",
        output
    );
    assert!(
        output.contains("delete_after_count:0"),
        "p3 should be gone after delete: {}",
        output
    );
    // UPS-03: Subquery WHERE verification
    assert!(
        output.contains("subquery_first:Alpha"),
        "subquery first should be Alpha: {}",
        output
    );
    // Completion
    assert!(output.contains("done"), "did not complete: {}", output);
}

// ── PostgreSQL E2E Tests (Phase 54 Plan 02) ─────────────────────────────
//
// Verifies the full PostgreSQL driver pipeline: Mesh source -> compiler ->
// linked binary -> TCP connection to PostgreSQL -> wire protocol -> CRUD
// operations. Tests connect (SCRAM-SHA-256/MD5 auth), execute (DDL + DML
// with $1/$2 params), query with column names, filtered query, and close.
//
// Requires a running PostgreSQL instance at MESH_TEST_DATABASE_URL, or else
// user, password and database mesh_test on localhost:5432. The coverage run
// (scripts/compiler-coverage.py) starts one in a container.
//
// Run with: cargo test e2e_pg -- --ignored

#[test]
#[ignore = "requires MESH_TEST_DATABASE_URL or the documented local mesh_test PostgreSQL"]
fn e2e_pg() {
    let source = read_fixture("stdlib_pg.mpl");
    let output = compile_and_run(&source);
    // Verify DDL result (CREATE TABLE returns 0 rows affected in PostgreSQL)
    assert!(
        output.contains("created: 0"),
        "CREATE TABLE should report 0 rows affected"
    );
    // Verify insert counts
    assert!(output.contains("inserted: 1"), "INSERT should affect 1 row");
    // Verify query results
    assert!(
        output.contains("Alice is 30"),
        "Should find Alice with age 30"
    );
    assert!(output.contains("Bob is 25"), "Should find Bob with age 25");
    // Verify parameterized query
    assert!(
        output.contains("older: Alice"),
        "Filtered query should find Alice (age 30 > 26)"
    );
    // Verify completion
    assert!(
        output.contains("done"),
        "Program should complete successfully"
    );
}

// ── Struct-in-Result ABI regression ────────────────────────────────────

/// Result<MultiFieldStruct, String> construct + match roundtrip.
/// Constructs Ok(Pair{42, 99}), Ok(Triple{10, 20, 30}), and Err("error"),
/// pattern matches to extract field sums. Validates that pointer-boxing
/// prevents the buffer overflow segfault when storing multi-field structs
/// into the {i8, ptr} sum type layout.
#[test]
fn e2e_struct_in_result_roundtrip() {
    let source = read_fixture("struct_in_result_roundtrip.mpl");
    let output = compile_and_run(&source);
    assert_eq!(output, "141\n-1\n60\n");
}

// ── HTTP route-handler boundary regressions ────────────────────────────

fn route_bare_server_source() -> &'static str {
    r#"
fn handler(_request) do
  HTTP.response(200, "bare_ok")
end

fn main() do
  let r = HTTP.router()
  let r = HTTP.route(r, "/", handler)
  HTTP.serve(r, 18124)
end
"#
}

fn route_closure_server_source() -> &'static str {
    r#"
fn main() do
  let suffix = "ok"
  let handler = fn(_request) do
    HTTP.response(200, "closure_" <> suffix)
  end

  let r = HTTP.router()
  let r = HTTP.route(r, "/", handler)
  HTTP.serve(r, 18123)
end
"#
}

/// Confirms a bare-function route handler serves live HTTP requests correctly.
#[test]
fn e2e_route_bare_handler_control() {
    let (_guard, port) = serve_on_free_port(route_bare_server_source(), 18124);

    let response = send_request(
        port,
        "GET / HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n",
    );
    assert!(
        response.contains("HTTP/1.1 200 OK"),
        "Expected bare-function control to return HTTP 200, got: {}",
        response
    );
    let body = response.split("\r\n\r\n").nth(1).unwrap_or("");
    assert_eq!(
        body.trim(),
        "bare_ok",
        "Expected bare-function control body 'bare_ok', got: {:?}",
        body
    );
}

/// A closure route handler serves live requests, like the bare-function
/// control above. This used to be the known limit: the closure form built but
/// crashed the server at request time, because route registration had no way
/// to receive the closure's environment.
#[test]
fn e2e_route_closure_handler() {
    let (_guard, port) = serve_on_free_port(route_closure_server_source(), 18123);

    let response = send_request(
        port,
        "GET / HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n",
    );
    assert!(
        response.contains("HTTP/1.1 200 OK"),
        "Expected the closure route to return HTTP 200, got: {}",
        response
    );
    let body = response.split("\r\n\r\n").nth(1).unwrap_or("");
    assert_eq!(
        body.trim(),
        "closure_ok",
        "Expected the closure route body 'closure_ok', got: {:?}",
        body
    );
}
