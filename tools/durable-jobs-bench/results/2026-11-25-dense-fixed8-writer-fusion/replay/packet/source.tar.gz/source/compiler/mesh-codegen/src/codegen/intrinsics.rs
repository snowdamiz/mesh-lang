//! Runtime function declarations in the LLVM module.
//!
//! Declares all `mesh-rt` extern "C" functions so that codegen can emit
//! calls to them. These declarations must match the signatures in the
//! `mesh-rt` crate exactly.

use inkwell::module::Module;
use inkwell::types::BasicMetadataTypeEnum;
use inkwell::values::FunctionValue;
use inkwell::AddressSpace;

/// Declare all Mesh runtime functions in the LLVM module.
///
/// This should be called once during module initialization, before any
/// codegen that might reference runtime functions.
pub fn declare_intrinsics<'ctx>(module: &Module<'ctx>) {
    let context = module.get_context();
    let void_type = context.void_type();
    let i8_type = context.i8_type();
    let i32_type = context.i32_type();
    let i64_type = context.i64_type();
    let f64_type = context.f64_type();
    let ptr_type = context.ptr_type(AddressSpace::default());

    // mesh_rt_init() -> void
    let init_ty = void_type.fn_type(&[], false);
    module.add_function(
        "mesh_rt_init",
        init_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_rt_disable_core_dumps() -> void: release builds call it first in `main`
    module.add_function(
        "mesh_rt_disable_core_dumps",
        void_type.fn_type(&[], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_run_main(entry: ptr) -> void: runs `main`, turning a panic into exit 101
    module.add_function(
        "mesh_run_main",
        void_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_library_invoke(entrypoint: ptr, input: ptr, len: u64, output: ptr) -> i32
    module.add_function(
        "mesh_library_invoke",
        i32_type.fn_type(
            &[
                ptr_type.into(),
                ptr_type.into(),
                i64_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    for name in [
        "mesh_host_secure_store_put",
        "mesh_host_secure_store_get",
        "mesh_host_secure_store_delete",
        "mesh_host_push_get_token",
        "mesh_host_background_schedule",
        "mesh_host_network_state",
        "mesh_host_monotonic_clock",
        "mesh_host_wall_clock",
        "mesh_host_log_redacted",
    ] {
        module.add_function(
            name,
            ptr_type.fn_type(&[ptr_type.into()], false),
            Some(inkwell::module::Linkage::External),
        );
    }

    // mesh_register_autonomous_config_json(data: ptr, len: u64) -> i32
    module.add_function(
        "mesh_register_autonomous_config_json",
        i32_type.fn_type(&[ptr_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_gc_alloc_actor(size: u64, align: u64) -> ptr
    let gc_alloc_ty = ptr_type.fn_type(&[i64_type.into(), i64_type.into()], false);
    module.add_function(
        "mesh_gc_alloc_actor",
        gc_alloc_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_string_new(data: ptr, len: u64) -> ptr
    let string_new_ty = ptr_type.fn_type(&[ptr_type.into(), i64_type.into()], false);
    module.add_function(
        "mesh_string_new",
        string_new_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_string_concat(a: ptr, b: ptr) -> ptr
    let string_concat_ty = ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false);
    module.add_function(
        "mesh_string_concat",
        string_concat_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_int_to_string(val: i64) -> ptr
    let int_to_string_ty = ptr_type.fn_type(&[i64_type.into()], false);
    module.add_function(
        "mesh_int_to_string",
        int_to_string_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_pid_to_string(pid: i64) -> ptr
    module.add_function(
        "mesh_pid_to_string",
        int_to_string_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_float_to_string(val: f64) -> ptr
    let float_to_string_ty = ptr_type.fn_type(&[f64_type.into()], false);
    module.add_function(
        "mesh_float_to_string",
        float_to_string_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_bool_to_string(val: i8) -> ptr
    let bool_to_string_ty = ptr_type.fn_type(&[i8_type.into()], false);
    module.add_function(
        "mesh_bool_to_string",
        bool_to_string_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_print(s: ptr) -> void
    let print_ty = void_type.fn_type(&[ptr_type.into()], false);
    module.add_function(
        "mesh_print",
        print_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_println(s: ptr) -> void
    let println_ty = void_type.fn_type(&[ptr_type.into()], false);
    module.add_function(
        "mesh_println",
        println_ty,
        Some(inkwell::module::Linkage::External),
    );

    // ── Actor runtime functions ──────────────────────────────────────────

    // mesh_rt_init_actor(num_schedulers: i32) -> void
    let init_actor_ty = void_type.fn_type(&[i32_type.into()], false);
    module.add_function(
        "mesh_rt_init_actor",
        init_actor_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_actor_spawn(fn_ptr: ptr, args: ptr, args_size: i64, priority: i8) -> i64
    let spawn_ty = i64_type.fn_type(
        &[
            ptr_type.into(),
            ptr_type.into(),
            i64_type.into(),
            i8_type.into(),
        ],
        false,
    );
    module.add_function(
        "mesh_actor_spawn",
        spawn_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_actor_spawn_shaped(fn_ptr: ptr, args: ptr, args_size: i64, priority: i8, shape: ptr) -> i64
    module.add_function(
        "mesh_actor_spawn_shaped",
        i64_type.fn_type(
            &[
                ptr_type.into(),
                ptr_type.into(),
                i64_type.into(),
                i8_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_actor_spawn_grouped(fn_ptr, args, args_size, shape, terminate) -> i64
    module.add_function(
        "mesh_actor_spawn_grouped",
        i64_type.fn_type(
            &[
                ptr_type.into(),
                ptr_type.into(),
                i64_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    module.add_function(
        "mesh_actor_spawn_step",
        i64_type.fn_type(
            &[
                ptr_type.into(),
                ptr_type.into(),
                i32_type.into(),
                ptr_type.into(),
                i64_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        None,
    );
    module.add_function(
        "mesh_actor_spawn_movable_step",
        i64_type.fn_type(
            &[
                ptr_type.into(),
                ptr_type.into(),
                i32_type.into(),
                ptr_type.into(),
                i64_type.into(),
                ptr_type.into(),
                i64_type.into(),
                i8_type.into(),
            ],
            false,
        ),
        None,
    );
    module.add_function("mesh_step_charge", void_type.fn_type(&[], false), None);

    // mesh_actor_send(target_pid: i64, msg_ptr: ptr, msg_size: i64) -> i64
    let send_ty = i64_type.fn_type(&[i64_type.into(), ptr_type.into(), i64_type.into()], false);
    module.add_function(
        "mesh_actor_send",
        send_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_actor_send_shaped(target_pid: i64, msg_ptr: ptr, msg_size: i64, shape: ptr) -> i64
    let send_typed_ty = i64_type.fn_type(
        &[
            i64_type.into(),
            ptr_type.into(),
            i64_type.into(),
            ptr_type.into(),
        ],
        false,
    );
    module.add_function(
        "mesh_actor_send_shaped",
        send_typed_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_actor_receive(timeout_ms: i64) -> ptr
    let receive_ty = ptr_type.fn_type(&[i64_type.into()], false);
    module.add_function(
        "mesh_actor_receive",
        receive_ty,
        Some(inkwell::module::Linkage::External),
    );

    module.add_function(
        "mesh_actor_receive_scalar",
        ptr_type.fn_type(&[i64_type.into(), i64_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_actor_wait_timeout",
        void_type.fn_type(&[i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_actor_stop",
        void_type.fn_type(&[], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_actor_self() -> i64
    let self_ty = i64_type.fn_type(&[], false);
    module.add_function(
        "mesh_actor_self",
        self_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_actor_link(target_pid: i64) -> void
    let link_ty = void_type.fn_type(&[i64_type.into()], false);
    module.add_function(
        "mesh_actor_link",
        link_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_reduction_check() -> void
    let reduction_ty = void_type.fn_type(&[], false);
    module.add_function(
        "mesh_reduction_check",
        reduction_ty,
        Some(inkwell::module::Linkage::External),
    );

    module.add_function(
        "mesh_reduction_state_v1",
        ptr_type.fn_type(&[], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_actor_set_terminate(pid: i64, callback_fn_ptr: ptr) -> void
    let set_terminate_ty = void_type.fn_type(&[i64_type.into(), ptr_type.into()], false);
    module.add_function(
        "mesh_actor_set_terminate",
        set_terminate_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_rt_run_scheduler() -> void
    let run_scheduler_ty = void_type.fn_type(&[], false);
    module.add_function(
        "mesh_rt_run_scheduler",
        run_scheduler_ty,
        Some(inkwell::module::Linkage::External),
    );

    // ── Supervisor runtime functions ─────────────────────────────────────

    // mesh_supervisor_start(config_ptr: ptr, config_size: i64) -> i64 (PID)
    let sup_start_ty = i64_type.fn_type(&[ptr_type.into(), i64_type.into()], false);
    module.add_function(
        "mesh_supervisor_start",
        sup_start_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_supervisor_start_child(sup_pid: i64, args_ptr: ptr, args_size: i64) -> i64
    let sup_start_child_ty =
        i64_type.fn_type(&[i64_type.into(), ptr_type.into(), i64_type.into()], false);
    module.add_function(
        "mesh_supervisor_start_child",
        sup_start_child_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_supervisor_terminate_child(sup_pid: i64, child_pid: i64) -> i64
    let sup_term_child_ty = i64_type.fn_type(&[i64_type.into(), i64_type.into()], false);
    module.add_function(
        "mesh_supervisor_terminate_child",
        sup_term_child_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_supervisor_count_children(sup_pid: i64) -> i64
    let sup_count_ty = i64_type.fn_type(&[i64_type.into()], false);
    module.add_function(
        "mesh_supervisor_count_children",
        sup_count_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_actor_trap_exit() -> void
    let trap_exit_ty = void_type.fn_type(&[], false);
    module.add_function(
        "mesh_actor_trap_exit",
        trap_exit_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_actor_exit(target_pid: i64, reason_tag: i8) -> void
    let actor_exit_ty = void_type.fn_type(&[i64_type.into(), i8_type.into()], false);
    module.add_function(
        "mesh_actor_exit",
        actor_exit_ty,
        Some(inkwell::module::Linkage::External),
    );

    // ── Standard library: String operations (Phase 8) ──────────────────

    // mesh_string_length(s: ptr) -> i64
    let string_length_ty = i64_type.fn_type(&[ptr_type.into()], false);
    module.add_function(
        "mesh_string_length",
        string_length_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_string_slice(s: ptr, start: i64, end: i64) -> ptr
    let string_slice_ty =
        ptr_type.fn_type(&[ptr_type.into(), i64_type.into(), i64_type.into()], false);
    module.add_function(
        "mesh_string_slice",
        string_slice_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_string_contains(haystack: ptr, needle: ptr) -> i8
    let string_contains_ty = i8_type.fn_type(&[ptr_type.into(), ptr_type.into()], false);
    module.add_function(
        "mesh_string_contains",
        string_contains_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_string_starts_with(s: ptr, prefix: ptr) -> i8
    let string_starts_with_ty = i8_type.fn_type(&[ptr_type.into(), ptr_type.into()], false);
    module.add_function(
        "mesh_string_starts_with",
        string_starts_with_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_string_ends_with(s: ptr, suffix: ptr) -> i8
    let string_ends_with_ty = i8_type.fn_type(&[ptr_type.into(), ptr_type.into()], false);
    module.add_function(
        "mesh_string_ends_with",
        string_ends_with_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_string_trim(s: ptr) -> ptr
    let string_trim_ty = ptr_type.fn_type(&[ptr_type.into()], false);
    module.add_function(
        "mesh_string_trim",
        string_trim_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_string_trim_start(s: ptr) -> ptr, mesh_string_trim_end(s: ptr) -> ptr
    for trim in ["mesh_string_trim_start", "mesh_string_trim_end"] {
        module.add_function(
            trim,
            string_trim_ty,
            Some(inkwell::module::Linkage::External),
        );
    }

    // mesh_string_repeat(s: ptr, count: i64) -> ptr
    module.add_function(
        "mesh_string_repeat",
        ptr_type.fn_type(&[ptr_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_string_to_upper(s: ptr) -> ptr
    let string_to_upper_ty = ptr_type.fn_type(&[ptr_type.into()], false);
    module.add_function(
        "mesh_string_to_upper",
        string_to_upper_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_string_to_lower(s: ptr) -> ptr
    let string_to_lower_ty = ptr_type.fn_type(&[ptr_type.into()], false);
    module.add_function(
        "mesh_string_to_lower",
        string_to_lower_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_string_replace(s: ptr, from: ptr, to: ptr) -> ptr
    let string_replace_ty =
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false);
    module.add_function(
        "mesh_string_replace",
        string_replace_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_string_eq(a: ptr, b: ptr) -> i8
    let string_eq_ty = i8_type.fn_type(&[ptr_type.into(), ptr_type.into()], false);
    module.add_function(
        "mesh_string_eq",
        string_eq_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_string_compare(a: ptr, b: ptr) -> i64 (-1, 0, 1)
    module.add_function(
        "mesh_string_compare",
        i64_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // Phase 46: String split/join/to_int/to_float
    // mesh_string_split(s: ptr, delim: ptr) -> ptr
    let string_split_ty = ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false);
    module.add_function(
        "mesh_string_split",
        string_split_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_string_join(list: ptr, sep: ptr) -> ptr
    let string_join_ty = ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false);
    module.add_function(
        "mesh_string_join",
        string_join_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_string_to_int(s: ptr) -> ptr (MeshOption)
    let string_to_int_ty = ptr_type.fn_type(&[ptr_type.into()], false);
    module.add_function(
        "mesh_string_to_int",
        string_to_int_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_string_to_float(s: ptr) -> ptr (MeshOption)
    let string_to_float_ty = ptr_type.fn_type(&[ptr_type.into()], false);
    module.add_function(
        "mesh_string_to_float",
        string_to_float_ty,
        Some(inkwell::module::Linkage::External),
    );

    // ── Standard library: File I/O functions (Phase 8) ────────────────

    // mesh_file_read(path: ptr) -> ptr (MeshResult)
    let file_read_ty = ptr_type.fn_type(&[ptr_type.into()], false);
    module.add_function(
        "mesh_file_read",
        file_read_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_file_read_bytes(path: ptr, offset: i64, length: i64) -> ptr (MeshResult)
    let file_read_bytes_ty =
        ptr_type.fn_type(&[ptr_type.into(), i64_type.into(), i64_type.into()], false);
    module.add_function(
        "mesh_file_read_bytes",
        file_read_bytes_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_file_write_bytes(path: ptr, offset: i64, bytes: ptr, truncate: i8) -> ptr
    let file_write_bytes_ty = ptr_type.fn_type(
        &[
            ptr_type.into(),
            i64_type.into(),
            ptr_type.into(),
            i8_type.into(),
        ],
        false,
    );
    module.add_function(
        "mesh_file_write_bytes",
        file_write_bytes_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_file_size(path: ptr) -> ptr (MeshResult)
    let file_size_ty = ptr_type.fn_type(&[ptr_type.into()], false);
    module.add_function(
        "mesh_file_size",
        file_size_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_file_write(path: ptr, content: ptr) -> ptr (MeshResult)
    let file_write_ty = ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false);
    module.add_function(
        "mesh_file_write",
        file_write_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_file_append(path: ptr, content: ptr) -> ptr (MeshResult)
    let file_append_ty = ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false);
    module.add_function(
        "mesh_file_append",
        file_append_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_file_exists(path: ptr) -> i8
    let file_exists_ty = i8_type.fn_type(&[ptr_type.into()], false);
    module.add_function(
        "mesh_file_exists",
        file_exists_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_file_delete(path: ptr) -> ptr (MeshResult)
    let file_delete_ty = ptr_type.fn_type(&[ptr_type.into()], false);
    module.add_function(
        "mesh_file_delete",
        file_delete_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_file_rename(from: ptr, to: ptr) -> ptr (MeshResult)
    let file_rename_ty = ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false);
    module.add_function(
        "mesh_file_rename",
        file_rename_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_file_sync(path: ptr) -> ptr (MeshResult)
    let file_sync_ty = ptr_type.fn_type(&[ptr_type.into()], false);
    module.add_function(
        "mesh_file_sync",
        file_sync_ty,
        Some(inkwell::module::Linkage::External),
    );

    // ── Standard library: IO functions (Phase 8) ─────────────────────

    // mesh_io_read_line() -> ptr (MeshResult)
    let io_read_line_ty = ptr_type.fn_type(&[], false);
    module.add_function(
        "mesh_io_read_line",
        io_read_line_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_io_eprintln(s: ptr) -> void
    let io_eprintln_ty = void_type.fn_type(&[ptr_type.into()], false);
    module.add_function(
        "mesh_io_eprintln",
        io_eprintln_ty,
        Some(inkwell::module::Linkage::External),
    );

    // ── Standard library: Env functions (Phase 8) ────────────────────

    // mesh_env_get(key: ptr) -> ptr (MeshOption)
    let env_get_ty = ptr_type.fn_type(&[ptr_type.into()], false);
    module.add_function(
        "mesh_env_get",
        env_get_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_env_args() -> ptr (List<String>)
    let env_args_ty = ptr_type.fn_type(&[], false);
    module.add_function(
        "mesh_env_args",
        env_args_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_env_get_with_default(key: ptr, default: ptr) -> ptr (MeshString)
    let env_get_def_ty = ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false);
    module.add_function(
        "mesh_env_get_with_default",
        env_get_def_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_env_get_int(key: ptr, default: i64) -> i64
    let env_get_int_ty = i64_type.fn_type(&[ptr_type.into(), i64_type.into()], false);
    module.add_function(
        "mesh_env_get_int",
        env_get_int_ty,
        Some(inkwell::module::Linkage::External),
    );

    module.add_function(
        "mesh_env_get_secret_hex",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // ── Standard library: Regex functions (Phase 119) ──────────────────

    // mesh_regex_from_literal(pattern: ptr, flags_bits: i64) -> ptr
    let regex_from_lit_ty = ptr_type.fn_type(&[ptr_type.into(), i64_type.into()], false);
    module.add_function(
        "mesh_regex_from_literal",
        regex_from_lit_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_regex_compile(pattern: ptr) -> ptr  (returns MeshOption/Result)
    let regex_compile_ty = ptr_type.fn_type(&[ptr_type.into()], false);
    module.add_function(
        "mesh_regex_compile",
        regex_compile_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_regex_match(rx_ptr: ptr, s: ptr) -> i8 (bool)
    let regex_match_ty = i8_type.fn_type(&[ptr_type.into(), ptr_type.into()], false);
    module.add_function(
        "mesh_regex_match",
        regex_match_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_regex_captures(rx_ptr: ptr, s: ptr) -> ptr  (MeshOption<List<String>>)
    let regex_captures_ty = ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false);
    module.add_function(
        "mesh_regex_captures",
        regex_captures_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_regex_replace(rx_ptr: ptr, s: ptr, replacement: ptr) -> ptr  (String)
    let regex_replace_ty =
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false);
    module.add_function(
        "mesh_regex_replace",
        regex_replace_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_regex_split(rx_ptr: ptr, s: ptr) -> ptr  (List<String>)
    let regex_split_ty = ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false);
    module.add_function(
        "mesh_regex_split",
        regex_split_ty,
        Some(inkwell::module::Linkage::External),
    );

    // ── Standard library: Crypto functions (Phase 135) ──────────────────────

    // mesh_crypto_sha256(s: ptr) -> ptr
    let sha256_ty = ptr_type.fn_type(&[ptr_type.into()], false);
    module.add_function(
        "mesh_crypto_sha256",
        sha256_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_crypto_sha512(s: ptr) -> ptr
    let sha512_ty = ptr_type.fn_type(&[ptr_type.into()], false);
    module.add_function(
        "mesh_crypto_sha512",
        sha512_ty,
        Some(inkwell::module::Linkage::External),
    );

    for name in ["mesh_crypto_sha256_hex", "mesh_crypto_sha512_hex"] {
        module.add_function(
            name,
            ptr_type.fn_type(&[ptr_type.into()], false),
            Some(inkwell::module::Linkage::External),
        );
    }

    module.add_function(
        "mesh_crypto_random_bytes",
        ptr_type.fn_type(&[i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_crypto_hmac_sha256(key: ptr, msg: ptr) -> ptr
    let hmac256_ty = ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false);
    module.add_function(
        "mesh_crypto_hmac_sha256",
        hmac256_ty,
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_crypto_hmac_sha256_tag",
        hmac256_ty,
        Some(inkwell::module::Linkage::External),
    );

    module.add_function(
        "mesh_crypto_hkdf_sha256",
        ptr_type.fn_type(
            &[
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                i64_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    module.add_function(
        "mesh_crypto_argon2id",
        ptr_type.fn_type(
            &[
                ptr_type.into(),
                ptr_type.into(),
                i64_type.into(),
                i64_type.into(),
                i64_type.into(),
                i64_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    for name in [
        "mesh_crypto_x25519_generate",
        "mesh_crypto_mlkem_generate",
        "mesh_crypto_signing_generate",
    ] {
        module.add_function(
            name,
            ptr_type.fn_type(&[], false),
            Some(inkwell::module::Linkage::External),
        );
    }

    module.add_function(
        "mesh_crypto_signing_from_seed",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    module.add_function(
        "mesh_crypto_signing_from_secret",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    module.add_function(
        "mesh_crypto_x25519_from_seed",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    module.add_function(
        "mesh_crypto_x25519_from_secret",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    module.add_function(
        "mesh_crypto_mlkem_from_seed",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    module.add_function(
        "mesh_crypto_mlkem_from_secret",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    for name in [
        "mesh_crypto_x25519_public",
        "mesh_crypto_mlkem_encapsulate",
        "mesh_crypto_aead_key",
    ] {
        module.add_function(
            name,
            ptr_type.fn_type(&[ptr_type.into()], false),
            Some(inkwell::module::Linkage::External),
        );
    }

    for name in [
        "mesh_crypto_x25519_shared",
        "mesh_crypto_mlkem_decapsulate",
        "mesh_crypto_sign",
    ] {
        module.add_function(
            name,
            ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
            Some(inkwell::module::Linkage::External),
        );
    }

    module.add_function(
        "mesh_crypto_verify",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // Blind RSA (BR1): every argument is a runtime pointer.
    for (name, arity) in [
        ("mesh_crypto_blind_rsa_generate", 0),
        ("mesh_crypto_blind_rsa_from_secret", 1),
        ("mesh_crypto_blind_rsa_public", 1),
        ("mesh_crypto_blind_rsa_public_from_spki", 1),
        ("mesh_crypto_blind_rsa_blind", 2),
        ("mesh_crypto_blind_rsa_sign", 2),
        ("mesh_crypto_blind_rsa_verify", 3),
        ("mesh_crypto_blind_rsa_finalize", 4),
    ] {
        module.add_function(
            name,
            ptr_type.fn_type(&vec![ptr_type.into(); arity], false),
            Some(inkwell::module::Linkage::External),
        );
    }

    for name in ["mesh_crypto_aead_seal", "mesh_crypto_aead_open"] {
        module.add_function(
            name,
            ptr_type.fn_type(
                &[
                    ptr_type.into(),
                    ptr_type.into(),
                    ptr_type.into(),
                    ptr_type.into(),
                ],
                false,
            ),
            Some(inkwell::module::Linkage::External),
        );
    }

    for name in [
        "mesh_crypto_hpke_seal",
        "mesh_crypto_hpke_open",
        "mesh_crypto_hpke_seal_secret",
        "mesh_crypto_hpke_open_secret",
        "mesh_crypto_hkdf_aead_seal",
        "mesh_crypto_hkdf_aead_open",
    ] {
        module.add_function(
            name,
            ptr_type.fn_type(
                &[
                    ptr_type.into(),
                    ptr_type.into(),
                    ptr_type.into(),
                    ptr_type.into(),
                ],
                false,
            ),
            Some(inkwell::module::Linkage::External),
        );
    }

    for name in [
        "mesh_crypto_hpke_seal_export",
        "mesh_crypto_hpke_open_export",
    ] {
        module.add_function(
            name,
            ptr_type.fn_type(&[ptr_type.into(); 5], false),
            Some(inkwell::module::Linkage::External),
        );
    }

    // mesh_crypto_hmac_sha512(key: ptr, msg: ptr) -> ptr
    let hmac512_ty = ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false);
    module.add_function(
        "mesh_crypto_hmac_sha512",
        hmac512_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_crypto_uuid4() -> ptr
    let uuid4_ty = ptr_type.fn_type(&[], false);
    module.add_function(
        "mesh_crypto_uuid4",
        uuid4_ty,
        Some(inkwell::module::Linkage::External),
    );

    // ── Standard library: Base64/Hex functions (Phase 135) ──────────────────

    // mesh_base64_encode(s: ptr) -> ptr
    let b64enc_ty = ptr_type.fn_type(&[ptr_type.into()], false);
    module.add_function(
        "mesh_base64_encode",
        b64enc_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_base64_decode(s: ptr) -> ptr (MeshResult)
    let b64dec_ty = ptr_type.fn_type(&[ptr_type.into()], false);
    module.add_function(
        "mesh_base64_decode",
        b64dec_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_base64_encode_url(s: ptr) -> ptr
    let b64url_enc_ty = ptr_type.fn_type(&[ptr_type.into()], false);
    module.add_function(
        "mesh_base64_encode_url",
        b64url_enc_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_base64_decode_url(s: ptr) -> ptr (MeshResult)
    let b64url_dec_ty = ptr_type.fn_type(&[ptr_type.into()], false);
    module.add_function(
        "mesh_base64_decode_url",
        b64url_dec_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_hex_encode(s: ptr) -> ptr
    let hex_enc_ty = ptr_type.fn_type(&[ptr_type.into()], false);
    module.add_function(
        "mesh_hex_encode",
        hex_enc_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_hex_decode(s: ptr) -> ptr (MeshResult)
    let hex_dec_ty = ptr_type.fn_type(&[ptr_type.into()], false);
    module.add_function(
        "mesh_hex_decode",
        hex_dec_ty,
        Some(inkwell::module::Linkage::External),
    );

    // ── Binary-safe Bytes ───────────────────────────────────────────────────

    module.add_function(
        "mesh_bytes_empty",
        ptr_type.fn_type(&[], false),
        Some(inkwell::module::Linkage::External),
    );
    for name in ["mesh_bytes_from_list", "mesh_bytes_to_list"] {
        module.add_function(
            name,
            ptr_type.fn_type(&[ptr_type.into()], false),
            Some(inkwell::module::Linkage::External),
        );
    }
    module.add_function(
        "mesh_bytes_repeat",
        ptr_type.fn_type(&[i64_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_bytes_length",
        i64_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_bytes_get",
        ptr_type.fn_type(&[ptr_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_bytes_slice",
        ptr_type.fn_type(&[ptr_type.into(), i64_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_bytes_concat",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_bytes_secure_equals",
        i8_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    for name in [
        "mesh_bytes_from_utf8",
        "mesh_bytes_from_base64",
        "mesh_bytes_from_base58",
        "mesh_bytes_from_hex",
    ] {
        module.add_function(
            name,
            ptr_type.fn_type(&[ptr_type.into()], false),
            Some(inkwell::module::Linkage::External),
        );
    }
    module.add_function(
        "mesh_json_array_length",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_json_is_null",
        i8_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_json_eq",
        i8_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    for name in [
        "mesh_bytes_to_utf8",
        "mesh_bytes_to_base64",
        "mesh_bytes_to_base58",
        "mesh_bytes_to_hex",
    ] {
        module.add_function(
            name,
            ptr_type.fn_type(&[ptr_type.into()], false),
            Some(inkwell::module::Linkage::External),
        );
    }
    module.add_function(
        "mesh_bytes_read_uint_le",
        ptr_type.fn_type(&[ptr_type.into(), i64_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_bytes_write_uint_le",
        ptr_type.fn_type(&[ptr_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    for name in [
        "mesh_bytes_read_u16_be",
        "mesh_bytes_read_u16_le",
        "mesh_bytes_read_u32_be",
        "mesh_bytes_read_u32_le",
        "mesh_bytes_read_u64_be",
        "mesh_bytes_read_u64_le",
    ] {
        module.add_function(
            name,
            ptr_type.fn_type(&[ptr_type.into(), i64_type.into()], false),
            Some(inkwell::module::Linkage::External),
        );
    }
    module.add_function(
        "mesh_bytes_write_u16_be",
        ptr_type.fn_type(&[i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    for name in ["mesh_bytes_write_u32_be", "mesh_bytes_write_u64_be"] {
        module.add_function(
            name,
            ptr_type.fn_type(&[ptr_type.into()], false),
            Some(inkwell::module::Linkage::External),
        );
    }
    module.add_function(
        "mesh_bytes_builder_new",
        ptr_type.fn_type(&[i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    for name in [
        "mesh_bytes_builder_write_u8",
        "mesh_bytes_builder_write_u16_be",
        "mesh_bytes_builder_write_u32_be",
    ] {
        module.add_function(
            name,
            ptr_type.fn_type(&[ptr_type.into(), i64_type.into()], false),
            Some(inkwell::module::Linkage::External),
        );
    }
    module.add_function(
        "mesh_bytes_builder_write_bytes",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_bytes_builder_finish",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_secret_random",
        ptr_type.fn_type(&[i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_storage_key_ephemeral",
        ptr_type.fn_type(&[], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_storage_key_from_secret",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_secret_from_bytes",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_storage_key_platform",
        ptr_type.fn_type(&[], false),
        Some(inkwell::module::Linkage::External),
    );
    for name in [
        "mesh_storage_key_seal_bytes",
        "mesh_storage_key_unseal_bytes",
    ] {
        module.add_function(
            name,
            ptr_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
            Some(inkwell::module::Linkage::External),
        );
    }
    module.add_function(
        "mesh_secret_concat",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_secret_destroy",
        void_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_resource_destroy",
        void_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_secret_map_new",
        ptr_type.fn_type(&[i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_secret_map_fork",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_secret_map_insert",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_secret_map_contains",
        i8_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    for name in [
        "mesh_secret_map_copy",
        "mesh_secret_map_delete",
        "mesh_secret_map_merge",
    ] {
        module.add_function(
            name,
            ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
            Some(inkwell::module::Linkage::External),
        );
    }
    for prefix in [
        "secret",
        "secret_map",
        "x25519_private_key",
        "signing_private_key",
        "mlkem_private_key",
        "blind_rsa_secret_key",
    ] {
        for operation in ["seal_for_storage", "unseal_from_storage"] {
            module.add_function(
                &format!("mesh_{prefix}_{operation}"),
                ptr_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
                Some(inkwell::module::Linkage::External),
            );
        }
    }

    // ── Checked wide integers ────────────────────────────────────────────────

    for prefix in ["u64", "u128", "i128"] {
        for operation in ["parse", "to_int", "to_string"] {
            module.add_function(
                &format!("mesh_{prefix}_{operation}"),
                ptr_type.fn_type(&[ptr_type.into()], false),
                Some(inkwell::module::Linkage::External),
            );
        }
        module.add_function(
            &format!("mesh_{prefix}_compare"),
            i64_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
            Some(inkwell::module::Linkage::External),
        );
        for operation in ["add", "subtract", "multiply", "divide"] {
            module.add_function(
                &format!("mesh_{prefix}_{operation}"),
                ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
                Some(inkwell::module::Linkage::External),
            );
        }
    }

    // ── DateTime functions (Phase 136) ───────────────────────────────────────

    // mesh_datetime_utc_now() -> i64
    let utc_now_ty = i64_type.fn_type(&[], false);
    module.add_function(
        "mesh_datetime_utc_now",
        utc_now_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_datetime_from_iso8601(s: ptr) -> ptr (MeshResult)
    let from_iso_ty = ptr_type.fn_type(&[ptr_type.into()], false);
    module.add_function(
        "mesh_datetime_from_iso8601",
        from_iso_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_datetime_to_iso8601(ms: i64) -> ptr (MeshString)
    let to_iso_ty = ptr_type.fn_type(&[i64_type.into()], false);
    module.add_function(
        "mesh_datetime_to_iso8601",
        to_iso_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_datetime_from_unix_ms(ms: i64) -> ptr (MeshResult)
    let from_unix_ms_ty = ptr_type.fn_type(&[i64_type.into()], false);
    module.add_function(
        "mesh_datetime_from_unix_ms",
        from_unix_ms_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_datetime_to_unix_ms(ms: i64) -> i64
    let to_unix_ms_ty = i64_type.fn_type(&[i64_type.into()], false);
    module.add_function(
        "mesh_datetime_to_unix_ms",
        to_unix_ms_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_datetime_from_unix_secs(secs: i64) -> ptr (MeshResult)
    let from_unix_secs_ty = ptr_type.fn_type(&[i64_type.into()], false);
    module.add_function(
        "mesh_datetime_from_unix_secs",
        from_unix_secs_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_datetime_to_unix_secs(ms: i64) -> i64
    let to_unix_secs_ty = i64_type.fn_type(&[i64_type.into()], false);
    module.add_function(
        "mesh_datetime_to_unix_secs",
        to_unix_secs_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_datetime_add(dt_ms: i64, n: i64, unit: ptr) -> i64
    let add_ty = i64_type.fn_type(&[i64_type.into(), i64_type.into(), ptr_type.into()], false);
    module.add_function(
        "mesh_datetime_add",
        add_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_datetime_diff(dt1_ms: i64, dt2_ms: i64, unit: ptr) -> f64  (Float, not i64!)
    let diff_ty = f64_type.fn_type(&[i64_type.into(), i64_type.into(), ptr_type.into()], false);
    module.add_function(
        "mesh_datetime_diff",
        diff_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_datetime_before(dt1_ms: i64, dt2_ms: i64) -> i8 (Bool)
    let before_ty = i8_type.fn_type(&[i64_type.into(), i64_type.into()], false);
    module.add_function(
        "mesh_datetime_before",
        before_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_datetime_after(dt1_ms: i64, dt2_ms: i64) -> i8 (Bool)
    let after_ty = i8_type.fn_type(&[i64_type.into(), i64_type.into()], false);
    module.add_function(
        "mesh_datetime_after",
        after_ty,
        Some(inkwell::module::Linkage::External),
    );

    for name in [
        "mesh_checked_add",
        "mesh_checked_sub",
        "mesh_checked_mul",
        "mesh_checked_div",
    ] {
        module.add_function(
            name,
            ptr_type.fn_type(&[i64_type.into(), i64_type.into()], false),
            Some(inkwell::module::Linkage::External),
        );
    }
    module.add_function(
        "mesh_checked_abs",
        ptr_type.fn_type(&[i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // Checked.mul_div/rescale each accept three integers and a rounding atom.
    let checked_mul_div_ty = ptr_type.fn_type(
        &[
            i64_type.into(),
            i64_type.into(),
            i64_type.into(),
            ptr_type.into(),
        ],
        false,
    );
    module.add_function(
        "mesh_checked_mul_div",
        checked_mul_div_ty,
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_checked_rescale",
        checked_mul_div_ty,
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_monotonic_now_nanos",
        i64_type.fn_type(&[], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_monotonic_elapsed",
        ptr_type.fn_type(&[i64_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    for name in ["mesh_duration_millis", "mesh_duration_seconds"] {
        module.add_function(
            name,
            ptr_type.fn_type(&[i64_type.into()], false),
            Some(inkwell::module::Linkage::External),
        );
    }
    module.add_function(
        "mesh_channel_bounded",
        ptr_type.fn_type(&[i64_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_channel_bounded_bytes",
        ptr_type.fn_type(&[i64_type.into(), i64_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    for name in ["mesh_channel_try_send", "mesh_channel_recv"] {
        module.add_function(
            name,
            ptr_type.fn_type(&[i64_type.into(), i64_type.into()], false),
            Some(inkwell::module::Linkage::External),
        );
    }
    // mesh_channel_try_send_shaped(handle, slot, shape) -> ptr: a value
    // that references heap objects, copied out of the sender's heap.
    module.add_function(
        "mesh_channel_try_send_shaped",
        ptr_type.fn_type(&[i64_type.into(), i64_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    for name in [
        "mesh_channel_depth",
        "mesh_channel_byte_depth",
        "mesh_channel_dropped",
    ] {
        module.add_function(
            name,
            i64_type.fn_type(&[i64_type.into()], false),
            Some(inkwell::module::Linkage::External),
        );
    }
    module.add_function(
        "mesh_random_seed",
        i64_type.fn_type(&[i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_random_next_int",
        ptr_type.fn_type(&[i64_type.into(), i64_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_random_next_unit_ppm",
        ptr_type.fn_type(&[i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // ── Http client functions (Phase 137) ──────────────────────────────────────

    // mesh_http_build(method: ptr, url: ptr) -> i64 (MeshRequest handle)
    let build_ty = i64_type.fn_type(&[ptr_type.into(), ptr_type.into()], false);
    module.add_function(
        "mesh_http_build",
        build_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_http_header(handle: i64, key: ptr, val: ptr) -> i64
    let header_ty = i64_type.fn_type(&[i64_type.into(), ptr_type.into(), ptr_type.into()], false);
    module.add_function(
        "mesh_http_header",
        header_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_http_body(handle: i64, body: ptr) -> i64
    let body_ty = i64_type.fn_type(&[i64_type.into(), ptr_type.into()], false);
    module.add_function(
        "mesh_http_body",
        body_ty,
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_http_body_bytes",
        body_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_http_timeout(handle: i64, ms: i64) -> i64
    let timeout_ty = i64_type.fn_type(&[i64_type.into(), i64_type.into()], false);
    module.add_function(
        "mesh_http_timeout",
        timeout_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_http_stage_timeout(handle: i64, stage: ptr, ms: i64) -> i64
    module.add_function(
        "mesh_http_stage_timeout",
        i64_type.fn_type(&[i64_type.into(), ptr_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_http_max_redirects(handle: i64, count: i64) -> i64
    module.add_function(
        "mesh_http_max_redirects",
        timeout_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_http_max_response_bytes(handle: i64, bytes: i64) -> i64
    module.add_function(
        "mesh_http_max_response_bytes",
        timeout_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_http_query(handle: i64, key: ptr, val: ptr) -> i64
    let query_ty = i64_type.fn_type(&[i64_type.into(), ptr_type.into(), ptr_type.into()], false);
    module.add_function(
        "mesh_http_query",
        query_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_http_json(handle: i64, body: ptr) -> i64
    let json_ty = i64_type.fn_type(&[i64_type.into(), ptr_type.into()], false);
    module.add_function(
        "mesh_http_json",
        json_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_http_send(handle: i64) -> ptr (Result<HttpResponse, String>)
    let send_ty = ptr_type.fn_type(&[i64_type.into()], false);
    module.add_function(
        "mesh_http_send",
        send_ty,
        Some(inkwell::module::Linkage::External),
    );

    // ── Http streaming + cancel + keep-alive (Phase 137 Plan 02) ──────────

    // mesh_http_stream(req: i64, fn_ptr: ptr, env_ptr: ptr) -> i64 (cancel handle)
    let stream_ty = i64_type.fn_type(&[i64_type.into(), ptr_type.into(), ptr_type.into()], false);
    module.add_function(
        "mesh_http_stream",
        stream_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_http_stream_bytes(req: i64, fn_ptr: ptr, env_ptr: ptr) -> i64
    module.add_function(
        "mesh_http_stream_bytes",
        stream_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_http_cancel(cancel_handle: i64) -> void
    let cancel_ty = void_type.fn_type(&[i64_type.into()], false);
    module.add_function(
        "mesh_http_cancel",
        cancel_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_http_client() -> i64 (keep-alive Agent handle)
    let client_ty = i64_type.fn_type(&[], false);
    module.add_function(
        "mesh_http_client",
        client_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_http_send_with(client: i64, req: i64) -> ptr (Result<HttpResponse, String>)
    let send_with_ty = ptr_type.fn_type(&[i64_type.into(), i64_type.into()], false);
    module.add_function(
        "mesh_http_send_with",
        send_with_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_http_client_close(client: i64) -> void
    let close_ty = void_type.fn_type(&[i64_type.into()], false);
    module.add_function(
        "mesh_http_client_close",
        close_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_http_retry_class(method: ptr, error: ptr) -> ptr
    module.add_function(
        "mesh_http_retry_class",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_http_metrics() -> ptr (HttpClientMetrics)
    module.add_function(
        "mesh_http_metrics",
        ptr_type.fn_type(&[], false),
        Some(inkwell::module::Linkage::External),
    );

    // ── Test runtime functions (Phase 138) ────────────────────────────────

    // mesh_test_begin(name: ptr) -> void
    let test_begin_ty = void_type.fn_type(&[ptr_type.into()], false);
    module.add_function(
        "mesh_test_begin",
        test_begin_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_test_pass() -> void
    let test_pass_ty = void_type.fn_type(&[], false);
    module.add_function(
        "mesh_test_pass",
        test_pass_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_test_fail_msg(msg: ptr) -> void
    let test_fail_msg_ty = void_type.fn_type(&[ptr_type.into()], false);
    module.add_function(
        "mesh_test_fail_msg",
        test_fail_msg_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_test_fail_msg_at(msg: ptr, file: ptr, file_len: i64, line: i64) -> void
    let test_fail_msg_at_ty = void_type.fn_type(
        &[
            ptr_type.into(),
            ptr_type.into(),
            i64_type.into(),
            i64_type.into(),
        ],
        false,
    );
    module.add_function(
        "mesh_test_fail_msg_at",
        test_fail_msg_at_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_test_assert(cond: i8, expr_src: ptr, file: ptr, file_len: i64, line: i64) -> void
    let test_assert_ty = void_type.fn_type(
        &[
            i8_type.into(),
            ptr_type.into(),
            ptr_type.into(),
            i64_type.into(),
            i64_type.into(),
        ],
        false,
    );
    module.add_function(
        "mesh_test_assert",
        test_assert_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_test_assert_eq(lhs: ptr, rhs: ptr, expr_src: ptr, file: ptr, file_len: i64, line: i64) -> void
    let test_assert_eq_ty = void_type.fn_type(
        &[
            ptr_type.into(),
            ptr_type.into(),
            ptr_type.into(),
            ptr_type.into(),
            i64_type.into(),
            i64_type.into(),
        ],
        false,
    );
    module.add_function(
        "mesh_test_assert_eq",
        test_assert_eq_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_test_assert_ne — same signature as assert_eq
    module.add_function(
        "mesh_test_assert_ne",
        test_assert_eq_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_test_assert_raises(fn_ptr: ptr, env_ptr: ptr, file: ptr, file_len: i64, line: i64) -> void
    let test_assert_raises_ty = void_type.fn_type(
        &[
            ptr_type.into(),
            ptr_type.into(),
            ptr_type.into(),
            i64_type.into(),
            i64_type.into(),
        ],
        false,
    );
    module.add_function(
        "mesh_test_assert_raises",
        test_assert_raises_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_test_summary(passed: i64, failed: i64, elapsed_ms: i64) -> void
    let test_summary_ty =
        void_type.fn_type(&[i64_type.into(), i64_type.into(), i64_type.into()], false);
    module.add_function(
        "mesh_test_summary",
        test_summary_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_test_cleanup_actors() -> void
    let test_cleanup_ty = void_type.fn_type(&[], false);
    module.add_function(
        "mesh_test_cleanup_actors",
        test_cleanup_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_test_run_body(fn_ptr: ptr, env_ptr: ptr) -> void
    let test_run_body_ty = void_type.fn_type(&[ptr_type.into(), ptr_type.into()], false);
    module.add_function(
        "mesh_test_run_body",
        test_run_body_ty,
        Some(inkwell::module::Linkage::External),
    );
    // mesh_test_end() -> void
    module.add_function(
        "mesh_test_end",
        void_type.fn_type(&[], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_test_mock_actor(fn_ptr: ptr, env_ptr: ptr) -> i64
    let test_mock_actor_ty = i64_type.fn_type(&[ptr_type.into(), ptr_type.into()], false);
    module.add_function(
        "mesh_test_mock_actor",
        test_mock_actor_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_test_install_in_memory_secure_store() -> bool
    module.add_function(
        "mesh_test_install_in_memory_secure_store",
        i8_type.fn_type(&[], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_test_set_push_token(selector: Bytes, token: Bytes) -> bool
    module.add_function(
        "mesh_test_set_push_token",
        i8_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_test_pass_count() -> i64
    let test_pass_count_ty = i64_type.fn_type(&[], false);
    module.add_function(
        "mesh_test_pass_count",
        test_pass_count_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_test_fail_count() -> i64
    let test_fail_count_ty = i64_type.fn_type(&[], false);
    module.add_function(
        "mesh_test_fail_count",
        test_fail_count_ty,
        Some(inkwell::module::Linkage::External),
    );

    // ── Standard library: Collection functions (Phase 8 Plan 02) ──────────

    // List functions
    module.add_function(
        "mesh_list_new",
        ptr_type.fn_type(&[], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_list_length",
        i64_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_list_append",
        ptr_type.fn_type(&[ptr_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_list_head",
        i64_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_list_tail",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_list_get",
        i64_type.fn_type(&[ptr_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_list_concat",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_list_reverse",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_list_map",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_list_filter",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_list_reduce",
        i64_type.fn_type(
            &[
                ptr_type.into(),
                i64_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_list_from_array",
        ptr_type.fn_type(&[ptr_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_list_builder_new",
        ptr_type.fn_type(&[i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // Returns the builder, which moves when it has to grow.
    module.add_function(
        "mesh_list_builder_push",
        ptr_type.fn_type(&[ptr_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // Phase 46: List sort, find, any, all, contains
    // mesh_list_sort(list: ptr, fn_ptr: ptr, env_ptr: ptr) -> ptr
    module.add_function(
        "mesh_list_sort",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_list_find(list: ptr, fn_ptr: ptr, env_ptr: ptr) -> ptr (MeshOption)
    module.add_function(
        "mesh_list_find",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_option_box_scalar(option: ptr) -> ptr: boxes a raw scalar `Some` payload
    module.add_function(
        "mesh_option_box_scalar",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_list_any(list: ptr, fn_ptr: ptr, env_ptr: ptr) -> i8 (Bool)
    module.add_function(
        "mesh_list_any",
        i8_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_list_all(list: ptr, fn_ptr: ptr, env_ptr: ptr) -> i8 (Bool)
    module.add_function(
        "mesh_list_all",
        i8_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_list_contains(list: ptr, elem: i64) -> i8 (Bool) — Int/Bool elements
    module.add_function(
        "mesh_list_contains",
        i8_type.fn_type(&[ptr_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // Map operations comparing keys by a key-type Eq callback and hashing them
    // by its Hash callback (both null: by the map's key type).
    for (name, params, returns_ptr) in [
        (
            "mesh_map_put_by",
            vec![
                ptr_type.into(),
                i64_type.into(),
                i64_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            1,
        ),
        (
            "mesh_map_get_by",
            vec![
                ptr_type.into(),
                i64_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            0,
        ),
        (
            "mesh_map_fetch_by",
            vec![
                ptr_type.into(),
                i64_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            0,
        ),
        (
            "mesh_map_has_key_by",
            vec![
                ptr_type.into(),
                i64_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            2,
        ),
        (
            "mesh_map_delete_by",
            vec![
                ptr_type.into(),
                i64_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            1,
        ),
        (
            "mesh_map_merge_by",
            vec![
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            1,
        ),
        (
            "mesh_map_from_list_by",
            vec![
                ptr_type.into(),
                i64_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            1,
        ),
        (
            "mesh_map_collect_by",
            vec![
                ptr_type.into(),
                i64_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            1,
        ),
        (
            "mesh_map_eq_by",
            vec![
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            2,
        ),
    ]
    .into_iter()
    .chain(set_by_declarations(ptr_type, i64_type))
    {
        let params: Vec<inkwell::types::BasicMetadataTypeEnum> = params;
        let fn_type = match returns_ptr {
            1 => ptr_type.fn_type(&params, false),
            2 => i8_type.fn_type(&params, false),
            _ => i64_type.fn_type(&params, false),
        };
        module.add_function(name, fn_type, Some(inkwell::module::Linkage::External));
    }
    // mesh_list_contains_by(list: ptr, elem: i64, eq: ptr) -> i8 (Bool) — by the element's Eq
    module.add_function(
        "mesh_list_contains_by",
        i8_type.fn_type(&[ptr_type.into(), i64_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_{list,set}_hash_by(coll: ptr, hash: ptr) -> i64 — by the element's Hash
    for name in ["mesh_list_hash_by", "mesh_set_hash_by"] {
        module.add_function(
            name,
            i64_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
            Some(inkwell::module::Linkage::External),
        );
    }
    // mesh_map_hash_by(map: ptr, key_hash: ptr, val_hash: ptr) -> i64
    module.add_function(
        "mesh_map_hash_by",
        i64_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_list_contains_str(list: ptr, elem: ptr) -> i8 (Bool) — String elements, uses mesh_string_eq
    module.add_function(
        "mesh_list_contains_str",
        i8_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // Phase 47: List zip, flat_map, flatten, enumerate, take, drop, last, nth
    module.add_function(
        "mesh_list_zip",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_list_flat_map",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_list_flatten",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_list_enumerate",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_list_take",
        ptr_type.fn_type(&[ptr_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_list_drop",
        ptr_type.fn_type(&[ptr_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_list_last",
        i64_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_list_nth",
        i64_type.fn_type(&[ptr_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // Map functions
    module.add_function(
        "mesh_map_new",
        ptr_type.fn_type(&[], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_map_new_typed",
        ptr_type.fn_type(&[i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_map_tag_string",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_map_put",
        ptr_type.fn_type(&[ptr_type.into(), i64_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_map_fetch",
        i64_type.fn_type(&[ptr_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_map_get",
        i64_type.fn_type(&[ptr_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_map_has_key",
        i8_type.fn_type(&[ptr_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_map_delete",
        ptr_type.fn_type(&[ptr_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_map_size",
        i64_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_map_keys",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_map_values",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // Phase 47: Map merge/to_list/from_list
    module.add_function(
        "mesh_map_merge",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_map_to_list",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_map_from_list",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_map_entry_key",
        i64_type.fn_type(&[ptr_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_map_entry_value",
        i64_type.fn_type(&[ptr_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // Set functions
    module.add_function(
        "mesh_set_new",
        ptr_type.fn_type(&[], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_set_add",
        ptr_type.fn_type(&[ptr_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_set_remove",
        ptr_type.fn_type(&[ptr_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_set_contains",
        i8_type.fn_type(&[ptr_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_set_size",
        i64_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_set_union",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_set_intersection",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_set_element_at",
        i64_type.fn_type(&[ptr_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // Phase 47: Set difference/to_list/from_list
    module.add_function(
        "mesh_set_difference",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_set_to_list",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_set_from_list",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // Tuple functions
    module.add_function(
        "mesh_tuple_nth",
        i64_type.fn_type(&[ptr_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_tuple_first",
        i64_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_tuple_second",
        i64_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_tuple_size",
        i64_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // Range functions
    module.add_function(
        "mesh_range_new",
        ptr_type.fn_type(&[i64_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_range_to_list",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_range_map",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_range_filter",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_range_length",
        i64_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // Queue functions
    module.add_function(
        "mesh_queue_new",
        ptr_type.fn_type(&[], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_queue_push",
        ptr_type.fn_type(&[ptr_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_queue_pop",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_queue_peek",
        i64_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_queue_size",
        i64_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_queue_is_empty",
        i8_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // ── Standard library: JSON functions (Phase 8 Plan 04) ──────────────

    // mesh_json_parse(input: ptr) -> ptr (MeshResult)
    module.add_function(
        "mesh_json_parse",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_json_encode(json: ptr) -> ptr (MeshString)
    module.add_function(
        "mesh_json_encode",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_json_encode_string(s: ptr) -> ptr (MeshString)
    module.add_function(
        "mesh_json_encode_string",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_json_encode_int(val: i64) -> ptr (MeshString)
    module.add_function(
        "mesh_json_encode_int",
        ptr_type.fn_type(&[i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_json_encode_bool(val: i8) -> ptr (MeshString)
    module.add_function(
        "mesh_json_encode_bool",
        ptr_type.fn_type(&[i8_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_json_encode_map(map: ptr) -> ptr (MeshString)
    module.add_function(
        "mesh_json_encode_map",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_json_encode_list(list: ptr) -> ptr (MeshString)
    module.add_function(
        "mesh_json_encode_list",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_json_from_int(val: i64) -> ptr
    module.add_function(
        "mesh_json_from_int",
        ptr_type.fn_type(&[i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_json_from_float(val: f64) -> ptr
    module.add_function(
        "mesh_json_from_float",
        ptr_type.fn_type(&[f64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_json_from_bool(val: i8) -> ptr
    module.add_function(
        "mesh_json_from_bool",
        ptr_type.fn_type(&[i8_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_json_from_string(s: ptr) -> ptr
    module.add_function(
        "mesh_json_from_string",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // ── Phase 103: JSON field extraction (no DB roundtrip) ────────────
    // mesh_json_get(json: ptr, key: ptr) -> ptr (MeshString)
    module.add_function(
        "mesh_json_get",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_json_get_nested(json: ptr, path1: ptr, path2: ptr) -> ptr (MeshString)
    module.add_function(
        "mesh_json_get_nested",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_json_is_string(json: ptr, key: ptr) -> i8 (Bool)
    module.add_function(
        "mesh_json_is_string",
        i8_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // ── Structured JSON object/array functions (Phase 49) ──────────────
    // mesh_json_object_new() -> ptr
    module.add_function(
        "mesh_json_object_new",
        ptr_type.fn_type(&[], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_json_object_put(obj: ptr, key: ptr, val: ptr) -> ptr
    module.add_function(
        "mesh_json_object_put",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_json_object_get(obj: ptr, key: ptr) -> ptr (MeshResult)
    module.add_function(
        "mesh_json_object_get",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_json_array_new() -> ptr
    module.add_function(
        "mesh_json_array_new",
        ptr_type.fn_type(&[], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_json_array_push(arr: ptr, val: ptr) -> ptr
    module.add_function(
        "mesh_json_array_push",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_json_array_get(arr: ptr, index: i64) -> ptr (MeshResult)
    module.add_function(
        "mesh_json_array_get",
        ptr_type.fn_type(&[ptr_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_json_as_int(json: ptr) -> ptr (MeshResult)
    module.add_function(
        "mesh_json_as_int",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_json_as_float(json: ptr) -> ptr (MeshResult)
    module.add_function(
        "mesh_json_as_float",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_json_as_string(json: ptr) -> ptr (MeshResult)
    module.add_function(
        "mesh_json_as_string",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_json_as_bool(json: ptr) -> ptr (MeshResult)
    module.add_function(
        "mesh_json_as_bool",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    for name in [
        "mesh_json_value_as_int",
        "mesh_json_value_as_float",
        "mesh_json_value_as_bool",
    ] {
        module.add_function(
            name,
            ptr_type.fn_type(&[ptr_type.into()], false),
            Some(inkwell::module::Linkage::External),
        );
    }
    // mesh_json_null() -> ptr
    module.add_function(
        "mesh_json_null",
        ptr_type.fn_type(&[], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_json_from_list(list: ptr, elem_fn: ptr) -> ptr
    module.add_function(
        "mesh_json_from_list",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_json_from_map(map: ptr, val_fn: ptr) -> ptr
    module.add_function(
        "mesh_json_from_map",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_json_to_list(json_arr: ptr, elem_fn: ptr) -> ptr (MeshResult)
    module.add_function(
        "mesh_json_to_list",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_json_to_map(json_obj: ptr, val_fn: ptr) -> ptr (MeshResult)
    module.add_function(
        "mesh_json_to_map",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_json_error_at(decoded: ptr, step: ptr) -> ptr (MeshResult)
    module.add_function(
        "mesh_json_error_at",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // ── Result helpers (Phase 49: from_json Result propagation) ─────────
    // mesh_alloc_result(tag: i64, value: ptr) -> ptr
    module.add_function(
        "mesh_alloc_result",
        ptr_type.fn_type(&[i64_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_result_is_ok(result: ptr) -> i64
    module.add_function(
        "mesh_result_is_ok",
        i64_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_result_unwrap(result: ptr) -> ptr
    module.add_function(
        "mesh_result_unwrap",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // ── Standard library: HTTP functions (Phase 8 Plan 05) ──────────────

    // mesh_http_router() -> ptr
    module.add_function(
        "mesh_http_router",
        ptr_type.fn_type(&[], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_http_route(router: ptr, pattern: ptr, handler_fn: ptr, handler_env: ptr) -> ptr
    module.add_function(
        "mesh_http_route",
        ptr_type.fn_type(
            &[
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_http_serve(router: ptr, port: i64) -> void
    module.add_function(
        "mesh_http_serve",
        void_type.fn_type(&[ptr_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_http_serve_tls(router: ptr, port: i64, cert_path: ptr, key_path: ptr) -> void
    module.add_function(
        "mesh_http_serve_tls",
        void_type.fn_type(
            &[
                ptr_type.into(),
                i64_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // ── WebSocket functions (Phase 60) ──────────────────────────────────
    // mesh_ws_serve(on_connect_fn: ptr, on_connect_env: ptr, on_message_fn: ptr, on_message_env: ptr, on_close_fn: ptr, on_close_env: ptr, port: i64) -> void
    module.add_function(
        "mesh_ws_serve",
        void_type.fn_type(
            &[
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                i64_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_ws_send(conn: ptr, msg: ptr) -> i64
    module.add_function(
        "mesh_ws_send",
        i64_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_ws_serve_tls(on_connect_fn: ptr, on_connect_env: ptr, on_message_fn: ptr, on_message_env: ptr, on_close_fn: ptr, on_close_env: ptr, port: i64, cert_path: ptr, key_path: ptr) -> void
    module.add_function(
        "mesh_ws_serve_tls",
        void_type.fn_type(
            &[
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                i64_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // ── Bounded WebSocket client ─────────────────────────────────────────
    module.add_function(
        "mesh_ws_client_options",
        i64_type.fn_type(&[], false),
        Some(inkwell::module::Linkage::External),
    );
    for name in [
        "mesh_ws_client_connect_timeout",
        "mesh_ws_client_heartbeat_timeout",
        "mesh_ws_client_max_message_bytes",
        "mesh_ws_client_queue_capacity",
    ] {
        module.add_function(
            name,
            i64_type.fn_type(&[i64_type.into(), i64_type.into()], false),
            Some(inkwell::module::Linkage::External),
        );
    }
    module.add_function(
        "mesh_ws_client_connect",
        ptr_type.fn_type(&[ptr_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_ws_client_send_text",
        ptr_type.fn_type(&[i64_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_ws_client_send_bytes",
        ptr_type.fn_type(&[i64_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_ws_client_recv",
        ptr_type.fn_type(&[i64_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_ws_client_close",
        ptr_type.fn_type(&[i64_type.into(), i64_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_ws_client_reconnect_delay",
        ptr_type.fn_type(
            &[
                i64_type.into(),
                i64_type.into(),
                i64_type.into(),
                i64_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // ── WebSocket Room functions (Phase 62) ──────────────────────────────
    // mesh_ws_join(conn: ptr, room: ptr) -> i64
    module.add_function(
        "mesh_ws_join",
        i64_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_ws_leave(conn: ptr, room: ptr) -> i64
    module.add_function(
        "mesh_ws_leave",
        i64_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_ws_broadcast(room: ptr, msg: ptr) -> i64
    module.add_function(
        "mesh_ws_broadcast",
        i64_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_ws_broadcast_except(room: ptr, msg: ptr, except_conn: ptr) -> i64
    module.add_function(
        "mesh_ws_broadcast_except",
        i64_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_http_response_new(status: i64, body: ptr) -> ptr
    module.add_function(
        "mesh_http_response_new",
        ptr_type.fn_type(&[i64_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_http_response_bytes_new",
        ptr_type.fn_type(&[i64_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_http_response_bytes_with_headers",
        ptr_type.fn_type(&[i64_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_http_response_with_headers(status: i64, body: ptr, headers: ptr) -> ptr
    module.add_function(
        "mesh_http_response_with_headers",
        ptr_type.fn_type(&[i64_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_http_request_method(req: ptr) -> ptr
    module.add_function(
        "mesh_http_request_method",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_http_request_path(req: ptr) -> ptr
    module.add_function(
        "mesh_http_request_path",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_http_request_body(req: ptr) -> ptr
    module.add_function(
        "mesh_http_request_body",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_http_request_body_bytes",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_http_request_header(req: ptr, name: ptr) -> ptr (MeshOption)
    module.add_function(
        "mesh_http_request_header",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_http_request_query(req: ptr, name: ptr) -> ptr (MeshOption)
    module.add_function(
        "mesh_http_request_query",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_http_request_id(req: ptr) -> ptr (MeshString)
    module.add_function(
        "mesh_http_request_id",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_http_idempotency_key(req: ptr) -> ptr (MeshOption<String>)
    module.add_function(
        "mesh_http_idempotency_key",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    module.add_function(
        "mesh_cluster_capacity",
        ptr_type.fn_type(&[], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_cluster_pressure",
        ptr_type.fn_type(&[], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_cluster_telemetry",
        ptr_type.fn_type(&[], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_cluster_role",
        ptr_type.fn_type(&[], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_cluster_state",
        ptr_type.fn_type(&[], false),
        Some(inkwell::module::Linkage::External),
    );

    // ── Phase 51: Method-specific routing and path parameter extraction ──

    // mesh_http_route_get(router: ptr, pattern: ptr, handler_fn: ptr, handler_env: ptr) -> ptr
    module.add_function(
        "mesh_http_route_get",
        ptr_type.fn_type(
            &[
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_http_route_post(router: ptr, pattern: ptr, handler_fn: ptr, handler_env: ptr) -> ptr
    module.add_function(
        "mesh_http_route_post",
        ptr_type.fn_type(
            &[
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_http_route_put(router: ptr, pattern: ptr, handler_fn: ptr, handler_env: ptr) -> ptr
    module.add_function(
        "mesh_http_route_put",
        ptr_type.fn_type(
            &[
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_http_route_delete(router: ptr, pattern: ptr, handler_fn: ptr, handler_env: ptr) -> ptr
    module.add_function(
        "mesh_http_route_delete",
        ptr_type.fn_type(
            &[
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_http_request_param(req: ptr, name: ptr) -> ptr (MeshOption)
    module.add_function(
        "mesh_http_request_param",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // ── Phase 52: Middleware ──────────────────────────────────────────────

    // mesh_http_use_middleware(router: ptr, middleware_fn: ptr, middleware_env: ptr) -> ptr
    module.add_function(
        "mesh_http_use_middleware",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // ── Phase 53: SQLite ──────────────────────────────────────────────

    // mesh_sqlite_open(path: ptr) -> ptr (MeshResult)
    module.add_function(
        "mesh_sqlite_open",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_sqlite_close(conn: i64) -> void
    module.add_function(
        "mesh_sqlite_close",
        void_type.fn_type(&[i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_sqlite_execute(conn: i64, sql: ptr, params: ptr) -> ptr (MeshResult)
    module.add_function(
        "mesh_sqlite_execute",
        ptr_type.fn_type(&[i64_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_sqlite_query(conn: i64, sql: ptr, params: ptr) -> ptr (MeshResult)
    module.add_function(
        "mesh_sqlite_query",
        ptr_type.fn_type(&[i64_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    for name in ["mesh_sqlite_execute_values", "mesh_sqlite_query_values"] {
        module.add_function(
            name,
            ptr_type.fn_type(&[i64_type.into(), ptr_type.into(), ptr_type.into()], false),
            Some(inkwell::module::Linkage::External),
        );
    }

    // ── Phase 54: PostgreSQL ──────────────────────────────────────────────

    // mesh_pg_connect(url: ptr) -> ptr (MeshResult)
    module.add_function(
        "mesh_pg_connect",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_pg_close(conn: i64) -> void
    module.add_function(
        "mesh_pg_close",
        void_type.fn_type(&[i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_pg_execute(conn: i64, sql: ptr, params: ptr) -> ptr (MeshResult)
    module.add_function(
        "mesh_pg_execute",
        ptr_type.fn_type(&[i64_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_pg_query(conn: i64, sql: ptr, params: ptr) -> ptr (MeshResult)
    module.add_function(
        "mesh_pg_query",
        ptr_type.fn_type(&[i64_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    for name in ["mesh_pg_execute_values", "mesh_pg_query_values"] {
        module.add_function(
            name,
            ptr_type.fn_type(&[i64_type.into(), ptr_type.into(), ptr_type.into()], false),
            Some(inkwell::module::Linkage::External),
        );
    }

    // ── Phase 57: PostgreSQL Transactions ──────────────────────────────

    // mesh_pg_begin(conn: i64) -> ptr (MeshResult)
    module.add_function(
        "mesh_pg_begin",
        ptr_type.fn_type(&[i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_pg_commit(conn: i64) -> ptr (MeshResult)
    module.add_function(
        "mesh_pg_commit",
        ptr_type.fn_type(&[i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_pg_rollback(conn: i64) -> ptr (MeshResult)
    module.add_function(
        "mesh_pg_rollback",
        ptr_type.fn_type(&[i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_pg_transaction(conn: i64, fn_ptr: ptr, env_ptr: ptr) -> ptr (MeshResult)
    module.add_function(
        "mesh_pg_transaction",
        ptr_type.fn_type(&[i64_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // ── PostgreSQL expression helpers ─────────────────────────────────

    // mesh_pg_cast(expr: ptr, sql_type: ptr) -> ptr
    module.add_function(
        "mesh_pg_cast",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_pg_jsonb/int/text/uuid/timestamptz(expr: ptr) -> ptr
    for name in [
        "mesh_pg_jsonb",
        "mesh_pg_int",
        "mesh_pg_text",
        "mesh_pg_uuid",
        "mesh_pg_timestamptz",
    ] {
        module.add_function(
            name,
            ptr_type.fn_type(&[ptr_type.into()], false),
            Some(inkwell::module::Linkage::External),
        );
    }

    // mesh_pg_gen_salt(algorithm: ptr, rounds: i64) -> ptr
    module.add_function(
        "mesh_pg_gen_salt",
        ptr_type.fn_type(&[ptr_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_pg_crypt/ts_rank/tsvector_matches/jsonb_contains(lhs: ptr, rhs: ptr) -> ptr
    for name in [
        "mesh_pg_crypt",
        "mesh_pg_ts_rank",
        "mesh_pg_tsvector_matches",
        "mesh_pg_jsonb_contains",
    ] {
        module.add_function(
            name,
            ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
            Some(inkwell::module::Linkage::External),
        );
    }

    // mesh_pg_to_tsvector/plainto_tsquery(config: ptr, expr: ptr) -> ptr
    for name in ["mesh_pg_to_tsvector", "mesh_pg_plainto_tsquery"] {
        module.add_function(
            name,
            ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
            Some(inkwell::module::Linkage::External),
        );
    }

    // ── Explicit PostgreSQL schema helpers ────────────────────────────

    // mesh_pg_create_extension(pool: i64, name: ptr) -> ptr (MeshResult)
    module.add_function(
        "mesh_pg_create_extension",
        ptr_type.fn_type(&[i64_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_pg_create_range_partitioned_table(pool: i64, table: ptr, cols: ptr, partition_col: ptr) -> ptr
    module.add_function(
        "mesh_pg_create_range_partitioned_table",
        ptr_type.fn_type(
            &[
                i64_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_pg_create_gin_index(pool: i64, table: ptr, index_name: ptr, column: ptr, opclass: ptr) -> ptr
    module.add_function(
        "mesh_pg_create_gin_index",
        ptr_type.fn_type(
            &[
                i64_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_pg_create_daily_partitions_ahead(pool: i64, parent_table: ptr, days: i64) -> ptr
    module.add_function(
        "mesh_pg_create_daily_partitions_ahead",
        ptr_type.fn_type(&[i64_type.into(), ptr_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_pg_list_daily_partitions_before(pool: i64, parent_table: ptr, max_days: i64) -> ptr
    module.add_function(
        "mesh_pg_list_daily_partitions_before",
        ptr_type.fn_type(&[i64_type.into(), ptr_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_pg_drop_partition(pool: i64, partition_name: ptr) -> ptr (MeshResult)
    module.add_function(
        "mesh_pg_drop_partition",
        ptr_type.fn_type(&[i64_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // ── Phase 57: SQLite Transactions ──────────────────────────────────

    // mesh_sqlite_begin(conn: i64) -> ptr (MeshResult)
    module.add_function(
        "mesh_sqlite_begin",
        ptr_type.fn_type(&[i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_sqlite_commit(conn: i64) -> ptr (MeshResult)
    module.add_function(
        "mesh_sqlite_commit",
        ptr_type.fn_type(&[i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_sqlite_rollback(conn: i64) -> ptr (MeshResult)
    module.add_function(
        "mesh_sqlite_rollback",
        ptr_type.fn_type(&[i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // ── Phase 57: Connection Pool ──────────────────────────────────────

    // mesh_pool_open(url: ptr, min: i64, max: i64, timeout: i64) -> ptr (MeshResult)
    module.add_function(
        "mesh_pool_open",
        ptr_type.fn_type(
            &[
                ptr_type.into(),
                i64_type.into(),
                i64_type.into(),
                i64_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_pool_close(pool: i64) -> void
    module.add_function(
        "mesh_pool_close",
        void_type.fn_type(&[i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_pool_query(pool: i64, sql: ptr, params: ptr) -> ptr (MeshResult)
    module.add_function(
        "mesh_pool_query",
        ptr_type.fn_type(&[i64_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_pool_execute(pool: i64, sql: ptr, params: ptr) -> ptr (MeshResult)
    module.add_function(
        "mesh_pool_execute",
        ptr_type.fn_type(&[i64_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    for name in ["mesh_pool_execute_values", "mesh_pool_query_values"] {
        module.add_function(
            name,
            ptr_type.fn_type(&[i64_type.into(), ptr_type.into(), ptr_type.into()], false),
            Some(inkwell::module::Linkage::External),
        );
    }

    // ── Phase 58: Row Parsing & Struct-to-Row Mapping ────────────────────

    // mesh_row_from_row_get(row: ptr, col_name: ptr) -> ptr (MeshResult)
    module.add_function(
        "mesh_row_from_row_get",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_row_parse_int(s: ptr) -> ptr (MeshResult)
    module.add_function(
        "mesh_row_parse_int",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_row_parse_float(s: ptr) -> ptr (MeshResult)
    module.add_function(
        "mesh_row_parse_float",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_row_parse_bool(s: ptr) -> ptr (MeshResult)
    module.add_function(
        "mesh_row_parse_bool",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_pg_query_as(conn: i64, sql: ptr, params: ptr, fn_ptr: ptr, env_ptr: ptr) -> ptr (MeshResult)
    module.add_function(
        "mesh_pg_query_as",
        ptr_type.fn_type(
            &[
                i64_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_pool_query_as(pool: i64, sql: ptr, params: ptr, fn_ptr: ptr, env_ptr: ptr) -> ptr (MeshResult)
    module.add_function(
        "mesh_pool_query_as",
        ptr_type.fn_type(
            &[
                i64_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // ── Hash runtime functions (Phase 21 Plan 01) ──────────────────────

    // mesh_hash_int(value: i64) -> i64
    module.add_function(
        "mesh_hash_int",
        i64_type.fn_type(&[i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_hash_float(value: f64) -> i64
    module.add_function(
        "mesh_hash_float",
        i64_type.fn_type(&[f64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_hash_bool(value: i8) -> i64
    module.add_function(
        "mesh_hash_bool",
        i64_type.fn_type(&[i8_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_hash_string(s: ptr) -> i64
    module.add_function(
        "mesh_hash_string",
        i64_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_hash_combine(hash_a: i64, hash_b: i64) -> i64
    module.add_function(
        "mesh_hash_combine",
        i64_type.fn_type(&[i64_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // ── Collection Display runtime functions (Phase 21 Plan 04) ──────────

    // mesh_list_to_string(list: ptr, elem_to_str: ptr) -> ptr
    module.add_function(
        "mesh_list_to_string",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_map_to_string(map: ptr, key_to_str: ptr, val_to_str: ptr) -> ptr
    module.add_function(
        "mesh_map_to_string",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_set_to_string(set: ptr, elem_to_str: ptr) -> ptr
    module.add_function(
        "mesh_set_to_string",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_string_inspect(s: ptr) -> ptr (quoted and escaped, for inspect())
    module.add_function(
        "mesh_string_inspect",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_string_to_string(val: u64) -> ptr (identity for string elements in collections)
    module.add_function(
        "mesh_string_to_string",
        ptr_type.fn_type(&[i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // ── List Eq/Ord runtime functions (Phase 27 Plan 01) ──────────────

    // mesh_map_eq(a: ptr, b: ptr, val_eq: ptr) -> i8
    module.add_function(
        "mesh_map_eq",
        i8_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_set_eq(a: ptr, b: ptr) -> i8
    module.add_function(
        "mesh_set_eq",
        i8_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_list_eq(list_a: ptr, list_b: ptr, elem_eq: ptr) -> i8
    module.add_function(
        "mesh_list_eq",
        i8_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_list_compare(list_a: ptr, list_b: ptr, elem_cmp: ptr) -> i64
    module.add_function(
        "mesh_list_compare",
        i64_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // ── Service runtime functions (Phase 9 Plan 03) ──────────────────────

    // mesh_service_call(target_pid: i64, msg_tag: i64, payload_ptr: ptr, payload_size: i64) -> ptr
    let service_call_ty = ptr_type.fn_type(
        &[
            i64_type.into(),
            i64_type.into(),
            ptr_type.into(),
            i64_type.into(),
        ],
        false,
    );
    module.add_function(
        "mesh_service_call",
        service_call_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_service_reply(caller_pid: i64, reply_ptr: ptr, reply_size: i64) -> void
    let service_reply_ty =
        void_type.fn_type(&[i64_type.into(), ptr_type.into(), i64_type.into()], false);
    module.add_function(
        "mesh_service_reply",
        service_reply_ty,
        Some(inkwell::module::Linkage::External),
    );

    // The `_shaped` variants take a shape table (see codegen/msg_shape.rs) so
    // the runtime can copy what the arguments or reply reference.
    module.add_function(
        "mesh_service_call_shaped",
        ptr_type.fn_type(
            &[
                i64_type.into(),
                i64_type.into(),
                ptr_type.into(),
                i64_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_service_cast_shaped",
        void_type.fn_type(
            &[
                i64_type.into(),
                ptr_type.into(),
                i64_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_service_reply_shaped",
        void_type.fn_type(
            &[
                i64_type.into(),
                ptr_type.into(),
                i64_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    for (name, params) in [
        ("mesh_jobs_migrate", vec![i64_type.into()]),
        (
            "mesh_jobs_enqueue",
            vec![i64_type.into(), ptr_type.into(), ptr_type.into()],
        ),
        (
            "mesh_jobs_enqueue_in",
            vec![i64_type.into(), ptr_type.into(), ptr_type.into()],
        ),
        (
            "mesh_jobs_control",
            vec![i64_type.into(), ptr_type.into(), ptr_type.into()],
        ),
        (
            "mesh_jobs_start",
            vec![
                i64_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
        ),
        (
            "mesh_jobs_start_effects_v1",
            vec![
                i64_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
        ),
        (
            "mesh_jobs_effect_v1",
            vec![ptr_type.into(), ptr_type.into()],
        ),
        (
            "mesh_jobs_drain",
            vec![
                i64_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
        ),
        (
            "mesh_test_jobs_inspect",
            vec![i64_type.into(), ptr_type.into(), ptr_type.into()],
        ),
        (
            "mesh_test_jobs_inspect_in",
            vec![i64_type.into(), ptr_type.into(), ptr_type.into()],
        ),
        (
            "mesh_test_assert_enqueued",
            vec![
                i64_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                i64_type.into(),
            ],
        ),
        (
            "mesh_test_refute_enqueued",
            vec![
                i64_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                i64_type.into(),
            ],
        ),
        (
            "mesh_test_assert_enqueued_in",
            vec![i64_type.into(), ptr_type.into(), ptr_type.into()],
        ),
        (
            "mesh_test_refute_enqueued_in",
            vec![i64_type.into(), ptr_type.into(), ptr_type.into()],
        ),
        (
            "mesh_test_build_job",
            vec![ptr_type.into(), i64_type.into()],
        ),
        (
            "mesh_test_perform_job",
            vec![
                ptr_type.into(),
                i64_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
        ),
        ("mesh_jobs_stop", vec![i64_type.into(), i64_type.into()]),
        ("mesh_jobs_join", vec![i64_type.into()]),
        ("mesh_jobs_status", vec![i64_type.into()]),
        (
            "mesh_jobs_read_events",
            vec![i64_type.into(), i64_type.into()],
        ),
        (
            "mesh_jobs_local_control",
            vec![i64_type.into(), ptr_type.into()],
        ),
    ] {
        module.add_function(
            name,
            ptr_type.fn_type(&params, false),
            Some(inkwell::module::Linkage::External),
        );
    }

    module.add_function(
        "mesh_jobs_register_handler",
        void_type.fn_type(&[ptr_type.into(), i64_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_jobs_enter_worker",
        void_type.fn_type(&[i32_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // ── Job runtime functions (Phase 9 Plan 04) ──────────────────────────

    // mesh_job_async(fn_ptr: ptr, env_ptr: ptr) -> i64 (PID)
    let job_async_ty = i64_type.fn_type(&[ptr_type.into(), ptr_type.into()], false);
    module.add_function(
        "mesh_job_async",
        job_async_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_job_await(job_pid: i64) -> ptr (MeshResult)
    let job_await_ty = ptr_type.fn_type(&[i64_type.into()], false);
    module.add_function(
        "mesh_job_await",
        job_await_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_job_await_timeout(job_pid: i64, timeout_ms: i64) -> ptr (MeshResult)
    let job_await_timeout_ty = ptr_type.fn_type(&[i64_type.into(), i64_type.into()], false);
    module.add_function(
        "mesh_job_await_timeout",
        job_await_timeout_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_job_map(list_ptr: ptr, fn_ptr: ptr, env_ptr: ptr) -> ptr (List of MeshResult)
    let job_map_ty = ptr_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false);
    module.add_function(
        "mesh_job_map",
        job_map_ty,
        Some(inkwell::module::Linkage::External),
    );

    // The `_shaped` job variants take the shape of the job's one-slot result,
    // so the caller gets its own copy before the job actor's heap is freed.
    // mesh_job_async_shaped(fn_ptr: ptr, env_ptr: ptr, result_shape: ptr) -> i64
    module.add_function(
        "mesh_job_async_shaped",
        i64_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_job_map_shaped(list_ptr: ptr, fn_ptr: ptr, env_ptr: ptr, result_shape: ptr) -> ptr
    module.add_function(
        "mesh_job_map_shaped",
        ptr_type.fn_type(
            &[
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // ── Timer functions (Phase 44 Plan 02) ──────────────────────────────

    // mesh_timer_sleep(ms: i64) -> void
    let timer_sleep_ty = void_type.fn_type(&[i64_type.into()], false);
    module.add_function(
        "mesh_timer_sleep",
        timer_sleep_ty,
        Some(inkwell::module::Linkage::External),
    );

    // mesh_timer_send_after(pid: i64, ms: i64, msg_ptr: ptr, msg_size: i64) -> void
    let timer_send_after_ty = void_type.fn_type(
        &[
            i64_type.into(),
            i64_type.into(),
            ptr_type.into(),
            i64_type.into(),
        ],
        false,
    );
    module.add_function(
        "mesh_timer_send_after",
        timer_send_after_ty,
        Some(inkwell::module::Linkage::External),
    );
    // mesh_timer_apply_after(ms: i64, fn_ptr: ptr, env_ptr: ptr) -> void
    module.add_function(
        "mesh_timer_apply_after",
        void_type.fn_type(&[i64_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_timer_send_after_shaped(pid, ms, msg_ptr, msg_size, shape: ptr) -> void
    module.add_function(
        "mesh_timer_send_after_shaped",
        void_type.fn_type(
            &[
                i64_type.into(),
                i64_type.into(),
                ptr_type.into(),
                i64_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_panic(msg: ptr, msg_len: u64, file: ptr, file_len: u64, line: u32) -> void
    // (noreturn -- marked via attribute)
    let panic_params: Vec<BasicMetadataTypeEnum<'ctx>> = vec![
        ptr_type.into(), // msg
        i64_type.into(), // msg_len
        ptr_type.into(), // file
        i64_type.into(), // file_len
        i32_type.into(), // line
    ];
    let panic_ty = void_type.fn_type(&panic_params, false);
    let panic_fn = module.add_function(
        "mesh_panic",
        panic_ty,
        Some(inkwell::module::Linkage::External),
    );
    // Mark as noreturn
    panic_fn.add_attribute(
        inkwell::attributes::AttributeLoc::Function,
        context.create_enum_attribute(
            inkwell::attributes::Attribute::get_named_enum_kind_id("noreturn"),
            0,
        ),
    );

    // mesh_panic_at(msg: ptr, msg_len: u64, file: ptr, file_len: u64, line: u32, col: u32) -> !
    // A panic whose source location compiled code knows.
    let panic_at_params: Vec<BasicMetadataTypeEnum<'ctx>> = vec![
        ptr_type.into(), // msg
        i64_type.into(), // msg_len
        ptr_type.into(), // file
        i64_type.into(), // file_len
        i32_type.into(), // line
        i32_type.into(), // col
    ];
    let panic_at_fn = module.add_function(
        "mesh_panic_at",
        void_type.fn_type(&panic_at_params, false),
        Some(inkwell::module::Linkage::External),
    );
    panic_at_fn.add_attribute(
        inkwell::attributes::AttributeLoc::Function,
        context.create_enum_attribute(
            inkwell::attributes::Attribute::get_named_enum_kind_id("noreturn"),
            0,
        ),
    );

    // ── Phase 67: Node distribution & remote spawn ──────────────────────

    // mesh_node_start(name_ptr: ptr, name_len: i64, cookie_ptr: ptr, cookie_len: i64) -> i64
    module.add_function(
        "mesh_node_start",
        i64_type.fn_type(
            &[
                ptr_type.into(),
                i64_type.into(),
                ptr_type.into(),
                i64_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_node_connect(name_ptr: ptr, name_len: i64) -> i64
    module.add_function(
        "mesh_node_connect",
        i64_type.fn_type(&[ptr_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_node_self() -> ptr
    module.add_function(
        "mesh_node_self",
        ptr_type.fn_type(&[], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_node_list() -> ptr
    module.add_function(
        "mesh_node_list",
        ptr_type.fn_type(&[], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_node_monitor(node_ptr: ptr, node_len: i64, msg_ptr: ptr, msg_size: i64, shape: ptr) -> i64
    module.add_function(
        "mesh_node_monitor",
        i64_type.fn_type(
            &[
                ptr_type.into(),
                i64_type.into(),
                ptr_type.into(),
                i64_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_node_spawn(node_ptr: ptr, node_len: i64, fn_name_ptr: ptr, fn_name_len: i64,
    //                 args_ptr: ptr, args_size: i64, arg_tags_ptr: ptr, arg_count: i64,
    //                 link_flag: i8) -> i64
    module.add_function(
        "mesh_node_spawn",
        i64_type.fn_type(
            &[
                ptr_type.into(),
                i64_type.into(),
                ptr_type.into(),
                i64_type.into(),
                ptr_type.into(),
                i64_type.into(),
                ptr_type.into(),
                i64_type.into(),
                i8_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_register_function(name_ptr: ptr, name_len: i64, fn_ptr: ptr,
    //     arg_tags_ptr: ptr, arg_count: i64) -> void
    module.add_function(
        "mesh_register_function",
        void_type.fn_type(
            &[
                ptr_type.into(),
                i64_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                i64_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_register_declared_handler(runtime_name_ptr: ptr, runtime_name_len: i64,
    //     executable_name_ptr: ptr, executable_name_len: i64, replication_count: i64,
    //     fn_ptr: ptr) -> void
    module.add_function(
        "mesh_register_declared_handler",
        void_type.fn_type(
            &[
                ptr_type.into(),
                i64_type.into(),
                ptr_type.into(),
                i64_type.into(),
                i64_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_register_startup_work(runtime_name_ptr: ptr, runtime_name_len: i64) -> void
    module.add_function(
        "mesh_register_startup_work",
        void_type.fn_type(&[ptr_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_trigger_startup_work() -> void
    module.add_function(
        "mesh_trigger_startup_work",
        void_type.fn_type(&[], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_process_monitor(target_pid: i64, msg_ptr: ptr, msg_size: i64, shape: ptr) -> i64
    module.add_function(
        "mesh_process_monitor",
        i64_type.fn_type(
            &[
                i64_type.into(),
                ptr_type.into(),
                i64_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_process_demonitor(monitor_ref: i64) -> i64
    module.add_function(
        "mesh_process_demonitor",
        i64_type.fn_type(&[i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_process_register(name: ptr, pid: i64) -> i64
    module.add_function(
        "mesh_process_register",
        i64_type.fn_type(&[ptr_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_process_whereis(name: ptr) -> i64
    module.add_function(
        "mesh_process_whereis",
        i64_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    module.add_function(
        "mesh_process_install_shutdown_signals",
        void_type.fn_type(&[], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_process_shutdown_requested",
        i8_type.fn_type(&[], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_process_request_shutdown",
        void_type.fn_type(&[], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_plaintext_enter() / mesh_plaintext_leave(): around a
    // `Plaintext.map`, whose panics then withhold their messages.
    for name in ["mesh_plaintext_enter", "mesh_plaintext_leave"] {
        module.add_function(
            name,
            void_type.fn_type(&[], false),
            Some(inkwell::module::Linkage::External),
        );
    }
    // mesh_panic_str(message: ptr) -> ! (`panic(message)`)
    let panic_str = module.add_function(
        "mesh_panic_str",
        void_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    panic_str.add_attribute(
        inkwell::attributes::AttributeLoc::Function,
        context.create_enum_attribute(
            inkwell::attributes::Attribute::get_named_enum_kind_id("noreturn"),
            0,
        ),
    );
    // mesh_panic_str_at(message: ptr, file: ptr, file_len: u64, line: u32, col: u32) -> !
    // (`panic(message)` whose source location compiled code knows)
    let panic_str_at = module.add_function(
        "mesh_panic_str_at",
        void_type.fn_type(
            &[
                ptr_type.into(),
                ptr_type.into(),
                i64_type.into(),
                i32_type.into(),
                i32_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );
    panic_str_at.add_attribute(
        inkwell::attributes::AttributeLoc::Function,
        context.create_enum_attribute(
            inkwell::attributes::Attribute::get_named_enum_kind_id("noreturn"),
            0,
        ),
    );
    let process_exit = module.add_function(
        "mesh_process_exit",
        void_type.fn_type(&[i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    process_exit.add_attribute(
        inkwell::attributes::AttributeLoc::Function,
        context.create_enum_attribute(
            inkwell::attributes::Attribute::get_named_enum_kind_id("noreturn"),
            0,
        ),
    );

    // ── Phase 76: Iterator runtime functions ──────────────────────────────
    // mesh_list_iter_new(list: ptr) -> ptr
    module.add_function(
        "mesh_list_iter_new",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_list_iter_next(iter: ptr) -> ptr (MeshOption)
    module.add_function(
        "mesh_list_iter_next",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_map_iter_new(map: ptr) -> ptr
    module.add_function(
        "mesh_map_iter_new",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_map_iter_next(iter: ptr) -> ptr (MeshOption)
    module.add_function(
        "mesh_map_iter_next",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_set_iter_new(set: ptr) -> ptr
    module.add_function(
        "mesh_set_iter_new",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_set_iter_next(iter: ptr) -> ptr (MeshOption)
    module.add_function(
        "mesh_set_iter_next",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_range_iter_new(start: i64, end: i64) -> ptr
    module.add_function(
        "mesh_range_iter_new",
        ptr_type.fn_type(&[i64_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_range_iter(range: ptr) -> ptr
    module.add_function(
        "mesh_range_iter",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_range_iter_next(iter: ptr) -> ptr (MeshOption)
    module.add_function(
        "mesh_range_iter_next",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_iter_from(collection: ptr) -> ptr (Iter.from entry point)
    module.add_function(
        "mesh_iter_from",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // ── Phase 78: Lazy Combinators & Terminals ──────────────────────────
    // Combinators: adapter constructors
    // mesh_iter_map(source: ptr, fn_ptr: ptr, env_ptr: ptr) -> ptr
    module.add_function(
        "mesh_iter_map",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_iter_filter(source: ptr, fn_ptr: ptr, env_ptr: ptr) -> ptr
    module.add_function(
        "mesh_iter_filter",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_iter_take(source: ptr, n: i64) -> ptr
    module.add_function(
        "mesh_iter_take",
        ptr_type.fn_type(&[ptr_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_iter_skip(source: ptr, n: i64) -> ptr
    module.add_function(
        "mesh_iter_skip",
        ptr_type.fn_type(&[ptr_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_iter_enumerate(source: ptr) -> ptr
    module.add_function(
        "mesh_iter_enumerate",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_iter_zip(source_a: ptr, source_b: ptr) -> ptr
    module.add_function(
        "mesh_iter_zip",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // Terminals
    // mesh_iter_count(iter: ptr) -> i64
    module.add_function(
        "mesh_iter_count",
        i64_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_iter_sum(iter: ptr) -> i64
    module.add_function(
        "mesh_iter_sum",
        i64_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_iter_any(iter: ptr, fn_ptr: ptr, env_ptr: ptr) -> i8 (Bool)
    module.add_function(
        "mesh_iter_any",
        i8_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_iter_all(iter: ptr, fn_ptr: ptr, env_ptr: ptr) -> i8 (Bool)
    module.add_function(
        "mesh_iter_all",
        i8_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_iter_find(iter: ptr, fn_ptr: ptr, env_ptr: ptr) -> ptr (MeshOption)
    module.add_function(
        "mesh_iter_find",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_iter_reduce(iter: ptr, init: i64, fn_ptr: ptr, env_ptr: ptr) -> i64
    module.add_function(
        "mesh_iter_reduce",
        i64_type.fn_type(
            &[
                ptr_type.into(),
                i64_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // Adapter _next functions (for resolve_iterator_fn dispatch)
    // mesh_iter_generic_next(iter: ptr) -> ptr (MeshOption)
    module.add_function(
        "mesh_iter_generic_next",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_iter_map_next(adapter: ptr) -> ptr (MeshOption)
    module.add_function(
        "mesh_iter_map_next",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_iter_filter_next(adapter: ptr) -> ptr (MeshOption)
    module.add_function(
        "mesh_iter_filter_next",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_iter_take_next(adapter: ptr) -> ptr (MeshOption)
    module.add_function(
        "mesh_iter_take_next",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_iter_skip_next(adapter: ptr) -> ptr (MeshOption)
    module.add_function(
        "mesh_iter_skip_next",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_iter_enumerate_next(adapter: ptr) -> ptr (MeshOption)
    module.add_function(
        "mesh_iter_enumerate_next",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_iter_zip_next(adapter: ptr) -> ptr (MeshOption)
    module.add_function(
        "mesh_iter_zip_next",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // ── Phase 79: Collect terminal operations ────────────────────────────
    // mesh_list_collect(iter: ptr) -> ptr
    module.add_function(
        "mesh_list_collect",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_map_collect(iter: ptr) -> ptr
    module.add_function(
        "mesh_map_collect",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_map_collect_string_keys(iter: ptr) -> ptr (Phase 96: string key variant)
    module.add_function(
        "mesh_map_collect_string_keys",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_set_collect(iter: ptr) -> ptr
    module.add_function(
        "mesh_set_collect",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    // mesh_string_collect(iter: ptr) -> ptr
    module.add_function(
        "mesh_string_collect",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // ── Phase 97: ORM SQL generation ────────────────────────────────

    // mesh_orm_build_select(table: ptr, fields: ptr, where_clauses: ptr, order_by: ptr, limit: i64, offset: i64) -> ptr
    module.add_function(
        "mesh_orm_build_select",
        ptr_type.fn_type(
            &[
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                i64_type.into(),
                i64_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_orm_build_insert(table: ptr, columns: ptr, returning: ptr) -> ptr
    module.add_function(
        "mesh_orm_build_insert",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_orm_build_update(table: ptr, set_columns: ptr, where_clauses: ptr, returning: ptr) -> ptr
    module.add_function(
        "mesh_orm_build_update",
        ptr_type.fn_type(
            &[
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_orm_build_delete(table: ptr, where_clauses: ptr, returning: ptr) -> ptr
    module.add_function(
        "mesh_orm_build_delete",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // ── Neutral SQL expression builder ────────────────────────────────

    module.add_function(
        "mesh_expr_column",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_expr_value",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_expr_null",
        ptr_type.fn_type(&[], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_expr_call",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_expr_add",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_expr_sub",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_expr_mul",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_expr_div",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_expr_eq",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_expr_neq",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_expr_lt",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_expr_lte",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_expr_gt",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_expr_gte",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_expr_case",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_expr_coalesce",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_expr_excluded",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
    module.add_function(
        "mesh_expr_alias",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // ── Phase 98: Query Builder ───────────────────────────────────────

    // mesh_query_from(table: ptr) -> ptr
    module.add_function(
        "mesh_query_from",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_query_where(q: ptr, field: ptr, value: ptr) -> ptr
    module.add_function(
        "mesh_query_where",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_query_where_op(q: ptr, field: ptr, op: ptr, value: ptr) -> ptr
    module.add_function(
        "mesh_query_where_op",
        ptr_type.fn_type(
            &[
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_query_where_in(q: ptr, field: ptr, values: ptr) -> ptr
    module.add_function(
        "mesh_query_where_in",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_query_where_null(q: ptr, field: ptr) -> ptr
    module.add_function(
        "mesh_query_where_null",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_query_where_not_null(q: ptr, field: ptr) -> ptr
    module.add_function(
        "mesh_query_where_not_null",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_query_where_not_in(q: ptr, field: ptr, values: ptr) -> ptr
    module.add_function(
        "mesh_query_where_not_in",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_query_where_between(q: ptr, field: ptr, low: ptr, high: ptr) -> ptr
    module.add_function(
        "mesh_query_where_between",
        ptr_type.fn_type(
            &[
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_query_where_or(q: ptr, fields: ptr, values: ptr) -> ptr
    module.add_function(
        "mesh_query_where_or",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_query_where_expr(q: ptr, expr: ptr) -> ptr
    module.add_function(
        "mesh_query_where_expr",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_query_select(q: ptr, fields: ptr) -> ptr
    module.add_function(
        "mesh_query_select",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_query_select_expr(q: ptr, expr: ptr) -> ptr
    module.add_function(
        "mesh_query_select_expr",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_query_select_exprs(q: ptr, exprs: ptr) -> ptr
    module.add_function(
        "mesh_query_select_exprs",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_query_order_by(q: ptr, field: ptr, direction: ptr) -> ptr
    module.add_function(
        "mesh_query_order_by",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_query_limit(q: ptr, n: i64) -> ptr
    module.add_function(
        "mesh_query_limit",
        ptr_type.fn_type(&[ptr_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_query_offset(q: ptr, n: i64) -> ptr
    module.add_function(
        "mesh_query_offset",
        ptr_type.fn_type(&[ptr_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_query_join(q: ptr, type: ptr, table: ptr, on_clause: ptr) -> ptr
    module.add_function(
        "mesh_query_join",
        ptr_type.fn_type(
            &[
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_query_join_as(q: ptr, type: ptr, table: ptr, alias: ptr, on_clause: ptr) -> ptr
    module.add_function(
        "mesh_query_join_as",
        ptr_type.fn_type(
            &[
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_query_group_by(q: ptr, field: ptr) -> ptr
    module.add_function(
        "mesh_query_group_by",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_query_having(q: ptr, clause: ptr, value: ptr) -> ptr
    module.add_function(
        "mesh_query_having",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // ── Phase 108: Aggregate SELECT functions ────────────────────────

    // mesh_query_select_count(q: ptr) -> ptr
    module.add_function(
        "mesh_query_select_count",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_query_select_count_field(q: ptr, field: ptr) -> ptr
    module.add_function(
        "mesh_query_select_count_field",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_query_select_sum(q: ptr, field: ptr) -> ptr
    module.add_function(
        "mesh_query_select_sum",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_query_select_avg(q: ptr, field: ptr) -> ptr
    module.add_function(
        "mesh_query_select_avg",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_query_select_min(q: ptr, field: ptr) -> ptr
    module.add_function(
        "mesh_query_select_min",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_query_select_max(q: ptr, field: ptr) -> ptr
    module.add_function(
        "mesh_query_select_max",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_query_fragment(q: ptr, sql: ptr, params: ptr) -> ptr
    module.add_function(
        "mesh_query_fragment",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // ── Phase 103: Query Builder Raw Extensions ──────────────────────

    // mesh_query_select_raw(q: ptr, expressions: ptr) -> ptr
    module.add_function(
        "mesh_query_select_raw",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_query_where_raw(q: ptr, clause: ptr, params: ptr) -> ptr
    module.add_function(
        "mesh_query_where_raw",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // ── Phase 106: Raw ORDER BY / GROUP BY ───────────────────────────

    // mesh_query_order_by_raw(q: ptr, expression: ptr) -> ptr
    module.add_function(
        "mesh_query_order_by_raw",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_query_group_by_raw(q: ptr, expression: ptr) -> ptr
    module.add_function(
        "mesh_query_group_by_raw",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // ── Phase 109: Subquery WHERE ──────────────────────────────────────

    // mesh_query_where_sub(q: ptr, field: ptr, sub_query: ptr) -> ptr
    module.add_function(
        "mesh_query_where_sub",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // ── Phase 98: Repo Read Operations ───────────────────────────────

    // mesh_repo_all(pool: i64, query: ptr) -> ptr
    module.add_function(
        "mesh_repo_all",
        ptr_type.fn_type(&[i64_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_repo_one(pool: i64, query: ptr) -> ptr
    module.add_function(
        "mesh_repo_one",
        ptr_type.fn_type(&[i64_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_repo_get(pool: i64, table: ptr, id: ptr) -> ptr
    module.add_function(
        "mesh_repo_get",
        ptr_type.fn_type(&[i64_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_repo_get_by(pool: i64, table: ptr, field: ptr, value: ptr) -> ptr
    module.add_function(
        "mesh_repo_get_by",
        ptr_type.fn_type(
            &[
                i64_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_repo_count(pool: i64, query: ptr) -> ptr
    module.add_function(
        "mesh_repo_count",
        ptr_type.fn_type(&[i64_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_repo_exists(pool: i64, query: ptr) -> ptr
    module.add_function(
        "mesh_repo_exists",
        ptr_type.fn_type(&[i64_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // ── Phase 98: Repo Write Operations ─────────────────────────────────

    // mesh_repo_insert(pool: i64, table: ptr, fields: ptr) -> ptr
    module.add_function(
        "mesh_repo_insert",
        ptr_type.fn_type(&[i64_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_repo_insert_expr(pool: i64, table: ptr, expr_fields: ptr) -> ptr
    module.add_function(
        "mesh_repo_insert_expr",
        ptr_type.fn_type(&[i64_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_repo_update(pool: i64, table: ptr, id: ptr, fields: ptr) -> ptr
    module.add_function(
        "mesh_repo_update",
        ptr_type.fn_type(
            &[
                i64_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_repo_delete(pool: i64, table: ptr, id: ptr) -> ptr
    module.add_function(
        "mesh_repo_delete",
        ptr_type.fn_type(&[i64_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_repo_transaction(pool: i64, fn_ptr: ptr, env_ptr: ptr) -> ptr
    module.add_function(
        "mesh_repo_transaction",
        ptr_type.fn_type(&[i64_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // ── Phase 103: Extended Repo Write Operations ──────────────────────

    // mesh_repo_update_where(pool: i64, table: ptr, fields: ptr, query: ptr) -> ptr
    module.add_function(
        "mesh_repo_update_where",
        ptr_type.fn_type(
            &[
                i64_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_repo_update_where_expr(pool: i64, table: ptr, expr_fields: ptr, query: ptr) -> ptr
    module.add_function(
        "mesh_repo_update_where_expr",
        ptr_type.fn_type(
            &[
                i64_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_repo_delete_where(pool: i64, table: ptr, query: ptr) -> ptr
    module.add_function(
        "mesh_repo_delete_where",
        ptr_type.fn_type(&[i64_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_repo_query_raw(pool: i64, sql: ptr, params: ptr) -> ptr
    module.add_function(
        "mesh_repo_query_raw",
        ptr_type.fn_type(&[i64_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_repo_execute_raw(pool: i64, sql: ptr, params: ptr) -> ptr
    module.add_function(
        "mesh_repo_execute_raw",
        ptr_type.fn_type(&[i64_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // ── Phase 109: Upsert, RETURNING, Subquery ──────────────────────────

    // mesh_repo_insert_or_update(pool: i64, table: ptr, fields: ptr, conflict_targets: ptr, update_fields: ptr) -> ptr
    module.add_function(
        "mesh_repo_insert_or_update",
        ptr_type.fn_type(
            &[
                i64_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_repo_insert_or_update_expr(pool: i64, table: ptr, fields: ptr, conflict_targets: ptr, expr_fields: ptr) -> ptr
    module.add_function(
        "mesh_repo_insert_or_update_expr",
        ptr_type.fn_type(
            &[
                i64_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_repo_delete_where_returning(pool: i64, table: ptr, query: ptr) -> ptr
    module.add_function(
        "mesh_repo_delete_where_returning",
        ptr_type.fn_type(&[i64_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // ── Phase 100: Repo Preloading ─────────────────────────────────────

    // mesh_repo_preload(pool: i64, rows: ptr, associations: ptr, rel_meta: ptr) -> ptr
    module.add_function(
        "mesh_repo_preload",
        ptr_type.fn_type(
            &[
                i64_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // ── Phase 99: Repo Changeset Operations ────────────────────────────

    // mesh_repo_insert_changeset(pool: i64, table: ptr, changeset: ptr) -> ptr
    module.add_function(
        "mesh_repo_insert_changeset",
        ptr_type.fn_type(&[i64_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_repo_update_changeset(pool: i64, table: ptr, id: ptr, changeset: ptr) -> ptr
    module.add_function(
        "mesh_repo_update_changeset",
        ptr_type.fn_type(
            &[
                i64_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // ── Phase 99: Changeset Operations ────────────────────────────────

    // mesh_changeset_cast(data: ptr, params: ptr, allowed: ptr) -> ptr
    module.add_function(
        "mesh_changeset_cast",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_changeset_cast_with_types(data: ptr, params: ptr, allowed: ptr, field_types: ptr) -> ptr
    module.add_function(
        "mesh_changeset_cast_with_types",
        ptr_type.fn_type(
            &[
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_changeset_validate_required(cs: ptr, fields: ptr) -> ptr
    module.add_function(
        "mesh_changeset_validate_required",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_changeset_validate_length(cs: ptr, field: ptr, min: i64, max: i64) -> ptr
    module.add_function(
        "mesh_changeset_validate_length",
        ptr_type.fn_type(
            &[
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_changeset_validate_format(cs: ptr, field: ptr, pattern: ptr) -> ptr
    module.add_function(
        "mesh_changeset_validate_format",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_changeset_validate_inclusion(cs: ptr, field: ptr, allowed_values: ptr) -> ptr
    module.add_function(
        "mesh_changeset_validate_inclusion",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_changeset_validate_number(cs: ptr, field: ptr, gt: i64, lt: i64, gte: i64, lte: i64) -> ptr
    module.add_function(
        "mesh_changeset_validate_number",
        ptr_type.fn_type(
            &[
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_changeset_valid(cs: ptr) -> ptr
    module.add_function(
        "mesh_changeset_valid",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_changeset_errors(cs: ptr) -> ptr
    module.add_function(
        "mesh_changeset_errors",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_changeset_changes(cs: ptr) -> ptr
    module.add_function(
        "mesh_changeset_changes",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_changeset_get_change(cs: ptr, field: ptr) -> ptr
    module.add_function(
        "mesh_changeset_get_change",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_changeset_get_error(cs: ptr, field: ptr) -> ptr
    module.add_function(
        "mesh_changeset_get_error",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // ── Phase 101: Migration DDL Operations ────────────────────────────

    // mesh_migration_create_table(pool: i64, table: ptr, columns: ptr) -> ptr
    module.add_function(
        "mesh_migration_create_table",
        ptr_type.fn_type(&[i64_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_migration_drop_table(pool: i64, table: ptr) -> ptr
    module.add_function(
        "mesh_migration_drop_table",
        ptr_type.fn_type(&[i64_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_migration_add_column(pool: i64, table: ptr, col_def: ptr) -> ptr
    module.add_function(
        "mesh_migration_add_column",
        ptr_type.fn_type(&[i64_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_migration_drop_column(pool: i64, table: ptr, col: ptr) -> ptr
    module.add_function(
        "mesh_migration_drop_column",
        ptr_type.fn_type(&[i64_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_migration_rename_column(pool: i64, table: ptr, old: ptr, new: ptr) -> ptr
    module.add_function(
        "mesh_migration_rename_column",
        ptr_type.fn_type(
            &[
                i64_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_migration_create_index(pool: i64, table: ptr, cols: ptr, opts: ptr) -> ptr
    module.add_function(
        "mesh_migration_create_index",
        ptr_type.fn_type(
            &[
                i64_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_migration_drop_index(pool: i64, table: ptr, cols: ptr) -> ptr
    module.add_function(
        "mesh_migration_drop_index",
        ptr_type.fn_type(&[i64_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_migration_execute(pool: i64, sql: ptr) -> ptr
    module.add_function(
        "mesh_migration_execute",
        ptr_type.fn_type(&[i64_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // ── Phase 68: Global Registry ──────────────────────────────────────

    // mesh_global_register(name_ptr: ptr, name_len: i64, pid: i64) -> i64
    module.add_function(
        "mesh_global_register",
        i64_type.fn_type(&[ptr_type.into(), i64_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_global_whereis(name_ptr: ptr, name_len: i64) -> i64
    module.add_function(
        "mesh_global_whereis",
        i64_type.fn_type(&[ptr_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_global_unregister(name_ptr: ptr, name_len: i64) -> i64
    module.add_function(
        "mesh_global_unregister",
        i64_type.fn_type(&[ptr_type.into(), i64_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_node_start_from_env() -> ptr (MeshResult<BootstrapStatus, String>)
    module.add_function(
        "mesh_node_start_from_env",
        ptr_type.fn_type(&[], false),
        Some(inkwell::module::Linkage::External),
    );

    // ── continuity: Continuity runtime functions ───────────────────────────
    // mesh_continuity_submit_with_durability(...) -> ptr (MeshResult<ContinuitySubmitDecision, String>)
    module.add_function(
        "mesh_continuity_submit_with_durability",
        ptr_type.fn_type(
            &[
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                i64_type.into(),
                i8_type.into(),
                i8_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_continuity_submit_declared_work(runtime_name, request_key, payload_hash, required_replica_count)
    //   -> ptr (MeshResult<ContinuitySubmitDecision, String>)
    module.add_function(
        "mesh_continuity_submit_declared_work",
        ptr_type.fn_type(
            &[
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                i64_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // Compatibility wrapper: mesh_continuity_submit(...) -> ptr (MeshResult<ContinuitySubmitDecision, String>)
    module.add_function(
        "mesh_continuity_submit",
        ptr_type.fn_type(
            &[
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                ptr_type.into(),
                i8_type.into(),
                i8_type.into(),
            ],
            false,
        ),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_continuity_status(request_key) -> ptr (MeshResult<ContinuityRecord, String>)
    module.add_function(
        "mesh_continuity_status",
        ptr_type.fn_type(&[ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_continuity_authority_status() -> ptr (MeshResult<ContinuityAuthorityStatus, String>)
    module.add_function(
        "mesh_continuity_authority_status",
        ptr_type.fn_type(&[], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_continuity_mark_completed(...) -> ptr (MeshResult<ContinuityRecord, String>)
    module.add_function(
        "mesh_continuity_mark_completed",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_continuity_complete_declared_work(...) -> ptr (MeshResult<ContinuityRecord, String>)
    module.add_function(
        "mesh_continuity_complete_declared_work",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );

    // mesh_continuity_acknowledge_replica(...) -> ptr (MeshResult<ContinuityRecord, String>)
    module.add_function(
        "mesh_continuity_acknowledge_replica",
        ptr_type.fn_type(&[ptr_type.into(), ptr_type.into()], false),
        Some(inkwell::module::Linkage::External),
    );
}

/// Get a runtime function by name from the module.
///
/// Panics if the function was not declared (call `declare_intrinsics` first).
pub fn get_intrinsic<'ctx>(module: &Module<'ctx>, name: &str) -> FunctionValue<'ctx> {
    module
        .get_function(name)
        .unwrap_or_else(|| panic!("Runtime function '{}' not declared", name))
}

/// The set operations that compare elements by an element-type Eq
/// callback and hash them by its Hash callback (both null: as words), as
/// `(name, params, returns)` with returns 1 for a pointer, 2 for a Bool.
fn set_by_declarations<'ctx>(
    ptr_type: inkwell::types::PointerType<'ctx>,
    i64_type: inkwell::types::IntType<'ctx>,
) -> Vec<(
    &'static str,
    Vec<inkwell::types::BasicMetadataTypeEnum<'ctx>>,
    u8,
)> {
    let callbacks = [ptr_type.into(), ptr_type.into()];
    let with = |args: &[inkwell::types::BasicMetadataTypeEnum<'ctx>]| {
        args.iter().chain(&callbacks).copied().collect::<Vec<_>>()
    };
    vec![
        (
            "mesh_set_add_by",
            with(&[ptr_type.into(), i64_type.into()]),
            1,
        ),
        (
            "mesh_set_remove_by",
            with(&[ptr_type.into(), i64_type.into()]),
            1,
        ),
        (
            "mesh_set_contains_by",
            with(&[ptr_type.into(), i64_type.into()]),
            2,
        ),
        (
            "mesh_set_union_by",
            with(&[ptr_type.into(), ptr_type.into()]),
            1,
        ),
        (
            "mesh_set_intersection_by",
            with(&[ptr_type.into(), ptr_type.into()]),
            1,
        ),
        (
            "mesh_set_difference_by",
            with(&[ptr_type.into(), ptr_type.into()]),
            1,
        ),
        (
            "mesh_set_eq_by",
            with(&[ptr_type.into(), ptr_type.into()]),
            2,
        ),
        ("mesh_set_from_list_by", with(&[ptr_type.into()]), 1),
        ("mesh_set_collect_by", with(&[ptr_type.into()]), 1),
    ]
}

#[cfg(test)]
mod tests {
    use super::*;
    use inkwell::context::Context;

    #[test]
    fn test_declare_all_intrinsics() {
        let context = Context::create();
        let module = context.create_module("test");
        declare_intrinsics(&module);

        // Verify all expected functions exist
        assert!(module.get_function("mesh_rt_init").is_some());
        assert!(module.get_function("mesh_run_main").is_some());
        assert!(module.get_function("mesh_gc_alloc_actor").is_some());
        assert!(module.get_function("mesh_string_new").is_some());
        assert!(module.get_function("mesh_string_concat").is_some());
        assert!(module.get_function("mesh_int_to_string").is_some());
        assert!(module.get_function("mesh_float_to_string").is_some());
        assert!(module.get_function("mesh_bool_to_string").is_some());
        assert!(module.get_function("mesh_print").is_some());
        assert!(module.get_function("mesh_println").is_some());
        assert!(module.get_function("mesh_panic").is_some());
        assert!(module.get_function("mesh_panic_at").is_some());

        // Actor runtime functions
        assert!(module.get_function("mesh_rt_init_actor").is_some());
        assert!(module.get_function("mesh_actor_spawn").is_some());
        assert!(module.get_function("mesh_actor_spawn_shaped").is_some());
        assert!(module.get_function("mesh_actor_send").is_some());
        assert!(module.get_function("mesh_actor_send_shaped").is_some());
        assert!(module.get_function("mesh_actor_receive").is_some());
        assert!(module.get_function("mesh_actor_self").is_some());
        assert!(module.get_function("mesh_actor_link").is_some());
        assert!(module.get_function("mesh_reduction_check").is_some());
        assert!(module.get_function("mesh_actor_set_terminate").is_some());
        assert!(module.get_function("mesh_rt_run_scheduler").is_some());

        // Supervisor runtime functions
        assert!(module.get_function("mesh_supervisor_start").is_some());
        assert!(module.get_function("mesh_supervisor_start_child").is_some());
        assert!(module
            .get_function("mesh_supervisor_terminate_child")
            .is_some());
        assert!(module
            .get_function("mesh_supervisor_count_children")
            .is_some());
        assert!(module.get_function("mesh_actor_trap_exit").is_some());
        assert!(module.get_function("mesh_actor_exit").is_some());

        // Standard library functions (Phase 8)
        assert!(module.get_function("mesh_file_read").is_some());
        assert!(module.get_function("mesh_file_write").is_some());
        assert!(module.get_function("mesh_file_append").is_some());
        assert!(module.get_function("mesh_file_exists").is_some());
        assert!(module.get_function("mesh_file_delete").is_some());
        assert!(module.get_function("mesh_file_rename").is_some());
        assert!(module.get_function("mesh_file_sync").is_some());
        assert!(module.get_function("mesh_string_length").is_some());
        assert!(module.get_function("mesh_string_slice").is_some());
        assert!(module.get_function("mesh_string_contains").is_some());
        assert!(module.get_function("mesh_string_starts_with").is_some());
        assert!(module.get_function("mesh_string_ends_with").is_some());
        assert!(module.get_function("mesh_string_trim").is_some());
        assert!(module.get_function("mesh_string_to_upper").is_some());
        assert!(module.get_function("mesh_string_to_lower").is_some());
        assert!(module.get_function("mesh_string_replace").is_some());
        assert!(module.get_function("mesh_string_eq").is_some());
        assert!(module.get_function("mesh_string_compare").is_some());
        assert!(module.get_function("mesh_string_split").is_some());
        assert!(module.get_function("mesh_string_join").is_some());
        assert!(module.get_function("mesh_string_to_int").is_some());
        assert!(module.get_function("mesh_string_to_float").is_some());
        assert!(module.get_function("mesh_io_read_line").is_some());
        assert!(module.get_function("mesh_io_eprintln").is_some());
        assert!(module.get_function("mesh_env_get").is_some());
        assert!(module.get_function("mesh_env_args").is_some());
        assert!(module.get_function("mesh_env_get_with_default").is_some());
        assert!(module.get_function("mesh_env_get_int").is_some());
        assert!(module.get_function("mesh_env_get_secret_hex").is_some());

        // Collection functions (Phase 8 Plan 02)
        assert!(module.get_function("mesh_list_new").is_some());
        assert!(module.get_function("mesh_list_length").is_some());
        assert!(module.get_function("mesh_list_append").is_some());
        assert!(module.get_function("mesh_list_head").is_some());
        assert!(module.get_function("mesh_list_tail").is_some());
        assert!(module.get_function("mesh_list_get").is_some());
        assert!(module.get_function("mesh_list_concat").is_some());
        assert!(module.get_function("mesh_list_reverse").is_some());
        assert!(module.get_function("mesh_list_map").is_some());
        assert!(module.get_function("mesh_list_filter").is_some());
        assert!(module.get_function("mesh_list_reduce").is_some());
        assert!(module.get_function("mesh_list_from_array").is_some());
        assert!(module.get_function("mesh_list_builder_new").is_some());
        assert!(module.get_function("mesh_list_builder_push").is_some());
        // Phase 46: List sort, find, any, all, contains
        assert!(module.get_function("mesh_list_sort").is_some());
        assert!(module.get_function("mesh_list_find").is_some());
        assert!(module.get_function("mesh_list_any").is_some());
        assert!(module.get_function("mesh_list_all").is_some());
        assert!(module.get_function("mesh_list_contains").is_some());
        // Phase 47: List zip, flat_map, flatten, enumerate, take, drop, last, nth
        assert!(module.get_function("mesh_list_zip").is_some());
        assert!(module.get_function("mesh_list_flat_map").is_some());
        assert!(module.get_function("mesh_list_flatten").is_some());
        assert!(module.get_function("mesh_list_enumerate").is_some());
        assert!(module.get_function("mesh_list_take").is_some());
        assert!(module.get_function("mesh_list_drop").is_some());
        assert!(module.get_function("mesh_list_last").is_some());
        assert!(module.get_function("mesh_list_nth").is_some());
        assert!(module.get_function("mesh_map_new").is_some());
        assert!(module.get_function("mesh_map_new_typed").is_some());
        assert!(module.get_function("mesh_map_put").is_some());
        assert!(module.get_function("mesh_map_get").is_some());
        assert!(module.get_function("mesh_map_has_key").is_some());
        assert!(module.get_function("mesh_map_delete").is_some());
        assert!(module.get_function("mesh_map_size").is_some());
        assert!(module.get_function("mesh_map_keys").is_some());
        assert!(module.get_function("mesh_map_values").is_some());
        assert!(module.get_function("mesh_map_merge").is_some());
        assert!(module.get_function("mesh_map_to_list").is_some());
        assert!(module.get_function("mesh_map_from_list").is_some());
        assert!(module.get_function("mesh_map_entry_key").is_some());
        assert!(module.get_function("mesh_map_entry_value").is_some());
        assert!(module.get_function("mesh_set_new").is_some());
        assert!(module.get_function("mesh_set_add").is_some());
        assert!(module.get_function("mesh_set_remove").is_some());
        assert!(module.get_function("mesh_set_contains").is_some());
        assert!(module.get_function("mesh_set_size").is_some());
        assert!(module.get_function("mesh_set_union").is_some());
        assert!(module.get_function("mesh_set_intersection").is_some());
        assert!(module.get_function("mesh_set_element_at").is_some());
        assert!(module.get_function("mesh_set_difference").is_some());
        assert!(module.get_function("mesh_set_to_list").is_some());
        assert!(module.get_function("mesh_set_from_list").is_some());
        assert!(module.get_function("mesh_tuple_nth").is_some());
        assert!(module.get_function("mesh_tuple_first").is_some());
        assert!(module.get_function("mesh_tuple_second").is_some());
        assert!(module.get_function("mesh_tuple_size").is_some());
        assert!(module.get_function("mesh_range_new").is_some());
        assert!(module.get_function("mesh_range_to_list").is_some());
        assert!(module.get_function("mesh_range_map").is_some());
        assert!(module.get_function("mesh_range_filter").is_some());
        assert!(module.get_function("mesh_range_length").is_some());
        assert!(module.get_function("mesh_queue_new").is_some());
        assert!(module.get_function("mesh_queue_push").is_some());
        assert!(module.get_function("mesh_queue_pop").is_some());
        assert!(module.get_function("mesh_queue_peek").is_some());
        assert!(module.get_function("mesh_queue_size").is_some());
        assert!(module.get_function("mesh_queue_is_empty").is_some());

        // HTTP functions (Phase 8 Plan 05)
        assert!(module.get_function("mesh_http_router").is_some());
        assert!(module.get_function("mesh_http_route").is_some());
        assert!(module.get_function("mesh_http_serve").is_some());
        assert!(module.get_function("mesh_http_serve_tls").is_some());
        assert!(module.get_function("mesh_http_response_new").is_some());
        assert!(module.get_function("mesh_http_request_method").is_some());
        assert!(module.get_function("mesh_http_request_path").is_some());
        assert!(module.get_function("mesh_http_request_body").is_some());
        assert!(module.get_function("mesh_http_request_header").is_some());
        assert!(module.get_function("mesh_http_request_query").is_some());

        // Phase 51: Method-specific routing and path parameter extraction
        assert!(module.get_function("mesh_http_route_get").is_some());
        assert!(module.get_function("mesh_http_route_post").is_some());
        assert!(module.get_function("mesh_http_route_put").is_some());
        assert!(module.get_function("mesh_http_route_delete").is_some());
        assert!(module.get_function("mesh_http_request_param").is_some());

        // Phase 52: Middleware
        assert!(module.get_function("mesh_http_use_middleware").is_some());

        // Phase 53: SQLite
        assert!(module.get_function("mesh_sqlite_open").is_some());
        assert!(module.get_function("mesh_sqlite_close").is_some());
        assert!(module.get_function("mesh_sqlite_execute").is_some());
        assert!(module.get_function("mesh_sqlite_query").is_some());
        assert!(module.get_function("mesh_sqlite_execute_values").is_some());
        assert!(module.get_function("mesh_sqlite_query_values").is_some());

        // Phase 54: PostgreSQL
        assert!(module.get_function("mesh_pg_connect").is_some());
        assert!(module.get_function("mesh_pg_close").is_some());
        assert!(module.get_function("mesh_pg_execute").is_some());
        assert!(module.get_function("mesh_pg_query").is_some());
        assert!(module.get_function("mesh_pg_execute_values").is_some());
        assert!(module.get_function("mesh_pg_query_values").is_some());

        // Phase 57: PostgreSQL Transactions
        assert!(module.get_function("mesh_pg_begin").is_some());
        assert!(module.get_function("mesh_pg_commit").is_some());
        assert!(module.get_function("mesh_pg_rollback").is_some());
        assert!(module.get_function("mesh_pg_transaction").is_some());

        // PostgreSQL expression helpers.
        assert!(module.get_function("mesh_pg_cast").is_some());
        assert!(module.get_function("mesh_pg_jsonb").is_some());
        assert!(module.get_function("mesh_pg_int").is_some());
        assert!(module.get_function("mesh_pg_text").is_some());
        assert!(module.get_function("mesh_pg_uuid").is_some());
        assert!(module.get_function("mesh_pg_timestamptz").is_some());
        assert!(module.get_function("mesh_pg_gen_salt").is_some());
        assert!(module.get_function("mesh_pg_crypt").is_some());
        assert!(module.get_function("mesh_pg_to_tsvector").is_some());
        assert!(module.get_function("mesh_pg_plainto_tsquery").is_some());
        assert!(module.get_function("mesh_pg_ts_rank").is_some());
        assert!(module.get_function("mesh_pg_tsvector_matches").is_some());
        assert!(module.get_function("mesh_pg_jsonb_contains").is_some());

        // PostgreSQL schema helpers.
        assert!(module.get_function("mesh_pg_create_extension").is_some());
        assert!(module
            .get_function("mesh_pg_create_range_partitioned_table")
            .is_some());
        assert!(module.get_function("mesh_pg_create_gin_index").is_some());
        assert!(module
            .get_function("mesh_pg_create_daily_partitions_ahead")
            .is_some());
        assert!(module
            .get_function("mesh_pg_list_daily_partitions_before")
            .is_some());
        assert!(module.get_function("mesh_pg_drop_partition").is_some());

        // Phase 57: SQLite Transactions
        assert!(module.get_function("mesh_sqlite_begin").is_some());
        assert!(module.get_function("mesh_sqlite_commit").is_some());
        assert!(module.get_function("mesh_sqlite_rollback").is_some());

        // Phase 57: Connection Pool
        assert!(module.get_function("mesh_pool_open").is_some());
        assert!(module.get_function("mesh_pool_close").is_some());
        assert!(module.get_function("mesh_pool_query").is_some());
        assert!(module.get_function("mesh_pool_execute").is_some());
        assert!(module.get_function("mesh_pool_query_values").is_some());
        assert!(module.get_function("mesh_pool_execute_values").is_some());

        // Phase 58: Row Parsing & Struct-to-Row Mapping
        assert!(module.get_function("mesh_row_from_row_get").is_some());
        assert!(module.get_function("mesh_row_parse_int").is_some());
        assert!(module.get_function("mesh_row_parse_float").is_some());
        assert!(module.get_function("mesh_row_parse_bool").is_some());
        assert!(module.get_function("mesh_pg_query_as").is_some());
        assert!(module.get_function("mesh_pool_query_as").is_some());

        // Service runtime functions (Phase 9 Plan 03)
        assert!(module.get_function("mesh_service_call").is_some());
        assert!(module.get_function("mesh_service_reply").is_some());

        // Job runtime functions (Phase 9 Plan 04)
        assert!(module.get_function("mesh_job_async").is_some());
        assert!(module.get_function("mesh_job_await").is_some());
        assert!(module.get_function("mesh_job_await_timeout").is_some());
        assert!(module.get_function("mesh_job_map").is_some());
        assert!(module.get_function("mesh_job_async_shaped").is_some());
        assert!(module.get_function("mesh_job_map_shaped").is_some());

        // JSON functions (Phase 8 Plan 04)
        assert!(module.get_function("mesh_json_parse").is_some());
        assert!(module.get_function("mesh_json_encode").is_some());
        assert!(module.get_function("mesh_json_encode_string").is_some());
        assert!(module.get_function("mesh_json_encode_int").is_some());
        assert!(module.get_function("mesh_json_encode_bool").is_some());
        assert!(module.get_function("mesh_json_encode_map").is_some());
        assert!(module.get_function("mesh_json_encode_list").is_some());
        assert!(module.get_function("mesh_json_from_int").is_some());
        assert!(module.get_function("mesh_json_from_float").is_some());
        assert!(module.get_function("mesh_json_from_bool").is_some());
        assert!(module.get_function("mesh_json_from_string").is_some());

        // Phase 103: JSON field extraction
        assert!(module.get_function("mesh_json_get").is_some());
        assert!(module.get_function("mesh_json_get_nested").is_some());
        assert!(module.get_function("mesh_json_is_string").is_some());

        // Structured JSON functions (Phase 49)
        assert!(module.get_function("mesh_json_object_new").is_some());
        assert!(module.get_function("mesh_json_object_put").is_some());
        assert!(module.get_function("mesh_json_object_get").is_some());
        assert!(module.get_function("mesh_json_array_new").is_some());
        assert!(module.get_function("mesh_json_array_push").is_some());
        assert!(module.get_function("mesh_json_array_get").is_some());
        assert!(module.get_function("mesh_json_as_int").is_some());
        assert!(module.get_function("mesh_json_as_float").is_some());
        assert!(module.get_function("mesh_json_as_string").is_some());
        assert!(module.get_function("mesh_json_as_bool").is_some());
        assert!(module.get_function("mesh_json_null").is_some());
        assert!(module.get_function("mesh_json_from_list").is_some());
        assert!(module.get_function("mesh_json_from_map").is_some());
        assert!(module.get_function("mesh_json_to_list").is_some());
        assert!(module.get_function("mesh_json_to_map").is_some());

        // Hash runtime functions (Phase 21 Plan 01)
        assert!(module.get_function("mesh_hash_int").is_some());
        assert!(module.get_function("mesh_hash_float").is_some());
        assert!(module.get_function("mesh_hash_bool").is_some());
        assert!(module.get_function("mesh_hash_string").is_some());
        assert!(module.get_function("mesh_hash_combine").is_some());

        // Collection Display runtime functions (Phase 21 Plan 04)
        assert!(module.get_function("mesh_list_to_string").is_some());
        assert!(module.get_function("mesh_map_to_string").is_some());
        assert!(module.get_function("mesh_set_to_string").is_some());
        assert!(module.get_function("mesh_string_to_string").is_some());

        // List Eq/Ord runtime functions (Phase 27 Plan 01)
        assert!(module.get_function("mesh_list_eq").is_some());
        assert!(module.get_function("mesh_list_compare").is_some());

        // Timer functions (Phase 44 Plan 02)
        assert!(module.get_function("mesh_timer_sleep").is_some());
        assert!(module.get_function("mesh_timer_send_after").is_some());
        assert!(module.get_function("mesh_timer_apply_after").is_some());
        assert!(module
            .get_function("mesh_timer_send_after_shaped")
            .is_some());

        // WebSocket functions (Phase 60)
        assert!(module.get_function("mesh_ws_serve").is_some());
        assert!(module.get_function("mesh_ws_send").is_some());
        assert!(module.get_function("mesh_ws_serve_tls").is_some());

        // WebSocket Room functions (Phase 62)
        assert!(module.get_function("mesh_ws_join").is_some());
        assert!(module.get_function("mesh_ws_leave").is_some());
        assert!(module.get_function("mesh_ws_broadcast").is_some());
        assert!(module.get_function("mesh_ws_broadcast_except").is_some());

        // Phase 67: Node distribution & remote spawn
        assert!(module.get_function("mesh_node_start").is_some());
        assert!(module.get_function("mesh_node_start_from_env").is_some());
        assert!(module.get_function("mesh_node_connect").is_some());
        assert!(module.get_function("mesh_node_self").is_some());
        assert!(module.get_function("mesh_node_list").is_some());
        assert!(module.get_function("mesh_node_monitor").is_some());
        assert!(module.get_function("mesh_node_spawn").is_some());
        assert!(module.get_function("mesh_register_function").is_some());
        assert!(module
            .get_function("mesh_register_declared_handler")
            .is_some());
        assert!(module.get_function("mesh_process_monitor").is_some());
        assert!(module.get_function("mesh_process_demonitor").is_some());

        // continuity: continuity runtime functions
        assert!(module
            .get_function("mesh_continuity_submit_with_durability")
            .is_some());
        assert!(module
            .get_function("mesh_continuity_submit_declared_work")
            .is_some());
        assert!(module.get_function("mesh_continuity_status").is_some());
        assert!(module
            .get_function("mesh_continuity_authority_status")
            .is_some());
        assert!(module
            .get_function("mesh_continuity_mark_completed")
            .is_some());
        assert!(module
            .get_function("mesh_continuity_complete_declared_work")
            .is_some());
        assert!(module
            .get_function("mesh_continuity_acknowledge_replica")
            .is_some());

        // Phase 68: Global Registry
        assert!(module.get_function("mesh_global_register").is_some());
        assert!(module.get_function("mesh_global_whereis").is_some());
        assert!(module.get_function("mesh_global_unregister").is_some());

        // Phase 76: Iterator runtime functions
        assert!(module.get_function("mesh_list_iter_new").is_some());
        assert!(module.get_function("mesh_list_iter_next").is_some());
        assert!(module.get_function("mesh_map_iter_new").is_some());
        assert!(module.get_function("mesh_map_iter_next").is_some());
        assert!(module.get_function("mesh_set_iter_new").is_some());
        assert!(module.get_function("mesh_set_iter_next").is_some());
        assert!(module.get_function("mesh_range_iter_new").is_some());
        assert!(module.get_function("mesh_range_iter").is_some());
        assert!(module.get_function("mesh_range_iter_next").is_some());
        assert!(module.get_function("mesh_iter_from").is_some());

        // Phase 78: Lazy Combinators & Terminals
        assert!(module.get_function("mesh_iter_map").is_some());
        assert!(module.get_function("mesh_iter_filter").is_some());
        assert!(module.get_function("mesh_iter_take").is_some());
        assert!(module.get_function("mesh_iter_skip").is_some());
        assert!(module.get_function("mesh_iter_enumerate").is_some());
        assert!(module.get_function("mesh_iter_zip").is_some());
        assert!(module.get_function("mesh_iter_count").is_some());
        assert!(module.get_function("mesh_iter_sum").is_some());
        assert!(module.get_function("mesh_iter_any").is_some());
        assert!(module.get_function("mesh_iter_all").is_some());
        assert!(module.get_function("mesh_iter_find").is_some());
        assert!(module.get_function("mesh_iter_reduce").is_some());
        assert!(module.get_function("mesh_iter_generic_next").is_some());
        assert!(module.get_function("mesh_iter_map_next").is_some());
        assert!(module.get_function("mesh_iter_filter_next").is_some());
        assert!(module.get_function("mesh_iter_take_next").is_some());
        assert!(module.get_function("mesh_iter_skip_next").is_some());
        assert!(module.get_function("mesh_iter_enumerate_next").is_some());
        assert!(module.get_function("mesh_iter_zip_next").is_some());

        // Phase 79: Collect terminal operations
        assert!(module.get_function("mesh_list_collect").is_some());
        assert!(module.get_function("mesh_map_collect").is_some());
        assert!(module.get_function("mesh_set_collect").is_some());
        assert!(module.get_function("mesh_string_collect").is_some());

        // Phase 97: ORM SQL Generation
        assert!(module.get_function("mesh_orm_build_select").is_some());
        assert!(module.get_function("mesh_orm_build_insert").is_some());
        assert!(module.get_function("mesh_orm_build_update").is_some());
        assert!(module.get_function("mesh_orm_build_delete").is_some());

        // Neutral SQL expression builder.
        assert!(module.get_function("mesh_expr_column").is_some());
        assert!(module.get_function("mesh_expr_value").is_some());
        assert!(module.get_function("mesh_expr_null").is_some());
        assert!(module.get_function("mesh_expr_call").is_some());
        assert!(module.get_function("mesh_expr_add").is_some());
        assert!(module.get_function("mesh_expr_sub").is_some());
        assert!(module.get_function("mesh_expr_mul").is_some());
        assert!(module.get_function("mesh_expr_div").is_some());
        assert!(module.get_function("mesh_expr_eq").is_some());
        assert!(module.get_function("mesh_expr_neq").is_some());
        assert!(module.get_function("mesh_expr_lt").is_some());
        assert!(module.get_function("mesh_expr_lte").is_some());
        assert!(module.get_function("mesh_expr_gt").is_some());
        assert!(module.get_function("mesh_expr_gte").is_some());
        assert!(module.get_function("mesh_expr_case").is_some());
        assert!(module.get_function("mesh_expr_coalesce").is_some());
        assert!(module.get_function("mesh_expr_excluded").is_some());
        assert!(module.get_function("mesh_expr_alias").is_some());

        // Phase 101: Migration DDL Operations
        assert!(module.get_function("mesh_migration_create_table").is_some());
        assert!(module.get_function("mesh_migration_drop_table").is_some());
        assert!(module.get_function("mesh_migration_add_column").is_some());
        assert!(module.get_function("mesh_migration_drop_column").is_some());
        assert!(module
            .get_function("mesh_migration_rename_column")
            .is_some());
        assert!(module.get_function("mesh_migration_create_index").is_some());
        assert!(module.get_function("mesh_migration_drop_index").is_some());
        assert!(module.get_function("mesh_migration_execute").is_some());

        // Phase 98: Query Builder
        assert!(module.get_function("mesh_query_from").is_some());
        assert!(module.get_function("mesh_query_where").is_some());
        assert!(module.get_function("mesh_query_where_op").is_some());
        assert!(module.get_function("mesh_query_where_in").is_some());
        assert!(module.get_function("mesh_query_where_null").is_some());
        assert!(module.get_function("mesh_query_where_not_null").is_some());
        assert!(module.get_function("mesh_query_select").is_some());
        assert!(module.get_function("mesh_query_where_expr").is_some());
        assert!(module.get_function("mesh_query_select_expr").is_some());
        assert!(module.get_function("mesh_query_select_exprs").is_some());
        assert!(module.get_function("mesh_query_order_by").is_some());
        assert!(module.get_function("mesh_query_limit").is_some());
        assert!(module.get_function("mesh_query_offset").is_some());
        assert!(module.get_function("mesh_query_join").is_some());
        assert!(module.get_function("mesh_query_join_as").is_some());
        assert!(module.get_function("mesh_query_group_by").is_some());
        assert!(module.get_function("mesh_query_having").is_some());
        assert!(module.get_function("mesh_query_fragment").is_some());
        // Phase 106: Raw ORDER BY / GROUP BY
        assert!(module.get_function("mesh_query_order_by_raw").is_some());
        assert!(module.get_function("mesh_query_group_by_raw").is_some());
        // Phase 108: Aggregate SELECT functions
        assert!(module.get_function("mesh_query_select_count").is_some());
        assert!(module
            .get_function("mesh_query_select_count_field")
            .is_some());
        assert!(module.get_function("mesh_query_select_sum").is_some());
        assert!(module.get_function("mesh_query_select_avg").is_some());
        assert!(module.get_function("mesh_query_select_min").is_some());
        assert!(module.get_function("mesh_query_select_max").is_some());
        // Phase 109: Upsert, RETURNING, Subquery
        assert!(module.get_function("mesh_repo_insert").is_some());
        assert!(module.get_function("mesh_repo_insert_expr").is_some());
        assert!(module.get_function("mesh_repo_insert_or_update").is_some());
        assert!(module
            .get_function("mesh_repo_insert_or_update_expr")
            .is_some());
        assert!(module.get_function("mesh_repo_update_where_expr").is_some());
        assert!(module
            .get_function("mesh_repo_delete_where_returning")
            .is_some());
        assert!(module.get_function("mesh_query_where_sub").is_some());

        // Phase 119: Regex functions
        assert!(module.get_function("mesh_regex_from_literal").is_some());
        assert!(module.get_function("mesh_regex_compile").is_some());
        assert!(module.get_function("mesh_regex_match").is_some());
        assert!(module.get_function("mesh_regex_captures").is_some());
        assert!(module.get_function("mesh_regex_replace").is_some());
        assert!(module.get_function("mesh_regex_split").is_some());
    }

    #[test]
    fn test_get_intrinsic() {
        let context = Context::create();
        let module = context.create_module("test");
        declare_intrinsics(&module);

        let init_fn = get_intrinsic(&module, "mesh_rt_init");
        assert_eq!(init_fn.get_name().to_str().unwrap(), "mesh_rt_init");
    }

    #[test]
    fn crypto_v2_intrinsics_match_runtime_arity() {
        let context = Context::create();
        let module = context.create_module("test");
        declare_intrinsics(&module);

        for (name, arity) in [
            ("mesh_crypto_sha256", 1),
            ("mesh_crypto_sha512", 1),
            ("mesh_crypto_sha256_hex", 1),
            ("mesh_crypto_sha512_hex", 1),
            ("mesh_crypto_random_bytes", 1),
            ("mesh_crypto_hmac_sha256", 2),
            ("mesh_crypto_hmac_sha256_tag", 2),
            ("mesh_crypto_hkdf_sha256", 4),
            ("mesh_crypto_argon2id", 6),
            ("mesh_crypto_x25519_generate", 0),
            ("mesh_crypto_x25519_from_seed", 1),
            ("mesh_crypto_x25519_from_secret", 1),
            ("mesh_crypto_x25519_public", 1),
            ("mesh_crypto_x25519_shared", 2),
            ("mesh_crypto_mlkem_generate", 0),
            ("mesh_crypto_mlkem_from_seed", 1),
            ("mesh_crypto_mlkem_from_secret", 1),
            ("mesh_crypto_mlkem_encapsulate", 1),
            ("mesh_crypto_mlkem_decapsulate", 2),
            ("mesh_crypto_signing_generate", 0),
            ("mesh_crypto_signing_from_seed", 1),
            ("mesh_crypto_signing_from_secret", 1),
            ("mesh_crypto_sign", 2),
            ("mesh_crypto_verify", 3),
            ("mesh_crypto_aead_key", 1),
            ("mesh_crypto_aead_seal", 4),
            ("mesh_crypto_aead_open", 4),
            ("mesh_crypto_hpke_seal", 4),
            ("mesh_crypto_hpke_open", 4),
            ("mesh_crypto_hpke_seal_secret", 4),
            ("mesh_crypto_hpke_open_secret", 4),
            ("mesh_crypto_hpke_seal_export", 5),
            ("mesh_crypto_hpke_open_export", 5),
            ("mesh_crypto_hkdf_aead_seal", 4),
            ("mesh_crypto_hkdf_aead_open", 4),
            ("mesh_crypto_blind_rsa_generate", 0),
            ("mesh_crypto_blind_rsa_from_secret", 1),
            ("mesh_crypto_blind_rsa_public", 1),
            ("mesh_crypto_blind_rsa_public_from_spki", 1),
            ("mesh_crypto_blind_rsa_blind", 2),
            ("mesh_crypto_blind_rsa_sign", 2),
            ("mesh_crypto_blind_rsa_finalize", 4),
            ("mesh_crypto_blind_rsa_verify", 3),
            ("mesh_blind_rsa_secret_key_seal_for_storage", 3),
            ("mesh_blind_rsa_secret_key_unseal_from_storage", 3),
        ] {
            let function = module
                .get_function(name)
                .unwrap_or_else(|| panic!("missing intrinsic {name}"));
            assert_eq!(
                function.get_type().count_param_types(),
                arity,
                "wrong ABI arity for {name}"
            );
            assert!(
                function
                    .get_type()
                    .get_return_type()
                    .is_some_and(|return_type| return_type.is_pointer_type()),
                "{name} must return a runtime pointer"
            );
        }
    }

    #[test]
    fn test_nonreturning_intrinsics_are_marked_noreturn() {
        let context = Context::create();
        let module = context.create_module("test");
        declare_intrinsics(&module);

        let noreturn_id = inkwell::attributes::Attribute::get_named_enum_kind_id("noreturn");
        for name in [
            "mesh_panic",
            "mesh_panic_at",
            "mesh_panic_str",
            "mesh_panic_str_at",
            "mesh_process_exit",
        ] {
            let function = get_intrinsic(&module, name);
            let attr = function
                .get_enum_attribute(inkwell::attributes::AttributeLoc::Function, noreturn_id);
            assert!(attr.is_some(), "{name} should have noreturn attribute");
        }
    }
}
