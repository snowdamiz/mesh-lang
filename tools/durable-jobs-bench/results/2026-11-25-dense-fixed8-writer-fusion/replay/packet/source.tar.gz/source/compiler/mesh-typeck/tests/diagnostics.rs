//! Snapshot tests for Mesh type error diagnostics.
//!
//! Each test triggers a specific type error, renders it as `meshc` does
//! (through a `Reporter`), and snapshots the output with insta. These verify
//! that error messages are terse, include dual-span labels, and show fix
//! suggestions when plausible.

use mesh_diagnostics::{Format, Reporter, SourceFile};
use mesh_typeck::error::TypeError;
use mesh_typeck::TypeckResult;

// ── Helpers ────────────────────────────────────────────────────────────

/// Parse Mesh source and run the type checker.
fn check_source(src: &str) -> TypeckResult {
    let parse = mesh_parser::parse(src);
    mesh_typeck::check(&parse)
}

/// `error` in `src`, a file named `test.mpl`, as a reporter writes it.
fn render_as(format: Format, error: &TypeError, src: &str) -> String {
    let mut out = Vec::new();
    Reporter::new(format, &mut out).emit(error.to_diagnostic(&SourceFile::new("test.mpl", src)));
    String::from_utf8(out).unwrap()
}

/// `error` in `src` as the terminal shows it, without colour.
fn render(error: &TypeError, src: &str) -> String {
    render_as(Format::Human { color: false }, error, src)
}

/// Render the first error from a type check result as a diagnostic string.
fn render_first_error(src: &str) -> String {
    let result = check_source(src);
    assert!(
        !result.errors.is_empty(),
        "expected at least one error for source: {:?}",
        src
    );
    render(&result.errors[0], src)
}

// ── Diagnostic Snapshot Tests ──────────────────────────────────────────

#[test]
fn try_error_mismatch_reports_both_result_types() {
    let source =
        "fn wrap() -> Bytes ! String do\n  let value = Bytes.repeat(0, 4) ?\n  Ok(value)\nend";
    let output = render_first_error(source);
    assert!(output.contains("Result<Bytes, BytesError>"), "{output}");
    assert!(output.contains("Result<Bytes, String>"), "{output}");
    assert!(!output.contains("requires function to return"), "{output}");
}

/// Type mismatch: annotation says Int but expression is a String.
#[test]
fn test_diag_type_mismatch() {
    let src = "let x :: Int = \"hello\"";
    let output = render_first_error(src);
    insta::assert_snapshot!(output);
}

/// Type mismatch in if branches: then branch Int, else branch String.
#[test]
fn test_diag_if_branch_mismatch() {
    let src = "if true do 1 else \"hello\" end";
    let output = render_first_error(src);
    insta::assert_snapshot!(output);
}

/// Arity mismatch: function expects 2 args, called with 1.
#[test]
fn test_diag_arity_mismatch() {
    let src = "let f = fn (x, y) -> x end\nf(1)";
    let output = render_first_error(src);
    insta::assert_snapshot!(output);
}

/// Unbound variable: name not defined.
#[test]
fn test_diag_unbound_variable() {
    let src = "x + 1";
    let output = render_first_error(src);
    insta::assert_snapshot!(output);
}

/// Not a function: trying to call an Int.
#[test]
fn test_diag_not_a_function() {
    let src = "let x = 42\nx(1)";
    let output = render_first_error(src);
    insta::assert_snapshot!(output);
}

/// Missing field in struct literal.
#[test]
fn test_diag_missing_field() {
    let src = "struct Point do\n  x :: Int\n  y :: Int\nend\nPoint { x: 1 }";
    let output = render_first_error(src);
    insta::assert_snapshot!(output);
}

/// Unknown field in struct literal.
#[test]
fn test_diag_unknown_field() {
    let src = "struct Point do\n  x :: Int\n  y :: Int\nend\nPoint { x: 1, z: 2 }";
    let output = render_first_error(src);
    insta::assert_snapshot!(output);
}

/// Trait not satisfied: String used with +.
#[test]
fn test_diag_trait_not_satisfied() {
    let src = "\"hello\" + \"world\"";
    let output = render_first_error(src);
    insta::assert_snapshot!(output);
}

/// A module's diagnostics are its errors, each rendered.
#[test]
fn test_every_error_of_a_module_renders() {
    let src = "x + y";
    let result = check_source(src);
    let file = SourceFile::new("test.mpl", src);
    let mut out = Vec::new();
    let mut reporter = Reporter::new(Format::Human { color: false }, &mut out);
    assert!(reporter.emit_all(result.diagnostics(&file)).is_err());
    let summary = reporter.finish();
    assert_eq!(summary.errors as usize, result.errors.len());
    let output = String::from_utf8(out).unwrap();
    assert_eq!(
        output.matches("] Error: ").count(),
        result.errors.len(),
        "{output}"
    );
}

/// Error code appears in diagnostic output.
#[test]
fn test_error_codes_present() {
    let src = "let x :: Int = \"hello\"";
    let output = render_first_error(src);
    assert!(
        output.contains("E0001"),
        "expected E0001 in mismatch diagnostic: {}",
        output
    );

    let src2 = "x + 1";
    let output2 = render_first_error(src2);
    assert!(
        output2.contains("E0004"),
        "expected E0004 in unbound var diagnostic: {}",
        output2
    );
}

// ── Phase 4 Diagnostic Tests ────────────────────────────────────────

#[test]
fn test_diag_non_exhaustive_match() {
    let src = "case x do Some(v) -> v end";
    let err = TypeError::NonExhaustiveMatch {
        scrutinee_type: "Option<Int>".to_string(),
        missing_patterns: vec!["None".to_string()],
        span: rowan::TextRange::new(0.into(), 26.into()),
    };
    let output = render(&err, src);
    insta::assert_snapshot!(output);
}

#[test]
fn test_diag_non_exhaustive_match_multiple() {
    let src = "case s do Circle(r) -> r end";
    let err = TypeError::NonExhaustiveMatch {
        scrutinee_type: "Shape".to_string(),
        missing_patterns: vec!["Rect".to_string(), "Point".to_string()],
        span: rowan::TextRange::new(0.into(), 28.into()),
    };
    let output = render(&err, src);
    assert!(output.contains("E0012"), "expected E0012 code: {}", output);
    assert!(
        output.contains("Rect"),
        "expected Rect in missing: {}",
        output
    );
    assert!(
        output.contains("Point"),
        "expected Point in missing: {}",
        output
    );
    assert!(
        output.contains("non-exhaustive"),
        "expected non-exhaustive message: {}",
        output
    );
}

#[test]
fn test_diag_redundant_arm() {
    let src = "case x do _ -> 1\n  _ -> 2 end";
    let err = TypeError::RedundantArm {
        arm_index: 1,
        span: rowan::TextRange::new(18.into(), 24.into()),
    };
    let output = render(&err, src);
    insta::assert_snapshot!(output);
}

#[test]
fn test_diag_redundant_arm_is_warning() {
    let src = "case x do _ -> 1\n  true -> 2 end";
    let err = TypeError::RedundantArm {
        arm_index: 1,
        span: rowan::TextRange::new(18.into(), 27.into()),
    };
    let output = render(&err, src);
    assert!(
        output.contains("Warning"),
        "expected Warning kind: {}",
        output
    );
    assert!(output.contains("W0001"), "expected W0001 code: {}", output);
    assert!(
        output.contains("unreachable"),
        "expected 'unreachable' label: {}",
        output
    );
}

#[test]
fn test_diag_unknown_variant() {
    let src = "type Shape do Circle(Float) end\ncase s do Triangle(a) -> a end";
    let err = TypeError::UnknownVariant {
        name: "Triangle".to_string(),
        span: rowan::TextRange::new(42.into(), 54.into()),
        suggestion: None,
        cons_tail: false,
    };
    let output = render(&err, src);
    assert!(output.contains("E0010"), "expected E0010 code: {}", output);
    assert!(
        output.contains("Triangle"),
        "expected 'Triangle' in output: {}",
        output
    );
}

#[test]
fn test_diag_or_pattern_binding_mismatch() {
    let src = "case x do a | (b, c) -> a end";
    let err = TypeError::OrPatternBindingMismatch {
        expected_bindings: vec!["a".to_string()],
        found_bindings: vec!["b".to_string(), "c".to_string()],
        list_tail: false,
        span: rowan::TextRange::new(10.into(), 20.into()),
    };
    let output = render(&err, src);
    assert!(output.contains("E0011"), "expected E0011 code: {}", output);
    assert!(
        output.contains("bind"),
        "expected binding-related message: {}",
        output
    );
}

/// A closure of two parameters where one taking a pair is expected, as
/// `fn (k, v) -> ...` over `Map.to_list`, names the tuple pattern form.
#[test]
fn test_diag_closure_of_a_tuple_elements_names_the_tuple_pattern() {
    let output = render_first_error(
        "fn main() do\n  let pairs = [(1, 2)] |> List.map(fn (a, b) -> \"x\" end)\n  pairs\nend\n",
    );
    assert!(output.contains("E0003"), "{output}");
    assert!(output.contains("fn ((a, b))"), "{output}");
    let arity = render_first_error("fn main() do\n  List.map([1], fn a, b -> a end)\nend\n");
    assert!(!arity.contains("tuple"), "{arity}");
}

/// `null`, a name other languages give the absent value, points at
/// `Option`.
#[test]
fn test_diag_null_names_option() {
    let output = render_first_error("fn main() do\n  let x = null\n  x\nend\n");
    assert!(output.contains("E0004"), "{output}");
    assert!(output.contains("`None`"), "{output}");
}

/// `+` on strings or lists points at the operators that join them, not at
/// implementing `Add` for a built-in type.
#[test]
fn test_diag_adding_strings_names_the_join_operator() {
    for src in [
        "fn main() do\n  println(\"x\" + \"y\")\nend\n",
        "fn f() -> List<Int> do\n  [1] + [2]\nend\n",
    ] {
        let output = render_first_error(src);
        assert!(output.contains("`<>`"), "{output}");
        assert!(!output.contains("impl Add"), "{output}");
    }
}

/// `n :: Int`, a type annotation written in a pattern, is a cons pattern
/// whose tail names no variant: the help says what `::` means there.
#[test]
fn test_diag_annotation_in_a_pattern_names_the_cons_reading() {
    let annotated = render_first_error(
        "fn f(x :: List<Int>) -> Int do\n  case x do\n    n :: Int -> 1\n    _ -> 0\n  end\nend\n",
    );
    assert!(annotated.contains("E0010"), "{annotated}");
    assert!(annotated.contains("no type annotation"), "{annotated}");
    let misspelled = render_first_error(
        "type Color do\n  Green\nend\n\nfn f(c :: Color) -> Int do\n  case c do\n    Grean -> 1\n  end\nend\n",
    );
    assert!(!misspelled.contains("no type annotation"), "{misspelled}");
}

/// `[a, b | rest]`, a list's tail as another language writes it, is an
/// or-pattern ending the list pattern: the help says how Mesh writes the
/// tail, where elsewhere it says what an or-pattern needs.
#[test]
fn test_diag_or_pattern_ending_a_list_names_the_tail_syntax() {
    let tail = render_first_error(
        "fn f(xs :: List<Int>) -> Int do\n  case xs do\n    [a, b | rest] -> a\n    _ -> 0\n  end\nend\n",
    );
    assert!(tail.contains("E0011"), "{tail}");
    assert!(tail.contains("a :: b :: rest"), "{tail}");
    let elsewhere = render_first_error(
        "fn f(p :: (Int, Int)) -> Int do\n  case p do\n    (a, 0) | (0, b) -> 1\n    _ -> 0\n  end\nend\n",
    );
    assert!(elsewhere.contains("E0011"), "{elsewhere}");
    assert!(!elsewhere.contains("::"), "{elsewhere}");
}

// ── Phase 6 Actor Diagnostic Tests ──────────────────────────────────

#[test]
fn test_diag_send_type_mismatch() {
    let src = "send(pid, 42)";
    let err = TypeError::SendTypeMismatch {
        expected: mesh_typeck::ty::Ty::string(),
        found: mesh_typeck::ty::Ty::int(),
        span: rowan::TextRange::new(0.into(), 13.into()),
    };
    let output = render(&err, src);
    insta::assert_snapshot!(output);
}

#[test]
fn test_diag_self_outside_actor() {
    let src = "let me = self()";
    let result = check_source(src);
    assert!(!result.errors.is_empty(), "expected SelfOutsideActor error");
    let output = render(&result.errors[0], src);
    assert!(output.contains("E0015"), "expected E0015 code: {}", output);
    assert!(
        output.contains("self()"),
        "expected 'self()' in output: {}",
        output
    );
    insta::assert_snapshot!(output);
}

#[test]
fn test_diag_spawn_non_function() {
    let src = "spawn(42)";
    let err = TypeError::SpawnNonFunction {
        found: mesh_typeck::ty::Ty::int(),
        span: rowan::TextRange::new(0.into(), 9.into()),
    };
    let output = render(&err, src);
    assert!(output.contains("E0016"), "expected E0016 code: {}", output);
    assert!(
        output.contains("function"),
        "expected 'function' in output: {}",
        output
    );
    insta::assert_snapshot!(output);
}

#[test]
fn test_diag_receive_outside_actor() {
    let src = "receive do\nn -> n\nend";
    let result = check_source(src);
    assert!(
        !result.errors.is_empty(),
        "expected ReceiveOutsideActor error"
    );
    let output = render(&result.errors[0], src);
    assert!(output.contains("E0017"), "expected E0017 code: {}", output);
    assert!(
        output.contains("receive"),
        "expected 'receive' in output: {}",
        output
    );
    insta::assert_snapshot!(output);
}

#[test]
fn test_wrong_send_reports_only_the_send_mismatch() {
    // The failed unification used to leave its own spanless mismatch too,
    // rendered over the whole file with a misleading `to_string()` hint.
    let src = "actor counter(total :: Int) do\n  receive do\n    amount -> counter(total + amount)\n  end\nend\n\nfn main() do\n  let pid = spawn(counter, 0)\n  send(pid, \"five\")\nend\n";
    let result = check_source(src);
    assert_eq!(result.errors.len(), 1, "{:?}", result.errors);
    assert!(
        matches!(result.errors[0], TypeError::SendTypeMismatch { .. }),
        "{:?}",
        result.errors
    );
}

#[test]
fn test_diag_send_type_mismatch_details() {
    let src = "send(pid, \"hello\")";
    let err = TypeError::SendTypeMismatch {
        expected: mesh_typeck::ty::Ty::int(),
        found: mesh_typeck::ty::Ty::string(),
        span: rowan::TextRange::new(0.into(), 18.into()),
    };
    let output = render(&err, src);
    assert!(
        output.contains("Int"),
        "expected 'Int' type in output: {}",
        output
    );
    assert!(
        output.contains("String"),
        "expected 'String' type in output: {}",
        output
    );
    assert!(
        output.contains("Pid"),
        "expected 'Pid' in help text: {}",
        output
    );
}

// ── Phase 10 JSON + Multi-span Diagnostic Tests ────────────────────

#[test]
fn test_json_output_mode() {
    let src = "let x :: Int = \"hello\"";
    let result = check_source(src);
    assert!(!result.errors.is_empty());
    let output = render_as(Format::Json, &result.errors[0], src);
    let parsed: serde_json::Value = serde_json::from_str(&output)
        .unwrap_or_else(|e| panic!("invalid JSON output: {}\n{}", e, output));
    assert_eq!(parsed["code"], "E0001");
    assert_eq!(parsed["severity"], "error");
    assert!(parsed["message"].as_str().unwrap().contains("expected"));
    assert!(!parsed["spans"].as_array().unwrap().is_empty());
}

#[test]
fn test_json_one_line() {
    let src = "x + 1";
    let result = check_source(src);
    assert!(!result.errors.is_empty());
    let output = render_as(Format::Json, &result.errors[0], src);
    // One object per line: a single trailing newline and none inside.
    assert!(
        output.ends_with('\n') && !output.trim_end().contains('\n'),
        "JSON output should be one line: {}",
        output
    );
}

/// A struct missing a derivable trait is told to derive it.
#[test]
fn test_a_struct_without_display_is_told_to_derive_it() {
    let src =
        "struct Box do\n  n :: Int\nend\n\nfn main() do\n  println(\"#{Box { n: 1 }}\")\nend\n";
    let result = mesh_typeck::check(&mesh_parser::parse(src));
    let err = result
        .errors
        .iter()
        .find(|error| matches!(error, TypeError::TraitNotSatisfied { .. }))
        .unwrap_or_else(|| panic!("{:?}", result.errors));
    let output = render(err, src);
    assert!(
        output.contains("add `deriving(Display)` to the definition of `Box`"),
        "{output}"
    );
}

#[test]
fn test_calling_a_value_is_not_a_function() {
    let src = "fn main() do\n  let x = 42\n  x(1)\nend\n";
    let parse = mesh_parser::parse(src);
    let result = mesh_typeck::check(&parse);
    let err = result
        .errors
        .iter()
        .find(|error| matches!(error, TypeError::NotAFunction { .. }))
        .unwrap_or_else(|| panic!("{:?}", result.errors));
    let TypeError::NotAFunction { ty, span } = err else {
        unreachable!()
    };
    assert_eq!(ty.to_string(), "Int");
    assert_eq!(&src[span.start().into()..span.end().into()], "x");
    let output = render(err, src);
    assert!(output.contains("`Int` is not a function"), "{output}");
    assert!(output.contains("remove the parentheses"), "{output}");
}

// ── Phase 32 AmbiguousMethod Diagnostic Tests ──────────────────────

#[test]
fn test_diag_ambiguous_method_deterministic_order() {
    use mesh_typeck::ty::Ty;

    let src = "x.to_string()";
    let err = TypeError::AmbiguousMethod {
        method_name: "to_string".to_string(),
        candidate_traits: vec!["Displayable".to_string(), "Printable".to_string()],
        ty: Ty::int(),
        span: rowan::TextRange::new(0.into(), 13.into()),
    };
    let output = render(&err, src);
    insta::assert_snapshot!(output);
}

#[test]
fn test_diag_ambiguous_method_help_text() {
    use mesh_typeck::ty::Ty;

    let src = "point.to_string()";
    let err = TypeError::AmbiguousMethod {
        method_name: "to_string".to_string(),
        candidate_traits: vec!["Display".to_string(), "Printable".to_string()],
        ty: Ty::Con(mesh_typeck::ty::TyCon::new("Point")),
        span: rowan::TextRange::new(0.into(), 17.into()),
    };
    let output = render(&err, src);
    insta::assert_snapshot!(output);
}

/// `xs[i]` used to type-check as an unknown type and compile to `()`.
#[test]
fn diag_indexing_is_unsupported() {
    let src = "fn main() do\n  let xs = [1, 2, 3]\n  let x = xs[1]\n  x\nend\n";
    let result = check_source(src);
    assert!(
        result
            .errors
            .iter()
            .any(|error| matches!(error, TypeError::IndexingUnsupported { .. })),
        "{:?}",
        result.errors
    );
    let rendered = render_first_error(src);
    assert!(rendered.contains("E0078"), "{rendered}");
    assert!(rendered.contains("List.get(list, index)"), "{rendered}");
}

/// A misspelled name gets the closest name in scope as its repair, with an
/// edit that a tool applies only after review.
#[test]
fn a_misspelled_name_suggests_an_edit() {
    let src = "fn main() do\n  let count = 1\n  println(\"#{cuont}\")\nend\n";
    let result = check_source(src);
    let error = result
        .errors
        .iter()
        .find(|error| matches!(error, TypeError::UnboundVariable { .. }))
        .unwrap_or_else(|| panic!("{:?}", result.errors));
    let json: serde_json::Value =
        serde_json::from_str(&render_as(Format::Json, error, src)).unwrap();
    let start = src.find("cuont").unwrap();
    assert_eq!(json["fix"], "did you mean `count`?");
    assert_eq!(
        json["edits"],
        serde_json::json!([{
            "file": "test.mpl",
            "start": start,
            "end": start + 5,
            "replacement": "count",
            "applicability": "maybe-incorrect"
        }])
    );
}

#[test]
fn scoped_typos_offer_edits_to_the_misspelled_token() {
    use mesh_diagnostics::{Applicability, Code};

    let point = "struct Point do\n  count :: Int\nend\n\n";
    let supervisor = "supervisor Workers do\n  strategy: one_for_one\n  child worker do\n    start: fn -> spawn(worker) end\n    restart: permannt\n  end\nend\n";
    for (source, code, typo, fixed) in [
        (format!("{point}fn make() = Point {{ coun: 1 }}"), Code::InvalidField, "coun", "count"),
        (format!("{point}fn change(p :: Point) = %{{p | coun: 1}}"), Code::InvalidField, "coun", "count"),
        (format!("{point}fn read(p :: Point) = p.coun"), Code::InvalidField, "coun", "count"),
        (format!("{point}fn read(p :: Point) do\n  case p do\n    Point {{ coun: n }} -> n\n  end\nend"), Code::InvalidField, "coun", "count"),
        ("fn size(s :: String) = s.lenght()".into(), Code::NoSuchMethod, "lenght", "length"),
        (format!("{point}fn read(p :: Poin) = p"), Code::UnknownType, "Poin", "Point"),
        ("fn read(s :: Strng) = s".into(), Code::UnknownType, "Strng", "String"),
        ("supervisor Workers do\n  strategy: one_for_oe\nend".into(), Code::UnknownSupervisionStrategy, "one_for_oe", "one_for_one"),
        (format!("actor worker() do\n  nil\nend\n\n{supervisor}"), Code::InvalidRestartType, "permannt", "permanent"),
    ] {
        let result = check_source(&source);
        let error = result.errors.iter().find(|error| error.code() == code)
            .unwrap_or_else(|| panic!("{source}: {:?}", result.errors));
        let diagnostic = error.to_diagnostic(&SourceFile::new("test.mpl", source.as_str()));
        assert_eq!(diagnostic.repair(), format!("did you mean `{fixed}`?"));
        let [edit] = diagnostic.edits() else {
            panic!("{source}: expected one edit, got {:?}", diagnostic.edits());
        };
        assert_eq!(edit.applicability(), Applicability::MaybeIncorrect);
        assert_eq!(edit.replacement(), fixed);
        let edited = edit.span();
        assert_eq!(&source[edited.start as usize..edited.end as usize], typo);

        let mut corrected = source.clone();
        corrected.replace_range(edited.start as usize..edited.end as usize, fixed);
        let corrected_result = check_source(&corrected);
        assert!(corrected_result.errors.is_empty(), "{corrected}: {:?}", corrected_result.errors);

        let mismatched = error.to_diagnostic(&SourceFile::new("test.mpl", source.replace(typo, &"x".repeat(typo.len()))));
        assert_eq!(mismatched.repair(), diagnostic.repair());
        assert!(mismatched.edits().is_empty());
    }
}
