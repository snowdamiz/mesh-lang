//! Algorithm J inference engine for Mesh.
//!
//! Walks the Mesh AST, generates type constraints, and solves them via
//! unification. Implements Hindley-Milner type inference with:
//! - Let-polymorphism (generalize + instantiate)
//! - Occurs check (rejects infinite types)
//! - Level-based generalization (Remy's algorithm)
//! - Error provenance via ConstraintOrigin
//! - Trait system: interface definitions, impl blocks, where-clause enforcement
//! - Compiler-known traits for operator dispatch (Add, Eq, Ord, etc.)
//! - Struct definitions, struct literals, and field access (03-03)

use mesh_parser::ast::expr::{
    BinaryExpr, BreakExpr, CallExpr, CaseExpr, ClosureExpr, ContinueExpr, Expr, FieldAccess,
    ForInExpr, IfExpr, JsonExpr, LinkExpr, ListLiteral, Literal, MapLiteral, NameRef, PipeExpr,
    ReceiveExpr, ReturnExpr, SelfExpr, SendExpr, SlotPipeExpr, SpawnExpr, StructLiteral,
    StructUpdate, TryExpr, TupleExpr, UnaryExpr, WhileExpr,
};
use mesh_parser::ast::item::{
    ActorDef, Block, FnDef, ImplDef as AstImplDef, InterfaceDef, Item, LetBinding, ServiceDef,
    StructDef, SumTypeDef, SupervisorDef, TypeAliasDef,
};
use mesh_parser::ast::pat::Pattern;
use mesh_parser::ast::AstNode;
use mesh_parser::syntax_kind::SyntaxKind;
use mesh_parser::Parse;
use rowan::TextRange;

use crate::builtins;
use crate::env::TypeEnv;
use crate::error::{ConstraintOrigin, TypeError};
use crate::exhaustiveness::{
    self, ConstructorSig, LitKind as AbsLitKind, Pat as AbsPat, TypeInfo as AbsTypeInfo,
    TypeRegistry as AbsTypeRegistry,
};
use crate::ownership::source_function_name;
use crate::traits::{
    AssocTypeDef as TraitAssocTypeDef, ImplDef as TraitImplDef, ImplMethodSig, ImplProblem,
    TraitDef, TraitMethodSig, TraitRegistry,
};
use crate::ty::{NatIndex, Scheme, Ty, TyCon, TyVar};
use crate::unify::{DeriveNeed, EarlyReturn, ImplChoice, InferCtx, MethodParam, PendingField};
use crate::{
    ClusteredRouteReplicationCount, ClusteredRouteWrapperMetadata, ImportContext, TypeckResult,
};

use rustc_hash::{FxHashMap, FxHashSet};

#[path = "indexed.rs"]
mod indexed;
use indexed::*;
pub use indexed::{IndexedSumTypeInfo, IndexedVariantInfo};

/// Helper enum for tracking children in source order during multi-clause grouping.
enum ChildKind {
    /// An item, identified by its index in the original items list.
    ItemIndex(usize),
    /// A bare expression (not wrapped in an item).
    Expr(Expr),
}

// ── Struct & Type Registry (03-03) ────────────────────────────────────

/// A registered struct definition with its fields and generic parameters.
#[derive(Clone, Debug)]
pub struct StructDefInfo {
    /// The struct's name.
    pub name: String,
    /// Names of generic type parameters (e.g., ["A", "B"] for `Pair<A, B>`).
    pub generic_params: Vec<String>,
    /// Field names and their types. Types may reference generic params.
    pub fields: Vec<(String, Ty)>,
    /// What `deriving(Schema)` declares, which relationships to the struct
    /// (in any module) read.
    pub schema: Option<SchemaInfo>,
}

/// A `deriving(Schema)` struct's table.
#[derive(Clone, Debug)]
pub struct SchemaInfo {
    /// The configured table, or `default_schema_table`.
    pub table: String,
    /// The configured primary key column, or `id`.
    pub primary_key: String,
    /// Whether `timestamps true` adds `inserted_at` and `updated_at`.
    pub timestamps: bool,
}

/// The table of a schema that configures none: the lowercased struct name
/// plus "s".
pub fn default_schema_table(struct_name: &str) -> String {
    format!("{}s", struct_name.to_lowercase())
}

fn schema_info(struct_def: &StructDef, name: &str) -> SchemaInfo {
    let mut schema = SchemaInfo {
        table: default_schema_table(name),
        primary_key: "id".to_string(),
        timestamps: false,
    };
    for option in struct_def.schema_options() {
        match option.option_name().as_deref() {
            Some("table") => schema.table = option.string_value().unwrap_or(schema.table),
            Some("primary_key") => {
                schema.primary_key = option.atom_value().unwrap_or(schema.primary_key)
            }
            // `timestamps`, the one option left.
            _ => schema.timestamps = option.bool_value().unwrap_or(false),
        }
    }
    schema
}

/// A registered type alias.
#[derive(Clone, Debug)]
pub struct TypeAliasInfo {
    /// The alias name.
    #[allow(dead_code)]
    pub name: String,
    /// Names of generic type parameters.
    #[allow(dead_code)]
    pub generic_params: Vec<String>,
    /// The aliased type (may reference generic params).
    #[allow(dead_code)]
    pub aliased_type: Ty,
}

// ── Sum Type Registry (04-02) ──────────────────────────────────────────

/// A registered sum type definition with its variants and generic parameters.
#[derive(Clone, Debug)]
pub struct SumTypeDefInfo {
    /// The sum type's name (e.g. "Shape", "Option").
    pub name: String,
    /// Names of generic type parameters (e.g. ["T"] for `Option<T>`).
    pub generic_params: Vec<String>,
    /// Kind information and defining-module identity for an indexed sum.
    pub indexed: Option<IndexedSumTypeInfo>,
    /// Variant definitions.
    pub variants: Vec<VariantInfo>,
}

/// A single variant of a sum type.
#[derive(Clone, Debug)]
pub struct VariantInfo {
    /// The variant's name (e.g. "Circle", "Some").
    pub name: String,
    /// The variant's fields (positional or named).
    pub fields: Vec<VariantFieldInfo>,
    /// The index telescope and result of an indexed constructor.
    pub indexed: Option<IndexedVariantInfo>,
}

/// A field in a variant -- either positional (unnamed) or named.
#[derive(Clone, Debug)]
pub enum VariantFieldInfo {
    /// Positional field (e.g. `Float` in `Circle(Float)`).
    Positional(Ty),
    /// Named field (e.g. `width :: Float` in `Rectangle(width :: Float, height :: Float)`).
    Named(String, Ty),
}

/// Registry for struct definitions, type aliases, and sum type definitions.
///
/// This is the central store of all type definitions in a Mesh program.
/// Codegen uses this to determine memory layouts for structs and ADTs.
#[derive(Clone, Debug, Default)]
pub struct TypeRegistry {
    /// Registered struct definitions, keyed by struct name.
    pub struct_defs: FxHashMap<String, StructDefInfo>,
    /// Registered type aliases, keyed by alias name.
    pub type_aliases: FxHashMap<String, TypeAliasInfo>,
    /// Registered sum type definitions, keyed by sum type name.
    pub sum_type_defs: FxHashMap<String, SumTypeDefInfo>,
    indexed_type_qualifiers: FxHashMap<String, (String, String)>,
    proof_predicates: crate::proof_values::ProofPredicates,
    /// Nominal types whose values have affine resource ownership.
    pub resource_types: FxHashSet<String>,
    /// Structs and sum types that hold a `Plaintext` value, directly or
    /// through another such type: plaintext themselves (see `plaintext.rs`).
    pub plaintext_types: FxHashSet<String>,
}

impl TypeRegistry {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn register_struct(&mut self, info: StructDefInfo) {
        self.struct_defs.insert(info.name.clone(), info);
    }

    pub fn register_alias(&mut self, info: TypeAliasInfo) {
        self.type_aliases.insert(info.name.clone(), info);
    }

    pub fn register_sum_type(&mut self, info: SumTypeDefInfo) {
        self.sum_type_defs.insert(info.name.clone(), info);
    }

    /// Recursively erase compile-time indices at the runtime lowering boundary.
    pub fn runtime_type(&self, ty: &Ty) -> Ty {
        match ty {
            proof if proof.is_proof() => Ty::Tuple(Vec::new()),
            Ty::Con(con) if con.indexed_origin.is_some() => Ty::Con(TyCon::new(&con.name)),
            Ty::App(con, args) if con.con().is_some_and(|con| con.indexed_origin.is_some()) => {
                let indexed = con
                    .con()
                    .and_then(|con| self.indexed_family(con))
                    .and_then(|def| def.indexed.as_ref());
                Ty::App(
                    Box::new(self.runtime_type(con)),
                    args.iter()
                        .enumerate()
                        .filter(|(position, arg)| {
                            !indexed.map_or(matches!(arg, Ty::Nat(_)), |indexed| {
                                indexed.index_positions.contains(&position)
                            })
                        })
                        .map(|(_, arg)| self.runtime_type(arg))
                        .collect(),
                )
            }
            other => other.map_parts(|part| self.runtime_type(part)),
        }
    }

    pub fn register_resource_type(&mut self, name: impl Into<String>) {
        self.resource_types.insert(name.into());
    }

    pub fn is_resource_name(&self, name: &str) -> bool {
        name == "SecretBytes" || self.resource_types.contains(name)
    }

    pub fn is_resource_type(&self, ty: &Ty) -> bool {
        match ty {
            Ty::Con(con) => self.is_resource_name(&con.name),
            Ty::Fun(..) => false,
            _ => ty.parts().any(|part| self.is_resource_type(part)),
        }
    }

    /// Whether a value of `ty` is or holds `Plaintext`. A function's type
    /// says nothing of what it captured; sealing its code in is what keeps
    /// a closure local (a message cannot take code to another node).
    pub fn is_plaintext_type(&self, ty: &Ty) -> bool {
        match ty {
            Ty::Con(con) => {
                con.name == crate::ty::PLAINTEXT || self.plaintext_types.contains(&con.name)
            }
            Ty::Fun(..) => false,
            _ => ty.parts().any(|part| self.is_plaintext_type(part)),
        }
    }

    /// The structs and sum types a field of which is plaintext, until no
    /// more are found: a type holding one of them holds plaintext too.
    fn propagate_plaintext_containment(&mut self) {
        loop {
            let found: Vec<String> = self
                .struct_defs
                .iter()
                .filter(|(name, definition)| {
                    !self.plaintext_types.contains(*name)
                        && definition
                            .fields
                            .iter()
                            .any(|(_, field_ty)| self.is_plaintext_type(field_ty))
                })
                .map(|(name, _)| name.clone())
                .chain(
                    self.sum_type_defs
                        .iter()
                        .filter(|(name, definition)| {
                            !self.plaintext_types.contains(*name)
                                && definition.variants.iter().any(|variant| {
                                    variant.fields.iter().any(|field| match field {
                                        VariantFieldInfo::Positional(ty)
                                        | VariantFieldInfo::Named(_, ty) => {
                                            self.is_plaintext_type(ty)
                                        }
                                    })
                                })
                        })
                        .map(|(name, _)| name.clone()),
                )
                .collect();
            if found.is_empty() {
                break;
            }
            self.plaintext_types.extend(found);
        }
    }

    fn propagate_resource_containment(&mut self) {
        self.propagate_plaintext_containment();
        loop {
            let mut newly_affine: Vec<String> = self
                .struct_defs
                .iter()
                .filter(|(name, definition)| {
                    !self.resource_types.contains(*name)
                        && definition
                            .fields
                            .iter()
                            .any(|(_, field_ty)| self.is_resource_type(field_ty))
                })
                .map(|(name, _)| name.clone())
                .collect();
            newly_affine.extend(
                self.sum_type_defs
                    .iter()
                    .filter(|(name, definition)| {
                        !self.resource_types.contains(*name)
                            && definition.variants.iter().any(|variant| {
                                variant.fields.iter().any(|field| {
                                    let ty = match field {
                                        VariantFieldInfo::Positional(ty)
                                        | VariantFieldInfo::Named(_, ty) => ty,
                                    };
                                    self.is_resource_type(ty)
                                })
                            })
                    })
                    .map(|(name, _)| name.clone()),
            );
            if newly_affine.is_empty() {
                break;
            }
            self.resource_types.extend(newly_affine);
        }
    }

    fn lookup_struct(&self, name: &str) -> Option<&StructDefInfo> {
        self.struct_defs.get(name)
    }

    #[allow(dead_code)]
    fn lookup_alias(&self, name: &str) -> Option<&TypeAliasInfo> {
        self.type_aliases.get(name)
    }

    fn lookup_sum_type(&self, name: &str) -> Option<&SumTypeDefInfo> {
        self.sum_type_defs.get(name)
    }

    /// Look up a variant by its unqualified name (e.g. "Circle").
    /// Returns the parent sum type info and the variant info.
    fn lookup_variant(&self, variant_name: &str) -> Option<(&SumTypeDefInfo, &VariantInfo)> {
        for sum_type in self.sum_type_defs.values() {
            for variant in &sum_type.variants {
                if variant.name == variant_name {
                    return Some((sum_type, variant));
                }
            }
        }
        None
    }
}

// ── Per-function metadata for where-clause enforcement (03-04) ────────

/// The names of the type parameters a definition declares (`<A, B>`).
fn generic_param_names(node: &mesh_parser::SyntaxNode) -> Vec<String> {
    generic_entries(node)
        .filter_map(|element| match element {
            rowan::NodeOrToken::Token(token) if token.kind() == SyntaxKind::IDENT => {
                Some(token.text().to_string())
            }
            rowan::NodeOrToken::Node(node) => {
                index_param_name(mesh_parser::ast::item::IndexParam::cast(node)?)
            }
            _ => None,
        })
        .collect()
}

/// A node's range without the line breaks, spaces and comments at its ends,
/// which the lossless tree gives it: an argument on a line of its own starts
/// at the line break before it.
fn significant_range(node: &mesh_parser::SyntaxNode) -> TextRange {
    node.descendants_with_tokens()
        .filter_map(|element| element.into_token())
        .filter(|token| !token.kind().is_trivia())
        .map(|token| token.text_range())
        .reduce(|first, last| first.cover(last))
        .unwrap_or_else(|| node.text_range())
}

/// What a function's body leaves to check until all of it is inferred (see
/// `InferCtx`): the enclosing function's, set aside while a function's body
/// is inferred so that each checks its own against its own type parameters.
struct EnclosingFn {
    where_bounds: Vec<(Ty, String)>,
    rigid_params: Vec<(Ty, String)>,
    operand_traits: Vec<(Ty, String, ConstraintOrigin)>,
    pending_fields: Vec<PendingField>,
    concat_operands: Vec<(Ty, &'static str, TextRange)>,
    default_calls: Vec<(Ty, TextRange)>,
    impl_choices: Vec<ImplChoice>,
    open_decodes: Vec<(Ty, TextRange)>,
}

/// Starts inferring the body of a function with these type parameters and
/// where-clause.
fn enter_fn_body(
    ctx: &mut InferCtx,
    where_constraints: &[(String, String)],
    type_params: &FxHashMap<String, Ty>,
) -> EnclosingFn {
    let rigid_params = ctx.rigid_params.clone();
    ctx.rigid_params.extend(
        type_params
            .iter()
            .map(|(name, ty)| (ty.clone(), name.clone())),
    );
    EnclosingFn {
        where_bounds: std::mem::replace(
            &mut ctx.where_bounds,
            where_bounds(where_constraints, type_params),
        ),
        rigid_params,
        operand_traits: std::mem::take(&mut ctx.operand_traits),
        pending_fields: std::mem::take(&mut ctx.pending_fields),
        concat_operands: std::mem::take(&mut ctx.concat_operands),
        default_calls: std::mem::take(&mut ctx.default_calls),
        impl_choices: std::mem::take(&mut ctx.impl_choices),
        open_decodes: std::mem::take(&mut ctx.open_decodes),
    }
}

/// Finishes the body of `def` (the first clause of a multi-clause
/// function): checks what the body left to check, records under `env_key`
/// what it requires of the arguments of parameters whose type is still open
/// (an operator's trait, being joinable) for calls to check, and restores
/// the enclosing function's. Returns the body's generic decodes, which need
/// the function's whole type (`check_open_decodes`).
#[allow(clippy::too_many_arguments)]
fn finish_fn_body(
    ctx: &mut InferCtx,
    enclosing: EnclosingFn,
    def: &FnDef,
    where_constraints: &[(String, String)],
    type_params: &FxHashMap<String, Ty>,
    param_types: &[Ty],
    env_key: &str,
    fn_constraints: &mut FxHashMap<String, FnConstraints>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
) -> Vec<(Ty, TextRange)> {
    ctx.where_bounds = enclosing.where_bounds;
    let open_decodes = std::mem::replace(&mut ctx.open_decodes, enclosing.open_decodes);
    let operand_traits = std::mem::replace(&mut ctx.operand_traits, enclosing.operand_traits);
    let default_calls = std::mem::replace(&mut ctx.default_calls, enclosing.default_calls);
    let impl_choices = std::mem::replace(&mut ctx.impl_choices, enclosing.impl_choices);
    let pending_fields = std::mem::replace(&mut ctx.pending_fields, enclosing.pending_fields);
    let unresolved = resolve_pending_fields(ctx, type_registry, pending_fields, false);
    ctx.pending_fields.extend(unresolved);
    let concat = std::mem::replace(&mut ctx.concat_operands, enclosing.concat_operands);
    let unresolved_concat = check_concat_operands(ctx, concat, type_params);
    let inferred_bounds = check_type_param_bounds(
        ctx,
        type_params,
        where_constraints,
        trait_registry,
        operand_traits,
    );
    let param_of = |ctx: &mut InferCtx, ty: &Ty| {
        let ty = ctx.resolve(ty.clone());
        (0..param_types.len()).find(|&i| ctx.resolve(param_types[i].clone()) == ty)
    };
    let mut inferred = Vec::new();
    for (ty, trait_name) in inferred_bounds {
        if let Some(index) = param_of(ctx, &ty) {
            inferred.push((index, trait_name));
        }
    }
    let mut concat_params = Vec::new();
    for (ty, op, _) in &unresolved_concat {
        if let Some(index) = param_of(ctx, ty) {
            concat_params.push((index, *op));
        }
    }
    ctx.concat_operands.extend(unresolved_concat);
    if !inferred.is_empty() || !concat_params.is_empty() {
        let entry = fn_constraints
            .entry(env_key.to_string())
            .or_insert_with(|| FnConstraints {
                where_constraints: Vec::new(),
                param_type_param_names: vec![None; param_types.len()],
                inferred_bounds: Vec::new(),
                concat_params: Vec::new(),
            });
        entry.inferred_bounds.extend(inferred);
        entry.concat_params.extend(concat_params);
    }
    check_rigid_type_params(ctx, def, type_params);
    check_default_calls(ctx, type_params, trait_registry, default_calls);
    check_impl_choices(ctx, impl_choices);
    ctx.rigid_params = enclosing.rigid_params;
    open_decodes
}

/// What the Eq, Ord, Display and Debug `type_name` derives need of its
/// fields (`fields`: name, type, where): each field's type must have the
/// trait (to show one, Display or Debug), since the derived function
/// compares or shows it (checked by `check_derive_needs`).
/// A field whose type names a type parameter is its instantiations' to have
/// it. Deriving everything by default is Eq, Ord and Debug (and Hash, which
/// any field has).
fn record_derive_needs(
    ctx: &mut InferCtx,
    type_name: &str,
    generic_params: &[String],
    derive_list: &[String],
    derive_all: bool,
    fields: impl IntoIterator<Item = (String, Ty, TextRange)>,
) {
    let traits: Vec<(&str, bool)> = ["Eq", "Ord", "Display", "Debug"]
        .into_iter()
        .filter_map(|t| {
            let explicit = derive_list.iter().any(|d| d == t);
            (explicit || (derive_all && t != "Display")).then_some((t, explicit))
        })
        .collect();
    for (field, field_ty, span) in fields {
        let mut named = Vec::new();
        type_constructors(&field_ty, &mut named);
        if named.iter().any(|name| generic_params.contains(name)) {
            continue;
        }
        for (trait_name, explicit) in &traits {
            ctx.derive_needs.push(DeriveNeed {
                type_name: type_name.to_string(),
                trait_name: trait_name.to_string(),
                explicit: *explicit,
                field: field.clone(),
                field_ty: field_ty.clone(),
                span,
            });
        }
    }
}

/// Whether each derived trait's fields have it, once every type and impl
/// is registered: one derived by default whose field lacks it is taken
/// back, and so, in turn, is one of a type holding that type; then a derive
/// the deriving list names whose field lacks it is an error. Its derived
/// function called the field's missing one and failed to build.
fn check_derive_needs(ctx: &mut InferCtx, trait_registry: &mut TraitRegistry) {
    let (explicit, mut by_default): (Vec<DeriveNeed>, Vec<DeriveNeed>) =
        std::mem::take(&mut ctx.derive_needs)
            .into_iter()
            .partition(|need| need.explicit);
    let has = |registry: &TraitRegistry, need: &DeriveNeed| match need.trait_name.as_str() {
        "Display" | "Debug" => registry.can_show(&need.field_ty),
        trait_name => registry.has_impl(trait_name, &need.field_ty),
    };
    while let Some(index) = by_default
        .iter()
        .position(|need| !has(trait_registry, need))
    {
        let need = by_default.swap_remove(index);
        trait_registry.remove_impl(&need.trait_name, &need.type_name);
        by_default.retain(|other| {
            (&other.trait_name, &other.type_name) != (&need.trait_name, &need.type_name)
        });
    }
    for need in explicit {
        if !has(trait_registry, &need) {
            ctx.errors.push(TypeError::UnderivableFieldType {
                trait_name: need.trait_name,
                type_name: need.type_name,
                field_name: need.field,
                field_ty: need.field_ty,
                span: need.span,
            });
        }
    }
}

/// The type variables in `ty`.
fn type_vars(ty: &Ty, out: &mut Vec<TyVar>) {
    match ty {
        Ty::Var(var) => out.push(*var),
        _ => ty.parts().for_each(|part| type_vars(part, out)),
    }
}

/// A generic type's `from_json` decodes the instantiation its result is
/// used at; one its function leaves open is decoded at the instantiation
/// each caller gives, when its type (`signature`) holds it. Any other open
/// type nothing can fix: it failed at run time, "cannot decode ?9 from
/// JSON".
fn check_open_decodes(ctx: &mut InferCtx, decodes: Vec<(Ty, TextRange)>, signature: &Ty) {
    let mut fixed_by_callers = Vec::new();
    type_vars(&ctx.resolve(signature.clone()), &mut fixed_by_callers);
    for (ty, span) in decodes {
        let decoded = ctx.resolve(ty);
        let mut open = Vec::new();
        type_vars(&decoded, &mut open);
        if open.iter().any(|var| !fixed_by_callers.contains(var)) {
            ctx.errors.push(TypeError::DecodeTypeUnknown {
                ty: decoded.with_holes(),
                span,
            });
        }
    }
}

/// What a function requires of its arguments beyond their types (its
/// where-clause, the traits its body needs of parameters it leaves open,
/// being joinable), required of `params`: a call's argument types, or the
/// parameter types of the function used as a value. Checked once the
/// enclosing function is done, or handed on to its own callers when a type
/// is open there too. `span` is the call's, or the function value's.
fn require_constraints(
    ctx: &mut InferCtx,
    constraints: &FnConstraints,
    params: &[Ty],
    span: TextRange,
) {
    let origin = ConstraintOrigin::FnArg {
        call_site: span,
        param_idx: 0,
    };
    for (index, trait_name) in &constraints.inferred_bounds {
        if let Some(param) = params.get(*index) {
            ctx.operand_traits
                .push((param.clone(), trait_name.clone(), origin.clone()));
        }
    }
    for (type_param, trait_name) in &constraints.where_constraints {
        for (param, name) in params.iter().zip(&constraints.param_type_param_names) {
            if name.as_ref() == Some(type_param) {
                ctx.operand_traits
                    .push((param.clone(), trait_name.clone(), origin.clone()));
            }
        }
    }
    for (index, op) in &constraints.concat_params {
        if let Some(param) = params.get(*index) {
            let param = ctx.resolve(param.clone());
            ctx.concat_operands.push((param, op, span));
        }
    }
}

/// The name `fn_constraints` keeps a function's requirements under: its
/// own, its arity's (`name__N`) for an overloaded one the call at
/// `call_range` resolved, `Module.name` for an imported module's. `None`
/// for a local variable, which is no such function.
fn constraints_key(
    ctx: &InferCtx,
    env: &TypeEnv,
    callee: &Expr,
    call_range: TextRange,
) -> Option<String> {
    let resolved = |name: String| {
        ctx.overloaded_call_targets
            .get(&call_range)
            .cloned()
            .unwrap_or(name)
    };
    match callee {
        Expr::NameRef(name_ref) => {
            let name = name_ref.text()?;
            (!env.is_local(&name)).then(|| resolved(name))
        }
        Expr::FieldAccess(fa) => {
            let Some(Expr::NameRef(module)) = fa.base() else {
                return None;
            };
            Some(format!(
                "{}.{}",
                module.text()?,
                resolved(fa.field()?.text().to_string())
            ))
        }
        _ => None,
    }
}

/// Whether `expr` is what a call calls: `f` in `f(x)` and `x |> f`. A
/// call checks its callee's requirements against its arguments
/// (`check_call`); a function used any other way is a value.
fn is_called(expr: &Expr) -> bool {
    let called = expr
        .syntax()
        .parent()
        .and_then(|parent| match parent.kind() {
            SyntaxKind::CALL_EXPR => CallExpr::cast(parent).and_then(|call| call.callee()),
            SyntaxKind::PIPE_EXPR => PipeExpr::cast(parent).and_then(|pipe| pipe.rhs()),
            SyntaxKind::SLOT_PIPE_EXPR => SlotPipeExpr::cast(parent).and_then(|pipe| pipe.rhs()),
            _ => None,
        });
    called.is_some_and(|called| called.syntax() == expr.syntax())
}

/// What a function requires of a call's arguments beyond their types (see
/// `check_call`): exported with its scheme, for calls from other modules.
#[derive(Clone, Debug)]
pub struct FnConstraints {
    /// Where-clause constraints: (type_param_name, trait_name).
    where_constraints: Vec<(String, String)>,
    /// For each function parameter (by index), the type parameter name it
    /// was annotated with (if any). Used to resolve type params from call-site
    /// argument types after instantiation + unification.
    param_type_param_names: Vec<Option<String>>,
    /// Traits the body needs of a parameter whose type is inferred, not
    /// declared (`fn add(a, b) do a + b end` needs Add of both): by
    /// parameter index. Each call hands them on to its arguments.
    inferred_bounds: Vec<(usize, String)>,
    /// Parameters, by index, that the body joins with `<>` or `++`.
    concat_params: Vec<(usize, &'static str)>,
}

// ── Standard Library Module Resolution (Phase 8) ──────────────────────

use std::collections::HashMap;

fn wide_integer_module(ty: Ty) -> HashMap<String, Scheme> {
    let result = || Ty::result(ty.clone(), Ty::string());
    let mut module = HashMap::new();
    module.insert(
        "parse".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::string()], result())),
    );
    module.insert(
        "compare".to_string(),
        Scheme::mono(Ty::fun(vec![ty.clone(), ty.clone()], Ty::int())),
    );
    for operation in ["add", "subtract", "multiply", "divide"] {
        module.insert(
            operation.to_string(),
            Scheme::mono(Ty::fun(vec![ty.clone(), ty.clone()], result())),
        );
    }
    module.insert(
        "to_int".to_string(),
        Scheme::mono(Ty::fun(
            vec![ty.clone()],
            Ty::result(Ty::int(), Ty::string()),
        )),
    );
    module.insert(
        "to_string".to_string(),
        Scheme::mono(Ty::fun(vec![ty], Ty::string())),
    );
    module
}

type StdlibModules = HashMap<String, HashMap<String, Scheme>>;

/// The stdlib module namespace registry, built once per thread. Every
/// `String.length(x)` looks its function up here, and building the
/// registry costs about as much as checking a small module.
/// The standard-library module whose functions are methods of values of
/// type `ty`: `"hello".length()` is `String.length("hello")`.
pub fn method_module(ty: &Ty) -> Option<&'static str> {
    // A `List` with no element type is the untyped one, with no methods.
    let modules: &[&'static str] = match ty {
        Ty::Con(_) => &["String", "Int", "Float", "Bytes", "Range"],
        _ => &["List", "Map", "Set", "Queue", "Iter", "Option", "Result"],
    };
    let name = ty.con_name()?;
    modules.iter().copied().find(|module| *module == name)
}

/// Whether `name` is a standard-library module (`String`, `IO`, ...).
pub(crate) fn is_stdlib_module(name: &str) -> bool {
    stdlib_modules(true).contains_key(name)
}

fn stdlib_modules(test_builtins: bool) -> std::rc::Rc<StdlibModules> {
    thread_local! {
        static MODULES: std::cell::RefCell<[Option<std::rc::Rc<StdlibModules>>; 2]> =
            const { std::cell::RefCell::new([None, None]) };
    }
    MODULES.with(|modules| {
        modules.borrow_mut()[test_builtins as usize]
            .get_or_insert_with(|| std::rc::Rc::new(build_stdlib_modules(test_builtins)))
            .clone()
    })
}

/// Report each derive a type holding plaintext asks for (only `Schema`,
/// field names, is harmless); whether there was one.
fn refuse_plaintext_derives(
    ctx: &mut InferCtx,
    name: &str,
    derive_list: &[String],
    definition: &mesh_parser::SyntaxNode,
) -> bool {
    let refused: Vec<&String> = derive_list.iter().filter(|t| *t != "Schema").collect();
    for trait_name in &refused {
        ctx.errors.push(TypeError::PlaintextViolation {
            reason: format!("`{name}` holds plaintext and cannot derive `{trait_name}`"),
            span: deriving_span(definition),
        });
    }
    !refused.is_empty()
}

/// Build the stdlib module namespace registry.
///
/// Maps module names (e.g., "String", "IO", "Env") to their exported
/// function names and type schemes. This is used by both `from X import y`
/// and `X.y` resolution paths.
fn build_stdlib_modules(test_builtins: bool) -> StdlibModules {
    let mut modules: HashMap<String, HashMap<String, Scheme>> = HashMap::new();

    // ── String module ──────────────────────────────────────────────
    let mut string_mod = HashMap::new();
    string_mod.insert(
        "length".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::string()], Ty::int())),
    );
    string_mod.insert(
        "slice".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::string(), Ty::int(), Ty::int()],
            Ty::string(),
        )),
    );
    string_mod.insert(
        "contains".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::string(), Ty::string()], Ty::bool())),
    );
    string_mod.insert(
        "starts_with".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::string(), Ty::string()], Ty::bool())),
    );
    string_mod.insert(
        "ends_with".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::string(), Ty::string()], Ty::bool())),
    );
    string_mod.insert(
        "trim".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::string()], Ty::string())),
    );
    for trim in ["trim_start", "trim_end"] {
        string_mod.insert(
            trim.to_string(),
            Scheme::mono(Ty::fun(vec![Ty::string()], Ty::string())),
        );
    }
    string_mod.insert(
        "repeat".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::string(), Ty::int()], Ty::string())),
    );
    string_mod.insert(
        "to_upper".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::string()], Ty::string())),
    );
    string_mod.insert(
        "to_lower".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::string()], Ty::string())),
    );
    string_mod.insert(
        "replace".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::string(), Ty::string(), Ty::string()],
            Ty::string(),
        )),
    );
    string_mod.insert(
        "split".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::string(), Ty::string()],
            Ty::list(Ty::string()),
        )),
    );
    string_mod.insert(
        "join".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::list(Ty::string()), Ty::string()],
            Ty::string(),
        )),
    );
    string_mod.insert(
        "to_int".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::string()], Ty::option(Ty::int()))),
    );
    string_mod.insert(
        "to_float".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::string()], Ty::option(Ty::float()))),
    );
    // Phase 77: String.from(T) -> String (polymorphic -- accepts Int, Float, Bool)
    {
        let from_input_var = TyVar(91100);
        string_mod.insert(
            "from".to_string(),
            Scheme {
                vars: vec![from_input_var],
                ty: Ty::fun(vec![Ty::Var(from_input_var)], Ty::string()),
            },
        );
    }
    // Phase 79: String.collect(iter) -> String
    string_mod.insert(
        "collect".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::iter(Ty::string())], Ty::string())),
    );
    modules.insert("String".to_string(), string_mod);

    // ── IO module ──────────────────────────────────────────────────
    let mut io_mod = HashMap::new();
    io_mod.insert(
        "read_line".to_string(),
        Scheme::mono(Ty::fun(vec![], Ty::result(Ty::string(), Ty::string()))),
    );
    io_mod.insert(
        "eprintln".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::string()], Ty::Tuple(vec![]))),
    );
    modules.insert("IO".to_string(), io_mod);

    // ── Env module ─────────────────────────────────────────────────
    let mut env_mod = HashMap::new();
    // Env.get(key, default) -> String  (Phase 118: 2-arg API replaces old Option-returning 1-arg)
    env_mod.insert(
        "get".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::string(), Ty::string()], Ty::string())),
    );
    // Env.get_int(key, default) -> Int
    env_mod.insert(
        "get_int".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::string(), Ty::int()], Ty::int())),
    );
    env_mod.insert(
        "get_secret_hex".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::string()],
            Ty::result(Ty::secret_bytes(), Ty::crypto_error()),
        )),
    );
    // Env.args() -> List<String>
    env_mod.insert(
        "args".to_string(),
        Scheme::mono(Ty::fun(vec![], Ty::list(Ty::string()))),
    );
    modules.insert("Env".to_string(), env_mod);

    // ── Regex module (Phase 119) ─────────────────────────────────────
    let mut regex_mod = HashMap::new();
    // Regex.compile(pattern) -> Result<Regex, String>
    regex_mod.insert(
        "compile".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::string()],
            Ty::result(Ty::Con(TyCon::new("Regex")), Ty::string()),
        )),
    );
    // Regex.is_match(rx, str) -> Bool
    regex_mod.insert(
        "is_match".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::Con(TyCon::new("Regex")), Ty::string()],
            Ty::bool(),
        )),
    );
    // Regex.captures(rx, str) -> Option<List<String>>
    regex_mod.insert(
        "captures".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::Con(TyCon::new("Regex")), Ty::string()],
            Ty::option(Ty::list(Ty::string())),
        )),
    );
    // Regex.replace(rx, str, replacement) -> String
    regex_mod.insert(
        "replace".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::Con(TyCon::new("Regex")), Ty::string(), Ty::string()],
            Ty::string(),
        )),
    );
    // Regex.split(rx, str) -> List<String>
    regex_mod.insert(
        "split".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::Con(TyCon::new("Regex")), Ty::string()],
            Ty::list(Ty::string()),
        )),
    );
    modules.insert("Regex".to_string(), regex_mod);

    // ── Bytes module ──────────────────────────────────────────────────
    let bytes_t = Ty::bytes();
    let bytes_result = || Ty::result(Ty::bytes(), Ty::string());
    let checked_bytes_result = || Ty::result(Ty::bytes(), Ty::bytes_error());
    let mut bytes_mod = HashMap::new();
    bytes_mod.insert(
        "empty".to_string(),
        Scheme::mono(Ty::fun(vec![], bytes_t.clone())),
    );
    bytes_mod.insert(
        "from_list".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::list(Ty::int())], checked_bytes_result())),
    );
    bytes_mod.insert(
        "to_list".to_string(),
        Scheme::mono(Ty::fun(vec![bytes_t.clone()], Ty::list(Ty::int()))),
    );
    bytes_mod.insert(
        "repeat".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::int(), Ty::int()], checked_bytes_result())),
    );
    bytes_mod.insert(
        "length".to_string(),
        Scheme::mono(Ty::fun(vec![bytes_t.clone()], Ty::int())),
    );
    bytes_mod.insert(
        "get".to_string(),
        Scheme::mono(Ty::fun(
            vec![bytes_t.clone(), Ty::int()],
            Ty::result(Ty::int(), Ty::string()),
        )),
    );
    bytes_mod.insert(
        "slice".to_string(),
        Scheme::mono(Ty::fun(
            vec![bytes_t.clone(), Ty::int(), Ty::int()],
            bytes_result(),
        )),
    );
    bytes_mod.insert(
        "concat".to_string(),
        Scheme::mono(Ty::fun(
            vec![bytes_t.clone(), bytes_t.clone()],
            bytes_result(),
        )),
    );
    bytes_mod.insert(
        "secure_equals".to_string(),
        Scheme::mono(Ty::fun(vec![bytes_t.clone(), bytes_t.clone()], Ty::bool())),
    );
    bytes_mod.insert(
        "from_utf8".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::string()], bytes_t.clone())),
    );
    bytes_mod.insert(
        "to_utf8".to_string(),
        Scheme::mono(Ty::fun(
            vec![bytes_t.clone()],
            Ty::result(Ty::string(), Ty::string()),
        )),
    );
    for name in ["to_base64", "to_base58", "to_hex"] {
        bytes_mod.insert(
            name.to_string(),
            Scheme::mono(Ty::fun(vec![bytes_t.clone()], Ty::string())),
        );
    }
    for name in ["from_base64", "from_base58", "from_hex"] {
        bytes_mod.insert(
            name.to_string(),
            Scheme::mono(Ty::fun(vec![Ty::string()], bytes_result())),
        );
    }
    bytes_mod.insert(
        "read_uint_le".to_string(),
        Scheme::mono(Ty::fun(
            vec![bytes_t.clone(), Ty::int(), Ty::int()],
            Ty::result(Ty::string(), Ty::string()),
        )),
    );
    bytes_mod.insert(
        "write_uint_le".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::string(), Ty::int()], bytes_result())),
    );
    for name in ["read_u16_be", "read_u16_le"] {
        bytes_mod.insert(
            name.to_string(),
            Scheme::mono(Ty::fun(
                vec![bytes_t.clone(), Ty::int()],
                Ty::result(Ty::int(), Ty::bytes_error()),
            )),
        );
    }
    for name in ["read_u32_be", "read_u32_le", "read_u64_be", "read_u64_le"] {
        bytes_mod.insert(
            name.to_string(),
            Scheme::mono(Ty::fun(
                vec![bytes_t.clone(), Ty::int()],
                Ty::result(Ty::u64(), Ty::bytes_error()),
            )),
        );
    }
    bytes_mod.insert(
        "write_u16_be".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::int()], checked_bytes_result())),
    );
    for name in ["write_u32_be", "write_u64_be"] {
        bytes_mod.insert(
            name.to_string(),
            Scheme::mono(Ty::fun(vec![Ty::u64()], checked_bytes_result())),
        );
    }
    modules.insert("Bytes".to_string(), bytes_mod);

    let mut host_mod = HashMap::new();
    for name in [
        "secure_store_put",
        "secure_store_get",
        "secure_store_delete",
        "push_get_token",
        "background_schedule",
        "network_state",
        "monotonic_clock",
        "wall_clock",
        "log_redacted",
    ] {
        host_mod.insert(
            name.to_string(),
            Scheme::mono(Ty::fun(vec![Ty::bytes()], bytes_result())),
        );
    }
    modules.insert("Host".to_string(), host_mod);

    let bytes_builder = Ty::bytes_builder();
    let builder_result = |value| Ty::result(value, Ty::binary_error());
    let mut builder_mod = HashMap::new();
    builder_mod.insert(
        "new".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::int()],
            builder_result(bytes_builder.clone()),
        )),
    );
    for name in ["write_u8", "write_u16_be", "write_u32_be"] {
        builder_mod.insert(
            name.to_string(),
            Scheme::mono(Ty::fun(
                vec![bytes_builder.clone(), Ty::int()],
                builder_result(Ty::Tuple(vec![])),
            )),
        );
    }
    builder_mod.insert(
        "write_bytes".to_string(),
        Scheme::mono(Ty::fun(
            vec![bytes_builder.clone(), Ty::bytes()],
            builder_result(Ty::Tuple(vec![])),
        )),
    );
    builder_mod.insert(
        "finish".to_string(),
        Scheme::mono(Ty::fun(vec![bytes_builder], builder_result(Ty::bytes()))),
    );
    modules.insert("BytesBuilder".to_string(), builder_mod);

    let mut secret_mod = HashMap::new();
    secret_mod.insert(
        "random".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::int()],
            Ty::result(Ty::secret_bytes(), Ty::crypto_error()),
        )),
    );
    secret_mod.insert(
        "destroy".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::secret_bytes()], Ty::Tuple(vec![]))),
    );
    secret_mod.insert(
        "from_bytes".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::bytes()],
            Ty::result(Ty::secret_bytes(), Ty::crypto_error()),
        )),
    );
    secret_mod.insert(
        "concat".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::secret_bytes(), Ty::secret_bytes()],
            Ty::result(Ty::secret_bytes(), Ty::crypto_error()),
        )),
    );
    secret_mod.insert(
        "seal_for_storage".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::secret_bytes(), Ty::storage_key(), Ty::bytes()],
            Ty::result(Ty::bytes(), Ty::crypto_error()),
        )),
    );
    secret_mod.insert(
        "unseal_from_storage".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::bytes(), Ty::storage_key(), Ty::bytes()],
            Ty::result(Ty::secret_bytes(), Ty::crypto_error()),
        )),
    );
    modules.insert("Secret".to_string(), secret_mod);

    let secret_map = Ty::secret_map();
    let secret_map_result = |value| Ty::result(value, Ty::crypto_error());
    let mut secret_map_mod = HashMap::new();
    secret_map_mod.insert(
        "new".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::int()],
            secret_map_result(secret_map.clone()),
        )),
    );
    secret_map_mod.insert(
        "fork".to_string(),
        Scheme::mono(Ty::fun(
            vec![secret_map.clone()],
            secret_map_result(secret_map.clone()),
        )),
    );
    secret_map_mod.insert(
        "insert".to_string(),
        Scheme::mono(Ty::fun(
            vec![secret_map.clone(), Ty::bytes(), Ty::secret_bytes()],
            secret_map_result(Ty::Tuple(vec![])),
        )),
    );
    secret_map_mod.insert(
        "contains".to_string(),
        Scheme::mono(Ty::fun(vec![secret_map.clone(), Ty::bytes()], Ty::bool())),
    );
    secret_map_mod.insert(
        "copy".to_string(),
        Scheme::mono(Ty::fun(
            vec![secret_map.clone(), Ty::bytes()],
            secret_map_result(Ty::secret_bytes()),
        )),
    );
    secret_map_mod.insert(
        "delete".to_string(),
        Scheme::mono(Ty::fun(
            vec![secret_map.clone(), Ty::bytes()],
            secret_map_result(Ty::Tuple(vec![])),
        )),
    );
    secret_map_mod.insert(
        "merge".to_string(),
        Scheme::mono(Ty::fun(
            vec![secret_map.clone(), secret_map.clone()],
            secret_map_result(Ty::Tuple(vec![])),
        )),
    );
    secret_map_mod.insert(
        "seal_for_storage".to_string(),
        Scheme::mono(Ty::fun(
            vec![secret_map.clone(), Ty::storage_key(), Ty::bytes()],
            secret_map_result(Ty::bytes()),
        )),
    );
    secret_map_mod.insert(
        "unseal_from_storage".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::bytes(), Ty::storage_key(), Ty::bytes()],
            secret_map_result(secret_map.clone()),
        )),
    );
    modules.insert("SecretMap".to_string(), secret_map_mod);

    let mut storage_key_mod = HashMap::new();
    storage_key_mod.insert(
        "ephemeral".to_string(),
        Scheme::mono(Ty::fun(
            vec![],
            Ty::result(Ty::storage_key(), Ty::crypto_error()),
        )),
    );
    storage_key_mod.insert(
        "platform".to_string(),
        Scheme::mono(Ty::fun(
            vec![],
            Ty::result(Ty::storage_key(), Ty::crypto_error()),
        )),
    );
    storage_key_mod.insert(
        "from_secret".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::secret_bytes(), Ty::bytes()],
            Ty::result(Ty::storage_key(), Ty::crypto_error()),
        )),
    );
    for name in ["seal_bytes", "unseal_bytes"] {
        storage_key_mod.insert(
            name.to_string(),
            Scheme::mono(Ty::fun(
                vec![Ty::bytes(), Ty::storage_key(), Ty::bytes()],
                Ty::result(Ty::bytes(), Ty::crypto_error()),
            )),
        );
    }
    modules.insert("StorageKey".to_string(), storage_key_mod);

    // ── Plaintext module ──────────────────────────────────────────────
    // `Plaintext<T>` is message content. `from` labels a value, `map` and
    // `map2` compute on content with a function that has no exits (checked
    // in `plaintext.rs`), and the storage seal is one of its exits.
    let (a, b, c) = (
        TyVar(u32::MAX - 40),
        TyVar(u32::MAX - 41),
        TyVar(u32::MAX - 42),
    );
    let labeled = |var: TyVar| Ty::plaintext(Ty::Var(var));
    let mut plaintext_mod = HashMap::new();
    plaintext_mod.insert(
        "from".to_string(),
        Scheme {
            vars: vec![a],
            ty: Ty::fun(vec![Ty::Var(a)], labeled(a)),
        },
    );
    plaintext_mod.insert(
        "map".to_string(),
        Scheme {
            vars: vec![a, b],
            ty: Ty::fun(
                vec![labeled(a), Ty::fun(vec![Ty::Var(a)], Ty::Var(b))],
                labeled(b),
            ),
        },
    );
    plaintext_mod.insert(
        "map2".to_string(),
        Scheme {
            vars: vec![a, b, c],
            ty: Ty::fun(
                vec![
                    labeled(a),
                    labeled(b),
                    Ty::fun(vec![Ty::Var(a), Ty::Var(b)], Ty::Var(c)),
                ],
                labeled(c),
            ),
        },
    );
    plaintext_mod.insert(
        "seal_for_storage".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::plaintext(Ty::bytes()), Ty::storage_key(), Ty::bytes()],
            Ty::result(Ty::bytes(), Ty::crypto_error()),
        )),
    );
    plaintext_mod.insert(
        "unseal_from_storage".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::bytes(), Ty::storage_key(), Ty::bytes()],
            Ty::result(Ty::plaintext(Ty::bytes()), Ty::crypto_error()),
        )),
    );
    modules.insert(crate::ty::PLAINTEXT.to_string(), plaintext_mod);

    for (module, private_key) in [
        ("X25519PrivateKey", Ty::x25519_private_key()),
        ("SigningPrivateKey", Ty::signing_private_key()),
        ("MlKemPrivateKey", Ty::mlkem_private_key()),
        ("BlindRsaSecretKey", Ty::blind_rsa_secret_key()),
    ] {
        let mut private_mod = HashMap::new();
        private_mod.insert(
            "seal_for_storage".to_string(),
            Scheme::mono(Ty::fun(
                vec![private_key.clone(), Ty::storage_key(), Ty::bytes()],
                Ty::result(Ty::bytes(), Ty::crypto_error()),
            )),
        );
        private_mod.insert(
            "unseal_from_storage".to_string(),
            Scheme::mono(Ty::fun(
                vec![Ty::bytes(), Ty::storage_key(), Ty::bytes()],
                Ty::result(private_key, Ty::crypto_error()),
            )),
        );
        modules.insert(module.to_string(), private_mod);
    }

    modules.insert("U64".to_string(), wide_integer_module(Ty::u64()));
    modules.insert("U128".to_string(), wide_integer_module(Ty::u128()));
    modules.insert("I128".to_string(), wide_integer_module(Ty::i128()));

    // ── Crypto V2 module ──────────────────────────────────────────────
    let crypto_mod = builtins::crypto_functions()
        .into_iter()
        .map(|(name, scheme)| (name.to_string(), scheme))
        .collect();
    modules.insert("Crypto".to_string(), crypto_mod);

    // ── Base64 module (Phase 135) ─────────────────────────────────────
    let mut base64_mod = HashMap::new();
    // Base64.encode(s) -> String
    base64_mod.insert(
        "encode".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::string()], Ty::string())),
    );
    // Base64.decode(s) -> Result<String, String>
    base64_mod.insert(
        "decode".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::string()],
            Ty::result(Ty::string(), Ty::string()),
        )),
    );
    // Base64.encode_url(s) -> String
    base64_mod.insert(
        "encode_url".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::string()], Ty::string())),
    );
    // Base64.decode_url(s) -> Result<String, String>
    base64_mod.insert(
        "decode_url".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::string()],
            Ty::result(Ty::string(), Ty::string()),
        )),
    );
    modules.insert("Base64".to_string(), base64_mod);

    // ── Hex module (Phase 135) ────────────────────────────────────────
    let mut hex_mod = HashMap::new();
    // Hex.encode(s) -> String
    hex_mod.insert(
        "encode".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::string()], Ty::string())),
    );
    // Hex.decode(s) -> Result<String, String>
    hex_mod.insert(
        "decode".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::string()],
            Ty::result(Ty::string(), Ty::string()),
        )),
    );
    modules.insert("Hex".to_string(), hex_mod);

    // ── DateTime module (Phase 136) ───────────────────────────────────────
    let dt_t = Ty::Con(TyCon::new("DateTime"));
    let mut datetime_mod = HashMap::new();

    datetime_mod.insert(
        "utc_now".to_string(),
        Scheme::mono(Ty::fun(vec![], dt_t.clone())),
    );
    datetime_mod.insert(
        "from_iso8601".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::string()],
            Ty::result(dt_t.clone(), Ty::string()),
        )),
    );
    datetime_mod.insert(
        "to_iso8601".to_string(),
        Scheme::mono(Ty::fun(vec![dt_t.clone()], Ty::string())),
    );
    datetime_mod.insert(
        "from_unix_ms".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::int()],
            Ty::result(dt_t.clone(), Ty::string()),
        )),
    );
    datetime_mod.insert(
        "to_unix_ms".to_string(),
        Scheme::mono(Ty::fun(vec![dt_t.clone()], Ty::int())),
    );
    datetime_mod.insert(
        "from_unix_secs".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::int()],
            Ty::result(dt_t.clone(), Ty::string()),
        )),
    );
    datetime_mod.insert(
        "to_unix_secs".to_string(),
        Scheme::mono(Ty::fun(vec![dt_t.clone()], Ty::int())),
    );
    // The unit parameter uses Atom type (e.g. :day, :hour) — Atom resolves to String at MIR level.
    let atom_t = Ty::Con(TyCon::new("Atom"));
    datetime_mod.insert(
        "add".to_string(),
        Scheme::mono(Ty::fun(
            vec![dt_t.clone(), Ty::int(), atom_t.clone()],
            dt_t.clone(),
        )),
    );
    datetime_mod.insert(
        "diff".to_string(),
        Scheme::mono(Ty::fun(
            vec![dt_t.clone(), dt_t.clone(), atom_t],
            Ty::float(),
        )),
    );
    datetime_mod.insert(
        "is_before".to_string(),
        Scheme::mono(Ty::fun(vec![dt_t.clone(), dt_t.clone()], Ty::bool())),
    );
    datetime_mod.insert(
        "is_after".to_string(),
        Scheme::mono(Ty::fun(vec![dt_t.clone(), dt_t.clone()], Ty::bool())),
    );

    modules.insert("DateTime".to_string(), datetime_mod);

    let mut checked_mod = HashMap::new();
    let checked_result = Ty::result(Ty::int(), Ty::string());
    for name in ["add", "sub", "mul", "div"] {
        checked_mod.insert(
            name.to_string(),
            Scheme::mono(Ty::fun(vec![Ty::int(), Ty::int()], checked_result.clone())),
        );
    }
    checked_mod.insert(
        "abs".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::int()], checked_result.clone())),
    );
    for name in ["mul_div", "rescale"] {
        checked_mod.insert(
            name.to_string(),
            Scheme::mono(Ty::fun(
                vec![Ty::int(), Ty::int(), Ty::int(), Ty::Con(TyCon::new("Atom"))],
                checked_result.clone(),
            )),
        );
    }
    modules.insert("Checked".to_string(), checked_mod);

    let mut monotonic_mod = HashMap::new();
    monotonic_mod.insert(
        "now_nanos".to_string(),
        Scheme::mono(Ty::fun(vec![], Ty::int())),
    );
    monotonic_mod.insert(
        "elapsed".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::int(), Ty::int()],
            Ty::result(Ty::int(), Ty::string()),
        )),
    );
    modules.insert("Monotonic".to_string(), monotonic_mod);

    let mut duration_mod = HashMap::new();
    for name in ["millis", "seconds"] {
        duration_mod.insert(
            name.to_string(),
            Scheme::mono(Ty::fun(
                vec![Ty::int()],
                Ty::result(Ty::int(), Ty::string()),
            )),
        );
    }
    modules.insert("Duration".to_string(), duration_mod);

    let channel_mod: HashMap<String, Scheme> = crate::builtins::channel_functions()
        .into_iter()
        .map(|(name, scheme)| (name.to_string(), scheme))
        .collect();
    modules.insert("Channel".to_string(), channel_mod);

    let mut random_mod = HashMap::new();
    random_mod.insert(
        "seed".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::int()], Ty::int())),
    );
    random_mod.insert(
        "next_int".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::int(), Ty::int(), Ty::int()],
            Ty::Tuple(vec![Ty::int(), Ty::int()]),
        )),
    );
    random_mod.insert(
        "next_unit_ppm".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::int()],
            Ty::Tuple(vec![Ty::int(), Ty::int()]),
        )),
    );
    modules.insert("Random".to_string(), random_mod);

    // ── Http client module (Phase 137) ───────────────────────────────────────
    let http_req_t = Ty::int(); // opaque handle — u64 ABI as Int
    let http_resp_t = Ty::Con(TyCon::new("HttpResponse"));
    // Atom type for HTTP method (e.g. :get, :post) — lowered to String at MIR level.
    let http_method_atom_t = Ty::Con(TyCon::new("Atom"));
    let mut http_client_mod = HashMap::new();

    // Http.build(:method, url) -> Request
    // First arg is Atom — atoms are lowered to String at MIR/codegen level.
    http_client_mod.insert(
        "build".to_string(),
        Scheme::mono(Ty::fun(
            vec![http_method_atom_t, Ty::string()],
            http_req_t.clone(),
        )),
    );
    http_client_mod.insert(
        "header".to_string(),
        Scheme::mono(Ty::fun(
            vec![http_req_t.clone(), Ty::string(), Ty::string()],
            http_req_t.clone(),
        )),
    );
    http_client_mod.insert(
        "body".to_string(),
        Scheme::mono(Ty::fun(
            vec![http_req_t.clone(), Ty::string()],
            http_req_t.clone(),
        )),
    );
    http_client_mod.insert(
        "body_bytes".to_string(),
        Scheme::mono(Ty::fun(
            vec![http_req_t.clone(), Ty::bytes()],
            http_req_t.clone(),
        )),
    );
    http_client_mod.insert(
        "timeout".to_string(),
        Scheme::mono(Ty::fun(
            vec![http_req_t.clone(), Ty::int()],
            http_req_t.clone(),
        )),
    );
    http_client_mod.insert(
        "stage_timeout".to_string(),
        Scheme::mono(Ty::fun(
            vec![http_req_t.clone(), Ty::Con(TyCon::new("Atom")), Ty::int()],
            http_req_t.clone(),
        )),
    );
    http_client_mod.insert(
        "max_redirects".to_string(),
        Scheme::mono(Ty::fun(
            vec![http_req_t.clone(), Ty::int()],
            http_req_t.clone(),
        )),
    );
    http_client_mod.insert(
        "max_response_bytes".to_string(),
        Scheme::mono(Ty::fun(
            vec![http_req_t.clone(), Ty::int()],
            http_req_t.clone(),
        )),
    );
    http_client_mod.insert(
        "query".to_string(),
        Scheme::mono(Ty::fun(
            vec![http_req_t.clone(), Ty::string(), Ty::string()],
            http_req_t.clone(),
        )),
    );
    http_client_mod.insert(
        "json".to_string(),
        Scheme::mono(Ty::fun(
            vec![http_req_t.clone(), Ty::string()],
            http_req_t.clone(),
        )),
    );
    http_client_mod.insert(
        "send".to_string(),
        Scheme::mono(Ty::fun(
            vec![http_req_t.clone()],
            Ty::result(http_resp_t.clone(), Ty::string()),
        )),
    );
    // Http.stream(req, fn(String) -> String) -> Int (cancel handle)
    // Callback receives chunk as String, returns :continue or :stop (lowered to String)
    let stream_cb_t = Ty::fun(vec![Ty::string()], Ty::string());
    http_client_mod.insert(
        "stream".to_string(),
        Scheme::mono(Ty::fun(
            vec![http_req_t.clone(), stream_cb_t.clone()],
            Ty::int(), // cancel handle
        )),
    );
    http_client_mod.insert(
        "stream_bytes".to_string(),
        Scheme::mono(Ty::fun(
            vec![http_req_t.clone(), Ty::fun(vec![Ty::bytes()], Ty::string())],
            Ty::int(), // cancel handle
        )),
    );
    // Http.cancel(cancel_handle) -> ()
    http_client_mod.insert(
        "cancel".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::int()], Ty::Tuple(vec![]))),
    );
    // Http.client() -> Int (keep-alive Agent handle)
    http_client_mod.insert(
        "client".to_string(),
        Scheme::mono(Ty::fun(vec![], Ty::int())),
    );
    // Http.send_with(client, req) -> Result<HttpResponse, String>
    http_client_mod.insert(
        "send_with".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::int(), http_req_t.clone()],
            Ty::result(http_resp_t.clone(), Ty::string()),
        )),
    );
    // Http.client_close(client) -> ()
    http_client_mod.insert(
        "client_close".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::int()], Ty::Tuple(vec![]))),
    );
    http_client_mod.insert(
        "retry_class".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::Con(TyCon::new("Atom")), Ty::string()],
            Ty::string(),
        )),
    );
    http_client_mod.insert(
        "metrics".to_string(),
        Scheme::mono(Ty::fun(vec![], Ty::Con(TyCon::new("HttpClientMetrics")))),
    );

    modules.insert("Http".to_string(), http_client_mod);

    // ── Scheduler-aware WebSocket client ────────────────────────────────
    let ws_message_t = Ty::Con(TyCon::new("WsMessage"));
    let mut ws_client_mod = HashMap::new();
    ws_client_mod.insert(
        "options".to_string(),
        Scheme::mono(Ty::fun(vec![], Ty::int())),
    );
    for name in [
        "connect_timeout",
        "heartbeat_timeout",
        "max_message_bytes",
        "queue_capacity",
    ] {
        ws_client_mod.insert(
            name.to_string(),
            Scheme::mono(Ty::fun(vec![Ty::int(), Ty::int()], Ty::int())),
        );
    }
    ws_client_mod.insert(
        "connect".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::string(), Ty::int()],
            Ty::result(Ty::int(), Ty::string()),
        )),
    );
    ws_client_mod.insert(
        "send_text".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::int(), Ty::string()],
            Ty::result(Ty::Tuple(vec![]), Ty::string()),
        )),
    );
    ws_client_mod.insert(
        "send_bytes".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::int(), Ty::bytes()],
            Ty::result(Ty::Tuple(vec![]), Ty::string()),
        )),
    );
    ws_client_mod.insert(
        "recv".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::int(), Ty::int()],
            Ty::result(ws_message_t, Ty::string()),
        )),
    );
    ws_client_mod.insert(
        "close".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::int(), Ty::int(), Ty::string()],
            Ty::result(Ty::Tuple(vec![]), Ty::string()),
        )),
    );
    ws_client_mod.insert(
        "reconnect_delay".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::int(), Ty::int(), Ty::int(), Ty::int()],
            Ty::result(Ty::int(), Ty::string()),
        )),
    );
    modules.insert("WsClient".to_string(), ws_client_mod);

    // ── Test module (Phase 138) ──────────────────────────────────────
    // assert/assert_eq/assert_ne/assert_raises are test-mode DSL builtins lowered
    // in lower.rs, not module-qualified functions. Only Test.mock_actor is a module
    // function.
    let mut test_mod: HashMap<String, Scheme> = HashMap::new();
    // Test.mock_actor(fn(msg: String) -> String) -> Pid
    // The callback receives a message (as opaque string/any) and handles it.
    // Returns an untyped Pid for the spawned mock actor.
    {
        let msg_cb_t = Ty::fun(vec![Ty::string()], Ty::string());
        let pid_t = Ty::untyped_pid();
        test_mod.insert(
            "mock_actor".to_string(),
            Scheme::mono(Ty::fun(vec![msg_cb_t], pid_t)),
        );
    }
    if test_builtins {
        test_mod.insert(
            "install_in_memory_secure_store".to_string(),
            Scheme::mono(Ty::fun(vec![], Ty::bool())),
        );
        test_mod.insert(
            "set_push_token".to_string(),
            Scheme::mono(Ty::fun(vec![Ty::bytes(), Ty::bytes()], Ty::bool())),
        );
    }
    modules.insert("Test".to_string(), test_mod);

    // ── File module ─────────────────────────────────────────────────
    let mut file_mod = HashMap::new();
    file_mod.insert(
        "read".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::string()],
            Ty::result(Ty::string(), Ty::string()),
        )),
    );
    file_mod.insert(
        "read_bytes".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::string(), Ty::int(), Ty::int()],
            Ty::result(Ty::bytes(), Ty::string()),
        )),
    );
    file_mod.insert(
        "write_bytes".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::string(), Ty::int(), Ty::bytes(), Ty::bool()],
            Ty::result(Ty::Tuple(vec![]), Ty::string()),
        )),
    );
    file_mod.insert(
        "size".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::string()],
            Ty::result(Ty::int(), Ty::string()),
        )),
    );
    file_mod.insert(
        "write".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::string(), Ty::string()],
            Ty::result(Ty::Tuple(vec![]), Ty::string()),
        )),
    );
    file_mod.insert(
        "append".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::string(), Ty::string()],
            Ty::result(Ty::Tuple(vec![]), Ty::string()),
        )),
    );
    file_mod.insert(
        "exists".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::string()], Ty::bool())),
    );
    file_mod.insert(
        "delete".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::string()],
            Ty::result(Ty::Tuple(vec![]), Ty::string()),
        )),
    );
    file_mod.insert(
        "rename".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::string(), Ty::string()],
            Ty::result(Ty::Tuple(vec![]), Ty::string()),
        )),
    );
    file_mod.insert(
        "sync".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::string()],
            Ty::result(Ty::Tuple(vec![]), Ty::string()),
        )),
    );
    modules.insert("File".to_string(), file_mod);

    // ── Collection modules (Phase 8 Plan 02) ─────────────────────────

    // List module -- polymorphic: List<T> with type variables for element type.
    let t_var = TyVar(91000);
    let u_var = TyVar(91001);
    let t = Ty::Var(t_var);
    let u = Ty::Var(u_var);
    let list_t = Ty::list(t.clone());
    let list_u = Ty::list(u.clone());
    let t_to_u = Ty::fun(vec![t.clone()], u.clone());
    let t_to_bool = Ty::fun(vec![t.clone()], Ty::bool());
    let u_t_to_u = Ty::fun(vec![u.clone(), t.clone()], u.clone());

    let mut list_mod = HashMap::new();
    list_mod.insert(
        "new".to_string(),
        Scheme {
            vars: vec![t_var],
            ty: Ty::fun(vec![], list_t.clone()),
        },
    );
    list_mod.insert(
        "length".to_string(),
        Scheme {
            vars: vec![t_var],
            ty: Ty::fun(vec![list_t.clone()], Ty::int()),
        },
    );
    list_mod.insert(
        "append".to_string(),
        Scheme {
            vars: vec![t_var],
            ty: Ty::fun(vec![list_t.clone(), t.clone()], list_t.clone()),
        },
    );
    list_mod.insert(
        "head".to_string(),
        Scheme {
            vars: vec![t_var],
            ty: Ty::fun(vec![list_t.clone()], t.clone()),
        },
    );
    list_mod.insert(
        "tail".to_string(),
        Scheme {
            vars: vec![t_var],
            ty: Ty::fun(vec![list_t.clone()], list_t.clone()),
        },
    );
    list_mod.insert(
        "get".to_string(),
        Scheme {
            vars: vec![t_var],
            ty: Ty::fun(vec![list_t.clone(), Ty::int()], t.clone()),
        },
    );
    list_mod.insert(
        "concat".to_string(),
        Scheme {
            vars: vec![t_var],
            ty: Ty::fun(vec![list_t.clone(), list_t.clone()], list_t.clone()),
        },
    );
    list_mod.insert(
        "reverse".to_string(),
        Scheme {
            vars: vec![t_var],
            ty: Ty::fun(vec![list_t.clone()], list_t.clone()),
        },
    );
    list_mod.insert(
        "map".to_string(),
        Scheme {
            vars: vec![t_var, u_var],
            ty: Ty::fun(vec![list_t.clone(), t_to_u], list_u),
        },
    );
    list_mod.insert(
        "filter".to_string(),
        Scheme {
            vars: vec![t_var],
            ty: Ty::fun(vec![list_t.clone(), t_to_bool.clone()], list_t.clone()),
        },
    );
    list_mod.insert(
        "reduce".to_string(),
        Scheme {
            vars: vec![t_var, u_var],
            ty: Ty::fun(vec![list_t.clone(), u.clone(), u_t_to_u], u),
        },
    );
    // Phase 46: sort, find, any, all, contains
    let t_t_to_int = Ty::fun(vec![t.clone(), t.clone()], Ty::int());
    list_mod.insert(
        "sort".to_string(),
        Scheme {
            vars: vec![t_var],
            ty: Ty::fun(vec![list_t.clone(), t_t_to_int], list_t.clone()),
        },
    );
    list_mod.insert(
        "find".to_string(),
        Scheme {
            vars: vec![t_var],
            ty: Ty::fun(
                vec![list_t.clone(), t_to_bool.clone()],
                Ty::option(t.clone()),
            ),
        },
    );
    list_mod.insert(
        "any".to_string(),
        Scheme {
            vars: vec![t_var],
            ty: Ty::fun(vec![list_t.clone(), t_to_bool.clone()], Ty::bool()),
        },
    );
    list_mod.insert(
        "all".to_string(),
        Scheme {
            vars: vec![t_var],
            ty: Ty::fun(vec![list_t.clone(), t_to_bool.clone()], Ty::bool()),
        },
    );
    list_mod.insert(
        "contains".to_string(),
        Scheme {
            vars: vec![t_var],
            ty: Ty::fun(vec![list_t.clone(), t.clone()], Ty::bool()),
        },
    );
    // Phase 47: zip, flat_map, flatten, enumerate, take, drop, last, nth
    let u = Ty::Var(u_var);
    let list_u2 = Ty::list(u.clone());
    list_mod.insert(
        "zip".to_string(),
        Scheme {
            vars: vec![t_var, u_var],
            ty: Ty::fun(
                vec![list_t.clone(), list_u2.clone()],
                Ty::list(Ty::Tuple(vec![t.clone(), u.clone()])),
            ),
        },
    );
    let t_to_list_u = Ty::fun(vec![t.clone()], list_u2.clone());
    list_mod.insert(
        "flat_map".to_string(),
        Scheme {
            vars: vec![t_var, u_var],
            ty: Ty::fun(vec![list_t.clone(), t_to_list_u], list_u2.clone()),
        },
    );
    list_mod.insert(
        "flatten".to_string(),
        Scheme {
            vars: vec![t_var],
            ty: Ty::fun(vec![Ty::list(list_t.clone())], list_t.clone()),
        },
    );
    list_mod.insert(
        "enumerate".to_string(),
        Scheme {
            vars: vec![t_var],
            ty: Ty::fun(
                vec![list_t.clone()],
                Ty::list(Ty::Tuple(vec![Ty::int(), t.clone()])),
            ),
        },
    );
    list_mod.insert(
        "take".to_string(),
        Scheme {
            vars: vec![t_var],
            ty: Ty::fun(vec![list_t.clone(), Ty::int()], list_t.clone()),
        },
    );
    list_mod.insert(
        "drop".to_string(),
        Scheme {
            vars: vec![t_var],
            ty: Ty::fun(vec![list_t.clone(), Ty::int()], list_t.clone()),
        },
    );
    list_mod.insert(
        "last".to_string(),
        Scheme {
            vars: vec![t_var],
            ty: Ty::fun(vec![list_t.clone()], t.clone()),
        },
    );
    list_mod.insert(
        "nth".to_string(),
        Scheme {
            vars: vec![t_var],
            ty: Ty::fun(vec![list_t.clone(), Ty::int()], t.clone()),
        },
    );
    // Phase 79: List.collect(iter) -> List<T>
    list_mod.insert(
        "collect".to_string(),
        Scheme {
            vars: vec![t_var],
            ty: Ty::fun(vec![Ty::iter(t.clone())], list_t.clone()),
        },
    );
    modules.insert("List".to_string(), list_mod);

    // Map module -- polymorphic: Map<K, V> with type variables for key/value.
    let k_var = TyVar(90000);
    let v_var = TyVar(90001);
    let k = Ty::Var(k_var);
    let v = Ty::Var(v_var);
    let map_kv = Ty::map(k.clone(), v.clone());

    let mut map_mod = HashMap::new();
    map_mod.insert(
        "new".to_string(),
        Scheme {
            vars: vec![k_var, v_var],
            ty: Ty::fun(vec![], map_kv.clone()),
        },
    );
    map_mod.insert(
        "put".to_string(),
        Scheme {
            vars: vec![k_var, v_var],
            ty: Ty::fun(vec![map_kv.clone(), k.clone(), v.clone()], map_kv.clone()),
        },
    );
    map_mod.insert(
        "get".to_string(),
        Scheme {
            vars: vec![k_var, v_var],
            ty: Ty::fun(vec![map_kv.clone(), k.clone()], v.clone()),
        },
    );
    map_mod.insert(
        "has_key".to_string(),
        Scheme {
            vars: vec![k_var, v_var],
            ty: Ty::fun(vec![map_kv.clone(), k.clone()], Ty::bool()),
        },
    );
    map_mod.insert(
        "delete".to_string(),
        Scheme {
            vars: vec![k_var, v_var],
            ty: Ty::fun(vec![map_kv.clone(), k.clone()], map_kv.clone()),
        },
    );
    map_mod.insert(
        "size".to_string(),
        Scheme {
            vars: vec![k_var, v_var],
            ty: Ty::fun(vec![map_kv.clone()], Ty::int()),
        },
    );
    map_mod.insert(
        "keys".to_string(),
        Scheme {
            vars: vec![k_var, v_var],
            ty: Ty::fun(vec![map_kv.clone()], Ty::list(k.clone())),
        },
    );
    map_mod.insert(
        "values".to_string(),
        Scheme {
            vars: vec![k_var, v_var],
            ty: Ty::fun(vec![map_kv.clone()], Ty::list(v.clone())),
        },
    );
    // Phase 47: merge, to_list, from_list
    map_mod.insert(
        "merge".to_string(),
        Scheme {
            vars: vec![k_var, v_var],
            ty: Ty::fun(vec![map_kv.clone(), map_kv.clone()], map_kv.clone()),
        },
    );
    map_mod.insert(
        "to_list".to_string(),
        Scheme {
            vars: vec![k_var, v_var],
            ty: Ty::fun(
                vec![map_kv.clone()],
                Ty::list(Ty::Tuple(vec![k.clone(), v.clone()])),
            ),
        },
    );
    map_mod.insert(
        "from_list".to_string(),
        Scheme {
            vars: vec![k_var, v_var],
            ty: Ty::fun(
                vec![Ty::list(Ty::Tuple(vec![k.clone(), v.clone()]))],
                map_kv.clone(),
            ),
        },
    );
    // Phase 79: Map.collect(iter) -> Map<K, V>
    map_mod.insert(
        "collect".to_string(),
        Scheme {
            vars: vec![k_var, v_var],
            ty: Ty::fun(
                vec![Ty::iter(Ty::Tuple(vec![k.clone(), v.clone()]))],
                map_kv.clone(),
            ),
        },
    );
    modules.insert("Map".to_string(), map_mod);

    // Sets and queues hold any element type.
    let (set_fns, queue_fns) = crate::builtins::set_and_queue_functions();
    let set_mod: HashMap<String, Scheme> = set_fns
        .into_iter()
        .map(|(name, scheme)| (name.to_string(), scheme))
        .collect();
    let queue_mod: HashMap<String, Scheme> = queue_fns
        .into_iter()
        .map(|(name, scheme)| (name.to_string(), scheme))
        .collect();
    modules.insert("Set".to_string(), set_mod);

    let mut tuple_mod = HashMap::new();
    tuple_mod.insert(
        "nth".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::Con(TyCon::new("Tuple")), Ty::int()],
            Ty::int(),
        )),
    );
    tuple_mod.insert(
        "first".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::Con(TyCon::new("Tuple"))], Ty::int())),
    );
    tuple_mod.insert(
        "second".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::Con(TyCon::new("Tuple"))], Ty::int())),
    );
    tuple_mod.insert(
        "size".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::Con(TyCon::new("Tuple"))], Ty::int())),
    );
    modules.insert("Tuple".to_string(), tuple_mod);

    let range_t = Ty::range();
    let mut range_mod = HashMap::new();
    range_mod.insert(
        "new".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::int(), Ty::int()], range_t.clone())),
    );
    range_mod.insert(
        "to_list".to_string(),
        Scheme::mono(Ty::fun(vec![range_t.clone()], Ty::list(Ty::int()))),
    );
    range_mod.insert(
        "map".to_string(),
        Scheme {
            vars: vec![u_var],
            ty: Ty::fun(
                vec![range_t.clone(), Ty::fun(vec![Ty::int()], u.clone())],
                Ty::list(u.clone()),
            ),
        },
    );
    range_mod.insert(
        "filter".to_string(),
        Scheme::mono(Ty::fun(
            vec![range_t.clone(), Ty::fun(vec![Ty::int()], Ty::bool())],
            Ty::list(Ty::int()),
        )),
    );
    range_mod.insert(
        "length".to_string(),
        Scheme::mono(Ty::fun(vec![range_t.clone()], Ty::int())),
    );
    modules.insert("Range".to_string(), range_mod);

    modules.insert("Queue".to_string(), queue_mod);

    // ── JSON module (Phase 8 Plan 04) ─────────────────────────────────
    let json_t = Ty::Con(TyCon::new("Json"));
    let mut json_mod = HashMap::new();
    json_mod.insert(
        "parse".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::string()],
            Ty::result(json_t.clone(), Ty::string()),
        )),
    );
    json_mod.insert(
        "encode".to_string(),
        Scheme::mono(Ty::fun(vec![json_t.clone()], Ty::string())),
    );
    json_mod.insert(
        "encode_string".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::string()], Ty::string())),
    );
    json_mod.insert(
        "encode_int".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::int()], Ty::string())),
    );
    json_mod.insert(
        "encode_bool".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::bool()], Ty::string())),
    );
    json_mod.insert(
        "encode_map".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::map_untyped()], Ty::string())),
    );
    json_mod.insert(
        "encode_list".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::list_untyped()], Ty::string())),
    );
    json_mod.insert(
        "object_get".to_string(),
        Scheme::mono(Ty::fun(
            vec![json_t.clone(), Ty::string()],
            Ty::result(json_t.clone(), Ty::string()),
        )),
    );
    json_mod.insert(
        "array_get".to_string(),
        Scheme::mono(Ty::fun(
            vec![json_t.clone(), Ty::int()],
            Ty::result(json_t.clone(), Ty::string()),
        )),
    );
    json_mod.insert(
        "array_length".to_string(),
        Scheme::mono(Ty::fun(
            vec![json_t.clone()],
            Ty::result(Ty::int(), Ty::string()),
        )),
    );
    json_mod.insert(
        "is_null".to_string(),
        Scheme::mono(Ty::fun(vec![json_t.clone()], Ty::bool())),
    );
    json_mod.insert(
        "as_int".to_string(),
        Scheme::mono(Ty::fun(
            vec![json_t.clone()],
            Ty::result(Ty::int(), Ty::string()),
        )),
    );
    json_mod.insert(
        "as_float".to_string(),
        Scheme::mono(Ty::fun(
            vec![json_t.clone()],
            Ty::result(Ty::float(), Ty::string()),
        )),
    );
    json_mod.insert(
        "as_string".to_string(),
        Scheme::mono(Ty::fun(
            vec![json_t.clone()],
            Ty::result(Ty::string(), Ty::string()),
        )),
    );
    json_mod.insert(
        "as_bool".to_string(),
        Scheme::mono(Ty::fun(
            vec![json_t.clone()],
            Ty::result(Ty::bool(), Ty::string()),
        )),
    );
    // Phase 103: JSON field extraction (no DB roundtrip)
    // Json.get(json_string, key) -> String
    json_mod.insert(
        "get".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::string(), Ty::string()], Ty::string())),
    );
    // Json.get_nested(json_string, path1, path2) -> String
    json_mod.insert(
        "get_nested".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::string(), Ty::string(), Ty::string()],
            Ty::string(),
        )),
    );
    // Json.is_string(json_string, key) -> Bool
    json_mod.insert(
        "is_string".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::string(), Ty::string()], Ty::bool())),
    );

    modules.insert("JSON".to_string(), json_mod.clone());

    // Also register "Json" as an alias for the JSON module.
    // Mesh users write Json.encode(...) for struct serde (Phase 49).
    // Override `encode` to accept any type (struct with ToJson impl will be
    // dispatched at codegen time via ToJson__to_json__StructName).
    let json_encode_tv = TyVar(9999);
    let mut json_mod_alias = json_mod;
    json_mod_alias.insert(
        "encode".to_string(),
        Scheme {
            vars: vec![json_encode_tv],
            ty: Ty::fun(vec![Ty::Var(json_encode_tv)], Ty::string()),
        },
    );
    modules.insert("Json".to_string(), json_mod_alias);

    // ── HTTP module (Phase 8 Plan 05) ────────────────────────────────
    let request_t = Ty::Con(TyCon::new("Request"));
    let response_t = Ty::Con(TyCon::new("Response"));
    let router_t = Ty::Con(TyCon::new("Router"));

    let mut http_mod = HashMap::new();
    http_mod.insert(
        "router".to_string(),
        Scheme::mono(Ty::fun(vec![], router_t.clone())),
    );
    http_mod.insert(
        "route".to_string(),
        Scheme::mono(Ty::fun(
            vec![
                router_t.clone(),
                Ty::string(),
                Ty::fun(vec![request_t.clone()], response_t.clone()),
            ],
            router_t.clone(),
        )),
    );
    http_mod.insert(
        "serve".to_string(),
        Scheme::mono(Ty::fun(
            vec![router_t.clone(), Ty::int()],
            Ty::Tuple(vec![]),
        )),
    );
    // Phase 56: HTTPS TLS server
    http_mod.insert(
        "serve_tls".to_string(),
        Scheme::mono(Ty::fun(
            vec![router_t.clone(), Ty::int(), Ty::string(), Ty::string()],
            Ty::Tuple(vec![]),
        )),
    );
    http_mod.insert(
        "response".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::int(), Ty::string()], response_t.clone())),
    );
    http_mod.insert(
        "response_bytes".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::int(), Ty::bytes()], response_t.clone())),
    );
    http_mod.insert(
        "response_bytes_with_headers".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::int(), Ty::bytes(), Ty::map(Ty::string(), Ty::string())],
            response_t.clone(),
        )),
    );
    // Phase 88: response_with_headers(Int, String, Map<K, V>) -> Response
    {
        let k_var = TyVar(92000);
        let v_var = TyVar(92001);
        let k = Ty::Var(k_var);
        let v = Ty::Var(v_var);
        let map_kv = Ty::map(k, v);
        http_mod.insert(
            "response_with_headers".to_string(),
            Scheme {
                vars: vec![k_var, v_var],
                ty: Ty::fun(vec![Ty::int(), Ty::string(), map_kv], response_t.clone()),
            },
        );
    }
    // Phase 51: Method-specific routing
    http_mod.insert(
        "on_get".to_string(),
        Scheme::mono(Ty::fun(
            vec![
                router_t.clone(),
                Ty::string(),
                Ty::fun(vec![request_t.clone()], response_t.clone()),
            ],
            router_t.clone(),
        )),
    );
    http_mod.insert(
        "on_post".to_string(),
        Scheme::mono(Ty::fun(
            vec![
                router_t.clone(),
                Ty::string(),
                Ty::fun(vec![request_t.clone()], response_t.clone()),
            ],
            router_t.clone(),
        )),
    );
    http_mod.insert(
        "on_put".to_string(),
        Scheme::mono(Ty::fun(
            vec![
                router_t.clone(),
                Ty::string(),
                Ty::fun(vec![request_t.clone()], response_t.clone()),
            ],
            router_t.clone(),
        )),
    );
    http_mod.insert(
        "on_delete".to_string(),
        Scheme::mono(Ty::fun(
            vec![
                router_t.clone(),
                Ty::string(),
                Ty::fun(vec![request_t.clone()], response_t.clone()),
            ],
            router_t.clone(),
        )),
    );
    // Phase 52: Middleware
    http_mod.insert(
        "use".to_string(),
        Scheme::mono(Ty::fun(
            vec![
                router_t.clone(),
                Ty::fun(
                    vec![
                        request_t.clone(),
                        Ty::fun(vec![request_t.clone()], response_t.clone()),
                    ],
                    response_t.clone(),
                ),
            ],
            router_t.clone(),
        )),
    );
    http_mod.insert(
        "request_id".to_string(),
        Scheme::mono(Ty::fun(vec![request_t.clone()], Ty::string())),
    );
    http_mod.insert(
        "idempotency_key".to_string(),
        Scheme::mono(Ty::fun(vec![request_t.clone()], Ty::option(Ty::string()))),
    );
    modules.insert("HTTP".to_string(), http_mod);

    // ── Request module (Phase 8 Plan 05) ─────────────────────────────
    let mut request_mod = HashMap::new();
    request_mod.insert(
        "method".to_string(),
        Scheme::mono(Ty::fun(vec![request_t.clone()], Ty::string())),
    );
    request_mod.insert(
        "path".to_string(),
        Scheme::mono(Ty::fun(vec![request_t.clone()], Ty::string())),
    );
    request_mod.insert(
        "body".to_string(),
        Scheme::mono(Ty::fun(vec![request_t.clone()], Ty::string())),
    );
    request_mod.insert(
        "body_bytes".to_string(),
        Scheme::mono(Ty::fun(vec![request_t.clone()], Ty::bytes())),
    );
    request_mod.insert(
        "header".to_string(),
        Scheme::mono(Ty::fun(
            vec![request_t.clone(), Ty::string()],
            Ty::option(Ty::string()),
        )),
    );
    request_mod.insert(
        "query".to_string(),
        Scheme::mono(Ty::fun(
            vec![request_t.clone(), Ty::string()],
            Ty::option(Ty::string()),
        )),
    );
    // Phase 51: Path parameter accessor (returns Option<String> -- runtime returns MeshOption)
    request_mod.insert(
        "param".to_string(),
        Scheme::mono(Ty::fun(
            vec![request_t.clone(), Ty::string()],
            Ty::option(Ty::string()),
        )),
    );
    modules.insert("Request".to_string(), request_mod);

    let mut cluster_mod = HashMap::new();
    cluster_mod.insert(
        "capacity".to_string(),
        Scheme::mono(Ty::fun(vec![], Ty::map(Ty::string(), Ty::int()))),
    );
    cluster_mod.insert(
        "pressure".to_string(),
        Scheme::mono(Ty::fun(vec![], Ty::map(Ty::string(), Ty::string()))),
    );
    cluster_mod.insert(
        "telemetry".to_string(),
        Scheme::mono(Ty::fun(vec![], Ty::map(Ty::string(), Ty::int()))),
    );
    cluster_mod.insert(
        "role".to_string(),
        Scheme::mono(Ty::fun(vec![], Ty::string())),
    );
    cluster_mod.insert(
        "state".to_string(),
        Scheme::mono(Ty::fun(vec![], Ty::string())),
    );
    modules.insert("Cluster".to_string(), cluster_mod);

    // ── Job module (Phase 9 Plan 02) ─────────────────────────────────
    // Job provides fire-and-forget async computation with Pid-based futures.
    // Uses synthetic TyVars for polymorphic type schemes -- these are replaced
    // with fresh vars during instantiation and never enter the unification table.
    let job_t = TyVar(u32::MAX - 10); // Synthetic type var T
    let job_a = TyVar(u32::MAX - 11); // Synthetic type var A
    let job_b = TyVar(u32::MAX - 12); // Synthetic type var B
    let ty_t = Ty::Var(job_t);
    let ty_a = Ty::Var(job_a);
    let ty_b = Ty::Var(job_b);

    let mut job_mod = HashMap::new();

    // Job.async: fn(fn() -> T) -> Pid<T>
    job_mod.insert(
        "async".to_string(),
        Scheme {
            vars: vec![job_t],
            ty: Ty::fun(vec![Ty::fun(vec![], ty_t.clone())], Ty::pid(ty_t.clone())),
        },
    );

    // Job.await: fn(Pid<T>) -> Result<T, String>
    job_mod.insert(
        "await".to_string(),
        Scheme {
            vars: vec![job_t],
            ty: Ty::fun(
                vec![Ty::pid(ty_t.clone())],
                Ty::result(ty_t.clone(), Ty::string()),
            ),
        },
    );

    // Job.await_timeout: fn(Pid<T>, Int) -> Result<T, String>
    job_mod.insert(
        "await_timeout".to_string(),
        Scheme {
            vars: vec![job_t],
            ty: Ty::fun(
                vec![Ty::pid(ty_t.clone()), Ty::int()],
                Ty::result(ty_t, Ty::string()),
            ),
        },
    );

    // Job.map: fn(List<A>, fn(A) -> B) -> List<Result<B, String>>
    job_mod.insert(
        "map".to_string(),
        Scheme {
            vars: vec![job_a, job_b],
            ty: Ty::fun(
                vec![Ty::list(ty_a.clone()), Ty::fun(vec![ty_a], ty_b.clone())],
                Ty::list(Ty::result(ty_b, Ty::string())),
            ),
        },
    );

    modules.insert("Job".to_string(), job_mod);

    // ── Math module (Phase 43 Plan 01) ─────────────────────────────────
    // Polymorphic abs/min/max using TyVar(92000) for type variable t.
    let math_t_var = TyVar(92000);
    let math_t = Ty::Var(math_t_var);

    let mut math_mod = HashMap::new();
    math_mod.insert(
        "abs".to_string(),
        Scheme {
            vars: vec![math_t_var],
            ty: Ty::fun(vec![math_t.clone()], math_t.clone()),
        },
    );
    math_mod.insert(
        "min".to_string(),
        Scheme {
            vars: vec![math_t_var],
            ty: Ty::fun(vec![math_t.clone(), math_t.clone()], math_t.clone()),
        },
    );
    math_mod.insert(
        "max".to_string(),
        Scheme {
            vars: vec![math_t_var],
            ty: Ty::fun(vec![math_t.clone(), math_t.clone()], math_t.clone()),
        },
    );
    math_mod.insert("pi".to_string(), Scheme::mono(Ty::float()));
    // ── pow/sqrt/floor/ceil/round (Phase 43 Plan 02) ──────────────────
    math_mod.insert(
        "pow".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::float(), Ty::float()], Ty::float())),
    );
    math_mod.insert(
        "sqrt".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::float()], Ty::float())),
    );
    math_mod.insert(
        "floor".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::float()], Ty::int())),
    );
    math_mod.insert(
        "ceil".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::float()], Ty::int())),
    );
    math_mod.insert(
        "round".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::float()], Ty::int())),
    );
    modules.insert("Math".to_string(), math_mod);

    // ── Int module (Phase 43 Plan 01) ──────────────────────────────────
    let mut int_mod = HashMap::new();
    int_mod.insert(
        "to_float".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::int()], Ty::float())),
    );
    int_mod.insert(
        "to_string".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::int()], Ty::string())),
    );
    modules.insert("Int".to_string(), int_mod);

    // ── Float module (Phase 43 Plan 01) ────────────────────────────────
    let mut float_mod = HashMap::new();
    float_mod.insert(
        "to_int".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::float()], Ty::int())),
    );
    float_mod.insert(
        "to_string".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::float()], Ty::string())),
    );
    // Phase 77: Float.from(Int) -> Float
    float_mod.insert(
        "from".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::int()], Ty::float())),
    );
    modules.insert("Float".to_string(), float_mod);

    // ── Timer module (Phase 44 Plan 02) ───────────────────────────────
    let timer_t_var = TyVar(u32::MAX - 20); // Synthetic type var T for Timer
    let timer_t = Ty::Var(timer_t_var);

    let mut timer_mod = HashMap::new();
    // Timer.sleep: fn(Int) -> Unit
    timer_mod.insert(
        "sleep".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::int()], Ty::Tuple(vec![]))),
    );
    // Timer.send_after: fn(Pid<T>, Int, T) -> Unit
    timer_mod.insert(
        "send_after".to_string(),
        Scheme {
            vars: vec![timer_t_var],
            ty: Ty::fun(
                vec![Ty::pid(timer_t.clone()), Ty::int(), timer_t],
                Ty::Tuple(vec![]),
            ),
        },
    );
    // Timer.apply_after: fn(Int, fn() -> T) -> Unit
    timer_mod.insert(
        "apply_after".to_string(),
        Scheme {
            vars: vec![timer_t_var],
            ty: Ty::fun(
                vec![Ty::int(), Ty::fun(vec![], Ty::Var(timer_t_var))],
                Ty::Tuple(vec![]),
            ),
        },
    );
    modules.insert("Timer".to_string(), timer_mod);

    // ── Sqlite module (Phase 53) ──────────────────────────────────────
    let sqlite_conn_t = Ty::Con(TyCon::new("SqliteConn"));

    let mut sqlite_mod = HashMap::new();
    // Sqlite.open: fn(String) -> Result<SqliteConn, String>
    sqlite_mod.insert(
        "open".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::string()],
            Ty::result(sqlite_conn_t.clone(), Ty::string()),
        )),
    );
    // Sqlite.close: fn(SqliteConn) -> Unit
    sqlite_mod.insert(
        "close".to_string(),
        Scheme::mono(Ty::fun(vec![sqlite_conn_t.clone()], Ty::Tuple(vec![]))),
    );
    // Sqlite.execute: fn(SqliteConn, String, List<String>) -> Result<Int, String>
    sqlite_mod.insert(
        "execute".to_string(),
        Scheme::mono(Ty::fun(
            vec![sqlite_conn_t.clone(), Ty::string(), Ty::list(Ty::string())],
            Ty::result(Ty::int(), Ty::string()),
        )),
    );
    // Sqlite.query: fn(SqliteConn, String, List<String>) -> Result<List<Map<String, String>>, String>
    sqlite_mod.insert(
        "query".to_string(),
        Scheme::mono(Ty::fun(
            vec![sqlite_conn_t.clone(), Ty::string(), Ty::list(Ty::string())],
            Ty::result(Ty::list(Ty::map(Ty::string(), Ty::string())), Ty::string()),
        )),
    );
    sqlite_mod.insert(
        "execute_values".to_string(),
        Scheme::mono(Ty::fun(
            vec![
                sqlite_conn_t.clone(),
                Ty::string(),
                Ty::list(Ty::db_value()),
            ],
            Ty::result(Ty::int(), Ty::string()),
        )),
    );
    sqlite_mod.insert(
        "query_values".to_string(),
        Scheme::mono(Ty::fun(
            vec![
                sqlite_conn_t.clone(),
                Ty::string(),
                Ty::list(Ty::db_value()),
            ],
            Ty::result(
                Ty::list(Ty::map(Ty::string(), Ty::db_value())),
                Ty::string(),
            ),
        )),
    );
    // Sqlite.begin: fn(SqliteConn) -> Result<Unit, String>
    sqlite_mod.insert(
        "begin".to_string(),
        Scheme::mono(Ty::fun(
            vec![sqlite_conn_t.clone()],
            Ty::result(Ty::Tuple(vec![]), Ty::string()),
        )),
    );
    // Sqlite.commit: fn(SqliteConn) -> Result<Unit, String>
    sqlite_mod.insert(
        "commit".to_string(),
        Scheme::mono(Ty::fun(
            vec![sqlite_conn_t.clone()],
            Ty::result(Ty::Tuple(vec![]), Ty::string()),
        )),
    );
    // Sqlite.rollback: fn(SqliteConn) -> Result<Unit, String>
    sqlite_mod.insert(
        "rollback".to_string(),
        Scheme::mono(Ty::fun(
            vec![sqlite_conn_t.clone()],
            Ty::result(Ty::Tuple(vec![]), Ty::string()),
        )),
    );
    modules.insert("Sqlite".to_string(), sqlite_mod);

    // ── Pg module (Phase 54) ──────────────────────────────────────────
    let pg_conn_t = Ty::Con(TyCon::new("PgConn"));

    let mut pg_mod = HashMap::new();
    // Pg.connect: fn(String) -> Result<PgConn, String>
    pg_mod.insert(
        "connect".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::string()],
            Ty::result(pg_conn_t.clone(), Ty::string()),
        )),
    );
    // Pg.close: fn(PgConn) -> Unit
    pg_mod.insert(
        "close".to_string(),
        Scheme::mono(Ty::fun(vec![pg_conn_t.clone()], Ty::Tuple(vec![]))),
    );
    // Pg.execute: fn(PgConn, String, List<String>) -> Result<Int, String>
    pg_mod.insert(
        "execute".to_string(),
        Scheme::mono(Ty::fun(
            vec![pg_conn_t.clone(), Ty::string(), Ty::list(Ty::string())],
            Ty::result(Ty::int(), Ty::string()),
        )),
    );
    // Pg.query: fn(PgConn, String, List<String>) -> Result<List<Map<String, String>>, String>
    pg_mod.insert(
        "query".to_string(),
        Scheme::mono(Ty::fun(
            vec![pg_conn_t.clone(), Ty::string(), Ty::list(Ty::string())],
            Ty::result(Ty::list(Ty::map(Ty::string(), Ty::string())), Ty::string()),
        )),
    );
    pg_mod.insert(
        "execute_values".to_string(),
        Scheme::mono(Ty::fun(
            vec![pg_conn_t.clone(), Ty::string(), Ty::list(Ty::db_value())],
            Ty::result(Ty::int(), Ty::string()),
        )),
    );
    pg_mod.insert(
        "query_values".to_string(),
        Scheme::mono(Ty::fun(
            vec![pg_conn_t.clone(), Ty::string(), Ty::list(Ty::db_value())],
            Ty::result(
                Ty::list(Ty::map(Ty::string(), Ty::db_value())),
                Ty::string(),
            ),
        )),
    );
    // Pg.begin: fn(PgConn) -> Result<Unit, String>
    pg_mod.insert(
        "begin".to_string(),
        Scheme::mono(Ty::fun(
            vec![pg_conn_t.clone()],
            Ty::result(Ty::Tuple(vec![]), Ty::string()),
        )),
    );
    // Pg.commit: fn(PgConn) -> Result<Unit, String>
    pg_mod.insert(
        "commit".to_string(),
        Scheme::mono(Ty::fun(
            vec![pg_conn_t.clone()],
            Ty::result(Ty::Tuple(vec![]), Ty::string()),
        )),
    );
    // Pg.rollback: fn(PgConn) -> Result<Unit, String>
    pg_mod.insert(
        "rollback".to_string(),
        Scheme::mono(Ty::fun(
            vec![pg_conn_t.clone()],
            Ty::result(Ty::Tuple(vec![]), Ty::string()),
        )),
    );
    // Pg.transaction: fn(PgConn, fn(PgConn) -> Result<Unit, String>) -> Result<Unit, String>
    pg_mod.insert(
        "transaction".to_string(),
        Scheme::mono(Ty::fun(
            vec![
                pg_conn_t.clone(),
                Ty::fun(
                    vec![pg_conn_t.clone()],
                    Ty::result(Ty::Tuple(vec![]), Ty::string()),
                ),
            ],
            Ty::result(Ty::Tuple(vec![]), Ty::string()),
        )),
    );
    // Pg.query_as: forall a. fn(PgConn, String, List<String>, fn(Map<String, String>) -> Result<a, String>) -> Result<List<Result<a, String>>, String>
    {
        let a = TyVar(99990);
        let a_ty = Ty::Var(a);
        let from_row_fn = Ty::fun(
            vec![Ty::map(Ty::string(), Ty::string())],
            Ty::result(a_ty.clone(), Ty::string()),
        );
        let ret = Ty::result(Ty::list(Ty::result(a_ty, Ty::string())), Ty::string());
        pg_mod.insert(
            "query_as".to_string(),
            Scheme {
                vars: vec![a],
                ty: Ty::fun(
                    vec![
                        pg_conn_t.clone(),
                        Ty::string(),
                        Ty::list(Ty::string()),
                        from_row_fn,
                    ],
                    ret,
                ),
            },
        );
    }
    let pg_pool_t = Ty::Con(TyCon::new("PoolHandle"));
    let pg_int_result_t = Ty::result(Ty::int(), Ty::string());
    // Explicit PostgreSQL schema helpers.
    pg_mod.insert(
        "create_extension".to_string(),
        Scheme::mono(Ty::fun(
            vec![pg_pool_t.clone(), Ty::string()],
            pg_int_result_t.clone(),
        )),
    );
    pg_mod.insert(
        "create_range_partitioned_table".to_string(),
        Scheme::mono(Ty::fun(
            vec![
                pg_pool_t.clone(),
                Ty::string(),
                Ty::list(Ty::string()),
                Ty::string(),
            ],
            pg_int_result_t.clone(),
        )),
    );
    pg_mod.insert(
        "create_gin_index".to_string(),
        Scheme::mono(Ty::fun(
            vec![
                pg_pool_t.clone(),
                Ty::string(),
                Ty::string(),
                Ty::string(),
                Ty::string(),
            ],
            pg_int_result_t.clone(),
        )),
    );
    pg_mod.insert(
        "create_daily_partitions_ahead".to_string(),
        Scheme::mono(Ty::fun(
            vec![pg_pool_t.clone(), Ty::string(), Ty::int()],
            pg_int_result_t.clone(),
        )),
    );
    pg_mod.insert(
        "list_daily_partitions_before".to_string(),
        Scheme::mono(Ty::fun(
            vec![pg_pool_t.clone(), Ty::string(), Ty::int()],
            Ty::result(Ty::list(Ty::string()), Ty::string()),
        )),
    );
    pg_mod.insert(
        "drop_partition".to_string(),
        Scheme::mono(Ty::fun(
            vec![pg_pool_t.clone(), Ty::string()],
            pg_int_result_t.clone(),
        )),
    );
    // Pg.cast(Expr, String) -> Expr  (vendor-specific SQL type cast)
    let expr_t = Ty::Con(TyCon::new("Expr"));
    pg_mod.insert(
        "cast".to_string(),
        Scheme::mono(Ty::fun(vec![expr_t.clone(), Ty::string()], expr_t.clone())),
    );
    // Pg.jsonb/int/text/uuid/timestamptz(Expr) -> Expr
    for helper in ["jsonb", "int", "text", "uuid", "timestamptz"] {
        pg_mod.insert(
            helper.to_string(),
            Scheme::mono(Ty::fun(vec![expr_t.clone()], expr_t.clone())),
        );
    }
    // Pg.gen_salt(String, Int) -> Expr
    pg_mod.insert(
        "gen_salt".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::string(), Ty::int()], expr_t.clone())),
    );
    // Pg.crypt(Expr, Expr) -> Expr
    pg_mod.insert(
        "crypt".to_string(),
        Scheme::mono(Ty::fun(
            vec![expr_t.clone(), expr_t.clone()],
            expr_t.clone(),
        )),
    );
    // Pg.to_tsvector/plainto_tsquery(String, Expr) -> Expr
    for helper in ["to_tsvector", "plainto_tsquery"] {
        pg_mod.insert(
            helper.to_string(),
            Scheme::mono(Ty::fun(vec![Ty::string(), expr_t.clone()], expr_t.clone())),
        );
    }
    // Pg.ts_rank(Expr, Expr) -> Expr
    pg_mod.insert(
        "ts_rank".to_string(),
        Scheme::mono(Ty::fun(
            vec![expr_t.clone(), expr_t.clone()],
            expr_t.clone(),
        )),
    );
    // Pg.tsvector_matches/jsonb_contains(Expr, Expr) -> Expr
    for helper in ["tsvector_matches", "jsonb_contains"] {
        pg_mod.insert(
            helper.to_string(),
            Scheme::mono(Ty::fun(
                vec![expr_t.clone(), expr_t.clone()],
                expr_t.clone(),
            )),
        );
    }
    modules.insert("Pg".to_string(), pg_mod);

    // ── Pool module (Phase 57) ──────────────────────────────────────
    let pool_handle_t = Ty::Con(TyCon::new("PoolHandle"));

    let mut pool_mod = HashMap::new();
    // Pool.open: fn(String, Int, Int, Int) -> Result<PoolHandle, String>
    pool_mod.insert(
        "open".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::string(), Ty::int(), Ty::int(), Ty::int()],
            Ty::result(pool_handle_t.clone(), Ty::string()),
        )),
    );
    // Pool.close: fn(PoolHandle) -> Unit
    pool_mod.insert(
        "close".to_string(),
        Scheme::mono(Ty::fun(vec![pool_handle_t.clone()], Ty::Tuple(vec![]))),
    );
    // Pool.query: fn(PoolHandle, String, List<String>) -> Result<List<Map<String, String>>, String>
    pool_mod.insert(
        "query".to_string(),
        Scheme::mono(Ty::fun(
            vec![pool_handle_t.clone(), Ty::string(), Ty::list(Ty::string())],
            Ty::result(Ty::list(Ty::map(Ty::string(), Ty::string())), Ty::string()),
        )),
    );
    // Pool.execute: fn(PoolHandle, String, List<String>) -> Result<Int, String>
    pool_mod.insert(
        "execute".to_string(),
        Scheme::mono(Ty::fun(
            vec![pool_handle_t.clone(), Ty::string(), Ty::list(Ty::string())],
            Ty::result(Ty::int(), Ty::string()),
        )),
    );
    pool_mod.insert(
        "query_values".to_string(),
        Scheme::mono(Ty::fun(
            vec![
                pool_handle_t.clone(),
                Ty::string(),
                Ty::list(Ty::db_value()),
            ],
            Ty::result(
                Ty::list(Ty::map(Ty::string(), Ty::db_value())),
                Ty::string(),
            ),
        )),
    );
    pool_mod.insert(
        "execute_values".to_string(),
        Scheme::mono(Ty::fun(
            vec![
                pool_handle_t.clone(),
                Ty::string(),
                Ty::list(Ty::db_value()),
            ],
            Ty::result(Ty::int(), Ty::string()),
        )),
    );
    // Pool.query_as: forall a. fn(PoolHandle, String, List<String>, fn(Map<String, String>) -> Result<a, String>) -> Result<List<Result<a, String>>, String>
    {
        let a = TyVar(99991);
        let a_ty = Ty::Var(a);
        let from_row_fn = Ty::fun(
            vec![Ty::map(Ty::string(), Ty::string())],
            Ty::result(a_ty.clone(), Ty::string()),
        );
        let ret = Ty::result(Ty::list(Ty::result(a_ty, Ty::string())), Ty::string());
        pool_mod.insert(
            "query_as".to_string(),
            Scheme {
                vars: vec![a],
                ty: Ty::fun(
                    vec![
                        pool_handle_t.clone(),
                        Ty::string(),
                        Ty::list(Ty::string()),
                        from_row_fn,
                    ],
                    ret,
                ),
            },
        );
    }
    modules.insert("Pool".to_string(), pool_mod);

    let job_text_result = Ty::result(Ty::string(), Ty::string());
    if test_builtins {
        let test_mod = modules.get_mut("Test").expect("Test module registered");
        let unit_result = Ty::result(Ty::Tuple(vec![]), Ty::string());
        for (name, params, result) in [
            (
                "jobs_inspect",
                vec![pool_handle_t.clone(), Ty::string(), Ty::string()],
                job_text_result.clone(),
            ),
            (
                "jobs_inspect_in",
                vec![pg_conn_t.clone(), Ty::string(), Ty::string()],
                job_text_result.clone(),
            ),
            (
                "assert_enqueued",
                vec![pool_handle_t.clone(), Ty::string(), Ty::string(), Ty::int()],
                unit_result.clone(),
            ),
            (
                "refute_enqueued",
                vec![pool_handle_t.clone(), Ty::string(), Ty::string(), Ty::int()],
                unit_result.clone(),
            ),
            (
                "assert_enqueued_in",
                vec![pg_conn_t.clone(), Ty::string(), Ty::string()],
                unit_result.clone(),
            ),
            (
                "refute_enqueued_in",
                vec![pg_conn_t.clone(), Ty::string(), Ty::string()],
                unit_result,
            ),
            (
                "build_job",
                vec![Ty::string(), Ty::int()],
                job_text_result.clone(),
            ),
            (
                "perform_job",
                vec![Ty::string(), Ty::int(), jobs_handler_type()],
                job_text_result.clone(),
            ),
        ] {
            test_mod.insert(name.to_string(), Scheme::mono(Ty::fun(params, result)));
        }
    }
    let mut jobs_mod = HashMap::new();
    for (name, params, result) in [
        (
            "migrate",
            vec![pool_handle_t.clone()],
            Ty::result(Ty::Tuple(vec![]), Ty::string()),
        ),
        (
            "enqueue",
            vec![pool_handle_t.clone(), Ty::string(), Ty::string()],
            job_text_result.clone(),
        ),
        (
            "enqueue_in",
            vec![pg_conn_t.clone(), Ty::string(), Ty::string()],
            job_text_result.clone(),
        ),
        (
            "control",
            vec![pool_handle_t.clone(), Ty::string(), Ty::string()],
            job_text_result.clone(),
        ),
        (
            "start",
            vec![pool_handle_t.clone(), Ty::string(), jobs_handler_type()],
            Ty::result(Ty::int(), Ty::string()),
        ),
        (
            "start_effects",
            vec![
                pool_handle_t.clone(),
                Ty::string(),
                jobs_handler_type(),
                Ty::string(),
                json_t.clone(),
            ],
            Ty::result(Ty::int(), Ty::string()),
        ),
        (
            "effect",
            vec![Ty::string(), json_t],
            Ty::result(Ty::bool(), Ty::string()),
        ),
        (
            "drain",
            vec![
                pool_handle_t,
                Ty::string(),
                jobs_handler_type(),
                Ty::string(),
            ],
            job_text_result.clone(),
        ),
        ("stop", vec![Ty::int(), Ty::int()], job_text_result.clone()),
        ("join", vec![Ty::int()], job_text_result.clone()),
        ("status", vec![Ty::int()], job_text_result.clone()),
        (
            "read_events",
            vec![Ty::int(), Ty::int()],
            job_text_result.clone(),
        ),
        (
            "local_control",
            vec![Ty::int(), Ty::string()],
            job_text_result,
        ),
    ] {
        jobs_mod.insert(name.to_string(), Scheme::mono(Ty::fun(params, result)));
    }
    modules.insert("Jobs".to_string(), jobs_mod);

    // ── Node module (Phase 67) ──────────────────────────────────────
    let node_spawn_t = TyVar(u32::MAX - 30); // Synthetic type var T for Node.spawn
    let _node_t = Ty::Var(node_spawn_t);

    let mut node_mod = HashMap::new();
    // Node.start: fn(String, String) -> Int  (name, cookie -> 0 on success)
    node_mod.insert(
        "start".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::string(), Ty::string()], Ty::int())),
    );
    // Node.start_from_env: fn() -> Result<BootstrapStatus, String>
    node_mod.insert(
        "start_from_env".to_string(),
        Scheme::mono(Ty::fun(
            vec![],
            Ty::result(Ty::Con(TyCon::new("BootstrapStatus")), Ty::string()),
        )),
    );
    // Node.connect: fn(String) -> Int  (node_name -> 0 on success)
    node_mod.insert(
        "connect".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::string()], Ty::int())),
    );
    // Node.self: fn() -> String  (returns node name)
    node_mod.insert(
        "self".to_string(),
        Scheme::mono(Ty::fun(vec![], Ty::string())),
    );
    // Node.list: fn() -> List<String>  (returns connected node names)
    node_mod.insert(
        "list".to_string(),
        Scheme::mono(Ty::fun(vec![], Ty::list(Ty::string()))),
    );
    // Node.monitor: fn(String, M) -> Int  (node name, message for when it
    // disconnects -> 0 on success); M is the monitoring actor's message type,
    // which `infer_field_access` supplies.
    node_mod.insert(
        "monitor".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::string(), Ty::Var(TyVar(u32::MAX - 31))],
            Ty::int(),
        )),
    );
    // Node.spawn/spawn_link are NOT defined here because they are variadic
    // (node_name, func_ref, args...). The type checker handles them specially
    // in infer_field_access by returning a fresh function type that matches
    // the actual call site arguments.
    modules.insert("Node".to_string(), node_mod);

    // ── Process module (Phase 67) ───────────────────────────────────
    let mut process_mod = HashMap::new();
    // Process.monitor: fn(Pid, M) -> Int  (target pid, message for when it
    // ends -> monitor ref); M is the monitoring actor's message type, which
    // `infer_field_access` supplies.
    process_mod.insert(
        "monitor".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::untyped_pid(), Ty::Var(TyVar(u32::MAX - 31))],
            Ty::int(),
        )),
    );
    // Process.demonitor: fn(Int) -> Int  (monitor_ref -> 0 on success)
    process_mod.insert(
        "demonitor".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::int()], Ty::int())),
    );
    // Process.register: fn(String, Pid<()>) -> Int  (name, pid -> 0 success, 1 error)
    process_mod.insert(
        "register".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::string(), Ty::Con(TyCon::new("Pid"))],
            Ty::int(),
        )),
    );
    // Process.whereis: fn(String) -> Pid<()>  (name -> pid, 0 if not found)
    process_mod.insert(
        "whereis".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::string()], Ty::Con(TyCon::new("Pid")))),
    );
    process_mod.insert(
        "install_shutdown_signals".to_string(),
        Scheme::mono(Ty::fun(vec![], Ty::Tuple(vec![]))),
    );
    process_mod.insert(
        "shutdown_requested".to_string(),
        Scheme::mono(Ty::fun(vec![], Ty::bool())),
    );
    process_mod.insert(
        "request_shutdown".to_string(),
        Scheme::mono(Ty::fun(vec![], Ty::Tuple(vec![]))),
    );
    process_mod.insert(
        "exit".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::int()], Ty::Tuple(vec![]))),
    );
    modules.insert("Process".to_string(), process_mod);

    // ── Global module (Phase 68) ─────────────────────────────────────
    let mut global_mod = HashMap::new();
    // Global.register: fn(String, Pid<()>) -> Int  (name, pid -> 0 success, 1 error)
    // Pid type matches Process.register for consistency; runtime treats Pid as u64.
    global_mod.insert(
        "register".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::string(), Ty::Con(TyCon::new("Pid"))],
            Ty::int(),
        )),
    );
    // Global.whereis: fn(String) -> Pid<()>  (name -> pid, 0 if not found)
    // Pid type matches Process.whereis for consistency; runtime treats Pid as u64.
    global_mod.insert(
        "whereis".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::string()], Ty::Con(TyCon::new("Pid")))),
    );
    // Global.unregister: fn(String) -> Int  (name -> 0 success, 1 not found)
    global_mod.insert(
        "unregister".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::string()], Ty::int())),
    );
    modules.insert("Global".to_string(), global_mod);

    // ── Continuity module (continuity) ─────────────────────────────────
    let continuity_authority_status_t = Ty::Con(TyCon::new("ContinuityAuthorityStatus"));
    let continuity_record_t = Ty::Con(TyCon::new("ContinuityRecord"));
    let continuity_submit_decision_t = Ty::Con(TyCon::new("ContinuitySubmitDecision"));
    let mut continuity_mod = HashMap::new();
    continuity_mod.insert(
        "submit".to_string(),
        Scheme::mono(Ty::fun(
            vec![
                Ty::string(),
                Ty::string(),
                Ty::string(),
                Ty::string(),
                Ty::string(),
                Ty::int(),
                Ty::bool(),
                Ty::bool(),
            ],
            Ty::result(continuity_submit_decision_t.clone(), Ty::string()),
        )),
    );
    continuity_mod.insert(
        "submit_declared_work".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::string(), Ty::string(), Ty::string(), Ty::int()],
            Ty::result(continuity_submit_decision_t.clone(), Ty::string()),
        )),
    );
    continuity_mod.insert(
        "status".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::string()],
            Ty::result(continuity_record_t.clone(), Ty::string()),
        )),
    );
    continuity_mod.insert(
        "authority_status".to_string(),
        Scheme::mono(Ty::fun(
            vec![],
            Ty::result(continuity_authority_status_t.clone(), Ty::string()),
        )),
    );
    continuity_mod.insert(
        "mark_completed".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::string(), Ty::string(), Ty::string()],
            Ty::result(continuity_record_t.clone(), Ty::string()),
        )),
    );
    continuity_mod.insert(
        "acknowledge_replica".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::string(), Ty::string()],
            Ty::result(continuity_record_t, Ty::string()),
        )),
    );
    modules.insert("Continuity".to_string(), continuity_mod);

    // ── Ws (WebSocket) module (Phase 88) ─────────────────────────
    let mut ws_mod = HashMap::new();
    // Ws.send: fn(Int, String) -> Int  (conn_handle, message -> 0 success)
    ws_mod.insert(
        "send".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::int(), Ty::string()], Ty::int())),
    );
    // Ws.serve: fn(fn(Int, String, Map<String,String>) -> Int, fn(Int, String) -> (), fn(Int, Int, String) -> (), Int) -> ()
    // Ws.serve_tls takes the same, then the PEM certificate and key paths.
    let ws_callbacks = [
        Ty::fun(
            vec![Ty::int(), Ty::string(), Ty::map(Ty::string(), Ty::string())],
            Ty::int(),
        ),
        Ty::fun(vec![Ty::int(), Ty::string()], Ty::Tuple(vec![])),
        Ty::fun(vec![Ty::int(), Ty::int(), Ty::string()], Ty::Tuple(vec![])),
        Ty::int(),
    ];
    ws_mod.insert(
        "serve".to_string(),
        Scheme::mono(Ty::fun(ws_callbacks.to_vec(), Ty::Tuple(vec![]))),
    );
    ws_mod.insert(
        "serve_tls".to_string(),
        Scheme::mono(Ty::fun(
            [ws_callbacks.to_vec(), vec![Ty::string(), Ty::string()]].concat(),
            Ty::Tuple(vec![]),
        )),
    );
    // ── WebSocket Room functions (Phase 90) ────────────────────────
    // Ws.join: fn(Int, String) -> Int  (conn_handle, room_name -> 0 success)
    ws_mod.insert(
        "join".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::int(), Ty::string()], Ty::int())),
    );
    // Ws.leave: fn(Int, String) -> Int  (conn_handle, room_name -> 0 success)
    ws_mod.insert(
        "leave".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::int(), Ty::string()], Ty::int())),
    );
    // Ws.broadcast: fn(String, String) -> Int  (room_name, message -> failure_count)
    ws_mod.insert(
        "broadcast".to_string(),
        Scheme::mono(Ty::fun(vec![Ty::string(), Ty::string()], Ty::int())),
    );
    // Ws.broadcast_except: fn(String, String, Int) -> Int  (room, msg, except_conn -> failure_count)
    ws_mod.insert(
        "broadcast_except".to_string(),
        Scheme::mono(Ty::fun(
            vec![Ty::string(), Ty::string(), Ty::int()],
            Ty::int(),
        )),
    );
    modules.insert("Ws".to_string(), ws_mod);

    // ── Iter module (Phase 76 + Phase 78) ──────────────────────────
    {
        let mut iter_mod = HashMap::new();
        // `Iter<T>` carries its element type, so closures and collectors see
        // it. (The iterator handle types `ListIterator` and friends stay
        // compatible with it, without an element type.)
        let iter = |elem: Ty| Ty::App(Box::new(Ty::Con(TyCon::new("Iter"))), vec![elem]);
        let (t, u) = (TyVar(91210), TyVar(91211));
        let (tv, uv) = (Ty::Var(t), Ty::Var(u));
        let scheme = |vars: Vec<TyVar>, params: Vec<Ty>, ret: Ty| Scheme {
            vars,
            ty: Ty::fun(params, ret),
        };
        let predicate = Ty::fun(vec![tv.clone()], Ty::bool());
        for (name, scheme) in [
            // `a -> Iter<b>`: the source's type settles `b` at the call
            // (`settle_iter_source`).
            (
                "from",
                scheme(vec![t, u], vec![tv.clone()], iter(uv.clone())),
            ),
            (
                "map",
                scheme(
                    vec![t, u],
                    vec![iter(tv.clone()), Ty::fun(vec![tv.clone()], uv.clone())],
                    iter(uv.clone()),
                ),
            ),
            (
                "filter",
                scheme(
                    vec![t],
                    vec![iter(tv.clone()), predicate.clone()],
                    iter(tv.clone()),
                ),
            ),
            (
                "take",
                scheme(vec![t], vec![iter(tv.clone()), Ty::int()], iter(tv.clone())),
            ),
            (
                "skip",
                scheme(vec![t], vec![iter(tv.clone()), Ty::int()], iter(tv.clone())),
            ),
            (
                "enumerate",
                scheme(
                    vec![t],
                    vec![iter(tv.clone())],
                    iter(Ty::Tuple(vec![Ty::int(), tv.clone()])),
                ),
            ),
            (
                "zip",
                scheme(
                    vec![t, u],
                    vec![iter(tv.clone()), iter(uv.clone())],
                    iter(Ty::Tuple(vec![tv.clone(), uv.clone()])),
                ),
            ),
            // The next element, advancing the iterator: `None` once it is
            // done. An iterator is a stateful handle, as a user `Iterator`'s
            // `next` keeps its position somewhere that changes.
            (
                "next",
                scheme(vec![t], vec![iter(tv.clone())], Ty::option(tv.clone())),
            ),
            ("count", scheme(vec![t], vec![iter(tv.clone())], Ty::int())),
            ("sum", scheme(vec![], vec![iter(Ty::int())], Ty::int())),
            (
                "any",
                scheme(
                    vec![t],
                    vec![iter(tv.clone()), predicate.clone()],
                    Ty::bool(),
                ),
            ),
            (
                "all",
                scheme(
                    vec![t],
                    vec![iter(tv.clone()), predicate.clone()],
                    Ty::bool(),
                ),
            ),
            (
                "find",
                scheme(
                    vec![t],
                    vec![iter(tv.clone()), predicate],
                    Ty::option(tv.clone()),
                ),
            ),
            (
                "reduce",
                scheme(
                    vec![t],
                    vec![
                        iter(tv.clone()),
                        tv.clone(),
                        Ty::fun(vec![tv.clone(), tv.clone()], tv.clone()),
                    ],
                    tv.clone(),
                ),
            ),
        ] {
            iter_mod.insert(name.to_string(), scheme);
        }

        modules.insert("Iter".to_string(), iter_mod);
    }

    // ── Option and Result modules ──────────────────────────────────
    // What a `case` over one would otherwise spell out; lowering generates
    // each as that `case` (`option_result_function`).
    {
        let (a, b, e, f) = (TyVar(91300), TyVar(91301), TyVar(91302), TyVar(91303));
        let (av, bv, ev, fv) = (Ty::Var(a), Ty::Var(b), Ty::Var(e), Ty::Var(f));
        let scheme = |vars: Vec<TyVar>, params: Vec<Ty>, ret: Ty| Scheme {
            vars,
            ty: Ty::fun(params, ret),
        };
        let option = Ty::option(av.clone());
        let result = Ty::result(av.clone(), ev.clone());
        let to = |from: &Ty, to: Ty| Ty::fun(vec![from.clone()], to);
        let option_mod = [
            (
                "map",
                scheme(
                    vec![a, b],
                    vec![option.clone(), to(&av, bv.clone())],
                    Ty::option(bv.clone()),
                ),
            ),
            (
                "and_then",
                scheme(
                    vec![a, b],
                    vec![option.clone(), to(&av, Ty::option(bv.clone()))],
                    Ty::option(bv.clone()),
                ),
            ),
            (
                "unwrap_or",
                scheme(vec![a], vec![option.clone(), av.clone()], av.clone()),
            ),
            ("is_some", scheme(vec![a], vec![option.clone()], Ty::bool())),
            ("is_none", scheme(vec![a], vec![option.clone()], Ty::bool())),
            (
                "ok_or",
                scheme(vec![a, e], vec![option.clone(), ev.clone()], result.clone()),
            ),
        ];
        let result_mod = [
            (
                "map",
                scheme(
                    vec![a, b, e],
                    vec![result.clone(), to(&av, bv.clone())],
                    Ty::result(bv.clone(), ev.clone()),
                ),
            ),
            (
                "map_err",
                scheme(
                    vec![a, e, f],
                    vec![result.clone(), to(&ev, fv.clone())],
                    Ty::result(av.clone(), fv.clone()),
                ),
            ),
            (
                "and_then",
                scheme(
                    vec![a, b, e],
                    vec![result.clone(), to(&av, Ty::result(bv.clone(), ev.clone()))],
                    Ty::result(bv.clone(), ev.clone()),
                ),
            ),
            (
                "unwrap_or",
                scheme(vec![a, e], vec![result.clone(), av.clone()], av.clone()),
            ),
            (
                "is_ok",
                scheme(vec![a, e], vec![result.clone()], Ty::bool()),
            ),
            (
                "is_err",
                scheme(vec![a, e], vec![result.clone()], Ty::bool()),
            ),
            (
                "ok",
                scheme(vec![a, e], vec![result.clone()], option.clone()),
            ),
        ];
        for (module, functions) in [
            ("Option", option_mod.to_vec()),
            ("Result", result_mod.to_vec()),
        ] {
            modules.insert(
                module.to_string(),
                functions
                    .into_iter()
                    .map(|(name, scheme)| (name.to_string(), scheme))
                    .collect(),
            );
        }
    }

    // ── Orm module (Phase 97) ───────────────────────────────────────
    {
        let mut orm_mod = HashMap::new();
        // Orm.build_select: fn(String, List<String>, List<String>, List<String>, Int, Int) -> String
        orm_mod.insert(
            "build_select".to_string(),
            Scheme::mono(Ty::fun(
                vec![
                    Ty::string(),
                    Ty::list(Ty::string()),
                    Ty::list(Ty::string()),
                    Ty::list(Ty::string()),
                    Ty::int(),
                    Ty::int(),
                ],
                Ty::string(),
            )),
        );
        // Orm.build_insert: fn(String, List<String>, List<String>) -> String
        orm_mod.insert(
            "build_insert".to_string(),
            Scheme::mono(Ty::fun(
                vec![Ty::string(), Ty::list(Ty::string()), Ty::list(Ty::string())],
                Ty::string(),
            )),
        );
        // Orm.build_update: fn(String, List<String>, List<String>, List<String>) -> String
        orm_mod.insert(
            "build_update".to_string(),
            Scheme::mono(Ty::fun(
                vec![
                    Ty::string(),
                    Ty::list(Ty::string()),
                    Ty::list(Ty::string()),
                    Ty::list(Ty::string()),
                ],
                Ty::string(),
            )),
        );
        // Orm.build_delete: fn(String, List<String>, List<String>) -> String
        orm_mod.insert(
            "build_delete".to_string(),
            Scheme::mono(Ty::fun(
                vec![Ty::string(), Ty::list(Ty::string()), Ty::list(Ty::string())],
                Ty::string(),
            )),
        );
        modules.insert("Orm".to_string(), orm_mod);
    }

    // ── Expr module ─────────────────────────────────────────────────
    {
        let expr_t = Ty::Con(TyCon::new("Expr"));
        let mut expr_mod = HashMap::new();
        expr_mod.insert(
            "column".to_string(),
            Scheme::mono(Ty::fun(vec![Ty::string()], expr_t.clone())),
        );
        expr_mod.insert(
            "value".to_string(),
            Scheme::mono(Ty::fun(vec![Ty::string()], expr_t.clone())),
        );
        expr_mod.insert(
            "null".to_string(),
            Scheme::mono(Ty::fun(vec![], expr_t.clone())),
        );
        expr_mod.insert(
            "call".to_string(),
            Scheme::mono(Ty::fun(
                vec![Ty::string(), Ty::list(expr_t.clone())],
                expr_t.clone(),
            )),
        );
        expr_mod.insert(
            "fn_call".to_string(),
            Scheme::mono(Ty::fun(
                vec![Ty::string(), Ty::list(expr_t.clone())],
                expr_t.clone(),
            )),
        );
        expr_mod.insert(
            "add".to_string(),
            Scheme::mono(Ty::fun(
                vec![expr_t.clone(), expr_t.clone()],
                expr_t.clone(),
            )),
        );
        expr_mod.insert(
            "sub".to_string(),
            Scheme::mono(Ty::fun(
                vec![expr_t.clone(), expr_t.clone()],
                expr_t.clone(),
            )),
        );
        expr_mod.insert(
            "mul".to_string(),
            Scheme::mono(Ty::fun(
                vec![expr_t.clone(), expr_t.clone()],
                expr_t.clone(),
            )),
        );
        expr_mod.insert(
            "div".to_string(),
            Scheme::mono(Ty::fun(
                vec![expr_t.clone(), expr_t.clone()],
                expr_t.clone(),
            )),
        );
        expr_mod.insert(
            "eq".to_string(),
            Scheme::mono(Ty::fun(
                vec![expr_t.clone(), expr_t.clone()],
                expr_t.clone(),
            )),
        );
        expr_mod.insert(
            "neq".to_string(),
            Scheme::mono(Ty::fun(
                vec![expr_t.clone(), expr_t.clone()],
                expr_t.clone(),
            )),
        );
        expr_mod.insert(
            "lt".to_string(),
            Scheme::mono(Ty::fun(
                vec![expr_t.clone(), expr_t.clone()],
                expr_t.clone(),
            )),
        );
        expr_mod.insert(
            "lte".to_string(),
            Scheme::mono(Ty::fun(
                vec![expr_t.clone(), expr_t.clone()],
                expr_t.clone(),
            )),
        );
        expr_mod.insert(
            "gt".to_string(),
            Scheme::mono(Ty::fun(
                vec![expr_t.clone(), expr_t.clone()],
                expr_t.clone(),
            )),
        );
        expr_mod.insert(
            "gte".to_string(),
            Scheme::mono(Ty::fun(
                vec![expr_t.clone(), expr_t.clone()],
                expr_t.clone(),
            )),
        );
        expr_mod.insert(
            "case".to_string(),
            Scheme::mono(Ty::fun(
                vec![
                    Ty::list(expr_t.clone()),
                    Ty::list(expr_t.clone()),
                    expr_t.clone(),
                ],
                expr_t.clone(),
            )),
        );
        expr_mod.insert(
            "case_when".to_string(),
            Scheme::mono(Ty::fun(
                vec![
                    Ty::list(expr_t.clone()),
                    Ty::list(expr_t.clone()),
                    expr_t.clone(),
                ],
                expr_t.clone(),
            )),
        );
        expr_mod.insert(
            "coalesce".to_string(),
            Scheme::mono(Ty::fun(vec![Ty::list(expr_t.clone())], expr_t.clone())),
        );
        expr_mod.insert(
            "excluded".to_string(),
            Scheme::mono(Ty::fun(vec![Ty::string()], expr_t.clone())),
        );
        expr_mod.insert(
            "alias".to_string(),
            Scheme::mono(Ty::fun(vec![expr_t.clone(), Ty::string()], expr_t.clone())),
        );
        expr_mod.insert(
            "label".to_string(),
            Scheme::mono(Ty::fun(vec![expr_t.clone(), Ty::string()], expr_t.clone())),
        );
        modules.insert("Expr".to_string(), expr_mod);
    }

    // ── Query module (Phase 98) ─────────────────────────────────────
    {
        let query_t = Ty::Con(TyCon::new("Query"));
        let expr_t = Ty::Con(TyCon::new("Expr"));
        let atom_t = Ty::Con(TyCon::new("Atom"));
        let mut query_mod = HashMap::new();
        // Query.from(String) -> Query
        query_mod.insert(
            "from".to_string(),
            Scheme::mono(Ty::fun(vec![Ty::string()], query_t.clone())),
        );
        // Query.where(Query, Atom, String) -> Query  (3-arg equality: field = value)
        query_mod.insert(
            "where".to_string(),
            Scheme::mono(Ty::fun(
                vec![query_t.clone(), atom_t.clone(), Ty::string()],
                query_t.clone(),
            )),
        );
        // Query.where_op(Query, Atom, Atom, String) -> Query  (4-arg operator: field op value)
        query_mod.insert(
            "where_op".to_string(),
            Scheme::mono(Ty::fun(
                vec![
                    query_t.clone(),
                    atom_t.clone(),
                    atom_t.clone(),
                    Ty::string(),
                ],
                query_t.clone(),
            )),
        );
        // Query.where_in(Query, Atom, List<String>) -> Query  (field IN values_list)
        query_mod.insert(
            "where_in".to_string(),
            Scheme::mono(Ty::fun(
                vec![query_t.clone(), atom_t.clone(), Ty::list(Ty::string())],
                query_t.clone(),
            )),
        );
        // Query.where_null(Query, Atom) -> Query  (field IS NULL)
        query_mod.insert(
            "where_null".to_string(),
            Scheme::mono(Ty::fun(
                vec![query_t.clone(), atom_t.clone()],
                query_t.clone(),
            )),
        );
        // Query.where_not_null(Query, Atom) -> Query  (field IS NOT NULL)
        query_mod.insert(
            "where_not_null".to_string(),
            Scheme::mono(Ty::fun(
                vec![query_t.clone(), atom_t.clone()],
                query_t.clone(),
            )),
        );
        // Query.where_not_in(Query, Atom, List<String>) -> Query  (field NOT IN (values...))
        query_mod.insert(
            "where_not_in".to_string(),
            Scheme::mono(Ty::fun(
                vec![query_t.clone(), atom_t.clone(), Ty::list(Ty::string())],
                query_t.clone(),
            )),
        );
        // Query.where_between(Query, Atom, String, String) -> Query  (field BETWEEN low AND high)
        query_mod.insert(
            "where_between".to_string(),
            Scheme::mono(Ty::fun(
                vec![query_t.clone(), atom_t.clone(), Ty::string(), Ty::string()],
                query_t.clone(),
            )),
        );
        // Query.where_or(Query, List<Atom>, List<String>) -> Query  ((field1 = $N OR field2 = $M))
        query_mod.insert(
            "where_or".to_string(),
            Scheme::mono(Ty::fun(
                vec![
                    query_t.clone(),
                    Ty::list(atom_t.clone()),
                    Ty::list(Ty::string()),
                ],
                query_t.clone(),
            )),
        );
        // Query.where_expr(Query, Query) -> Query  (structured expression predicate)
        query_mod.insert(
            "where_expr".to_string(),
            Scheme::mono(Ty::fun(
                vec![query_t.clone(), expr_t.clone()],
                query_t.clone(),
            )),
        );
        // Query.select(Query, List<String>) -> Query  (select fields list)
        query_mod.insert(
            "select".to_string(),
            Scheme::mono(Ty::fun(
                vec![query_t.clone(), Ty::list(Ty::string())],
                query_t.clone(),
            )),
        );
        // Query.select_expr(Query, Query) -> Query  (single structured SELECT expression)
        query_mod.insert(
            "select_expr".to_string(),
            Scheme::mono(Ty::fun(
                vec![query_t.clone(), expr_t.clone()],
                query_t.clone(),
            )),
        );
        // Query.select_exprs(Query, List<Expr>) -> Query  (structured SELECT expressions)
        query_mod.insert(
            "select_exprs".to_string(),
            Scheme::mono(Ty::fun(
                vec![query_t.clone(), Ty::list(expr_t.clone())],
                query_t.clone(),
            )),
        );
        // Query.order_by(Query, Atom, Atom) -> Query  (field atom, direction atom)
        query_mod.insert(
            "order_by".to_string(),
            Scheme::mono(Ty::fun(
                vec![query_t.clone(), atom_t.clone(), atom_t.clone()],
                query_t.clone(),
            )),
        );
        // Query.limit(Query, Int) -> Query
        query_mod.insert(
            "limit".to_string(),
            Scheme::mono(Ty::fun(vec![query_t.clone(), Ty::int()], query_t.clone())),
        );
        // Query.offset(Query, Int) -> Query
        query_mod.insert(
            "offset".to_string(),
            Scheme::mono(Ty::fun(vec![query_t.clone(), Ty::int()], query_t.clone())),
        );
        // Query.join(Query, Atom, String, String) -> Query  (type atom, table, on_clause)
        query_mod.insert(
            "join".to_string(),
            Scheme::mono(Ty::fun(
                vec![query_t.clone(), atom_t.clone(), Ty::string(), Ty::string()],
                query_t.clone(),
            )),
        );
        // Query.join_as(Query, Atom, String, String, String) -> Query  (type atom, table, alias, on_clause)
        query_mod.insert(
            "join_as".to_string(),
            Scheme::mono(Ty::fun(
                vec![
                    query_t.clone(),
                    atom_t.clone(),
                    Ty::string(),
                    Ty::string(),
                    Ty::string(),
                ],
                query_t.clone(),
            )),
        );
        // Query.group_by(Query, Atom) -> Query  (field atom)
        query_mod.insert(
            "group_by".to_string(),
            Scheme::mono(Ty::fun(
                vec![query_t.clone(), atom_t.clone()],
                query_t.clone(),
            )),
        );
        // Query.having(Query, String, String) -> Query  (clause, value)
        query_mod.insert(
            "having".to_string(),
            Scheme::mono(Ty::fun(
                vec![query_t.clone(), Ty::string(), Ty::string()],
                query_t.clone(),
            )),
        );
        // Query.fragment(Query, String, List<String>) -> Query  (raw sql, params list)
        query_mod.insert(
            "fragment".to_string(),
            Scheme::mono(Ty::fun(
                vec![query_t.clone(), Ty::string(), Ty::list(Ty::string())],
                query_t.clone(),
            )),
        );
        // Query.select_raw(Query, List<String>) -> Query  (raw SQL expressions list)
        query_mod.insert(
            "select_raw".to_string(),
            Scheme::mono(Ty::fun(
                vec![query_t.clone(), Ty::list(Ty::string())],
                query_t.clone(),
            )),
        );
        // Query.where_raw(Query, String, List<String>) -> Query  (raw clause, params list)
        query_mod.insert(
            "where_raw".to_string(),
            Scheme::mono(Ty::fun(
                vec![query_t.clone(), Ty::string(), Ty::list(Ty::string())],
                query_t.clone(),
            )),
        );
        // Query.order_by_raw(Query, String) -> Query  (raw ORDER BY expression)
        query_mod.insert(
            "order_by_raw".to_string(),
            Scheme::mono(Ty::fun(
                vec![query_t.clone(), Ty::string()],
                query_t.clone(),
            )),
        );
        // Query.group_by_raw(Query, String) -> Query  (raw GROUP BY expression)
        query_mod.insert(
            "group_by_raw".to_string(),
            Scheme::mono(Ty::fun(
                vec![query_t.clone(), Ty::string()],
                query_t.clone(),
            )),
        );
        // ── Phase 108: Aggregate SELECT functions ─────────────────────────
        // Query.select_count(Query) -> Query  (count all rows)
        query_mod.insert(
            "select_count".to_string(),
            Scheme::mono(Ty::fun(vec![query_t.clone()], query_t.clone())),
        );
        // Query.select_count_field(Query, Atom) -> Query  (count specific field)
        query_mod.insert(
            "select_count_field".to_string(),
            Scheme::mono(Ty::fun(
                vec![query_t.clone(), atom_t.clone()],
                query_t.clone(),
            )),
        );
        // Query.select_sum(Query, Atom) -> Query
        query_mod.insert(
            "select_sum".to_string(),
            Scheme::mono(Ty::fun(
                vec![query_t.clone(), atom_t.clone()],
                query_t.clone(),
            )),
        );
        // Query.select_avg(Query, Atom) -> Query
        query_mod.insert(
            "select_avg".to_string(),
            Scheme::mono(Ty::fun(
                vec![query_t.clone(), atom_t.clone()],
                query_t.clone(),
            )),
        );
        // Query.select_min(Query, Atom) -> Query
        query_mod.insert(
            "select_min".to_string(),
            Scheme::mono(Ty::fun(
                vec![query_t.clone(), atom_t.clone()],
                query_t.clone(),
            )),
        );
        // Query.select_max(Query, Atom) -> Query
        query_mod.insert(
            "select_max".to_string(),
            Scheme::mono(Ty::fun(
                vec![query_t.clone(), atom_t.clone()],
                query_t.clone(),
            )),
        );
        // ── Phase 109: Subquery WHERE ─────────────────────────────────────
        // Query.where_sub(Query, Atom, Query) -> Query  (query, field, sub_query)
        query_mod.insert(
            "where_sub".to_string(),
            Scheme::mono(Ty::fun(
                vec![query_t.clone(), atom_t.clone(), query_t.clone()],
                query_t.clone(),
            )),
        );
        modules.insert("Query".to_string(), query_mod);
    }

    // ── Repo module (Phase 98) ──────────────────────────────────────
    {
        let query_t = Ty::Con(TyCon::new("Query"));
        let expr_t = Ty::Con(TyCon::new("Expr"));
        let changeset_t = Ty::Con(TyCon::new("Changeset"));
        let pool_t = Ty::Con(TyCon::new("PoolHandle"));
        let mut repo_mod = HashMap::new();
        // Repo.all(PoolHandle, Query) -> Result<List<Map<String,String>>, String>  (pool, query)
        repo_mod.insert(
            "all".to_string(),
            Scheme::mono(Ty::fun(
                vec![pool_t.clone(), query_t.clone()],
                Ty::result(Ty::list(Ty::map(Ty::string(), Ty::string())), Ty::string()),
            )),
        );
        // Repo.one(PoolHandle, Query) -> Result<Map<String,String>, String>
        repo_mod.insert(
            "one".to_string(),
            Scheme::mono(Ty::fun(
                vec![pool_t.clone(), query_t.clone()],
                Ty::result(Ty::map(Ty::string(), Ty::string()), Ty::string()),
            )),
        );
        // Repo.get(PoolHandle, String, String) -> Result<Map<String,String>, String>  (pool, table, id)
        repo_mod.insert(
            "get".to_string(),
            Scheme::mono(Ty::fun(
                vec![pool_t.clone(), Ty::string(), Ty::string()],
                Ty::result(Ty::map(Ty::string(), Ty::string()), Ty::string()),
            )),
        );
        // Repo.get_by(PoolHandle, String, String, String) -> Result<Map<String,String>, String>  (pool, table, field, value)
        repo_mod.insert(
            "get_by".to_string(),
            Scheme::mono(Ty::fun(
                vec![pool_t.clone(), Ty::string(), Ty::string(), Ty::string()],
                Ty::result(Ty::map(Ty::string(), Ty::string()), Ty::string()),
            )),
        );
        // Repo.count(PoolHandle, Query) -> Result<Int, String>
        repo_mod.insert(
            "count".to_string(),
            Scheme::mono(Ty::fun(
                vec![pool_t.clone(), query_t.clone()],
                Ty::result(Ty::int(), Ty::string()),
            )),
        );
        // Repo.exists(PoolHandle, Query) -> Result<Bool, String>
        repo_mod.insert(
            "exists".to_string(),
            Scheme::mono(Ty::fun(
                vec![pool_t.clone(), query_t.clone()],
                Ty::result(Ty::bool(), Ty::string()),
            )),
        );
        // Repo.insert(PoolHandle, String, Map<String,String>) -> Result<Map<String,String>, String>  (pool, table, fields_map)
        repo_mod.insert(
            "insert".to_string(),
            Scheme::mono(Ty::fun(
                vec![
                    pool_t.clone(),
                    Ty::string(),
                    Ty::map(Ty::string(), Ty::string()),
                ],
                Ty::result(Ty::map(Ty::string(), Ty::string()), Ty::string()),
            )),
        );
        // Repo.insert_expr(PoolHandle, String, Map<String,Expr>) -> Result<Map<String,String>, String>
        repo_mod.insert(
            "insert_expr".to_string(),
            Scheme::mono(Ty::fun(
                vec![
                    pool_t.clone(),
                    Ty::string(),
                    Ty::map(Ty::string(), expr_t.clone()),
                ],
                Ty::result(Ty::map(Ty::string(), Ty::string()), Ty::string()),
            )),
        );
        // Repo.update(PoolHandle, String, String, Map<String,String>) -> Result<Map<String,String>, String>
        repo_mod.insert(
            "update".to_string(),
            Scheme::mono(Ty::fun(
                vec![
                    pool_t.clone(),
                    Ty::string(),
                    Ty::string(),
                    Ty::map(Ty::string(), Ty::string()),
                ],
                Ty::result(Ty::map(Ty::string(), Ty::string()), Ty::string()),
            )),
        );
        // Repo.delete(PoolHandle, String, String) -> Result<Map<String,String>, String>  (pool, table, id)
        repo_mod.insert(
            "delete".to_string(),
            Scheme::mono(Ty::fun(
                vec![pool_t.clone(), Ty::string(), Ty::string()],
                Ty::result(Ty::map(Ty::string(), Ty::string()), Ty::string()),
            )),
        );
        // Repo.transaction(PoolHandle, fn(borrow PgConn) -> Result<T, String>)
        //   -> Result<T, String>
        // Ownership mode is enforced separately; the HM type records the
        // scoped connection and preserves the callback's success value.
        let transaction_value = TyVar(99992);
        let transaction_value_ty = Ty::Var(transaction_value);
        repo_mod.insert(
            "transaction".to_string(),
            Scheme {
                vars: vec![transaction_value],
                ty: Ty::fun(
                    vec![
                        pool_t.clone(),
                        Ty::fun(
                            vec![pg_conn_t.clone()],
                            Ty::result(transaction_value_ty.clone(), Ty::string()),
                        ),
                    ],
                    Ty::result(transaction_value_ty, Ty::string()),
                ),
            },
        );
        // ── Phase 103: Extended Repo Write Operations ────────────────────
        // Repo.update_where(PoolHandle, String, Map<String,String>, Query) -> Result<Map<String,String>, String>  (pool, table, fields_map, query)
        repo_mod.insert(
            "update_where".to_string(),
            Scheme::mono(Ty::fun(
                vec![
                    pool_t.clone(),
                    Ty::string(),
                    Ty::map(Ty::string(), Ty::string()),
                    query_t.clone(),
                ],
                Ty::result(Ty::map(Ty::string(), Ty::string()), Ty::string()),
            )),
        );
        // Repo.update_where_expr(PoolHandle, String, Map<String,Expr>, Query) -> Result<Map<String,String>, String>
        repo_mod.insert(
            "update_where_expr".to_string(),
            Scheme::mono(Ty::fun(
                vec![
                    pool_t.clone(),
                    Ty::string(),
                    Ty::map(Ty::string(), expr_t.clone()),
                    query_t.clone(),
                ],
                Ty::result(Ty::map(Ty::string(), Ty::string()), Ty::string()),
            )),
        );
        // Repo.delete_where(PoolHandle, String, Query) -> Result<Int, String>  (pool, table, query)
        repo_mod.insert(
            "delete_where".to_string(),
            Scheme::mono(Ty::fun(
                vec![pool_t.clone(), Ty::string(), query_t.clone()],
                Ty::result(Ty::int(), Ty::string()),
            )),
        );
        // Repo.query_raw(PoolHandle, String, List<String>) -> Result<List<Map<String,String>>, String>
        repo_mod.insert(
            "query_raw".to_string(),
            Scheme::mono(Ty::fun(
                vec![pool_t.clone(), Ty::string(), Ty::list(Ty::string())],
                Ty::result(Ty::list(Ty::map(Ty::string(), Ty::string())), Ty::string()),
            )),
        );
        // Repo.execute_raw(PoolHandle, String, List<String>) -> Result<Int, String>
        repo_mod.insert(
            "execute_raw".to_string(),
            Scheme::mono(Ty::fun(
                vec![pool_t.clone(), Ty::string(), Ty::list(Ty::string())],
                Ty::result(Ty::int(), Ty::string()),
            )),
        );
        // ── Phase 109: Upsert, RETURNING, Subquery ────────────────────────
        // Repo.insert_or_update(PoolHandle, String, Map<String,String>, List<String>, List<String>) -> Result<Map<String,String>, String>
        repo_mod.insert(
            "insert_or_update".to_string(),
            Scheme::mono(Ty::fun(
                vec![
                    pool_t.clone(),
                    Ty::string(),
                    Ty::map(Ty::string(), Ty::string()),
                    Ty::list(Ty::string()),
                    Ty::list(Ty::string()),
                ],
                Ty::result(Ty::map(Ty::string(), Ty::string()), Ty::string()),
            )),
        );
        // Repo.insert_or_update_expr(PoolHandle, String, Map<String,String>, List<String>, Map<String,Expr>) -> Result<Map<String,String>, String>
        repo_mod.insert(
            "insert_or_update_expr".to_string(),
            Scheme::mono(Ty::fun(
                vec![
                    pool_t.clone(),
                    Ty::string(),
                    Ty::map(Ty::string(), Ty::string()),
                    Ty::list(Ty::string()),
                    Ty::map(Ty::string(), expr_t.clone()),
                ],
                Ty::result(Ty::map(Ty::string(), Ty::string()), Ty::string()),
            )),
        );
        // Repo.delete_where_returning(PoolHandle, String, Query) -> Result<List<Map<String,String>>, String>
        repo_mod.insert(
            "delete_where_returning".to_string(),
            Scheme::mono(Ty::fun(
                vec![pool_t.clone(), Ty::string(), query_t.clone()],
                Ty::result(Ty::list(Ty::map(Ty::string(), Ty::string())), Ty::string()),
            )),
        );
        // ── Phase 99: Repo Changeset Operations ────────────────────────
        // Repo.insert_changeset(PoolHandle, String, Changeset) -> Result<Map<String,String>, Changeset>
        repo_mod.insert(
            "insert_changeset".to_string(),
            Scheme::mono(Ty::fun(
                vec![pool_t.clone(), Ty::string(), changeset_t.clone()],
                Ty::result(Ty::map(Ty::string(), Ty::string()), changeset_t.clone()),
            )),
        );
        // Repo.update_changeset(PoolHandle, String, String, Changeset) -> Result<Map<String,String>, Changeset>
        repo_mod.insert(
            "update_changeset".to_string(),
            Scheme::mono(Ty::fun(
                vec![
                    pool_t.clone(),
                    Ty::string(),
                    Ty::string(),
                    changeset_t.clone(),
                ],
                Ty::result(Ty::map(Ty::string(), Ty::string()), changeset_t.clone()),
            )),
        );
        // ── Phase 100: Repo Preloading ───────────────────────────────────
        // Repo.preload(pool, rows, associations, relationship_meta) -> Result<List<Map>, String>
        repo_mod.insert(
            "preload".to_string(),
            Scheme::mono(Ty::fun(
                vec![
                    pool_t.clone(),
                    Ty::list(Ty::map(Ty::string(), Ty::string())),
                    Ty::list(Ty::string()),
                    Ty::list(Ty::string()),
                ],
                Ty::result(Ty::list(Ty::map(Ty::string(), Ty::string())), Ty::string()),
            )),
        );
        modules.insert("Repo".to_string(), repo_mod);
    }

    // ── Changeset module (Phase 99) ──────────────────────────────────
    {
        let changeset_t = Ty::Con(TyCon::new("Changeset"));
        let atom_t = Ty::Con(TyCon::new("Atom"));
        let map_ss = Ty::map(Ty::string(), Ty::string());
        let list_atom = Ty::list(atom_t.clone());
        let list_str = Ty::list(Ty::string());
        let mut cs_mod = HashMap::new();

        // Changeset.cast(Map<String,String>, Map<String,String>, List<Atom>) -> Changeset
        cs_mod.insert(
            "cast".to_string(),
            Scheme::mono(Ty::fun(
                vec![map_ss.clone(), map_ss.clone(), list_atom.clone()],
                changeset_t.clone(),
            )),
        );
        // Changeset.cast_with_types(Map<String,String>, Map<String,String>, List<Atom>, List<String>) -> Changeset
        cs_mod.insert(
            "cast_with_types".to_string(),
            Scheme::mono(Ty::fun(
                vec![
                    map_ss.clone(),
                    map_ss.clone(),
                    list_atom.clone(),
                    list_str.clone(),
                ],
                changeset_t.clone(),
            )),
        );

        // Changeset.validate_required(Changeset, List<Atom>) -> Changeset
        cs_mod.insert(
            "validate_required".to_string(),
            Scheme::mono(Ty::fun(
                vec![changeset_t.clone(), list_atom.clone()],
                changeset_t.clone(),
            )),
        );
        // Changeset.validate_length(Changeset, Atom, Int, Int) -> Changeset
        cs_mod.insert(
            "validate_length".to_string(),
            Scheme::mono(Ty::fun(
                vec![changeset_t.clone(), atom_t.clone(), Ty::int(), Ty::int()],
                changeset_t.clone(),
            )),
        );
        // Changeset.validate_format(Changeset, Atom, String) -> Changeset
        cs_mod.insert(
            "validate_format".to_string(),
            Scheme::mono(Ty::fun(
                vec![changeset_t.clone(), atom_t.clone(), Ty::string()],
                changeset_t.clone(),
            )),
        );
        // Changeset.validate_inclusion(Changeset, Atom, List<String>) -> Changeset
        cs_mod.insert(
            "validate_inclusion".to_string(),
            Scheme::mono(Ty::fun(
                vec![changeset_t.clone(), atom_t.clone(), list_str.clone()],
                changeset_t.clone(),
            )),
        );
        // Changeset.validate_number(Changeset, Atom, Int, Int, Int, Int) -> Changeset
        cs_mod.insert(
            "validate_number".to_string(),
            Scheme::mono(Ty::fun(
                vec![
                    changeset_t.clone(),
                    atom_t.clone(),
                    Ty::int(),
                    Ty::int(),
                    Ty::int(),
                    Ty::int(),
                ],
                changeset_t.clone(),
            )),
        );

        // Changeset.valid(Changeset) -> Bool
        cs_mod.insert(
            "valid".to_string(),
            Scheme::mono(Ty::fun(vec![changeset_t.clone()], Ty::bool())),
        );
        // Changeset.errors(Changeset) -> Map<String,String>
        cs_mod.insert(
            "errors".to_string(),
            Scheme::mono(Ty::fun(vec![changeset_t.clone()], map_ss.clone())),
        );
        // Changeset.changes(Changeset) -> Map<String,String>
        cs_mod.insert(
            "changes".to_string(),
            Scheme::mono(Ty::fun(vec![changeset_t.clone()], map_ss.clone())),
        );
        // Changeset.get_change(Changeset, Atom) -> String
        cs_mod.insert(
            "get_change".to_string(),
            Scheme::mono(Ty::fun(
                vec![changeset_t.clone(), atom_t.clone()],
                Ty::string(),
            )),
        );
        // Changeset.get_error(Changeset, Atom) -> String
        cs_mod.insert(
            "get_error".to_string(),
            Scheme::mono(Ty::fun(
                vec![changeset_t.clone(), atom_t.clone()],
                Ty::string(),
            )),
        );

        modules.insert("Changeset".to_string(), cs_mod);
    }

    // ── Migration module (Phase 101) ──────────────────────────────────
    {
        let pool_t = Ty::Con(TyCon::new("PoolHandle"));
        let result_t = Ty::result(Ty::int(), Ty::string());
        let mut migration_mod = HashMap::new();

        // Migration.create_table: fn(PoolHandle, String, List<String>) -> Result<Int, String>
        migration_mod.insert(
            "create_table".to_string(),
            Scheme::mono(Ty::fun(
                vec![pool_t.clone(), Ty::string(), Ty::list(Ty::string())],
                result_t.clone(),
            )),
        );
        // Migration.drop_table: fn(PoolHandle, String) -> Result<Int, String>
        migration_mod.insert(
            "drop_table".to_string(),
            Scheme::mono(Ty::fun(
                vec![pool_t.clone(), Ty::string()],
                result_t.clone(),
            )),
        );
        // Migration.add_column: fn(PoolHandle, String, String) -> Result<Int, String>
        migration_mod.insert(
            "add_column".to_string(),
            Scheme::mono(Ty::fun(
                vec![pool_t.clone(), Ty::string(), Ty::string()],
                result_t.clone(),
            )),
        );
        // Migration.drop_column: fn(PoolHandle, String, String) -> Result<Int, String>
        migration_mod.insert(
            "drop_column".to_string(),
            Scheme::mono(Ty::fun(
                vec![pool_t.clone(), Ty::string(), Ty::string()],
                result_t.clone(),
            )),
        );
        // Migration.rename_column: fn(PoolHandle, String, String, String) -> Result<Int, String>
        migration_mod.insert(
            "rename_column".to_string(),
            Scheme::mono(Ty::fun(
                vec![pool_t.clone(), Ty::string(), Ty::string(), Ty::string()],
                result_t.clone(),
            )),
        );
        // Migration.create_index: fn(PoolHandle, String, List<String>, String) -> Result<Int, String>
        migration_mod.insert(
            "create_index".to_string(),
            Scheme::mono(Ty::fun(
                vec![
                    pool_t.clone(),
                    Ty::string(),
                    Ty::list(Ty::string()),
                    Ty::string(),
                ],
                result_t.clone(),
            )),
        );
        // Migration.drop_index: fn(PoolHandle, String, List<String>) -> Result<Int, String>
        migration_mod.insert(
            "drop_index".to_string(),
            Scheme::mono(Ty::fun(
                vec![pool_t.clone(), Ty::string(), Ty::list(Ty::string())],
                result_t.clone(),
            )),
        );
        // Migration.execute: fn(PoolHandle, String) -> Result<Int, String>
        migration_mod.insert(
            "execute".to_string(),
            Scheme::mono(Ty::fun(
                vec![pool_t.clone(), Ty::string()],
                result_t.clone(),
            )),
        );

        modules.insert("Migration".to_string(), migration_mod);
    }

    modules
}

/// Infer types for a parsed Mesh program.
///
/// This is the main entry point for single-module type checking.
/// Delegates to `infer_with_imports` with an empty ImportContext.
pub fn infer(parse: &Parse) -> TypeckResult {
    infer_with_imports(parse, &ImportContext::empty())
}

/// Infer types for a parsed Mesh program with pre-resolved imports.
///
/// This is the multi-module entry point. The ImportContext contains
/// symbols from already-type-checked dependency modules, which are
/// pre-seeded into the type environments before inference begins.
pub fn infer_with_imports(parse: &Parse, import_ctx: &ImportContext) -> TypeckResult {
    let mut ctx = InferCtx::new();
    ctx.project_modules = import_ctx.project_modules.clone();
    ctx.current_module = import_ctx.current_module.clone();
    ctx.test_builtins = import_ctx.test_builtins;
    let mut env = TypeEnv::new();
    let mut trait_registry = TraitRegistry::new();
    let mut type_registry = TypeRegistry::new();
    builtins::register_builtins(&mut ctx, &mut env, &mut trait_registry);
    register_builtin_sum_types(&mut ctx, &mut env, &mut type_registry);
    register_crypto_v2_types(&mut type_registry);
    // A connection is a unique raw runtime capability. Treating it as a value
    // would permit aliases to close or concurrently mutate the same PgConn.
    type_registry.register_resource_type("PgConn");

    // Register stdlib struct types for field access (Phase 137+)
    // Layouts MUST match the Mesh-facing runtime structs allocated in mesh-rt.
    type_registry.register_struct(StructDefInfo {
        name: "HttpResponse".to_string(),
        generic_params: vec![],
        fields: vec![
            ("status".to_string(), Ty::int()),
            ("body".to_string(), Ty::string()),
            ("headers".to_string(), Ty::map(Ty::string(), Ty::string())),
            ("body_bytes".to_string(), Ty::bytes()),
        ],
        schema: None,
    });
    type_registry.register_struct(StructDefInfo {
        name: "HttpClientMetrics".to_string(),
        generic_params: vec![],
        fields: vec![
            ("requests".to_string(), Ty::int()),
            ("in_flight".to_string(), Ty::int()),
            ("dns_micros".to_string(), Ty::int()),
            ("connect_micros".to_string(), Ty::int()),
            ("tls_micros".to_string(), Ty::int()),
            ("dns_failures".to_string(), Ty::int()),
            ("connect_failures".to_string(), Ty::int()),
            ("tls_failures".to_string(), Ty::int()),
            ("timeouts".to_string(), Ty::int()),
            ("first_byte_micros".to_string(), Ty::int()),
            ("total_micros".to_string(), Ty::int()),
            ("response_bytes".to_string(), Ty::int()),
            ("cancellations".to_string(), Ty::int()),
        ],
        schema: None,
    });
    type_registry.register_struct(StructDefInfo {
        name: "WsMessage".to_string(),
        generic_params: vec![],
        fields: vec![
            ("kind".to_string(), Ty::string()),
            ("data".to_string(), Ty::bytes()),
            ("close_code".to_string(), Ty::int()),
            ("close_reason".to_string(), Ty::string()),
        ],
        schema: None,
    });
    type_registry.register_struct(StructDefInfo {
        name: "BootstrapStatus".to_string(),
        generic_params: vec![],
        fields: vec![
            ("mode".to_string(), Ty::string()),
            ("node_name".to_string(), Ty::string()),
            ("cluster_port".to_string(), Ty::int()),
            ("discovery_seed".to_string(), Ty::string()),
        ],
        schema: None,
    });
    type_registry.register_struct(StructDefInfo {
        name: "ContinuityAuthorityStatus".to_string(),
        generic_params: vec![],
        fields: vec![
            ("cluster_role".to_string(), Ty::string()),
            ("promotion_epoch".to_string(), Ty::int()),
            ("replication_health".to_string(), Ty::string()),
        ],
        schema: None,
    });
    type_registry.register_struct(StructDefInfo {
        name: "ContinuityRecord".to_string(),
        generic_params: vec![],
        fields: vec![
            ("request_key".to_string(), Ty::string()),
            ("payload_hash".to_string(), Ty::string()),
            ("attempt_id".to_string(), Ty::string()),
            ("phase".to_string(), Ty::string()),
            ("result".to_string(), Ty::string()),
            ("ingress_node".to_string(), Ty::string()),
            ("owner_node".to_string(), Ty::string()),
            ("replica_node".to_string(), Ty::string()),
            ("replication_count".to_string(), Ty::int()),
            ("replica_status".to_string(), Ty::string()),
            ("cluster_role".to_string(), Ty::string()),
            ("promotion_epoch".to_string(), Ty::int()),
            ("replication_health".to_string(), Ty::string()),
            ("execution_node".to_string(), Ty::string()),
            ("routed_remotely".to_string(), Ty::bool()),
            ("fell_back_locally".to_string(), Ty::bool()),
            ("error".to_string(), Ty::string()),
        ],
        schema: None,
    });
    type_registry.register_struct(StructDefInfo {
        name: "ContinuitySubmitDecision".to_string(),
        generic_params: vec![],
        fields: vec![
            ("outcome".to_string(), Ty::string()),
            ("conflict_reason".to_string(), Ty::string()),
            (
                "record".to_string(),
                Ty::Con(TyCon::new("ContinuityRecord")),
            ),
        ],
        schema: None,
    });

    let builtin_types = builtin_type_names(&env, &type_registry, &trait_registry);
    ctx.builtin_types = builtin_types.clone();

    // Pre-seed with imported trait defs (XMOD-05: globally visible)
    for trait_def in &import_ctx.all_trait_defs {
        trait_registry.register_trait(trait_def.clone());
    }
    for impl_def in &import_ctx.all_trait_impls {
        trait_registry.register_imported_impl(impl_def.clone());
    }

    // Pre-seed TypeRegistry and TypeEnv with imported struct definitions
    for mod_exports in import_ctx.module_exports.values() {
        for resource_type in &mod_exports.resource_types {
            type_registry.register_resource_type(resource_type.clone());
        }
        type_registry
            .plaintext_types
            .extend(mod_exports.plaintext_types.iter().cloned());
        for (name, struct_def) in &mod_exports.struct_defs {
            type_registry.register_struct(struct_def.clone());
            // Register struct constructor in env with display_prefix set to source module
            let module_path = &mod_exports.module_name;
            let qualifier = module_path.rsplit('.').next().unwrap_or(module_path);
            let display = if import_ctx
                .module_at_qualifier(qualifier)
                .is_some_and(|module| module.module_name == *module_path)
            {
                qualifier
            } else {
                module_path
            };
            let tycon = TyCon::with_module(name, display);
            let struct_ty = if struct_def.generic_params.is_empty() {
                Ty::App(Box::new(Ty::Con(tycon)), vec![])
            } else {
                let type_args: Vec<Ty> = struct_def
                    .generic_params
                    .iter()
                    .map(|_| ctx.fresh_var())
                    .collect();
                Ty::App(Box::new(Ty::Con(tycon)), type_args)
            };
            env.insert(name.clone(), Scheme::mono(struct_ty));
        }
    }

    let tree = parse.tree();
    check_index_syntax(&mut ctx, tree.syntax());
    let proof_values = crate::proof_values::collect(&tree, import_ctx);
    type_registry.proof_predicates = proof_values.predicates;
    ctx.errors.extend(proof_values.errors);

    // Pre-seed with imported sum type definitions.
    for (path, mod_exports) in &import_ctx.module_exports {
        for sum_type_def in mod_exports.sum_type_defs.values() {
            type_registry.check_indexed_layout_collision(
                &mut ctx,
                &sum_type_def.name,
                sum_type_def
                    .indexed
                    .as_ref()
                    .map(|info| info.origin.as_str()),
                TextRange::empty(tree.syntax().text_range().start()),
            );
            let qualifiers = import_ctx
                .module_qualifiers
                .iter()
                .filter(|(_, target)| *target == path || **target == mod_exports.module_name)
                .map(|(qualifier, _)| qualifier.clone());
            type_registry.register_imported_sum_type(
                sum_type_def,
                &mod_exports.module_name,
                qualifiers.chain([path.clone()]),
            );
            register_variant_constructors(
                &mut ctx,
                &mut env,
                &sum_type_def.name,
                &sum_type_def.generic_params,
                &sum_type_def.variants,
            );
        }
    }

    // Pre-register imported type aliases so they are available for resolution
    // in the current module's type annotations (ALIAS-03).
    // Register under both the short name ("UserId") and the qualified name
    // ("Types.UserId") so that annotations like `:: Types.UserId` resolve
    // correctly when the annotation parser emits a qualified key.
    for mod_exports in import_ctx.module_exports.values() {
        for alias_info in mod_exports.type_aliases.values() {
            // Unqualified: `UserId`
            type_registry.register_alias(alias_info.clone());
            // Qualified: `Types.UserId`
            let path = &mod_exports.module_name;
            type_registry.register_alias(TypeAliasInfo {
                name: format!("{path}.{}", alias_info.name),
                ..alias_info.clone()
            });
            if let Some((_, short)) = path.rsplit_once('.') {
                if import_ctx
                    .module_at_qualifier(short)
                    .is_some_and(|module| module.module_name == *path)
                {
                    type_registry.register_alias(TypeAliasInfo {
                        name: format!("{short}.{}", alias_info.name),
                        ..alias_info.clone()
                    });
                }
            }
        }
    }

    let mut types = FxHashMap::default();
    let mut fn_constraints: FxHashMap<String, FnConstraints> = FxHashMap::default();
    let mut default_method_bodies: FxHashMap<(String, String), TextRange> = FxHashMap::default();

    // Collect all children and separate items from bare expressions.
    // Items are grouped to detect multi-clause functions before inference.
    let mut children_ordered: Vec<(TextRange, ChildKind)> = Vec::new();
    let mut items_for_grouping: Vec<Item> = Vec::new();

    for child in tree.syntax().children() {
        let range = child.text_range();
        if let Some(item) = Item::cast(child.clone()) {
            children_ordered.push((range, ChildKind::ItemIndex(items_for_grouping.len())));
            items_for_grouping.push(item);
        } else if let Some(expr) = Expr::cast(child) {
            children_ordered.push((range, ChildKind::Expr(expr)));
        }
    }

    // ── ALIAS-04: Pre-registration pass ──────────────────────────────────
    // Before the main inference loop, pre-register all type aliases so that
    // forward references (e.g., alias B used before alias A that equals B)
    // resolve correctly. Also pre-register struct and sum type names (by scanning
    // items) so alias validation can check against locally-defined types.
    //
    // We collect (TypeAliasDef, TextRange) tuples during this pass for
    // subsequent validation.
    let mut alias_defs_for_validation: Vec<(TypeAliasDef, TextRange)> = Vec::new();

    for child in file_items(tree.syntax().clone(), import_ctx) {
        let range = child.text_range();
        let item = Item::cast(child);
        let type_name = match &item {
            Some(Item::TypeAliasDef(def)) => def.name(),
            Some(Item::StructDef(def)) => def.name(),
            Some(Item::SumTypeDef(def)) => def.name(),
            _ => None,
        };
        if let Some(name) = type_name {
            if name.text().as_deref() == Some(crate::proof_values::PROOF_TYPE) {
                ctx.errors.push(TypeError::ReservedProofName {
                    span: name.syntax().text_range(),
                });
                continue;
            }
        }
        match item {
            Some(Item::TypeAliasDef(alias_def)) => {
                register_type_alias(&alias_def, &mut type_registry);
                alias_defs_for_validation.push((alias_def, range));
            }
            Some(Item::StructDef(struct_def)) => {
                // Pre-register struct name so alias validation can reference it.
                let name = struct_def
                    .name()
                    .and_then(|n| n.text())
                    .unwrap_or_else(|| "<unnamed>".to_string());
                type_registry.check_indexed_layout_collision(
                    &mut ctx,
                    &name,
                    None,
                    significant_range(struct_def.syntax()),
                );
                // Only register the name stub, with the struct's parameters
                // (a struct naming one declared later takes them): full
                // registration happens in the main loop.
                if struct_def.is_declared_resource() {
                    type_registry.register_resource_type(name.clone());
                }
                trait_registry.register_nominal(&name);
                if struct_def.deriving_traits().iter().any(|t| t == "Json") {
                    ctx.json_types.insert(name.clone());
                }
                type_registry.register_struct(StructDefInfo {
                    name,
                    generic_params: generic_param_names(struct_def.syntax()),
                    fields: vec![],
                    schema: None,
                });
            }
            Some(Item::SumTypeDef(sum_def)) => {
                // Pre-register sum type name so alias validation can reference it.
                let name = sum_def
                    .name()
                    .and_then(|n| n.text())
                    .unwrap_or_else(|| "<unnamed>".to_string());
                let indexed = index_family_info(
                    sum_def.syntax(),
                    ctx.current_module.as_deref().unwrap_or_default(),
                );
                type_registry.check_indexed_layout_collision(
                    &mut ctx,
                    &name,
                    indexed.as_ref().map(|info| info.origin.as_str()),
                    significant_range(sum_def.syntax()),
                );
                trait_registry.register_nominal(&name);
                if indexed.is_none() && sum_def.deriving_traits().iter().any(|t| t == "Json") {
                    ctx.json_types.insert(name.clone());
                }
                // With its parameters, which a variant naming the type
                // itself (`Node(Tree<T>)`) gives it.
                type_registry.register_sum_type(SumTypeDefInfo {
                    name,
                    generic_params: generic_param_names(sum_def.syntax()),
                    indexed,
                    variants: vec![],
                });
            }
            _ => {}
        }
    }

    // Check and fix the identity of indexed types in alias templates while
    // the defining module's names are in scope.
    for (alias, span) in &alias_defs_for_validation {
        let Some(name) = alias.name().and_then(|name| name.text()) else {
            continue;
        };
        let aliased = type_registry.type_aliases[&name].aliased_type.clone();
        match check_indexed_type(aliased, alias.syntax(), &type_registry, *span) {
            Ok(ty) => {
                let info = type_registry
                    .type_aliases
                    .get_mut(&name)
                    .expect("pre-registered alias");
                info.aliased_type = ty;
            }
            Err(error) => ctx.errors.push(error),
        }
    }
    validate_type_aliases(
        &mut ctx,
        &type_registry,
        &alias_defs_for_validation,
        &builtin_types,
        import_ctx,
    );

    // Resolve struct field metadata before value-trait registration so affine
    // containment is known even through forward and transitive references.
    for child in file_items(tree.syntax().clone(), import_ctx) {
        let Some(Item::StructDef(struct_def)) = Item::cast(child) else {
            continue;
        };
        let name = struct_def
            .name()
            .and_then(|name| name.text())
            .unwrap_or_else(|| "<unnamed>".to_string());
        let generic_params = generic_param_names(struct_def.syntax());
        let fields = struct_def
            .fields()
            .map(|field| {
                let field_name = field
                    .name()
                    .and_then(|field_name| field_name.text())
                    .unwrap_or_else(|| "<unnamed>".to_string());
                let field_ty = field
                    .type_annotation()
                    .and_then(|annotation| {
                        resolve_type_annotation(&mut ctx, &annotation, &type_registry)
                    })
                    .unwrap_or_else(|| ctx.fresh_var());
                (field_name, field_ty)
            })
            .collect();
        trait_registry.register_nominal(&name);
        type_registry.register_struct(StructDefInfo {
            name,
            generic_params,
            fields,
            schema: None,
        });
    }
    for child in file_items(tree.syntax().clone(), import_ctx) {
        let Some(Item::SumTypeDef(sum_def)) = Item::cast(child) else {
            continue;
        };
        let info = sum_type_def_info(&mut ctx, &sum_def, &type_registry);
        type_registry.register_sum_type(info);
    }
    type_registry.propagate_resource_containment();
    trait_registry.set_plaintext_types(type_registry.plaintext_types.clone());

    check_annotation_types(
        &mut ctx,
        tree.syntax(),
        &type_registry,
        &builtin_types,
        import_ctx,
    );

    // Group consecutive same-name, same-arity FnDef items.
    let grouped = group_multi_clause_fns(items_for_grouping);

    // Check for non-consecutive same-name function definitions.
    check_non_consecutive_clauses(&grouped, &mut ctx);

    // Record visibility, and the names defined at more than one arity: each
    // arity is its own function (`name__N`), dispatched by argument count.
    {
        let mut arities: FxHashMap<String, FxHashSet<usize>> = FxHashMap::default();
        for gi in &grouped {
            let first = match gi {
                GroupedItem::Single(Item::FnDef(fn_)) => Some(fn_),
                GroupedItem::MultiClause { clauses } => clauses.first(),
                _ => None,
            };
            let Some(first) = first else { continue };
            let Some(name) = first.name().and_then(|n| n.text()) else {
                continue;
            };
            ctx.top_level_function_visibility
                .entry(name.clone())
                .and_modify(|visible| *visible |= first.visibility().is_some())
                .or_insert(first.visibility().is_some());
            arities.entry(name).or_default().insert(fn_arity(first));
        }
        ctx.overloaded_fn_names = arities
            .into_iter()
            .filter(|(_, arities)| arities.len() > 1)
            .map(|(name, _)| name)
            .collect();
    }

    // Pre-register all top-level fn names so mutual recursion works.
    // Each fn gets a fresh monomorphic placeholder in env. When infer_fn_def
    // later processes the fn, it unifies the placeholder with the actual
    // inferred type, propagating constraints from any earlier forward references.
    // An arity-overloaded fn is registered under its `name__N` key.
    for gi in &grouped {
        let (fn_name_opt, arity): (Option<String>, usize) = match gi {
            GroupedItem::Single(Item::FnDef(fn_)) => {
                (fn_.name().and_then(|n| n.text()), fn_arity(fn_))
            }
            GroupedItem::MultiClause { clauses } => {
                let first = clauses.first();
                (
                    first.and_then(|f| f.name().and_then(|n| n.text())),
                    first.map(fn_arity).unwrap_or(0),
                )
            }
            _ => (None, 0),
        };
        if let Some(name) = fn_name_opt {
            // A fully annotated signature is known before any body is checked,
            // so a call earlier in the file gets its types (`f(x)?.field`).
            let declared = match gi {
                GroupedItem::Single(Item::FnDef(fn_)) => {
                    declared_signature(&mut ctx, fn_, &type_registry)
                }
                _ => None,
            };
            let pre_var = declared.unwrap_or_else(|| ctx.fresh_var());
            env.insert(fn_env_key(&ctx, &env, &name, arity), Scheme::mono(pre_var));
        }
    }

    // Build a map from original item index to grouped item index.
    // Each grouped item knows which original item indices it consumed.
    let mut item_idx_to_grouped: FxHashMap<usize, usize> = FxHashMap::default();
    {
        let mut original_idx = 0;
        for (grouped_idx, gi) in grouped.iter().enumerate() {
            match gi {
                GroupedItem::Single(_) => {
                    item_idx_to_grouped.insert(original_idx, grouped_idx);
                    original_idx += 1;
                }
                GroupedItem::MultiClause { clauses } => {
                    for _ in 0..clauses.len() {
                        item_idx_to_grouped.insert(original_idx, grouped_idx);
                        original_idx += 1;
                    }
                }
            }
        }
    }

    // Register every type definition, then every interface, then every impl,
    // before any body is checked: a function can call a method whose impl
    // comes later in the file, and an impl's methods can call each other.
    // Imports go first, so the module's own names (a variant with the name
    // of an imported one) shadow the imported ones, as in source order.
    let singles = || {
        grouped.iter().filter_map(|gi| match gi {
            GroupedItem::Single(item) => Some(item),
            GroupedItem::MultiClause { .. } => None,
        })
    };
    for item in singles() {
        register_import(
            &mut ctx,
            &mut env,
            item,
            &mut type_registry,
            &mut fn_constraints,
            import_ctx,
        );
    }
    let mut defined_types: Vec<String> = Vec::new();
    for item in singles() {
        let name = match item {
            Item::StructDef(def) => def.name(),
            Item::SumTypeDef(def) => def.name(),
            _ => None,
        };
        if let Some((name, span)) = name.and_then(|n| Some((n.text()?, n.syntax().text_range()))) {
            if defined_types.contains(&name) {
                ctx.errors.push(TypeError::DuplicateDefinition {
                    kind: "type",
                    name,
                    span,
                });
            } else {
                defined_types.push(name);
            }
        }
    }
    for item in singles() {
        match item {
            Item::StructDef(def) => {
                register_struct_def(
                    &mut ctx,
                    &mut env,
                    def,
                    &mut type_registry,
                    &mut trait_registry,
                );
            }
            Item::SumTypeDef(def) => {
                register_sum_type_def(
                    &mut ctx,
                    &mut env,
                    def,
                    &mut type_registry,
                    &mut trait_registry,
                );
            }
            _ => {}
        }
    }
    for item in singles() {
        if let Item::InterfaceDef(iface) = item {
            let trait_def =
                interface_trait_def(&mut ctx, iface, &type_registry, &mut default_method_bodies);
            trait_registry.register_trait(trait_def);
        }
    }
    for item in singles() {
        if let Item::ImplDef(impl_) = item {
            if check_impl_header(
                &mut ctx,
                impl_,
                &type_registry,
                &trait_registry,
                &builtin_types,
            ) {
                register_impl_signature(&mut ctx, impl_, &type_registry, &mut trait_registry);
            }
        }
    }
    check_derive_needs(&mut ctx, &mut trait_registry);

    let mut local_proof_values = FxHashMap::default();
    for proof in proof_values.values {
        if env.lookup(&proof.name).is_some() || !env.overload_arities(&proof.name).is_empty() {
            ctx.errors.push(TypeError::DuplicateDefinition {
                kind: "value",
                name: proof.name,
                span: proof.span,
            });
            continue;
        }
        env.insert(proof.name.clone(), Scheme::mono(proof.ty.clone()));
        local_proof_values.insert(proof.name, proof.ty);
    }

    // Check the items and expressions in source order, except that a
    // function, top-level `let`, actor or service comes after those it names
    // further down (see `dependency_order`, which gives each multi-clause
    // function once).
    // Each starts at the module's own nesting, however the one before it
    // failed (see `InferCtx::nesting`).
    let mut child_types: Vec<Option<Ty>> = vec![None; children_ordered.len()];
    let module_nesting = ctx.nesting(&env);
    for child in dependency_order(&children_ordered, &item_idx_to_grouped, &grouped) {
        ctx.restore(&mut env, module_nesting);
        child_types[child] = match &children_ordered[child].1 {
            ChildKind::ItemIndex(item) => match &grouped[item_idx_to_grouped[item]] {
                GroupedItem::Single(item) => infer_item(
                    &mut ctx,
                    &mut env,
                    item,
                    &mut types,
                    &mut type_registry,
                    &mut trait_registry,
                    &mut fn_constraints,
                    &mut default_method_bodies,
                ),
                GroupedItem::MultiClause { clauses } => infer_multi_clause_fn(
                    &mut ctx,
                    &mut env,
                    clauses,
                    &mut types,
                    &type_registry,
                    &trait_registry,
                    &mut fn_constraints,
                    import_ctx,
                )
                .ok(),
            },
            ChildKind::Expr(expr) => infer_expr(
                &mut ctx,
                &mut env,
                expr,
                &mut types,
                &type_registry,
                &trait_registry,
                &fn_constraints,
            )
            .ok()
            .map(|ty| {
                let resolved = ctx.resolve(ty);
                types.insert(expr.syntax().text_range(), resolved.clone());
                resolved
            }),
        };
    }
    // The type of the last item or expression in source order.
    let result_type = child_types.into_iter().flatten().last();

    for wrapper_span in ctx
        .clustered_route_wrappers
        .keys()
        .copied()
        .collect::<Vec<_>>()
    {
        if !ctx
            .consumed_clustered_route_wrappers
            .contains(&wrapper_span)
        {
            ctx.errors
                .push(TypeError::HttpClusteredOutsideRouteHandlerPosition { span: wrapper_span });
        }
    }

    // Decodes outside any function: nothing but this code fixes their type.
    let top_level_decodes = std::mem::take(&mut ctx.open_decodes);
    check_open_decodes(&mut ctx, top_level_decodes, &Ty::Tuple(vec![]));

    for (actor, msg_ty, span) in std::mem::take(&mut ctx.actor_message_types) {
        if matches!(ctx.resolve(msg_ty), Ty::Var(_)) {
            ctx.errors
                .push(TypeError::ActorMessageTypeUnknown { actor, span });
        }
    }

    // Field reads whose value's type was still unknown when their function
    // was done, and those outside any function (top-level code, actors).
    let pending_fields = std::mem::take(&mut ctx.pending_fields);
    resolve_pending_fields(&mut ctx, &type_registry, pending_fields, true);
    check_method_params_typed(&mut ctx);
    // The same for what an interpolation or operator needs of its operand's
    // type, and for `<>`: outside a function nothing else checks them.
    let concat = std::mem::take(&mut ctx.concat_operands);
    check_concat_operands(&mut ctx, concat, &FxHashMap::default());
    let operand_traits = std::mem::take(&mut ctx.operand_traits);
    check_type_param_bounds(
        &mut ctx,
        &FxHashMap::default(),
        &[],
        &trait_registry,
        operand_traits,
    );

    // An associated type reached through a method is the receiver's, known
    // wherever the receiver ended up concrete: as a call of a generic
    // function makes it, or as it was all along.
    settle_projections(&mut ctx, &trait_registry, 0);

    // Resolve all types in the type table through the union-find.
    let resolved_types: FxHashMap<TextRange, Ty> = types
        .into_iter()
        .map(|(range, ty)| (range, ctx.resolve(ty)))
        .collect();

    for (span, called) in std::mem::take(&mut ctx.jobs_runner_references) {
        if !called {
            ctx.errors.push(TypeError::JobsStartInvalid {
                reason:
                    "call the Jobs runner function directly so the compiler can check the handler",
                span,
            });
        }
    }
    for (name, span) in std::mem::take(&mut ctx.jobs_local_handlers) {
        if !is_jobs_handler_type(&mut ctx, env.lookup(&name)) {
            ctx.errors.push(invalid_jobs_handler(span));
        }
    }

    type_registry.propagate_resource_containment();
    let ownership = crate::ownership::check(
        parse,
        &resolved_types,
        &type_registry,
        import_ctx,
        &ctx.overloaded_fn_names,
        &ctx.overloaded_call_targets,
        &ctx.stdlib_imports,
    );
    ctx.errors.extend(ownership.errors);
    let untyped_pid_conversions = std::mem::take(&mut ctx.untyped_pid_conversions)
        .into_iter()
        .map(|(message, origin)| (ctx.resolve(message), origin))
        .collect();
    let plaintext = crate::plaintext::check(
        parse,
        &resolved_types,
        &type_registry,
        import_ctx,
        &ctx.stdlib_imports,
        untyped_pid_conversions,
    );
    ctx.errors.extend(plaintext.errors);
    // Plaintext has no trait impls, and a type holding it none it did not
    // write: that, not a missing `deriving`, is why it lacks one.
    for error in &mut ctx.errors {
        if let TypeError::TraitNotSatisfied {
            ty,
            trait_name,
            origin,
            ..
        } = error
        {
            if type_registry.is_plaintext_type(ty) {
                *error = crate::plaintext::missing_trait(ty, trait_name, origin);
            }
        }
    }
    // A call whose callee failed is inferred again as a method call, which
    // reports the same error a second time; each error is reported once.
    let mut seen = FxHashSet::default();
    ctx.errors.retain(|error| seen.insert(format!("{error:?}")));
    // A type reported unknown matches nothing; that it does not match a
    // value says nothing more.
    let unknown = &ctx.unknown_types;
    ctx.errors.retain(|error| match error {
        TypeError::Mismatch {
            expected, found, ..
        } => !names_any(expected, unknown) && !names_any(found, unknown),
        _ => true,
    });

    // Resolve the result type as well.
    let resolved_result = result_type.map(|ty| ctx.resolve(ty));
    let assoc_projections = std::mem::take(&mut ctx.assoc_projections)
        .into_iter()
        .map(|(var, trait_name, assoc, receiver)| {
            (ctx.resolve(var), trait_name, assoc, ctx.resolve(receiver))
        })
        .collect();

    // Extract qualified module function names for the MIR lowerer.
    let qualified_modules_for_codegen: FxHashMap<String, Vec<String>> = ctx
        .qualified_modules
        .iter()
        .map(|(mod_name, functions)| (mod_name.clone(), functions.keys().cloned().collect()))
        .collect();

    TypeckResult {
        proof_values: local_proof_values,
        types: resolved_types,
        errors: ctx.errors,
        warnings: ctx.warnings,
        result_type: resolved_result,
        type_registry,
        trait_registry,
        default_method_bodies,
        qualified_modules: qualified_modules_for_codegen,
        imported_functions: ctx.imported_functions,
        stdlib_imports: ctx.stdlib_imports,
        imported_service_methods: ctx.imported_service_methods,
        local_service_exports: ctx.local_service_exports,
        overloaded_call_targets: ctx.overloaded_call_targets,
        overloaded_fn_names: ctx.overloaded_fn_names,
        clustered_route_wrappers: ctx.clustered_route_wrappers,
        discarded_callback_results: ctx.discarded_callback_results,
        json_text_arguments: ctx.json_text_arguments,
        function_ownership: ownership.function_ownership,
        fn_constraints,
        assoc_projections,
        plaintext: plaintext.facts,
    }
}

fn register_crypto_v2_types(type_registry: &mut TypeRegistry) {
    for resource in [
        "BytesBuilder",
        "SecretMap",
        "StorageKey",
        "X25519PrivateKey",
        "MlKemPrivateKey",
        "SigningPrivateKey",
        "AeadKey",
        "BlindRsaSecretKey",
        "BlindRsaBlindingState",
    ] {
        type_registry.register_resource_type(resource);
    }

    for (name, fields) in [
        ("X25519PublicKey", vec![("bytes", Ty::bytes())]),
        ("MlKemPublicKey", vec![("bytes", Ty::bytes())]),
        ("MlKemCiphertext", vec![("bytes", Ty::bytes())]),
        ("BlindRsaPublicKey", vec![("bytes", Ty::bytes())]),
        (
            "BlindRsaBlinded",
            vec![
                ("blinded", Ty::bytes()),
                ("state", Ty::blind_rsa_blinding_state()),
            ],
        ),
        ("SigningPublicKey", vec![("bytes", Ty::bytes())]),
        ("Signature", vec![("bytes", Ty::bytes())]),
        (
            "X25519KeyPair",
            vec![
                ("private_key", Ty::x25519_private_key()),
                ("public_key", Ty::x25519_public_key()),
            ],
        ),
        (
            "MlKemKeyPair",
            vec![
                ("private_key", Ty::mlkem_private_key()),
                ("public_key", Ty::mlkem_public_key()),
            ],
        ),
        (
            "SigningKeyPair",
            vec![
                ("private_key", Ty::signing_private_key()),
                ("public_key", Ty::signing_public_key()),
            ],
        ),
    ] {
        type_registry.register_struct(StructDefInfo {
            name: name.to_string(),
            generic_params: vec![],
            fields: fields
                .into_iter()
                .map(|(field, ty)| (field.to_string(), ty))
                .collect(),
            schema: None,
        });
    }
}

/// Register Option<T> and Result<T, E> as proper sum types in the type registry.
///
/// This replaces the old approach of registering constructors only in the type
/// environment. By registering them as SumTypeDefInfo entries, exhaustiveness
/// checking works for Option/Result: `case opt do Some(x) -> x end` triggers
/// a non-exhaustive error because None is missing.
///
/// Uses enter_level/leave_level to ensure fresh type variables are created
/// at a higher level than current, so they get properly generalized into
/// polymorphic schemes (forall).
fn register_builtin_sum_types(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    type_registry: &mut TypeRegistry,
) {
    // ── Option<T> ──────────────────────────────────────────────────────
    //
    // type Option<T> do
    //   Some(T)
    //   None
    // end

    let option_generic_params = vec!["T".to_string()];
    let option_variants = vec![
        VariantInfo {
            name: "Some".to_string(),
            indexed: None,
            fields: vec![VariantFieldInfo::Positional(Ty::Con(TyCon::new("T")))],
        },
        VariantInfo {
            name: "None".to_string(),
            indexed: None,
            fields: vec![],
        },
    ];

    type_registry.register_sum_type(SumTypeDefInfo {
        name: "Option".to_string(),
        indexed: None,
        generic_params: option_generic_params.clone(),
        variants: option_variants.clone(),
    });

    register_variant_constructors(ctx, env, "Option", &option_generic_params, &option_variants);

    // ── Result<T, E> ───────────────────────────────────────────────────
    //
    // type Result<T, E> do
    //   Ok(T)
    //   Err(E)
    // end

    let result_generic_params = vec!["T".to_string(), "E".to_string()];
    let result_variants = vec![
        VariantInfo {
            name: "Ok".to_string(),
            indexed: None,
            fields: vec![VariantFieldInfo::Positional(Ty::Con(TyCon::new("T")))],
        },
        VariantInfo {
            name: "Err".to_string(),
            indexed: None,
            fields: vec![VariantFieldInfo::Positional(Ty::Con(TyCon::new("E")))],
        },
    ];

    type_registry.register_sum_type(SumTypeDefInfo {
        name: "Result".to_string(),
        indexed: None,
        generic_params: result_generic_params.clone(),
        variants: result_variants.clone(),
    });

    register_variant_constructors(ctx, env, "Result", &result_generic_params, &result_variants);

    // ── CryptoError ───────────────────────────────────────────────────

    let crypto_error_variants = vec![
        VariantInfo {
            name: "InvalidLength".to_string(),
            indexed: None,
            fields: vec![
                VariantFieldInfo::Named("expected".to_string(), Ty::int()),
                VariantFieldInfo::Named("actual".to_string(), Ty::int()),
            ],
        },
        VariantInfo {
            name: "InvalidKey".to_string(),
            indexed: None,
            fields: vec![],
        },
        VariantInfo {
            name: "InvalidPublicKey".to_string(),
            indexed: None,
            fields: vec![],
        },
        VariantInfo {
            name: "InvalidSignature".to_string(),
            indexed: None,
            fields: vec![],
        },
        VariantInfo {
            name: "AuthenticationFailed".to_string(),
            indexed: None,
            fields: vec![],
        },
        VariantInfo {
            name: "EntropyUnavailable".to_string(),
            indexed: None,
            fields: vec![],
        },
        VariantInfo {
            name: "SecretDestroyed".to_string(),
            indexed: None,
            fields: vec![],
        },
        VariantInfo {
            name: "ResourceLimitExceeded".to_string(),
            indexed: None,
            fields: vec![],
        },
        VariantInfo {
            name: "UnsupportedOperation".to_string(),
            indexed: None,
            fields: vec![],
        },
        VariantInfo {
            name: "InternalFailure".to_string(),
            indexed: None,
            fields: vec![],
        },
        // Appended: the variants above keep their tags.
        VariantInfo {
            name: "UnsupportedTarget".to_string(),
            indexed: None,
            fields: vec![],
        },
    ];

    type_registry.register_sum_type(SumTypeDefInfo {
        name: "CryptoError".to_string(),
        indexed: None,
        generic_params: vec![],
        variants: crypto_error_variants.clone(),
    });
    register_variant_constructors(ctx, env, "CryptoError", &[], &crypto_error_variants);

    let db_value_variants = vec![
        VariantInfo {
            name: "Text".to_string(),
            indexed: None,
            fields: vec![VariantFieldInfo::Positional(Ty::string())],
        },
        VariantInfo {
            name: "Binary".to_string(),
            indexed: None,
            fields: vec![VariantFieldInfo::Positional(Ty::bytes())],
        },
        VariantInfo {
            name: "Null".to_string(),
            indexed: None,
            fields: vec![],
        },
    ];
    type_registry.register_sum_type(SumTypeDefInfo {
        name: "DbValue".to_string(),
        indexed: None,
        generic_params: vec![],
        variants: db_value_variants.clone(),
    });
    register_variant_constructors(ctx, env, "DbValue", &[], &db_value_variants);

    // ── Ordering (Less | Equal | Greater) ────────────────────────────────
    //
    // type Ordering do
    //   Less
    //   Equal
    //   Greater
    // end
    //
    // Non-generic sum type used as the return type for compare().

    let ordering_variants = vec![
        VariantInfo {
            name: "Less".to_string(),
            indexed: None,
            fields: vec![],
        },
        VariantInfo {
            name: "Equal".to_string(),
            indexed: None,
            fields: vec![],
        },
        VariantInfo {
            name: "Greater".to_string(),
            indexed: None,
            fields: vec![],
        },
    ];

    type_registry.register_sum_type(SumTypeDefInfo {
        name: "Ordering".to_string(),
        indexed: None,
        generic_params: vec![],
        variants: ordering_variants.clone(),
    });

    register_variant_constructors(ctx, env, "Ordering", &[], &ordering_variants);
}

/// Register variant constructors for a sum type as polymorphic functions in env.
///
/// This is the shared logic extracted from `register_sum_type_def` so that both
/// user-defined sum types (parsed from source) and built-in sum types (Option,
/// Result) use the same variant registration mechanism.
pub fn register_variant_constructors(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    type_name: &str,
    generic_params: &[String],
    variants: &[VariantInfo],
) {
    for variant in variants {
        let field_types: Vec<Ty> = variant
            .fields
            .iter()
            .map(|f| match f {
                VariantFieldInfo::Positional(ty) => ty.clone(),
                VariantFieldInfo::Named(_, ty) => ty.clone(),
            })
            .collect();

        ctx.enter_level();

        let (result_ty, substituted_fields) = match &variant.indexed {
            Some(indexed) => {
                let mut params: FxHashMap<_, _> = generic_params
                    .iter()
                    .map(|name| (name.clone(), ctx.fresh_var()))
                    .collect();
                for name in &indexed.index_params {
                    params.insert(name.clone(), ctx.fresh_index(None));
                }
                let result_ty = with_declared_type_params(&indexed.result, &params);
                let fields = field_types
                    .iter()
                    .map(|ty| with_declared_type_params(ty, &params))
                    .collect::<Vec<_>>();
                (result_ty, fields)
            }
            None => {
                let vars: Vec<_> = generic_params.iter().map(|_| ctx.fresh_var()).collect();
                let fields = field_types
                    .iter()
                    .map(|ty| substitute_type_params(ty, generic_params, &vars))
                    .collect();
                (Ty::struct_ty(type_name, vars), fields)
            }
        };

        let ctor_ty = if substituted_fields.is_empty() {
            // Nullary constructor: not a function, just the type itself.
            result_ty.clone()
        } else {
            // Constructor with fields: function from fields to result type.
            Ty::Fun(substituted_fields, Box::new(result_ty.clone()))
        };

        ctx.leave_level();
        let scheme = ctx.generalize(ctor_ty);

        // Register under qualified name: Option.Some, Result.Ok
        let qualified_name = format!("{}.{}", type_name, variant.name);
        env.insert(qualified_name, scheme.clone());
        if let Some(origin) = result_ty
            .con()
            .and_then(|con| con.indexed_origin.as_deref())
        {
            if !origin.is_empty() {
                env.insert(
                    format!("{origin}.{type_name}.{}", variant.name),
                    scheme.clone(),
                );
            }
        }

        // Register under unqualified name: Some, None, Ok, Err
        env.insert(variant.name.clone(), scheme);
    }
}

// ── Multi-Clause Function Grouping (11-02) ────────────────────────────

/// A grouped item: either a single item or a multi-clause function group.
/// The order to check the module's top-level children in (indices into
/// `children`): source order, except that a function, top-level `let`,
/// actor, service or impl comes after the ones of these it names further
/// down, an impl being named by its methods. Their types are then known
/// where it uses them: a generic function called before its definition
/// stays generic, `spawn(worker)` above `actor worker` finds it, and a
/// method whose return type its body settles (`fn count(self) do ... end`)
/// is found above its impl. Items in a cycle (mutual recursion) keep
/// their source order, and the earlier ones see the later ones through
/// their pre-registered placeholders.
fn dependency_order(
    children: &[(TextRange, ChildKind)],
    item_to_group: &FxHashMap<usize, usize>,
    grouped: &[GroupedItem],
) -> Vec<usize> {
    let group_of = |child: usize| match &children[child].1 {
        ChildKind::ItemIndex(item) => item_to_group.get(item).copied(),
        ChildKind::Expr(_) => None,
    };
    let mut first_child: FxHashMap<usize, usize> = FxHashMap::default();
    for child in 0..children.len() {
        if let Some(group) = group_of(child) {
            first_child.entry(group).or_insert(child);
        }
    }
    let defined_names = |group: &GroupedItem| -> Vec<String> {
        let name = match group {
            GroupedItem::MultiClause { clauses } => clauses.first().and_then(|c| c.name()?.text()),
            GroupedItem::Single(Item::FnDef(def)) => def.name().and_then(|n| n.text()),
            GroupedItem::Single(Item::LetBinding(def)) => def.name().and_then(|n| n.text()),
            GroupedItem::Single(Item::ActorDef(def)) => def.name().and_then(|n| n.text()),
            GroupedItem::Single(Item::ServiceDef(def)) => def.name().and_then(|n| n.text()),
            GroupedItem::Single(Item::ImplDef(def)) => {
                return def.methods().filter_map(|m| m.name()?.text()).collect();
            }
            _ => None,
        };
        name.into_iter().collect()
    };
    let mut by_name: FxHashMap<String, Vec<usize>> = FxHashMap::default();
    for (group, item) in grouped.iter().enumerate() {
        for name in defined_names(item) {
            by_name.entry(name).or_default().push(group);
        }
    }
    let uses = |group: usize| -> Vec<usize> {
        let nodes: Vec<mesh_parser::SyntaxNode> = match &grouped[group] {
            GroupedItem::MultiClause { clauses } => {
                clauses.iter().map(|c| c.syntax().clone()).collect()
            }
            GroupedItem::Single(item) => vec![item.syntax().clone()],
        };
        let mut used = Vec::new();
        for node in nodes {
            // Names, and the methods named after a `.` (`e.count()`).
            let names = node
                .descendants()
                .filter_map(NameRef::cast)
                .filter_map(|name_ref| name_ref.text())
                .chain(
                    node.descendants()
                        .filter_map(FieldAccess::cast)
                        .filter_map(|fa| Some(fa.field()?.text().to_string())),
                );
            for text in names {
                for &other in by_name.get(&text).into_iter().flatten() {
                    if other != group && !used.contains(&other) {
                        used.push(other);
                    }
                }
            }
        }
        used
    };

    fn visit(
        group: usize,
        first_child: &FxHashMap<usize, usize>,
        uses: &dyn Fn(usize) -> Vec<usize>,
        seen: &mut FxHashSet<usize>,
        order: &mut Vec<usize>,
    ) {
        if !seen.insert(group) {
            return;
        }
        for used in uses(group) {
            visit(used, first_child, uses, seen, order);
        }
        if let Some(&child) = first_child.get(&group) {
            order.push(child);
        }
    }

    let mut seen: FxHashSet<usize> = FxHashSet::default();
    let mut order = Vec::with_capacity(children.len());
    for child in 0..children.len() {
        match group_of(child) {
            // Only orderable items are checked ahead of their place.
            Some(group) if !defined_names(&grouped[group]).is_empty() => {
                visit(group, &first_child, &uses, &mut seen, &mut order)
            }
            Some(group) => {
                if seen.insert(group) {
                    order.push(first_child[&group]);
                }
            }
            None => order.push(child),
        }
    }
    order
}

enum GroupedItem {
    /// A non-FnDef item, or a standalone single-clause FnDef.
    Single(Item),
    /// Consecutive same-name, same-arity FnDef items grouped together.
    MultiClause {
        /// All clauses (first clause contains visibility, generics, return type).
        clauses: Vec<FnDef>,
    },
}

fn fn_arity(fn_: &FnDef) -> usize {
    fn_.param_list().map(|pl| pl.params().count()).unwrap_or(0)
}

/// The env key of a fn: `name__N` for a top-level fn whose name is defined
/// at more than one arity, so each arity is its own function.
fn fn_env_key(ctx: &InferCtx, env: &TypeEnv, name: &str, arity: usize) -> String {
    if env.depth() == 1 && ctx.overloaded_fn_names.contains(name) {
        format!("{}__{}", name, arity)
    } else {
        name.to_string()
    }
}

/// Group consecutive same-name, same-arity FnDef items from a list of items.
///
/// Rules:
/// - Group by name AND arity (param count). Different arities are separate functions.
/// - Only group CONSECUTIVE FnDef items. Non-fn items break the grouping.
/// - A single FnDef with `= expr` body is treated as a 1-clause multi-clause function.
/// - A single FnDef with `do/end` body remains a Single item (regular function).
/// - Multiple consecutive FnDef nodes with the same name produce a MultiClause group.
/// - A native or exported function is a Single item, whatever its form: its
///   declaration is checked as one (a guard on it was not).
fn group_multi_clause_fns(items: Vec<Item>) -> Vec<GroupedItem> {
    let is_declaration =
        |fn_def: &FnDef| fn_def.native_decl().is_some() || fn_def.export_decl().is_some();
    let mut result: Vec<GroupedItem> = Vec::new();
    let mut i = 0;

    while i < items.len() {
        match &items[i] {
            Item::FnDef(fn_def) if !is_declaration(fn_def) => {
                let name = fn_def.name().and_then(|n| n.text()).unwrap_or_default();
                let arity = fn_arity(fn_def);

                // Collect consecutive FnDef items with the same name and arity.
                let mut clauses = vec![fn_def.clone()];
                let mut j = i + 1;
                while j < items.len() {
                    if let Item::FnDef(next_fn) = &items[j] {
                        let next_name = next_fn.name().and_then(|n| n.text()).unwrap_or_default();
                        if next_name == name
                            && fn_arity(next_fn) == arity
                            && !is_declaration(next_fn)
                        {
                            clauses.push(next_fn.clone());
                            j += 1;
                            continue;
                        }
                    }
                    break;
                }

                if clauses.len() == 1 {
                    // Single FnDef -- an `= expr` form, a guard, or a parameter
                    // written as a pattern makes it a clause to match against.
                    let clause = &clauses[0];
                    if clause.has_eq_body()
                        || clause.guard().is_some()
                        || clause
                            .param_list()
                            .is_some_and(|pl| pl.params().any(|param| param.pattern().is_some()))
                    {
                        // Single-clause multi-clause function (still valid).
                        result.push(GroupedItem::MultiClause { clauses });
                    } else {
                        // Regular do/end function -- keep as Single.
                        result.push(GroupedItem::Single(items[i].clone()));
                    }
                } else {
                    // Multiple clauses with same name/arity.
                    result.push(GroupedItem::MultiClause { clauses });
                }

                i = j;
            }
            _ => {
                result.push(GroupedItem::Single(items[i].clone()));
                i += 1;
            }
        }
    }

    result
}

/// Check for non-consecutive same-name function definitions after grouping.
///
/// If a function name/arity appears in multiple groups, emit a `NonConsecutiveClauses` error.
fn check_non_consecutive_clauses(grouped: &[GroupedItem], ctx: &mut InferCtx) {
    // Track seen function name/arity -> span of first group.
    let mut seen: FxHashMap<(String, usize), TextRange> = FxHashMap::default();

    for gi in grouped {
        let (name, arity, span) = match gi {
            GroupedItem::Single(Item::FnDef(fn_def)) => {
                let name = fn_def.name().and_then(|n| n.text()).unwrap_or_default();
                let arity = fn_def
                    .param_list()
                    .map(|pl| pl.params().count())
                    .unwrap_or(0);
                (name, arity, fn_def.syntax().text_range())
            }
            GroupedItem::MultiClause { clauses } => {
                let first = &clauses[0];
                let name = first.name().and_then(|n| n.text()).unwrap_or_default();
                let arity = first
                    .param_list()
                    .map(|pl| pl.params().count())
                    .unwrap_or(0);
                (name, arity, first.syntax().text_range())
            }
            _ => continue,
        };

        if name.is_empty() {
            continue;
        }

        let key = (name.clone(), arity);
        if let Some(first_span) = seen.get(&key) {
            ctx.errors.push(TypeError::NonConsecutiveClauses {
                fn_name: name,
                arity,
                first_span: *first_span,
                second_span: span,
            });
        } else {
            seen.insert(key, span);
        }
    }
}

/// Check if a clause is a "catch-all" -- all parameters are wildcards or simple variable bindings.
///
/// A catch-all clause has no literal, constructor, or tuple patterns in any parameter.
fn is_catch_all_clause(fn_def: &FnDef) -> bool {
    let param_list = match fn_def.param_list() {
        Some(pl) => pl,
        None => return true, // No params = catch-all (vacuously)
    };

    for param in param_list.params() {
        if let Some(pat) = param.pattern() {
            // Has a pattern child -- check if it's just a variable or wildcard.
            match pat {
                // An uppercase name is a constructor (`Red`, `None`).
                Pattern::Ident(ident)
                    if ident
                        .name()
                        .is_some_and(|name| name.text().starts_with(char::is_uppercase)) =>
                {
                    return false;
                }
                Pattern::Wildcard(_) | Pattern::Ident(_) => {
                    // Simple binding or wildcard -- still catch-all for this param.
                }
                _ => {
                    // Literal, constructor, tuple, or, as -- NOT catch-all.
                    return false;
                }
            }
        }
        // No pattern child means it's a plain IDENT parameter -- catch-all for this param.
    }

    // Also check if there's a guard -- a guarded clause is NOT catch-all.
    if fn_def.guard().is_some() {
        return false;
    }

    true
}

/// Infer a multi-clause function group.
///
/// Groups consecutive FnDef nodes with the same name/arity and type-checks them
/// as a single function with pattern matching on the parameters.
///
/// This conceptually desugars:
/// ```text
/// fn fib(0) = 0
/// fn fib(1) = 1
/// fn fib(n) = fib(n - 1) + fib(n - 2)
/// ```
/// into the equivalent of:
/// ```text
/// fn fib(__p0) do
///   case __p0 do
///     0 -> 0
///     1 -> 1
///     n -> fib(n - 1) + fib(n - 2)
///   end
/// end
/// ```
fn infer_multi_clause_fn(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    clauses: &[FnDef],
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &mut FxHashMap<String, FnConstraints>,
    _import_ctx: &ImportContext,
) -> Result<Ty, TypeError> {
    assert!(!clauses.is_empty());

    let first = &clauses[0];
    let fn_name = first
        .name()
        .and_then(|n| n.text())
        .unwrap_or_else(|| "<anonymous>".to_string());
    let arity = first
        .param_list()
        .map(|pl| pl.params().count())
        .unwrap_or(0);

    // ── Step 1: Validate clause properties ─────────────────────────────

    // Check that non-first clauses don't have visibility, generics, return type.
    for (_idx, clause) in clauses.iter().enumerate().skip(1) {
        if clause.visibility().is_some() {
            ctx.warnings.push(TypeError::NonFirstClauseAnnotation {
                fn_name: fn_name.clone(),
                what: "visibility".to_string(),
                span: clause.syntax().text_range(),
            });
        }
        // Check for generic params on non-first clause.
        let has_generics = clause
            .syntax()
            .children()
            .any(|n| n.kind() == SyntaxKind::GENERIC_PARAM_LIST);
        if has_generics {
            ctx.warnings.push(TypeError::NonFirstClauseAnnotation {
                fn_name: fn_name.clone(),
                what: "generic parameters".to_string(),
                span: clause.syntax().text_range(),
            });
        }
        if clause.return_type().is_some() {
            ctx.warnings.push(TypeError::NonFirstClauseAnnotation {
                fn_name: fn_name.clone(),
                what: "return type annotation".to_string(),
                span: clause.syntax().text_range(),
            });
        }

        // Check for where clause on non-first clause.
        let has_where = clause
            .syntax()
            .children()
            .any(|n| n.kind() == SyntaxKind::WHERE_CLAUSE);
        if has_where {
            ctx.warnings.push(TypeError::NonFirstClauseAnnotation {
                fn_name: fn_name.clone(),
                what: "where clause".to_string(),
                span: clause.syntax().text_range(),
            });
        }
    }

    // E0022 already explains why clauses after a catch-all are unreachable.
    let mut coverage_end = clauses.len();
    for (idx, clause) in clauses.iter().enumerate().take(clauses.len() - 1) {
        if is_catch_all_clause(clause) {
            coverage_end = coverage_end.min(idx + 1);
            ctx.errors.push(TypeError::CatchAllNotLast {
                fn_name: fn_name.clone(),
                arity,
                span: clause.syntax().text_range(),
            });
        }
    }

    // ── Step 2: Set up function type infrastructure ────────────────────

    // The placeholder calls earlier in the module used.
    let env_key = fn_env_key(ctx, env, &fn_name, arity);
    let pre_registered = env
        .lookup(&env_key)
        .filter(|scheme| scheme.vars.is_empty())
        .map(|scheme| scheme.ty.clone());

    ctx.enter_level();

    // Pre-register the function name with a fresh type variable for recursion.
    let self_var = ctx.fresh_var();
    env.insert(env_key.clone(), Scheme::mono(self_var.clone()));

    // Extract generic type parameters from the FIRST clause only.
    if clauses.len() != 1
        || first
            .param_list()
            .is_some_and(|list| list.params().any(|param| param.pattern().is_some()))
    {
        if let Some(clause) = clauses
            .iter()
            .find(|clause| index_param_names(clause.syntax()).next().is_some())
        {
            return Err(invalid_indexed_type(
                ctx,
                significant_range(clause.syntax()),
                "index parameters require a single clause with plain parameters".into(),
            ));
        }
    }
    let type_params = function_type_params(ctx, first.syntax());

    // Extract where-clause constraints from the first clause.
    let where_constraints = extract_where_constraints(first);
    check_index_bounds(ctx, first, &type_params, &where_constraints);

    // Create fresh type variables for each parameter position.
    let param_types: Vec<Ty> = (0..arity).map(|_| ctx.fresh_var()).collect();

    // Parse return type annotation from the first clause.
    // Use resolve_type_annotation which handles generic args and sugar types
    // (e.g., Result<Int, String>, Int!String, Int?) correctly.
    let return_type_annotation = first.return_type().and_then(|ann| {
        // A declared type parameter shadows an alias of the same name.
        if let Some(name) = annotation_type_param(&ann, &type_params) {
            return Some(type_params[&name].clone());
        }
        // Use full annotation resolution for generic/sugar types.
        resolve_type_annotation(ctx, &ann, type_registry)
            .map(|ty| with_declared_type_params(&ty, &type_params))
    });

    // Store fn constraints if any.
    if !where_constraints.is_empty() {
        let param_type_param_names = first
            .param_list()
            .iter()
            .flat_map(|list| list.params())
            .map(|param| {
                param
                    .type_annotation()
                    .and_then(|ann| annotation_type_param(&ann, &type_params))
            })
            .collect();
        fn_constraints.insert(
            env_key.clone(),
            FnConstraints {
                where_constraints: where_constraints.clone(),
                param_type_param_names,
                inferred_bounds: Vec::new(),
                concat_params: Vec::new(),
            },
        );
    }

    // ── Step 3: Infer each clause (like case arms) ─────────────────────

    let enclosing = enter_fn_body(ctx, &where_constraints, &type_params);
    ctx.push_fn_return_type(return_type_annotation.clone());

    let mut result_ty: Option<Ty> = None;
    let mut first_branch: Option<TextRange> = None;
    let clauses_span = TextRange::new(
        first.syntax().text_range().start(),
        clauses[clauses.len() - 1].syntax().text_range().end(),
    );
    let mut arm_patterns: Vec<AbsPat> = Vec::new();
    let mut arm_has_guard: Vec<bool> = Vec::new();
    let mut arm_spans: Vec<TextRange> = Vec::new();

    for clause in clauses {
        env.push_scope();

        // Insert type params into scope.
        for (name, ty) in &type_params {
            if !matches!(ty, Ty::Nat(_)) {
                env.insert(name.clone(), Scheme::mono(ty.clone()));
            }
        }

        arm_patterns.push(bind_clause_params(
            ctx,
            env,
            clause.param_list(),
            &param_types,
            &type_params,
            types,
            type_registry,
        )?);

        // Process guard expression if present.
        // A guard is any `Bool` expression; one the parser could not
        // finish guards nothing.
        let guard = clause.guard().and_then(|guard| guard.expr());
        arm_has_guard.push(guard.is_some());
        arm_spans.push(clause.syntax().text_range());
        if let Some(guard_expr) = guard {
            let guard_ty = infer_expr(
                ctx,
                env,
                &guard_expr,
                types,
                type_registry,
                trait_registry,
                fn_constraints,
            )?;
            let _ = ctx.unify(
                Ty::bool(),
                guard_ty,
                ConstraintOrigin::Expr {
                    span: guard_expr.syntax().text_range(),
                },
            );
        }

        // Infer the body expression.
        let body_ty = if let Some(expr_body) = clause.expr_body() {
            // `= expr` form
            infer_expr(
                ctx,
                env,
                &expr_body,
                types,
                type_registry,
                trait_registry,
                fn_constraints,
            )?
        } else {
            // `do ... end` form (rare for multi-clause but allowed for single clause)
            infer_body(
                ctx,
                env,
                clause.body(),
                types,
                type_registry,
                trait_registry,
                fn_constraints,
            )
        };

        // Unify body type with previous clause body types.
        let body_span = clause
            .expr_body()
            .map(|body| body.syntax().text_range())
            .or_else(|| clause.body().map(|body| body.syntax().text_range()))
            .unwrap_or_else(|| clause.syntax().text_range());
        join_branch_ty(
            ctx,
            &mut result_ty,
            &mut first_branch,
            clauses_span,
            body_ty.clone(),
            body_span,
        )?;

        // Unify with return type annotation if present.
        if let Some(ref ret_ann) = return_type_annotation {
            ctx.unify(ret_ann.clone(), body_ty, ConstraintOrigin::Builtin)?;
        }

        env.pop_scope();
    }

    let open_decodes = finish_fn_body(
        ctx,
        enclosing,
        first,
        &where_constraints,
        &type_params,
        &param_types,
        &env_key,
        fn_constraints,
        type_registry,
        trait_registry,
    );
    // Each clause joined its body's type in.
    let mut result_ty = result_ty.expect("a function has a clause");
    for early in ctx.pop_fn_return_type() {
        join_early_return(ctx, &mut result_ty, early)?;
    }
    let signature = Ty::Fun(param_types.clone(), Box::new(result_ty.clone()));
    check_open_decodes(ctx, open_decodes, &signature);

    // ── Step 4: Exhaustiveness and redundancy checking ─────────────────

    // Build scrutinee type for exhaustiveness checking.
    let scrutinee_ty = if param_types.len() == 1 {
        ctx.resolve(param_types[0].clone())
    } else if param_types.is_empty() {
        Ty::Tuple(vec![])
    } else {
        Ty::Tuple(param_types.iter().map(|t| ctx.resolve(t.clone())).collect())
    };

    // The clauses must cover every argument, as a case's arms must.
    check_arm_coverage(
        ctx,
        &scrutinee_ty,
        &arm_patterns[..coverage_end],
        &arm_has_guard[..coverage_end],
        &arm_spans[..coverage_end],
        first.syntax().text_range(),
        type_registry,
        true,
    );

    // ── Step 5: Build function type and register ───────────────────────

    let ret_ty = return_type_annotation.unwrap_or(result_ty);
    let fn_ty = Ty::Fun(param_types, Box::new(ret_ty));

    ctx.unify(self_var, fn_ty.clone(), ConstraintOrigin::Builtin)?;

    ctx.leave_level();
    let scheme = ctx.generalize(fn_ty.clone());
    if let Some(pre_var) = pre_registered {
        let instance = ctx.instantiate(&scheme);
        let _ = ctx.unify(pre_var, instance, ConstraintOrigin::Builtin);
    }
    env.insert(env_key, scheme);

    let resolved = ctx.resolve(fn_ty);
    types.insert(first.syntax().text_range(), resolved.clone());

    Ok(resolved)
}

// ── Item Inference ─────────────────────────────────────────────────────

/// Infer the type of a top-level item.
/// Returns the type of the item (for let bindings, the type of the initializer;
/// for function defs, the function type).
fn infer_item(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    item: &Item,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &mut TypeRegistry,
    trait_registry: &mut TraitRegistry,
    fn_constraints: &mut FxHashMap<String, FnConstraints>,
    default_method_bodies: &mut FxHashMap<(String, String), TextRange>,
) -> Option<Ty> {
    match item {
        Item::LetBinding(let_) => infer_let_binding(
            ctx,
            env,
            let_,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        )
        .ok(),
        Item::FnDef(fn_) => infer_fn_def(
            ctx,
            env,
            fn_,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        )
        .ok(),
        Item::TypeAliasDef(_) => None,
        Item::InterfaceDef(iface) => {
            infer_interface_def(
                ctx,
                env,
                iface,
                types,
                type_registry,
                trait_registry,
                fn_constraints,
                default_method_bodies,
            );
            None
        }
        Item::ImplDef(impl_) => {
            infer_impl_def(
                ctx,
                env,
                impl_,
                types,
                type_registry,
                trait_registry,
                fn_constraints,
            );
            None
        }
        // Registered before any item is checked (see `infer_with_imports`),
        // and a module block is checked as a module of its own.
        Item::ImportDecl(_)
        | Item::FromImportDecl(_)
        | Item::StructDef(_)
        | Item::SumTypeDef(_)
        | Item::ModuleDef(_) => None,
        Item::ActorDef(actor_def) => infer_actor_def(
            ctx,
            env,
            actor_def,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        )
        .ok(),
        Item::ServiceDef(service_def) => infer_service_def(
            ctx,
            env,
            service_def,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        )
        .ok(),
        Item::SupervisorDef(sup_def) => infer_supervisor_def(
            ctx,
            env,
            sup_def,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        )
        .ok(),
    }
}

/// Bring what an `import` or `from ... import` names into scope.
fn register_import(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    item: &Item,
    type_registry: &mut TypeRegistry,
    fn_constraints: &mut FxHashMap<String, FnConstraints>,
    import_ctx: &ImportContext,
) {
    match item {
        Item::ImportDecl(import_decl) => {
            // An import cut off before its module names nothing.
            let segments = import_decl.module_path().map(|path| path.segments());
            let segments = segments.unwrap_or_default();
            let Some(module) = segments.last().cloned() else {
                return;
            };
            let path = segments.join(".");
            let Some(mod_exports) = import_ctx.module_at_path(&path) else {
                // A standard module's functions are found where they are used.
                if segments.len() != 1
                    || !stdlib_modules(import_ctx.test_builtins).contains_key(&module)
                {
                    ctx.errors.push(TypeError::ImportModuleNotFound {
                        module_name: path,
                        span: import_decl.syntax().text_range(),
                        suggestion: None,
                    });
                }
                return;
            };
            // The module's functions, structs and variants, for `Module.name`.
            let mut functions = mod_exports.functions.clone();
            for (name, def) in &mod_exports.struct_defs {
                let struct_ty = imported_struct_ty(ctx, name, &module, def);
                functions.insert(name.clone(), Scheme::mono(struct_ty));
            }
            ctx.qualified_modules.insert(module.clone(), functions);
            for (name, constraints) in &mod_exports.function_constraints {
                fn_constraints.insert(format!("{module}.{name}"), constraints.clone());
            }
            ctx.qualified_module_origins
                .insert(module.clone(), mod_exports.module_name.clone());
            ctx.qualified_module_private_names
                .insert(module.clone(), mod_exports.private_names.clone());
            // Constructors are registered under their type's name (`Shape.Dot`).
            let variants = ctx.module_variants.entry(module).or_default();
            for sum_type in mod_exports.sum_type_defs.values() {
                let owner = match &sum_type.indexed {
                    Some(indexed) if !indexed.origin.is_empty() => {
                        format!("{}.{}", indexed.origin, sum_type.name)
                    }
                    _ => sum_type.name.clone(),
                };
                for variant in &sum_type.variants {
                    variants.insert(variant.name.clone(), owner.clone());
                }
            }
            for (name, service) in &mod_exports.service_defs {
                register_imported_service(ctx, env, name, service);
            }
        }
        Item::FromImportDecl(from_import) => {
            // An import cut off before its module names nothing.
            let segments = from_import.module_path().map(|path| path.segments());
            let segments = segments.unwrap_or_default();
            let Some(module) = segments.last().cloned() else {
                return;
            };
            let import_list = from_import.import_list();
            let names = import_list
                .iter()
                .flat_map(|list| list.names())
                .filter_map(|node| Some((node.text()?, node.syntax().text_range())));
            let path = segments.join(".");
            if let Some(mod_exports) = import_ctx.module_at_path(&path) {
                for (name, span) in names {
                    import_name(
                        ctx,
                        env,
                        type_registry,
                        fn_constraints,
                        import_ctx,
                        mod_exports,
                        &path,
                        name,
                        span,
                    );
                }
            } else if let Some(functions) = stdlib_modules(import_ctx.test_builtins).get(&path) {
                // A standard module's function comes in under its own name
                // and with the module's prefix (`length`, `string_length`).
                for (name, span) in names {
                    match functions.get(&name) {
                        Some(scheme) => {
                            let prefixed = format!("{}_{name}", module.to_lowercase());
                            ctx.stdlib_imports.insert(name.clone(), module.clone());
                            env.insert(prefixed, scheme.clone());
                            env.insert(name, scheme.clone());
                        }
                        None => ctx.errors.push(TypeError::NoSuchModuleFunction {
                            module: module.clone(),
                            name,
                            available: listed_names(functions.keys()),
                            span,
                        }),
                    }
                }
            } else {
                ctx.errors.push(TypeError::ImportModuleNotFound {
                    module_name: path,
                    span: from_import.syntax().text_range(),
                    suggestion: None,
                });
            }
        }
        _ => {}
    }
}

/// Bring the definition `name` of a module (`module_path`) into scope, as
/// `from module_path import name` at `span` does.
#[allow(clippy::too_many_arguments)]
fn import_name(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    type_registry: &mut TypeRegistry,
    fn_constraints: &mut FxHashMap<String, FnConstraints>,
    import_ctx: &ImportContext,
    mod_exports: &crate::ModuleExports,
    module_path: &str,
    name: String,
    span: TextRange,
) {
    // A function, or each arity of one defined at several (`name__2`).
    let functions: Vec<&String> = match mod_exports.functions.get_key_value(&name) {
        Some((key, _)) => vec![key],
        None => mod_exports
            .functions
            .keys()
            .filter(|key| source_function_name(key) == name)
            .collect(),
    };
    if !functions.is_empty() {
        for key in functions {
            env.insert(key.clone(), mod_exports.functions[key].clone());
            if let Some(constraints) = mod_exports.function_constraints.get(key) {
                fn_constraints.insert(key.clone(), constraints.clone());
            }
            ctx.imported_functions.push(key.clone());
            ctx.imported_function_origins
                .insert(key.clone(), mod_exports.module_name.clone());
        }
    } else if let Some(def) = mod_exports.struct_defs.get(&name) {
        let module = module_path.rsplit('.').next().unwrap_or(module_path);
        let struct_ty = imported_struct_ty(ctx, &name, module, def);
        env.insert(name.clone(), Scheme::mono(struct_ty));
        type_registry.register_struct(def.clone());
        // Its schema functions (`User.__table__()`) come with it.
        if import_ctx
            .all_trait_impls
            .iter()
            .any(|imp| imp.trait_name == "Schema" && imp.impl_type_name == name)
        {
            let fields = def.fields.iter().map(|(field, _)| field.as_str());
            register_schema_functions(env, &name, fields);
        }
    } else if let Some(def) = mod_exports.sum_type_defs.get(&name) {
        type_registry.register_sum_type(def.clone());
        register_variant_constructors(ctx, env, &def.name, &def.generic_params, &def.variants);
    } else if let Some(scheme) = mod_exports.actor_defs.get(&name) {
        env.insert(name.clone(), scheme.clone());
        ctx.imported_function_origins
            .insert(name.clone(), mod_exports.module_name.clone());
        ctx.imported_functions.push(name);
    } else if let Some(service) = mod_exports.service_defs.get(&name) {
        register_imported_service(ctx, env, &name, service);
    } else if mod_exports.type_aliases.contains_key(&name) || mod_exports.interfaces.contains(&name)
    {
        // An alias is registered with the module's others; a public
        // interface is visible in every module checked after its own, and
        // importing it by name orders the modules.
    } else if mod_exports.private_names.contains(&name) {
        ctx.errors.push(TypeError::PrivateItem {
            module_name: module_path.to_string(),
            name,
            span,
        });
    } else {
        let available = listed_names(
            mod_exports
                .functions
                .keys()
                .chain(mod_exports.struct_defs.keys())
                .chain(mod_exports.sum_type_defs.keys())
                .chain(mod_exports.service_defs.keys())
                .chain(mod_exports.actor_defs.keys())
                .chain(mod_exports.type_aliases.keys())
                .chain(mod_exports.interfaces.iter()),
        );
        ctx.errors.push(TypeError::ImportNameNotFound {
            module_name: module_path.to_string(),
            name,
            span,
            available,
        });
    }
}

/// The type of the struct `name` a module `module` exports, with fresh
/// arguments for its type parameters.
fn imported_struct_ty(ctx: &mut InferCtx, name: &str, module: &str, def: &StructDefInfo) -> Ty {
    let args = def.generic_params.iter().map(|_| ctx.fresh_var()).collect();
    Ty::App(Box::new(Ty::Con(TyCon::with_module(name, module))), args)
}

/// Bring an imported service into scope: its helpers as `Name.helper`
/// (and in its namespace, for lowering), its name for field access, and its
/// methods for lowering.
fn register_imported_service(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    name: &str,
    service: &crate::ServiceExportInfo,
) {
    for (helper, scheme) in &service.helpers {
        env.insert(format!("{name}.{helper}"), scheme.clone());
        ctx.qualified_modules
            .entry(name.to_string())
            .or_default()
            .insert(helper.clone(), scheme.clone());
    }
    env.insert(name.to_string(), Scheme::mono(Ty::Con(TyCon::new(name))));
    ctx.imported_service_methods
        .insert(name.to_string(), service.methods.clone());
}

/// The functions `deriving(Schema)` gives the struct `name`, called as
/// `User.__table__()`: its table, fields, primary key and relationships,
/// and a column name for each of its `fields`.
fn register_schema_functions<'a>(
    env: &mut TypeEnv,
    name: &str,
    fields: impl Iterator<Item = &'a str>,
) {
    let strings = Ty::list(Ty::string());
    for (function, ty) in [
        ("__table__", Ty::string()),
        ("__fields__", strings.clone()),
        ("__primary_key__", Ty::string()),
        // Each "kind:name:target".
        ("__relationships__", strings.clone()),
        // Each "field_name:SQL_TYPE".
        ("__field_types__", strings.clone()),
        // Each "kind:name:target:fk:target_table:key".
        ("__relationship_meta__", strings),
    ] {
        env.insert(
            format!("{name}.{function}"),
            Scheme::mono(Ty::fun(vec![], ty)),
        );
    }
    for field in fields {
        let column = Ty::fun(vec![], Ty::string());
        env.insert(format!("{name}.__{field}_col__"), Scheme::mono(column));
    }
}

/// The names a module defines, as an error lists them: sorted, each
/// arity of a function by the function's name, without internal ones.
fn listed_names<'a>(names: impl Iterator<Item = &'a String>) -> Vec<String> {
    let mut names: Vec<String> = names
        .map(|name| source_function_name(name))
        .filter(|name| !name.contains("__"))
        .collect();
    names.sort();
    names.dedup();
    names
}

// ── Struct Registration (03-03) ────────────────────────────────────────

/// Register a struct definition: extract field names/types and generic params.
fn register_struct_def(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    struct_def: &StructDef,
    type_registry: &mut TypeRegistry,
    trait_registry: &mut TraitRegistry,
) {
    let name = struct_def
        .name()
        .and_then(|n| n.text())
        .unwrap_or_else(|| "<unnamed>".to_string());

    // Extract generic type parameters.
    let generic_params = generic_param_names(struct_def.syntax());

    // Extract fields.
    let mut fields = Vec::new();
    for field in struct_def.fields() {
        let field_name = field
            .name()
            .and_then(|n| n.text())
            .unwrap_or_else(|| "<unnamed>".to_string());

        let field_ty = field
            .type_annotation()
            .and_then(|ann| resolve_type_annotation(ctx, &ann, type_registry))
            .unwrap_or_else(|| ctx.fresh_var());

        if fields.iter().any(|(existing, _)| *existing == field_name) {
            ctx.errors.push(TypeError::DuplicateDefinition {
                kind: "field",
                name: field_name.clone(),
                span: field.syntax().text_range(),
            });
            continue;
        }
        fields.push((field_name, field_ty));
    }

    // Register a constructor function: StructName(field1, field2, ...) -> StructName
    // Named as the module's own code names it (`Dog`, as in its annotations);
    // importers see it with its module (`Geometry.Point`).
    let tycon = TyCon::new(&name);
    let struct_ty = if generic_params.is_empty() {
        Ty::App(Box::new(Ty::Con(tycon)), vec![])
    } else {
        let type_args: Vec<Ty> = generic_params.iter().map(|_| ctx.fresh_var()).collect();
        Ty::App(Box::new(Ty::Con(tycon)), type_args)
    };

    // Opaque resources are nominal declarations backed by trusted runtime
    // producers. Their type name must never double as a zero-field value
    // constructor that source code can use to fabricate a handle.
    if !struct_def.is_opaque_resource() {
        env.insert(name.clone(), Scheme::mono(struct_ty));
    }

    // Conditional auto-registration of trait impls based on deriving clause.
    // No deriving clause = backward compat (derive all default traits).
    // Explicit deriving(...) = only derive listed traits.
    let is_affine_resource = struct_def.is_declared_resource()
        || fields
            .iter()
            .any(|(_, field_ty)| type_registry.is_resource_type(field_ty));
    if is_affine_resource {
        type_registry.register_resource_type(name.clone());
    }
    // A struct holding plaintext shows, compares and serializes nothing of
    // itself unless the program writes the impl (which cannot read the
    // plaintext): no default derives, and none it asks for.
    let holds_plaintext = type_registry.plaintext_types.contains(&name)
        || fields
            .iter()
            .any(|(_, field_ty)| type_registry.is_plaintext_type(field_ty));
    let has_deriving = struct_def.has_deriving_clause();
    let derive_list = struct_def.deriving_traits();
    let fn_field = fields
        .iter()
        .find(|(_, ty)| holds_function(ty))
        .map(|(field, _)| (field.clone(), struct_field_span(struct_def, field)));
    let (derive_list, derive_all) = without_function_derives(
        ctx,
        &name,
        derive_list,
        !has_deriving && !is_affine_resource && !holds_plaintext,
        fn_field,
    );
    if holds_plaintext && refuse_plaintext_derives(ctx, &name, &derive_list, struct_def.syntax()) {
        trait_registry.register_nominal(&name);
        type_registry.register_struct(StructDefInfo {
            name,
            generic_params,
            fields,
            schema: None,
        });
        return;
    }

    // Validate derive trait names.
    let valid_derives = [
        "Eq", "Ord", "Display", "Debug", "Hash", "Json", "Row", "Schema",
    ];
    for trait_name in &derive_list {
        if !valid_derives.contains(&trait_name.as_str()) {
            ctx.errors.push(TypeError::UnsupportedDerive {
                trait_name: trait_name.clone(),
                type_name: name.clone(),
                span: deriving_span(struct_def.syntax()),
            });
        }
    }

    if is_affine_resource && !derive_list.is_empty() {
        for trait_name in &derive_list {
            ctx.errors.push(TypeError::ResourceCrossesBoundary {
                reason: format!("resource type `{name}` cannot derive `{trait_name}`"),
                span: struct_def.syntax().text_range(),
            });
        }
        trait_registry.register_nominal(&name);
        type_registry.register_struct(StructDefInfo {
            name,
            generic_params,
            fields,
            schema: None,
        });
        return;
    }

    // Check trait dependencies: Ord requires Eq.
    if has_deriving
        && derive_list.iter().any(|t| t == "Ord")
        && !derive_list.iter().any(|t| t == "Eq")
    {
        ctx.errors.push(TypeError::MissingDerivePrerequisite {
            trait_name: "Ord".to_string(),
            requires: "Eq".to_string(),
            type_name: name.clone(),
            span: deriving_span(struct_def.syntax()),
        });
        // Register the struct type info so the rest of compilation doesn't crash,
        // but skip trait impl registration to avoid generating broken MIR.
        trait_registry.register_nominal(&name);
        type_registry.register_struct(StructDefInfo {
            name,
            generic_params,
            fields,
            schema: None,
        });
        return;
    }

    // Build the impl type: non-generic uses Ty::Con, generic uses Ty::App
    // over sigil parameters (`'Item`), which the registry always treats as
    // parameters, whatever their names.
    let impl_ty = if generic_params.is_empty() {
        Ty::Con(TyCon::new(&name))
    } else {
        let base_ty = Ty::Con(TyCon::new(&name));
        let param_tys: Vec<Ty> = generic_params
            .iter()
            .map(|p| Ty::Con(TyCon::new(format!("'{p}"))))
            .collect();
        Ty::App(Box::new(base_ty), param_tys)
    };

    // Schema metadata functions -- only via explicit deriving(Schema), structs only.
    if derive_list.iter().any(|t| t == "Schema") {
        let fields: Vec<String> = struct_def
            .fields()
            .filter_map(|field| field.name()?.text())
            .collect();
        register_schema_functions(env, &name, fields.iter().map(String::as_str));

        // Register Schema trait impl so it's exported via collect_exports
        // and available for cross-module import resolution.
        let _ = trait_registry.register_impl(TraitImplDef {
            trait_name: "Schema".to_string(),
            trait_type_args: vec![],
            impl_type: impl_ty.clone(),
            impl_type_name: name.clone(),
            methods: FxHashMap::default(),
            associated_types: FxHashMap::default(),
        });
    }

    // A struct derives Hash by default, and Display only when asked.
    let fields_needing = fields.iter().map(|(field, ty)| {
        (
            field.clone(),
            ty.clone(),
            struct_field_span(struct_def, field),
        )
    });
    record_derive_needs(
        ctx,
        &name,
        &generic_params,
        &derive_list,
        derive_all,
        fields_needing,
    );
    register_value_trait_impls(trait_registry, &name, &impl_ty, |t| {
        derive_list.iter().any(|d| d == t) || (derive_all && t != "Display")
    });

    // Json impl (ToJson + FromJson) -- only via explicit deriving(Json)
    if derive_list.iter().any(|t| t == "Json") {
        // Validate all fields are JSON-serializable BEFORE registering impls.
        let mut json_valid = true;
        for (field_name, field_ty) in &fields {
            if !is_json_serializable(field_ty, &generic_params, &ctx.json_types, trait_registry) {
                ctx.errors.push(TypeError::NonSerializableField {
                    struct_name: name.clone(),
                    field_name: field_name.clone(),
                    field_type: field_ty.with_holes().to_string(),
                    span: struct_field_span(struct_def, field_name),
                });
                json_valid = false;
            }
        }

        if json_valid {
            register_json_impls(trait_registry, &name, &impl_ty);
        }
    }

    // Row impl (FromRow) -- only via explicit deriving(Row), structs only
    if derive_list.iter().any(|t| t == "Row") {
        let mut row_valid = true;
        for (field_name, field_ty) in &fields {
            if !is_row_mappable(field_ty) {
                ctx.errors.push(TypeError::NonMappableField {
                    struct_name: name.clone(),
                    field_name: field_name.clone(),
                    field_type: field_ty.with_holes().to_string(),
                    span: struct_field_span(struct_def, field_name),
                });
                row_valid = false;
            }
        }

        if row_valid {
            // `Name.from_row(row)`, of a `Map<String, String>`.
            let decoded = Ty::result(Ty::Con(TyCon::new(&name)), Ty::string());
            register_derived_impl(
                trait_registry,
                &name,
                &impl_ty,
                "FromRow",
                ("from_row", false, 1, decoded),
            );
        }
    }

    let schema = derive_list
        .iter()
        .any(|t| t == "Schema")
        .then(|| schema_info(struct_def, &name));
    type_registry.register_struct(StructDefInfo {
        name,
        generic_params,
        fields,
        schema,
    });
}

/// The one method of an impl a `deriving` gives a type: its name, whether
/// it takes `self`, how many arguments it takes besides, and its return type.
type DerivedMethod<'a> = (&'a str, bool, usize, Ty);

/// Register the impl of `trait_name` a `deriving` gives the type `name`
/// (`impl_ty`), with its one method.
fn register_derived_impl(
    trait_registry: &mut TraitRegistry,
    name: &str,
    impl_ty: &Ty,
    trait_name: &str,
    (method, has_self, param_count, ret): DerivedMethod,
) {
    let sig = ImplMethodSig {
        has_self,
        param_count,
        return_type: Some(ret),
        param_types: None,
    };
    let _ = trait_registry.register_impl(TraitImplDef {
        trait_name: trait_name.to_string(),
        trait_type_args: vec![],
        impl_type: impl_ty.clone(),
        impl_type_name: name.to_string(),
        methods: std::iter::once((method.to_string(), sig)).collect(),
        associated_types: FxHashMap::default(),
    });
}

/// Register the impls `deriving(Json)` gives the type `name` (`impl_ty`):
/// `value.to_json()` and `Name.from_json(text)`.
fn register_json_impls(trait_registry: &mut TraitRegistry, name: &str, impl_ty: &Ty) {
    let to_json = ("to_json", true, 0, Ty::Con(TyCon::new("Json")));
    register_derived_impl(trait_registry, name, impl_ty, "ToJson", to_json);
    let decoded = Ty::result(Ty::Con(TyCon::new(name)), Ty::string());
    let from_json = ("from_json", false, 1, decoded);
    register_derived_impl(trait_registry, name, impl_ty, "FromJson", from_json);
}

/// Register the impls of the traits that compare, hash or show values
/// that `derives` says the type `name` (`impl_ty`) has.
fn register_value_trait_impls(
    trait_registry: &mut TraitRegistry,
    name: &str,
    impl_ty: &Ty,
    derives: impl Fn(&str) -> bool,
) {
    for (trait_name, method) in [
        ("Debug", ("inspect", true, 0, Ty::string())),
        ("Eq", ("eq", true, 1, Ty::bool())),
        ("Ord", ("lt", true, 1, Ty::bool())),
        ("Hash", ("hash", true, 0, Ty::int())),
        ("Display", ("to_string", true, 0, Ty::string())),
    ] {
        if derives(trait_name) {
            register_derived_impl(trait_registry, name, impl_ty, trait_name, method);
        }
    }
}

/// Whether a value of type `ty` holds a function, which cannot be compared,
/// hashed or shown.
fn holds_function(ty: &Ty) -> bool {
    matches!(ty, Ty::Fun(..)) || ty.parts().any(holds_function)
}

/// The derives of type `name` once a function-valued field (`fn_field`:
/// its label and span) is taken into account: it gets none of the traits
/// that compare, hash or show values by default, and naming one of them is
/// an error at the field. Returns the derive list and whether to derive the
/// defaults.
fn without_function_derives(
    ctx: &mut InferCtx,
    name: &str,
    derive_list: Vec<String>,
    derive_all: bool,
    fn_field: Option<(String, TextRange)>,
) -> (Vec<String>, bool) {
    let Some((field, span)) = fn_field else {
        return (derive_list, derive_all);
    };
    let needs_values = |t: &str| matches!(t, "Eq" | "Ord" | "Hash" | "Debug" | "Display");
    for trait_name in derive_list.iter().filter(|t| needs_values(t)) {
        ctx.errors.push(TypeError::UnderivableField {
            trait_name: trait_name.clone(),
            type_name: name.to_string(),
            field_name: field.clone(),
            span,
        });
    }
    let kept = derive_list
        .into_iter()
        .filter(|t| !needs_values(t))
        .collect();
    (kept, false)
}

/// Where a diagnostic about a type definition's derives points: its
/// `deriving(...)` clause, else the whole definition.
fn deriving_span(def: &mesh_parser::SyntaxNode) -> TextRange {
    def.children()
        .find(|n| n.kind() == SyntaxKind::DERIVING_CLAUSE)
        .map(|n| n.text_range())
        .unwrap_or_else(|| def.text_range())
}

/// The span of the struct field named `field`, else the deriving clause.
fn struct_field_span(struct_def: &StructDef, field: &str) -> TextRange {
    struct_def
        .fields()
        .find(|f| f.name().and_then(|n| n.text()).as_deref() == Some(field))
        .map(|f| f.syntax().text_range())
        .unwrap_or_else(|| deriving_span(struct_def.syntax()))
}

/// Whether a field of type `ty` can be converted to and from JSON: a
/// scalar, one of `params` (checked where the type is used), a tuple, an
/// `Option`, `List` or `Map<String, _>` of such, or a type deriving Json
/// (`json_types` holds this module's, declared anywhere in it).
fn is_json_serializable(
    ty: &Ty,
    params: &[String],
    json_types: &rustc_hash::FxHashSet<String>,
    trait_registry: &TraitRegistry,
) -> bool {
    let ok = |t: &Ty| is_json_serializable(t, params, json_types, trait_registry);
    let derives_json = |name: &str| {
        json_types.contains(name) || trait_registry.has_impl("ToJson", &Ty::Con(TyCon::new(name)))
    };
    let args: &[Ty] = match ty {
        Ty::Tuple(elems) => return !elems.is_empty() && elems.iter().all(ok),
        Ty::App(_, args) => args,
        _ => &[],
    };
    match ty.con_name() {
        Some("Int" | "Float" | "Bool" | "String") => true,
        Some("Option" | "List") => args.first().is_some_and(ok),
        // JSON object keys are strings.
        Some("Map") => args.first() == Some(&Ty::string()) && args.get(1).is_some_and(ok),
        Some(name) => {
            params.iter().any(|p| p == name) || (derives_json(name) && args.iter().all(ok))
        }
        None => false, // Type variables, functions, etc. are not serializable
    }
}

/// Check if a type is row-mappable for deriving(Row) validation.
/// Row-mappable: Int, Float, Bool, String, Option<T> where T is row-mappable primitive.
/// NOT mappable: nested structs, sum types (except Option), List, Map, Ptr.
fn is_row_mappable(ty: &Ty) -> bool {
    match ty {
        Ty::Con(con) => matches!(con.name.as_str(), "Int" | "Float" | "Bool" | "String"),
        _ => ty
            .args_of("Option")
            .and_then(<[Ty]>::first)
            .is_some_and(is_row_mappable),
    }
}

/// Register a type alias.
fn register_type_alias(alias_def: &TypeAliasDef, type_registry: &mut TypeRegistry) {
    let name = alias_def
        .name()
        .and_then(|n| n.text())
        .unwrap_or_else(|| "<unnamed>".to_string());
    // Its type parameters stand in the aliased type as the types of their
    // names (`A` in `type Pair<A> = (A, A)`).
    type_registry.register_alias(TypeAliasInfo {
        name,
        generic_params: generic_param_names(alias_def.syntax()),
        aliased_type: type_after_eq(alias_def.syntax()).unwrap_or(Ty::Never),
    });
}

// ── Type Alias Validation (ALIAS-04) ──────────────────────────────────

/// The nodes of a file whose types are its module's. In a project a
/// `module ... do ... end` block is a module of its own (checked from the
/// file with the rest masked), so the file's module skips it: a block's
/// private struct was usable outside it without an import. A file checked
/// alone keeps its blocks' types.
fn file_items(
    root: mesh_parser::SyntaxNode,
    import_ctx: &ImportContext,
) -> impl Iterator<Item = mesh_parser::SyntaxNode> {
    let in_project = import_ctx.current_module.is_some();
    root.descendants().filter(move |node| {
        !in_project
            || !node
                .ancestors()
                .skip(1)
                .any(|ancestor| ancestor.kind() == SyntaxKind::MODULE_DEF)
    })
}

/// Check whether a type name is known: a primitive, struct, sum type, or alias.
fn is_known_type(name: &str, type_registry: &TypeRegistry) -> bool {
    // Known primitive and builtin types
    matches!(
        name,
        "Int"
            | "Float"
            | "String"
            | "Bool"
            | "Unit"
            | "Option"
            | "Result"
            | "List"
            | "Map"
            | "Set"
            | "Range"
            | "Queue"
            | "Pid"
            | "Atom"
            | "Regex"
            | "Bytes"
            | "SecretBytes"
            | "SecretMap"
            | "StorageKey"
            | "CryptoError"
            | "X25519PrivateKey"
            | "SigningPrivateKey"
            | "AeadKey"
            | "Never"
    ) || type_registry.struct_defs.contains_key(name)
        || type_registry.sum_type_defs.contains_key(name)
        || type_registry.type_aliases.contains_key(name)
        || type_registry.resource_types.contains(name)
}

/// Whether `ty` names one of the types `names`.
fn names_any(ty: &Ty, names: &FxHashSet<String>) -> bool {
    let mut named = Vec::new();
    type_constructors(ty, &mut named);
    named.iter().any(|name| names.contains(name))
}

/// The name of every type constructor in `ty`.
fn type_constructors(ty: &Ty, out: &mut Vec<String>) {
    if ty.is_proof() {
        return;
    }
    match ty {
        Ty::Con(tc) => out.push(tc.name.clone()),
        _ => ty.parts().for_each(|part| type_constructors(part, out)),
    }
}

/// Every type the builtins name: their signatures, their impls (the
/// iterator types), and the fields of the runtime's structs and sum types.
fn builtin_type_names(
    env: &TypeEnv,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
) -> FxHashSet<String> {
    let mut names = Vec::new();
    for scheme in env.schemes() {
        type_constructors(&scheme.ty, &mut names);
    }
    // Types only the standard library's modules mention, such as `Iter`.
    for scheme in stdlib_modules(true)
        .values()
        .flat_map(|module| module.values())
    {
        type_constructors(&scheme.ty, &mut names);
    }
    for ty in trait_registry.impl_types() {
        type_constructors(ty, &mut names);
    }
    // A field's type names the type's own parameters too (`Some(T)`), which
    // are no types anywhere else.
    let mut field_names = |name: &str, generic_params: &[String], fields: Vec<&Ty>| {
        names.push(name.to_string());
        let mut named = Vec::new();
        fields
            .into_iter()
            .for_each(|ty| type_constructors(ty, &mut named));
        names.extend(named.into_iter().filter(|n| !generic_params.contains(n)));
    };
    for info in type_registry.struct_defs.values() {
        field_names(
            &info.name,
            &info.generic_params,
            info.fields.iter().map(|(_, ty)| ty).collect(),
        );
    }
    for info in type_registry.sum_type_defs.values() {
        let fields = info.variants.iter().flat_map(|variant| &variant.fields);
        field_names(
            &info.name,
            &info.generic_params,
            fields
                .map(|field| match field {
                    VariantFieldInfo::Positional(ty) | VariantFieldInfo::Named(_, ty) => ty,
                })
                .collect(),
        );
    }
    names.into_iter().collect()
}

fn declared_type_names(registry: &TypeRegistry) -> impl Iterator<Item = &str> {
    registry
        .struct_defs
        .keys()
        .chain(registry.sum_type_defs.keys())
        .chain(registry.type_aliases.keys())
        .chain(registry.resource_types.iter())
        .map(String::as_str)
}

/// An impl names an interface and a type that exist: `impl Dispaly for P`
/// (a typo) or `impl Show for Nope` was accepted and did nothing. Returns
/// whether the type exists: an impl for none implements nothing (`impl Show
/// for T` was taken for an impl for every type).
fn check_impl_header(
    ctx: &mut InferCtx,
    impl_: &AstImplDef,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    builtin_types: &FxHashSet<String>,
) -> bool {
    if let Some(name) = impl_.interface_name() {
        if trait_registry.get_trait(name.text()).is_none() {
            ctx.errors.push(TypeError::UnknownInterface {
                name: name.text().to_string(),
                span: name.text_range(),
            });
        }
    }
    let Some(ty) = impl_.type_name() else {
        return false;
    };
    let known = builtin_types.contains(ty.text()) || is_known_type(ty.text(), type_registry);
    if !known {
        ctx.errors.push(TypeError::UnknownType {
            name: ty.text().to_string(),
            span: ty.text_range(),
            suggestion: closest_name(
                ty.text(),
                declared_type_names(type_registry).chain(builtin_types.iter().map(String::as_str)),
            ),
        });
    }
    // Registered for the bare type, the impl was accepted but no value
    // (`Box<Int>`, `Option<Int>`) ever had its methods.
    let generic = matches!(ty.text(), "List" | "Map" | "Set")
        || declared_param_count(type_registry, ty.text()).is_some_and(|count| count > 0);
    if generic {
        ctx.errors.push(TypeError::GenericImplTarget {
            name: ty.text().to_string(),
            span: ty.text_range(),
        });
    }
    known
}

/// Report each type name an annotation uses that names no type: a
/// misspelled `Strng` would otherwise become a new, empty type.
fn check_annotation_types(
    ctx: &mut InferCtx,
    root: &mesh_parser::SyntaxNode,
    type_registry: &TypeRegistry,
    builtin_types: &FxHashSet<String>,
    import_ctx: &ImportContext,
) {
    let annotations = root.descendants().filter(|n| {
        n.kind() == SyntaxKind::TYPE_ANNOTATION
            && !n
                .parent()
                .is_some_and(|parent| parent.kind() == SyntaxKind::INDEX_PARAM)
            && !n
                .ancestors()
                .skip(1)
                .any(|a| a.kind() == SyntaxKind::TYPE_ANNOTATION)
    });
    for ann in annotations {
        // A name is an IDENT, with `.IDENT` segments for a qualified one.
        let mut names: Vec<(String, TextRange)> = Vec::new();
        let mut after_dot = false;
        for token in ann.descendants_with_tokens().filter_map(|e| e.into_token()) {
            if token.parent_ancestors().any(|n| {
                n.kind() == SyntaxKind::OWNERSHIP_MODIFIER
                    || crate::proof_values::is_proposition_arguments(&n)
            }) {
                continue;
            }
            match token.kind() {
                SyntaxKind::IDENT if after_dot => {
                    if let Some((name, range)) = names.last_mut() {
                        name.push('.');
                        name.push_str(token.text());
                        *range = range.cover(token.text_range());
                    }
                    after_dot = false;
                }
                SyntaxKind::IDENT => names.push((token.text().to_string(), token.text_range())),
                SyntaxKind::DOT => after_dot = true,
                _ => after_dot = false,
            }
        }
        for (name, span) in names {
            if !names_a_type(&name, &ann, type_registry, builtin_types, import_ctx) {
                ctx.unknown_types.insert(name.clone());
                let suggestion = if let Some((module, short)) = name.rsplit_once('.') {
                    import_ctx
                        .module_at_path(module)
                        .or_else(|| import_ctx.module_at_qualifier(module))
                        .and_then(|exports| {
                            closest_name(
                                short,
                                exports
                                    .struct_defs
                                    .keys()
                                    .chain(exports.sum_type_defs.keys())
                                    .chain(exports.type_aliases.keys())
                                    .map(String::as_str),
                            )
                        })
                        .map(|close| format!("{module}.{close}"))
                } else {
                    let params: Vec<_> = ann
                        .ancestors()
                        .flat_map(|item| generic_param_names(&item))
                        .collect();
                    closest_name(
                        &name,
                        declared_type_names(type_registry)
                            .chain(builtin_types.iter().map(String::as_str))
                            .chain(params.iter().map(String::as_str)),
                    )
                };
                ctx.errors.push(TypeError::UnknownType {
                    name,
                    span,
                    suggestion,
                });
            }
        }
    }
}

/// Whether `name`, written in a type at `node`, names a type: one the
/// builtins or this module define, one an imported module exports, or a
/// type parameter of an item around `node`.
fn names_a_type(
    name: &str,
    node: &mesh_parser::SyntaxNode,
    type_registry: &TypeRegistry,
    builtin_types: &FxHashSet<String>,
    import_ctx: &ImportContext,
) -> bool {
    if name == "Self"
        || name.starts_with("Self.")
        || matches!(name, "Fun" | "Succ" | crate::proof_values::PROOF_TYPE)
    {
        return true;
    }
    if builtin_types.contains(name) || is_known_type(name, type_registry) {
        return true;
    }
    if let Some((module, short)) = name.rsplit_once('.') {
        return (import_ctx.module_at_path(module).is_some()
            || import_ctx.module_at_qualifier(module).is_some())
            && is_known_type(short, type_registry);
    }
    // The type parameters of the enclosing items.
    node.ancestors()
        .any(|item| generic_param_names(&item).iter().any(|param| param == name))
}

/// Report each alias that could never be expanded, as it names itself, and
/// each type an alias names that does not exist, as an annotation's are
/// checked: every type in it, the builtins' and imported ones included.
///
/// Called after all type pre-registrations are complete (structs, sum types,
/// and type aliases all registered) so that forward references resolve correctly.
fn validate_type_aliases(
    ctx: &mut InferCtx,
    type_registry: &TypeRegistry,
    alias_defs: &[(TypeAliasDef, rowan::TextRange)],
    builtin_types: &FxHashSet<String>,
    import_ctx: &ImportContext,
) {
    for (alias_def, range) in alias_defs {
        let Some(alias_name) = alias_def.name().and_then(|n| n.text()) else {
            continue;
        };
        if alias_is_cyclic(&alias_name, type_registry) {
            ctx.errors.push(TypeError::CyclicAlias {
                alias_name,
                span: *range,
            });
            continue;
        }
        let aliased_type = &type_registry.type_aliases[&alias_name].aliased_type;
        if let Some((name, expected, found)) =
            wrong_type_argument_count(aliased_type, type_registry)
        {
            ctx.errors.push(TypeError::TypeArgumentCount {
                name,
                expected,
                found,
                span: *range,
            });
        }
        let mut named = Vec::new();
        type_constructors(aliased_type, &mut named);
        for target_name in named {
            let node = alias_def.syntax();
            if !names_a_type(&target_name, node, type_registry, builtin_types, import_ctx) {
                // Reported here, not again at each use of the alias.
                ctx.unknown_types.insert(target_name.clone());
                ctx.errors.push(TypeError::UndefinedType {
                    alias_name: alias_name.clone(),
                    target_name,
                    span: *range,
                });
            }
        }
    }
}

/// Whether the alias `name` refers back to itself through the aliases its
/// definition names (`type A = B` with `type B = A`, or
/// `type L<T> = List<L<T>>`), so it could never be expanded.
fn alias_is_cyclic(name: &str, type_registry: &TypeRegistry) -> bool {
    let constructors = type_constructors;
    let mut stack = vec![name.to_string()];
    let mut seen = FxHashSet::default();
    while let Some(current) = stack.pop() {
        let Some(alias) = type_registry.lookup_alias(&current) else {
            continue;
        };
        let mut names = Vec::new();
        constructors(&alias.aliased_type, &mut names);
        for referenced in names {
            if referenced == name {
                return true;
            }
            if seen.insert(referenced.clone()) {
                stack.push(referenced);
            }
        }
    }
    false
}

// ── Sum Type Registration (04-02) ──────────────────────────────────────

fn sum_type_def_info(
    ctx: &mut InferCtx,
    sum_def: &SumTypeDef,
    type_registry: &TypeRegistry,
) -> SumTypeDefInfo {
    let name = sum_def
        .name()
        .and_then(|n| n.text())
        .unwrap_or_else(|| "<unnamed>".to_string());

    // Extract generic type parameters.
    let generic_params = generic_param_names(sum_def.syntax());
    let indexed = index_family_info(
        sum_def.syntax(),
        ctx.current_module.as_deref().unwrap_or_default(),
    );
    let mut info = SumTypeDefInfo {
        name,
        generic_params,
        indexed,
        variants: Vec::new(),
    };
    if info.indexed.is_some() {
        let mut seen = FxHashSet::default();
        for param in &info.generic_params {
            if !seen.insert(param) {
                invalid_indexed_type(
                    ctx,
                    significant_range(sum_def.syntax()),
                    format!("duplicate parameter `{param}`"),
                );
            }
        }
    }

    // Extract variants.
    for variant_def in sum_def.variants() {
        let variant_name = variant_def
            .name()
            .map(|t| t.text().to_string())
            .unwrap_or_else(|| "<unnamed>".to_string());

        let mut fields = Vec::new();

        // Check for named fields first (VARIANT_FIELD children).
        let named_fields: Vec<_> = variant_def.fields().collect();
        if !named_fields.is_empty() {
            for field in named_fields {
                let field_name = field
                    .name()
                    .and_then(|n| n.text())
                    .unwrap_or_else(|| "<unnamed>".to_string());
                let field_ty = field
                    .type_annotation()
                    .and_then(|ann| resolve_type_annotation(ctx, &ann, type_registry))
                    .unwrap_or_else(|| ctx.fresh_var());
                fields.push(VariantFieldInfo::Named(field_name, field_ty));
            }
        } else {
            // Positional types (TYPE_ANNOTATION children directly under VARIANT_DEF).
            for type_ann in variant_def.positional_types() {
                let field_ty = resolve_type_annotation(ctx, &type_ann, type_registry)
                    .unwrap_or_else(|| ctx.fresh_var());
                fields.push(VariantFieldInfo::Positional(field_ty));
            }
        }

        let indices: Vec<_> = index_param_names(variant_def.syntax()).collect();
        let explicit = variant_def.result_type();
        let span = significant_range(variant_def.syntax());
        if generic_param_names(variant_def.syntax()).len() != indices.len() {
            invalid_indexed_type(
                ctx,
                span,
                "constructor parameters must have kind `Nat`".into(),
            );
        }
        let indexed = if info.indexed.is_some() {
            let mut seen = FxHashSet::default();
            for param in &indices {
                if info.runtime_generic_params().any(|outer| outer == param) || !seen.insert(param)
                {
                    invalid_indexed_type(
                        ctx,
                        span,
                        format!("duplicate constructor parameter `{param}`"),
                    );
                }
            }
            let result = match explicit {
                Some(ann) => {
                    let result =
                        resolve_type_annotation(ctx, &ann, type_registry).unwrap_or(Ty::Never);
                    if result != Ty::Never {
                        if let Err(error) = check_variant_result(&info, &result, &indices) {
                            invalid_indexed_type(ctx, annotated_type_range(&ann), error);
                        }
                    }
                    result
                }
                None => {
                    invalid_indexed_type(
                        ctx,
                        span,
                        "each indexed constructor must declare its result type".into(),
                    );
                    Ty::Never
                }
            };
            for field in &fields {
                let field = match field {
                    VariantFieldInfo::Named(_, ty) | VariantFieldInfo::Positional(ty) => ty,
                };
                if let Err(error) = check_variant_field(field, &indices) {
                    invalid_indexed_type(ctx, span, error);
                }
            }
            Some(IndexedVariantInfo {
                index_params: indices,
                result,
            })
        } else {
            if !indices.is_empty() || explicit.is_some() {
                invalid_indexed_type(
                    ctx,
                    span,
                    "constructor indices and explicit results require an indexed sum type".into(),
                );
            }
            None
        };
        info.variants.push(VariantInfo {
            name: variant_name,
            fields,
            indexed,
        });
    }

    info
}

/// Register a sum type definition and its polymorphic variant constructors.
fn register_sum_type_def(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    sum_def: &SumTypeDef,
    type_registry: &mut TypeRegistry,
    trait_registry: &mut TraitRegistry,
) {
    let sum_name = sum_def
        .name()
        .and_then(|name| name.text())
        .unwrap_or_default();
    let sum_info = match type_registry.lookup_sum_type(&sum_name) {
        Some(info) if info.indexed.is_some() => info.clone(),
        _ => sum_type_def_info(ctx, sum_def, type_registry),
    };
    let indexed = sum_info.indexed.is_some();
    let name = sum_info.name.clone();
    let generic_params = sum_info.generic_params.clone();
    let variants = sum_info.variants.clone();
    type_registry.register_sum_type(sum_info);
    trait_registry.register_nominal(&name);
    type_registry.propagate_resource_containment();
    let is_affine_resource = type_registry.is_resource_name(&name);
    let holds_plaintext = type_registry.plaintext_types.contains(&name);

    // A variant declared twice in the type.
    let mut declared: Vec<String> = Vec::new();
    for variant_def in sum_def.variants() {
        let Some(variant) = variant_def.name().map(|t| t.text().to_string()) else {
            continue;
        };
        if declared.contains(&variant) {
            ctx.errors.push(TypeError::DuplicateDefinition {
                kind: "variant",
                name: variant,
                span: variant_def.syntax().text_range(),
            });
        } else {
            declared.push(variant);
        }
    }

    // An unqualified variant name names one variant of this module (one
    // of an imported type it shadows); two here would be ambiguous. The
    // first keeps the unqualified name; the second is still `B.Same`.
    let mut kept = Vec::new();
    for variant in &variants {
        match ctx.local_variants.get(&variant.name) {
            Some(first) if *first != name => {
                if let Some(scheme) = env.lookup(&variant.name) {
                    kept.push((variant.name.clone(), scheme.clone()));
                }
                ctx.errors.push(TypeError::DuplicateVariant {
                    variant: variant.name.clone(),
                    first_type: first.clone(),
                    second_type: name.clone(),
                    span: sum_def
                        .variants()
                        .find(|v| v.name().is_some_and(|n| n.text() == variant.name))
                        .map(|v| v.syntax().text_range())
                        .unwrap_or_else(|| sum_def.syntax().text_range()),
                });
            }
            _ => {
                ctx.local_variants
                    .insert(variant.name.clone(), name.clone());
            }
        }
    }

    // Register each variant constructor using the shared mechanism.
    register_variant_constructors(ctx, env, &name, &generic_params, &variants);
    for (variant, scheme) in kept {
        env.insert(variant, scheme);
    }

    if indexed {
        if !sum_def.deriving_traits().is_empty() {
            invalid_indexed_type(
                ctx,
                deriving_span(sum_def.syntax()),
                "deriving traits for indexed sum types is unsupported".into(),
            );
        }
        return;
    }

    // Conditional auto-registration of trait impls based on deriving clause.
    // No deriving clause = backward compat (derive all default traits).
    // Explicit deriving(...) = only derive listed traits.
    let has_deriving = sum_def.has_deriving_clause();
    let derive_list = sum_def.deriving_traits();
    let fn_field = variants.iter().find_map(|variant| {
        variant.fields.iter().enumerate().find_map(|(i, field)| {
            let (label, ty) = match field {
                VariantFieldInfo::Positional(ty) => (format!("{}::{i}", variant.name), ty),
                VariantFieldInfo::Named(field, ty) => (format!("{}::{field}", variant.name), ty),
            };
            holds_function(ty).then(|| {
                let span = sum_def
                    .variants()
                    .find(|v| v.name().is_some_and(|n| n.text() == variant.name))
                    .map(|v| v.syntax().text_range())
                    .unwrap_or_else(|| deriving_span(sum_def.syntax()));
                (label, span)
            })
        })
    });
    let (derive_list, derive_all) = without_function_derives(
        ctx,
        &name,
        derive_list,
        !has_deriving && !is_affine_resource && !holds_plaintext,
        fn_field,
    );
    if holds_plaintext && refuse_plaintext_derives(ctx, &name, &derive_list, sum_def.syntax()) {
        return;
    }

    // Validate derive trait names.
    let valid_derives = [
        "Eq", "Ord", "Display", "Debug", "Hash", "Json", "Row", "Schema",
    ];
    for trait_name in &derive_list {
        if !valid_derives.contains(&trait_name.as_str()) {
            ctx.errors.push(TypeError::UnsupportedDerive {
                trait_name: trait_name.clone(),
                type_name: name.clone(),
                span: deriving_span(sum_def.syntax()),
            });
        }
    }

    if is_affine_resource && !derive_list.is_empty() {
        for trait_name in &derive_list {
            ctx.errors.push(TypeError::ResourceCrossesBoundary {
                reason: format!("resource type `{name}` cannot derive `{trait_name}`"),
                span: sum_def.syntax().text_range(),
            });
        }
        return;
    }

    // Row and Schema map struct fields to columns; a sum type has none.
    for trait_name in derive_list.iter().filter(|t| *t == "Row" || *t == "Schema") {
        ctx.errors.push(TypeError::UnsupportedDerive {
            trait_name: trait_name.clone(),
            type_name: name.clone(),
            span: deriving_span(sum_def.syntax()),
        });
    }

    // Check trait dependencies: Ord requires Eq.
    if has_deriving
        && derive_list.iter().any(|t| t == "Ord")
        && !derive_list.iter().any(|t| t == "Eq")
    {
        ctx.errors.push(TypeError::MissingDerivePrerequisite {
            trait_name: "Ord".to_string(),
            requires: "Eq".to_string(),
            type_name: name.clone(),
            span: deriving_span(sum_def.syntax()),
        });
        // Sum type and variant constructors are already registered above.
        // Skip trait impl registration to avoid generating broken MIR.
        return;
    }

    // Build the impl type: non-generic uses Ty::Con, generic uses Ty::App
    // over sigil parameters (`'Item`), which the registry always treats as
    // parameters, whatever their names.
    let impl_ty = if generic_params.is_empty() {
        Ty::Con(TyCon::new(&name))
    } else {
        let base_ty = Ty::Con(TyCon::new(&name));
        let param_tys: Vec<Ty> = generic_params
            .iter()
            .map(|p| Ty::Con(TyCon::new(format!("'{p}"))))
            .collect();
        Ty::App(Box::new(base_ty), param_tys)
    };

    let payloads_needing = variants.iter().flat_map(|variant| {
        let span = sum_def
            .variants()
            .find(|v| v.name().is_some_and(|n| n.text() == variant.name))
            .map(|v| v.syntax().text_range())
            .unwrap_or_else(|| deriving_span(sum_def.syntax()));
        variant
            .fields
            .iter()
            .enumerate()
            .map(move |(i, field)| match field {
                VariantFieldInfo::Positional(ty) => {
                    (format!("{}::{i}", variant.name), ty.clone(), span)
                }
                VariantFieldInfo::Named(field, ty) => {
                    (format!("{}::{field}", variant.name), ty.clone(), span)
                }
            })
    });
    let payloads_needing: Vec<_> = payloads_needing.collect();
    record_derive_needs(
        ctx,
        &name,
        &generic_params,
        &derive_list,
        derive_all,
        payloads_needing,
    );
    // A sum type derives neither Hash nor Display unless asked.
    register_value_trait_impls(trait_registry, &name, &impl_ty, |t| {
        derive_list.iter().any(|d| d == t) || (derive_all && !matches!(t, "Hash" | "Display"))
    });

    // Json impl (ToJson + FromJson) -- only via explicit deriving(Json)
    if derive_list.iter().any(|t| t == "Json") {
        // Validate all variant field types are JSON-serializable.
        let mut json_valid = true;
        for variant in &variants {
            for (field_idx, field) in variant.fields.iter().enumerate() {
                let field_ty = match field {
                    VariantFieldInfo::Positional(ty) => ty,
                    VariantFieldInfo::Named(_, ty) => ty,
                };
                if !is_json_serializable(field_ty, &generic_params, &ctx.json_types, trait_registry)
                {
                    let field_ident = match field {
                        VariantFieldInfo::Positional(_) => {
                            format!("{}::{}", variant.name, field_idx)
                        }
                        VariantFieldInfo::Named(fname, _) => format!("{}::{}", variant.name, fname),
                    };
                    ctx.errors.push(TypeError::NonSerializableField {
                        struct_name: name.clone(),
                        field_name: field_ident,
                        field_type: field_ty.with_holes().to_string(),
                        span: sum_def
                            .variants()
                            .find(|v| v.name().is_some_and(|n| n.text() == variant.name))
                            .map(|v| v.syntax().text_range())
                            .unwrap_or_else(|| deriving_span(sum_def.syntax())),
                    });
                    json_valid = false;
                }
            }
        }

        if json_valid {
            register_json_impls(trait_registry, &name, &impl_ty);
        }
    }
}

// ── Interface/Impl Registration (03-04) ───────────────────────────────

/// A method's non-self parameter types, when every one is annotated.
fn method_param_types(
    ctx: &mut InferCtx,
    param_list: Option<mesh_parser::ast::item::ParamList>,
    self_assoc: &FxHashMap<String, Ty>,
    type_registry: &TypeRegistry,
) -> Option<Vec<Ty>> {
    let mut types = Vec::new();
    for param in param_list?.params() {
        if param.is_self() {
            continue;
        }
        let ann = param.type_annotation()?;
        types.push(resolve_method_annotation(
            ctx,
            &ann,
            self_assoc,
            type_registry,
        )?);
    }
    Some(types)
}

/// Process an interface definition: register the trait in the registry.
/// Also stores default method body syntax nodes for later MIR lowering.
/// The trait an interface declares, from its signatures alone (its default
/// bodies are checked by `infer_interface_def`).
fn interface_trait_def(
    ctx: &mut InferCtx,
    iface: &InterfaceDef,
    type_registry: &TypeRegistry,
    default_method_bodies: &mut FxHashMap<(String, String), TextRange>,
) -> TraitDef {
    let trait_name = iface
        .name()
        .and_then(|n| n.text())
        .unwrap_or_else(|| "<unnamed>".to_string());

    // `Self.Item` names the implementing type's associated type; other
    // annotations are types in full (`List<Int>`, not `List`).
    let self_assoc: FxHashMap<String, Ty> = iface
        .assoc_types()
        .filter_map(|assoc| assoc.name().and_then(|n| n.text()))
        .map(|name| (name.clone(), Ty::Con(TyCon::new(format!("Self.{name}")))))
        .collect();
    let mut methods = Vec::new();
    for method in iface.methods() {
        let method_name = method
            .name()
            .and_then(|n| n.text())
            .unwrap_or_else(|| "<unnamed>".to_string());

        let mut has_self = false;
        let mut param_count = 0;

        if let Some(param_list) = method.param_list() {
            for param in param_list.params() {
                let is_self = param.is_self();
                if is_self {
                    has_self = true;
                } else {
                    param_count += 1;
                }
            }
        }

        let return_type = method
            .return_type()
            .and_then(|ann| resolve_method_annotation(ctx, &ann, &self_assoc, type_registry));
        let param_types = method_param_types(ctx, method.param_list(), &self_assoc, type_registry);

        let has_default_body = method.body().is_some();

        // Store the default method body text range for MIR lowering.
        if has_default_body {
            default_method_bodies.insert(
                (trait_name.clone(), method_name.clone()),
                method.syntax().text_range(),
            );
        }

        methods.push(TraitMethodSig {
            name: method_name,
            has_self,
            param_count,
            return_type,
            has_default_body,
            param_types,
        });
    }

    // Collect associated type declarations from the interface.
    let mut associated_types = Vec::new();
    for assoc in iface.assoc_types() {
        if let Some(name) = assoc.name().and_then(|n| n.text()) {
            associated_types.push(TraitAssocTypeDef { name });
        }
    }

    TraitDef {
        name: trait_name,
        methods,
        associated_types,
    }
}

fn infer_interface_def(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    iface: &InterfaceDef,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &mut TraitRegistry,
    fn_constraints: &FxHashMap<String, FnConstraints>,
    default_method_bodies: &mut FxHashMap<(String, String), TextRange>,
) {
    let trait_def = interface_trait_def(ctx, iface, type_registry, default_method_bodies);
    let trait_name = trait_def.name.clone();
    trait_registry.register_trait(trait_def);

    // Check each default method body once, with `self :: Self`, so its
    // expressions have types for codegen to specialize per implementing type
    // and so errors in it are reported. The trait is registered first, which
    // is what lets `self.other_method()` resolve through the interface.
    let previous_interface = ctx.current_interface.replace(trait_name.clone());
    for method in iface.methods() {
        let Some(body) = method.body() else {
            continue;
        };
        env.push_scope();
        let mut param_tys = Vec::new();
        if let Some(param_list) = method.param_list() {
            for param in param_list.params() {
                let is_self = param.is_self();
                let param_ty = if is_self {
                    Ty::Con(TyCon::new("Self"))
                } else {
                    param
                        .type_annotation()
                        .and_then(|ann| resolve_type_annotation(ctx, &ann, type_registry))
                        .unwrap_or_else(|| ctx.fresh_var())
                };
                let name = if is_self {
                    "self".to_string()
                } else {
                    param
                        .name()
                        .map(|t| t.text().to_string())
                        .unwrap_or_else(|| "_".to_string())
                };
                ctx.method_params.push(MethodParam {
                    method: method.name().and_then(|n| n.text()),
                    name: param.name().filter(|_| !is_self),
                    span: param.syntax().text_range(),
                    ty: param_ty.clone(),
                });
                env.insert(name, Scheme::mono(param_ty.clone()));
                param_tys.push(param_ty);
            }
        }
        let declared_ret = method
            .return_type()
            .and_then(|ann| resolve_type_annotation(ctx, &ann, type_registry));
        ctx.push_fn_return_type(declared_ret.clone());
        let body_ty = infer_block(
            ctx,
            env,
            &body,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
            None,
        );
        let returns = ctx.pop_fn_return_type();
        env.pop_scope();
        let ret = match declared_ret {
            Some(declared) => {
                let _ = ctx.unify(declared.clone(), body_ty, body_origin(Some(body.clone())));
                declared
            }
            None => {
                let ret = join_returns(ctx, body_ty, returns).unwrap_or_else(|_| Ty::Tuple(vec![]));
                // What the body returns is what the method returns, as if
                // written: `p.greet()` has its type. Not a type the body
                // leaves open.
                let ret = ctx.resolve(ret);
                if !ret.has_type_vars() {
                    // Named as `interface_trait_def` registered it.
                    let name = method
                        .name()
                        .and_then(|n| n.text())
                        .unwrap_or_else(|| "<unnamed>".to_string());
                    trait_registry.set_default_return(&trait_name, &name, &ret);
                }
                ret
            }
        };
        types.insert(
            method.syntax().text_range(),
            Ty::Fun(param_tys, Box::new(ret)),
        );
    }
    ctx.current_interface = previous_interface;
}

/// The type an impl binds an associated type to: `List<Int>` in
/// `type Item = List<Int>`.
fn resolve_assoc_type_binding(
    ctx: &mut InferCtx,
    binding: &mesh_parser::ast::item::AssocTypeBinding,
    type_registry: &TypeRegistry,
) -> Option<Ty> {
    type_after_eq(binding.syntax()).map(|ty| resolve_alias(ctx, ty, type_registry))
}

/// A method annotation in an interface or impl: `Self.Item` is the
/// associated type it names, anything else a type in full. `Self.X` naming no
/// associated type is an error (reported once, though signatures are read in
/// two passes), and its type unknown.
///
/// Note: uppercase `Self` is parsed as an IDENT token (not SELF_KW, which is
/// lowercase `self`).
fn resolve_method_annotation(
    ctx: &mut InferCtx,
    ann: &mesh_parser::ast::item::TypeAnnotation,
    assoc_types: &FxHashMap<String, Ty>,
    type_registry: &TypeRegistry,
) -> Option<Ty> {
    let ty = resolve_type_annotation(ctx, ann, type_registry)?;
    let mut unknown = Vec::new();
    let ty = ty.replace_cons(&mut |con| {
        let name = con.name.strip_prefix("Self.")?;
        Some(match assoc_types.get(name) {
            Some(ty) => ty.clone(),
            None => {
                unknown.push(name.to_string());
                ctx.fresh_var()
            }
        })
    });
    // An associated type reads as if written here: `type Iter = ListIterator`
    // leaves its element type to inference, in `-> Self.Iter` as in
    // `-> ListIterator`. (The rest of the annotation has its arguments.)
    let ty = infer_missing_type_args(ctx, ty, type_registry);
    for name in unknown {
        // The name's own token, after `Self` and `.`.
        let tokens: Vec<_> = ann
            .syntax()
            .descendants_with_tokens()
            .filter_map(|t| t.into_token())
            .filter(|t| !t.kind().is_trivia())
            .collect();
        let span = tokens
            .windows(3)
            .find(|window| {
                window[0].text() == "Self"
                    && window[1].kind() == SyntaxKind::DOT
                    && window[2].text() == name
            })
            .map_or(ann.syntax().text_range(), |window| window[2].text_range());
        let reported = ctx.errors.iter().any(
            |error| matches!(error, TypeError::UnresolvedAssocType { span: at, .. } if *at == span),
        );
        if !reported {
            ctx.errors.push(TypeError::UnresolvedAssocType {
                assoc_name: name,
                span,
            });
        }
    }
    Some(ty)
}

/// `ty` with `Self` as the implementing type: in an impl, `-> Self` is the
/// type the impl is for.
fn with_self(ty: &Ty, impl_type: &Ty) -> Ty {
    ty.replace_cons(&mut |con| (con.name == "Self").then(|| impl_type.clone()))
}

/// The type arguments an impl gives its interface, as written: `<Int>` in
/// `impl From<Int> for Meters`.
fn written_trait_args(impl_: &AstImplDef) -> Option<mesh_parser::SyntaxNode> {
    impl_
        .syntax()
        .children()
        .find(|n| n.kind() == SyntaxKind::GENERIC_ARG_LIST)
}

/// The type arguments an impl gives its interface, each read in full:
/// `(Int, Int)` in `impl From<(Int, Int)> for Bag`, `List<Int>` in
/// `impl From<List<Int>> for Bag`. (Only their names were read, as
/// `From<Int, Int>` and `From<List>`, and a conversion went to the wrong
/// impl.)
fn impl_trait_type_args(
    ctx: &mut InferCtx,
    impl_: &AstImplDef,
    type_registry: &TypeRegistry,
) -> Vec<Ty> {
    let Some(written) = written_trait_args(impl_) else {
        return Vec::new();
    };
    let mut tokens = Vec::new();
    collect_annotation_tokens(&written, &mut tokens);
    // After the `<` the parser opens the list with.
    parse_type_args(&tokens, &mut 1)
        .into_iter()
        .map(|arg| resolve_alias(ctx, arg, type_registry))
        .collect()
}

/// An impl's registry entry from its signatures alone. A method without a
/// return annotation has no return type here; `infer_impl_def` fills it in
/// from the body.
fn impl_signature(
    ctx: &mut InferCtx,
    impl_: &AstImplDef,
    type_registry: &TypeRegistry,
) -> TraitImplDef {
    let trait_name = impl_
        .interface_name()
        .map(|t| t.text().to_string())
        .unwrap_or_else(|| "<unknown>".to_string());

    let trait_type_args = impl_trait_type_args(ctx, impl_, type_registry);

    let impl_type_name = impl_
        .type_name()
        .map(|t| t.text().to_string())
        .unwrap_or_else(|| "<unknown>".to_string());

    let impl_type = name_to_type(&impl_type_name);

    // Collect associated type bindings from the impl block.
    let mut assoc_types: FxHashMap<String, Ty> = FxHashMap::default();
    for binding in impl_.assoc_type_bindings() {
        if let Some(name) = binding.name().and_then(|n| n.text()) {
            if let Some(concrete_ty) = resolve_assoc_type_binding(ctx, &binding, type_registry) {
                assoc_types.insert(name, concrete_ty);
            }
        }
    }

    let mut methods = FxHashMap::default();
    for method in impl_.methods() {
        let method_name = method
            .name()
            .and_then(|n| n.text())
            .unwrap_or_else(|| "<unnamed>".to_string());
        let mut has_self = false;
        let mut param_types = Some(Vec::new());
        if let Some(param_list) = method.param_list() {
            for param in param_list.params() {
                let is_self = param.is_self();
                if is_self {
                    has_self = true;
                    continue;
                }
                let declared = param.type_annotation().and_then(|ann| {
                    resolve_method_annotation(ctx, &ann, &assoc_types, type_registry)
                        .map(|ty| with_self(&ty, &impl_type))
                });
                match (&mut param_types, declared) {
                    (Some(tys), Some(ty)) if !ty.has_type_vars() => tys.push(ty),
                    _ => param_types = None,
                }
            }
        }
        let param_count = method
            .param_list()
            .map(|list| list.params().count())
            .unwrap_or(0)
            - usize::from(has_self);
        let return_type = method
            .return_type()
            .and_then(|ann| resolve_method_annotation(ctx, &ann, &assoc_types, type_registry))
            .map(|ty| with_self(&ty, &impl_type))
            .filter(|ty| !ty.has_type_vars());
        methods.insert(
            method_name,
            ImplMethodSig {
                has_self,
                param_count,
                return_type,
                param_types: param_types.filter(|tys| tys.len() == param_count),
            },
        );
    }
    TraitImplDef {
        trait_name,
        trait_type_args,
        impl_type,
        impl_type_name,
        methods,
        associated_types: assoc_types,
    }
}

/// Register the impl `impl_` from its signatures, reporting where it does
/// not match its interface at the impl. Every impl of a module is
/// registered before any body is checked, so its methods can be called from
/// anywhere in the module, the impl's own methods included.
fn register_impl_signature(
    ctx: &mut InferCtx,
    impl_: &AstImplDef,
    type_registry: &TypeRegistry,
    trait_registry: &mut TraitRegistry,
) {
    let signature = impl_signature(ctx, impl_, type_registry);
    let trait_name = signature.trait_name.clone();
    let impl_ty = signature.impl_type_name.clone();
    let problems = trait_registry.register_impl(signature);
    let header = impl_
        .syntax()
        .children_with_tokens()
        .find(|element| element.kind() == SyntaxKind::DO_KW)
        .map(|do_kw| {
            TextRange::new(
                impl_.syntax().text_range().start(),
                do_kw.text_range().end(),
            )
        })
        .unwrap_or_else(|| impl_.syntax().text_range());
    // A method, or an associated type's binding, is where the impl says it.
    let method_span = |name: &str| {
        impl_
            .methods()
            .find(|m| m.name().and_then(|n| n.text()).as_deref() == Some(name))
            .map_or(header, |m| m.syntax().text_range())
    };
    let binding_span = |name: &str| {
        impl_
            .assoc_type_bindings()
            .find(|b| b.name().and_then(|n| n.text()).as_deref() == Some(name))
            .map_or(header, |b| b.syntax().text_range())
    };
    ctx.errors
        .extend(problems.into_iter().map(|problem| match problem {
            ImplProblem::MissingMethod(method_name) => TypeError::MissingTraitMethod {
                trait_name: trait_name.clone(),
                method_name,
                impl_ty: impl_ty.clone(),
                span: header,
            },
            ImplProblem::MethodMismatch {
                method_name,
                expected,
                found,
            } => TypeError::TraitMethodSignatureMismatch {
                trait_name: trait_name.clone(),
                span: method_span(&method_name),
                method_name,
                expected,
                found,
            },
            ImplProblem::MissingAssocType(assoc_name) => TypeError::MissingAssocType {
                trait_name: trait_name.clone(),
                assoc_name,
                impl_ty: impl_ty.clone(),
                span: header,
            },
            ImplProblem::ExtraAssocType(assoc_name) => TypeError::ExtraAssocType {
                trait_name: trait_name.clone(),
                span: binding_span(&assoc_name),
                assoc_name,
                impl_ty: impl_ty.clone(),
            },
            ImplProblem::Duplicate(first) => TypeError::DuplicateImpl {
                trait_name: trait_name.clone(),
                impl_type: impl_ty.clone(),
                first_impl: format!("previously defined for `{first}`"),
                span: header,
            },
        }));
}

/// A method is compiled once, for the type it is implemented for, so each
/// of its parameters needs a type by the module's end: one nothing fixed was
/// compiled as `()` (a `Box` argument read as `()`, an `Int` one failing in
/// LLVM). So is an interface's default method, once per implementing type.
/// The parameters are those the methods' inference recorded.
fn check_method_params_typed(ctx: &mut InferCtx) {
    for param in std::mem::take(&mut ctx.method_params) {
        let Some(name) = param.name else {
            continue;
        };
        if ctx.resolve(param.ty).has_type_vars() {
            ctx.errors.push(TypeError::UntypedMethodParam {
                method: param.method.unwrap_or_default(),
                param: name.text().to_string(),
                span: param.span,
            });
        }
    }
}

/// Type-check an impl's method bodies (the impl itself was registered by
/// `register_impl_signature`), filling in the return types of methods that
/// declare none from their bodies.
fn infer_impl_def(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    impl_: &AstImplDef,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &mut TraitRegistry,
    fn_constraints: &mut FxHashMap<String, FnConstraints>,
) {
    let TraitImplDef {
        trait_name,
        trait_type_args,
        impl_type,
        impl_type_name,
        associated_types: assoc_types,
        ..
    } = impl_signature(ctx, impl_, type_registry);

    // Where they are written, the interface applied to its arguments
    // (`From<(Int, Int)>`): lowering names the impl's functions by them.
    if let Some(written) = written_trait_args(impl_) {
        let applied = Ty::App(
            Box::new(Ty::Con(TyCon::new(&trait_name))),
            trait_type_args.clone(),
        );
        types.insert(written.text_range(), applied);
    }

    for method in impl_.methods() {
        let method_name = method
            .name()
            .and_then(|n| n.text())
            .unwrap_or_else(|| "<unnamed>".to_string());

        let has_self = method
            .param_list()
            .is_some_and(|list| list.params().any(|param| param.is_self()));

        // What the annotation says, or else what the interface declares:
        // `fn name(self) do 5 end` for `fn name(self) -> String` was taken
        // to return an `Int`.
        let return_type = method
            .return_type()
            .and_then(|ann| {
                // Simple name resolution only if the annotation fails to parse.
                resolve_method_annotation(ctx, &ann, &assoc_types, type_registry)
                    .map(|ty| with_self(&ty, &impl_type))
            })
            .or_else(|| {
                trait_registry.declared_return_type(
                    &trait_name,
                    &method_name,
                    &impl_type,
                    &assoc_types,
                )
            })
            // Read as an annotation is: a `Self.Iter` bound to `ListIterator`
            // leaves its element type to inference.
            .map(|ty| infer_missing_type_args(ctx, ty, type_registry));

        // Also infer the method body to check it type-checks.
        env.push_scope();
        env.insert("self".into(), Scheme::mono(impl_type.clone()));

        // Collect all param types for fn_ty (self + non-self params).
        // Only prepend impl_type when method has self parameter (e.g., instance methods).
        // Static trait methods like From.from() do NOT take self.
        let mut all_param_tys: Vec<Ty> = if has_self {
            vec![impl_type.clone()]
        } else {
            vec![]
        };

        if let Some(param_list) = method.param_list() {
            for param in param_list.params() {
                let is_self = param.is_self();
                if !is_self {
                    if let Some(name_tok) = param.name() {
                        let name_text = name_tok.text().to_string();
                        let param_ty = param
                            .type_annotation()
                            .and_then(|ann| {
                                resolve_method_annotation(ctx, &ann, &assoc_types, type_registry)
                                    .map(|ty| with_self(&ty, &impl_type))
                            })
                            .unwrap_or_else(|| ctx.fresh_var());
                        ctx.method_params.push(MethodParam {
                            method: method.name().and_then(|n| n.text()),
                            name: Some(name_tok),
                            span: param.syntax().text_range(),
                            ty: param_ty.clone(),
                        });
                        env.insert(name_text, Scheme::mono(param_ty.clone()));
                        all_param_tys.push(param_ty);
                    }
                }
            }
        }

        // The method returns what its annotation says, else what its body
        // is inferred to produce.
        let mut return_type = return_type;
        if let Some(body) = method.body() {
            let body_ty = infer_block(
                ctx,
                env,
                &body,
                types,
                type_registry,
                &*trait_registry,
                fn_constraints,
                None,
            );
            match return_type {
                Some(ref ret_ty) => {
                    let origin = body_origin(Some(body.clone()));
                    let _ = ctx.unify(ret_ty.clone(), body_ty, origin);
                }
                None => return_type = Some(ctx.resolve(body_ty)),
            }
        }

        env.pop_scope();

        // The registry answers method lookups from other inference contexts,
        // so a return type still holding this context's type variables stays
        // unknown there (the trait's declared type stands in). One the body
        // settled (`-> List` returning a `List<Int>`) is known: read before
        // it was resolved, it was unknown too, and the method was not found.
        let return_type = return_type.map(|ty| ctx.resolve(ty));
        let declared_params: Vec<Ty> = all_param_tys
            .iter()
            .skip(usize::from(has_self))
            .map(|ty| ctx.resolve(ty.clone()))
            .collect();
        trait_registry.update_impl_method(
            &trait_name,
            &trait_type_args,
            &impl_type_name,
            &method_name,
            return_type.clone().filter(|ty| !ty.has_type_vars()),
            (!declared_params.iter().any(|ty| ty.has_type_vars())).then_some(declared_params),
        );

        // Register the method as a callable function so `to_string(42)` works.
        // Include all params (self + non-self) so the MIR lowerer can bind them.
        let fn_ty = {
            let ret = return_type.clone().unwrap_or_else(|| Ty::Tuple(vec![]));
            Ty::Fun(all_param_tys, Box::new(ret))
        };
        // Store the function type in the types map so the MIR lowerer can look it up.
        types.insert(method.syntax().text_range(), fn_ty.clone());
        if env.lookup(&method_name).is_none() {
            ctx.trait_method_fns.insert(method_name.clone());
            env.insert(method_name.clone(), Scheme::mono(fn_ty));
        }
    }
}

/// Infer a let binding: `let x = expr`
/// Whether a `let` initializer is a value whose type may be generalized: a
/// literal, a name, a closure or a module's function (`String.length`),
/// which each use gets its own copy of. Anything computed is computed once,
/// so it has one type: `let f = make_id()` generalized to `B -> B` ran a
/// closure made for no type at all, and `let m = Map.new()` a map made for
/// one kind of key.
fn is_generalizable(expr: &Expr) -> bool {
    match expr {
        Expr::Literal(_)
        | Expr::StringExpr(_)
        | Expr::AtomLiteral(_)
        | Expr::RegexExpr(_)
        | Expr::NameRef(_)
        | Expr::ClosureExpr(_) => true,
        Expr::FieldAccess(fa) => matches!(fa.base(), Some(Expr::NameRef(_))),
        _ => false,
    }
}

fn infer_let_binding(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    let_: &LetBinding,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &FxHashMap<String, FnConstraints>,
) -> Result<Ty, TypeError> {
    if let Some(pattern) = let_.pattern() {
        if let Err(error) = validate_let_destructuring_pattern(&pattern) {
            ctx.errors.push(error.clone());
            // The initializer is checked all the same, and the names the
            // pattern binds are bound to no type in particular: their uses
            // report nothing more ("undefined variable: b").
            if let Some(init) = let_.initializer() {
                let _ = infer_expr(
                    ctx,
                    env,
                    &init,
                    types,
                    type_registry,
                    trait_registry,
                    fn_constraints,
                );
            }
            for name in collect_pattern_binding_names(&pattern) {
                env.insert(name, Scheme::mono(Ty::Never));
            }
            return Err(error);
        }
    }

    ctx.enter_level();
    let pending_before = ctx.pending_fields.len();
    let traits_before = ctx.operand_traits.len();
    let concat_before = ctx.concat_operands.len();

    let init_expr = let_.initializer().ok_or_else(incomplete)?;

    let init_ty = match infer_expr(
        ctx,
        env,
        &init_expr,
        types,
        type_registry,
        trait_registry,
        fn_constraints,
    ) {
        Ok(ty) => ty,
        Err(error) => {
            // The error is reported; the names are still defined (as whatever
            // their uses need), so they do not add "undefined variable" errors.
            ctx.leave_level();
            if let Some(name) = let_.name().and_then(|name| name.text()) {
                let ty = ctx.fresh_var();
                env.insert(name, Scheme::mono(ty));
            } else if let Some(pat) = let_.pattern() {
                let _ = infer_pattern(ctx, env, &pat, types, type_registry);
            }
            return Err(error);
        }
    };

    // If there is a type annotation, resolve and unify with the inferred type.
    // The annotation declares the variable's type, also when the value does
    // not match it (that is reported, and the binding keeps its declared type).
    // (A let has an initializer only when the parser read its annotation
    // whole, and an annotation read whole names a type.)
    let annotated = let_.type_annotation().and_then(|annotation| {
        let ann_ty = resolve_type_annotation(ctx, &annotation, type_registry)?;
        Some((annotation, ann_ty))
    });
    let binding_ty = match annotated {
        Some((annotation, ann_ty)) => {
            let origin = ConstraintOrigin::Annotation {
                annotation_span: annotation.syntax().text_range(),
            };
            let _ = ctx.unify(ann_ty.clone(), init_ty.clone(), origin);
            ann_ty
        }
        None => init_ty.clone(),
    };

    ctx.leave_level();
    // A field read from a value of a type not known yet (`fn p -> p.x end`)
    // is settled by the binding's uses, so the binding stays monomorphic.
    let bases: Vec<Ty> = ctx.pending_fields[pending_before..]
        .iter()
        .map(|pending| pending.base.clone())
        .collect();
    let reads_unknown_field = bases
        .into_iter()
        .any(|base| is_type_var(&ctx.resolve(base)));
    let scheme = if reads_unknown_field || !is_generalizable(&init_expr) {
        ctx.monomorphic(binding_ty)
    } else {
        ctx.generalize(binding_ty)
    };
    // What the value requires of a type the scheme generalizes (`let f =
    // show`, when `show` needs Display of its parameter) is required of
    // each use's instance.
    ctx.generalize_requirements(&scheme.vars, traits_before, concat_before);

    match let_.pattern() {
        Some(pat) => {
            let pat_ty = infer_pattern(ctx, env, &pat, types, type_registry)?;
            ctx.unify(
                pat_ty,
                init_ty.clone(),
                ConstraintOrigin::LetBinding {
                    binding_span: let_.syntax().text_range(),
                },
            )?;
        }
        None => {
            // The parser reads an initializer only after a pattern or a name.
            let name = let_
                .name()
                .and_then(|name| name.text())
                .expect("a let with an initializer and no pattern has a name");
            env.insert(name, scheme);
        }
    }

    let resolved = ctx.resolve(init_ty);
    types.insert(let_.syntax().text_range(), resolved.clone());

    Ok(resolved)
}

fn validate_let_destructuring_pattern(pattern: &Pattern) -> Result<(), TypeError> {
    let mut binders = FxHashSet::default();
    validate_let_destructuring_element(pattern, &mut binders)
}

fn validate_let_destructuring_element(
    pattern: &Pattern,
    binders: &mut FxHashSet<String>,
) -> Result<(), TypeError> {
    match pattern {
        Pattern::Tuple(_) | Pattern::Struct(_) => {
            for element in pattern.sub_patterns() {
                validate_let_destructuring_element(&element, binders)?;
            }
            Ok(())
        }
        Pattern::Wildcard(_) => Ok(()),
        Pattern::Ident(identifier) => {
            let name = identifier
                .name()
                .map(|token| token.text().to_string())
                .unwrap_or_default();
            let binder = name.trim_start_matches('_');
            if !binder.chars().next().is_some_and(char::is_lowercase) {
                return Err(TypeError::InvalidLetPattern {
                    reason: "the names a pattern binds must start with a lowercase letter"
                        .to_string(),
                    span: identifier.syntax().text_range(),
                });
            }

            if !binders.insert(name.clone()) {
                return Err(TypeError::InvalidLetPattern {
                    reason: format!(
                        "the names a pattern binds must be unique; `{name}` is repeated"
                    ),
                    span: identifier.syntax().text_range(),
                });
            }

            Ok(())
        }
        _ => Err(TypeError::InvalidLetPattern {
            reason: "a `let` or `for` pattern must match every value (use `case` to match some)"
                .to_string(),
            span: pattern.syntax().text_range(),
        }),
    }
}

/// Infer a named function definition: `fn name(params) [-> RetType] [where T: Trait] do body end`
fn infer_fn_def(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    fn_: &FnDef,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &mut FxHashMap<String, FnConstraints>,
) -> Result<Ty, TypeError> {
    let fn_name = fn_
        .name()
        .and_then(|n| n.text())
        .unwrap_or_else(|| "<anonymous>".to_string());
    let is_native = fn_.native_decl().is_some();
    let is_export = fn_.export_decl().is_some();
    if is_native {
        validate_native_declaration(ctx, fn_);
    }
    if is_export {
        validate_export_declaration(ctx, fn_);
    }

    // Save any pre-registered mutual-recursion placeholder before we overwrite the env entry.
    // An arity-overloaded fn's placeholder is under its `name__N` key: the
    // plain name may hold another arity's scheme.
    let env_key = fn_env_key(ctx, env, &fn_name, fn_arity(fn_));
    let pre_registered = env.lookup(&env_key).and_then(|s| {
        if s.vars.is_empty() {
            Some(s.ty.clone())
        } else {
            None
        }
    });

    ctx.enter_level();

    let self_var = ctx.fresh_var();
    env.insert(env_key.clone(), Scheme::mono(self_var.clone()));

    // Extract generic type parameters if present.
    let type_params = function_type_params(ctx, fn_.syntax());

    // Extract where-clause constraints.
    let where_constraints = extract_where_constraints(fn_);
    check_index_bounds(ctx, fn_, &type_params, &where_constraints);

    env.push_scope();

    // Compiler-generated test functions (`__test_body_*`, and `__test_describe_*`
    // for a describe's tests) are called by the test harness from the main thread,
    // which has an actor process entry (PID created by mesh_rt_init_actor). They may
    // contain `receive do ... end` blocks generated by the assert_receive
    // preprocessor. Inject ACTOR_MSG_TYPE_KEY so that typeck allows `receive`
    // expressions inside these generated functions.
    if fn_name.starts_with("__test_body_") || fn_name.starts_with("__test_describe_") {
        let msg_ty = ctx.fresh_var();
        env.insert(ACTOR_MSG_TYPE_KEY.into(), Scheme::mono(msg_ty));
    }

    // Insert type params into the scope.
    for (name, ty) in &type_params {
        let key = if matches!(ty, Ty::Nat(_)) {
            static_index_key(name)
        } else {
            name.clone()
        };
        env.insert(key, Scheme::mono(ty.clone()));
    }

    let mut param_types = Vec::new();
    let mut param_type_param_names: Vec<Option<String>> = Vec::new();

    if let Some(param_list) = fn_.param_list() {
        let mut names: Vec<String> = Vec::new();
        for param in param_list.params() {
            if let Some(name) = param.name().map(|t| t.text().to_string()) {
                if names.contains(&name) {
                    ctx.errors.push(TypeError::DuplicateDefinition {
                        kind: "parameter",
                        name,
                        span: param.syntax().text_range(),
                    });
                } else {
                    names.push(name);
                }
            }
        }
        for param in param_list.params() {
            let (param_ty, tp_name) = if let Some(ann) = param.type_annotation() {
                if let Some(name) = annotation_type_param(&ann, &type_params) {
                    (type_params[&name].clone(), Some(name))
                } else if let Some(full_ty) = resolve_type_annotation(ctx, &ann, type_registry) {
                    (with_declared_type_params(&full_ty, &type_params), None)
                } else {
                    (ctx.fresh_var(), None)
                }
            } else {
                (ctx.fresh_var(), None)
            };

            if let Some(name_tok) = param.name() {
                let name_text = name_tok.text().to_string();
                env.insert(name_text, Scheme::mono(param_ty.clone()));
            }
            param_types.push(param_ty);
            param_type_param_names.push(tp_name);
        }
    }

    if !where_constraints.is_empty() {
        fn_constraints.insert(
            env_key.clone(),
            FnConstraints {
                where_constraints: where_constraints.clone(),
                param_type_param_names,
                inferred_bounds: Vec::new(),
                concat_params: Vec::new(),
            },
        );
    }

    // Parse return type annotation.
    // Use resolve_type_annotation which handles generic args and sugar types
    // (e.g., Result<Int, String>, Int!String, Int?) correctly.
    let return_type_annotation = fn_.return_type().and_then(|ann| {
        // A declared type parameter shadows an alias of the same name.
        if let Some(name) = annotation_type_param(&ann, &type_params) {
            return Some(type_params[&name].clone());
        }
        // Use full annotation resolution for generic/sugar types.
        resolve_type_annotation(ctx, &ann, type_registry)
            .map(|ty| with_declared_type_params(&ty, &type_params))
    });
    // A generic declaration is rejected already: its parameters have no
    // ABI type, and were shown as `?12`.
    if is_native && type_params.is_empty() {
        validate_native_abi_types(ctx, fn_, &param_types, return_type_annotation.as_ref());
    }
    if is_export && type_params.is_empty() {
        validate_export_abi_types(ctx, fn_, &param_types, return_type_annotation.as_ref());
    }

    // A complete signature can be used recursively at a different Nat
    // index. Ordinary type parameters still share the body inference.
    let index_vars: Vec<_> = type_params
        .values()
        .filter_map(|ty| match ty {
            Ty::Nat(NatIndex::Variable(var)) => Some(*var),
            _ => None,
        })
        .collect();
    if let Some(ret) = return_type_annotation.as_ref().filter(|_| {
        !index_vars.is_empty()
            && fn_.param_list().is_none_or(|params| {
                params
                    .params()
                    .all(|param| param.type_annotation().is_some())
            })
    }) {
        if let Some(binding) = env
            .lookup_mut(&env_key)
            .filter(|scheme| scheme.ty == self_var)
        {
            *binding = Scheme {
                vars: index_vars,
                ty: Ty::fun(param_types.clone(), ret.clone()),
            };
        }
    }

    let enclosing = enter_fn_body(ctx, &where_constraints, &type_params);
    // `main` without a declared return type returns nothing: a `?` in it
    // has nowhere to send its error.
    let returns_to = match &return_type_annotation {
        None if fn_name == "main" => Some(Ty::Tuple(vec![])),
        declared => declared.clone(),
    };
    ctx.push_fn_return_type(returns_to);
    let body_ty = if is_native {
        return_type_annotation
            .clone()
            .unwrap_or_else(|| Ty::Tuple(vec![]))
    } else if let Some(body) = fn_.body() {
        infer_block(
            ctx,
            env,
            &body,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
            return_type_annotation.as_ref(),
        )
    } else {
        ctx.fresh_var()
    };
    let returns = ctx.pop_fn_return_type();
    if let Some(ref ret_ann) = return_type_annotation {
        let _ = ctx.unify(ret_ann.clone(), body_ty.clone(), body_origin(fn_.body()));
    }
    let open_decodes = finish_fn_body(
        ctx,
        enclosing,
        fn_,
        &where_constraints,
        &type_params,
        &param_types,
        &env_key,
        fn_constraints,
        type_registry,
        trait_registry,
    );

    env.pop_scope();

    let ret_ty = match return_type_annotation {
        Some(ret_ann) => ret_ann,
        None => join_returns(ctx, body_ty, returns)?,
    };
    let fn_ty = Ty::Fun(param_types, Box::new(ret_ty));
    check_open_decodes(ctx, open_decodes, &fn_ty);

    ctx.unify(self_var, fn_ty.clone(), ConstraintOrigin::Builtin)?;

    ctx.leave_level();
    let scheme = ctx.generalize(fn_ty.clone());

    // Calls earlier in the module used the pre-registered placeholder: they
    // are one use of the function, so they get an instance of its type (the
    // placeholder is module-wide; unified with the type itself it would keep
    // the function from being generic).
    if let Some(pre_var) = pre_registered {
        let instance = ctx.instantiate(&scheme);
        let _ = ctx.unify(pre_var, instance, ConstraintOrigin::Builtin);
    }

    env.insert(env_key, scheme);

    let resolved = ctx.resolve(fn_ty);
    types.insert(fn_.syntax().text_range(), resolved.clone());

    Ok(resolved)
}

fn validate_native_declaration(ctx: &mut InferCtx, function: &FnDef) {
    let span = function.syntax().text_range();
    let mut reject = |reason: &str| {
        ctx.errors.push(TypeError::NativeDeclarationInvalid {
            reason: reason.to_string(),
            span,
        });
    };

    if function.visibility().is_none() {
        reject("native functions must be public");
    }
    let symbol = function
        .native_decl()
        .and_then(|declaration| declaration.symbol())
        .unwrap_or_default();
    if !is_c_identifier(&symbol) {
        reject("native symbol must be a non-empty C identifier");
    }
    if function.return_type().is_none() {
        reject("native functions require an explicit return type");
    }
    if function.param_list().is_some_and(|params| {
        params
            .params()
            .any(|parameter| parameter.type_annotation().is_none())
    }) {
        reject("every native function parameter requires an explicit type");
    }
    if function
        .syntax()
        .children()
        .any(|child| child.kind() == SyntaxKind::GENERIC_PARAM_LIST)
    {
        reject("generic native functions are unsupported; generate concrete bindings");
    }
    if function
        .syntax()
        .children()
        .any(|child| child.kind() == SyntaxKind::WHERE_CLAUSE)
    {
        reject("native function declarations cannot have a where clause");
    }
    if function.guard().is_some() {
        reject("native function declarations cannot have a guard");
    }
}

/// Symbols an export cannot take: the host ABI the runtime defines, `main`,
/// and C keywords, which the generated header could not declare.
fn is_reserved_export_symbol(symbol: &str) -> bool {
    const C_KEYWORDS: &[&str] = &[
        "auto",
        "break",
        "case",
        "char",
        "const",
        "continue",
        "default",
        "do",
        "double",
        "else",
        "enum",
        "extern",
        "float",
        "for",
        "goto",
        "if",
        "inline",
        "int",
        "long",
        "register",
        "restrict",
        "return",
        "short",
        "signed",
        "sizeof",
        "static",
        "struct",
        "switch",
        "typedef",
        "union",
        "unsigned",
        "void",
        "volatile",
        "while",
        "_Bool",
        "_Complex",
        "_Imaginary",
        "_Alignas",
        "_Alignof",
        "_Atomic",
        "_Generic",
        "_Noreturn",
        "_Static_assert",
        "_Thread_local",
        "bool",
        "true",
        "false",
    ];
    symbol == "main" || symbol.starts_with("mesh_library_") || C_KEYWORDS.contains(&symbol)
}

fn is_c_identifier(symbol: &str) -> bool {
    let mut bytes = symbol.bytes();
    bytes
        .next()
        .is_some_and(|byte| byte == b'_' || byte.is_ascii_alphabetic())
        && bytes.all(|byte| byte == b'_' || byte.is_ascii_alphanumeric())
}

fn validate_native_abi_types(
    ctx: &mut InferCtx,
    function: &FnDef,
    params: &[Ty],
    return_type: Option<&Ty>,
) {
    let span = function.syntax().text_range();
    for ty in params {
        if !is_native_abi_value(ty) {
            ctx.errors.push(TypeError::NativeDeclarationInvalid {
                reason: format!(
                    "parameter type `{}` is not ABI-safe; use Int, Float, Bool, String, Bytes, U64, U128, or I128",
                    ty.with_holes()
                ),
                span,
            });
        }
    }
    if let Some(ty) = return_type.filter(|ty| !is_native_abi_return(ty)) {
        ctx.errors.push(TypeError::NativeDeclarationInvalid {
            reason: format!(
                "return type `{}` is not ABI-safe; use a native value, Result, or Option",
                ty.with_holes()
            ),
            span,
        });
    }
}

fn is_native_abi_value(ty: &Ty) -> bool {
    matches!(
        ty,
        Ty::Con(con)
            if matches!(
                con.name.as_str(),
                "Int" | "Float" | "Bool" | "String" | "Bytes" | "U64" | "U128" | "I128"
            )
    )
}

fn is_native_abi_return(ty: &Ty) -> bool {
    if is_native_abi_value(ty) {
        return true;
    }
    ty.args_of("Result")
        .or_else(|| ty.args_of("Option"))
        .is_some_and(|values| values.iter().all(is_native_abi_value))
}

fn validate_export_declaration(ctx: &mut InferCtx, function: &FnDef) {
    let span = function.syntax().text_range();
    let mut reject = |reason: &str| {
        ctx.errors.push(TypeError::ExportDeclarationInvalid {
            reason: reason.to_string(),
            span,
        });
    };

    if function.visibility().is_none() {
        reject("exported functions must be public");
    }
    let symbol = function
        .export_decl()
        .and_then(|declaration| declaration.symbol())
        .unwrap_or_default();
    if !is_c_identifier(&symbol) {
        reject("exported symbol must be a non-empty C identifier");
    } else if is_reserved_export_symbol(&symbol) {
        reject(
            "exported symbol is reserved: `main`, C keywords, and `mesh_library_*` (the host ABI) cannot be exported",
        );
    }
    if function.return_type().is_none() {
        reject("exported functions require an explicit return type");
    }
    if function.param_list().is_none_or(|params| {
        params
            .params()
            .any(|parameter| parameter.type_annotation().is_none())
    }) {
        reject("every exported function parameter requires an explicit type");
    }
    if function
        .syntax()
        .children()
        .any(|child| child.kind() == SyntaxKind::GENERIC_PARAM_LIST)
    {
        reject("generic exported functions are unsupported");
    }
    if function
        .syntax()
        .children()
        .any(|child| child.kind() == SyntaxKind::WHERE_CLAUSE)
    {
        reject("exported functions cannot have a where clause");
    }
    if function.guard().is_some() {
        reject("exported functions cannot have a guard");
    }
}

fn validate_export_abi_types(
    ctx: &mut InferCtx,
    function: &FnDef,
    params: &[Ty],
    return_type: Option<&Ty>,
) {
    // `Plaintext<Bytes>` is `Bytes` at run time; which exports may carry it
    // (those marked `@display`) is `plaintext.rs`'s to say.
    let bytes = |ty: &Ty| {
        matches!(ty, Ty::Con(con) if con.name == "Bytes")
            || matches!(ty.args_of(crate::ty::PLAINTEXT), Some([Ty::Con(con)]) if con.name == "Bytes")
    };
    let valid_params = matches!(params, [param] if bytes(param));
    let valid_return = matches!(
        return_type.and_then(|ty| ty.args_of("Result")),
        Some([ok, Ty::Con(error)]) if bytes(ok) && error.name == "String"
    );
    if !valid_params || !valid_return {
        ctx.errors.push(TypeError::ExportDeclarationInvalid {
            reason: "stable exports require exactly `(Bytes) -> Result<Bytes, String>`".to_string(),
            span: function.syntax().text_range(),
        });
    }
}

// ── Expression Inference ───────────────────────────────────────────────

/// Infer the type of an expression.
fn infer_expr(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    expr: &Expr,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &FxHashMap<String, FnConstraints>,
) -> Result<Ty, TypeError> {
    infer_expr_with_case_result(
        ctx,
        env,
        expr,
        types,
        type_registry,
        trait_registry,
        fn_constraints,
        None,
    )
}

fn infer_expr_with_case_result(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    expr: &Expr,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &FxHashMap<String, FnConstraints>,
    case_result: Option<&Ty>,
) -> Result<Ty, TypeError> {
    // Constraints without a more specific origin are reported at the
    // innermost expression being inferred.
    ctx.expr_spans.push(expr.syntax().text_range());
    let nesting = ctx.nesting(env);
    let result = infer_expr_here(
        ctx,
        env,
        expr,
        types,
        type_registry,
        trait_registry,
        fn_constraints,
        case_result,
    );
    // An expression given up on midway leaves what it entered: a loop
    // (`break` after it was taken for inside one), a scope (its bindings
    // stayed visible), a `let` level.
    if result.is_err() {
        ctx.restore(env, nesting);
    }
    ctx.expr_spans.pop();
    result
}

fn infer_expr_here(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    expr: &Expr,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &FxHashMap<String, FnConstraints>,
    case_result: Option<&Ty>,
) -> Result<Ty, TypeError> {
    let ty = match expr {
        Expr::Literal(lit) => {
            // The parser makes a literal node of the one token it is.
            let token = lit.token().expect("a literal is its token");
            // `-9223372036854775808` is a minus applied to a literal.
            let negated = lit.syntax().parent().is_some_and(|parent| {
                parent.kind() == SyntaxKind::UNARY_EXPR
                    && parent
                        .children_with_tokens()
                        .any(|t| t.kind() == SyntaxKind::MINUS)
            });
            check_numeric_literal(ctx, &token, negated);
            Ok(infer_literal(lit))
        }
        Expr::NameRef(name_ref) => {
            reject_type_as_value(ctx, env, type_registry, name_ref)?;
            infer_name_ref(ctx, env, name_ref)
        }
        Expr::BinaryExpr(bin) => infer_binary(
            ctx,
            env,
            bin,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        ),
        Expr::UnaryExpr(un) => infer_unary(
            ctx,
            env,
            un,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        ),
        // An actor calling itself continues with new arguments; the call
        // does not produce a value, so any arm may end in one.
        Expr::CallExpr(call) => infer_call(
            ctx,
            env,
            call,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        )
        .map(|ty| {
            if calls_enclosing_actor(env, call) {
                Ty::Never
            } else {
                ty
            }
        }),
        Expr::PipeExpr(pipe) => infer_piped(
            ctx,
            env,
            pipe.lhs(),
            pipe.rhs(),
            None,
            pipe.syntax().text_range(),
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        ),
        Expr::IfExpr(if_) => infer_if(
            ctx,
            env,
            if_,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        ),
        Expr::ClosureExpr(closure) => infer_closure(
            ctx,
            env,
            closure,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
            None,
        ),
        Expr::Block(block) => Ok(infer_block(
            ctx,
            env,
            block,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
            None,
        )),
        Expr::TupleExpr(tuple) => infer_tuple(
            ctx,
            env,
            tuple,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        ),
        Expr::CaseExpr(case) => infer_case(
            ctx,
            env,
            case,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
            case_result,
        ),
        Expr::ReturnExpr(ret) => infer_return(
            ctx,
            env,
            ret,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        ),
        Expr::StringExpr(se) => {
            // Each interpolated expression is shown with its Display; one
            // with an error leaves the string a string.
            let interpolated = se
                .syntax()
                .children()
                .filter(|child| child.kind() == SyntaxKind::INTERPOLATION)
                .flat_map(|interpolation| interpolation.children())
                .filter_map(Expr::cast);
            for inner in interpolated {
                let inferred = infer_expr(
                    ctx,
                    env,
                    &inner,
                    types,
                    type_registry,
                    trait_registry,
                    fn_constraints,
                );
                if let Ok(ty) = inferred {
                    let span = inner.syntax().text_range();
                    let origin = ConstraintOrigin::Expr { span };
                    ctx.operand_traits.push((ty, "Display".to_string(), origin));
                }
            }
            Ok(Ty::string())
        }
        Expr::FieldAccess(fa) => infer_field_access(
            ctx,
            env,
            fa,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
            false,
            None,
        ),
        Expr::StructLiteral(sl) => infer_struct_literal(
            ctx,
            env,
            sl,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        ),
        Expr::MapLiteral(map_lit) => infer_map_literal(
            ctx,
            env,
            map_lit,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        ),
        Expr::ListLiteral(lit) => infer_list_literal(
            ctx,
            env,
            lit,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        ),
        Expr::IndexExpr(index) => {
            ctx.errors.push(TypeError::IndexingUnsupported {
                span: index.syntax().text_range(),
            });
            Ok(ctx.fresh_var())
        }
        // Loop expressions.
        Expr::WhileExpr(w) => infer_while(
            ctx,
            env,
            w,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        ),
        Expr::BreakExpr(b) => infer_break(ctx, b),
        Expr::ContinueExpr(c) => infer_continue(ctx, c),
        Expr::ForInExpr(for_in) => infer_for_in(
            ctx,
            env,
            for_in,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        ),
        // Actor expressions.
        Expr::SpawnExpr(spawn) => infer_spawn(
            ctx,
            env,
            spawn,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        ),
        Expr::SendExpr(send) => infer_send(
            ctx,
            env,
            send,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        ),
        Expr::ReceiveExpr(recv) => infer_receive(
            ctx,
            env,
            recv,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        ),
        Expr::SelfExpr(self_expr) => infer_self_expr(ctx, env, self_expr),
        Expr::LinkExpr(link) => infer_link(
            ctx,
            env,
            link,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        ),
        Expr::TryExpr(try_expr) => infer_try_expr(
            ctx,
            env,
            try_expr,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        ),
        Expr::AtomLiteral(_atom) => {
            // Atoms have a distinct type from String -- they are opaque typed values.
            Ok(Ty::Con(TyCon::new("Atom")))
        }
        Expr::RegexExpr(_rx) => {
            // Regex literals have the opaque Regex type.
            // The runtime represents a compiled regex as an opaque pointer.
            Ok(Ty::Con(TyCon::new("Regex")))
        }
        Expr::StructUpdate(update) => infer_struct_update(
            ctx,
            env,
            update,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        ),
        // 1-indexed, >= 2 by parse guarantee.
        Expr::SlotPipeExpr(pipe) => infer_piped(
            ctx,
            env,
            pipe.lhs(),
            pipe.rhs(),
            Some(pipe.slot().unwrap_or(2)),
            pipe.syntax().text_range(),
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        ),
        Expr::JsonExpr(json_expr) => infer_json_expr(
            ctx,
            env,
            json_expr,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        ),
    }?;

    let resolved = ctx.resolve(ty.clone());
    types.insert(expr.syntax().text_range(), resolved.clone());

    // A function used as a value (`apply(show, x)`), not called: whatever
    // its parameters turn out to be must meet its requirements.
    if matches!(expr, Expr::NameRef(_) | Expr::FieldAccess(_)) && !is_called(expr) {
        let span = expr.syntax().text_range();
        if let (Some(constraints), Ty::Fun(params, _)) = (
            constraints_key(ctx, env, expr, span).and_then(|key| fn_constraints.get(&key)),
            &resolved,
        ) {
            require_constraints(ctx, constraints, params, span);
        }
    }

    Ok(ty)
}

/// Report a numeric literal that is malformed (`1e`, `0x`) or out of
/// range (`9223372036854775808` outside `-...`): codegen made each 0.
fn check_numeric_literal(ctx: &mut InferCtx, token: &mesh_parser::SyntaxToken, negated: bool) {
    if let Some(reason) = numeric_literal_error(token.kind(), token.text(), negated) {
        ctx.errors.push(TypeError::InvalidLiteral {
            reason,
            span: token.text_range(),
        });
    }
}

/// Why `text` is not a valid literal of `kind`, if it is not.
fn numeric_literal_error(kind: SyntaxKind, text: &str, negated: bool) -> Option<String> {
    let normalized = text.replace('_', "");
    match kind {
        SyntaxKind::INT_LITERAL => {
            let lower = normalized.to_ascii_lowercase();
            let radixes = [
                ("0x", 16, "hexadecimal"),
                ("0b", 2, "binary"),
                ("0o", 8, "octal"),
            ];
            let (digits, radix, prefix, kind) = radixes
                .iter()
                .find_map(|&(prefix, radix, kind)| {
                    let digits = lower.strip_prefix(prefix)?;
                    Some((digits.to_string(), radix, prefix, kind))
                })
                .unwrap_or((lower.clone(), 10, "", "decimal"));
            if digits.is_empty() {
                return Some(format!("expected digits after `{prefix}`"));
            }
            if let Some(bad) = digits.chars().find(|c| !c.is_digit(radix)) {
                return Some(format!("invalid digit `{bad}` in {kind} literal `{text}`"));
            }
            match u64::from_str_radix(&digits, radix) {
                Ok(value) if value <= i64::MAX as u64 => None,
                // `-9223372036854775808` is the smallest Int.
                Ok(value) if negated && value == 1 << 63 => None,
                _ => Some(format!(
                    "integer literal `{text}` is out of range: an Int is at most 9223372036854775807"
                )),
            }
        }
        // The lexer makes a float of digits, a `.` and digits, and an
        // exponent, whose digits alone may be missing.
        SyntaxKind::FLOAT_LITERAL => {
            if normalized.ends_with(['e', 'E', '+', '-']) {
                return Some("expected digits after the exponent".to_string());
            }
            let finite = normalized.parse::<f64>().is_ok_and(f64::is_finite);
            (!finite).then(|| format!("float literal `{text}` is out of range"))
        }
        _ => None,
    }
}

/// Infer the type of a literal expression.
fn infer_literal(lit: &Literal) -> Ty {
    // The parser makes a literal of a number, `true`, `false` or `nil`.
    match lit.token().map(|token| token.kind()) {
        Some(SyntaxKind::INT_LITERAL) => Ty::int(),
        Some(SyntaxKind::FLOAT_LITERAL) => Ty::float(),
        Some(SyntaxKind::TRUE_KW | SyntaxKind::FALSE_KW) => Ty::bool(),
        _ => Ty::Tuple(vec![]),
    }
}

/// Whether `name` is a struct or sum type of the program's.
fn is_named_type(type_registry: &TypeRegistry, name: &str) -> bool {
    type_registry.lookup_struct(name).is_some() || type_registry.lookup_sum_type(name).is_some()
}

/// `ty` does not implement `trait_name`. A built-in type (`Regex`, `Map`)
/// is told apart: it has no definition to derive the trait on.
fn trait_not_satisfied(
    ctx: &InferCtx,
    ty: Ty,
    trait_name: String,
    origin: ConstraintOrigin,
) -> TypeError {
    let builtin = ty
        .con_name()
        .is_some_and(|name| ctx.builtin_types.contains(name));
    TypeError::TraitNotSatisfied {
        ty,
        trait_name,
        builtin,
        origin,
    }
}

/// A struct or sum type's name names no value: it is the base of a
/// qualified name (`Point.origin()`, `Shape.Circle`) or an error. It type
/// checked as a value of the type, and code generation failed on it. So
/// does a built-in type's (`Int`, `Json`, `Map`), which is the base of its
/// module's functions (`Int.parse`). An alias's name is not even such a base
/// (`Id.parse` for `type Id = Int`): it was "undefined variable".
fn reject_type_as_value(
    ctx: &mut InferCtx,
    env: &TypeEnv,
    type_registry: &TypeRegistry,
    name_ref: &NameRef,
) -> Result<(), TypeError> {
    let Some(name) = name_ref.text() else {
        return Ok(());
    };
    let is_base = name_ref
        .syntax()
        .parent()
        .and_then(FieldAccess::cast)
        .and_then(|fa| fa.base())
        .is_some_and(|base| base.syntax() == name_ref.syntax());
    let builtin = ctx.builtin_types.contains(&name);
    let is_type = type_registry.lookup_alias(&name).is_some()
        || (!is_base && (builtin || is_named_type(type_registry, &name)));
    if !is_type || env.is_local(&name) {
        return Ok(());
    }
    let err = TypeError::TypeNotValue {
        name,
        builtin,
        span: name_ref.syntax().text_range(),
    };
    ctx.errors.push(err.clone());
    Err(err)
}

/// `Type.method` for a struct or sum type `Type`: a static method
/// (`Config.version()`, `Meters.from(5)`), or an instance method named on
/// the type, which takes the value first (`Wrap.label(w, 5)` is
/// `w.label(5)`, as `Labeler.label(w, 5)` is). A type is no value, so a
/// name that is neither is no method rather than a field of a `Type` value.
fn type_qualified_method(
    ctx: &mut InferCtx,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    type_name: &str,
    method: &str,
    span: TextRange,
    method_span: TextRange,
) -> Result<Ty, TypeError> {
    let params = declared_param_count(type_registry, type_name).unwrap_or(0);
    let ty = with_unknown_args(ctx, Ty::Con(TyCon::new(type_name)), params);
    let traits = trait_registry.find_method_traits(method, &ty);
    if traits.len() > 1 {
        let err = TypeError::AmbiguousMethod {
            method_name: method.to_string(),
            candidate_traits: traits,
            ty,
            span,
        };
        ctx.errors.push(err.clone());
        return Err(err);
    }
    match trait_registry.find_method_sig(method, &ty) {
        Some(sig) if !sig.has_self => {
            // Several impls may provide it for the type, taking different
            // arguments (`From<Int>` and `From<String>`): the argument
            // picks one, checked when the function is done.
            let mut takes: Vec<Vec<Ty>> = Vec::new();
            for (imp, _) in trait_registry.impls_providing(method, &ty) {
                if let Some(params) = imp
                    .methods
                    .get(method)
                    .filter(|sig| !sig.has_self)
                    .and_then(|sig| sig.param_types.clone())
                {
                    if !takes.contains(&params) {
                        takes.push(params);
                    }
                }
            }
            let ret = method_return_type(ctx, trait_registry, method, &ty, span)
                .unwrap_or_else(|| ctx.fresh_var());
            let params: Vec<Ty> = match takes.as_slice() {
                [only] if only.len() == sig.param_count => only.clone(),
                _ => (0..sig.param_count).map(|_| ctx.fresh_var()).collect(),
            };
            if takes.len() > 1 && sig.param_count == 1 {
                ctx.impl_choices.push(ImplChoice {
                    result: params[0].clone(),
                    method: method.to_string(),
                    receiver: ty.clone(),
                    candidates: takes
                        .into_iter()
                        .filter_map(|params| params.into_iter().next())
                        .collect(),
                    span,
                    by_argument: true,
                });
            }
            Ok(Ty::Fun(params, Box::new(ret)))
        }
        Some(_) => {
            let ret = method_return_type(ctx, trait_registry, method, &ty, span)
                .unwrap_or_else(|| ctx.fresh_var());
            Ok(build_method_fn_type(trait_registry, method, &ty, &ret, ctx))
        }
        None => {
            let err = TypeError::NoSuchMethod {
                suggestion: closest_name(method, trait_registry.method_names_for(&ty)),
                ty,
                method_name: method.to_string(),
                span: method_span,
            };
            ctx.errors.push(err.clone());
            Err(err)
        }
    }
}

/// `Process.monitor`'s type, or `Node.monitor`'s (`module`): a monitor's
/// message goes to the actor that sets it up, so it is of that actor's
/// message type, and there must be one.
fn monitor_type(
    ctx: &mut InferCtx,
    env: &TypeEnv,
    module: &str,
    span: TextRange,
) -> Result<Ty, TypeError> {
    let Some(message) = env.lookup(ACTOR_MSG_TYPE_KEY).map(|s| ctx.instantiate(s)) else {
        let err = TypeError::MonitorOutsideActor { span };
        ctx.errors.push(err.clone());
        return Err(err);
    };
    let target = if module == "Process" {
        Ty::untyped_pid()
    } else {
        Ty::string()
    };
    Ok(Ty::fun(vec![target, message], Ty::int()))
}

/// Infer the type of a name reference (variable lookup).
fn infer_name_ref(ctx: &mut InferCtx, env: &TypeEnv, name_ref: &NameRef) -> Result<Ty, TypeError> {
    // A name the parser could not read was reported with it, and is no
    // variable to look up.
    let Some(name) = name_ref.text() else {
        return Ok(ctx.fresh_var());
    };
    // `monitor` imported from `Process` or `Node` is typed as
    // `Process.monitor` or `Node.monitor` is.
    let monitor_module = match ctx.stdlib_imports.get(&name).map(String::as_str) {
        Some(module @ ("Process" | "Node")) if name == "monitor" => Some(module.to_string()),
        _ => None,
    };
    if let (Some(module), false) = (monitor_module, env.is_local(&name)) {
        return monitor_type(ctx, env, &module, name_ref.syntax().text_range());
    }

    match env.lookup(&name) {
        Some(scheme) => {
            if scheme.ty.is_callable_theorem() {
                return Err(theorem_requires_application(
                    ctx,
                    name_ref.syntax().text_range(),
                ));
            }
            let jobs_runner = matches!(
                name.as_str(),
                "jobs_start" | "jobs_start_effects" | "jobs_drain"
            ) || (matches!(name.as_str(), "start" | "start_effects" | "drain")
                && ctx
                    .stdlib_imports
                    .get(&name)
                    .is_some_and(|module| module == "Jobs"));
            if jobs_runner
                && !env.is_local(&name)
                && !ctx.top_level_function_visibility.contains_key(&name)
                && !ctx.imported_functions.contains(&name)
            {
                ctx.jobs_runner_references
                    .entry(name_ref.syntax().text_range())
                    .or_default();
            }
            Ok(ctx.instantiate(scheme))
        }
        None => {
            let arities = env.overload_arities(&name);
            let span = name_ref.syntax().text_range();
            let err = if arities.len() > 1 {
                TypeError::OverloadedFunctionValue {
                    name,
                    arities,
                    span,
                }
            } else if let Some(module) = ctx
                .project_modules
                .iter()
                .find(|module| {
                    // Qualified access is through the last segment (`Vector`
                    // for `Math.Vector`); a full path starts with the first.
                    module.rsplit('.').next() == Some(name.as_str())
                        || module.split('.').next() == Some(name.as_str())
                })
                .cloned()
            {
                TypeError::ModuleNotImported { name, module, span }
            } else {
                let suggestion = did_you_mean(env, &name);
                TypeError::UnboundVariable {
                    name,
                    span,
                    suggestion,
                }
            };
            ctx.errors.push(err.clone());
            Err(err)
        }
    }
}

/// A name in scope that `name` may be a misspelling of: at most two edits
/// away (one for a short name), and of its kind (a constructor or type for
/// an uppercase name, a variable or function otherwise).
fn did_you_mean(env: &TypeEnv, name: &str) -> Option<String> {
    let upper = name.starts_with(char::is_uppercase);
    let candidates = env.names().map(String::as_str).filter(|candidate| {
        *candidate != name
            && candidate.starts_with(char::is_uppercase) == upper
            && !candidate.starts_with("__")
            && candidate
                .chars()
                .all(|c| c.is_alphanumeric() || c == '_' || c == '.')
    });
    let max_distance = if name.chars().count() <= 3 { 1 } else { 2 };
    mesh_diagnostics::closest(name, candidates, max_distance).map(str::to_owned)
}

fn closest_name<'a>(name: &str, candidates: impl IntoIterator<Item = &'a str>) -> Option<String> {
    let mut candidates: Vec<_> = candidates
        .into_iter()
        .filter(|candidate| *candidate != name)
        .collect();
    candidates.sort_unstable();
    let max_distance = if name.chars().count() <= 3 { 1 } else { 2 };
    mesh_diagnostics::closest(name, candidates, max_distance).map(str::to_owned)
}

/// Infer the type of a binary expression with trait-based operator dispatch.
fn infer_binary(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    bin: &BinaryExpr,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &FxHashMap<String, FnConstraints>,
) -> Result<Ty, TypeError> {
    let lhs_expr = bin.lhs().ok_or_else(incomplete)?;
    let rhs_expr = bin.rhs().ok_or_else(incomplete)?;

    let lhs_ty = infer_expr(
        ctx,
        env,
        &lhs_expr,
        types,
        type_registry,
        trait_registry,
        fn_constraints,
    )?;
    let rhs_ty = infer_expr(
        ctx,
        env,
        &rhs_expr,
        types,
        type_registry,
        trait_registry,
        fn_constraints,
    )?;

    let op = bin.op().ok_or_else(incomplete)?;
    let origin = ConstraintOrigin::BinOp {
        op_span: bin.syntax().text_range(),
    };

    match op.kind() {
        // Arithmetic: dispatch via compiler-known traits
        SyntaxKind::PLUS
        | SyntaxKind::MINUS
        | SyntaxKind::STAR
        | SyntaxKind::SLASH
        | SyntaxKind::PERCENT => {
            let trait_name = match op.kind() {
                SyntaxKind::PLUS => "Add",
                SyntaxKind::MINUS => "Sub",
                SyntaxKind::STAR => "Mul",
                SyntaxKind::SLASH => "Div",
                _ => "Mod",
            };
            infer_trait_binary_op(ctx, trait_name, &lhs_ty, &rhs_ty, trait_registry, &origin)
        }

        // Equality and ordering: operands of one type with `Eq` or `Ord`.
        SyntaxKind::EQ_EQ
        | SyntaxKind::NOT_EQ
        | SyntaxKind::LT
        | SyntaxKind::GT
        | SyntaxKind::LT_EQ
        | SyntaxKind::GT_EQ => {
            let trait_name = if matches!(op.kind(), SyntaxKind::EQ_EQ | SyntaxKind::NOT_EQ) {
                "Eq"
            } else {
                "Ord"
            };
            ctx.unify(lhs_ty.clone(), rhs_ty, origin.clone())?;
            let resolved = ctx.resolve(lhs_ty);
            if is_type_var(&resolved) {
                ctx.operand_traits
                    .push((resolved, trait_name.to_string(), origin));
            } else if !trait_registry.has_impl(trait_name, &resolved) {
                let err = trait_not_satisfied(ctx, resolved, trait_name.to_string(), origin);
                ctx.errors.push(err.clone());
                return Err(err);
            }
            Ok(Ty::bool())
        }

        // Logical: unify both sides with Bool, return Bool
        SyntaxKind::AND_KW | SyntaxKind::OR_KW | SyntaxKind::AMP_AMP | SyntaxKind::PIPE_PIPE => {
            ctx.unify(Ty::bool(), lhs_ty, origin.clone())?;
            ctx.unify(Ty::bool(), rhs_ty, origin)?;
            Ok(Ty::bool())
        }

        // Concatenation operators join two strings or two lists.
        SyntaxKind::DIAMOND | SyntaxKind::PLUS_PLUS => {
            ctx.unify(lhs_ty.clone(), rhs_ty, origin)?;
            let op = if op.kind() == SyntaxKind::DIAMOND {
                "<>"
            } else {
                "++"
            };
            let span = bin.syntax().text_range();
            let operand = ctx.resolve(lhs_ty.clone());
            if is_type_var(&operand) {
                ctx.concat_operands.push((operand, op, span));
            } else if !is_concatenable(&operand) {
                let err = TypeError::InvalidConcat {
                    op,
                    ty: operand,
                    span,
                };
                ctx.errors.push(err.clone());
                return Err(err);
            }
            Ok(lhs_ty)
        }

        // `start..end`, the one operator left, is a Range of Int wherever it
        // appears.
        _ => {
            ctx.unify(Ty::int(), lhs_ty, origin.clone())?;
            ctx.unify(Ty::int(), rhs_ty, origin)?;
            Ok(Ty::range())
        }
    }
}

/// Infer a binary operator using trait dispatch.
fn infer_trait_binary_op(
    ctx: &mut InferCtx,
    trait_name: &str,
    lhs_ty: &Ty,
    rhs_ty: &Ty,
    trait_registry: &TraitRegistry,
    origin: &ConstraintOrigin,
) -> Result<Ty, TypeError> {
    // A left operand without the operator is the problem to report, not
    // that the right one differs (`maybe + 1` on an `Int?`).
    let lhs = ctx.resolve(lhs_ty.clone());
    if !lhs.has_type_vars() && !trait_registry.has_impl(trait_name, &lhs) {
        let err = trait_not_satisfied(ctx, lhs, trait_name.to_string(), origin.clone());
        ctx.errors.push(err.clone());
        return Err(err);
    }
    ctx.unify(lhs_ty.clone(), rhs_ty.clone(), origin.clone())?;

    let resolved = ctx.resolve(lhs_ty.clone());

    if is_type_var(&resolved) {
        ctx.operand_traits
            .push((resolved.clone(), trait_name.to_string(), origin.clone()));
        return Ok(resolved);
    }

    // The result is the impl's `Output` (`Int` for `Int + Int`); an impl
    // without one is reported already, and gives its operand's type.
    if trait_registry.has_impl(trait_name, &resolved) {
        return Ok(trait_registry
            .resolve_associated_type(trait_name, "Output", &resolved)
            .unwrap_or(resolved));
    }
    let err = trait_not_satisfied(ctx, resolved, trait_name.to_string(), origin.clone());
    ctx.errors.push(err.clone());
    Err(err)
}

/// Infer the type of a unary expression.
fn infer_unary(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    un: &UnaryExpr,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &FxHashMap<String, FnConstraints>,
) -> Result<Ty, TypeError> {
    let operand = un.operand().ok_or_else(incomplete)?;

    let operand_ty = infer_expr(
        ctx,
        env,
        &operand,
        types,
        type_registry,
        trait_registry,
        fn_constraints,
    )?;

    // `!x` and `not x` take a Bool; `-x` a number, or a type with `Neg`.
    let op = un.op().ok_or_else(incomplete)?;
    if op.kind() != SyntaxKind::MINUS {
        let origin = ConstraintOrigin::BinOp {
            op_span: op.text_range(),
        };
        ctx.unify(Ty::bool(), operand_ty, origin)?;
        return Ok(Ty::bool());
    }
    let resolved = ctx.resolve(operand_ty);
    // A type not known yet, or a number: negated, it is itself.
    if is_type_var(&resolved)
        || matches!(&resolved, Ty::Con(tc) if tc.name == "Int" || tc.name == "Float")
    {
        return Ok(resolved);
    }
    // An impl without its `Output` is reported already, and negates to its
    // own type.
    if trait_registry.has_impl("Neg", &resolved) {
        return Ok(trait_registry
            .resolve_associated_type("Neg", "Output", &resolved)
            .unwrap_or(resolved));
    }
    let span = un.syntax().text_range();
    let err = trait_not_satisfied(
        ctx,
        resolved,
        "Neg".to_string(),
        ConstraintOrigin::Expr { span },
    );
    ctx.errors.push(err.clone());
    Err(err)
}

#[derive(Debug, Clone)]
struct ClusteredRouteHandlerRef {
    handler_name: String,
    defining_module: Option<String>,
    runtime_name: String,
}

fn http_field_access_name(expr: &Expr) -> Option<(String, String)> {
    let Expr::FieldAccess(field_access) = expr else {
        return None;
    };
    let base_expr = field_access.base()?;
    let Expr::NameRef(base_name_ref) = base_expr else {
        return None;
    };

    Some((
        base_name_ref.text()?,
        field_access.field()?.text().to_string(),
    ))
}

fn is_http_clustered_callee(expr: &Expr) -> bool {
    matches!(
        http_field_access_name(expr),
        Some((base_name, field_name)) if base_name == "HTTP" && field_name == "clustered"
    )
}

fn is_http_route_registration_callee(expr: &Expr) -> bool {
    matches!(
        http_field_access_name(expr),
        Some((base_name, field_name))
            if base_name == "HTTP"
                && matches!(field_name.as_str(), "route" | "on_get" | "on_post" | "on_put" | "on_delete")
    )
}

fn clustered_wrapper_call_range(expr: &Expr) -> Option<TextRange> {
    let Expr::CallExpr(call) = expr else {
        return None;
    };
    let callee_expr = call.callee()?;
    if is_http_clustered_callee(&callee_expr) {
        Some(call.syntax().text_range())
    } else {
        None
    }
}

fn mark_http_clustered_wrapper_consumed(ctx: &mut InferCtx, expr: &Expr) {
    if let Some(range) = clustered_wrapper_call_range(expr) {
        ctx.consumed_clustered_route_wrappers.insert(range);
    }
}

fn route_handler_function_ty() -> Ty {
    Ty::fun(
        vec![Ty::Con(TyCon::new("Request"))],
        Ty::Con(TyCon::new("Response")),
    )
}

fn is_route_handler_function_ty(ty: &Ty) -> bool {
    match ty {
        Ty::Fun(params, ret) if params.len() == 1 => {
            matches!(&params[0], Ty::Con(con) if con.name == "Request")
                && matches!(ret.as_ref(), Ty::Con(con) if con.name == "Response")
        }
        _ => false,
    }
}

fn qualify_clustered_route_runtime_name(
    defining_module: Option<&str>,
    handler_name: &str,
) -> String {
    match defining_module {
        Some(module_name) if !module_name.is_empty() => format!("{}.{}", module_name, handler_name),
        _ => handler_name.to_string(),
    }
}

fn parse_http_clustered_replication_count(expr: &Expr) -> Option<u32> {
    let Expr::Literal(lit) = expr else {
        return None;
    };
    let token = lit.token()?;
    if token.kind() != SyntaxKind::INT_LITERAL {
        return None;
    }

    token.text().parse::<u32>().ok().filter(|value| *value > 0)
}

fn push_http_clustered_error(ctx: &mut InferCtx, error: TypeError) -> TypeError {
    ctx.errors.push(error.clone());
    error
}

/// The handler `HTTP.clustered(handler)` names: a public top-level function
/// of this module, one imported by name, or `Module.handler` of an imported
/// module, of type `Request -> Response`.
#[allow(clippy::too_many_arguments)]
fn resolve_clustered_route_handler_ref(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    handler_expr: &Expr,
    wrapper_span: TextRange,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &FxHashMap<String, FnConstraints>,
) -> Result<(Ty, ClusteredRouteHandlerRef), TypeError> {
    let invalid = |ctx: &mut InferCtx, reason: String| {
        Err(push_http_clustered_error(
            ctx,
            TypeError::HttpClusteredInvalidArguments {
                reason,
                span: wrapper_span,
            },
        ))
    };
    let private = |ctx: &mut InferCtx, handler_name: String| {
        Err(push_http_clustered_error(
            ctx,
            TypeError::HttpClusteredPrivateHandler {
                handler_name,
                span: wrapper_span,
            },
        ))
    };
    // The handler, which must be a `Request -> Response` function (`shown`
    // is how an error names it), and where it is defined.
    let mut typed = |ctx: &mut InferCtx,
                     env: &mut TypeEnv,
                     shown: String,
                     handler_name: String,
                     defining_module: Option<String>| {
        let handler_ty = infer_expr(
            ctx,
            env,
            handler_expr,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        )?;
        if !is_route_handler_function_ty(&ctx.resolve(handler_ty.clone())) {
            return invalid(
                ctx,
                format!("`{shown}` must have type `{}`", route_handler_function_ty()),
            );
        }
        let runtime_name =
            qualify_clustered_route_runtime_name(defining_module.as_deref(), &handler_name);
        Ok((
            handler_ty,
            ClusteredRouteHandlerRef {
                handler_name,
                defining_module,
                runtime_name,
            },
        ))
    };
    match handler_expr {
        Expr::NameRef(name_ref) => {
            let handler_name = name_ref.text().unwrap_or_else(|| "<unknown>".to_string());
            if let Some(is_public) = ctx
                .top_level_function_visibility
                .get(&handler_name)
                .copied()
            {
                if !is_public {
                    return private(ctx, handler_name);
                }
                // A name defined at several arities is several functions.
                if env.lookup(&handler_name).is_none() {
                    return invalid(
                        ctx,
                        format!(
                            "`{handler_name}` must resolve to a single public top-level route handler reference"
                        ),
                    );
                }
                let defining_module = ctx.current_module.clone();
                return typed(
                    ctx,
                    env,
                    handler_name.clone(),
                    handler_name,
                    defining_module,
                );
            }
            if ctx.imported_functions.contains(&handler_name) {
                let Some(defining_module) = ctx
                    .imported_function_origins
                    .get(&handler_name)
                    .filter(|module| !module.is_empty())
                    .cloned()
                else {
                    return Err(push_http_clustered_error(
                        ctx,
                        TypeError::HttpClusteredImportedOriginMissing {
                            handler_name,
                            span: wrapper_span,
                        },
                    ));
                };
                return typed(
                    ctx,
                    env,
                    handler_name.clone(),
                    handler_name,
                    Some(defining_module),
                );
            }
            let reason = if env.lookup(&handler_name).is_some() {
                format!(
                    "`{handler_name}` must be a public top-level function reference, not a local binding or unsupported value"
                )
            } else {
                format!(
                    "`{handler_name}` must resolve to a public top-level route handler reference"
                )
            };
            invalid(ctx, reason)
        }
        Expr::FieldAccess(field_access) => {
            let Some(Expr::NameRef(base_name_ref)) = field_access.base() else {
                return invalid(
                    ctx,
                    "expected a module-qualified handler reference like `Module.handle`"
                        .to_string(),
                );
            };
            let module_alias = base_name_ref
                .text()
                .unwrap_or_else(|| "<unknown>".to_string());
            let handler_name = field_access
                .field()
                .map(|token| token.text().to_string())
                .unwrap_or_else(|| "<unknown>".to_string());
            let shown = format!("{module_alias}.{handler_name}");
            let Some(defining_module) = ctx.qualified_module_origins.get(&module_alias).cloned()
            else {
                return invalid(
                    ctx,
                    format!("`{shown}` must reference a function from an imported user module"),
                );
            };
            if ctx
                .qualified_module_private_names
                .get(&module_alias)
                .is_some_and(|names| names.contains(&handler_name))
            {
                return private(ctx, handler_name);
            }
            if !ctx
                .qualified_modules
                .get(&module_alias)
                .is_some_and(|exports| exports.contains_key(&handler_name))
            {
                return invalid(
                    ctx,
                    format!(
                        "`{shown}` is not an exported public handler in module `{defining_module}`"
                    ),
                );
            }
            typed(ctx, env, shown, handler_name, Some(defining_module))
        }
        _ => invalid(
            ctx,
            "expected a bare handler reference or module-qualified handler reference".to_string(),
        ),
    }
}

fn infer_http_clustered_wrapper_call(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    call: &CallExpr,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &FxHashMap<String, FnConstraints>,
) -> Result<Ty, TypeError> {
    let wrapper_span = call.syntax().text_range();
    let args: Vec<Expr> = call
        .arg_list()
        .map(|arg_list| arg_list.args().collect())
        .unwrap_or_default();

    let (replication_count, handler_expr) = match args.as_slice() {
        [handler_expr] => (ClusteredRouteReplicationCount::defaulted(), handler_expr),
        [count_expr, handler_expr] => {
            let Some(value) = parse_http_clustered_replication_count(count_expr) else {
                let err = TypeError::HttpClusteredInvalidArguments {
                    reason:
                        "the replication count must be a positive integer literal, e.g. `HTTP.clustered(3, handler)`"
                            .to_string(),
                    span: wrapper_span,
                };
                return Err(push_http_clustered_error(ctx, err));
            };
            (
                ClusteredRouteReplicationCount::explicit(value),
                handler_expr,
            )
        }
        _ => {
            let err = TypeError::HttpClusteredInvalidArguments {
                reason: "expected `HTTP.clustered(handler)` or `HTTP.clustered(<int>, handler)`"
                    .to_string(),
                span: wrapper_span,
            };
            return Err(push_http_clustered_error(ctx, err));
        }
    };

    let (handler_ty, handler_ref) = resolve_clustered_route_handler_ref(
        ctx,
        env,
        handler_expr,
        wrapper_span,
        types,
        type_registry,
        trait_registry,
        fn_constraints,
    )?;

    if let Some(existing_count) = ctx
        .clustered_route_replication_counts
        .get(&handler_ref.runtime_name)
        .copied()
    {
        if existing_count.value != replication_count.value {
            let first_span = ctx
                .clustered_route_wrappers
                .iter()
                .find_map(|(span, metadata)| {
                    (metadata.runtime_name == handler_ref.runtime_name).then_some(*span)
                })
                .unwrap_or(wrapper_span);
            let err = TypeError::HttpClusteredConflictingReplicationCount {
                runtime_name: handler_ref.runtime_name,
                first_count: existing_count.value,
                current_count: replication_count.value,
                first_span,
                span: wrapper_span,
            };
            return Err(push_http_clustered_error(ctx, err));
        }
    }

    ctx.clustered_route_replication_counts
        .entry(handler_ref.runtime_name.clone())
        .or_insert(replication_count);
    ctx.clustered_route_wrappers.insert(
        wrapper_span,
        ClusteredRouteWrapperMetadata {
            handler_name: handler_ref.handler_name,
            defining_module: handler_ref.defining_module,
            runtime_name: handler_ref.runtime_name,
            handler_span: handler_expr.syntax().text_range(),
            replication_count,
        },
    );

    Ok(handler_ty)
}

/// Infer a call argument after the callee has established its expected parameter type.
///
/// Closures need the expected function type before their bodies are inferred so field
/// access and other parameter-dependent expressions see the concrete parameter type.
fn infer_call_argument(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    arg: &Expr,
    expected_ty: Ty,
    origin: ConstraintOrigin,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &FxHashMap<String, FnConstraints>,
) -> Result<Ty, TypeError> {
    // A callback declared to return `()` is only run for its effects, so it
    // accepts a function returning anything and the result is discarded:
    // `Ws.serve` takes an `on_message` that ends in `Ws.broadcast(..)` without
    // a trailing `nil`. A closure gets the callback's parameter types but keeps
    // its body's own type.
    let unit_callback_params = match ctx.resolve(expected_ty.clone()) {
        Ty::Fun(params, ret) if is_unit(&ctx.resolve((*ret).clone())) => Some(params),
        _ => None,
    };
    let arg_ty = match arg {
        Expr::ClosureExpr(closure) => {
            let expected = match &unit_callback_params {
                Some(params) => Ty::Fun(params.clone(), Box::new(ctx.fresh_var())),
                None => expected_ty.clone(),
            };
            infer_closure(
                ctx,
                env,
                closure,
                types,
                type_registry,
                trait_registry,
                fn_constraints,
                Some(expected),
            )?
        }
        _ => infer_expr(
            ctx,
            env,
            arg,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        )?,
    };

    if let (Some(params), Ty::Fun(arg_params, arg_ret)) =
        (unit_callback_params, ctx.resolve(arg_ty.clone()))
    {
        let arg_ret = ctx.resolve(*arg_ret);
        if arg_params.len() == params.len()
            && !is_unit(&arg_ret)
            && !matches!(arg_ret, Ty::Var(_) | Ty::Never)
        {
            for (param, arg_param) in params.into_iter().zip(arg_params) {
                ctx.unify(param, arg_param, origin.clone())?;
            }
            ctx.discarded_callback_results
                .insert(arg.syntax().text_range());
            types.insert(arg.syntax().text_range(), ctx.resolve(arg_ty.clone()));
            return Ok(arg_ty);
        }
    }

    if !json_as_text(ctx, &expected_ty, &arg_ty, arg.syntax().text_range()) {
        ctx.unify(expected_ty, arg_ty.clone(), origin)?;
    }
    types.insert(arg.syntax().text_range(), ctx.resolve(arg_ty.clone()));
    Ok(arg_ty)
}

/// Whether the argument at `range`, of type `arg_ty`, is a `Json` where a
/// `String` is expected: the call is given its encoded text, which lowering
/// makes (`json_text_arguments`), so `HTTP.response(200, json { .. })` needs
/// no `Json.encode`. Nowhere else does a `Json` stand for a `String`.
fn json_as_text(ctx: &mut InferCtx, expected_ty: &Ty, arg_ty: &Ty, range: TextRange) -> bool {
    let is = |ty: &Ty, name: &str| matches!(ty, Ty::Con(con) if con.name == name);
    let converts =
        is(&ctx.resolve(expected_ty.clone()), "String") && is(&ctx.resolve(arg_ty.clone()), "Json");
    if converts {
        ctx.json_text_arguments.insert(range);
    }
    converts
}

fn is_unit(ty: &Ty) -> bool {
    matches!(ty, Ty::Tuple(elems) if elems.is_empty())
}

/// Which element a call to `Tuple.first`, `Tuple.second` or `Tuple.nth` selects:
/// `Some(Some(i))` for a known position, `Some(None)` for `nth` with a computed
/// index, `None` when `callee` is not one of them.
///
/// They are declared `(Tuple, ..) -> Int`, the most an untyped `Tuple` allows,
/// which made them a type error, or the element's address, on any tuple whose
/// element is not an `Int`. A call usually knows the tuple's type, so it takes
/// the element's type from there (`tuple_element_type`).
fn tuple_accessor(
    ctx: &InferCtx,
    callee: &Expr,
    index_arg: Option<&Expr>,
) -> Option<Option<usize>> {
    let name = match callee {
        Expr::FieldAccess(access) => {
            let Some(Expr::NameRef(module)) = access.base() else {
                return None;
            };
            // A user module called `Tuple` shadows the stdlib one.
            if module.text().as_deref() != Some("Tuple")
                || ctx.qualified_modules.contains_key("Tuple")
            {
                return None;
            }
            access.field()?.text().to_string()
        }
        Expr::NameRef(name) => name.text()?.strip_prefix("tuple_")?.to_string(),
        _ => return None,
    };
    match name.as_str() {
        "first" => Some(Some(0)),
        "second" => Some(Some(1)),
        "nth" => Some(index_arg.and_then(|index| match index {
            Expr::Literal(literal) => literal.token()?.text().parse().ok(),
            _ => None,
        })),
        _ => None,
    }
}

/// The type of element `index` of the tuple an accessor is applied to.
///
/// A tuple whose type is known gives its element's type. One whose type
/// inference has not reached yet -- an unannotated parameter, as in
/// `fn head(p) do Tuple.first(p) end` -- is constrained to be a tuple with at
/// least that many elements (`Ty::tuple_row`), and the element's type comes out
/// when the rest is known; `head` generalizes like any other function. A
/// computed index needs every element of a known tuple to share one type,
/// since any of them could be the one selected. Only an untyped `Tuple` is
/// left reading as `Int`, as declared.
fn tuple_element_type(
    ctx: &mut InferCtx,
    tuple_ty: &Ty,
    index: Option<usize>,
    origin: ConstraintOrigin,
) -> Result<Ty, TypeError> {
    match (ctx.resolve(tuple_ty.clone()), index) {
        (Ty::Tuple(elems), Some(index)) if index < elems.len() => Ok(elems[index].clone()),
        (unknown, Some(index))
            if matches!(unknown, Ty::Var(_)) || unknown.as_tuple_row().is_some() =>
        {
            let elems: Vec<Ty> = (0..=index).map(|_| ctx.fresh_var()).collect();
            let element = elems[index].clone();
            let tail = ctx.fresh_var();
            ctx.unify(tuple_ty.clone(), Ty::tuple_row(elems, tail), origin)?;
            Ok(element)
        }
        // A computed index can land on any element, so the element's type is
        // knowable only when every element shares one. Reading the slot as the
        // declared `Int` instead would hand back a reference's address.
        (Ty::Tuple(elems), None) if !elems.is_empty() => {
            let element = elems[0].clone();
            for other in elems.iter().skip(1) {
                ctx.unify(element.clone(), other.clone(), origin.clone())?;
            }
            Ok(element)
        }
        _ => {
            // Anything that is not a tuple at all is rejected here.
            ctx.unify(Ty::Con(TyCon::new("Tuple")), tuple_ty.clone(), origin)?;
            Ok(Ty::int())
        }
    }
}

/// Infer the type of a function call expression with where-clause enforcement.
/// A call's type. What its callee left open about an associated type
/// (`Add.add(v, v)` returns `Self.Output`) is settled as soon as the
/// arguments fix the receiver, so a method called on the result
/// (`Add.add(v, v).add(v)`) finds its type.
fn infer_call(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    call: &CallExpr,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &FxHashMap<String, FnConstraints>,
) -> Result<Ty, TypeError> {
    let from = ctx.projection_requirements.len();
    let ty = infer_call_unsettled(
        ctx,
        env,
        call,
        types,
        type_registry,
        trait_registry,
        fn_constraints,
    );
    settle_projections(ctx, trait_registry, from);
    ty
}

/// Unify each associated type required from index `from` on with the
/// receiver's, where the receiver is now known.
fn settle_projections(ctx: &mut InferCtx, trait_registry: &TraitRegistry, from: usize) {
    // A copy: unifying needs `ctx` mutably.
    let pending = ctx.projection_requirements[from..].to_vec();
    for (required, trait_name, assoc, receiver, span) in pending {
        let receiver = ctx.resolve(receiver);
        if receiver.has_type_vars() {
            continue;
        }
        if let Some(assoc_ty) =
            trait_registry.resolve_associated_type(&trait_name, &assoc, &receiver)
        {
            let origin = span.map_or(ConstraintOrigin::Builtin, |span| ConstraintOrigin::Expr {
                span,
            });
            let _ = ctx.unify(required, assoc_ty, origin);
        }
    }
}

fn infer_call_unsettled(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    call: &CallExpr,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &FxHashMap<String, FnConstraints>,
) -> Result<Ty, TypeError> {
    // The builtin `default()` builds a value of whatever type its context
    // gives it; which type, and that it has a Default, is checked once the
    // enclosing function is inferred.
    let builtin_default = matches!(call.callee(), Some(Expr::NameRef(ref name)) if name.text().as_deref() == Some("default"))
        && call
            .arg_list()
            .is_none_or(|list| list.args().next().is_none())
        && env
            .lookup("default")
            .is_some_and(|scheme| scheme.vars == [TyVar(99000)]);
    // The parser opens a call around the expression it calls.
    let callee = call.callee().expect("a call has its callee");
    if let Some(ty) = theorem_callee_type(ctx, env, &callee) {
        let result = infer_theorem_application(
            ctx,
            env,
            call,
            &ty,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        )?;
        types.insert(callee.syntax().text_range(), ty);
        return Ok(result);
    }
    if let Some(ty) = infer_node_spawn(
        ctx,
        env,
        &callee,
        &call.args(),
        None,
        call.syntax().text_range(),
        types,
        type_registry,
        trait_registry,
        fn_constraints,
    )? {
        return Ok(ty);
    }
    let ty = infer_call_inner(
        ctx,
        env,
        call,
        types,
        type_registry,
        trait_registry,
        fn_constraints,
    )?;
    if builtin_default {
        ctx.default_calls
            .push((ty.clone(), call.syntax().text_range()));
    }
    Ok(ty)
}

fn theorem_requires_application(ctx: &mut InferCtx, span: TextRange) -> TypeError {
    report(
        ctx,
        TypeError::InvalidProposition {
            reason: "apply this theorem directly to its static indices and proof arguments".into(),
            span,
        },
    )
}

fn theorem_callee_type(ctx: &InferCtx, env: &TypeEnv, callee: &Expr) -> Option<Ty> {
    let scheme = match callee {
        Expr::NameRef(name) => env.lookup(&name.text()?)?,
        Expr::FieldAccess(access) => {
            let Expr::NameRef(base) = access.base()? else {
                return None;
            };
            ctx.qualified_modules
                .get(&base.text()?)?
                .get(access.field()?.text())?
        }
        _ => return None,
    };
    scheme.ty.is_callable_theorem().then(|| scheme.ty.clone())
}

fn static_index_key(name: &str) -> String {
    format!("\0static Nat {name}")
}

fn static_index_argument(env: &TypeEnv, arg: &Expr) -> Option<NatIndex> {
    match arg {
        Expr::Literal(literal) => {
            let token = literal.token()?;
            (token.kind() == SyntaxKind::INT_LITERAL)
                .then(|| parse_nat_literal(token.text()))
                .flatten()
                .map(NatIndex::Literal)
        }
        Expr::NameRef(name) => match &env.lookup(&static_index_key(&name.text()?))?.ty {
            Ty::Nat(index) => Some(index.clone()),
            _ => None,
        },
        Expr::CallExpr(call) if matches!(call.callee(), Some(Expr::NameRef(name)) if name.text().as_deref() == Some("Succ")) =>
        {
            let args = call.args();
            let [index] = args.as_slice() else {
                return None;
            };
            Some(static_index_argument(env, index)?.successor())
        }
        Expr::BinaryExpr(expression) => {
            let left = static_index_argument(env, &expression.lhs()?)?;
            let right = static_index_argument(env, &expression.rhs()?)?;
            use NatIndex::Literal;
            match (expression.op()?.kind(), left, right) {
                (SyntaxKind::PLUS, Literal(a), Literal(b)) => a.checked_add(b).map(Literal),
                (SyntaxKind::MINUS, Literal(a), Literal(b)) => Some(Literal(a.saturating_sub(b))),
                (SyntaxKind::STAR, Literal(a), Literal(b)) => a.checked_mul(b).map(Literal),
                (SyntaxKind::PLUS, value, Literal(0))
                | (SyntaxKind::PLUS, Literal(0), value)
                | (SyntaxKind::MINUS, value, Literal(0))
                | (SyntaxKind::STAR, value, Literal(1))
                | (SyntaxKind::STAR, Literal(1), value) => Some(value),
                (SyntaxKind::STAR, _, Literal(0)) | (SyntaxKind::STAR, Literal(0), _) => {
                    Some(Literal(0))
                }
                _ => None,
            }
        }
        _ => None,
    }
}

#[allow(clippy::too_many_arguments)]
fn infer_theorem_application(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    call: &CallExpr,
    ty: &Ty,
    types: &mut FxHashMap<TextRange, Ty>,
    registry: &TypeRegistry,
    traits: &TraitRegistry,
    constraints: &FxHashMap<String, FnConstraints>,
) -> Result<Ty, TypeError> {
    use crate::proof_values::{instantiate_theorem_proof, CallableTheoremParam};

    let span = call.syntax().text_range();
    let theorem = ty
        .callable_theorem()
        .expect("a checked theorem application");
    let args = call.args();
    let params = theorem.params();
    if args.len() != params.len() {
        let error = TypeError::ArityMismatch {
            expected: params.len(),
            found: args.len(),
            origin: ConstraintOrigin::Expr { span },
        };
        ctx.errors.push(error.clone());
        return Err(error);
    }

    let mut indices = FxHashMap::default();
    for (argument, parameter) in args.iter().zip(params) {
        let arg_span = argument.syntax().text_range();
        match parameter {
            CallableTheoremParam::Nat(name) => {
                let index = static_index_argument(env, argument).ok_or_else(|| {
                    invalid_index(
                        ctx,
                        arg_span,
                        "a theorem's Nat argument requires a static Nat expression".into(),
                    )
                })?;
                types.insert(arg_span, Ty::Nat(index.clone()));
                indices.insert(name.to_owned(), index);
            }
            CallableTheoremParam::Evidence(premise) => {
                let expected = instantiate_theorem_proof(premise, &indices)
                    .expect("a theorem premise refers only to earlier Nat binders");
                let actual = infer_expr(ctx, env, argument, types, registry, traits, constraints)?;
                ctx.unify(expected, actual, ConstraintOrigin::Expr { span: arg_span })?;
            }
        }
    }
    let result = instantiate_theorem_proof(theorem.result, &indices)
        .expect("a theorem result refers only to its Nat binders");
    Ok(ctx.resolve(result))
}

/// `Iter.from(source)` iterates over a list's elements, a map's `(key,
/// value)` pairs, a set's elements or a range's integers: `source`'s type
/// decides the element type of the `Iter` the call returns (`ret`). A source
/// of no known collection type is a list.
fn settle_iter_source(
    ctx: &mut InferCtx,
    env: &TypeEnv,
    callee: &Expr,
    source: &Ty,
    ret: &Ty,
    origin: &ConstraintOrigin,
) -> Result<(), TypeError> {
    let Expr::FieldAccess(fa) = callee else {
        return Ok(());
    };
    let is_iter_from = fa.field().is_some_and(|f| f.text() == "from")
        && matches!(fa.base(), Some(Expr::NameRef(base)) if base.text().as_deref() == Some("Iter"))
        && env.lookup("Iter").is_none();
    if !is_iter_from {
        return Ok(());
    }
    let element = match ctx.resolve(source.clone()) {
        Ty::App(con, args)
            if matches!(con.as_ref(), Ty::Con(tc) if tc.name == "Map") && args.len() == 2 =>
        {
            Ty::Tuple(args)
        }
        Ty::App(con, mut args)
            if matches!(con.as_ref(), Ty::Con(tc) if tc.name == "Set") && args.len() == 1 =>
        {
            args.remove(0)
        }
        Ty::Con(tc) if tc.name == "Range" => Ty::int(),
        _ => {
            let element = ctx.fresh_var();
            ctx.unify(source.clone(), Ty::list(element.clone()), origin.clone())?;
            element
        }
    };
    ctx.unify(ret.clone(), Ty::iter(element), origin.clone())
}

/// `Node.spawn(node, actor, args...)` and `Node.spawn_link(...)`, typed as a
/// local `spawn` is: the node name is a `String`, the actor takes the
/// arguments, and the call returns the actor's `Pid<M>`. `piped` is the
/// value a pipe gives the call, with where it comes from and the argument
/// position it goes to. `None` for any other callee.
#[allow(clippy::too_many_arguments)]
fn infer_node_spawn(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    callee: &Expr,
    args: &[Expr],
    piped: Option<(TextRange, usize, Ty)>,
    span: TextRange,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &FxHashMap<String, FnConstraints>,
) -> Result<Option<Ty>, TypeError> {
    let Expr::FieldAccess(access) = callee else {
        return Ok(None);
    };
    if !is_node_spawn(env, access) {
        return Ok(None);
    }
    let mut arg_types = Vec::new();
    for arg in args {
        let ty = infer_expr(
            ctx,
            env,
            arg,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        );
        arg_types.push((arg.syntax().text_range(), ty?));
    }
    if let Some((range, index, ty)) = piped {
        arg_types.insert(index.min(arg_types.len()), (range, ty));
    }
    let [(node_range, node), (actor_range, actor), rest @ ..] = arg_types.as_slice() else {
        let err = TypeError::ArityMismatch {
            expected: 2,
            found: arg_types.len(),
            origin: ConstraintOrigin::Expr { span },
        };
        ctx.errors.push(err.clone());
        return Err(err);
    };
    let node_origin = ConstraintOrigin::FnArg {
        call_site: *node_range,
        param_idx: 0,
    };
    ctx.unify(Ty::string(), node.clone(), node_origin)?;
    let pid = Ty::pid(ctx.fresh_var());
    let actor_args = rest.iter().map(|(_, ty)| ty.clone()).collect();
    let actor_origin = ConstraintOrigin::FnArg {
        call_site: *actor_range,
        param_idx: 1,
    };
    ctx.unify(
        actor.clone(),
        Ty::Fun(actor_args, Box::new(pid.clone())),
        actor_origin,
    )?;
    let params = arg_types.into_iter().map(|(_, ty)| ty).collect();
    types.insert(
        callee.syntax().text_range(),
        Ty::Fun(params, Box::new(pid.clone())),
    );
    Ok(Some(pid))
}

/// Whether `callee` is `Node.spawn` or `Node.spawn_link` (with no local
/// `Node` in scope).
fn is_node_spawn(env: &TypeEnv, access: &FieldAccess) -> bool {
    matches!(access.base(), Some(Expr::NameRef(ref base)) if base.text().as_deref() == Some("Node"))
        && env.lookup("Node").is_none()
        && access
            .field()
            .is_some_and(|field| matches!(field.text(), "spawn" | "spawn_link"))
}

fn infer_call_inner(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    call: &CallExpr,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &FxHashMap<String, FnConstraints>,
) -> Result<Ty, TypeError> {
    if let Some(ty) = infer_bare_method_call(
        ctx,
        env,
        call,
        types,
        type_registry,
        trait_registry,
        fn_constraints,
    )? {
        return Ok(ty);
    }
    let callee_expr = call.callee().ok_or_else(incomplete)?;

    if is_http_clustered_callee(&callee_expr) {
        return infer_http_clustered_wrapper_call(
            ctx,
            env,
            call,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        );
    }

    // A fn defined at more than one arity: the arity the call names.
    let arity_dispatched_ty = infer_overloaded_callee(
        ctx,
        env,
        &callee_expr,
        call.args().len(),
        call.syntax().text_range(),
        types,
    );

    // Try normal callee inference first. For FieldAccess callees, this goes through
    // the standard infer_field_access path (modules, services, variants, struct fields).
    // If that fails AND the callee is a FieldAccess, retry in method-call context.
    let callee_ty = if let Some(ty) = arity_dispatched_ty {
        ty
    } else {
        match infer_expr(
            ctx,
            env,
            &callee_expr,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        ) {
            Ok(ty) => ty,
            Err(first_err) => {
                // A name the base's type has no field of may be one of its
                // methods, looked up on the type the attempt gave the base:
                // inferring the base again made a chain of calls exponential.
                // Any other failure (an undefined base, a module without the
                // function, an error in the base itself) would only fail
                // again, and report it again.
                let (fa, base_ty, field_span) =
                    match (&callee_expr, &first_err, ctx.field_base.take()) {
                        (
                            Expr::FieldAccess(fa),
                            TypeError::NoSuchField { span, .. },
                            Some((access, base_ty)),
                        ) if access == fa.syntax().text_range()
                            && fa.field().is_some_and(|field| field.text_range() == *span) =>
                        {
                            (fa, base_ty, *span)
                        }
                        _ => return Err(first_err),
                    };
                // Take back the error this attempt reported, and no other.
                ctx.errors.retain(|error| {
                    !matches!(error, TypeError::NoSuchField { span, .. } if *span == field_span)
                });
                let callee_ty = infer_field_access(
                    ctx,
                    env,
                    fa,
                    types,
                    type_registry,
                    trait_registry,
                    fn_constraints,
                    true,
                    Some(base_ty.clone()),
                )?;
                let explicit_args = call.args();
                let ret_var = ctx.fresh_var();
                let origin = ConstraintOrigin::FnArg {
                    call_site: call.syntax().text_range(),
                    param_idx: 0,
                };
                // The receiver, then the arguments.
                let param_types: Vec<Ty> = std::iter::once(base_ty)
                    .chain(explicit_args.iter().map(|_| ctx.fresh_var()))
                    .collect();
                let expected_fn_ty = Ty::Fun(param_types.clone(), Box::new(ret_var.clone()));

                // Establish the method signature, with the receiver, first:
                // the receiver specializes generic method parameters before
                // explicit closure arguments are inferred.
                ctx.unify(callee_ty, expected_fn_ty, origin)?;

                for (arg_idx, arg) in explicit_args.iter().enumerate() {
                    let param_idx = arg_idx + 1;
                    infer_call_argument(
                        ctx,
                        env,
                        arg,
                        param_types[param_idx].clone(),
                        ConstraintOrigin::FnArg {
                            call_site: significant_range(arg.syntax()),
                            param_idx,
                        },
                        types,
                        type_registry,
                        trait_registry,
                        fn_constraints,
                    )?;
                }

                let result = ctx.resolve(ret_var);
                types.insert(call.syntax().text_range(), result.clone());
                return Ok(result);
            }
        }
    }; // close else { match ... } and the let binding

    check_call(
        ctx,
        env,
        &callee_expr,
        callee_ty,
        &call.args(),
        None,
        call.syntax().text_range(),
        types,
        type_registry,
        trait_registry,
        fn_constraints,
    )
}

/// Checks a call of `callee_expr`, of type `callee_ty`, with the arguments
/// `written` in it and a value piped in (`x |> f(a)`, `x |2> f(a)`): its
/// expression, optional numbered slot and type. The arguments are checked
/// against the parameters, then against what the callee requires of them: its
/// where-clause, the bounds its body infers of them, `Display` for
/// `String.from`. `call_range` is the call's. Returns the call's type.
#[allow(clippy::too_many_arguments)]
fn check_call(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    callee_expr: &Expr,
    callee_ty: Ty,
    written: &[Expr],
    piped: Option<(&Expr, Option<u32>, Ty)>,
    call_range: TextRange,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &FxHashMap<String, FnConstraints>,
) -> Result<Ty, TypeError> {
    // Every argument in order; the piped one's type is known already.
    let mut args: Vec<(&Expr, Option<Ty>)> = written.iter().map(|arg| (arg, None)).collect();
    let plain_pipe = matches!(piped, Some((_, None, _)));
    if let Some((expr, slot, ty)) = piped {
        let index = slot.map_or(0, |slot| slot as usize - 1);
        args.insert(index.min(args.len()), (expr, Some(ty)));
    }

    if let Some(called) = ctx
        .jobs_runner_references
        .get_mut(&callee_expr.syntax().text_range())
    {
        *called = true;
        if let Some((handler, _)) = args.get(2) {
            check_jobs_handler(ctx, env, handler)?;
        }
    }

    let ret_var = ctx.fresh_var();
    let origin = ConstraintOrigin::FnArg {
        call_site: call_range,
        param_idx: 0,
    };
    let mut arg_types = Vec::with_capacity(args.len());

    let accessor = tuple_accessor(ctx, callee_expr, args.get(1).map(|(arg, _)| *arg));
    let resolved_callee = ctx.resolve(callee_ty.clone());
    if matches!(resolved_callee, Ty::Fun(_, _) | Ty::Var(_)) {
        let param_types: Vec<Ty> = (0..args.len()).map(|_| ctx.fresh_var()).collect();
        // A tuple accessor is typed by `tuple_element_type`, not by its
        // declared `(Tuple, ..) -> Int`, which would pin an argument of
        // unknown type to the untyped `Tuple`. Only `nth`'s index stays declared.
        if accessor.is_some() {
            if let Some(index_ty) = param_types.get(1) {
                ctx.unify(Ty::int(), index_ty.clone(), origin.clone())?;
            }
        }
        let expected_fn_ty = match accessor {
            Some(_) => callee_ty.clone(),
            None => Ty::Fun(param_types.clone(), Box::new(ret_var.clone())),
        };

        // Establish the callee's parameter types first, then the piped value,
        // then the written arguments in source order. This lets an earlier
        // argument specialize the expected type of a later closure.
        let callee_origin = if plain_pipe
            && accessor.is_none()
            && matches!(&resolved_callee, Ty::Fun(params, _) if params.len() == written.len())
        {
            pipe_placeholder_slot(env, written).map_or_else(
                || origin.clone(),
                |placeholder_slot| ConstraintOrigin::PipePlaceholder {
                    call_site: call_range,
                    placeholder_slot,
                },
            )
        } else {
            origin.clone()
        };
        ctx.unify(callee_ty, expected_fn_ty, callee_origin)?;
        for (param_idx, (piped, piped_ty)) in args.iter().enumerate() {
            if let Some(ty) = piped_ty {
                let origin = ConstraintOrigin::FnArg {
                    call_site: call_range,
                    param_idx,
                };
                let param_ty = &param_types[param_idx];
                if !json_as_text(ctx, param_ty, ty, piped.syntax().text_range()) {
                    ctx.unify(param_ty.clone(), ty.clone(), origin)?;
                }
            }
        }
        for (param_idx, (arg, piped_ty)) in args.iter().enumerate() {
            let arg_ty = match piped_ty {
                Some(ty) => ty.clone(),
                None => infer_call_argument(
                    ctx,
                    env,
                    arg,
                    param_types[param_idx].clone(),
                    ConstraintOrigin::FnArg {
                        call_site: significant_range(arg.syntax()),
                        param_idx,
                    },
                    types,
                    type_registry,
                    trait_registry,
                    fn_constraints,
                )?,
            };
            arg_types.push(arg_ty);
        }
    } else {
        // The arguments' own errors come first; then the callee, which is a
        // value that cannot be called (unless an earlier error left it
        // `Never`, which is callable as anything).
        for (arg, piped_ty) in &args {
            let arg_ty = match piped_ty {
                Some(ty) => ty.clone(),
                None => infer_expr(
                    ctx,
                    env,
                    arg,
                    types,
                    type_registry,
                    trait_registry,
                    fn_constraints,
                )?,
            };
            arg_types.push(arg_ty);
        }
        let callee_ty = ctx.resolve(callee_ty);
        if callee_ty != Ty::Never {
            let err = TypeError::NotAFunction {
                ty: callee_ty,
                span: significant_range(callee_expr.syntax()),
            };
            ctx.errors.push(err.clone());
            return Err(err);
        }
        let expected_fn_ty = Ty::Fun(arg_types.clone(), Box::new(ret_var.clone()));
        ctx.unify(callee_ty, expected_fn_ty, origin.clone())?;
    }

    if let (Some(index), Some(tuple_ty)) = (accessor, arg_types.first()) {
        let element = tuple_element_type(ctx, tuple_ty, index, origin.clone())?;
        ctx.unify(ret_var.clone(), element, origin.clone())?;
    }
    if let Some(source) = arg_types.first() {
        settle_iter_source(ctx, env, callee_expr, source, &ret_var, &origin)?;
    }

    if is_http_route_registration_callee(callee_expr) {
        if let Some((handler, None)) = args.get(2) {
            mark_http_clustered_wrapper_consumed(ctx, handler);
        }
    }

    // `String.from(x)` shows `x` as interpolating it would: x needs Display.
    // `Json.encode(x)`: x must be something JSON holds (checked with the
    // operators' traits, see `check_type_param_bounds`).
    if let (Expr::FieldAccess(fa), Some(arg)) = (callee_expr, arg_types.first()) {
        let module = match fa.base() {
            Some(Expr::NameRef(base)) => base.text(),
            _ => None,
        };
        let required = match (module.as_deref(), fa.field().map(|f| f.text().to_string())) {
            (Some("String"), Some(field)) if field == "from" => Some("Display"),
            (Some("Json" | "JSON"), Some(field)) if field == "encode" => Some("Json"),
            _ => None,
        };
        if let Some(trait_name) = required {
            ctx.operand_traits
                .push((arg.clone(), trait_name.to_string(), origin.clone()));
        }
        // A map's keys and a set's elements are told apart by their Eq
        // (lowering's `key_needs_eq`), asked where one is added: a set of
        // functions was refused there, without a place.
        let adds_key = matches!(
            (
                module.as_deref(),
                fa.field().map(|f| f.text().to_string()).as_deref()
            ),
            (Some("Map"), Some("put")) | (Some("Set"), Some("add"))
        );
        if adds_key {
            let collection = ctx.resolve(arg.clone());
            let key = collection
                .args_of("Map")
                .or_else(|| collection.args_of("Set"))
                .and_then(<[Ty]>::first);
            if let Some(key) = key {
                ctx.operand_traits
                    .push((key.clone(), "Eq".to_string(), origin.clone()));
            }
        }
    }

    if let Some(constraints) =
        constraints_key(ctx, env, callee_expr, call_range).and_then(|key| fn_constraints.get(&key))
    {
        require_constraints(ctx, constraints, &arg_types, call_range);
    }

    Ok(ret_var)
}

fn pipe_placeholder_slot(env: &TypeEnv, written: &[Expr]) -> Option<usize> {
    if env.lookup("_").is_some() {
        return None;
    }
    let mut placeholders = written.iter().enumerate().filter(
        |(_, arg)| matches!(arg, Expr::NameRef(name) if name.text().as_deref() == Some("_")),
    );
    let (index, _) = placeholders.next()?;
    placeholders.next().is_none().then_some(index + 1)
}

fn jobs_handler_type() -> Ty {
    Ty::fun(vec![Ty::string()], Ty::string())
}

/// The runner may call this function after its caller returns. Only a
/// named function with a concrete signature is eligible.
fn check_jobs_handler(ctx: &mut InferCtx, env: &TypeEnv, handler: &Expr) -> Result<(), TypeError> {
    let span = handler.syntax().text_range();
    let scheme = match handler {
        Expr::NameRef(name) => match name.text() {
            Some(name) if !env.is_local(&name) => {
                if ctx.top_level_function_visibility.contains_key(&name) {
                    ctx.jobs_local_handlers.push((name, span));
                    return Ok(());
                }
                ctx.imported_function_origins
                    .contains_key(&name)
                    .then(|| env.lookup(&name))
                    .flatten()
            }
            _ => None,
        },
        Expr::FieldAccess(access) => match access.base() {
            Some(Expr::NameRef(base)) => base.text().and_then(|module| {
                if env.is_local(&module) || !ctx.qualified_module_origins.contains_key(&module) {
                    return None;
                }
                ctx.qualified_modules
                    .get(&module)?
                    .get(access.field()?.text())
            }),
            _ => None,
        },
        _ => None,
    };
    let scheme = scheme.cloned();
    if is_jobs_handler_type(ctx, scheme.as_ref()) {
        return Ok(());
    }

    let error = invalid_jobs_handler(span);
    ctx.errors.push(error.clone());
    Err(error)
}

fn is_jobs_handler_type(ctx: &mut InferCtx, scheme: Option<&Scheme>) -> bool {
    scheme.is_some_and(|scheme| {
        scheme.vars.is_empty() && ctx.resolve(scheme.ty.clone()) == jobs_handler_type()
    })
}

fn invalid_jobs_handler(span: TextRange) -> TypeError {
    TypeError::JobsStartInvalid {
        reason: "pass a named function with type fn(String) -> String as the handler",
        span,
    }
}

/// A call to a fn defined at more than one arity (`area(2)`, `Geo.area(2)`,
/// `x |> area(3)`, `x |> area`): the type of the arity `arg_count` names,
/// `name__N`, recorded as the target of the call at `call_range`. `None`
/// when the callee is no such fn.
fn infer_overloaded_callee(
    ctx: &mut InferCtx,
    env: &TypeEnv,
    callee_expr: &Expr,
    arg_count: usize,
    call_range: TextRange,
    types: &mut FxHashMap<TextRange, Ty>,
) -> Option<Ty> {
    let (scheme, mangled) = match callee_expr {
        Expr::NameRef(name_ref) => {
            let name = name_ref.text()?;
            // A local variable of that name is what the call means.
            if env.is_local(&name) {
                return None;
            }
            let mangled = format!("{name}__{arg_count}");
            (env.lookup(&mangled)?.clone(), mangled)
        }
        Expr::FieldAccess(fa) => {
            let Some(Expr::NameRef(module)) = fa.base() else {
                return None;
            };
            let mangled = format!("{}__{arg_count}", fa.field()?.text());
            let module = ctx.qualified_modules.get(&module.text()?)?;
            (module.get(&mangled)?.clone(), mangled)
        }
        _ => return None,
    };
    let ty = ctx.instantiate(&scheme);
    types.insert(callee_expr.syntax().text_range(), ty.clone());
    ctx.overloaded_call_targets.insert(call_range, mangled);
    Some(ty)
}

/// What an expression the parser could not complete (`1 +` with nothing
/// after it) checks as: given up on, with no error of its own, since its
/// parse error says what is wrong.
fn incomplete() -> TypeError {
    TypeError::Mismatch {
        expected: Ty::Never,
        found: Ty::Never,
        origin: ConstraintOrigin::Builtin,
    }
}

/// Infer a pipe, `lhs |> rhs` or `lhs |N> rhs` (`slot` N): a call of `rhs`
/// with `lhs` inserted among its arguments, first or at position N (the
/// end, when the call has fewer). A bare `rhs` (`x |> f`, `x |2> f` alike)
/// is called with `lhs` alone.
#[allow(clippy::too_many_arguments)]
fn infer_piped(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    lhs: Option<Expr>,
    rhs: Option<Expr>,
    slot: Option<u32>,
    pipe_range: TextRange,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &FxHashMap<String, FnConstraints>,
) -> Result<Ty, TypeError> {
    let lhs = lhs.ok_or_else(incomplete)?;
    let rhs = rhs.ok_or_else(incomplete)?;
    let index = slot.map_or(0, |slot| slot as usize - 1);

    // `x |> f(a)?` is `(x |> f(a))?`: `?` takes the result of the call the
    // value goes into (recorded at the `?`, whose value is the pipe's).
    if let Expr::TryExpr(try_expr) = &rhs {
        let span = try_expr.syntax().text_range();
        let piped = infer_piped(
            ctx,
            env,
            Some(lhs),
            try_expr.operand(),
            slot,
            span,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        )?;
        types.insert(span, piped.clone());
        return try_value(ctx, trait_registry, piped, span);
    }

    let lhs_ty = infer_expr(
        ctx,
        env,
        &lhs,
        types,
        type_registry,
        trait_registry,
        fn_constraints,
    )?;

    if let Expr::SendExpr(send) = &rhs {
        return infer_piped_send(
            ctx,
            env,
            send,
            lhs_ty,
            index,
            pipe_range,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        );
    }

    let lhs_range = lhs.syntax().text_range();
    let Expr::CallExpr(call) = &rhs else {
        let rhs_range = rhs.syntax().text_range();
        let piped = Some((lhs_range, 0, lhs_ty.clone()));
        // A bare `Node.spawn` is given the piped value alone, not the node
        // and the actor it needs: that is reported. Any other bare callee
        // is a function the value is passed to.
        infer_node_spawn(
            ctx,
            env,
            &rhs,
            &[],
            piped,
            pipe_range,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        )?;
        let callee_ty = match infer_overloaded_callee(ctx, env, &rhs, 1, rhs_range, types) {
            Some(ty) => ty,
            None => infer_expr(
                ctx,
                env,
                &rhs,
                types,
                type_registry,
                trait_registry,
                fn_constraints,
            )?,
        };
        return check_call(
            ctx,
            env,
            &rhs,
            callee_ty,
            &[],
            Some((&lhs, slot, lhs_ty)),
            rhs_range,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        );
    };

    let callee_expr = call.callee().ok_or_else(incomplete)?;
    if is_http_clustered_callee(&callee_expr) {
        let err = TypeError::HttpClusteredOutsideRouteHandlerPosition {
            span: call.syntax().text_range(),
        };
        ctx.errors.push(err.clone());
        return Err(err);
    }

    let args = call.args();
    let call_range = call.syntax().text_range();
    let piped = Some((lhs_range, index, lhs_ty.clone()));
    if let Some(ty) = infer_node_spawn(
        ctx,
        env,
        &callee_expr,
        &args,
        piped,
        pipe_range,
        types,
        type_registry,
        trait_registry,
        fn_constraints,
    )? {
        types.insert(call_range, ctx.resolve(ty.clone()));
        return Ok(ty);
    }
    let callee_ty =
        match infer_overloaded_callee(ctx, env, &callee_expr, args.len() + 1, call_range, types) {
            Some(ty) => ty,
            None => infer_expr(
                ctx,
                env,
                &callee_expr,
                types,
                type_registry,
                trait_registry,
                fn_constraints,
            )?,
        };

    if let (Some(slot), Ty::Fun(params, _)) = (slot, ctx.resolve(callee_ty.clone())) {
        if slot as usize > params.len() {
            let err = TypeError::SlotPipeOutOfRange {
                slot,
                // As written: `add`, or `String.length`, which was ``.
                fn_name: callee_expr.syntax().text().to_string().trim().to_string(),
                arity: params.len(),
                span: pipe_range,
            };
            ctx.errors.push(err.clone());
            return Err(err);
        }
    }

    let ty = check_call(
        ctx,
        env,
        &callee_expr,
        callee_ty,
        &args,
        Some((&lhs, slot, lhs_ty)),
        call_range,
        types,
        type_registry,
        trait_registry,
        fn_constraints,
    )?;
    // Recorded for MIR lowering, which lowers the call itself.
    types.insert(call_range, ctx.resolve(ty.clone()));
    Ok(ty)
}

/// Infer the type of an if expression.
fn infer_if(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    if_: &IfExpr,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &FxHashMap<String, FnConstraints>,
) -> Result<Ty, TypeError> {
    if let Some(cond) = if_.condition() {
        let cond_ty = infer_expr(
            ctx,
            env,
            &cond,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        )?;
        ctx.unify(
            Ty::bool(),
            cond_ty,
            ConstraintOrigin::Expr {
                span: cond.syntax().text_range(),
            },
        )?;
    }

    let then_ty = infer_body(
        ctx,
        env,
        if_.then_branch(),
        types,
        type_registry,
        trait_registry,
        fn_constraints,
    );

    if let Some(else_branch) = if_.else_branch() {
        let else_ty = if let Some(else_if) = else_branch.if_expr() {
            infer_if(
                ctx,
                env,
                &else_if,
                types,
                type_registry,
                trait_registry,
                fn_constraints,
            )?
        } else {
            infer_body(
                ctx,
                env,
                else_branch.block(),
                types,
                type_registry,
                trait_registry,
                fn_constraints,
            )
        };

        let origin = ConstraintOrigin::IfBranches {
            if_span: if_.syntax().text_range(),
            then_span: if_
                .then_branch()
                .map(|b| b.syntax().text_range())
                .unwrap_or_else(|| if_.syntax().text_range()),
            else_span: else_branch.syntax().text_range(),
        };
        ctx.unify(then_ty.clone(), else_ty.clone(), origin)?;
        // A then branch that never returns (`return`, `panic`) leaves the
        // else branch's type as the value of the whole `if`.
        let if_ty = if matches!(ctx.resolve(then_ty.clone()), Ty::Never) {
            else_ty
        } else {
            then_ty
        };

        // Store the resolved type for this if-expression so that codegen can
        // look it up via `resolve_range`.  Without this, recursive `infer_if`
        // calls (for `else if` chains) bypass `infer_expr` and never populate
        // the `types` map, causing codegen to fall back to `MirType::Unit`.
        types.insert(if_.syntax().text_range(), ctx.resolve(if_ty.clone()));

        Ok(if_ty)
    } else {
        // No else branch: the `if` has no value (the docs make `else`
        // optional only when the result is unused), whatever the then branch
        // produces.
        let _ = then_ty;
        let unit = Ty::Tuple(vec![]);
        types.insert(if_.syntax().text_range(), unit.clone());

        Ok(unit)
    }
}

/// Infer the type of a while expression: `while cond do body end`
///
/// The condition must be Bool. The body is inferred with loop_depth incremented.
/// While expressions always return Unit (WHILE-03).
fn infer_while(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    w: &WhileExpr,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &FxHashMap<String, FnConstraints>,
) -> Result<Ty, TypeError> {
    // Infer and unify condition with Bool.
    if let Some(cond) = w.condition() {
        let cond_ty = infer_expr(
            ctx,
            env,
            &cond,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        )?;
        ctx.unify(
            Ty::bool(),
            cond_ty,
            ConstraintOrigin::Expr {
                span: cond.syntax().text_range(),
            },
        )?;
    }

    // Infer body with incremented loop_depth.
    ctx.enter_loop();
    if let Some(body) = w.body() {
        let _ = infer_block(
            ctx,
            env,
            &body,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
            None,
        );
    }
    ctx.exit_loop();

    // While always returns Unit regardless of body type (WHILE-03).
    Ok(Ty::Tuple(vec![]))
}

/// Infer the type of a break expression.
///
/// Break is a control flow transfer -- type is Never.
/// Produces BreakOutsideLoop error if not inside a loop (BRKC-04).
fn infer_break(ctx: &mut InferCtx, b: &BreakExpr) -> Result<Ty, TypeError> {
    if !ctx.in_loop() {
        let span = b.syntax().text_range();
        ctx.errors.push(TypeError::BreakOutsideLoop { span });
    }
    Ok(Ty::Never)
}

/// Infer the type of a continue expression.
///
/// Continue is a control flow transfer -- type is Never.
/// Produces ContinueOutsideLoop error if not inside a loop (BRKC-04).
fn infer_continue(ctx: &mut InferCtx, c: &ContinueExpr) -> Result<Ty, TypeError> {
    if !ctx.in_loop() {
        let span = c.syntax().text_range();
        ctx.errors.push(TypeError::ContinueOutsideLoop { span });
    }
    Ok(Ty::Never)
}

/// Infer the type of a for-in expression: `for i in 0..10 do body end`
///
/// Handles range (DotDot), List<T>, Map<K,V>, and Set<T> iterables.
/// Binds loop variable(s) to the element type(s).
/// Returns List<body_ty> (comprehension semantics).
fn infer_for_in(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    for_in: &ForInExpr,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &FxHashMap<String, FnConstraints>,
) -> Result<Ty, TypeError> {
    // Infer the iterable expression.
    let iter_ty = if let Some(iterable) = for_in.iterable() {
        let ty = infer_expr(
            ctx,
            env,
            &iterable,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        )?;
        ctx.resolve(ty)
    } else {
        return Ok(Ty::Tuple(vec![]));
    };

    // A range written in place, `a..b`, iterates its integers (whose ends
    // its inference already made integers).
    let is_range = matches!(
        for_in.iterable(),
        Some(Expr::BinaryExpr(ref bin)) if bin.op().map(|t| t.kind()) == Some(SyntaxKind::DOT_DOT)
    );

    // Push a new scope for the loop variable(s).
    env.push_scope();

    // A pattern binding (`for (a, b) in pairs`) is checked like a `let`
    // pattern against the element type; a map yields `(key, value)`.
    let pattern = for_in.pattern();
    if let Some(pat) = &pattern {
        if let Err(error) = validate_let_destructuring_pattern(pat) {
            ctx.errors.push(error.clone());
            return Err(error);
        }
    }
    let mut bind = |ctx: &mut InferCtx, env: &mut TypeEnv, elem_ty: Ty| -> Result<(), TypeError> {
        match &pattern {
            Some(pat) => {
                let pat_ty = infer_pattern(ctx, env, pat, types, type_registry)?;
                ctx.unify(
                    pat_ty,
                    elem_ty,
                    ConstraintOrigin::LetBinding {
                        binding_span: pat.syntax().text_range(),
                    },
                )?;
            }
            // `{k, v}` takes a map's entries apart; this is not a map (the
            // names were left unbound, and every use was undefined).
            None if for_in.destructure_binding().is_some() => {
                let (key, value) = (ctx.fresh_var(), ctx.fresh_var());
                let span = for_in
                    .iterable()
                    .map(|e| e.syntax().text_range())
                    .unwrap_or_else(|| for_in.syntax().text_range());
                let _ = ctx.unify(
                    Ty::map(key.clone(), value.clone()),
                    iter_ty.clone(),
                    ConstraintOrigin::Expr { span },
                );
                let names = for_in
                    .destructure_binding()
                    .map(|destr| destr.names())
                    .unwrap_or_default();
                for (name, ty) in names.iter().zip([key, value]) {
                    if let Some(name) = name.text() {
                        env.insert(name, Scheme::mono(ty));
                    }
                }
            }
            None => {
                let var_name = for_in
                    .binding_name()
                    .and_then(|n| n.text())
                    .unwrap_or_else(|| "_".to_string());
                env.insert(var_name, Scheme::mono(elem_ty));
            }
        }
        Ok(())
    };

    if is_range {
        // Range iteration: bind loop variable as Int.
        bind(ctx, env, Ty::int())?;
    } else {
        // Collection iteration: detect type and bind accordingly.
        match extract_collection_elem_type(&iter_ty) {
            CollectionType::List(elem_ty) => {
                bind(ctx, env, elem_ty)?;
            }
            CollectionType::Map(key_ty, val_ty) if pattern.is_some() => {
                bind(ctx, env, Ty::Tuple(vec![key_ty, val_ty]))?;
            }
            CollectionType::Map(key_ty, val_ty) => {
                // Expect destructuring binding {k, v}.
                if let Some(destr) = for_in.destructure_binding() {
                    for (name, ty) in destr.names().iter().zip([key_ty, val_ty]) {
                        if let Some(name) = name.text() {
                            env.insert(name, Scheme::mono(ty));
                        }
                    }
                } else {
                    // Single binding over map: bind as Int (key) as fallback.
                    let var_name = for_in
                        .binding_name()
                        .and_then(|n| n.text())
                        .unwrap_or_else(|| "_".to_string());
                    env.insert(var_name, Scheme::mono(key_ty));
                }
            }
            CollectionType::Set(elem_ty) => {
                bind(ctx, env, elem_ty)?;
            }
            CollectionType::Unknown => {
                let resolved = ctx.resolve(iter_ty.clone());
                if let Ty::Var(_) = resolved {
                    // Nothing says what is iterated yet (an unannotated
                    // parameter): a list, the common case.
                    let elem_ty = ctx.fresh_var();
                    ctx.unify(
                        iter_ty.clone(),
                        Ty::list(elem_ty.clone()),
                        ConstraintOrigin::Builtin,
                    )
                    .expect("an unbound variable takes a list of a fresh one");
                    bind(ctx, env, elem_ty)?;
                } else {
                    // An Iterable (collection -> iterator) or an Iterator
                    // yields its Item; nothing else can be iterated.
                    let trait_name = ["Iterable", "Iterator"]
                        .into_iter()
                        .find(|trait_name| trait_registry.has_impl(trait_name, &resolved));
                    let Some(trait_name) = trait_name else {
                        let span = for_in
                            .iterable()
                            .map(|e| e.syntax().text_range())
                            .unwrap_or_else(|| for_in.syntax().text_range());
                        let err = trait_not_satisfied(
                            ctx,
                            resolved,
                            "Iterable".to_string(),
                            ConstraintOrigin::Expr { span },
                        );
                        ctx.errors.push(err.clone());
                        env.pop_scope();
                        return Err(err);
                    };
                    // An `Iter<T>` yields `T`: the impls of the iterator
                    // handles it unifies with name no element type.
                    let item_ty = match resolved.args_of("Iter") {
                        Some([elem]) => elem.clone(),
                        _ => trait_registry
                            .resolve_associated_type(trait_name, "Item", &resolved)
                            .unwrap_or_else(Ty::int),
                    };
                    bind(ctx, env, item_ty)?;
                }
            }
        }
    }

    // Enter loop context (enables break/continue validation).
    ctx.enter_loop();

    // Infer filter condition if present (FILT-01).
    if let Some(filter_expr) = for_in.filter() {
        let filter_ty = infer_expr(
            ctx,
            env,
            &filter_expr,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        )?;
        let origin = ConstraintOrigin::BinOp {
            op_span: filter_expr.syntax().text_range(),
        };
        ctx.unify(Ty::bool(), filter_ty, origin)?;
    }

    // Infer body -- its type becomes the List element type.
    let body_ty = infer_body(
        ctx,
        env,
        for_in.body(),
        types,
        type_registry,
        trait_registry,
        fn_constraints,
    );

    ctx.exit_loop();

    // Pop the loop variable scope.
    env.pop_scope();

    // For-in returns List<body_ty> (comprehension semantics).
    Ok(Ty::list(body_ty))
}

/// Helper enum for classifying collection iterable types.
enum CollectionType {
    List(Ty),
    Map(Ty, Ty),
    Set(Ty),
    Unknown,
}

/// Extract the element type from a collection type (List<T>, Map<K,V>, Set<T>).
fn extract_collection_elem_type(ty: &Ty) -> CollectionType {
    match ty {
        Ty::App(_, args) => match (ty.con_name(), args.as_slice()) {
            (Some("List"), [elem, ..]) => CollectionType::List(elem.clone()),
            (Some("Map"), [key, value, ..]) => CollectionType::Map(key.clone(), value.clone()),
            (Some("Set"), [elem, ..]) => CollectionType::Set(elem.clone()),
            _ => CollectionType::Unknown,
        },
        Ty::Con(tc) => match tc.name.as_str() {
            "List" => CollectionType::List(Ty::int()),
            "Map" => CollectionType::Map(Ty::int(), Ty::int()),
            _ => CollectionType::Unknown,
        },
        _ => CollectionType::Unknown,
    }
}

/// Infer the type of a closure expression: `fn (params) -> body end`
///
/// Handles three forms:
/// 1. Single-clause arrow: `fn x -> expr end` or `fn(x) -> expr end`
/// 2. Single-clause do/end: `fn x do stmts end`
/// 3. Multi-clause: `fn 0 -> "zero" | n -> to_string(n) end`
fn infer_closure(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    closure: &ClosureExpr,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &FxHashMap<String, FnConstraints>,
    expected_ty: Option<Ty>,
) -> Result<Ty, TypeError> {
    // Several clauses, a guard, or a parameter written as a pattern: the
    // arguments are matched against each clause.
    if closure.matches_arguments() {
        return infer_multi_clause_closure(
            ctx,
            env,
            closure,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
            expected_ty,
        );
    }

    let (expected_param_types, expected_return_ty) = match expected_ty.map(|ty| ctx.resolve(ty)) {
        Some(Ty::Fun(param_types, return_ty)) => (Some(param_types), Some(*return_ty)),
        _ => (None, None),
    };

    // Single-clause closure: existing path.
    env.push_scope();

    let mut param_types = Vec::new();

    if let Some(param_list) = closure.param_list() {
        for (param_idx, param) in param_list.params().enumerate() {
            let expected_param_ty = expected_param_types
                .as_ref()
                .and_then(|types| types.get(param_idx))
                .cloned();
            let param_ty = if let Some(ann) = param.type_annotation() {
                // Full resolution keeps generic arguments (`List<Int>`) and aliases.
                let annotated_ty = resolve_type_annotation(ctx, &ann, type_registry)
                    .unwrap_or_else(|| ctx.fresh_var());
                if let Some(expected_param_ty) = expected_param_ty {
                    ctx.unify(
                        annotated_ty.clone(),
                        expected_param_ty,
                        ConstraintOrigin::Builtin,
                    )?;
                }
                annotated_ty
            } else {
                expected_param_ty.unwrap_or_else(|| ctx.fresh_var())
            };
            if let Some(name_tok) = param.name() {
                let name_text = name_tok.text().to_string();
                env.insert(name_text, Scheme::mono(param_ty.clone()));
            }
            param_types.push(param_ty);
        }
    }

    // Reset loop_depth inside closure body (BRKC-05: break/continue cannot cross closure boundary).
    let saved_loop_depth = ctx.enter_closure();
    ctx.push_fn_return_type(expected_return_ty.clone());
    let body_ty = infer_body(
        ctx,
        env,
        closure.body(),
        types,
        type_registry,
        trait_registry,
        fn_constraints,
    );
    let returns = ctx.pop_fn_return_type();
    ctx.exit_closure(saved_loop_depth);
    let body_ty = join_returns(ctx, body_ty, returns)?;

    if let Some(expected_return_ty) = expected_return_ty {
        ctx.unify(
            expected_return_ty,
            body_ty.clone(),
            body_origin(closure.body()),
        )?;
    }

    env.pop_scope();

    Ok(Ty::Fun(param_types, Box::new(body_ty)))
}

/// Binds a clause's parameters to the function's parameter types: a
/// pattern's bindings, or a name, with the type an annotation declares
/// (`type_params` are the function's). Returns what the clause matches its
/// arguments with, for exhaustiveness: its one parameter's pattern, or a
/// tuple of several.
#[allow(clippy::too_many_arguments)]
fn bind_clause_params(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    param_list: Option<mesh_parser::ast::item::ParamList>,
    param_types: &[Ty],
    type_params: &FxHashMap<String, Ty>,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
) -> Result<AbsPat, TypeError> {
    let params: Vec<_> = param_list.iter().flat_map(|list| list.params()).collect();
    let patterns: Vec<Pattern> = params.iter().filter_map(|param| param.pattern()).collect();
    check_unique_binders(ctx, &patterns);

    let mut clause_pats = Vec::new();
    for (param, param_ty) in params.iter().zip(param_types) {
        if let Some(ann) = param.type_annotation() {
            let declared = match annotation_type_param(&ann, type_params) {
                Some(name) => Some(type_params[&name].clone()),
                None => resolve_type_annotation(ctx, &ann, type_registry)
                    .map(|ty| with_declared_type_params(&ty, type_params)),
            };
            if let Some(declared) = declared {
                ctx.unify(
                    param_ty.clone(),
                    declared,
                    ConstraintOrigin::Annotation {
                        annotation_span: ann.syntax().text_range(),
                    },
                )?;
            }
        }
        if let Some(pat) = param.pattern() {
            let pat_ty = infer_pattern(ctx, env, &pat, types, type_registry)?;
            ctx.unify(
                param_ty.clone(),
                pat_ty,
                ConstraintOrigin::Pattern {
                    pattern_span: pat.syntax().text_range(),
                },
            )?;
            clause_pats.push(ast_pattern_to_abstract(ctx, &pat, env, type_registry));
        } else {
            if let Some(name) = param.name() {
                env.insert(name.text().to_string(), Scheme::mono(param_ty.clone()));
            }
            clause_pats.push(AbsPat::Wildcard);
        }
    }
    Ok(match clause_pats.len() {
        0 => AbsPat::Wildcard,
        1 => clause_pats.remove(0),
        _ => AbsPat::Constructor {
            name: "Tuple".to_string(),
            type_name: "Tuple".to_string(),
            args: clause_pats,
        },
    })
}

/// Infer the type of a multi-clause closure.
///
/// Multi-clause closures like `fn 0 -> "zero" | n -> to_string(n) end` are
/// desugared during type inference: each clause is treated like a match arm.
/// The first clause's params/guard/body are direct children of CLOSURE_EXPR,
/// and subsequent clauses are CLOSURE_CLAUSE children.
fn infer_multi_clause_closure(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    closure: &ClosureExpr,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &FxHashMap<String, FnConstraints>,
    expected_ty: Option<Ty>,
) -> Result<Ty, TypeError> {
    // Get arity from the first clause's param list.
    let arity = closure
        .param_list()
        .map(|pl| pl.params().count())
        .unwrap_or(0);

    let (expected_param_types, expected_return_ty) = match expected_ty.map(|ty| ctx.resolve(ty)) {
        Some(Ty::Fun(param_types, return_ty)) => (Some(param_types), Some(*return_ty)),
        _ => (None, None),
    };

    // Use expected parameter types when available so clause bodies see concrete bindings.
    let param_types: Vec<Ty> = (0..arity)
        .map(|param_idx| {
            expected_param_types
                .as_ref()
                .and_then(|types| types.get(param_idx))
                .cloned()
                .unwrap_or_else(|| ctx.fresh_var())
        })
        .collect();

    // The first clause's params/guard/body are direct children of the
    // CLOSURE_EXPR; later clauses are CLOSURE_CLAUSE children.
    let clauses = std::iter::once((
        closure.param_list(),
        closure.guard(),
        closure.body(),
        closure.syntax().text_range(),
    ))
    .chain(closure.clauses().map(|clause| {
        (
            clause.param_list(),
            clause.guard(),
            clause.body(),
            clause.syntax().text_range(),
        )
    }))
    .collect::<Vec<_>>();

    let mut result_ty: Option<Ty> = None;
    let mut first_branch: Option<TextRange> = None;
    let mut arm_patterns: Vec<AbsPat> = Vec::new();
    let mut arm_has_guard: Vec<bool> = Vec::new();
    let mut arm_spans: Vec<TextRange> = Vec::new();

    for (param_list, guard, body, span) in clauses {
        let body_span = body
            .as_ref()
            .map_or(span, |body| body.syntax().text_range());
        env.push_scope();

        arm_patterns.push(bind_clause_params(
            ctx,
            env,
            param_list,
            &param_types,
            &FxHashMap::default(),
            types,
            type_registry,
        )?);
        arm_has_guard.push(guard.is_some());
        arm_spans.push(span);

        // Process guard expression if present.
        if let Some(guard_expr) = guard.and_then(|guard_clause| guard_clause.expr()) {
            let guard_ty = infer_expr(
                ctx,
                env,
                &guard_expr,
                types,
                type_registry,
                trait_registry,
                fn_constraints,
            )?;
            let _ = ctx.unify(
                Ty::bool(),
                guard_ty,
                ConstraintOrigin::Expr {
                    span: guard_expr.syntax().text_range(),
                },
            );
        }

        // Infer the body (reset loop_depth inside closure -- BRKC-05).
        let saved_loop_depth = ctx.enter_closure();
        ctx.push_fn_return_type(expected_return_ty.clone());
        let origin = body_origin(body.clone());
        let body_ty = infer_body(
            ctx,
            env,
            body,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        );
        let returns = ctx.pop_fn_return_type();
        ctx.exit_closure(saved_loop_depth);
        let body_ty = join_returns(ctx, body_ty, returns)?;

        if let Some(ref expected_return_ty) = expected_return_ty {
            ctx.unify(expected_return_ty.clone(), body_ty.clone(), origin)?;
        }

        // Unify body type with previous clauses.
        join_branch_ty(
            ctx,
            &mut result_ty,
            &mut first_branch,
            closure.syntax().text_range(),
            body_ty,
            body_span,
        )?;

        env.pop_scope();
    }

    // The clauses must cover every argument, as a case's arms must.
    let scrutinee_ty = match param_types.len() {
        0 => Ty::Tuple(vec![]),
        1 => param_types[0].clone(),
        _ => Ty::Tuple(param_types.clone()),
    };
    check_arm_coverage(
        ctx,
        &scrutinee_ty,
        &arm_patterns,
        &arm_has_guard,
        &arm_spans,
        closure.syntax().text_range(),
        type_registry,
        true,
    );

    let body_ty = result_ty.unwrap_or_else(|| Ty::Tuple(vec![]));

    Ok(Ty::Fun(param_types, Box::new(body_ty)))
}

/// The type of a body the parser may have found none of (`if b` cut off
/// before its `do`): unknown when it is missing, since its parse error says
/// what is wrong, where `()` mismatched what the body was to give.
fn infer_body(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    body: Option<Block>,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &FxHashMap<String, FnConstraints>,
) -> Ty {
    match body {
        Some(body) => infer_block(
            ctx,
            env,
            &body,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
            None,
        ),
        None => ctx.fresh_var(),
    }
}

/// Infer the type of a block.
fn infer_block(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    block: &Block,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &FxHashMap<String, FnConstraints>,
    tail_case_result: Option<&Ty>,
) -> Ty {
    // The block's value is its last expression's; a `let` last gives unit.
    let mut last_ty = Ty::Tuple(vec![]);
    let mut children = block.syntax().children().peekable();
    while let Some(child) = children.next() {
        if let Some(item) = Item::cast(child.clone()) {
            last_ty = Ty::Tuple(vec![]);
            let Some(let_) = nested_let(ctx, item) else {
                continue;
            };
            let nesting = ctx.nesting(env);
            if infer_let_binding(
                ctx,
                env,
                &let_,
                types,
                type_registry,
                trait_registry,
                fn_constraints,
            )
            .is_err()
            {
                ctx.restore(env, nesting);
            }
        } else if let Some(expr) = Expr::cast(child.clone()) {
            // An expression reported already has no known type, neither
            // the previous statement's nor unit.
            last_ty = infer_expr_with_case_result(
                ctx,
                env,
                &expr,
                types,
                type_registry,
                trait_registry,
                fn_constraints,
                tail_case_result.filter(|_| children.peek().is_none()),
            )
            .unwrap_or_else(|_| ctx.fresh_var());
        } else if child.kind() == SyntaxKind::ASSERT_RECEIVE_EXPR {
            // The test assertion `meshc test` expands; not defined elsewhere.
            let keyword = child
                .first_token()
                .map_or(child.text_range(), |token| token.text_range());
            ctx.errors
                .push(TypeError::AssertReceiveOutsideTest { span: keyword });
        }
    }
    last_ty
}

/// `item`, inside a function, as the `let` it has to be. Only `let` binds
/// there: a function, type, import or any other definition there was
/// accepted and then ignored (a call of a nested `fn` failed in code
/// generation, an `import` of no module compiled), and is reported.
fn nested_let(ctx: &mut InferCtx, item: Item) -> Option<LetBinding> {
    let keyword = match &item {
        Item::LetBinding(let_) => return Some(let_.clone()),
        Item::FnDef(_) => "fn",
        Item::ModuleDef(_) => "module",
        Item::ImportDecl(_) => "import",
        Item::FromImportDecl(_) => "from ... import",
        Item::StructDef(_) => "struct",
        Item::InterfaceDef(_) => "interface",
        Item::ImplDef(_) => "impl",
        Item::TypeAliasDef(_) | Item::SumTypeDef(_) => "type",
        Item::ActorDef(_) => "actor",
        Item::ServiceDef(_) => "service",
        Item::SupervisorDef(_) => "supervisor",
    };
    // The definition's first line, not all of it.
    let span = item
        .syntax()
        .descendants_with_tokens()
        .filter_map(|element| element.into_token())
        .filter(|token| !token.kind().is_trivia())
        .take_while(|token| token.kind() != SyntaxKind::NEWLINE)
        .map(|token| token.text_range())
        .reduce(|first, last| first.cover(last))
        .unwrap_or_else(|| item.syntax().text_range());
    ctx.errors
        .push(TypeError::NestedDefinition { keyword, span });
    None
}

/// Infer the type of a tuple expression.
fn infer_tuple(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    tuple: &TupleExpr,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &FxHashMap<String, FnConstraints>,
) -> Result<Ty, TypeError> {
    let mut elem_types = Vec::new();
    for elem in tuple.elements() {
        let ty = infer_expr(
            ctx,
            env,
            &elem,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        )?;
        elem_types.push(ty);
    }

    if elem_types.len() == 1 {
        Ok(elem_types.into_iter().next().unwrap())
    } else {
        Ok(Ty::Tuple(elem_types))
    }
}

// ── AST-to-Abstract Pattern Conversion (04-04) ────────────────────────

/// Convert an AST pattern to the abstract `Pat` used by the exhaustiveness algorithm.
///
/// Variable bindings become wildcards (they match anything). Literals, constructors,
/// and or-patterns are mapped directly to their abstract equivalents.
fn ast_pattern_to_abstract(
    ctx: &mut InferCtx,
    pat: &Pattern,
    env: &TypeEnv,
    type_registry: &TypeRegistry,
) -> AbsPat {
    match pat {
        Pattern::Wildcard(_) => AbsPat::Wildcard,
        Pattern::Ident(ident) => {
            // The name of a variant in scope is that variant (a nullary
            // one); any other name binds whatever it matches.
            let name = ident
                .name()
                .map(|t| t.text().to_string())
                .unwrap_or_default();
            match type_registry
                .lookup_variant(&name)
                .filter(|_| env.lookup(&name).is_some())
            {
                Some((sum_info, variant)) => AbsPat::Constructor {
                    type_name: sum_info.name.clone(),
                    args: vec![AbsPat::Wildcard; variant.fields.len()],
                    name,
                },
                None => AbsPat::Wildcard,
            }
        }
        Pattern::Literal(lit) => {
            let token = lit.token();
            let text = token.as_ref().map_or("", |t| t.text());
            let sign = if lit.is_negative() { "-" } else { "" };
            let literal = |value: String, ty| AbsPat::Literal { value, ty };
            match token.as_ref().map(|t| t.kind()) {
                Some(SyntaxKind::INT_LITERAL) => literal(format!("{sign}{text}"), AbsLitKind::Int),
                Some(SyntaxKind::FLOAT_LITERAL) => {
                    literal(format!("{sign}{text}"), AbsLitKind::Float)
                }
                Some(SyntaxKind::TRUE_KW | SyntaxKind::FALSE_KW) => {
                    literal(text.to_string(), AbsLitKind::Bool)
                }
                Some(SyntaxKind::STRING_START) => {
                    let content = lit
                        .syntax()
                        .children_with_tokens()
                        .filter_map(|child| child.into_token())
                        .filter(|t| t.kind() == SyntaxKind::STRING_CONTENT)
                        .map(|t| t.text().to_string())
                        .collect();
                    literal(content, AbsLitKind::String)
                }
                // An atom is its name at run time; like a string, it
                // takes a catch-all arm to be exhaustive.
                Some(SyntaxKind::ATOM_LITERAL) => {
                    literal(text.trim_start_matches(':').to_string(), AbsLitKind::String)
                }
                // `nil`, whose one value any pattern matches.
                _ => AbsPat::Wildcard,
            }
        }
        Pattern::Tuple(tuple_pat) => {
            let args: Vec<AbsPat> = tuple_pat
                .patterns()
                .map(|sub| ast_pattern_to_abstract(ctx, &sub, env, type_registry))
                .collect();
            AbsPat::Constructor {
                name: exhaustiveness::TUPLE.to_string(),
                type_name: exhaustiveness::TUPLE.to_string(),
                args,
            }
        }
        Pattern::Constructor(ctor_pat) => {
            // The type it belongs to, however it is named: `Shape.Circle`,
            // `Geo.Circle` (through the module that exports `Shape`), or
            // `Circle`.
            let name = constructor_lookup_name(ctx, ctor_pat);
            let type_name = variant_owner(type_registry, &name)
                .expect("the pattern was checked: it names a variant")
                .name
                .clone();
            let variant_name = name.rsplit('.').next().unwrap_or(&name).to_string();

            let args: Vec<AbsPat> = ctor_pat
                .fields()
                .map(|sub| ast_pattern_to_abstract(ctx, &sub, env, type_registry))
                .collect();

            AbsPat::Constructor {
                name: variant_name,
                type_name,
                args,
            }
        }
        // A struct is a type with one constructor, whose arguments are its
        // fields in declaration order.
        Pattern::Struct(struct_pat) => {
            // The struct the pattern was checked against, through any
            // aliases (`B` in `type B = A`, `type A = P`).
            let name = struct_pat.type_name().map(|name| name.text().to_string());
            let named = resolve_alias(
                ctx,
                Ty::Con(TyCon::new(name.unwrap_or_default())),
                type_registry,
            );
            let def = named
                .con_name()
                .and_then(|name| type_registry.lookup_struct(name))
                .expect("the pattern was checked: it names a struct");
            AbsPat::Constructor {
                name: def.name.clone(),
                type_name: def.name.clone(),
                args: def
                    .fields
                    .iter()
                    .map(|(field, _)| {
                        struct_pat
                            .fields()
                            .find(|f| f.name().is_some_and(|n| n.text() == field))
                            .and_then(|f| f.pattern())
                            .map(|sub| ast_pattern_to_abstract(ctx, &sub, env, type_registry))
                            .unwrap_or(AbsPat::Wildcard)
                    })
                    .collect(),
            }
        }
        Pattern::Or(or_pat) => {
            let alts: Vec<AbsPat> = or_pat
                .alternatives()
                .map(|alt| ast_pattern_to_abstract(ctx, &alt, env, type_registry))
                .collect();
            AbsPat::Or { alternatives: alts }
        }
        Pattern::As(as_pat) => {
            // For exhaustiveness, an as-pattern is equivalent to its inner pattern.
            as_pat.pattern().map_or(AbsPat::Wildcard, |inner| {
                ast_pattern_to_abstract(ctx, &inner, env, type_registry)
            })
        }
        Pattern::Cons(cons_pat) => {
            // `head :: tail` is the non-empty constructor of the list type.
            let mut lower = |sub: Option<Pattern>| {
                sub.map(|sub| ast_pattern_to_abstract(ctx, &sub, env, type_registry))
                    .unwrap_or(AbsPat::Wildcard)
            };
            AbsPat::Constructor {
                name: exhaustiveness::CONS.to_string(),
                type_name: exhaustiveness::LIST.to_string(),
                args: vec![lower(cons_pat.head()), lower(cons_pat.tail())],
            }
        }
        Pattern::List(list_pat) => {
            // `[a, b]` is `a :: b :: []`.
            let nil = AbsPat::Constructor {
                name: exhaustiveness::NIL.to_string(),
                type_name: exhaustiveness::LIST.to_string(),
                args: vec![],
            };
            list_pat
                .patterns()
                .collect::<Vec<_>>()
                .into_iter()
                .rev()
                .fold(nil, |tail, elem| AbsPat::Constructor {
                    name: exhaustiveness::CONS.to_string(),
                    type_name: exhaustiveness::LIST.to_string(),
                    args: vec![
                        ast_pattern_to_abstract(ctx, &elem, env, type_registry),
                        tail,
                    ],
                })
        }
    }
}

/// Convert a resolved scrutinee type to the abstract `TypeInfo` used by exhaustiveness.
fn type_to_type_info(ty: &Ty, type_registry: &TypeRegistry) -> AbsTypeInfo {
    if let Ty::Tuple(elems) = ty {
        return exhaustiveness::tuple_type_info(elems.len());
    }
    if ty.args_of(exhaustiveness::LIST).is_some() {
        return exhaustiveness::list_type_info();
    }
    if let Some(con) = ty.con() {
        let name = con.name.as_str();
        // Check if it's Bool.
        if name == "Bool" {
            return AbsTypeInfo::Bool;
        }

        // Check if it's a registered sum type.
        let sum_info = if con.indexed_origin.is_some() {
            type_registry.indexed_family(con)
        } else {
            type_registry.lookup_sum_type(name)
        };
        if let Some(sum_info) = sum_info {
            let variants: Vec<ConstructorSig> = sum_info
                .variants
                .iter()
                .filter(|variant| {
                    variant
                        .indexed
                        .as_ref()
                        .is_none_or(|indexed| indexed_variant_can_match(indexed, ty))
                })
                .map(|v| ConstructorSig {
                    name: v.name.clone(),
                    arity: v.fields.len(),
                })
                .collect();
            return AbsTypeInfo::SumType { variants };
        }
        if let Some(def) = type_registry.lookup_struct(name) {
            return struct_type_info(def);
        }
    }

    // Int, Float, String, or unknown -> infinite type.
    AbsTypeInfo::Infinite
}

/// A struct for exhaustiveness: one constructor with a field per argument.
fn struct_type_info(def: &StructDefInfo) -> AbsTypeInfo {
    AbsTypeInfo::SumType {
        variants: vec![ConstructorSig {
            name: def.name.clone(),
            arity: def.fields.len(),
        }],
    }
}

/// The sum type whose variant a constructor pattern's lookup name
/// (`Circle`, or `Shape.Circle`) names: none when it names no variant (a
/// struct, an actor, a service's helper).
fn variant_owner<'a>(type_registry: &'a TypeRegistry, name: &str) -> Option<&'a SumTypeDefInfo> {
    match name.rsplit_once('.') {
        Some((owner, variant)) => type_registry
            .lookup_sum_type(owner)
            .or_else(|| type_registry.indexed_family(&TyCon::new(owner)))
            .filter(|sum| sum.variants.iter().any(|v| v.name == variant)),
        None => type_registry.lookup_variant(name).map(|(sum, _)| sum),
    }
}

/// Build an exhaustiveness `TypeRegistry` from the infer `TypeRegistry`.
///
/// This populates the abstract type registry with all known sum types
/// so that nested pattern checking can look up inner types.
fn build_abs_type_registry(type_registry: &TypeRegistry) -> AbsTypeRegistry {
    let mut abs_reg = AbsTypeRegistry::new();

    for (name, sum_info) in &type_registry.sum_type_defs {
        let variants: Vec<ConstructorSig> = sum_info
            .variants
            .iter()
            .map(|v| ConstructorSig {
                name: v.name.clone(),
                arity: v.fields.len(),
            })
            .collect();
        abs_reg.register(name.clone(), AbsTypeInfo::SumType { variants });
    }

    for (name, def) in &type_registry.struct_defs {
        abs_reg.register(name.clone(), struct_type_info(def));
    }

    // Also register Bool for nested bool patterns, and lists for `::` patterns.
    abs_reg.register("Bool", AbsTypeInfo::Bool);
    abs_reg.register(exhaustiveness::LIST, exhaustiveness::list_type_info());

    abs_reg
}

/// Format an abstract pattern as a human-readable string for error messages.
fn format_abstract_pat(pat: &AbsPat, type_registry: &TypeRegistry) -> String {
    let format = |pat: &AbsPat| format_abstract_pat(pat, type_registry);
    match pat {
        AbsPat::Wildcard => "_".to_string(),
        AbsPat::Constructor {
            name,
            type_name,
            args,
        } => {
            let args_str: Vec<String> = args.iter().map(format).collect();
            if name == exhaustiveness::TUPLE {
                format!("({})", args_str.join(", "))
            } else if name == exhaustiveness::CONS {
                format!("{} :: {}", args_str[0], args_str[1])
            } else if let Some(def) = type_registry.lookup_struct(name).filter(|_| {
                // A top-level witness carries no type name; a variant may
                // share a struct's name.
                (type_name.is_empty() || name == type_name)
                    && type_registry.lookup_variant(name).is_none()
            }) {
                let fields: Vec<String> = def
                    .fields
                    .iter()
                    .zip(&args_str)
                    .map(|((field, _), arg)| format!("{field}: {arg}"))
                    .collect();
                format!("{name} {{ {} }}", fields.join(", "))
            } else if args.is_empty() {
                name.clone()
            } else {
                format!("{}({})", name, args_str.join(", "))
            }
        }
        AbsPat::Literal { value, .. } => value.clone(),
        AbsPat::Or { alternatives } => {
            let alts_str: Vec<String> = alternatives.iter().map(format).collect();
            alts_str.join(" | ")
        }
    }
}

/// Infer the type of a case/match expression.
///
/// After type-checking all arms, runs exhaustiveness and redundancy analysis.
/// Guarded arms are excluded from the exhaustiveness matrix (they may not match).
fn infer_case(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    case: &CaseExpr,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &FxHashMap<String, FnConstraints>,
    expected: Option<&Ty>,
) -> Result<Ty, TypeError> {
    let scrutinee_ty = if let Some(scrutinee) = case.scrutinee() {
        infer_expr(
            ctx,
            env,
            &scrutinee,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        )?
    } else {
        ctx.fresh_var()
    };

    let has_indexed_scrutinee = |ctx: &mut InferCtx| {
        ctx.resolve(scrutinee_ty.clone()).con().is_some_and(|con| {
            con.indexed_origin.is_some() && type_registry.indexed_family(con).is_some()
        })
    };
    let mut indexed_case = has_indexed_scrutinee(ctx);
    let expected = expected.filter(|_| indexed_case);

    let mut result_ty: Option<Ty> = None;
    let mut first_branch: Option<TextRange> = None;

    // Collect patterns and guard info for exhaustiveness checking.
    let mut arm_patterns: Vec<AbsPat> = Vec::new();
    let mut arm_has_guard: Vec<bool> = Vec::new();
    let mut arm_spans: Vec<TextRange> = Vec::new();

    for arm in case.arms() {
        // A preceding arm can have fixed an initially unknown scrutinee.
        indexed_case = indexed_case || has_indexed_scrutinee(ctx);
        let nesting = ctx.nesting(env);
        env.push_scope();
        if indexed_case {
            ctx.enter_level();
        }
        let branch = (|| {
            if let Some(pat) = arm.pattern() {
                check_unique_binders(ctx, std::slice::from_ref(&pat));
                let pat_ty = infer_pattern_with_scrutinee(
                    ctx,
                    env,
                    &pat,
                    types,
                    type_registry,
                    Some(&scrutinee_ty),
                )?;
                ctx.unify(
                    scrutinee_ty.clone(),
                    pat_ty,
                    ConstraintOrigin::Pattern {
                        pattern_span: pat.syntax().text_range(),
                    },
                )?;

                // Convert to abstract pattern for exhaustiveness.
                let abs_pat = ast_pattern_to_abstract(ctx, &pat, env, type_registry);
                arm_patterns.push(abs_pat);
            } else {
                arm_patterns.push(AbsPat::Wildcard);
            }

            // Check for guard expression.
            let has_guard = arm.guard().is_some();
            arm_has_guard.push(has_guard);
            arm_spans.push(arm.syntax().text_range());

            // A guard is any `Bool` expression, as a function clause's is.
            if let Some(guard_expr) = arm.guard() {
                let guard_ty = infer_expr(
                    ctx,
                    env,
                    &guard_expr,
                    types,
                    type_registry,
                    trait_registry,
                    fn_constraints,
                )?;
                let _ = ctx.unify(
                    Ty::bool(),
                    guard_ty,
                    ConstraintOrigin::Expr {
                        span: guard_expr.syntax().text_range(),
                    },
                );
            }

            let body_ty = match (arm.body(), arm.pattern()) {
                (Some(body), _) => Some(infer_expr(
                    ctx,
                    env,
                    &body,
                    types,
                    type_registry,
                    trait_registry,
                    fn_constraints,
                )?),
                (None, Some(pat)) if arm.is_pass_through() => {
                    Some(infer_rebuilt_pattern(ctx, env, &pat)?)
                }
                _ => None,
            };
            let Some(body_ty) = body_ty else {
                return Ok(None);
            };
            let branch_span = arm
                .body()
                .map(|body| body.syntax().text_range())
                .unwrap_or_else(|| arm.syntax().text_range());
            let body_ty = if let Some(expected) = expected {
                ctx.unify(
                    expected.clone(),
                    body_ty,
                    ConstraintOrigin::Expr { span: branch_span },
                )?;
                expected.clone()
            } else if indexed_case {
                // Preserve what each branch proved about its own result.
                // Its equations cannot be used to check any other branch.
                ctx.resolve(body_ty)
            } else {
                body_ty
            };
            Ok(Some((body_ty, branch_span)))
        })();
        ctx.restore(env, nesting);

        if let Some((body_ty, branch_span)) = branch? {
            if expected.is_some() {
                result_ty = Some(body_ty);
                continue;
            }
            if indexed_case {
                ctx.close_arm_type(&body_ty, branch_span)?;
            }
            join_branch_ty(
                ctx,
                &mut result_ty,
                &mut first_branch,
                case.syntax().text_range(),
                body_ty,
                branch_span,
            )?;
        }
    }

    check_arm_coverage(
        ctx,
        &scrutinee_ty,
        &arm_patterns,
        &arm_has_guard,
        &arm_spans,
        case.syntax().text_range(),
        type_registry,
        false,
    );

    Ok(result_ty.unwrap_or_else(|| Ty::Tuple(vec![])))
}

/// Merge one branch's type into the type of a multi-branch expression at
/// `whole` (`case`, `receive`, clauses). A branch that never returns
/// (`return`, `panic`) is `Never`, which unifies with anything but must not
/// become the type of the whole expression. A branch that disagrees is
/// reported at itself and at `first`, the branch that set the type.
fn join_branch_ty(
    ctx: &mut InferCtx,
    joined: &mut Option<Ty>,
    first: &mut Option<TextRange>,
    whole: TextRange,
    branch: Ty,
    span: TextRange,
) -> Result<(), TypeError> {
    match joined {
        Some(prev) => {
            let origin = ConstraintOrigin::IfBranches {
                if_span: whole,
                then_span: first.unwrap_or(whole),
                else_span: span,
            };
            ctx.unify(prev.clone(), branch.clone(), origin)?;
            if matches!(ctx.resolve(prev.clone()), Ty::Never) {
                *prev = branch;
                *first = Some(span);
            }
        }
        None => {
            *joined = Some(branch);
            *first = Some(span);
        }
    }
    Ok(())
}

/// Report a `case` or `receive` that misses values of the scrutinee type, and
/// warn about arms that earlier arms already cover.
///
/// Missing values are an error for a `case` or `receive`, and a warning for
/// function or closure `clauses` (a call no clause matches panics).
#[allow(clippy::too_many_arguments)]
fn check_arm_coverage(
    ctx: &mut InferCtx,
    scrutinee_ty: &Ty,
    arm_patterns: &[AbsPat],
    arm_has_guard: &[bool],
    arm_spans: &[TextRange],
    span: TextRange,
    type_registry: &TypeRegistry,
    clauses: bool,
) {
    let resolved_scrutinee = ctx.resolve(scrutinee_ty.clone());
    let scrutinee_type_info = type_to_type_info(&resolved_scrutinee, type_registry);
    let abs_registry = build_abs_type_registry(type_registry);

    // For exhaustiveness: exclude guarded arms (they may not match).
    let unguarded_patterns: Vec<AbsPat> = arm_patterns
        .iter()
        .zip(arm_has_guard.iter())
        .filter(|(_, has_guard)| !**has_guard)
        .map(|(pat, _)| pat.clone())
        .collect();

    if let Some(witnesses) = exhaustiveness::check_exhaustiveness(
        &unguarded_patterns,
        &scrutinee_type_info,
        &abs_registry,
    ) {
        let missing: Vec<String> = witnesses
            .iter()
            .map(|pat| format_abstract_pat(pat, type_registry))
            .collect();
        let scrutinee_type = resolved_scrutinee.with_holes().to_string();
        if clauses {
            ctx.warnings.push(TypeError::NonExhaustiveClauses {
                scrutinee_type,
                missing_patterns: missing,
                span,
            });
        } else {
            ctx.errors.push(TypeError::NonExhaustiveMatch {
                scrutinee_type,
                missing_patterns: missing,
                span,
            });
        }
    }

    // For redundancy: check all arms; guarded arms cover nothing for later ones.
    let redundant_indices = exhaustiveness::check_redundancy(
        arm_patterns,
        arm_has_guard,
        &scrutinee_type_info,
        &abs_registry,
    );
    for idx in redundant_indices {
        let warn = TypeError::RedundantArm {
            arm_index: idx,
            span: arm_spans.get(idx).copied().unwrap_or(span),
        };
        ctx.warnings.push(warn);
    }
}

/// Infer the type of a return expression.
fn infer_return(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    ret: &ReturnExpr,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &FxHashMap<String, FnConstraints>,
) -> Result<Ty, TypeError> {
    let value_ty = match ret.value() {
        Some(value) => infer_expr(
            ctx,
            env,
            &value,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        )?,
        None => Ty::Tuple(vec![]),
    };
    // The value is what the function returns: checked against a declared
    // return type now, or joined with the body's type when the function ends.
    match ctx.current_fn_return_type().cloned() {
        Some(declared) => {
            let origin = ConstraintOrigin::Expr {
                span: ret.syntax().text_range(),
            };
            let _ = ctx.unify(declared, value_ty, origin);
        }
        None => ctx.record_return(EarlyReturn {
            ty: value_ty,
            span: ret.syntax().text_range(),
            try_operand: None,
        }),
    }
    Ok(Ty::Never)
}

/// The type a function body produces, given the types of its `return`
/// values when no return type was declared: all must agree.
fn join_returns(
    ctx: &mut InferCtx,
    body_ty: Ty,
    returns: Vec<EarlyReturn>,
) -> Result<Ty, TypeError> {
    let mut joined = body_ty;
    for early in returns {
        join_early_return(ctx, &mut joined, early)?;
    }
    Ok(joined)
}

/// Join an early return with the other results of its function, reporting
/// a conflict where the return is.
fn join_early_return(
    ctx: &mut InferCtx,
    joined: &mut Ty,
    early: EarlyReturn,
) -> Result<(), TypeError> {
    let prev = joined.clone();
    let errors = ctx.errors.len();
    let origin = ConstraintOrigin::Expr { span: early.span };
    match (
        ctx.unify(prev.clone(), early.ty.clone(), origin),
        early.try_operand,
    ) {
        (Ok(()), _) => {
            if matches!(ctx.resolve(prev), Ty::Never) {
                *joined = early.ty;
            }
            Ok(())
        }
        (Err(_), Some(operand_ty)) => {
            ctx.errors.truncate(errors);
            let err = TypeError::TryIncompatibleReturn {
                operand_ty,
                fn_return_ty: ctx.resolve(prev),
                span: early.span,
            };
            ctx.errors.push(err.clone());
            Err(err)
        }
        (Err(err), None) => Err(err),
    }
}

// ── Method Resolution (30-01) ──────────────────────────────────────────

/// Build the full function type for a trait method, including the self parameter.
/// Returns `Ty::Fun([self_type, ...param_types], return_type)`.
///
/// Uses the matching impl's method signature for the given self type, and
/// its `param_count` to create fresh type variables for non-self parameters
/// no declaration gives a type. The caller found the method's return type
/// in that impl.
fn build_method_fn_type(
    trait_registry: &TraitRegistry,
    method_name: &str,
    self_ty: &Ty,
    ret_ty: &Ty,
    ctx: &mut InferCtx,
) -> Ty {
    let method_sig = trait_registry
        .find_method_sig(method_name, self_ty)
        .expect("the impl that gave the method's return type provides the method");
    let mut param_types = vec![self_ty.clone()]; // self parameter
                                                 // The impl's declared parameter types check the arguments; a derived
                                                 // or built-in impl declares none, and takes what its interface
                                                 // declares, `Self` being the receiver's type (`eq` takes another
                                                 // value of it, which it compared with whatever it was given).
    let declared = method_sig.param_types.clone().or_else(|| {
        let trait_name = trait_registry
            .find_method_traits(method_name, self_ty)
            .into_iter()
            .next()?;
        let method = trait_registry
            .get_trait(&trait_name)?
            .methods
            .iter()
            .find(|method| method.name == method_name)?;
        let self_as_receiver =
            |ty: &Ty| ty.replace_cons(&mut |tc| (tc.name == "Self").then(|| self_ty.clone()));
        Some(
            method
                .param_types
                .as_ref()?
                .iter()
                .map(self_as_receiver)
                .collect(),
        )
    });
    match declared {
        Some(declared) if declared.len() == method_sig.param_count => param_types.extend(declared),
        _ => {
            for _ in 0..method_sig.param_count {
                param_types.push(ctx.fresh_var());
            }
        }
    }
    Ty::Fun(param_types, Box::new(ret_ty.clone()))
}

// ── Struct/Field Inference (03-03) ─────────────────────────────────────

/// Infer the type of a field access expression: `expr.field_name`, or of
/// the method it names when `is_method_call`. `base_ty` is the base's type
/// when it has been inferred already.
#[allow(clippy::too_many_arguments)]
fn infer_field_access(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    fa: &FieldAccess,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &FxHashMap<String, FnConstraints>,
    is_method_call: bool,
    base_ty: Option<Ty>,
) -> Result<Ty, TypeError> {
    let base_expr = fa.base().ok_or_else(incomplete)?;

    let field = fa.field().ok_or_else(incomplete)?;
    let field_span = field.text_range();
    let field_name = field.text().to_string();

    // Check if base is a NameRef pointing to a module name for qualified access.
    // e.g. Vector.add (user module), String.length (stdlib) -- module-qualified function reference.
    let qualifier = match &base_expr {
        Expr::NameRef(name_ref) => name_ref.text(),
        _ => None,
    };
    if let Some(base_name) = qualifier {
        if base_name == "Continuity" && field_name == "promote" {
            let err = TypeError::ManualContinuityPromotionDisabled {
                span: fa.syntax().text_range(),
            };
            ctx.errors.push(err.clone());
            return Err(err);
        }

        // An imported module's function or struct (or a service's
        // helper), then one of the module's variants.
        if let Some(scheme) = ctx
            .qualified_modules
            .get(&base_name)
            .and_then(|functions| functions.get(&field_name))
            .cloned()
        {
            if scheme.ty.is_callable_theorem() {
                return Err(theorem_requires_application(ctx, fa.syntax().text_range()));
            }
            return Ok(ctx.instantiate(&scheme));
        }
        if let Some(scheme) = module_variant(ctx, &base_name, &field_name)
            .and_then(|qualified| env.lookup(&qualified).cloned())
        {
            return Ok(ctx.instantiate(&scheme));
        }

        if field_name == "monitor"
            && matches!(base_name.as_str(), "Process" | "Node")
            && env.lookup(&base_name).is_none()
        {
            return monitor_type(ctx, env, &base_name, fa.syntax().text_range());
        }

        // A standard module's function (`String.length`).
        if let Some(scheme) = stdlib_modules(ctx.test_builtins)
            .get(&base_name)
            .and_then(|functions| functions.get(&field_name))
        {
            if base_name == "Jobs"
                && matches!(field_name.as_str(), "start" | "start_effects" | "drain")
            {
                ctx.jobs_runner_references
                    .entry(fa.syntax().text_range())
                    .or_default();
            }
            return Ok(ctx.instantiate(scheme));
        }

        // `Node.spawn` takes any number of arguments after the node and
        // the actor, which no function type says: it is checked where it
        // is called or piped into, and is no value.
        if is_node_spawn(env, fa) {
            let err = TypeError::ArityMismatch {
                expected: 2,
                found: 0,
                origin: ConstraintOrigin::Expr {
                    span: fa.syntax().text_range(),
                },
            };
            ctx.errors.push(err.clone());
            return Err(err);
        }

        // A service's helper (`Counter.get_count`), a variant
        // (`Shape.Circle`) or a schema function (`User.__table__`): each
        // is in the environment under its qualified name.
        if let Some(scheme) = env.lookup(&format!("{base_name}.{field_name}")) {
            return Ok(ctx.instantiate(scheme));
        }

        // Check if base is a struct type name with a static trait method.
        // e.g. User.from_json -- User is a struct type, from_json is a FromJson method.
        // `Iface.method(value, ...)`: the interface's method, for a
        // receiver that must implement it (checked when the function is
        // done), which names the method when several interfaces share it.
        if !env.is_local(&base_name) {
            if let Some(sig) = trait_registry.get_trait(&base_name).and_then(|trait_def| {
                trait_def
                    .methods
                    .iter()
                    .find(|m| m.name == field_name && m.has_self)
                    .cloned()
            }) {
                let receiver = ctx.fresh_var();
                let method_ty = trait_method_type(ctx, &base_name, &sig, &receiver);
                ctx.operand_traits.push((
                    receiver,
                    base_name.clone(),
                    ConstraintOrigin::Expr {
                        span: fa.syntax().text_range(),
                    },
                ));
                return Ok(method_ty);
            }
        }

        // A type's derived functions: `from_json` :: String -> Result<T,
        // String>, where a generic T is instantiated afresh
        // (`Box.from_json` gives `Box<_>`), and a struct's `from_row`.
        let named = Ty::Con(TyCon::new(&base_name));
        if field_name == "from_json" {
            if let Some(params) = declared_param_count(type_registry, &base_name) {
                let decoded = with_unknown_args(ctx, named.clone(), params);
                if trait_registry.has_impl("FromJson", &named)
                    || trait_registry.has_impl("FromJson", &decoded)
                {
                    // A generic type decodes at the instantiation asked for,
                    // which JSON must hold too (`Box<Point>` needs a Point
                    // deriving Json): checked once it is known, as
                    // `Json.encode`'s argument is.
                    if params > 0 {
                        let span = fa.syntax().text_range();
                        ctx.operand_traits.push((
                            decoded.clone(),
                            "Json".to_string(),
                            ConstraintOrigin::Expr { span },
                        ));
                        ctx.open_decodes.push((decoded.clone(), span));
                    }
                    let result_ty = Ty::result(decoded, Ty::string());
                    return Ok(Ty::fun(vec![Ty::string()], result_ty));
                }
            }
        }

        if field_name == "from_row"
            && type_registry.lookup_struct(&base_name).is_some()
            && trait_registry.has_impl("FromRow", &named)
        {
            // from_row :: Map<String, String> -> Result<StructName, String>
            let map_ty = Ty::map(Ty::string(), Ty::string());
            let result_ty = Ty::result(named, Ty::string());
            return Ok(Ty::fun(vec![map_ty], result_ty));
        }

        if !env.is_local(&base_name) && is_named_type(type_registry, &base_name) {
            return type_qualified_method(
                ctx,
                type_registry,
                trait_registry,
                &base_name,
                &field_name,
                fa.syntax().text_range(),
                field_span,
            );
        }

        // A module without the function: say so, instead of
        // "undefined variable" for the module's name. A type named like
        // a module (`Int.tag()` for `impl Named for Int`) may provide
        // the name as a static method, which the call resolves.
        let static_method = trait_registry
            .impls_with_static_method(&field_name)
            .iter()
            .any(|imp| imp.impl_type_name == base_name);
        let module_functions: Option<Vec<String>> = if env.is_local(&base_name) || static_method {
            None
        } else if let Some(functions) = ctx.qualified_modules.get(&base_name) {
            Some(listed_names(functions.keys()))
        } else {
            stdlib_modules(ctx.test_builtins)
                .get(&base_name)
                .map(|functions| listed_names(functions.keys()))
        };
        if let Some(available) = module_functions {
            let err = TypeError::NoSuchModuleFunction {
                module: base_name,
                name: field_name,
                available,
                span: fa.syntax().text_range(),
            };
            ctx.errors.push(err.clone());
            return Err(err);
        }
    }

    let base_ty = match base_ty {
        Some(base_ty) => base_ty,
        None => infer_expr(
            ctx,
            env,
            &base_expr,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        )?,
    };
    ctx.field_base = Some((fa.syntax().text_range(), base_ty.clone()));
    let resolved_base = ctx.resolve(base_ty);

    // Inside an interface's default method `self` has the type `Self`: its
    // methods are the interface's own signatures (implemented later, per type).
    if is_method_call {
        if let (Ty::Con(tc), Some(iface)) = (&resolved_base, ctx.current_interface.clone()) {
            if tc.name == "Self" {
                if let Some(sig) = trait_registry
                    .get_trait(&iface)
                    .and_then(|def| def.methods.iter().find(|m| m.name == field_name))
                {
                    return Ok(trait_method_type(ctx, &iface, sig, &resolved_base));
                }
            }
        }
    }

    if let Some(name) = resolved_base.con_name() {
        if let Some(struct_info) = type_registry.lookup_struct(name) {
            let struct_info = struct_info.clone();
            // Get the type arguments from the resolved base type.
            let type_args = match &resolved_base {
                Ty::App(_, args) => args.clone(),
                _ => vec![],
            };
            for (fname, fty) in &struct_info.fields {
                if *fname == field_name {
                    // Substitute generic params with actual type args.
                    let resolved_field =
                        substitute_type_params(fty, &struct_info.generic_params, &type_args);
                    return Ok(resolved_field);
                }
            }
            // Not a field: a method, as of any type, when it is called.
            if !is_method_call {
                let err = TypeError::NoSuchField {
                    suggestion: closest_name(
                        &field_name,
                        struct_info.fields.iter().map(|(name, _)| name.as_str()),
                    ),
                    ty: resolved_base,
                    field_name,
                    span: field_span,
                };
                ctx.errors.push(err.clone());
                return Err(err);
            }
        }
    }

    // Base type is not a struct (or no struct def found).
    // A method of a type parameter comes from a trait its `where` clause
    // names: `x.size()` under `where T: Sized` has `Sized.size`'s type. As a
    // plain field access it is no field, which sends the call to method
    // resolution.
    let mut bound_methods = Vec::new();
    for (param_ty, trait_name) in ctx.where_bounds.clone() {
        if ctx.resolve(param_ty) != resolved_base {
            continue;
        }
        if let Some(def) = trait_registry.get_trait(&trait_name) {
            if let Some(sig) = def.methods.iter().find(|m| m.name == field_name) {
                if !is_method_call {
                    let err = TypeError::NoSuchField {
                        ty: resolved_base,
                        field_name,
                        span: field_span,
                        suggestion: None,
                    };
                    ctx.errors.push(err.clone());
                    return Err(err);
                }
                return Ok(trait_method_type(ctx, &trait_name, sig, &resolved_base));
            }
            if is_method_call {
                bound_methods.extend(def.methods.iter().map(|m| m.name.as_str()));
            }
        }
    }
    // A declared type parameter stands for any type: it has no fields, and
    // no methods but its bounds'. Its fields were left for later, when no
    // type could give it one ("cannot tell which type has the field").
    if let Ty::Var(v) = resolved_base {
        if let Some(param) = ctx.rigid_param_name(v) {
            let ty = Ty::Con(TyCon::new(&param));
            let err = if is_method_call {
                TypeError::NoSuchMethod {
                    suggestion: closest_name(&field_name, bound_methods),
                    ty,
                    method_name: field_name,
                    span: field_span,
                }
            } else {
                TypeError::NoSuchField {
                    ty,
                    field_name,
                    span: field_span,
                    suggestion: None,
                }
            };
            ctx.errors.push(err.clone());
            return Err(err);
        }
    }

    if is_method_call {
        let matching_traits = trait_registry.find_method_traits(&field_name, &resolved_base);
        if matching_traits.len() > 1 {
            let err = TypeError::AmbiguousMethod {
                method_name: field_name.clone(),
                candidate_traits: matching_traits,
                ty: resolved_base.clone(),
                span: fa.syntax().text_range(),
            };
            ctx.errors.push(err.clone());
            return Err(err);
        }
        // An `Iter<T>` pipeline's methods are the typed `Iter` functions
        // (`it.next()` is `Iter.next(it)`): the untyped built-in `Iterator`
        // impl of the handle behind it would otherwise answer.
        if resolved_base.args_of("Iter").is_some() {
            if let Some(scheme) = stdlib_modules(ctx.test_builtins)
                .get("Iter")
                .and_then(|module| module.get(&field_name))
            {
                return Ok(ctx.instantiate(scheme));
            }
        }
        if let Some(ret_ty) = method_return_type(
            ctx,
            trait_registry,
            &field_name,
            &resolved_base,
            fa.syntax().text_range(),
        ) {
            let method_fn_ty =
                build_method_fn_type(trait_registry, &field_name, &resolved_base, &ret_ty, ctx);
            return Ok(method_fn_ty);
        }

        // ── Stdlib module method fallback (Phase 31) ──────────────────
        // After trait method resolution fails, check if the method name
        // matches a stdlib module function for the receiver type.
        // e.g. "hello".length() -> String.length(str), my_list.length() -> List.length(list)
        // (Every module method_module names is a standard module.)
        if let Some(scheme) = method_module(&resolved_base).and_then(|module| {
            stdlib_modules(ctx.test_builtins)
                .get(module)?
                .get(&field_name)
                .cloned()
        }) {
            return Ok(ctx.instantiate(&scheme));
        }

        // An impl provides the method, but nothing fixed what it returns.
        let err = if matching_traits.is_empty() {
            let modules = stdlib_modules(ctx.test_builtins);
            let module_methods = method_module(&resolved_base)
                .and_then(|module| modules.get(module))
                .into_iter()
                .flat_map(|module| module.keys().map(String::as_str));
            let default_methods = ctx
                .current_interface
                .as_deref()
                .filter(|_| resolved_base.con_name() == Some("Self"))
                .and_then(|name| trait_registry.get_trait(name))
                .into_iter()
                .flat_map(|def| def.methods.iter().map(|method| method.name.as_str()));
            let suggestion = closest_name(
                &field_name,
                trait_registry
                    .method_names_for(&resolved_base)
                    .chain(module_methods)
                    .chain(default_methods)
                    .chain(bound_methods),
            );
            TypeError::NoSuchMethod {
                ty: resolved_base,
                method_name: field_name,
                span: field_span,
                suggestion,
            }
        } else {
            TypeError::MethodReturnUnknown {
                method: field_name,
                ty: resolved_base,
                span: fa.syntax().text_range(),
            }
        };
        ctx.errors.push(err.clone());
        return Err(err);
    }

    // ── Non-struct concrete type NoSuchField (Phase 31) ──────────────
    // For known concrete non-struct types (Ty::Con, Ty::App), return
    // Err(NoSuchField) to trigger the retry mechanism in infer_call.
    // Only return Ok(fresh_var) for truly unresolved types (Ty::Var).
    match resolved_base.con_name() {
        // A type already reported unknown has no fields to check.
        Some(name) if ctx.unknown_types.contains(name) => return Ok(ctx.fresh_var()),
        Some(_) => {
            let err = TypeError::NoSuchField {
                ty: resolved_base,
                field_name,
                span: field_span,
                suggestion: None,
            };
            ctx.errors.push(err.clone());
            return Err(err);
        }
        None => {} // Ty::Var, Ty::Fun, etc. -- leave as fresh_var for unresolved types
    }

    // The value's type may be fixed later in the function (a closure's
    // parameter by its call); the field is looked up then.
    let result = ctx.fresh_var();
    if is_type_var(&resolved_base) && !is_method_call {
        ctx.pending_fields.push(PendingField {
            base: resolved_base,
            field: field_name,
            result: result.clone(),
            span: field_span,
        });
    }
    Ok(result)
}

/// Whether `<>`/`++` joins values of type `ty`: strings or lists.
fn is_concatenable(ty: &Ty) -> bool {
    matches!(ty.con_name(), Some("String" | "List"))
}

/// Check the operands of `<>`/`++` whose type was unknown when they were
/// checked, now that the function is done, and return those still unknown.
/// A declared type parameter stands for any type, so it cannot be joined.
fn check_concat_operands(
    ctx: &mut InferCtx,
    operands: Vec<(Ty, &'static str, TextRange)>,
    type_params: &FxHashMap<String, Ty>,
) -> Vec<(Ty, &'static str, TextRange)> {
    let mut unresolved = Vec::new();
    for (ty, op, span) in operands {
        let resolved = ctx.resolve(ty);
        let param = type_params
            .iter()
            .find(|(_, param)| ctx.resolve((*param).clone()) == resolved)
            .map(|(name, _)| name.clone());
        let offending = match (&resolved, param) {
            (_, Some(name)) => Some(Ty::Con(TyCon::new(name))),
            (Ty::Var(_), None) => {
                unresolved.push((resolved, op, span));
                None
            }
            (other, None) if !is_concatenable(other) => Some(other.clone()),
            _ => None,
        };
        if let Some(ty) = offending {
            ctx.errors.push(TypeError::InvalidConcat { op, ty, span });
        }
    }
    unresolved
}

/// The type a non-generic function declares with every parameter and its
/// result annotated, or `None` when inference has to find part of it.
fn declared_signature(ctx: &mut InferCtx, fn_: &FnDef, type_registry: &TypeRegistry) -> Option<Ty> {
    let generic = fn_
        .syntax()
        .children()
        .any(|n| n.kind() == SyntaxKind::GENERIC_PARAM_LIST);
    if generic {
        return None;
    }
    let mut params = Vec::new();
    if let Some(list) = fn_.param_list() {
        for param in list.params() {
            let ann = param.type_annotation()?;
            params.push(resolve_type_annotation(ctx, &ann, type_registry)?);
        }
    }
    let ret = resolve_type_annotation(ctx, &fn_.return_type()?, type_registry)?;
    Some(Ty::Fun(params, Box::new(ret)))
}

/// Resolve the field reads `pending` from values whose type was unknown
/// when they were checked, and return those whose type is still unknown:
/// a function called before its definition fixes it only later. At the
/// module's end (`last`), a value whose type is still unknown cannot be
/// compiled (its layout is not known): the program must annotate it.
fn resolve_pending_fields(
    ctx: &mut InferCtx,
    type_registry: &TypeRegistry,
    pending: Vec<PendingField>,
    last: bool,
) -> Vec<PendingField> {
    let mut unresolved = Vec::new();
    for PendingField {
        base,
        field,
        result,
        span,
    } in pending
    {
        let base = ctx.resolve(base);
        if let Ty::Var(_) = base {
            if last {
                ctx.errors
                    .push(TypeError::UnknownFieldOwner { field, span });
            } else {
                unresolved.push(PendingField {
                    base,
                    field,
                    result,
                    span,
                });
            }
            continue;
        }
        // Only a struct has fields: a tuple or a function had none checked.
        let args = match &base {
            Ty::App(_, args) => args.as_slice(),
            _ => &[],
        };
        let struct_info = base
            .con_name()
            .and_then(|name| type_registry.lookup_struct(name));
        let field_ty = struct_info.and_then(|info| {
            info.fields
                .iter()
                .find(|(name, _)| *name == field)
                .map(|(_, ty)| substitute_type_params(ty, &info.generic_params, args))
        });
        match field_ty {
            Some(field_ty) => {
                let _ = ctx.unify(field_ty, result, ConstraintOrigin::Expr { span });
            }
            None => ctx.errors.push(TypeError::NoSuchField {
                suggestion: struct_info.and_then(|info| {
                    closest_name(&field, info.fields.iter().map(|(name, _)| name.as_str()))
                }),
                ty: base,
                field_name: field,
                span,
            }),
        }
    }
    unresolved
}

/// Infer the type of a struct literal: `StructName { field1: expr1, ... }`
///
/// 1. Look up the struct definition.
/// 2. Create fresh type variables for generic parameters.
/// 3. For each field in the literal, infer value type and unify with expected.
/// 4. Check all required fields are present.
/// 5. Return the struct type with inferred generic arguments.
fn infer_struct_literal(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    sl: &StructLiteral,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &FxHashMap<String, FnConstraints>,
) -> Result<Ty, TypeError> {
    let struct_name = sl.type_name().unwrap_or_else(|| "<unknown>".to_string());
    let span = sl
        .name_ref()
        .map(|nr| nr.syntax().text_range())
        .unwrap_or_else(|| sl.syntax().text_range());
    let Some((struct_def, generic_vars)) =
        resolve_struct_name(ctx, type_registry, &struct_name, span)
    else {
        // Infer the field values anyway, for their own errors.
        for field in sl.fields() {
            if let Some(value) = field.value() {
                let _ = infer_expr(
                    ctx,
                    env,
                    &value,
                    types,
                    type_registry,
                    trait_registry,
                    fn_constraints,
                );
            }
        }
        return Ok(Ty::struct_ty(&struct_name, vec![]));
    };
    let struct_name = struct_def.name.clone();

    // Track provided fields.
    let mut provided_fields: Vec<String> = Vec::new();

    for field in sl.fields() {
        let name = field.name().ok_or_else(incomplete)?;
        let field_name = name.text().ok_or_else(incomplete)?;
        // A field's error is reported and the literal keeps its type: its
        // uses are checked as the struct's, not reported again as unknown.
        if provided_fields.contains(&field_name) {
            ctx.errors.push(TypeError::DuplicateField {
                field_name,
                span: field.syntax().text_range(),
            });
            continue;
        }

        // Find expected field type.
        let expected_ty = struct_def
            .fields
            .iter()
            .find(|(name, _)| *name == field_name)
            .map(|(_, ty)| substitute_type_params(ty, &struct_def.generic_params, &generic_vars));

        let expected_ty = match expected_ty {
            Some(ty) => ty,
            None => {
                let written: FxHashSet<_> = sl
                    .fields()
                    .filter_map(|field| field.name()?.text())
                    .collect();
                ctx.errors.push(TypeError::UnknownField {
                    struct_name: struct_name.clone(),
                    suggestion: closest_name(
                        &field_name,
                        struct_def
                            .fields
                            .iter()
                            .filter(|(name, _)| !written.contains(name))
                            .map(|(name, _)| name.as_str()),
                    ),
                    field_name,
                    span: name.syntax().text_range(),
                });
                continue;
            }
        };

        // Infer field value (a mismatch is recorded by `unify`).
        if let Some(value) = field.value() {
            if let Ok(value_ty) = infer_expr(
                ctx,
                env,
                &value,
                types,
                type_registry,
                trait_registry,
                fn_constraints,
            ) {
                let _ = ctx.unify(
                    expected_ty,
                    value_ty,
                    ConstraintOrigin::Annotation {
                        annotation_span: field.syntax().text_range(),
                    },
                );
            }
        }

        provided_fields.push(field_name);
    }

    // Check for missing fields.
    for (field_name, _) in &struct_def.fields {
        if !provided_fields.contains(field_name) {
            ctx.errors.push(TypeError::MissingField {
                struct_name: struct_name.clone(),
                field_name: field_name.clone(),
                span: sl.syntax().text_range(),
            });
        }
    }

    Ok(struct_value_type(env, &struct_name, generic_vars))
}

/// The struct a literal or a pattern names, and its type arguments: fresh
/// variables, or the arguments an alias gives it (`P { x: 4 }` with
/// `type P = Point` builds a `Point`). A name that is not a struct is
/// reported at `span`.
fn resolve_struct_name(
    ctx: &mut InferCtx,
    type_registry: &TypeRegistry,
    name: &str,
    span: TextRange,
) -> Option<(StructDefInfo, Vec<Ty>)> {
    let named = resolve_alias(ctx, Ty::Con(TyCon::new(name)), type_registry);
    let (struct_name, alias_args) = match named.con_name() {
        Some(struct_name) if type_registry.lookup_struct(struct_name).is_some() => {
            let struct_name = struct_name.to_string();
            match named {
                Ty::App(_, args) => (struct_name, Some(args)),
                _ => (struct_name, None),
            }
        }
        _ => (name.to_string(), None),
    };
    let Some(struct_def) = type_registry.lookup_struct(&struct_name).cloned() else {
        if is_known_type(&struct_name, type_registry) {
            ctx.errors.push(TypeError::NotAStruct {
                ty: Ty::Con(TyCon::new(&struct_name)),
                span,
            });
        } else {
            // Not in scope: declared nowhere, or private to another
            // module (it said "`Secret` is not a struct").
            ctx.unknown_types.insert(struct_name.clone());
            ctx.errors.push(TypeError::UnknownType {
                suggestion: closest_name(
                    name,
                    type_registry
                        .struct_defs
                        .keys()
                        .chain(type_registry.type_aliases.keys())
                        .map(String::as_str),
                ),
                name: name.to_string(),
                span,
            });
        }
        return None;
    };
    let args = match alias_args {
        Some(args) if args.len() == struct_def.generic_params.len() => args,
        _ => struct_def
            .generic_params
            .iter()
            .map(|_| ctx.fresh_var())
            .collect(),
    };
    Some((struct_def, args))
}

/// The type of a value of struct `name` with type arguments `args`, keeping
/// the display prefix an import gave the struct.
fn struct_value_type(env: &TypeEnv, name: &str, args: Vec<Ty>) -> Ty {
    let tycon = env
        .lookup(name)
        .and_then(|scheme| scheme.ty.con())
        .cloned()
        .unwrap_or_else(|| TyCon::new(name));
    Ty::App(Box::new(Ty::Con(tycon)), args)
}

// ── Struct Update Inference ────────────────────────────────────────────

/// Infer the type of a struct update expression: `%{base | field: value, ...}`
///
/// The base expression must resolve to a struct type. Each override field must
/// exist in the struct definition and its value must unify with the field's type.
/// Returns the same struct type as the base expression.
fn infer_struct_update(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    update: &StructUpdate,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &FxHashMap<String, FnConstraints>,
) -> Result<Ty, TypeError> {
    // Infer the type of the base expression.
    let base_expr = update.base_expr().ok_or_else(incomplete)?;
    let base_ty = infer_expr(
        ctx,
        env,
        &base_expr,
        types,
        type_registry,
        trait_registry,
        fn_constraints,
    )?;
    let resolved_base = ctx.resolve(base_ty.clone());

    // The base must be a struct value.
    let struct_def = resolved_base
        .con_name()
        .and_then(|name| type_registry.lookup_struct(name));
    let Some(struct_def) = struct_def.cloned() else {
        let err = TypeError::NotAStruct {
            ty: resolved_base.clone(),
            span: base_expr.syntax().text_range(),
        };
        ctx.errors.push(err.clone());
        return Err(err);
    };
    let struct_name = struct_def.name.clone();

    // Create fresh type variables for generic params (matching base type args).
    let generic_vars: Vec<Ty> = match &resolved_base {
        Ty::App(_, args) => args.clone(),
        _ => struct_def
            .generic_params
            .iter()
            .map(|_| ctx.fresh_var())
            .collect(),
    };

    // Validate and infer each override field.
    let mut updated: Vec<String> = Vec::new();
    for field in update.override_fields() {
        let name = field.name().ok_or_else(incomplete)?;
        let field_name = name.text().ok_or_else(incomplete)?;
        // As in a struct literal, a field's error leaves the update typed.
        if updated.contains(&field_name) {
            ctx.errors.push(TypeError::DuplicateField {
                field_name,
                span: field.syntax().text_range(),
            });
            continue;
        }
        updated.push(field_name.clone());

        // Verify the field exists in the struct.
        let expected_ty = struct_def
            .fields
            .iter()
            .find(|(name, _)| *name == field_name)
            .map(|(_, ty)| substitute_type_params(ty, &struct_def.generic_params, &generic_vars));

        let expected_ty = match expected_ty {
            Some(ty) => ty,
            None => {
                let written: FxHashSet<_> = update
                    .override_fields()
                    .into_iter()
                    .filter_map(|field| field.name()?.text())
                    .collect();
                ctx.errors.push(TypeError::UnknownField {
                    struct_name: struct_name.clone(),
                    suggestion: closest_name(
                        &field_name,
                        struct_def
                            .fields
                            .iter()
                            .filter(|(name, _)| !written.contains(name))
                            .map(|(name, _)| name.as_str()),
                    ),
                    field_name,
                    span: name.syntax().text_range(),
                });
                continue;
            }
        };

        // Infer the override value and unify with expected field type.
        if let Some(value) = field.value() {
            if let Ok(value_ty) = infer_expr(
                ctx,
                env,
                &value,
                types,
                type_registry,
                trait_registry,
                fn_constraints,
            ) {
                let _ = ctx.unify(
                    expected_ty,
                    value_ty,
                    ConstraintOrigin::Annotation {
                        annotation_span: field.syntax().text_range(),
                    },
                );
            }
        }
    }

    // Return the same type as the base expression.
    Ok(base_ty)
}

// ── Map Literal Inference ──────────────────────────────────────────────

/// Infer the type of a map literal: `%{k1 => v1, k2 => v2, ...}`
///
/// Creates fresh type variables for K and V, then unifies each entry's key
/// and value types against them. Returns `Map<K, V>`.
fn infer_map_literal(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    map_lit: &MapLiteral,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &FxHashMap<String, FnConstraints>,
) -> Result<Ty, TypeError> {
    let k_ty = ctx.fresh_var();
    let v_ty = ctx.fresh_var();

    for entry in map_lit.entries() {
        let key_expr = entry.key().ok_or_else(incomplete)?;
        // For keyword argument entries (name: value), the key is a NAME_REF
        // representing the identifier text as a string key, not a variable reference.
        let key_inferred = if entry.is_keyword_entry() {
            Ty::string()
        } else {
            infer_expr(
                ctx,
                env,
                &key_expr,
                types,
                type_registry,
                trait_registry,
                fn_constraints,
            )?
        };
        // The map's keys are of the first one's type.
        let origin = ConstraintOrigin::Expr {
            span: key_expr.syntax().text_range(),
        };
        ctx.unify(k_ty.clone(), key_inferred, origin)?;
        let val_expr = entry.value().ok_or_else(incomplete)?;
        let val_inferred = infer_expr(
            ctx,
            env,
            &val_expr,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        )?;
        let origin = ConstraintOrigin::Expr {
            span: val_expr.syntax().text_range(),
        };
        ctx.unify(v_ty.clone(), val_inferred, origin)?;
    }

    Ok(Ty::map(k_ty, v_ty))
}

// ── List Literal Inference ──────────────────────────────────────────────

/// Infer the type of a list literal: `[e1, e2, ...]`
///
/// Creates a fresh type variable for the element type, then unifies each
/// element's inferred type against it. Returns `List<T>`.
fn infer_list_literal(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    lit: &ListLiteral,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &FxHashMap<String, FnConstraints>,
) -> Result<Ty, TypeError> {
    let elem_ty = ctx.fresh_var();
    for elem in lit.elements() {
        let t = infer_expr(
            ctx,
            env,
            &elem,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        )?;
        // The list's elements are of the first one's type.
        let origin = ConstraintOrigin::Expr {
            span: elem.syntax().text_range(),
        };
        ctx.unify(elem_ty.clone(), t, origin)?;
    }
    let resolved = ctx.resolve(elem_ty);
    let result_ty = Ty::list(resolved);
    types.insert(lit.syntax().text_range(), result_ty.clone());
    Ok(result_ty)
}

// ── Pattern Inference ──────────────────────────────────────────────────

/// Infer the type of a pattern, binding any variables into the environment.
fn infer_pattern(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    pat: &Pattern,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
) -> Result<Ty, TypeError> {
    infer_pattern_with_scrutinee(ctx, env, pat, types, type_registry, None)
}

fn infer_pattern_with_scrutinee(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    pat: &Pattern,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    scrutinee: Option<&Ty>,
) -> Result<Ty, TypeError> {
    let span = pat.syntax().text_range();
    match pat {
        Pattern::Ident(ident) => {
            let name_text = ident.name().ok_or_else(incomplete)?.text().to_string();

            // Check if this identifier is a known nullary variant constructor.
            // In Mesh, bare uppercase names like `Red`, `None`, `Point` in pattern
            // position should resolve to constructors, not create fresh bindings.
            // Bare payload-bearing constructors like `Ok` or `Err` (no parens) are
            // treated as `Ok(_)` / `Err(_)` -- match the constructor, ignore payload.
            // A lowercase name is always a new binding, even when a
            // variable of a sum type has that name (`case v do Some(v)`).
            let constructor_like = name_text.starts_with(|c: char| c.is_uppercase());
            if let Some(scheme) = env.lookup(&name_text).filter(|_| constructor_like) {
                let candidate = ctx.instantiate(scheme);
                // A nullary constructor is a value of its sum type; one with
                // a payload, named bare, stands for its result whatever the
                // payload. Anything else so named is no constructor.
                let matched = match ctx.resolve(candidate.clone()) {
                    Ty::App(..) => Some(candidate),
                    Ty::Fun(_, ret) => Some(*ret),
                    _ => None,
                };
                if let Some(ty) = matched {
                    let ty = match scrutinee {
                        Some(scrutinee)
                            if indexed_pattern_fields(
                                ctx,
                                type_registry,
                                &name_text,
                                &ty,
                                scrutinee,
                                span,
                            )?
                            .is_some() =>
                        {
                            ctx.resolve(scrutinee.clone())
                        }
                        None => {
                            reject_unchecked_indexed_pattern(ctx, &ty, span)?;
                            ty
                        }
                        _ => ty,
                    };
                    types.insert(pat.syntax().text_range(), ty.clone());
                    return Ok(ty);
                }
            }
            // An uppercase name is a constructor, never a new binding: a
            // misspelled one (`Grean`) matched everything.
            if constructor_like {
                let err = TypeError::UnknownVariant {
                    suggestion: did_you_mean(env, &name_text),
                    name: name_text,
                    span: pat.syntax().text_range(),
                    cons_tail: pat
                        .syntax()
                        .parent()
                        .is_some_and(|parent| parent.kind() == SyntaxKind::CONS_PAT)
                        && pat.syntax().next_sibling().is_none(),
                };
                ctx.errors.push(err.clone());
                return Err(err);
            }

            // Regular identifier pattern: create a fresh binding.
            let ty = ctx.fresh_var();
            env.insert(name_text, Scheme::mono(ty.clone()));
            types.insert(pat.syntax().text_range(), ty.clone());
            Ok(ty)
        }
        Pattern::Wildcard(_) => {
            let ty = ctx.fresh_var();
            types.insert(pat.syntax().text_range(), ty.clone());
            Ok(ty)
        }
        Pattern::Literal(lit) => {
            if let Some(token) = lit.token() {
                check_numeric_literal(ctx, &token, lit.is_negative());
            }
            let ty = literal_pattern_type(lit);
            types.insert(pat.syntax().text_range(), ty.clone());
            Ok(ty)
        }
        Pattern::Tuple(tuple_pat) => {
            let mut elem_types = Vec::new();
            for sub_pat in tuple_pat.patterns() {
                let ty = infer_pattern(ctx, env, &sub_pat, types, type_registry)?;
                elem_types.push(ty);
            }
            let ty = Ty::Tuple(elem_types);
            types.insert(pat.syntax().text_range(), ty.clone());
            Ok(ty)
        }
        Pattern::Constructor(ctor_pat) => {
            infer_constructor_pattern(ctx, env, ctor_pat, pat, types, type_registry, scrutinee)
        }
        Pattern::Struct(struct_pat) => {
            infer_struct_pattern(ctx, env, struct_pat, pat, types, type_registry)
        }
        Pattern::Or(or_pat) => infer_or_pattern(ctx, env, or_pat, pat, types, type_registry),
        Pattern::As(as_pat) => infer_as_pattern(ctx, env, as_pat, pat, types, type_registry),
        Pattern::Cons(cons_pat) => {
            infer_cons_pattern(ctx, env, cons_pat, pat, types, type_registry)
        }
        Pattern::List(list_pat) => {
            // `[p1, p2]` is a List<T> whose every element pattern is a T.
            let elem_ty = ctx.fresh_var();
            for sub_pat in list_pat.patterns() {
                let sub_ty = infer_pattern(ctx, env, &sub_pat, types, type_registry)?;
                ctx.unify(sub_ty, elem_ty.clone(), ConstraintOrigin::Builtin)?;
            }
            let ty = Ty::list(elem_ty);
            types.insert(pat.syntax().text_range(), ty.clone());
            Ok(ty)
        }
    }
}

/// Infer a struct pattern: `Point { x: 0, y }`. Each field it names matches
/// a value of that field's type; the fields it leaves out match anything.
/// An error in it is returned, as for an unknown constructor, so the match
/// is not checked further.
fn infer_struct_pattern(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    struct_pat: &mesh_parser::ast::pat::StructPat,
    pat: &Pattern,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
) -> Result<Ty, TypeError> {
    let errors_before = ctx.errors.len();
    let first_error = |ctx: &InferCtx| ctx.errors[errors_before].clone();
    let name = struct_pat.type_name();
    let span = name
        .as_ref()
        .map(|t| t.text_range())
        .unwrap_or_else(|| pat.syntax().text_range());
    let name = name.map(|t| t.text().to_string()).unwrap_or_default();
    let Some((def, args)) = resolve_struct_name(ctx, type_registry, &name, span) else {
        return Err(first_error(ctx));
    };
    let mut seen: Vec<String> = Vec::new();
    for field in struct_pat.fields() {
        let field_name = field.name().ok_or_else(incomplete)?;
        let sub = field.pattern().ok_or_else(incomplete)?;
        let field_span = field_name.text_range();
        let field_name = field_name.text().to_string();
        let span = field.syntax().text_range();
        if seen.contains(&field_name) {
            ctx.errors
                .push(TypeError::DuplicateField { field_name, span });
            return Err(first_error(ctx));
        }
        let Some((_, field_ty)) = def.fields.iter().find(|(name, _)| *name == field_name) else {
            let written: FxHashSet<_> = struct_pat
                .fields()
                .filter_map(|field| field.name().map(|name| name.text().to_string()))
                .collect();
            ctx.errors.push(TypeError::UnknownField {
                struct_name: def.name.clone(),
                suggestion: closest_name(
                    &field_name,
                    def.fields
                        .iter()
                        .filter(|(name, _)| !written.contains(name))
                        .map(|(name, _)| name.as_str()),
                ),
                field_name,
                span: field_span,
            });
            return Err(first_error(ctx));
        };
        let sub_ty = infer_pattern(ctx, env, &sub, types, type_registry)?;
        let expected = substitute_type_params(field_ty, &def.generic_params, &args);
        ctx.unify(
            expected,
            sub_ty,
            ConstraintOrigin::Annotation {
                annotation_span: span,
            },
        )?;
        seen.push(field_name);
    }
    let ty = struct_value_type(env, &def.name, args);
    types.insert(pat.syntax().text_range(), ty.clone());
    Ok(ty)
}

/// Infer a constructor pattern: `Circle(r)` or `Shape.Circle(r)`.
///
/// 1. Look up the variant constructor (qualified or unqualified) in the env.
/// 2. Instantiate the constructor scheme to get fresh type vars.
/// 3. If it's a function type, unify sub-pattern types with param types.
/// 4. Return the result type (the sum type).
fn infer_constructor_pattern(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    ctor_pat: &mesh_parser::ast::pat::ConstructorPat,
    pat: &Pattern,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    scrutinee: Option<&Ty>,
) -> Result<Ty, TypeError> {
    let lookup_name = constructor_lookup_name(ctx, ctor_pat);

    // Look up the constructor in the environment: a variant's.
    let variant = env
        .lookup(&lookup_name)
        .filter(|_| variant_owner(type_registry, &lookup_name).is_some());
    let ctor_scheme = match variant {
        Some(scheme) => scheme.clone(),
        None => {
            let err = TypeError::UnknownVariant {
                suggestion: did_you_mean(env, &lookup_name),
                name: lookup_name,
                span: pat.syntax().text_range(),
                cons_tail: false,
            };
            ctx.errors.push(err.clone());
            return Err(err);
        }
    };

    // A variant with fields is a function of them, a nullary one its type.
    let (field_types, ty) = match ctx.instantiate(&ctor_scheme) {
        Ty::Fun(field_types, ty) => (field_types, *ty),
        ty => (Vec::new(), ty),
    };
    let span = pat.syntax().text_range();
    let (field_types, ty) = if let Some(scrutinee) = scrutinee {
        let variant = lookup_name.rsplit('.').next().unwrap_or(&lookup_name);
        match indexed_pattern_fields(ctx, type_registry, variant, &ty, scrutinee, span)? {
            Some(fields) => (fields, ctx.resolve(scrutinee.clone())),
            None => (field_types, ty),
        }
    } else {
        reject_unchecked_indexed_pattern(ctx, &ty, span)?;
        (field_types, ty)
    };
    let sub_patterns: Vec<Pattern> = ctor_pat.fields().collect();
    if sub_patterns.len() != field_types.len() {
        let err = TypeError::ArityMismatch {
            expected: field_types.len(),
            found: sub_patterns.len(),
            origin: ConstraintOrigin::Pattern {
                pattern_span: pat.syntax().text_range(),
            },
        };
        ctx.errors.push(err.clone());
        return Err(err);
    }
    for (sub_pat, field_ty) in sub_patterns.iter().zip(field_types) {
        let sub_ty = infer_pattern(ctx, env, sub_pat, types, type_registry)?;
        let origin = ConstraintOrigin::Pattern {
            pattern_span: sub_pat.syntax().text_range(),
        };
        ctx.unify(field_ty, sub_ty, origin)?;
    }
    types.insert(pat.syntax().text_range(), ty.clone());
    Ok(ty)
}

/// The environment name of a constructor pattern's variant: `Circle` or
/// `Shape.Circle`.
fn constructor_lookup_name(
    ctx: &InferCtx,
    ctor_pat: &mesh_parser::ast::pat::ConstructorPat,
) -> String {
    let name = |token: Option<mesh_parser::SyntaxToken>| {
        token
            .map(|t| t.text().to_string())
            .unwrap_or_else(|| "<unknown>".to_string())
    };
    let variant_name = name(ctor_pat.variant_name());
    if ctor_pat.is_qualified() {
        let qualifier = name(ctor_pat.type_name());
        module_variant(ctx, &qualifier, &variant_name)
            .unwrap_or_else(|| format!("{qualifier}.{variant_name}"))
    } else {
        variant_name
    }
}

/// `Type.Variant` for a variant named through the module that exports its
/// type (`Geo.Dot`).
fn module_variant(ctx: &InferCtx, module: &str, variant: &str) -> Option<String> {
    let owner = ctx.module_variants.get(module)?.get(variant)?;
    Some(format!("{owner}.{variant}"))
}

/// The type of a pass-through arm's value: its pattern read back as an
/// expression, so `Ok(value)` alone means `Ok(value) -> Ok(value)`. The
/// constructors are instantiated afresh, which lets the other arms decide the
/// rest of the type, as when `Err(e) -> Err(wrap(e))` changes the error.
fn infer_rebuilt_pattern(
    ctx: &mut InferCtx,
    env: &TypeEnv,
    pat: &Pattern,
) -> Result<Ty, TypeError> {
    let not_a_value = |ctx: &mut InferCtx, reason: String| {
        ctx.errors.push(TypeError::InvalidPassThroughArm {
            reason,
            span: pat.syntax().text_range(),
        });
        ctx.fresh_var()
    };
    // The arm's pattern was checked first: each name in it is one it bound
    // or a constructor it found.
    let known = "a pass-through arm's pattern names what it binds or constructs";
    match pat {
        // A name the pattern bound, or a nullary constructor.
        Pattern::Ident(ident) => {
            let name = ident
                .name()
                .map(|t| t.text().to_string())
                .unwrap_or_default();
            let ty = ctx.instantiate(env.lookup(&name).expect(known));
            if matches!(ctx.resolve(ty.clone()), Ty::Fun(..))
                && name.starts_with(|c: char| c.is_uppercase())
            {
                return Ok(not_a_value(
                    ctx,
                    format!("`{name}` alone leaves its payload unnamed"),
                ));
            }
            Ok(ty)
        }
        Pattern::Constructor(ctor_pat) => {
            let scheme = env
                .lookup(&constructor_lookup_name(ctx, ctor_pat))
                .expect(known);
            match ctx.instantiate(scheme) {
                Ty::Fun(param_types, ret) => {
                    for (field, param_ty) in ctor_pat.fields().zip(param_types) {
                        let field_ty = infer_rebuilt_pattern(ctx, env, &field)?;
                        ctx.unify(param_ty, field_ty, ConstraintOrigin::Builtin)?;
                    }
                    Ok(*ret)
                }
                ty => Ok(ty),
            }
        }
        Pattern::Literal(lit) => Ok(literal_pattern_type(lit)),
        Pattern::Wildcard(_) => Ok(not_a_value(ctx, "`_` names no value".to_string())),
        _ => Ok(not_a_value(
            ctx,
            "only constructors, literals and the names a pattern binds can stand for the arm's value"
                .to_string(),
        )),
    }
}

/// The type of a literal pattern, which the parser makes only of a number,
/// `true` or `false`, a string, an atom, or `nil`.
fn literal_pattern_type(lit: &mesh_parser::ast::pat::LiteralPat) -> Ty {
    match lit.token().map(|t| t.kind()) {
        Some(SyntaxKind::INT_LITERAL) => Ty::int(),
        Some(SyntaxKind::FLOAT_LITERAL) => Ty::float(),
        Some(SyntaxKind::TRUE_KW | SyntaxKind::FALSE_KW) => Ty::bool(),
        Some(SyntaxKind::STRING_START) => Ty::string(),
        Some(SyntaxKind::ATOM_LITERAL) => Ty::Con(TyCon::new("Atom")),
        _ => Ty::Tuple(vec![]),
    }
}

/// Infer an or-pattern: `Circle(_) | Point`.
///
/// 1. Infer each alternative in a temporary scope.
/// 2. Unify all alternatives (they must match the same type).
/// 3. Validate that all alternatives bind the same set of variable names.
/// 4. Re-bind variables from the first alternative into the current scope.
fn infer_or_pattern(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    or_pat: &mesh_parser::ast::pat::OrPat,
    pat: &Pattern,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
) -> Result<Ty, TypeError> {
    // The parser gives an or-pattern two alternatives or more.
    let alternatives: Vec<Pattern> = or_pat.alternatives().collect();

    // Collect binding names using semantic-aware collection (needs env).
    let first_names = collect_pattern_binding_names(&alternatives[0]);

    // Infer first alternative in a temporary scope.
    env.push_scope();
    let first_ty = infer_pattern(ctx, env, &alternatives[0], types, type_registry)?;

    // Save the bindings from the first alternative to re-apply later.
    let first_bindings: Vec<(String, Scheme)> = first_names
        .iter()
        .filter_map(|name| {
            env.lookup(name)
                .map(|scheme| (name.clone(), scheme.clone()))
        })
        .collect();
    env.pop_scope();

    // Infer remaining alternatives, unify types, validate bindings.
    for alt in alternatives.iter().skip(1) {
        let alt_names = collect_pattern_binding_names(alt);

        env.push_scope();
        let alt_ty = infer_pattern(ctx, env, alt, types, type_registry)?;
        // Each alternative matches the first one's type, and binds a name
        // at one type: a name means one value.
        let origin = ConstraintOrigin::Pattern {
            pattern_span: alt.syntax().text_range(),
        };
        ctx.unify(first_ty.clone(), alt_ty, origin.clone())?;
        for (name, first_scheme) in &first_bindings {
            if let Some(alt_scheme) = env.lookup(name).cloned() {
                ctx.unify(first_scheme.ty.clone(), alt_scheme.ty, origin.clone())?;
            }
        }
        env.pop_scope();

        // Validate same variable names are bound.
        let mut first_sorted = first_names.clone();
        first_sorted.sort();
        let mut alt_sorted = alt_names;
        alt_sorted.sort();

        if first_sorted != alt_sorted {
            let err = TypeError::OrPatternBindingMismatch {
                expected_bindings: first_sorted,
                found_bindings: alt_sorted,
                list_tail: pat
                    .syntax()
                    .parent()
                    .is_some_and(|parent| parent.kind() == SyntaxKind::LIST_PAT)
                    && pat.syntax().next_sibling().is_none(),
                span: pat.syntax().text_range(),
            };
            ctx.errors.push(err.clone());
            return Err(err);
        }
    }

    // Re-bind the variables from the first alternative into the current scope.
    for (name, scheme) in first_bindings {
        env.insert(name, scheme);
    }

    types.insert(pat.syntax().text_range(), first_ty.clone());
    Ok(first_ty)
}

/// Report a name that `patterns` (one arm's, or one clause's parameters)
/// bind twice: `(a, a)` bound the second value and dropped the first.
fn check_unique_binders(ctx: &mut InferCtx, patterns: &[Pattern]) {
    let mut seen = FxHashSet::default();
    for pattern in patterns {
        for name in collect_pattern_binding_names(pattern) {
            if name != "_" && !seen.insert(name.clone()) {
                ctx.errors.push(TypeError::DuplicateBinding {
                    name,
                    span: pattern.syntax().text_range(),
                });
            }
        }
    }
}

/// The names a pattern binds (an uppercase identifier is a constructor).
fn collect_pattern_binding_names(pat: &Pattern) -> Vec<String> {
    pat.binders().iter().map(|t| t.text().to_string()).collect()
}

/// Infer an as-pattern: `Circle(r) as c`.
///
/// 1. Infer the inner pattern.
/// 2. Bind the "as" name to the inner pattern's type.
fn infer_as_pattern(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    as_pat: &mesh_parser::ast::pat::AsPat,
    pat: &Pattern,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
) -> Result<Ty, TypeError> {
    // Infer the inner pattern.
    let inner_pat = as_pat.pattern().ok_or_else(incomplete)?;
    let inner_ty = infer_pattern(ctx, env, &inner_pat, types, type_registry)?;

    // Bind the "as" name to the whole matched value's type.
    if let Some(binding_name_tok) = as_pat.binding_name() {
        let binding_name = binding_name_tok.text().to_string();
        env.insert(binding_name, Scheme::mono(inner_ty.clone()));
        if let Some(binding) = binding_name_tok.parent() {
            types.insert(binding.text_range(), inner_ty.clone());
        }
    }

    types.insert(pat.syntax().text_range(), inner_ty.clone());
    Ok(inner_ty)
}

/// Infer a cons pattern: `head :: tail`.
///
/// The cons pattern destructures a List<T> into:
/// - head: T (the first element)
/// - tail: List<T> (the remaining list)
fn infer_cons_pattern(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    cons_pat: &mesh_parser::ast::pat::ConsPat,
    pat: &Pattern,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
) -> Result<Ty, TypeError> {
    // The overall type is List<T> where T is a fresh variable.
    let elem_ty = ctx.fresh_var();
    let list_ty = Ty::list(elem_ty.clone());

    // Infer head pattern and unify with element type T.
    let head_pat = cons_pat.head().ok_or_else(incomplete)?;
    let head_ty = infer_pattern(ctx, env, &head_pat, types, type_registry)?;
    ctx.unify(head_ty, elem_ty.clone(), ConstraintOrigin::Builtin)?;

    // Infer tail pattern and unify with List<T>.
    let tail_pat = cons_pat.tail().ok_or_else(incomplete)?;
    let tail_ty = infer_pattern(ctx, env, &tail_pat, types, type_registry)?;
    ctx.unify(tail_ty, list_ty.clone(), ConstraintOrigin::Builtin)?;

    types.insert(pat.syntax().text_range(), list_ty.clone());
    Ok(list_ty)
}

// ── Actor Inference (06-04) ─────────────────────────────────────────────

/// Well-known environment key for tracking the current actor's message type.
/// When inside an actor block, this is bound to `Scheme::mono(M)` where M is
/// the actor's message type. Used by `self()` and `receive` to know the
/// current actor context.
const ACTOR_MSG_TYPE_KEY: &str = "__actor_msg_type__";
/// The catch-all arm name the test runner gives `assert_receive`'s receive.
const ASSERT_RECEIVE_FALLBACK: &str = "__assert_receive_other";
/// The type variable an actor's name is bound to inside its own body.
const ACTOR_SELF_KEY: &str = "__actor_self__";

/// Whether `call` calls the actor whose body is being checked, by its own
/// (unshadowed) name.
fn calls_enclosing_actor(env: &TypeEnv, call: &CallExpr) -> bool {
    let Some(Expr::NameRef(callee)) = call.callee() else {
        return false;
    };
    let (Some(name), Some(actor)) = (callee.text(), env.lookup(ACTOR_SELF_KEY)) else {
        return false;
    };
    env.lookup(&name)
        .is_some_and(|scheme| scheme.ty == actor.ty)
}

/// Infer an actor definition:
///
/// ```mesh
/// actor counter(state :: Int) do
///   receive do
///     n :: Int -> counter(state + n)
///   end
/// end
/// ```
///
/// The actor's message type M is inferred from the receive block's patterns.
/// The actor is registered in the environment as a function: `actor_name :: (StateType) -> Pid<M>`.
fn infer_actor_def(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    actor_def: &ActorDef,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &mut FxHashMap<String, FnConstraints>,
) -> Result<Ty, TypeError> {
    let actor_name = actor_def
        .name()
        .and_then(|n| n.text())
        .unwrap_or_else(|| "<unnamed_actor>".to_string());

    // The actor compiles to one body, so its type is not generalized: the
    // messages sent to it and the arguments it is spawned with, anywhere in
    // the module, decide the types its body works with.

    // Create a fresh type variable for the message type M.
    let msg_ty = ctx.fresh_var();

    // Pre-bind the actor name as a self-recursive function (for tail calls).
    let self_var = ctx.fresh_var();
    env.insert(actor_name.clone(), Scheme::mono(self_var.clone()));

    env.push_scope();

    // Bind the actor message type for self() and receive.
    env.insert(ACTOR_MSG_TYPE_KEY.into(), Scheme::mono(msg_ty.clone()));
    env.insert(ACTOR_SELF_KEY.into(), Scheme::mono(self_var.clone()));

    // Infer parameter types.
    let mut param_types = Vec::new();
    if let Some(param_list) = actor_def.param_list() {
        for param in param_list.params() {
            let param_ty = param
                .type_annotation()
                .and_then(|ann| resolve_type_annotation(ctx, &ann, type_registry))
                .unwrap_or_else(|| ctx.fresh_var());
            if let Some(name_tok) = param.name() {
                let name_text = name_tok.text().to_string();
                env.insert(name_text, Scheme::mono(param_ty.clone()));
            }
            param_types.push(param_ty);
        }
    }

    // Infer the actor body.
    infer_body(
        ctx,
        env,
        actor_def.body(),
        types,
        type_registry,
        trait_registry,
        fn_constraints,
    );

    env.pop_scope();

    // A receive arm that uses the message it binds needs the message's type
    // from somewhere in the module; without one it would read every message
    // as `()`. A binding the arm never reads does no harm.
    let uses_message = actor_def.syntax().descendants().any(|arm| {
        if arm.kind() != SyntaxKind::RECEIVE_ARM {
            return false;
        }
        let bound: Vec<String> = arm
            .descendants()
            .filter(|node| node.kind() == SyntaxKind::IDENT_PAT)
            .map(|node| node.text().to_string().trim().to_string())
            .collect();
        arm.descendants().any(|node| {
            node.kind() == SyntaxKind::NAME_REF && bound.contains(&node.text().to_string())
        })
    });
    if uses_message {
        let span = actor_def
            .name()
            .map(|name| name.syntax().text_range())
            .unwrap_or_else(|| actor_def.syntax().text_range());
        ctx.actor_message_types
            .push((actor_name.clone(), msg_ty.clone(), span));
    }

    // The actor function type: (StateTypes...) -> Pid<M>
    let pid_ty = Ty::pid(msg_ty);
    let fn_ty = Ty::Fun(param_types, Box::new(pid_ty.clone()));

    // Unify with the pre-bound self-recursive variable.
    ctx.unify(self_var, fn_ty.clone(), ConstraintOrigin::Builtin)?;

    env.insert(actor_name, Scheme::mono(fn_ty.clone()));

    let resolved = ctx.resolve(fn_ty);
    types.insert(actor_def.syntax().text_range(), resolved.clone());

    Ok(resolved)
}

pub(crate) const SUPERVISION_STRATEGIES: [&str; 4] = [
    "one_for_one",
    "one_for_all",
    "rest_for_one",
    "simple_one_for_one",
];
pub(crate) const SUPERVISION_RESTART_TYPES: [&str; 3] = ["permanent", "transient", "temporary"];

/// Infer the type of a supervisor definition.
///
/// The supervisor is registered as a function: `supervisor_name :: () -> Pid<Unit>`.
/// Supervisors don't receive user messages; they manage child processes.
///
/// Validates child specs at compile time:
/// - Strategy must be one_for_one, one_for_all, rest_for_one, or simple_one_for_one
/// - Child start functions must return Pid (checked via spawn reference)
/// - Restart types must be permanent, transient, or temporary
/// - Shutdown values must be positive integers or brutal_kill
/// - Child names must be unique within the supervisor
fn infer_supervisor_def(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    sup_def: &SupervisorDef,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &mut FxHashMap<String, FnConstraints>,
) -> Result<Ty, TypeError> {
    let sup_name = sup_def
        .name()
        .and_then(|n| n.text())
        .unwrap_or_else(|| "<unnamed_supervisor>".to_string());

    // ── Strategy validation ──────────────────────────────────────────
    // `strategy: one_for_one`: the value is the clause's second name.
    let strategy = sup_def.strategy().and_then(|clause| {
        clause
            .children_with_tokens()
            .filter_map(|c| c.into_token())
            .filter(|t| t.kind() == SyntaxKind::IDENT)
            .nth(1)
    });
    if let Some(strategy) = strategy {
        if !SUPERVISION_STRATEGIES.contains(&strategy.text()) {
            ctx.errors.push(TypeError::InvalidStrategy {
                found: strategy.text().to_string(),
                span: strategy.text_range(),
            });
        }
    }

    // ── Child spec validation ────────────────────────────────────────
    let mut seen_child_names: Vec<String> = Vec::new();
    for child_node in sup_def.child_specs() {
        let name = child_node
            .children()
            .find(|c| c.kind() == SyntaxKind::NAME)
            .and_then(|n| n.first_token());
        let child_name = name
            .as_ref()
            .map_or_else(|| "<unnamed_child>".to_string(), |t| t.text().to_string());
        if seen_child_names.contains(&child_name) {
            ctx.errors.push(TypeError::DuplicateDefinition {
                kind: "child",
                name: child_name.clone(),
                span: name.map_or(child_node.text_range(), |t| t.text_range()),
            });
        }
        seen_child_names.push(child_name.clone());

        let Some(block) = child_node
            .children()
            .find(|c| c.kind() == SyntaxKind::BLOCK)
        else {
            continue;
        };
        // The start value is the child spec's only expression: a function
        // that spawns the child and returns its pid. Unchecked, a misspelled
        // actor in it compiled and crashed.
        if let Some(start) = block.children().find_map(Expr::cast) {
            if let Ok(start_ty) = infer_expr(
                ctx,
                env,
                &start,
                types,
                type_registry,
                trait_registry,
                fn_constraints,
            ) {
                let expected = Ty::Fun(vec![], Box::new(Ty::pid(ctx.fresh_var())));
                let errors_before = ctx.errors.len();
                if ctx
                    .unify(start_ty.clone(), expected, ConstraintOrigin::Builtin)
                    .is_err()
                {
                    ctx.errors.truncate(errors_before);
                    let found = ctx.resolve(start_ty);
                    ctx.errors.push(TypeError::InvalidChildStart {
                        child_name: child_name.clone(),
                        found,
                        span: start.syntax().text_range(),
                    });
                }
            }
        }
        // `restart: permanent` and `shutdown: 5000`: the block's own tokens
        // (not those of the start expression), each value after its key and
        // colon.
        let tokens: Vec<_> = block
            .children_with_tokens()
            .filter_map(|c| c.into_token())
            .filter(|t| !t.kind().is_trivia() && t.kind() != SyntaxKind::NEWLINE)
            .collect();
        for pair in tokens
            .windows(3)
            .filter(|pair| pair[1].kind() == SyntaxKind::COLON)
        {
            let (key, value) = (&pair[0], &pair[2]);
            let found = value.text().to_string();
            match key.text() {
                "restart" if !SUPERVISION_RESTART_TYPES.contains(&value.text()) => {
                    ctx.errors.push(TypeError::InvalidRestartType {
                        found,
                        child_name: child_name.clone(),
                        span: value.text_range(),
                    });
                }
                // A timeout in milliseconds, or `brutal_kill`.
                "shutdown"
                    if value.text() != "brutal_kill"
                        && !(value.kind() == SyntaxKind::INT_LITERAL
                            && found.replace('_', "").parse::<i64>().is_ok_and(|ms| ms > 0)) =>
                {
                    ctx.errors.push(TypeError::InvalidShutdownValue {
                        found,
                        child_name: child_name.clone(),
                        span: value.text_range(),
                    });
                }
                _ => {}
            }
        }
    }

    // ── Register supervisor type ─────────────────────────────────────
    // Supervisors are zero-arg functions that return Pid<Unit>.
    let pid_ty = Ty::pid(Ty::Tuple(vec![]));
    let fn_ty = Ty::Fun(vec![], Box::new(pid_ty.clone()));

    let scheme = ctx.generalize(fn_ty.clone());
    env.insert(sup_name, scheme);

    let resolved = ctx.resolve(fn_ty);
    types.insert(sup_def.syntax().text_range(), resolved.clone());

    Ok(resolved)
}

/// Convert a PascalCase name to snake_case.
///
/// Examples: "GetCount" -> "get_count", "Increment" -> "increment",
/// "ResetAll" -> "reset_all".
fn to_snake_case(name: &str) -> String {
    let mut result = String::new();
    for (i, ch) in name.chars().enumerate() {
        if ch.is_uppercase() {
            if i > 0 {
                result.push('_');
            }
            result.push(ch.to_lowercase().next().unwrap());
        } else {
            result.push(ch);
        }
    }
    result
}

/// Where a handler body's type is checked: the body's last expression, or the
/// whole body when it is empty.
fn body_origin(body: Option<Block>) -> ConstraintOrigin {
    match body {
        Some(block) => ConstraintOrigin::Expr {
            span: block
                .syntax()
                .children()
                .filter_map(Expr::cast)
                .last()
                .map(|expr| expr.syntax().text_range())
                .unwrap_or_else(|| block.syntax().text_range()),
        },
        None => ConstraintOrigin::Builtin,
    }
}

/// Infer the type of a service definition.
///
/// Services define a typed client-server abstraction. The type checker:
/// 1. Infers init function return type and unifies with state type variable.
/// 2. For each call handler: validates state param, infers reply type from
///    annotation, ensures body returns (new_state, reply) tuple.
/// 3. For each cast handler: validates state param, ensures body returns new_state.
/// 4. Registers module-qualified helper functions (ServiceName.method_name).
///
/// The service is registered as a module with:
/// - start(init_args...) -> Pid<Unit>
/// - Per call handler: snake_name(pid, args...) -> reply_ty
/// - Per cast handler: snake_name(pid, args...) -> Unit
fn infer_service_def(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    service_def: &ServiceDef,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &mut FxHashMap<String, FnConstraints>,
) -> Result<Ty, TypeError> {
    let service_name = service_def
        .name()
        .and_then(|n| n.text())
        .unwrap_or_else(|| "<unnamed_service>".to_string());

    ctx.enter_level();

    // Create a fresh type variable for the service state.
    let state_ty = ctx.fresh_var();

    // Pid type for callers: Pid<Unit> (internal message dispatching uses type_tags,
    // callers don't see message types directly).
    let pid_ty = Ty::pid(Ty::Tuple(vec![]));

    env.push_scope();

    // ── Infer init function ──────────────────────────────────────────
    let mut init_param_types: Vec<Ty> = Vec::new();

    if let Some(init_fn) = service_def.init_fn() {
        env.push_scope();

        init_param_types =
            bind_service_params(ctx, env, init_fn.param_list(), types, type_registry);

        // Infer init body -- its return type is the initial state.
        let init_body_ty = infer_body(
            ctx,
            env,
            init_fn.body(),
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        );

        // Unify init return type with state_ty.
        let _ = ctx.unify(init_body_ty, state_ty.clone(), body_origin(init_fn.body()));

        // Record the init function's type so MIR lowering can resolve parameter types.
        let init_fn_ty = Ty::Fun(
            init_param_types.clone(),
            Box::new(ctx.resolve(state_ty.clone())),
        );
        types.insert(init_fn.syntax().text_range(), init_fn_ty);

        env.pop_scope();
    }

    // ── Infer call handlers ──────────────────────────────────────────
    let call_handlers = service_def.call_handlers();
    let mut call_handler_info: Vec<(String, Vec<Ty>, Ty)> = Vec::new(); // (variant_name, param_types, reply_ty)

    for handler in &call_handlers {
        let variant_name = handler
            .name()
            .and_then(|n| n.text())
            .unwrap_or_else(|| "<unnamed_call>".to_string());

        env.push_scope();

        // Bind state parameter.
        if let Some(state_name) = handler.state_param_name() {
            env.insert(state_name, Scheme::mono(state_ty.clone()));
        }

        // The call's arguments.
        let handler_param_types =
            bind_service_params(ctx, env, handler.params(), types, type_registry);

        // Parse return type annotation (:: Type).
        let reply_ty = handler
            .return_type()
            .and_then(|ann| resolve_type_annotation(ctx, &ann, type_registry))
            .unwrap_or_else(|| ctx.fresh_var());

        // Infer call handler body -- should return (new_state, reply) tuple.
        let body_ty = infer_body(
            ctx,
            env,
            handler.body(),
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        );

        // Body should return a tuple of (new_state, reply).
        let expected_body_ty = Ty::Tuple(vec![state_ty.clone(), reply_ty.clone()]);
        let _ = ctx.unify(expected_body_ty, body_ty, body_origin(handler.body()));

        env.pop_scope();

        call_handler_info.push((variant_name, handler_param_types, reply_ty));
    }

    // ── Infer cast handlers ──────────────────────────────────────────
    let cast_handlers = service_def.cast_handlers();
    let mut cast_handler_info: Vec<(String, Vec<Ty>)> = Vec::new(); // (variant_name, param_types)

    for handler in &cast_handlers {
        let variant_name = handler
            .name()
            .and_then(|n| n.text())
            .unwrap_or_else(|| "<unnamed_cast>".to_string());

        env.push_scope();

        // Bind state parameter.
        if let Some(state_name) = handler.state_param_name() {
            env.insert(state_name, Scheme::mono(state_ty.clone()));
        }

        // The cast's arguments.
        let handler_param_types =
            bind_service_params(ctx, env, handler.params(), types, type_registry);

        // Infer cast handler body -- returns new_state.
        let body_ty = infer_body(
            ctx,
            env,
            handler.body(),
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        );

        // Unify body return with state type.
        let _ = ctx.unify(state_ty.clone(), body_ty, body_origin(handler.body()));

        env.pop_scope();

        cast_handler_info.push((variant_name, handler_param_types));
    }

    env.pop_scope();

    // A service that takes plaintext is reached through its own typed pid,
    // which an untyped `Pid` (a registry lookup, perhaps of another node's
    // service) does not become (see `plaintext.rs`).
    let takes_plaintext = call_handler_info
        .iter()
        .map(|(_, params, _)| params)
        .chain(cast_handler_info.iter().map(|(_, params)| params))
        .flatten()
        .any(|param| type_registry.is_plaintext_type(&ctx.resolve(param.clone())));
    let pid_ty = if takes_plaintext {
        Ty::pid(Ty::plaintext(Ty::Tuple(vec![])))
    } else {
        pid_ty
    };

    // ── The service's helper functions ────────────────────────────────
    // `Service.start(init_args...)`, and for each handler
    // `Service.snake_name(pid, args...)`, which returns a call's reply and
    // a cast's nothing; each with the function lowering generates for it.
    let name_lower = service_name.to_lowercase();
    let start_fn_ty = Ty::Fun(init_param_types, Box::new(pid_ty.clone()));
    let mut helpers = vec![(
        "start".to_string(),
        start_fn_ty.clone(),
        format!("__service_{name_lower}_start"),
    )];
    let calls = call_handler_info
        .iter()
        .map(|(name, params, reply)| (name, params, Some(reply), "call"));
    let casts = cast_handler_info
        .iter()
        .map(|(name, params)| (name, params, None, "cast"));
    for (variant_name, param_types, reply, kind) in calls.chain(casts) {
        let returns = reply.map_or(Ty::Tuple(vec![]), |reply| ctx.resolve(reply.clone()));
        let snake_name = to_snake_case(variant_name);
        let params = std::iter::once(pid_ty.clone()).chain(param_types.iter().cloned());
        let fn_ty = Ty::Fun(params.collect(), Box::new(returns));
        let generated = format!("__service_{name_lower}_{kind}_{snake_name}");
        helpers.push((snake_name, fn_ty, generated));
    }
    let mut info = crate::ServiceExportInfo {
        name: service_name.clone(),
        helpers: FxHashMap::default(),
        methods: Vec::new(),
    };
    for (name, fn_ty, generated) in helpers {
        env.insert(
            format!("{service_name}.{name}"),
            Scheme::mono(fn_ty.clone()),
        );
        let resolved = ctx.resolve(fn_ty);
        info.helpers.insert(name.clone(), Scheme::mono(resolved));
        info.methods.push((name, generated));
    }
    ctx.local_service_exports.insert(service_name.clone(), info);

    ctx.leave_level();

    // The service itself is a module-like entity. Register the name so it can be
    // used as a module qualifier in ServiceName.method() calls.
    // Register as a simple type constructor for recognition in field access.
    env.insert(
        service_name.clone(),
        Scheme::mono(Ty::Con(TyCon::new(&service_name))),
    );

    let resolved = ctx.resolve(start_fn_ty);
    types.insert(service_def.syntax().text_range(), resolved.clone());

    Ok(resolved)
}

/// Bind a service's init or handler parameters (`params`) in scope, each of
/// its annotated type or a fresh one, and record each for lowering.
fn bind_service_params(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    params: Option<mesh_parser::ast::item::ParamList>,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
) -> Vec<Ty> {
    let mut param_types = Vec::new();
    for param in params.iter().flat_map(|list| list.params()) {
        let param_ty = param
            .type_annotation()
            .and_then(|ann| resolve_type_annotation(ctx, &ann, type_registry))
            .unwrap_or_else(|| ctx.fresh_var());
        if let Some(name) = param.name() {
            env.insert(name.text().to_string(), Scheme::mono(param_ty.clone()));
        }
        types.insert(param.syntax().text_range(), param_ty.clone());
        param_types.push(param_ty);
    }
    param_types
}

/// Infer the type of a spawn expression: `spawn(actor_fn, initial_state...)`.
///
/// The first argument must be a function. Its return type determines the Pid
/// type. Returns `Pid<M>` where M is inferred from the actor function.
fn infer_spawn(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    spawn: &SpawnExpr,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &FxHashMap<String, FnConstraints>,
) -> Result<Ty, TypeError> {
    let args: Vec<Expr> = spawn.arg_list().ok_or_else(incomplete)?.args().collect();
    // The first argument is the actor, the others its arguments.
    let Some(actor_fn_expr) = args.first() else {
        let err = TypeError::ArityMismatch {
            expected: 1,
            found: 0,
            origin: ConstraintOrigin::Expr {
                span: spawn.syntax().text_range(),
            },
        };
        ctx.errors.push(err.clone());
        return Err(err);
    };
    let actor_fn_ty = infer_expr(
        ctx,
        env,
        actor_fn_expr,
        types,
        type_registry,
        trait_registry,
        fn_constraints,
    )?;
    // An actor starts from its function's compiled entry: a name, maybe
    // module-qualified, and not a value that holds a function.
    let not_local = |expr: &Expr| match expr {
        Expr::NameRef(name) => name.text().is_some_and(|name| !env.is_local(&name)),
        _ => false,
    };
    let named = match actor_fn_expr {
        Expr::FieldAccess(fa) => fa.base().is_some_and(|base| not_local(&base)),
        other => not_local(other),
    };
    if !named && matches!(ctx.resolve(actor_fn_ty.clone()), Ty::Fun(..)) {
        let err = TypeError::SpawnByName {
            span: actor_fn_expr.syntax().text_range(),
        };
        ctx.errors.push(err.clone());
        return Err(err);
    }

    // Remaining args are initial state.
    let mut state_arg_types = Vec::new();
    for arg in args.iter().skip(1) {
        let arg_ty = infer_expr(
            ctx,
            env,
            arg,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        )?;
        state_arg_types.push(arg_ty);
    }

    // The actor function should be: (StateTypes...) -> Pid<M>
    // Create the expected function type and unify.
    let msg_var = ctx.fresh_var();
    let pid_ret = Ty::pid(msg_var.clone());
    let expected_fn_ty = Ty::Fun(state_arg_types, Box::new(pid_ret.clone()));

    let resolved_fn = ctx.resolve(actor_fn_ty.clone());
    match resolved_fn {
        // A function that is no actor returns no pid: it said "expected
        // `()`, found `Pid<_>`" of the spawn.
        Ty::Fun(_, ret) if !matches!(*ret, Ty::Var(_)) && ret.con_name() != Some("Pid") => {
            let err = TypeError::SpawnNotActor {
                span: actor_fn_expr.syntax().text_range(),
            };
            ctx.errors.push(err.clone());
            return Err(err);
        }
        Ty::Fun(_, _) | Ty::Var(_) => {
            let origin = ConstraintOrigin::FnArg {
                call_site: spawn.syntax().text_range(),
                param_idx: 0,
            };
            ctx.unify(actor_fn_ty, expected_fn_ty, origin)?;
        }
        _ => {
            let err = TypeError::SpawnNonFunction {
                found: resolved_fn,
                span: spawn.syntax().text_range(),
            };
            ctx.errors.push(err.clone());
            return Err(err);
        }
    }

    Ok(pid_ret)
}

/// Infer the type of a send expression: `send(pid, message)`.
///
/// If pid is `Pid<M>`, validates that message has type M.
/// If pid is untyped `Pid`, accepts any message type.
/// Returns an observable delivery status code.
fn infer_send(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    send: &SendExpr,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &FxHashMap<String, FnConstraints>,
) -> Result<Ty, TypeError> {
    infer_send_with(
        ctx,
        env,
        send,
        None,
        send.syntax().text_range(),
        types,
        type_registry,
        trait_registry,
        fn_constraints,
    )
}

/// `send` on the right of a pipe: the piped value is the argument at
/// `insert_idx` (`m |2> send(p)` is `send(p, m)`).
#[allow(clippy::too_many_arguments)]
fn infer_piped_send(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    send: &SendExpr,
    piped: Ty,
    insert_idx: usize,
    span: TextRange,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &FxHashMap<String, FnConstraints>,
) -> Result<Ty, TypeError> {
    let ty = infer_send_with(
        ctx,
        env,
        send,
        Some((piped, insert_idx)),
        span,
        types,
        type_registry,
        trait_registry,
        fn_constraints,
    )?;
    types.insert(send.syntax().text_range(), ty.clone());
    Ok(ty)
}

/// `send(pid, message)` at `span`, with the value a pipe gives it (and the
/// argument position it goes to), if any.
#[allow(clippy::too_many_arguments)]
fn infer_send_with(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    send: &SendExpr,
    piped: Option<(Ty, usize)>,
    span: TextRange,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &FxHashMap<String, FnConstraints>,
) -> Result<Ty, TypeError> {
    let explicit: Vec<Expr> = send.arg_list().ok_or_else(incomplete)?.args().collect();
    let mut arg_tys = Vec::new();
    for arg in &explicit {
        let ty = infer_expr(
            ctx,
            env,
            arg,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        );
        arg_tys.push(ty?);
    }
    if let Some((piped, insert_idx)) = piped {
        arg_tys.insert(insert_idx.min(arg_tys.len()), piped);
    }
    let [pid_ty, msg_ty] = <[Ty; 2]>::try_from(arg_tys).map_err(|arg_tys| {
        let err = TypeError::ArityMismatch {
            expected: 2,
            found: arg_tys.len(),
            origin: ConstraintOrigin::Expr { span },
        };
        ctx.errors.push(err.clone());
        err
    })?;
    check_send(ctx, pid_ty, msg_ty, span)
}

/// A message of type `msg_ty` sent to a pid of type `pid_ty`, at `span`:
/// `send(p, m)`, or `m |2> send(p)`.
fn check_send(
    ctx: &mut InferCtx,
    pid_ty: Ty,
    msg_ty: Ty,
    span: TextRange,
) -> Result<Ty, TypeError> {
    let resolved_pid = ctx.resolve(pid_ty);
    match resolved_pid.args_of("Pid") {
        // A typed `Pid<M>` takes messages of type `M`.
        Some([expected_msg]) => {
            let errors_before = ctx.errors.len();
            if ctx
                .unify(
                    msg_ty.clone(),
                    expected_msg.clone(),
                    ConstraintOrigin::Builtin,
                )
                .is_err()
            {
                // Report the send, not also the spanless mismatch `unify` recorded.
                ctx.errors.truncate(errors_before);
                let err = TypeError::SendTypeMismatch {
                    expected: ctx.resolve(expected_msg.clone()),
                    found: ctx.resolve(msg_ty),
                    span,
                };
                ctx.errors.push(err.clone());
                return Err(err);
            }
        }
        // The untyped `Pid` takes any message (an escape hatch); anything
        // else must be a pid of the message's type.
        _ if resolved_pid.con_name() == Some("Pid") => {}
        _ => {
            let origin = ConstraintOrigin::FnArg {
                call_site: span,
                param_idx: 0,
            };
            ctx.unify(Ty::pid(msg_ty), resolved_pid, origin)?;
        }
    }
    Ok(Ty::int())
}

/// Infer the type of a receive expression.
///
/// Each arm pattern contributes to inferring the message type M.
/// All arms must return the same type. Optional after clause for timeouts.
fn infer_receive(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    recv: &ReceiveExpr,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &FxHashMap<String, FnConstraints>,
) -> Result<Ty, TypeError> {
    // Only an actor receives, messages of its message type.
    let Some(msg_scheme) = env.lookup(ACTOR_MSG_TYPE_KEY) else {
        let err = TypeError::ReceiveOutsideActor {
            span: recv.syntax().text_range(),
        };
        ctx.errors.push(err.clone());
        return Err(err);
    };
    let actor_msg_ty = ctx.instantiate(msg_scheme);

    let mut result_ty: Option<Ty> = None;
    let mut first_branch: Option<TextRange> = None;
    let mut arm_patterns: Vec<AbsPat> = Vec::new();
    let mut arm_has_guard: Vec<bool> = Vec::new();
    let mut arm_spans: Vec<TextRange> = Vec::new();

    for arm in recv.arms() {
        env.push_scope();

        if let Some(pat) = arm.pattern() {
            check_unique_binders(ctx, std::slice::from_ref(&pat));
            let pat_ty = infer_pattern(ctx, env, &pat, types, type_registry)?;
            // Unify pattern type with actor message type.
            ctx.unify(
                actor_msg_ty.clone(),
                pat_ty,
                ConstraintOrigin::Pattern {
                    pattern_span: pat.syntax().text_range(),
                },
            )?;
            // Lowering reads the message type from the pattern's range.
            types.insert(pat.syntax().text_range(), actor_msg_ty.clone());
            arm_patterns.push(ast_pattern_to_abstract(ctx, &pat, env, type_registry));
        } else {
            arm_patterns.push(AbsPat::Wildcard);
        }
        arm_has_guard.push(arm.guard().is_some());
        arm_spans.push(arm.syntax().text_range());

        if let Some(guard_expr) = arm.guard() {
            let guard_ty = infer_expr(
                ctx,
                env,
                &guard_expr,
                types,
                type_registry,
                trait_registry,
                fn_constraints,
            )?;
            let _ = ctx.unify(
                Ty::bool(),
                guard_ty,
                ConstraintOrigin::Expr {
                    span: guard_expr.syntax().text_range(),
                },
            );
        }

        if let Some(body) = arm.body() {
            let body_ty = infer_expr(
                ctx,
                env,
                &body,
                types,
                type_registry,
                trait_registry,
                fn_constraints,
            )?;
            join_branch_ty(
                ctx,
                &mut result_ty,
                &mut first_branch,
                recv.syntax().text_range(),
                body_ty,
                body.syntax().text_range(),
            )?;
        }

        env.pop_scope();
    }

    // A receive takes whatever message arrives next, so its arms must cover
    // the whole message type, as a case's arms cover its scrutinee.
    if !arm_patterns.is_empty() {
        check_arm_coverage(
            ctx,
            &actor_msg_ty,
            &arm_patterns,
            &arm_has_guard,
            &arm_spans,
            recv.syntax().text_range(),
            type_registry,
            false,
        );
        // `assert_receive` adds a catch-all arm that fails the test; it is
        // redundant whenever the asserted pattern matches everything.
        if ctx.test_builtins {
            let fallback: Vec<TextRange> = recv
                .arms()
                .filter(|arm| {
                    matches!(arm.pattern(), Some(Pattern::Ident(ident))
                        if ident.name().is_some_and(|name| name.text() == ASSERT_RECEIVE_FALLBACK))
                })
                .map(|arm| arm.syntax().text_range())
                .collect();
            ctx.warnings.retain(|warning| {
                !matches!(warning, TypeError::RedundantArm { span, .. } if fallback.contains(span))
            });
        }
    }

    // Handle after (timeout) clause.
    if let Some(after) = recv.after_clause() {
        if let Some(timeout_expr) = after.timeout() {
            let timeout_ty = infer_expr(
                ctx,
                env,
                &timeout_expr,
                types,
                type_registry,
                trait_registry,
                fn_constraints,
            )?;
            let origin = ConstraintOrigin::Expr {
                span: timeout_expr.syntax().text_range(),
            };
            let _ = ctx.unify(Ty::int(), timeout_ty, origin);
        }
        if let Some(body) = after.body() {
            let body_ty = infer_expr(
                ctx,
                env,
                &body,
                types,
                type_registry,
                trait_registry,
                fn_constraints,
            )?;
            join_branch_ty(
                ctx,
                &mut result_ty,
                &mut first_branch,
                recv.syntax().text_range(),
                body_ty,
                body.syntax().text_range(),
            )?;
        }
    }

    Ok(result_ty.unwrap_or_else(|| Ty::Tuple(vec![])))
}

/// Infer the type of a self() expression.
///
/// Returns `Pid<M>` where M is the current actor's message type.
/// Errors if called outside an actor block.
fn infer_self_expr(
    ctx: &mut InferCtx,
    env: &TypeEnv,
    self_expr: &SelfExpr,
) -> Result<Ty, TypeError> {
    match env.lookup(ACTOR_MSG_TYPE_KEY) {
        Some(scheme) => {
            let msg_ty = ctx.instantiate(scheme);
            Ok(Ty::pid(msg_ty))
        }
        None => {
            let err = TypeError::SelfOutsideActor {
                span: self_expr.syntax().text_range(),
            };
            ctx.errors.push(err.clone());
            Err(err)
        }
    }
}

/// `link(pid)`: links the running actor to the process `pid`, a pid of
/// any message type. Anything else was linked as if it were one.
fn infer_link(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    link: &LinkExpr,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &FxHashMap<String, FnConstraints>,
) -> Result<Ty, TypeError> {
    let args: Vec<Expr> = link.arg_list().ok_or_else(incomplete)?.args().collect();
    let span = link.syntax().text_range();
    let [target] = args.as_slice() else {
        let err = TypeError::ArityMismatch {
            expected: 1,
            found: args.len(),
            origin: ConstraintOrigin::Expr { span },
        };
        ctx.errors.push(err.clone());
        return Err(err);
    };
    let target_ty = infer_expr(
        ctx,
        env,
        target,
        types,
        type_registry,
        trait_registry,
        fn_constraints,
    )?;
    let origin = ConstraintOrigin::FnArg {
        call_site: span,
        param_idx: 0,
    };
    let any_pid = Ty::pid(ctx.fresh_var());
    ctx.unify(any_pid, target_ty, origin)?;
    Ok(Ty::Tuple(vec![]))
}

// ── Try (?) expression inference ───────────────────────────────────────

/// Infer the type of a try expression (`expr?`): the value inside a
/// `Result<T, E>` or `Option<T>`, whose `Err` or `None` the enclosing
/// function returns early. That function must return a `Result` whose error
/// type is `E` or converts from it (`From`), or an `Option`. An operand whose
/// type is not known yet is taken for an `Option` in a function returning
/// one, and a `Result` otherwise.
fn infer_try_expr(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    try_expr: &TryExpr,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &FxHashMap<String, FnConstraints>,
) -> Result<Ty, TypeError> {
    let span = try_expr.syntax().text_range();
    let operand = try_expr.operand().ok_or_else(incomplete)?;
    let operand_ty = infer_expr(
        ctx,
        env,
        &operand,
        types,
        type_registry,
        trait_registry,
        fn_constraints,
    )?;
    try_value(ctx, trait_registry, operand_ty, span)
}

/// What `?` at `span` gives on a value of `operand_ty` (see
/// `infer_try_expr`), checking the early return against the function's.
fn try_value(
    ctx: &mut InferCtx,
    trait_registry: &TraitRegistry,
    operand_ty: Ty,
    span: TextRange,
) -> Result<Ty, TypeError> {
    let fn_ret = ctx
        .current_fn_return_type()
        .cloned()
        .map(|ty| ctx.resolve(ty));
    if let Ty::Var(_) = ctx.resolve(operand_ty.clone()) {
        let value = ctx.fresh_var();
        let known = match fn_ret.as_ref().and_then(|ret| ret.args_of("Option")) {
            Some(_) => Ty::option(value),
            None => Ty::result(value, ctx.fresh_var()),
        };
        ctx.unify(operand_ty.clone(), known, ConstraintOrigin::Builtin)?;
    }
    let resolved = ctx.resolve(operand_ty);

    // The value `?` gives, and what the function returns early.
    let (value, early) = match (resolved.args_of("Result"), resolved.args_of("Option")) {
        (Some([ok, err]), _) => (ok.clone(), Ty::result(ctx.fresh_var(), err.clone())),
        (_, Some([inner])) => (inner.clone(), Ty::option(ctx.fresh_var())),
        _ => {
            ctx.errors.push(TypeError::TryOnNonResultOption {
                operand_ty: resolved,
                span,
            });
            return Ok(ctx.fresh_var());
        }
    };
    let Some(fn_ret) = fn_ret else {
        // No declared return type: the early return is one of the
        // function's returns, joined with its body's type.
        ctx.record_return(EarlyReturn {
            ty: early,
            span,
            try_operand: Some(resolved),
        });
        return Ok(value);
    };
    let before = ctx.errors.len();
    if ctx
        .unify(fn_ret.clone(), early.clone(), ConstraintOrigin::Builtin)
        .is_err()
    {
        ctx.errors.truncate(before);
        // A different error type is fine when it converts to the one the
        // function returns.
        let converts = match (early.args_of("Result"), fn_ret.args_of("Result")) {
            (Some([_, err]), Some([_, fn_err])) => {
                trait_registry.has_impl_with_type_args("From", std::slice::from_ref(err), fn_err)
            }
            _ => false,
        };
        if !converts {
            ctx.errors.push(TypeError::TryIncompatibleReturn {
                operand_ty: resolved,
                fn_return_ty: fn_ret,
                span,
            });
        }
    }
    Ok(value)
}

// ── Helpers ────────────────────────────────────────────────────────────

/// A bare call of a trait method (`hello(dog)`) is that method called on its
/// first argument: it dispatches by the argument's type, and a name two of
/// the type's interfaces provide is ambiguous (E0027), as in `dog.hello()`.
/// `None` when the call is not one (a local, a function, or a receiver
/// whose type is not known yet).
fn infer_bare_method_call(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    call: &CallExpr,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &FxHashMap<String, FnConstraints>,
) -> Result<Option<Ty>, TypeError> {
    let Some(Expr::NameRef(name_ref)) = call.callee() else {
        return Ok(None);
    };
    let name = name_ref.text().unwrap_or_default();
    let args = call.args();
    // The test DSL's names are global builtins, and too common to take from
    // every program: an interface method called `describe` wins over them.
    const TEST_DSL_NAMES: &[&str] = &["test", "describe", "setup", "teardown"];
    let is_method_name = env.lookup(&name).is_none()
        || ctx.trait_method_fns.contains(&name)
        || TEST_DSL_NAMES.contains(&name.as_str());
    if env.is_local(&name) || !is_method_name {
        return Ok(None);
    }
    if args.is_empty() {
        // A static method (`fn version() -> Int`) called bare names one
        // impl only when a single type provides it.
        let impls = trait_registry.impls_with_static_method(&name);
        if impls.len() > 1 {
            let err = TypeError::AmbiguousStaticMethod {
                method: name,
                types: impls.iter().map(|imp| imp.impl_type_name.clone()).collect(),
                span: name_ref.syntax().text_range(),
            };
            ctx.errors.push(err.clone());
            return Err(err);
        }
        return Ok(None);
    }
    let receiver = infer_expr(
        ctx,
        env,
        &args[0],
        types,
        type_registry,
        trait_registry,
        fn_constraints,
    )?;
    let resolved = ctx.resolve(receiver.clone());
    let span = name_ref.syntax().text_range();
    let method_ty = if is_type_var(&resolved) {
        // A method of a type parameter's `where` bound: `show(x)` under
        // `where T: Show` works for every `T`, not only the types with impls.
        let mut bound = None;
        for (param, trait_name) in ctx.where_bounds.clone() {
            if ctx.resolve(param) != resolved {
                continue;
            }
            if let Some(sig) = trait_registry
                .get_trait(&trait_name)
                .and_then(|def| def.methods.iter().find(|m| m.name == name))
            {
                bound = Some((trait_name, sig.clone()));
                break;
            }
        }
        let Some((trait_name, sig)) = bound else {
            return Ok(None);
        };
        trait_method_type(ctx, &trait_name, &sig, &resolved)
    } else {
        let traits = trait_registry.find_method_traits(&name, &resolved);
        if traits.len() > 1 {
            let err = TypeError::AmbiguousMethod {
                method_name: name,
                candidate_traits: traits,
                ty: resolved,
                span,
            };
            ctx.errors.push(err.clone());
            return Err(err);
        }
        if traits.is_empty() {
            // A trait's method, of a value whose type lacks the trait: it
            // was "undefined variable `inspect`".
            let declaring = trait_registry.traits_declaring(&name);
            let Some(trait_name) = declaring.into_iter().next() else {
                return Ok(None);
            };
            let origin = ConstraintOrigin::Expr {
                span: call.syntax().text_range(),
            };
            let err = trait_not_satisfied(ctx, resolved.with_holes(), trait_name, origin);
            ctx.errors.push(err.clone());
            return Err(err);
        }
        let Some(ret) = method_return_type(ctx, trait_registry, &name, &resolved, span) else {
            return Ok(None);
        };
        build_method_fn_type(trait_registry, &name, &resolved, &ret, ctx)
    };
    let mut arg_tys = vec![receiver];
    for arg in &args[1..] {
        arg_tys.push(infer_expr(
            ctx,
            env,
            arg,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        )?);
    }
    let result = ctx.fresh_var();
    ctx.unify(
        method_ty.clone(),
        Ty::Fun(arg_tys, Box::new(result.clone())),
        ConstraintOrigin::Expr {
            span: call.syntax().text_range(),
        },
    )?;
    types.insert(span, method_ty);
    Ok(Some(ctx.resolve(result)))
}

/// What the trait method `method` returns for a receiver of type `ty`. When
/// several impls provide it with different return types (`Convert<Int>` and
/// `Convert<String>` for one type, or `.into()`), the call's context picks
/// one: its type is left open here and checked when the function is done.
fn method_return_type(
    ctx: &mut InferCtx,
    trait_registry: &TraitRegistry,
    method: &str,
    ty: &Ty,
    span: TextRange,
) -> Option<Ty> {
    let mut returns: Vec<Ty> = Vec::new();
    for (_, ret) in trait_registry.impls_providing(method, ty) {
        if let Some(ret) = ret {
            if !returns.contains(&ret) {
                returns.push(ret);
            }
        }
    }
    if returns.len() > 1 {
        let chosen = ctx.fresh_var();
        ctx.impl_choices.push(ImplChoice {
            result: chosen.clone(),
            method: method.to_string(),
            receiver: ty.clone(),
            candidates: returns,
            span,
            by_argument: false,
        });
        return Some(chosen);
    }
    trait_registry.resolve_trait_method(method, ty)
}

/// Whether two resolved types are the same, a non-generic struct written
/// either way (`Point`, or `Point` applied to no arguments).
fn same_nominal_type(a: &Ty, b: &Ty) -> bool {
    fn nominal(ty: &Ty) -> &Ty {
        match ty {
            Ty::App(con, args) if args.is_empty() => con,
            other => other,
        }
    }
    nominal(a) == nominal(b)
}

/// Each method call that several impls could answer must have been given
/// one of their return types by its context, and each call of a static
/// method they take different arguments for (`Meters.from(x)`) an argument
/// one of them takes.
fn check_impl_choices(ctx: &mut InferCtx, choices: Vec<ImplChoice>) {
    for choice in choices {
        let result = ctx.resolve(choice.result);
        if !choice
            .candidates
            .iter()
            .any(|candidate| same_nominal_type(candidate, &result))
        {
            let found = (!result.has_type_vars()).then_some(result);
            let receiver = ctx.resolve(choice.receiver);
            ctx.errors.push(TypeError::AmbiguousImplMethod {
                method: choice.method,
                receiver,
                candidates: choice.candidates,
                found,
                span: choice.span,
                by_argument: choice.by_argument,
            });
        }
    }
}

/// A declared type parameter stands for every type: the function's body may
/// not fix it (`fn bad<T>(x :: T) -> T do 5 end`) nor make two parameters
/// one type. Checked before the function's callers' uses are unified in.
fn check_rigid_type_params(ctx: &mut InferCtx, fn_: &FnDef, type_params: &FxHashMap<String, Ty>) {
    let span = fn_
        .syntax()
        .children()
        .find(|n| n.kind() == SyntaxKind::GENERIC_PARAM_LIST)
        .map(|n| n.text_range())
        .unwrap_or_else(|| fn_.syntax().text_range());
    let mut names: Vec<&String> = type_params.keys().collect();
    names.sort();
    let mut seen: Vec<(Ty, String)> = Vec::new();
    for name in names {
        let resolved = ctx.resolve(type_params[name].clone());
        if matches!(resolved, Ty::Nat(_)) {
            continue;
        }
        let found = if !is_type_var(&resolved) {
            Some(resolved.clone())
        } else {
            seen.iter()
                .find(|(ty, _)| *ty == resolved)
                .map(|(_, other)| Ty::Con(TyCon::new(other)))
        };
        match found {
            Some(found) => ctx.errors.push(TypeError::RigidTypeParam {
                param: name.clone(),
                found,
                span,
            }),
            None => seen.push((resolved, name.clone())),
        }
    }
}

/// Each builtin `default()` call must have been given a type by its context
/// (a declared type parameter counts: its callers fix it), and that type
/// must implement Default.
fn check_default_calls(
    ctx: &mut InferCtx,
    type_params: &FxHashMap<String, Ty>,
    trait_registry: &TraitRegistry,
    calls: Vec<(Ty, TextRange)>,
) {
    for (ty, span) in calls {
        let built = ctx.resolve(ty);
        let is_param = type_params
            .values()
            .any(|param| ctx.resolve(param.clone()) == built);
        if is_param {
            continue;
        }
        if built.has_type_vars() {
            ctx.errors.push(TypeError::AmbiguousDefault { span });
        } else if !trait_registry.has_impl("Default", &built) {
            ctx.errors.push(trait_not_satisfied(
                ctx,
                built,
                "Default".to_string(),
                ConstraintOrigin::Expr { span },
            ));
        }
    }
}

/// A generic function's body applies an operator to a value of its type
/// parameter `T`: the parameter needs the operator's trait as a bound
/// (`where T: Ord`), or a call at a type without it would compile to
/// nothing. `Ord` includes `Eq`.
fn check_type_param_bounds(
    ctx: &mut InferCtx,
    type_params: &FxHashMap<String, Ty>,
    constraints: &[(String, String)],
    trait_registry: &TraitRegistry,
    uses: Vec<(Ty, String, ConstraintOrigin)>,
) -> Vec<(Ty, String)> {
    let mut reported = FxHashSet::default();
    let mut inferred = Vec::new();
    for (ty, trait_name, origin) in uses {
        let used = ctx.resolve(ty);
        // What `Json.encode` takes: a `Json` value, or one `deriving(Json)`
        // could store. A type left open is encoded by its instances.
        if trait_name == "Json" {
            let encodable = matches!(&used, Ty::Con(c) if c.name == "Json")
                || is_json_serializable(&used, &[], &ctx.json_types, trait_registry);
            if !used.has_type_vars() && !encodable {
                ctx.errors
                    .push(trait_not_satisfied(ctx, used, trait_name, origin));
            }
            continue;
        }
        // A type fixed only later must still implement the trait, and one
        // left partly open must have an instance that could: no `Queue`
        // implements Display, whatever it holds.
        if !is_type_var(&used) && !trait_registry.has_impl(&trait_name, &used) {
            let err = trait_not_satisfied(ctx, used.with_holes(), trait_name, origin);
            ctx.errors.push(err);
            continue;
        }
        if !used.has_type_vars() {
            continue;
        }
        let Some(param) = type_params
            .iter()
            .find(|(_, param_ty)| ctx.resolve((*param_ty).clone()) == used)
            .map(|(name, _)| name.clone())
        else {
            // A type inference left open: the callers' arguments decide.
            if is_type_var(&used) && !inferred.contains(&(used.clone(), trait_name.clone())) {
                inferred.push((used, trait_name));
            }
            continue;
        };
        let bounded = constraints.iter().any(|(bound_param, bound)| {
            *bound_param == param
                && (*bound == trait_name || (trait_name == "Eq" && bound == "Ord"))
        });
        if !bounded && reported.insert((param.clone(), trait_name.clone())) {
            ctx.errors.push(TypeError::UnboundedTypeParam {
                param,
                trait_name,
                origin,
            });
        }
    }
    inferred
}

/// A function's `where` bounds as (type parameter variable, trait) pairs.
fn where_bounds(
    constraints: &[(String, String)],
    type_params: &FxHashMap<String, Ty>,
) -> Vec<(Ty, String)> {
    constraints
        .iter()
        .filter_map(|(param, trait_name)| {
            type_params
                .get(param)
                .map(|ty| (ty.clone(), trait_name.clone()))
        })
        .collect()
}

/// A trait method's declared type with `Self` taken as `receiver`. What
/// cannot be known without the implementing type (`Self.Item`) is left open.
fn trait_method_type(
    ctx: &mut InferCtx,
    trait_name: &str,
    sig: &TraitMethodSig,
    receiver: &Ty,
) -> Ty {
    fn subst(ctx: &mut InferCtx, trait_name: &str, ty: &Ty, receiver: &Ty) -> Ty {
        ty.replace_cons(&mut |tc| {
            if tc.name == "Self" {
                return Some(receiver.clone());
            }
            let assoc = tc.name.strip_prefix("Self.")?;
            // In the interface's own default methods, `Self.Item` is what
            // the implementing type makes it, as `Self` is.
            if receiver.con_name() == Some("Self") {
                return None;
            }
            // Beside the type parameter, so that a `let` holding it keeps
            // this variable, which specializations bind.
            let var = ctx.fresh_var_beside(receiver);
            ctx.assoc_projections.push((
                var.clone(),
                trait_name.to_string(),
                assoc.to_string(),
                receiver.clone(),
            ));
            // Whatever the call's use takes it for, it is the receiver's
            // associated type once the receiver is known.
            let span = ctx.expr_spans.last().copied();
            ctx.projection_requirements.push((
                var.clone(),
                trait_name.to_string(),
                assoc.to_string(),
                receiver.clone(),
                span,
            ));
            Some(var)
        })
    }
    let ret = match &sig.return_type {
        Some(ret) => subst(ctx, trait_name, ret, receiver),
        None => ctx.fresh_var(),
    };
    let mut params = vec![receiver.clone()];
    match &sig.param_types {
        Some(declared) => {
            for param in declared {
                params.push(subst(ctx, trait_name, param, receiver));
            }
        }
        None => {
            for _ in 0..sig.param_count {
                params.push(ctx.fresh_var());
            }
        }
    }
    Ty::Fun(params, Box::new(ret))
}

/// A function's `where` clause as (type parameter, trait) pairs.
fn extract_where_constraints(fn_: &FnDef) -> Vec<(String, String)> {
    // A where clause's nodes are its bounds, `T: Trait`; one the parser
    // could not finish names no trait.
    fn_.syntax()
        .children()
        .filter(|child| child.kind() == SyntaxKind::WHERE_CLAUSE)
        .flat_map(|clause| clause.children())
        .filter_map(|bound| {
            let mut names = bound
                .children_with_tokens()
                .filter_map(|t| t.into_token())
                .filter(|t| t.kind() == SyntaxKind::IDENT);
            let type_param = names.next()?.text().to_string();
            let trait_name = names.next()?.text().to_string();
            Some((type_param, trait_name))
        })
        .collect()
}

/// The declared type parameter an annotation consists of, if it is exactly
/// one: `x :: T`, but not `x :: T?` or `-> (T, U)`, which only start with it.
fn annotation_type_param(
    ann: &mesh_parser::ast::item::TypeAnnotation,
    type_params: &FxHashMap<String, Ty>,
) -> Option<String> {
    let mut tokens = Vec::new();
    collect_annotation_tokens(ann.syntax(), &mut tokens);
    match tokens.as_slice() {
        [(SyntaxKind::IDENT, name)] | [(SyntaxKind::ARROW, _), (SyntaxKind::IDENT, name)]
            if type_params
                .get(name)
                .is_some_and(|ty| !matches!(ty, Ty::Nat(_))) =>
        {
            Some(name.clone())
        }
        _ => None,
    }
}

/// Resolve a type annotation using the type registry (supports struct types, aliases).
fn resolve_type_annotation(
    ctx: &mut InferCtx,
    ann: &mesh_parser::ast::item::TypeAnnotation,
    type_registry: &TypeRegistry,
) -> Option<Ty> {
    // Collect all significant tokens from the annotation to parse the full type.
    let mut tokens: Vec<(SyntaxKind, String)> = Vec::new();
    collect_annotation_tokens(ann.syntax(), &mut tokens);
    if tokens.is_empty() {
        return None;
    }
    // Skip leading ARROW (`->`) or COLON_COLON (`::`) prefix tokens that are
    // part of the TYPE_ANNOTATION node but not part of the type itself.
    let mut start = 0;
    if start < tokens.len() && matches!(tokens[start].0, SyntaxKind::ARROW) {
        start += 1;
    }
    if start >= tokens.len() {
        return None;
    }
    let ty = parse_type_tokens(&tokens, &mut start);
    let ty = match check_indexed_type(ty, ann.syntax(), type_registry, annotated_type_range(ann)) {
        Ok(ty) => ty,
        Err(error) => {
            ctx.errors.push(error);
            return Some(Ty::Never);
        }
    };
    // Counted as written: what an alias expands to is counted where the
    // alias is defined.
    if let Some((name, expected, found)) = wrong_type_argument_count(&ty, type_registry) {
        ctx.errors.push(TypeError::TypeArgumentCount {
            name,
            expected,
            found,
            span: annotated_type_range(ann),
        });
    }
    let ty = resolve_alias(ctx, ty, type_registry);
    let ty = infer_missing_type_args(ctx, ty, type_registry);
    if !contains_indexed_type(&ty) {
        return Some(ty);
    }
    Some(ty.replace_cons(&mut |con| {
        ctx.rigid_params.iter().rev().find_map(|(ty, name)| {
            (name == &con.name && con.indexed_origin.is_none()).then(|| ty.clone())
        })
    }))
}

/// Where an annotation names its type: without the `::` or `->` before it.
fn annotated_type_range(ann: &mesh_parser::ast::item::TypeAnnotation) -> TextRange {
    let range = significant_range(ann.syntax());
    let start = ann
        .syntax()
        .children_with_tokens()
        .find(|element| {
            !element.kind().is_trivia()
                && !matches!(element.kind(), SyntaxKind::COLON_COLON | SyntaxKind::ARROW)
        })
        .map_or(range.start(), |element| element.text_range().start());
    TextRange::new(start, range.end())
}

/// How many type arguments the type `name` takes: a built-in generic type's
/// number, or a struct's, sum type's or alias's (none for one without
/// parameters).
/// `None` for any other type.
fn type_arity(name: &str, type_registry: &TypeRegistry) -> Option<usize> {
    match name {
        "List" | "Set" | "Queue" | "Iter" | "Option" | "Pid" | "Channel" => Some(1),
        "Map" | "Result" => Some(2),
        _ => declared_param_count(type_registry, name).or_else(|| {
            type_registry
                .lookup_alias(name)
                .map(|alias| alias.generic_params.len())
        }),
    }
}

/// How many type parameters the struct or sum type `name` declares.
fn declared_param_count(type_registry: &TypeRegistry, name: &str) -> Option<usize> {
    type_registry
        .lookup_struct(name)
        .map(|def| def.generic_params.len())
        .or_else(|| {
            type_registry
                .lookup_sum_type(name)
                .map(|def| def.generic_params.len())
        })
}

/// The type constructor `con` applied to `count` arguments not known yet,
/// or `con` itself when it takes none.
fn with_unknown_args(ctx: &mut InferCtx, con: Ty, count: usize) -> Ty {
    if count == 0 {
        return con;
    }
    Ty::App(Box::new(con), (0..count).map(|_| ctx.fresh_var()).collect())
}

/// The first type in `ty` named with another number of type arguments than
/// it takes: its name, how many it takes, and how many it was given.
fn wrong_type_argument_count(
    ty: &Ty,
    type_registry: &TypeRegistry,
) -> Option<(String, usize, usize)> {
    if let Ty::App(con, args) = ty {
        let name = con.con_name().unwrap_or_default();
        if let Some(expected) = type_arity(name, type_registry) {
            if expected != args.len() {
                return Some((name.to_string(), expected, args.len()));
            }
        }
    }
    ty.parts()
        .find_map(|part| wrong_type_argument_count(part, type_registry))
}

/// A generic type named without its arguments, as in `xs :: List`, takes
/// arguments to be inferred: `List<_>`. (It was the unrelated bare type,
/// which no value has.) So does one named with the wrong number of them,
/// which is reported where it is named. An untyped `Pid` is a type of its
/// own.
fn infer_missing_type_args(ctx: &mut InferCtx, ty: Ty, type_registry: &TypeRegistry) -> Ty {
    let fresh = |ctx: &mut InferCtx, con: Box<Ty>, arity: usize| {
        let args = (0..arity).map(|_| ctx.fresh_var()).collect();
        Ty::App(con, args)
    };
    match ty {
        Ty::Con(tc) => match type_arity(&tc.name, type_registry) {
            Some(arity) if arity > 0 && tc.name != "Pid" => {
                fresh(ctx, Box::new(Ty::Con(tc)), arity)
            }
            _ => Ty::Con(tc),
        },
        Ty::App(con, args) => {
            let arity = con
                .con()
                .filter(|con| con.indexed_origin.is_none())
                .and_then(|con| type_arity(&con.name, type_registry));
            match arity {
                Some(arity) if arity != args.len() => fresh(ctx, con, arity),
                // The constructor of `List<Int>` has its arguments.
                _ => Ty::App(
                    con,
                    args.into_iter()
                        .map(|arg| infer_missing_type_args(ctx, arg, type_registry))
                        .collect(),
                ),
            }
        }
        other => other.map_parts(|part| infer_missing_type_args(ctx, part.clone(), type_registry)),
    }
}

/// Collect significant tokens (IDENT, LT, GT, COMMA, QUESTION, BANG,
/// L_PAREN, R_PAREN, DOT) from a TYPE_ANNOTATION node tree.
/// DOT is included so that qualified type names like `Types.UserId` are
/// collected as `[IDENT("Types"), DOT("."), IDENT("UserId")]` and can be
/// joined into a qualified lookup key by `parse_type_tokens`.
fn collect_annotation_tokens(
    node: &mesh_parser::SyntaxNode,
    tokens: &mut Vec<(SyntaxKind, String)>,
) {
    if node.kind() == SyntaxKind::OWNERSHIP_MODIFIER {
        return;
    }
    for child in node.children_with_tokens() {
        collect_type_element(child, tokens);
    }
}

/// The significant tokens of one element of a written type.
fn collect_type_element(
    element: mesh_parser::SyntaxElement,
    tokens: &mut Vec<(SyntaxKind, String)>,
) {
    match element {
        rowan::NodeOrToken::Token(t) => {
            let kind = t.kind();
            if matches!(
                kind,
                SyntaxKind::IDENT
                    | SyntaxKind::INT_LITERAL
                    | SyntaxKind::LT
                    | SyntaxKind::GT
                    | SyntaxKind::COMMA
                    | SyntaxKind::QUESTION
                    | SyntaxKind::BANG
                    | SyntaxKind::L_PAREN
                    | SyntaxKind::R_PAREN
                    | SyntaxKind::ARROW
                    | SyntaxKind::DOT
            ) {
                tokens.push((kind, t.text().to_string()));
            }
        }
        rowan::NodeOrToken::Node(n) => collect_annotation_tokens(&n, tokens),
    }
}

/// The type written after the `=` of `node`: `String` in `type Url =
/// String`, `List<Int>` in an impl's `type Item = List<Int>`.
fn type_after_eq(node: &mesh_parser::SyntaxNode) -> Option<Ty> {
    let mut tokens = Vec::new();
    node.children_with_tokens()
        .skip_while(|element| element.kind() != SyntaxKind::EQ)
        .skip(1)
        .for_each(|element| collect_type_element(element, &mut tokens));
    (!tokens.is_empty()).then(|| parse_type_tokens(&tokens, &mut 0))
}

/// Parse a Ty from a flat list of significant tokens.
fn parse_type_tokens(tokens: &[(SyntaxKind, String)], pos: &mut usize) -> Ty {
    if *pos >= tokens.len() {
        return Ty::Never;
    }

    // Tuple: (A, B)
    if tokens[*pos].0 == SyntaxKind::L_PAREN {
        *pos += 1;
        let mut elems = Vec::new();
        while *pos < tokens.len() && tokens[*pos].0 != SyntaxKind::R_PAREN {
            elems.push(parse_type_tokens(tokens, pos));
            if *pos < tokens.len() && tokens[*pos].0 == SyntaxKind::COMMA {
                *pos += 1;
            }
        }
        if *pos < tokens.len() && tokens[*pos].0 == SyntaxKind::R_PAREN {
            *pos += 1;
        }
        let base = Ty::Tuple(elems);
        return apply_type_sugar(tokens, pos, base);
    }

    if tokens[*pos].0 == SyntaxKind::INT_LITERAL {
        let value = parse_nat_literal(&tokens[*pos].1).unwrap_or_default();
        *pos += 1;
        return Ty::Nat(NatIndex::Literal(value));
    }

    if tokens[*pos].0 != SyntaxKind::IDENT {
        *pos += 1;
        return Ty::Never;
    }

    let mut name = tokens[*pos].1.clone();
    *pos += 1;

    // Qualified type name: Module.TypeName  (e.g. Types.UserId)
    // When we encounter IDENT DOT IDENT, join them into "Module.TypeName" so
    // that the lookup key matches the qualified alias registered from imports.
    while *pos + 1 < tokens.len()
        && tokens[*pos].0 == SyntaxKind::DOT
        && tokens[*pos + 1].0 == SyntaxKind::IDENT
    {
        name.push('.');
        name.push_str(&tokens[*pos + 1].1);
        *pos += 2; // consume DOT and IDENT
    }

    // Function type: Fun(ParamTypes) -> ReturnType
    if name == "Fun" && *pos < tokens.len() && tokens[*pos].0 == SyntaxKind::L_PAREN {
        *pos += 1; // skip (
        let mut param_tys = Vec::new();
        while *pos < tokens.len() && tokens[*pos].0 != SyntaxKind::R_PAREN {
            param_tys.push(parse_type_tokens(tokens, pos));
            if *pos < tokens.len() && tokens[*pos].0 == SyntaxKind::COMMA {
                *pos += 1;
            }
        }
        if *pos < tokens.len() && tokens[*pos].0 == SyntaxKind::R_PAREN {
            *pos += 1; // skip )
        }
        // Expect ->
        if *pos < tokens.len() && tokens[*pos].0 == SyntaxKind::ARROW {
            *pos += 1; // skip ->
        }
        let ret_ty = parse_type_tokens(tokens, pos);
        return Ty::Fun(param_tys, Box::new(ret_ty));
    }

    // Generic args: Name<A, B>
    let base = if *pos < tokens.len() && tokens[*pos].0 == SyntaxKind::LT {
        *pos += 1;
        Ty::App(
            Box::new(Ty::Con(TyCon::new(&name))),
            parse_type_args(tokens, pos),
        )
    } else {
        name_to_type(&name)
    };

    apply_type_sugar(tokens, pos, base)
}

/// The types of a written argument list whose `<` is read, through its `>`.
fn parse_type_args(tokens: &[(SyntaxKind, String)], pos: &mut usize) -> Vec<Ty> {
    let mut args = Vec::new();
    while *pos < tokens.len() && tokens[*pos].0 != SyntaxKind::GT {
        args.push(parse_type_tokens(tokens, pos));
        if *pos < tokens.len() && tokens[*pos].0 == SyntaxKind::COMMA {
            *pos += 1;
        }
    }
    if *pos < tokens.len() && tokens[*pos].0 == SyntaxKind::GT {
        *pos += 1;
    }
    args
}

/// Apply sugar postfix: `?` for Option, `!` for Result.
fn apply_type_sugar(tokens: &[(SyntaxKind, String)], pos: &mut usize, base: Ty) -> Ty {
    if *pos < tokens.len() && tokens[*pos].0 == SyntaxKind::QUESTION {
        *pos += 1;
        Ty::option(base)
    } else if *pos < tokens.len() && tokens[*pos].0 == SyntaxKind::BANG {
        *pos += 1;
        let err_ty = parse_type_tokens(tokens, pos);
        Ty::result(base, err_ty)
    } else {
        base
    }
}

/// Recursively resolve type aliases, including aliases an alias expands
/// to (`type Twin<T> = Pair<T, T>`).
fn resolve_alias(ctx: &mut InferCtx, ty: Ty, type_registry: &TypeRegistry) -> Ty {
    resolve_alias_within(ctx, ty, type_registry, 0)
}

/// `resolve_alias` at nesting `depth`; an alias that keeps expanding into
/// itself stops at a fixed depth instead of recursing forever.
fn resolve_alias_within(
    ctx: &mut InferCtx,
    ty: Ty,
    type_registry: &TypeRegistry,
    depth: usize,
) -> Ty {
    const MAX_DEPTH: usize = 64;
    if depth > MAX_DEPTH || ty.is_proof() {
        return ty;
    }
    let again =
        |ctx: &mut InferCtx, ty: Ty| resolve_alias_within(ctx, ty, type_registry, depth + 1);
    let Some(tc) = ty.con().cloned() else {
        return ty.map_parts(|part| again(ctx, part.clone()));
    };
    let applied = matches!(ty, Ty::App(..));
    let args: Vec<Ty> = match ty {
        Ty::App(_, args) => args.into_iter().map(|arg| again(ctx, arg)).collect(),
        _ => Vec::new(),
    };
    if tc.indexed_origin.is_some() {
        return Ty::App(Box::new(Ty::Con(tc)), args);
    }
    if let Some(alias) = type_registry.lookup_alias(&tc.name) {
        // Named with another number of arguments than it takes (reported
        // where it is written) or with none, its parameters are not known.
        let args = if args.len() == alias.generic_params.len() {
            args
        } else {
            alias
                .generic_params
                .iter()
                .map(|_| ctx.fresh_var())
                .collect()
        };
        let expanded = substitute_type_params(&alias.aliased_type, &alias.generic_params, &args);
        return again(ctx, expanded);
    }
    // An imported struct or sum type named through its module (`Geo.Point`)
    // is registered under its own name.
    let tc = match tc.name.rsplit_once('.') {
        Some((_, short))
            if type_registry.lookup_struct(short).is_some()
                || type_registry.lookup_sum_type(short).is_some() =>
        {
            TyCon::new(short)
        }
        _ => tc,
    };
    // An iterator handle's old name (`-> ListIterator`) is `Iter`, whose
    // element type is inferred where it is left out, as a bare `List`'s
    // is. (A type of its own had no element type: its elements were read
    // as `()`, or as raw bits.)
    let tc = match tc.name.as_str() {
        "ListIterator" | "MapIterator" | "SetIterator" | "RangeIterator"
            if declared_param_count(type_registry, &tc.name).is_none() =>
        {
            TyCon::new("Iter")
        }
        _ => tc,
    };
    // `Unit`, as the documentation writes it (`Result<Unit, String>`), is
    // `()`: it was a type of its own, which nothing returns.
    if tc.name == "Unit" && !applied && declared_param_count(type_registry, "Unit").is_none() {
        return Ty::Tuple(Vec::new());
    }
    if applied {
        Ty::App(Box::new(Ty::Con(tc)), args)
    } else {
        Ty::Con(tc)
    }
}

/// Replace the function's declared type parameters, which an annotation such
/// as `List<T>` resolves to plain constructors named `T`, with the inference
/// variables that stand for them in the body.
fn with_declared_type_params(ty: &Ty, type_params: &FxHashMap<String, Ty>) -> Ty {
    ty.replace_cons(&mut |tc| {
        if tc.indexed_origin.is_some() {
            return None;
        }
        type_params.get(&tc.name).cloned()
    })
}

/// `ty` with each of the type parameters `param_names` that
/// `param_values` gives a type for replaced by it.
fn substitute_type_params(ty: &Ty, param_names: &[String], param_values: &[Ty]) -> Ty {
    ty.replace_cons(&mut |tc| {
        if tc.indexed_origin.is_some() {
            return None;
        }
        let index = param_names.iter().position(|name| *name == tc.name)?;
        param_values.get(index).cloned()
    })
}

/// Convert a type name string to a Ty.
fn name_to_type(name: &str) -> Ty {
    match name {
        "Int" => Ty::int(),
        "Float" => Ty::float(),
        "String" => Ty::string(),
        "Bool" => Ty::bool(),
        other => Ty::Con(TyCon::new(other)),
    }
}

/// Check if a type is an unresolved type variable.
fn is_type_var(ty: &Ty) -> bool {
    matches!(ty, Ty::Var(_))
}

/// Infer the type of a json literal expression.
///
/// Type-checks each field value for compile-time error detection (e.g. undefined
/// variables produce type errors). Returns `Ty::json()` which is the `Json` newtype.
///
/// `Json` auto-coerces to `String` at use sites via the unify rules in unify.rs,
/// so `HTTP.response(200, json { status: "ok" })` works without explicit conversion.
fn infer_json_expr(
    ctx: &mut InferCtx,
    env: &mut TypeEnv,
    json_expr: &JsonExpr,
    types: &mut FxHashMap<TextRange, Ty>,
    type_registry: &TypeRegistry,
    trait_registry: &TraitRegistry,
    fn_constraints: &FxHashMap<String, FnConstraints>,
) -> Result<Ty, TypeError> {
    // Each value must be one JSON holds, as `Json.encode`'s argument must
    // (checked once its type is known): a struct deriving nothing was
    // written as `null`. `nil` is null.
    for field in json_expr.fields() {
        let val_expr = field.value().ok_or_else(incomplete)?;
        let ty = infer_expr(
            ctx,
            env,
            &val_expr,
            types,
            type_registry,
            trait_registry,
            fn_constraints,
        )?;
        if ctx.resolve(ty.clone()) != Ty::Tuple(vec![]) {
            let span = val_expr.syntax().text_range();
            ctx.operand_traits
                .push((ty, "Json".to_string(), ConstraintOrigin::Expr { span }));
        }
    }
    // A Json, not its text: passed where a String is expected, a Json is
    // encoded there (`json_as_text`).
    Ok(Ty::json())
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Abstract patterns read as they are written: an or-pattern's
    /// alternatives joined by `|` (the witnesses a missing-pattern error
    /// shows are built without them).
    #[test]
    fn abstract_patterns_read_as_written() {
        let pattern = AbsPat::Or {
            alternatives: vec![
                AbsPat::Literal {
                    value: "1".to_string(),
                    ty: AbsLitKind::Int,
                },
                AbsPat::Constructor {
                    name: "Some".to_string(),
                    type_name: "Option".to_string(),
                    args: vec![AbsPat::Wildcard],
                },
            ],
        };
        assert_eq!(
            format_abstract_pat(&pattern, &TypeRegistry::new()),
            "1 | Some(_)"
        );
    }
}
