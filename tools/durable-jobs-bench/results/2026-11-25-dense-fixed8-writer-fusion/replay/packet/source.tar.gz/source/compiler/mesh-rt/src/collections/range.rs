//! GC-managed Range for the Mesh runtime.
//!
//! A Range represents a half-open interval `[start, end)` of integers.
//! Layout: `{ i64 start, i64 end }` (16 bytes total).
//!
//! Ranges support conversion to List and higher-order operations (map, filter).

use crate::callback::call1;
use crate::gc::mesh_gc_alloc_actor;

// ── Internal helpers ──────────────────────────────────────────────────

unsafe fn range_start(r: *const u8) -> i64 {
    *(r as *const i64)
}

unsafe fn range_end(r: *const u8) -> i64 {
    *((r as *const i64).add(1))
}

/// A list builder with room for the range's elements (at most a million
/// up front: the builder grows). Appending one element at a time copied
/// the list each time, which took quadratic time.
unsafe fn range_builder(start: i64, end: i64) -> *mut u8 {
    let len = (end as i128 - start as i128).clamp(0, 1 << 20);
    super::list::mesh_list_builder_new(len as i64)
}

// ── Public API ────────────────────────────────────────────────────────

/// Create a new range `[start, end)`.
#[no_mangle]
pub extern "C-unwind" fn mesh_range_new(start: i64, end: i64) -> *mut u8 {
    unsafe {
        let p = mesh_gc_alloc_actor(16, 8);
        *(p as *mut i64) = start;
        *((p as *mut i64).add(1)) = end;
        p
    }
}

/// Convert a range to a List of integers.
#[no_mangle]
pub extern "C-unwind" fn mesh_range_to_list(range: *mut u8) -> *mut u8 {
    unsafe {
        let start = range_start(range);
        let end = range_end(range);
        let mut list = range_builder(start, end);
        let mut i = start;
        while i < end {
            list = super::list::mesh_list_builder_push(list, i as u64);
            i += 1;
        }
        list
    }
}

/// Apply a closure to each element of the range, returning a List.
#[no_mangle]
pub extern "C-unwind" fn mesh_range_map(
    range: *mut u8,
    fn_ptr: *mut u8,
    env_ptr: *mut u8,
) -> *mut u8 {
    unsafe {
        let start = range_start(range);
        let end = range_end(range);
        let mut list = range_builder(start, end);

        for i in start..end {
            let result = call1(fn_ptr, env_ptr, i as u64);
            list = super::list::mesh_list_builder_push(list, result);
        }
        list
    }
}

/// Filter elements of the range, returning a List of matching integers.
#[no_mangle]
pub extern "C-unwind" fn mesh_range_filter(
    range: *mut u8,
    fn_ptr: *mut u8,
    env_ptr: *mut u8,
) -> *mut u8 {
    unsafe {
        let start = range_start(range);
        let end = range_end(range);
        let mut list = range_builder(start, end);

        for i in start..end {
            if call1(fn_ptr, env_ptr, i as u64) != 0 {
                list = super::list::mesh_list_builder_push(list, i as u64);
            }
        }
        list
    }
}

/// Return the number of elements in the range. A range wider than the
/// largest Int (`-9223372036854775808..1`) has that many: saturated, not
/// wrapped (or, in a debug runtime, an abort).
#[no_mangle]
pub extern "C-unwind" fn mesh_range_length(range: *mut u8) -> i64 {
    unsafe {
        let start = range_start(range);
        let end = range_end(range);
        end.saturating_sub(start).max(0)
    }
}

// ── Iterator handle ───────────────────────────────────────────────────

/// Internal iterator state for Range iteration.
#[repr(C)]
struct RangeIterator {
    tag: u8,
    current: i64,
    end: i64,
}

/// Create a new iterator handle for a range [start, end).
#[no_mangle]
pub extern "C-unwind" fn mesh_range_iter_new(start: i64, end: i64) -> *mut u8 {
    unsafe {
        let iter = mesh_gc_alloc_actor(
            std::mem::size_of::<RangeIterator>() as u64,
            std::mem::align_of::<RangeIterator>() as u64,
        ) as *mut RangeIterator;
        (*iter).tag = 3; // ITER_TAG_RANGE
        (*iter).current = start;
        (*iter).end = end;
        iter as *mut u8
    }
}

/// An iterator over a Range value: what `for i in r` runs for one.
#[no_mangle]
pub extern "C-unwind" fn mesh_range_iter(range: *mut u8) -> *mut u8 {
    unsafe { mesh_range_iter_new(range_start(range), range_end(range)) }
}

/// Advance the range iterator, returning Option (tag 0 = Some, tag 1 = None).
#[no_mangle]
pub extern "C-unwind" fn mesh_range_iter_next(iter_ptr: *mut u8) -> *mut u8 {
    unsafe {
        let iter = iter_ptr as *mut RangeIterator;
        if (*iter).current >= (*iter).end {
            crate::option::alloc_option(1, std::ptr::null_mut()) as *mut u8
        } else {
            let val = (*iter).current;
            (*iter).current += 1;
            crate::option::alloc_option(0, val as usize as *mut u8) as *mut u8
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::collections::list;
    use crate::gc::mesh_rt_init;

    #[test]
    fn test_range_new() {
        mesh_rt_init();
        let r = mesh_range_new(1, 5);
        assert_eq!(mesh_range_length(r), 4);
    }

    #[test]
    fn test_range_length_saturates() {
        mesh_rt_init();
        assert_eq!(mesh_range_length(mesh_range_new(i64::MIN, 1)), i64::MAX);
        assert_eq!(mesh_range_length(mesh_range_new(5, 1)), 0);
    }

    #[test]
    fn test_range_to_list() {
        mesh_rt_init();
        let r = mesh_range_new(1, 4);
        let l = mesh_range_to_list(r);
        assert_eq!(list::mesh_list_length(l), 3);
        assert_eq!(list::mesh_list_get(l, 0), 1);
        assert_eq!(list::mesh_list_get(l, 1), 2);
        assert_eq!(list::mesh_list_get(l, 2), 3);
    }

    #[test]
    fn test_range_map() {
        mesh_rt_init();
        let r = mesh_range_new(1, 4);

        unsafe extern "C-unwind" fn double(x: u64) -> u64 {
            x * 2
        }

        let mapped = mesh_range_map(r, double as *mut u8, std::ptr::null_mut());
        assert_eq!(list::mesh_list_length(mapped), 3);
        assert_eq!(list::mesh_list_get(mapped, 0), 2);
        assert_eq!(list::mesh_list_get(mapped, 1), 4);
        assert_eq!(list::mesh_list_get(mapped, 2), 6);
    }

    #[test]
    fn test_range_filter() {
        mesh_rt_init();
        let r = mesh_range_new(1, 6);

        unsafe extern "C-unwind" fn is_even(x: u64) -> u64 {
            if x.is_multiple_of(2) {
                1
            } else {
                0
            }
        }

        let filtered = mesh_range_filter(r, is_even as *mut u8, std::ptr::null_mut());
        assert_eq!(list::mesh_list_length(filtered), 2);
        assert_eq!(list::mesh_list_get(filtered, 0), 2);
        assert_eq!(list::mesh_list_get(filtered, 1), 4);
    }

    #[test]
    fn test_range_empty() {
        mesh_rt_init();
        let r = mesh_range_new(5, 5);
        assert_eq!(mesh_range_length(r), 0);
        let l = mesh_range_to_list(r);
        assert_eq!(list::mesh_list_length(l), 0);
    }

    #[test]
    fn test_range_inverted() {
        mesh_rt_init();
        let r = mesh_range_new(5, 3);
        assert_eq!(mesh_range_length(r), 0);
    }
}
