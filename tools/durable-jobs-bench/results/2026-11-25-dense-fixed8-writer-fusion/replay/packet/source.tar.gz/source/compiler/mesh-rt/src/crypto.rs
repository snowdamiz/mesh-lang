//! Binary-safe cryptographic primitives and legacy encoding functions.
//!
//! Crypto V2 keeps private material in actor-owned zeroizing resources and
//! exposes raw hash bytes by default. The non-colliding legacy HMAC-SHA-512,
//! UUID, Base64, and Hex exports remain available for existing callers.

pub(crate) mod blind_rsa;
#[cfg(test)]
mod mlkem_tests;
pub(crate) mod provider;

use std::ptr;

use base64::{engine::general_purpose, Engine as _};
use hmac::{Hmac, Mac};
use libcrux_ml_kem::mlkem768::{self, MlKem768Ciphertext, MlKem768PrivateKey, MlKem768PublicKey};
use rand::RngCore;
use sha2::Sha512;
use zeroize::{Zeroize, Zeroizing};

#[cfg(feature = "fuzzing")]
use self::provider::FixedProvider;
use self::provider::{
    CryptoProvider, ProviderError, SystemProvider, MAX_ARGON2_ITERATIONS, MAX_ARGON2_MEMORY_KIB,
    MAX_ARGON2_OUTPUT_BYTES, MAX_ARGON2_PARALLELISM, MAX_ARGON2_SALT_BYTES,
    MIN_ARGON2_OUTPUT_BYTES, MIN_ARGON2_SALT_BYTES,
};
use crate::actor::Process;
use crate::bytes::{decode_base64, decode_hex, hex_string, mesh_bytes_new, MeshBytes};
use crate::gc::mesh_gc_alloc_actor;
use crate::io::{alloc_result, err_result, MeshResult};
use crate::secret::{
    consume_and_retype_owned_resource, consume_owned_resource, crypto_error, insert_owned_resource,
    with_owned_resource, CryptoErrorTag, MeshSecretHandle, ResourceError, ResourceKind,
    RetypeError,
};
use crate::string::{mesh_str, MeshString};

type HmacSha512 = Hmac<Sha512>;

const MAX_INPUT_BYTES: usize = 64 * 1024;
// A secret (a key, a password) is always within the input bound, so an
// operation on one never has to check its length.
const _: () = assert!(crate::secret::MAX_SECRET_BYTES <= MAX_INPUT_BYTES);
const MAX_RANDOM_BYTES: usize = 64 * 1024;
const MAX_HKDF_OUTPUT_BYTES: usize = 255 * 32;
const AEAD_NONCE_BYTES: usize = 12;
const AEAD_TAG_BYTES: usize = 16;
const MAX_AEAD_CIPHERTEXT_BYTES: usize = MAX_INPUT_BYTES + AEAD_TAG_BYTES;
const MLKEM_PRIVATE_SEED_BYTES: usize = 64;
const MLKEM_PUBLIC_KEY_BYTES: usize = 1184;
const MLKEM_CIPHERTEXT_BYTES: usize = 1088;
const MLKEM_SHARED_SECRET_BYTES: usize = 32;
const HPKE_ENCAPSULATED_KEY_BYTES: usize = 32;
const HPKE_MIN_SEALED_BYTES: usize = HPKE_ENCAPSULATED_KEY_BYTES + AEAD_TAG_BYTES;
const MAX_HPKE_INFO_BYTES: usize = MAX_INPUT_BYTES - 64;
// The longest labeled HMAC input HPKE builds, the info hash's, stays within
// HMAC's input bound: no step of the key schedule can be refused.
const _: () = assert!(
    HPKE_VERSION_LABEL.len() + HPKE_SUITE_ID.len() + b"info_hash".len() + MAX_HPKE_INFO_BYTES
        <= MAX_INPUT_BYTES
);
const MAX_HPKE_SEALED_BYTES: usize = HPKE_ENCAPSULATED_KEY_BYTES + MAX_AEAD_CIPHERTEXT_BYTES;
const HPKE_KEM_SUITE_ID: &[u8] = b"KEM\x00\x20";
const HPKE_SUITE_ID: &[u8] = b"HPKE\x00\x20\x00\x01\x00\x03";
const HPKE_VERSION_LABEL: &[u8] = b"HPKE-v1";

#[repr(C)]
/// Runtime representation of an X25519 public-key wrapper.
pub struct MeshX25519PublicKey {
    pub bytes: *mut MeshBytes,
}

#[repr(C)]
/// Runtime representation of an X25519 key pair with an inline public wrapper.
pub struct MeshX25519KeyPair {
    pub private_key: *mut MeshSecretHandle,
    pub public_key: MeshX25519PublicKey,
}

#[repr(C)]
/// Runtime representation of an ML-KEM-768 encapsulation key.
pub struct MeshMlKemPublicKey {
    pub bytes: *mut MeshBytes,
}

#[repr(C)]
/// Runtime representation of an ML-KEM-768 ciphertext.
pub struct MeshMlKemCiphertext {
    pub bytes: *mut MeshBytes,
}

#[repr(C)]
/// Runtime representation of an ML-KEM-768 key pair.
pub struct MeshMlKemKeyPair {
    pub private_key: *mut MeshSecretHandle,
    pub public_key: MeshMlKemPublicKey,
}

#[repr(C)]
struct MeshTuple2Pointers {
    len: u64,
    first: *mut MeshBytes,
    second: *mut MeshSecretHandle,
}

#[cfg(test)]
struct GeneratedX25519KeyPair {
    private_key: *mut MeshSecretHandle,
    public_key: [u8; 32],
}

#[repr(C)]
/// Runtime representation of an Ed25519 public-key wrapper.
pub struct MeshSigningPublicKey {
    pub bytes: *mut MeshBytes,
}

#[repr(C)]
/// Runtime representation of an Ed25519 signature wrapper.
pub struct MeshSignature {
    pub bytes: *mut MeshBytes,
}

#[repr(C)]
/// Runtime representation of a signing key pair with an inline public wrapper.
pub struct MeshSigningKeyPair {
    pub private_key: *mut MeshSecretHandle,
    pub public_key: MeshSigningPublicKey,
}

#[repr(C)]
/// Runtime representation of a blind RSA public key: its RFC 9578 SPKI.
pub struct MeshBlindRsaPublicKey {
    pub bytes: *mut MeshBytes,
}

#[repr(C)]
/// Runtime representation of a blinded message and its affine blinding state.
pub struct MeshBlindRsaBlinded {
    pub blinded: *mut MeshBytes,
    pub state: *mut MeshSecretHandle,
}

#[cfg(test)]
struct GeneratedSigningKeyPair {
    private_key: *mut MeshSecretHandle,
    public_key: [u8; 32],
}

/// A `CryptoError` before it is allocated as a Mesh value.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) struct CryptoFailure {
    pub(crate) tag: CryptoErrorTag,
    pub(crate) expected: i64,
    pub(crate) actual: i64,
}

pub(crate) fn failure(tag: CryptoErrorTag, expected: i64, actual: i64) -> CryptoFailure {
    CryptoFailure {
        tag,
        expected,
        actual,
    }
}

/// The value of a step of a crypto entry point, or a return of the step's
/// failure as the entry point's `Err`.
macro_rules! try_crypto {
    ($step:expr) => {
        match $step {
            Ok(value) => value,
            Err(error) => return error_result(error),
        }
    };
}

pub(crate) fn error_result(error: CryptoFailure) -> *mut MeshResult {
    crypto_error(error.tag, error.expected, error.actual)
}

pub(crate) fn ok_result<T>(value: *mut T) -> *mut MeshResult {
    alloc_result(0, value.cast())
}

/// An entry point's `Result<T, CryptoError>`.
pub(crate) fn crypto_result<T>(value: Result<*mut T, CryptoFailure>) -> *mut MeshResult {
    match value {
        Ok(value) => ok_result(value),
        Err(error) => error_result(error),
    }
}

/// `value` in the running actor's heap, which aborts rather than fail.
fn allocate_value<T>(value: T) -> *mut T {
    let pointer = mesh_gc_alloc_actor(
        std::mem::size_of::<T>() as u64,
        std::mem::align_of::<T>() as u64,
    ) as *mut T;
    unsafe { pointer.write(value) };
    pointer
}

/// A copy of `data` as Bytes: never null, since a slice's length is
/// always one Bytes can have.
pub(crate) fn bytes_value(data: &[u8]) -> *mut MeshBytes {
    mesh_bytes_new(data.as_ptr(), data.len() as u64)
}

fn actual_length(length: u64) -> i64 {
    i64::try_from(length).unwrap_or(i64::MAX)
}

/// The bytes of `bytes`, at most `maximum` of them.
pub(crate) unsafe fn required_bytes<'a>(
    bytes: *const MeshBytes,
    maximum: usize,
) -> Result<&'a [u8], CryptoFailure> {
    if bytes.is_null() {
        return Err(failure(CryptoErrorTag::InvalidLength, maximum as i64, -1));
    }
    let length = (*bytes).len;
    if length > maximum as u64 {
        return Err(failure(
            CryptoErrorTag::InvalidLength,
            maximum as i64,
            actual_length(length),
        ));
    }
    Ok((*bytes).as_slice())
}

/// Exactly `N` bytes of `bytes`; any other length is refused as `tag`.
unsafe fn exact_bytes<'a, const N: usize>(
    bytes: *const MeshBytes,
    tag: CryptoErrorTag,
) -> Result<&'a [u8; N], CryptoFailure> {
    if bytes.is_null() {
        return Err(failure(tag, N as i64, -1));
    }
    <&[u8; N]>::try_from((*bytes).as_slice())
        .map_err(|_| failure(tag, N as i64, actual_length((*bytes).len)))
}

pub(crate) fn resource_failure(error: ResourceError) -> CryptoFailure {
    match error {
        ResourceError::ResourceLimitExceeded => {
            failure(CryptoErrorTag::ResourceLimitExceeded, 0, 0)
        }
        ResourceError::WrongKind => failure(CryptoErrorTag::InvalidKey, 0, 0),
        ResourceError::StaleHandle | ResourceError::WrongOwner | ResourceError::OwnerExited => {
            failure(CryptoErrorTag::SecretDestroyed, 0, 0)
        }
    }
}

/// How a provider's failure is reported. Every length a provider checks is
/// checked before it is called, so its `InvalidLength` is a runtime fault.
pub(crate) fn provider_failure(error: ProviderError) -> CryptoFailure {
    match error {
        ProviderError::EntropyUnavailable => failure(CryptoErrorTag::EntropyUnavailable, 0, 0),
        ProviderError::InvalidLength => failure(CryptoErrorTag::InternalFailure, 0, 0),
        ProviderError::ResourceLimitExceeded => {
            failure(CryptoErrorTag::ResourceLimitExceeded, 0, 0)
        }
        ProviderError::InvalidPublicKey => failure(CryptoErrorTag::InvalidPublicKey, 32, 32),
        ProviderError::AuthenticationFailed => failure(CryptoErrorTag::AuthenticationFailed, 0, 0),
    }
}

/// How a refused retype of secret bytes into a key is reported. The table
/// zeroized the removed material; dropping it frees it.
fn retype_failure(error: RetypeError<CryptoFailure>) -> CryptoFailure {
    match error {
        RetypeError::Resource(error) => resource_failure(error),
        RetypeError::Rejected { error, removed } => {
            drop(removed);
            error
        }
        RetypeError::GenerationExhausted { removed } => {
            drop(removed);
            failure(CryptoErrorTag::ResourceLimitExceeded, 0, 0)
        }
    }
}

fn with_current_process<R>(
    operation: impl FnOnce(&mut Process) -> Result<R, CryptoFailure>,
) -> Result<R, CryptoFailure> {
    let process = crate::actor::current_process()
        .ok_or_else(|| failure(CryptoErrorTag::InternalFailure, 0, 0))?;
    let mut process = process.lock();
    operation(&mut process)
}

unsafe fn valid_bytes<'a>(bytes: *const MeshBytes) -> Option<&'a [u8]> {
    if bytes.is_null() {
        return None;
    }
    Some((*bytes).as_slice())
}

// ── Public ABI ─────────────────────────────────────────────────────────

/// Return the SHA-256 digest of arbitrary valid binary input.
#[no_mangle]
pub extern "C" fn mesh_crypto_sha256(input: *const MeshBytes) -> *mut MeshBytes {
    let Some(input) = (unsafe { valid_bytes(input) }) else {
        return ptr::null_mut();
    };
    let digest = SystemProvider.sha256(input);
    mesh_bytes_new(digest.as_ptr(), digest.len() as u64)
}

/// Return the SHA-512 digest of arbitrary valid binary input.
#[no_mangle]
pub extern "C" fn mesh_crypto_sha512(input: *const MeshBytes) -> *mut MeshBytes {
    let Some(input) = (unsafe { valid_bytes(input) }) else {
        return ptr::null_mut();
    };
    let digest = SystemProvider.sha512(input);
    mesh_bytes_new(digest.as_ptr(), digest.len() as u64)
}

/// Return the SHA-256 digest as lowercase hexadecimal text.
#[no_mangle]
pub extern "C" fn mesh_crypto_sha256_hex(input: *const MeshBytes) -> *mut MeshString {
    let Some(input) = (unsafe { valid_bytes(input) }) else {
        return ptr::null_mut();
    };
    hex_string(&SystemProvider.sha256(input))
}

/// Return the SHA-512 digest as lowercase hexadecimal text.
#[no_mangle]
pub extern "C" fn mesh_crypto_sha512_hex(input: *const MeshBytes) -> *mut MeshString {
    let Some(input) = (unsafe { valid_bytes(input) }) else {
        return ptr::null_mut();
    };
    hex_string(&SystemProvider.sha512(input))
}

fn random_bytes_with_provider(
    provider: &impl CryptoProvider,
    length: i64,
) -> Result<Zeroizing<Vec<u8>>, CryptoFailure> {
    if length < 0 || length as u64 > MAX_RANDOM_BYTES as u64 {
        return Err(failure(
            CryptoErrorTag::InvalidLength,
            MAX_RANDOM_BYTES as i64,
            length,
        ));
    }
    let mut output = Zeroizing::new(vec![0; length as usize]);
    provider
        .fill_random(&mut output)
        .map_err(provider_failure)?;
    Ok(output)
}

/// Return cryptographically secure random bytes from the operating system.
#[no_mangle]
pub extern "C" fn mesh_crypto_random_bytes(length: i64) -> *mut MeshResult {
    crypto_result(
        random_bytes_with_provider(&SystemProvider, length).map(|bytes| bytes_value(&bytes)),
    )
}

fn hmac_sha256_for_process(
    process: &mut Process,
    provider: &impl CryptoProvider,
    key: *const MeshSecretHandle,
    message: *const MeshBytes,
) -> Result<*mut MeshSecretHandle, CryptoFailure> {
    let message = unsafe { required_bytes(message, MAX_INPUT_BYTES) }?;
    let mut output = Zeroizing::new(vec![0; 32].into_boxed_slice());
    let operation = with_owned_resource(process, key, ResourceKind::SecretBytes, |key| {
        let output = <&mut [u8; 32]>::try_from(&mut output[..]).expect("a 32-byte output");
        provider
            .hmac_sha256(key, message, output)
            .map_err(provider_failure)
    })
    .map_err(resource_failure)?;
    operation?;
    insert_owned_resource(process, ResourceKind::SecretBytes, output).map_err(resource_failure)
}

/// Return HMAC-SHA-256 output as an actor-owned secret resource.
#[no_mangle]
pub extern "C" fn mesh_crypto_hmac_sha256(
    key: *const MeshSecretHandle,
    message: *const MeshBytes,
) -> *mut MeshResult {
    crypto_result(with_current_process(|process| {
        hmac_sha256_for_process(process, &SystemProvider, key, message)
    }))
}

fn hmac_sha256_tag_for_process(
    process: &Process,
    provider: &impl CryptoProvider,
    key: *const MeshSecretHandle,
    message: *const MeshBytes,
) -> Result<[u8; 32], CryptoFailure> {
    let message = unsafe { required_bytes(message, MAX_INPUT_BYTES) }?;
    let mut output = [0u8; 32];
    with_owned_resource(process, key, ResourceKind::SecretBytes, |key| {
        provider
            .hmac_sha256(key, message, &mut output)
            .map_err(provider_failure)
    })
    .map_err(resource_failure)??;
    Ok(output)
}

/// HMAC-SHA-256 under a borrowed secret key, returned as public `Bytes`: a
/// MAC tag is not secret, so it needs no resource. Compare tags with
/// `Bytes.secure_equals`.
#[no_mangle]
pub extern "C" fn mesh_crypto_hmac_sha256_tag(
    key: *const MeshSecretHandle,
    message: *const MeshBytes,
) -> *mut MeshResult {
    let tag = with_current_process(|process| {
        hmac_sha256_tag_for_process(process, &SystemProvider, key, message)
    });
    crypto_result(tag.map(|tag| bytes_value(&tag)))
}

fn hkdf_sha256_for_process(
    process: &mut Process,
    provider: &impl CryptoProvider,
    input_key: *const MeshSecretHandle,
    salt: *const MeshBytes,
    info: *const MeshBytes,
    output_length: i64,
) -> Result<*mut MeshSecretHandle, CryptoFailure> {
    if output_length <= 0 || output_length as u64 > MAX_HKDF_OUTPUT_BYTES as u64 {
        return Err(failure(
            CryptoErrorTag::InvalidLength,
            MAX_HKDF_OUTPUT_BYTES as i64,
            output_length,
        ));
    }
    let salt = unsafe { required_bytes(salt, MAX_INPUT_BYTES) }?;
    let info = unsafe { required_bytes(info, MAX_INPUT_BYTES) }?;
    let mut output = Zeroizing::new(vec![0; output_length as usize].into_boxed_slice());
    let operation =
        with_owned_resource(process, input_key, ResourceKind::SecretBytes, |input_key| {
            provider
                .hkdf_sha256(input_key, salt, info, &mut output)
                .map_err(provider_failure)
        })
        .map_err(resource_failure)?;
    operation?;
    insert_owned_resource(process, ResourceKind::SecretBytes, output).map_err(resource_failure)
}

/// Derive an actor-owned secret with HKDF-SHA-256.
#[no_mangle]
pub extern "C" fn mesh_crypto_hkdf_sha256(
    input_key: *const MeshSecretHandle,
    salt: *const MeshBytes,
    info: *const MeshBytes,
    output_length: i64,
) -> *mut MeshResult {
    crypto_result(with_current_process(|process| {
        hkdf_sha256_for_process(
            process,
            &SystemProvider,
            input_key,
            salt,
            info,
            output_length,
        )
    }))
}

fn bounded_argon2_parameter(value: i64, minimum: u32, maximum: u32) -> Result<u32, CryptoFailure> {
    if value < i64::from(minimum) {
        return Err(failure(
            CryptoErrorTag::InvalidLength,
            i64::from(minimum),
            value,
        ));
    }
    if value > i64::from(maximum) {
        return Err(failure(
            CryptoErrorTag::InvalidLength,
            i64::from(maximum),
            value,
        ));
    }
    Ok(value as u32)
}

#[expect(
    clippy::too_many_arguments,
    reason = "mirrors the six-parameter public Argon2id API with its process and provider context"
)]
fn argon2id_for_process(
    process: &mut Process,
    provider: &impl CryptoProvider,
    password: *const MeshSecretHandle,
    salt: *const MeshBytes,
    memory_kib: i64,
    iterations: i64,
    parallelism: i64,
    output_length: i64,
) -> Result<*mut MeshSecretHandle, CryptoFailure> {
    let parallelism = bounded_argon2_parameter(parallelism, 1, MAX_ARGON2_PARALLELISM)?;
    let memory_kib = bounded_argon2_parameter(memory_kib, parallelism * 8, MAX_ARGON2_MEMORY_KIB)?;
    let iterations = bounded_argon2_parameter(iterations, 1, MAX_ARGON2_ITERATIONS)?;
    let output_length = bounded_argon2_parameter(
        output_length,
        MIN_ARGON2_OUTPUT_BYTES as u32,
        MAX_ARGON2_OUTPUT_BYTES as u32,
    )? as usize;
    let salt = unsafe { required_bytes(salt, MAX_ARGON2_SALT_BYTES) }?;
    if salt.len() < MIN_ARGON2_SALT_BYTES {
        return Err(failure(
            CryptoErrorTag::InvalidLength,
            MIN_ARGON2_SALT_BYTES as i64,
            salt.len() as i64,
        ));
    }
    let password = with_owned_resource(process, password, ResourceKind::SecretBytes, |password| {
        Zeroizing::new(password.to_vec())
    })
    .map_err(resource_failure)?;
    let mut output = Zeroizing::new(vec![0; output_length].into_boxed_slice());
    provider
        .argon2id(
            &password,
            salt,
            memory_kib,
            iterations,
            parallelism,
            &mut output,
        )
        .map_err(provider_failure)?;
    insert_owned_resource(process, ResourceKind::SecretBytes, output).map_err(resource_failure)
}

/// Derive an actor-owned secret with Argon2id v1.3 and bounded costs.
#[no_mangle]
pub extern "C" fn mesh_crypto_argon2id(
    password: *const MeshSecretHandle,
    salt: *const MeshBytes,
    memory_kib: i64,
    iterations: i64,
    parallelism: i64,
    output_length: i64,
) -> *mut MeshResult {
    crypto_result(with_current_process(|process| {
        argon2id_for_process(
            process,
            &SystemProvider,
            password,
            salt,
            memory_kib,
            iterations,
            parallelism,
            output_length,
        )
    }))
}

#[cfg(test)]
fn x25519_generate_for_process(
    process: &mut Process,
    provider: &impl CryptoProvider,
) -> Result<GeneratedX25519KeyPair, CryptoFailure> {
    let (private_key, public_key) = x25519_key_material(provider)?;
    let private_key = insert_owned_resource(process, ResourceKind::X25519PrivateKey, private_key)
        .map_err(resource_failure)?;
    Ok(GeneratedX25519KeyPair {
        private_key,
        public_key,
    })
}

fn x25519_key_material(
    provider: &impl CryptoProvider,
) -> Result<(Zeroizing<Box<[u8]>>, [u8; 32]), CryptoFailure> {
    let mut private_key = Zeroizing::new(vec![0; 32].into_boxed_slice());
    provider
        .fill_random(&mut private_key)
        .map_err(provider_failure)?;
    let private_array = <&[u8; 32]>::try_from(&private_key[..]).expect("a 32-byte private key");
    let public_key = provider.x25519_public(private_array);
    Ok((private_key, public_key))
}

fn mlkem_key_material(
    provider: &impl CryptoProvider,
) -> Result<(Zeroizing<Box<[u8]>>, Vec<u8>), CryptoFailure> {
    let mut private_seed = Zeroizing::new(vec![0; MLKEM_PRIVATE_SEED_BYTES].into_boxed_slice());
    provider
        .fill_random(&mut private_seed)
        .map_err(provider_failure)?;
    let public_key = mlkem_public_key(&private_seed);
    Ok((private_seed, public_key))
}

/// An ML-KEM-768 key pair expanded from its 64-byte seed (d then z) by
/// FIPS 203 `ML-KEM.KeyGen_internal`. The runtime stores only the seed and
/// expands it for each use; the expanded private key is wiped on drop.
struct ExpandedMlKemKey {
    private_key: MlKem768PrivateKey,
    public_key: MlKem768PublicKey,
}

impl Drop for ExpandedMlKemKey {
    fn drop(&mut self) {
        self.private_key[0..].zeroize();
    }
}

/// Every seed reaching here is 64 bytes: callers check it, and an ML-KEM
/// private key resource holds nothing else. libcrux's portable
/// implementation is called directly on every target, never its runtime
/// CPU dispatch to the NEON or AVX2 code.
fn mlkem_expand(private_seed: &[u8]) -> ExpandedMlKemKey {
    let mut seed = Zeroizing::new([0; MLKEM_PRIVATE_SEED_BYTES]);
    seed.copy_from_slice(private_seed);
    let (private_key, public_key) = mlkem768::portable::generate_key_pair(*seed).into_parts();
    ExpandedMlKemKey {
        private_key,
        public_key,
    }
}

fn mlkem_public_key(private_seed: &[u8]) -> Vec<u8> {
    mlkem_expand(private_seed).public_key.as_slice().to_vec()
}

fn mlkem_encapsulate_material(
    provider: &impl CryptoProvider,
    public_key: &[u8; MLKEM_PUBLIC_KEY_BYTES],
) -> Result<(Vec<u8>, Zeroizing<Box<[u8]>>), CryptoFailure> {
    let public_key = MlKem768PublicKey::from(public_key);
    // FIPS 203 section 7.2 input check: every coefficient is reduced mod q.
    if !mlkem768::portable::validate_public_key(&public_key) {
        return Err(failure(CryptoErrorTag::InvalidPublicKey, 0, 0));
    }
    let mut randomness = Zeroizing::new([0; MLKEM_SHARED_SECRET_BYTES]);
    provider
        .fill_random(&mut *randomness)
        .map_err(provider_failure)?;
    let (ciphertext, shared_secret) = mlkem768::portable::encapsulate(&public_key, *randomness);
    Ok((
        ciphertext.as_slice().to_vec(),
        mlkem_shared_secret(shared_secret),
    ))
}

/// The shared secret of `ciphertext` under a private key resource's seed,
/// which is always 64 bytes.
fn mlkem_decapsulate_material(
    private_seed: &[u8],
    ciphertext: &[u8; MLKEM_CIPHERTEXT_BYTES],
) -> Zeroizing<Box<[u8]>> {
    mlkem_decapsulate_expanded(&mlkem_expand(private_seed).private_key, ciphertext)
}

fn mlkem_decapsulate_expanded(
    private_key: &MlKem768PrivateKey,
    ciphertext: &[u8; MLKEM_CIPHERTEXT_BYTES],
) -> Zeroizing<Box<[u8]>> {
    mlkem_shared_secret(mlkem768::portable::decapsulate(
        private_key,
        &MlKem768Ciphertext::from(ciphertext),
    ))
}

fn mlkem_shared_secret(mut shared_secret: [u8; MLKEM_SHARED_SECRET_BYTES]) -> Zeroizing<Box<[u8]>> {
    let owned = Zeroizing::new(Box::from(&shared_secret[..]));
    shared_secret.zeroize();
    owned
}

/// Generate an actor-owned X25519 private key and its public key.
#[no_mangle]
pub extern "C" fn mesh_crypto_x25519_generate() -> *mut MeshResult {
    let (private_material, public_key) = try_crypto!(x25519_key_material(&SystemProvider));
    allocate_x25519_key_pair(private_material, public_key)
}

fn allocate_x25519_key_pair(
    private_material: Zeroizing<Box<[u8]>>,
    public_key: [u8; 32],
) -> *mut MeshResult {
    let public_bytes = bytes_value(&public_key);
    let key_pair = allocate_value(MeshX25519KeyPair {
        private_key: ptr::null_mut(),
        public_key: MeshX25519PublicKey {
            bytes: public_bytes,
        },
    });
    let result = alloc_result(0, key_pair.cast());
    let private_key = try_crypto!(with_current_process(move |process| {
        insert_owned_resource(process, ResourceKind::X25519PrivateKey, private_material)
            .map_err(resource_failure)
    }));
    unsafe { (*key_pair).private_key = private_key };
    result
}

/// Construct an actor-owned X25519 key pair from exact 32-byte private material.
#[no_mangle]
pub extern "C" fn mesh_crypto_x25519_from_seed(seed: *const MeshBytes) -> *mut MeshResult {
    let seed = try_crypto!(unsafe { exact_bytes::<32>(seed, CryptoErrorTag::InvalidLength) });
    let public_key = SystemProvider.x25519_public(seed);
    allocate_x25519_key_pair(Zeroizing::new(seed.to_vec().into_boxed_slice()), public_key)
}

fn x25519_from_secret_for_process(
    process: &mut Process,
    provider: &impl CryptoProvider,
    material: *const MeshSecretHandle,
) -> Result<(*mut MeshSecretHandle, [u8; 32]), CryptoFailure> {
    let mut public_key = [0; 32];
    let private_key = consume_and_retype_owned_resource(
        process,
        material,
        ResourceKind::SecretBytes,
        ResourceKind::X25519PrivateKey,
        |bytes| {
            let private_key = <&[u8; 32]>::try_from(bytes)
                .map_err(|_| failure(CryptoErrorTag::InvalidKey, 32, bytes.len() as i64))?;
            public_key = provider.x25519_public(private_key);
            Ok(())
        },
    )
    .map_err(retype_failure)?;
    Ok((private_key, public_key))
}

/// Consume exactly 32 secret bytes and retype them as an X25519 private key.
#[no_mangle]
pub extern "C" fn mesh_crypto_x25519_from_secret(
    material: *const MeshSecretHandle,
) -> *mut MeshResult {
    let (private_key, public_key) = try_crypto!(with_current_process(|process| {
        x25519_from_secret_for_process(process, &SystemProvider, material)
    }));
    let public_bytes = bytes_value(&public_key);
    let key_pair = allocate_value(MeshX25519KeyPair {
        private_key,
        public_key: MeshX25519PublicKey {
            bytes: public_bytes,
        },
    });
    ok_result(key_pair)
}

unsafe fn x25519_public_key_bytes<'a>(
    public_key: *const MeshX25519PublicKey,
) -> Result<&'a [u8; 32], CryptoFailure> {
    exact_bytes((*public_key).bytes, CryptoErrorTag::InvalidPublicKey)
}

fn x25519_public_for_process(
    process: &Process,
    provider: &impl CryptoProvider,
    private_key: *const MeshSecretHandle,
) -> Result<[u8; 32], CryptoFailure> {
    with_owned_resource(
        process,
        private_key,
        ResourceKind::X25519PrivateKey,
        |private_key| {
            let private_key = <&[u8; 32]>::try_from(private_key)
                .map_err(|_| failure(CryptoErrorTag::InvalidKey, 32, private_key.len() as i64))?;
            Ok(provider.x25519_public(private_key))
        },
    )
    .map_err(resource_failure)?
}

/// Derive the public half of an actor-owned X25519 private key.
#[no_mangle]
pub extern "C" fn mesh_crypto_x25519_public(
    private_key: *const MeshSecretHandle,
) -> *mut MeshResult {
    let public_key = try_crypto!(with_current_process(|process| {
        x25519_public_for_process(process, &SystemProvider, private_key)
    }));
    let bytes = bytes_value(&public_key);
    ok_result(allocate_value(MeshX25519PublicKey { bytes }))
}

fn x25519_shared_for_process(
    process: &mut Process,
    provider: &impl CryptoProvider,
    private_key: *const MeshSecretHandle,
    peer_public_key: *const MeshX25519PublicKey,
) -> Result<*mut MeshSecretHandle, CryptoFailure> {
    let peer_public_key = unsafe { x25519_public_key_bytes(peer_public_key) }?;
    let mut shared_secret = Zeroizing::new(vec![0; 32].into_boxed_slice());
    let operation = with_owned_resource(
        process,
        private_key,
        ResourceKind::X25519PrivateKey,
        |private_key| {
            let private_key = <&[u8; 32]>::try_from(private_key)
                .map_err(|_| failure(CryptoErrorTag::InvalidKey, 32, private_key.len() as i64))?;
            let output =
                <&mut [u8; 32]>::try_from(&mut shared_secret[..]).expect("a 32-byte output");
            provider
                .x25519_shared(private_key, peer_public_key, output)
                .map_err(provider_failure)
        },
    )
    .map_err(resource_failure)?;
    operation?;
    insert_owned_resource(process, ResourceKind::SecretBytes, shared_secret)
        .map_err(resource_failure)
}

/// Derive an actor-owned X25519 shared secret.
#[no_mangle]
pub extern "C" fn mesh_crypto_x25519_shared(
    private_key: *const MeshSecretHandle,
    peer_public_key: *const MeshX25519PublicKey,
) -> *mut MeshResult {
    crypto_result(with_current_process(|process| {
        x25519_shared_for_process(process, &SystemProvider, private_key, peer_public_key)
    }))
}

fn hpke_labeled_extract(
    provider: &impl CryptoProvider,
    suite_id: &[u8],
    salt: &[u8],
    label: &[u8],
    input_key_material: &[u8],
) -> Zeroizing<[u8; 32]> {
    let mut labeled_input = Zeroizing::new(Vec::with_capacity(
        HPKE_VERSION_LABEL.len() + suite_id.len() + label.len() + input_key_material.len(),
    ));
    labeled_input.extend_from_slice(HPKE_VERSION_LABEL);
    labeled_input.extend_from_slice(suite_id);
    labeled_input.extend_from_slice(label);
    labeled_input.extend_from_slice(input_key_material);
    let mut output = Zeroizing::new([0; 32]);
    provider
        .hmac_sha256(salt, &labeled_input, &mut output)
        .expect("an HPKE label within HMAC's input bound");
    output
}

fn hpke_labeled_expand<const N: usize>(
    provider: &impl CryptoProvider,
    suite_id: &[u8],
    pseudo_random_key: &[u8; 32],
    label: &[u8],
    info: &[u8],
) -> Zeroizing<[u8; N]> {
    // One HMAC block: every expansion HPKE's suite needs is a key or nonce.
    const { assert!(N > 0 && N <= 32) };
    let mut labeled_info = Vec::with_capacity(
        2 + HPKE_VERSION_LABEL.len() + suite_id.len() + label.len() + info.len() + 1,
    );
    labeled_info.extend_from_slice(&(N as u16).to_be_bytes());
    labeled_info.extend_from_slice(HPKE_VERSION_LABEL);
    labeled_info.extend_from_slice(suite_id);
    labeled_info.extend_from_slice(label);
    labeled_info.extend_from_slice(info);
    labeled_info.push(1);
    let mut block = Zeroizing::new([0; 32]);
    provider
        .hmac_sha256(pseudo_random_key, &labeled_info, &mut block)
        .expect("an HPKE label within HMAC's input bound");
    let mut output = Zeroizing::new([0; N]);
    output.copy_from_slice(&block[..N]);
    output
}

fn hpke_derive_private_key(
    provider: &impl CryptoProvider,
    input_key_material: &[u8; 32],
) -> Zeroizing<[u8; 32]> {
    let pseudo_random_key = hpke_labeled_extract(
        provider,
        HPKE_KEM_SUITE_ID,
        &[],
        b"dkp_prk",
        input_key_material,
    );
    hpke_labeled_expand(provider, HPKE_KEM_SUITE_ID, &pseudo_random_key, b"sk", &[])
}

fn hpke_shared_secret(
    provider: &impl CryptoProvider,
    dh: &[u8; 32],
    encapsulated_key: &[u8; 32],
    recipient_public_key: &[u8; 32],
) -> Zeroizing<[u8; 32]> {
    let pseudo_random_key = hpke_labeled_extract(provider, HPKE_KEM_SUITE_ID, &[], b"eae_prk", dh);
    let mut kem_context = [0; 64];
    kem_context[..32].copy_from_slice(encapsulated_key);
    kem_context[32..].copy_from_slice(recipient_public_key);
    hpke_labeled_expand(
        provider,
        HPKE_KEM_SUITE_ID,
        &pseudo_random_key,
        b"shared_secret",
        &kem_context,
    )
}

fn hpke_key_and_nonce(
    provider: &impl CryptoProvider,
    shared_secret: &[u8; 32],
    info: &[u8],
) -> (Zeroizing<[u8; 32]>, Zeroizing<[u8; 12]>) {
    let psk_id_hash = hpke_labeled_extract(provider, HPKE_SUITE_ID, &[], b"psk_id_hash", &[]);
    let info_hash = hpke_labeled_extract(provider, HPKE_SUITE_ID, &[], b"info_hash", info);
    let mut key_schedule_context = Zeroizing::new([0; 65]);
    key_schedule_context[1..33].copy_from_slice(&psk_id_hash[..]);
    key_schedule_context[33..].copy_from_slice(&info_hash[..]);
    let secret = hpke_labeled_extract(provider, HPKE_SUITE_ID, shared_secret, b"secret", &[]);
    let key = hpke_labeled_expand(
        provider,
        HPKE_SUITE_ID,
        &secret,
        b"key",
        &key_schedule_context[..],
    );
    let nonce = hpke_labeled_expand(
        provider,
        HPKE_SUITE_ID,
        &secret,
        b"base_nonce",
        &key_schedule_context[..],
    );
    (key, nonce)
}

fn hpke_seal_material(
    provider: &impl CryptoProvider,
    recipient_public_key: &[u8; 32],
    info: &[u8],
    associated_data: &[u8],
    plaintext: &[u8],
) -> Result<Vec<u8>, CryptoFailure> {
    hpke_seal_keeping_secret(
        provider,
        recipient_public_key,
        info,
        associated_data,
        plaintext,
    )
    .map(|(sealed, _)| sealed)
}

// RFC 9180 section 5.3: Export(exporter_context, Nh) from the context the KEM
// shared secret and info set up. OHTTP (RFC 9458 section 4.4) takes its
// response key from one export of max(Nn, Nk) = 32 bytes for this AEAD.
fn hpke_export(
    provider: &impl CryptoProvider,
    shared_secret: &[u8; 32],
    info: &[u8],
    exporter_context: &[u8],
) -> Zeroizing<[u8; 32]> {
    let psk_id_hash = hpke_labeled_extract(provider, HPKE_SUITE_ID, &[], b"psk_id_hash", &[]);
    let info_hash = hpke_labeled_extract(provider, HPKE_SUITE_ID, &[], b"info_hash", info);
    let mut key_schedule_context = Zeroizing::new([0; 65]);
    key_schedule_context[1..33].copy_from_slice(&psk_id_hash[..]);
    key_schedule_context[33..].copy_from_slice(&info_hash[..]);
    let secret = hpke_labeled_extract(provider, HPKE_SUITE_ID, shared_secret, b"secret", &[]);
    let exporter_secret: Zeroizing<[u8; 32]> = hpke_labeled_expand(
        provider,
        HPKE_SUITE_ID,
        &secret,
        b"exp",
        &key_schedule_context[..],
    );
    hpke_labeled_expand(
        provider,
        HPKE_SUITE_ID,
        &exporter_secret,
        b"sec",
        exporter_context,
    )
}

// The seal, and the KEM shared secret its context came from (for an export).
fn hpke_seal_keeping_secret(
    provider: &impl CryptoProvider,
    recipient_public_key: &[u8; 32],
    info: &[u8],
    associated_data: &[u8],
    plaintext: &[u8],
) -> Result<(Vec<u8>, Zeroizing<[u8; 32]>), CryptoFailure> {
    let mut input_key_material = Zeroizing::new([0; 32]);
    provider
        .fill_random(&mut input_key_material[..])
        .map_err(provider_failure)?;
    let ephemeral_private_key = hpke_derive_private_key(provider, &input_key_material);
    let encapsulated_key = provider.x25519_public(&ephemeral_private_key);
    let mut dh = Zeroizing::new([0; 32]);
    provider
        .x25519_shared(&ephemeral_private_key, recipient_public_key, &mut dh)
        .map_err(provider_failure)?;
    let shared_secret = hpke_shared_secret(provider, &dh, &encapsulated_key, recipient_public_key);
    let (key, nonce) = hpke_key_and_nonce(provider, &shared_secret, info);
    let ciphertext = provider
        .chacha20poly1305_seal(&key, &nonce, associated_data, plaintext)
        .map_err(provider_failure)?;
    let mut sealed = Vec::with_capacity(HPKE_ENCAPSULATED_KEY_BYTES + ciphertext.len());
    sealed.extend_from_slice(&encapsulated_key);
    sealed.extend_from_slice(&ciphertext);
    Ok((sealed, shared_secret))
}

fn hpke_open_material(
    provider: &impl CryptoProvider,
    recipient_private_key: &[u8; 32],
    info: &[u8],
    associated_data: &[u8],
    sealed: &[u8],
) -> Result<Zeroizing<Vec<u8>>, CryptoFailure> {
    hpke_open_keeping_secret(
        provider,
        recipient_private_key,
        info,
        associated_data,
        sealed,
    )
    .map(|(plaintext, _)| plaintext)
}

fn hpke_open_keeping_secret(
    provider: &impl CryptoProvider,
    recipient_private_key: &[u8; 32],
    info: &[u8],
    associated_data: &[u8],
    sealed: &[u8],
) -> Result<(Zeroizing<Vec<u8>>, Zeroizing<[u8; 32]>), CryptoFailure> {
    if sealed.len() < HPKE_MIN_SEALED_BYTES || sealed.len() > MAX_HPKE_SEALED_BYTES {
        return Err(failure(
            CryptoErrorTag::InvalidLength,
            HPKE_MIN_SEALED_BYTES as i64,
            sealed.len() as i64,
        ));
    }
    let encapsulated_key =
        <[u8; 32]>::try_from(&sealed[..32]).expect("the sealed length checked above");
    let recipient_public_key = provider.x25519_public(recipient_private_key);
    let mut dh = Zeroizing::new([0; 32]);
    provider
        .x25519_shared(recipient_private_key, &encapsulated_key, &mut dh)
        .map_err(provider_failure)?;
    let shared_secret = hpke_shared_secret(provider, &dh, &encapsulated_key, &recipient_public_key);
    let (key, nonce) = hpke_key_and_nonce(provider, &shared_secret, info);
    let mut plaintext = Zeroizing::new(sealed[32..].to_vec());
    provider
        .chacha20poly1305_open(&key, &nonce, associated_data, &mut plaintext)
        .map_err(provider_failure)?;
    Ok((plaintext, shared_secret))
}

/// Seal one RFC 9180 base-mode X25519/HKDF-SHA-256/ChaCha20-Poly1305 message.
/// The returned canonical wire value is `enc || ciphertext`.
#[no_mangle]
pub extern "C" fn mesh_crypto_hpke_seal(
    recipient_public_key: *const MeshX25519PublicKey,
    info: *const MeshBytes,
    associated_data: *const MeshBytes,
    plaintext: *const MeshBytes,
) -> *mut MeshResult {
    let recipient_public_key =
        try_crypto!(unsafe { x25519_public_key_bytes(recipient_public_key) });
    let info = try_crypto!(unsafe { required_bytes(info, MAX_HPKE_INFO_BYTES) });
    let associated_data = try_crypto!(unsafe { required_bytes(associated_data, MAX_INPUT_BYTES) });
    let plaintext = try_crypto!(unsafe { required_bytes(plaintext, MAX_INPUT_BYTES) });
    crypto_result(
        hpke_seal_material(
            &SystemProvider,
            recipient_public_key,
            info,
            associated_data,
            plaintext,
        )
        .map(|sealed| bytes_value(&sealed)),
    )
}

fn hpke_open_for_process(
    process: &Process,
    provider: &impl CryptoProvider,
    recipient_private_key: *const MeshSecretHandle,
    info: &[u8],
    associated_data: &[u8],
    sealed: &[u8],
) -> Result<Zeroizing<Vec<u8>>, CryptoFailure> {
    with_owned_resource(
        process,
        recipient_private_key,
        ResourceKind::X25519PrivateKey,
        |private_key| {
            let private_key = <&[u8; 32]>::try_from(private_key)
                .map_err(|_| failure(CryptoErrorTag::InvalidKey, 32, private_key.len() as i64))?;
            hpke_open_material(provider, private_key, info, associated_data, sealed)
        },
    )
    .map_err(resource_failure)?
}

/// Open one canonical `enc || ciphertext` RFC 9180 base-mode message.
#[no_mangle]
pub extern "C" fn mesh_crypto_hpke_open(
    recipient_private_key: *const MeshSecretHandle,
    info: *const MeshBytes,
    associated_data: *const MeshBytes,
    sealed: *const MeshBytes,
) -> *mut MeshResult {
    let info = try_crypto!(unsafe { required_bytes(info, MAX_HPKE_INFO_BYTES) });
    let associated_data = try_crypto!(unsafe { required_bytes(associated_data, MAX_INPUT_BYTES) });
    let sealed = try_crypto!(unsafe { required_bytes(sealed, MAX_HPKE_SEALED_BYTES) });
    crypto_result(
        with_current_process(|process| {
            hpke_open_for_process(
                process,
                &SystemProvider,
                recipient_private_key,
                info,
                associated_data,
                sealed,
            )
        })
        .map(|plaintext| bytes_value(&plaintext)),
    )
}

fn hpke_seal_secret_for_process(
    process: &Process,
    provider: &impl CryptoProvider,
    recipient_public_key: &[u8; 32],
    info: &[u8],
    associated_data: &[u8],
    plaintext: *const MeshSecretHandle,
) -> Result<Vec<u8>, CryptoFailure> {
    with_owned_resource(process, plaintext, ResourceKind::SecretBytes, |plaintext| {
        hpke_seal_material(
            provider,
            recipient_public_key,
            info,
            associated_data,
            plaintext,
        )
    })
    .map_err(resource_failure)?
}

/// Seal actor-owned secret material without exposing it as ordinary bytes.
#[no_mangle]
pub extern "C" fn mesh_crypto_hpke_seal_secret(
    recipient_public_key: *const MeshX25519PublicKey,
    info: *const MeshBytes,
    associated_data: *const MeshBytes,
    plaintext: *const MeshSecretHandle,
) -> *mut MeshResult {
    let recipient_public_key =
        try_crypto!(unsafe { x25519_public_key_bytes(recipient_public_key) });
    let info = try_crypto!(unsafe { required_bytes(info, MAX_HPKE_INFO_BYTES) });
    let associated_data = try_crypto!(unsafe { required_bytes(associated_data, MAX_INPUT_BYTES) });
    crypto_result(
        with_current_process(|process| {
            hpke_seal_secret_for_process(
                process,
                &SystemProvider,
                recipient_public_key,
                info,
                associated_data,
                plaintext,
            )
        })
        .map(|sealed| bytes_value(&sealed)),
    )
}

fn hpke_open_secret_for_process(
    process: &mut Process,
    provider: &impl CryptoProvider,
    recipient_private_key: *const MeshSecretHandle,
    info: &[u8],
    associated_data: &[u8],
    sealed: &[u8],
) -> Result<*mut MeshSecretHandle, CryptoFailure> {
    let plaintext = hpke_open_for_process(
        process,
        provider,
        recipient_private_key,
        info,
        associated_data,
        sealed,
    )?;
    let plaintext = Zeroizing::new(plaintext.as_slice().to_vec().into_boxed_slice());
    insert_owned_resource(process, ResourceKind::SecretBytes, plaintext).map_err(resource_failure)
}

/// Open sealed material directly into an actor-owned secret resource.
#[no_mangle]
pub extern "C" fn mesh_crypto_hpke_open_secret(
    recipient_private_key: *const MeshSecretHandle,
    info: *const MeshBytes,
    associated_data: *const MeshBytes,
    sealed: *const MeshBytes,
) -> *mut MeshResult {
    let info = try_crypto!(unsafe { required_bytes(info, MAX_HPKE_INFO_BYTES) });
    let associated_data = try_crypto!(unsafe { required_bytes(associated_data, MAX_INPUT_BYTES) });
    let sealed = try_crypto!(unsafe { required_bytes(sealed, MAX_HPKE_SEALED_BYTES) });
    crypto_result(with_current_process(|process| {
        hpke_open_secret_for_process(
            process,
            &SystemProvider,
            recipient_private_key,
            info,
            associated_data,
            sealed,
        )
    }))
}

// `(Bytes, SecretBytes)`: a sealed or opened message and the secret exported
// from its context, owned by the running actor.
fn bytes_and_secret(value: &[u8], exported: Zeroizing<[u8; 32]>) -> *mut MeshResult {
    let output = allocate_value(MeshTuple2Pointers {
        len: 2,
        first: bytes_value(value),
        second: ptr::null_mut(),
    });
    let result = alloc_result(0, output.cast());
    let exported = try_crypto!(with_current_process(move |process| {
        insert_owned_resource(
            process,
            ResourceKind::SecretBytes,
            Zeroizing::new(Box::from(&exported[..])),
        )
        .map_err(resource_failure)
    }));
    unsafe { (*output).second = exported };
    result
}

/// Seal like `mesh_crypto_hpke_seal`, and also export 32 bytes from the
/// sender's context under `exporter_context` (RFC 9180 section 5.3).
#[no_mangle]
pub extern "C" fn mesh_crypto_hpke_seal_export(
    recipient_public_key: *const MeshX25519PublicKey,
    info: *const MeshBytes,
    associated_data: *const MeshBytes,
    plaintext: *const MeshBytes,
    exporter_context: *const MeshBytes,
) -> *mut MeshResult {
    let recipient_public_key =
        try_crypto!(unsafe { x25519_public_key_bytes(recipient_public_key) });
    let info = try_crypto!(unsafe { required_bytes(info, MAX_HPKE_INFO_BYTES) });
    let associated_data = try_crypto!(unsafe { required_bytes(associated_data, MAX_INPUT_BYTES) });
    let plaintext = try_crypto!(unsafe { required_bytes(plaintext, MAX_INPUT_BYTES) });
    let exporter_context =
        try_crypto!(unsafe { required_bytes(exporter_context, MAX_HPKE_INFO_BYTES) });
    let (sealed, shared_secret) = try_crypto!(hpke_seal_keeping_secret(
        &SystemProvider,
        recipient_public_key,
        info,
        associated_data,
        plaintext,
    ));
    let exported = hpke_export(&SystemProvider, &shared_secret, info, exporter_context);
    bytes_and_secret(&sealed, exported)
}

/// Open like `mesh_crypto_hpke_open`, and also export 32 bytes from the
/// receiver's context under `exporter_context`: the sender's export.
#[no_mangle]
pub extern "C" fn mesh_crypto_hpke_open_export(
    recipient_private_key: *const MeshSecretHandle,
    info: *const MeshBytes,
    associated_data: *const MeshBytes,
    sealed: *const MeshBytes,
    exporter_context: *const MeshBytes,
) -> *mut MeshResult {
    let info = try_crypto!(unsafe { required_bytes(info, MAX_HPKE_INFO_BYTES) });
    let associated_data = try_crypto!(unsafe { required_bytes(associated_data, MAX_INPUT_BYTES) });
    let sealed = try_crypto!(unsafe { required_bytes(sealed, MAX_HPKE_SEALED_BYTES) });
    let exporter_context =
        try_crypto!(unsafe { required_bytes(exporter_context, MAX_HPKE_INFO_BYTES) });
    let (plaintext, shared_secret) = try_crypto!(with_current_process(|process| {
        with_owned_resource(
            process,
            recipient_private_key,
            ResourceKind::X25519PrivateKey,
            |private_key| {
                let private_key = <&[u8; 32]>::try_from(private_key).map_err(|_| {
                    failure(CryptoErrorTag::InvalidKey, 32, private_key.len() as i64)
                })?;
                hpke_open_keeping_secret(
                    &SystemProvider,
                    private_key,
                    info,
                    associated_data,
                    sealed,
                )
            },
        )
        .map_err(resource_failure)?
    }));
    let exported = hpke_export(&SystemProvider, &shared_secret, info, exporter_context);
    bytes_and_secret(&plaintext, exported)
}

// The derived-key AEAD takes messages up to a mebibyte: an OHTTP response
// carries a whole mailbox batch.
const MAX_DERIVED_AEAD_BYTES: usize = 1024 * 1024;

// RFC 9458 section 4.4 steps 3-5 with HKDF-SHA-256 and ChaCha20-Poly1305:
// prk = Extract(salt, secret), key = Expand(prk, "key", 32),
// nonce = Expand(prk, "nonce", 12).
fn derived_aead_key_and_nonce(
    provider: &impl CryptoProvider,
    secret: &[u8],
    salt: &[u8],
) -> Result<(Zeroizing<[u8; 32]>, Zeroizing<[u8; 12]>), CryptoFailure> {
    let mut pseudo_random_key = Zeroizing::new([0; 32]);
    provider
        .hmac_sha256(salt, secret, &mut pseudo_random_key)
        .map_err(provider_failure)?;
    let mut key = Zeroizing::new([0; 32]);
    provider
        .hmac_sha256(&pseudo_random_key[..], b"key\x01", &mut key)
        .map_err(provider_failure)?;
    let mut block = Zeroizing::new([0; 32]);
    provider
        .hmac_sha256(&pseudo_random_key[..], b"nonce\x01", &mut block)
        .map_err(provider_failure)?;
    let mut nonce = Zeroizing::new([0; 12]);
    nonce.copy_from_slice(&block[..12]);
    Ok((key, nonce))
}

fn derived_aead_seal_material(
    provider: &impl CryptoProvider,
    secret: &[u8],
    salt: &[u8],
    associated_data: &[u8],
    plaintext: &[u8],
) -> Result<Vec<u8>, CryptoFailure> {
    let (key, nonce) = derived_aead_key_and_nonce(provider, secret, salt)?;
    provider
        .chacha20poly1305_seal_within(
            &key,
            &nonce,
            associated_data,
            plaintext,
            MAX_DERIVED_AEAD_BYTES,
        )
        .map_err(provider_failure)
}

fn derived_aead_open_material(
    provider: &impl CryptoProvider,
    secret: &[u8],
    salt: &[u8],
    associated_data: &[u8],
    ciphertext: &[u8],
) -> Result<Zeroizing<Vec<u8>>, CryptoFailure> {
    let (key, nonce) = derived_aead_key_and_nonce(provider, secret, salt)?;
    let mut plaintext = Zeroizing::new(ciphertext.to_vec());
    provider
        .chacha20poly1305_open_within(
            &key,
            &nonce,
            associated_data,
            &mut plaintext,
            MAX_DERIVED_AEAD_BYTES,
        )
        .map_err(provider_failure)?;
    Ok(plaintext)
}

/// ChaCha20-Poly1305 under the key and nonce HKDF-SHA-256 derives from a
/// secret and a public salt (RFC 9458 section 4.4); the secret is borrowed.
#[no_mangle]
pub extern "C" fn mesh_crypto_hkdf_aead_seal(
    secret: *const MeshSecretHandle,
    salt: *const MeshBytes,
    associated_data: *const MeshBytes,
    plaintext: *const MeshBytes,
) -> *mut MeshResult {
    let salt = try_crypto!(unsafe { required_bytes(salt, MAX_INPUT_BYTES) });
    let associated_data = try_crypto!(unsafe { required_bytes(associated_data, MAX_INPUT_BYTES) });
    let plaintext = try_crypto!(unsafe { required_bytes(plaintext, MAX_DERIVED_AEAD_BYTES) });
    crypto_result(
        with_current_process(|process| {
            with_owned_resource(process, secret, ResourceKind::SecretBytes, |secret| {
                derived_aead_seal_material(
                    &SystemProvider,
                    secret,
                    salt,
                    associated_data,
                    plaintext,
                )
            })
            .map_err(resource_failure)?
        })
        .map(|ciphertext| bytes_value(&ciphertext)),
    )
}

/// Open what `mesh_crypto_hkdf_aead_seal` sealed.
#[no_mangle]
pub extern "C" fn mesh_crypto_hkdf_aead_open(
    secret: *const MeshSecretHandle,
    salt: *const MeshBytes,
    associated_data: *const MeshBytes,
    ciphertext: *const MeshBytes,
) -> *mut MeshResult {
    let salt = try_crypto!(unsafe { required_bytes(salt, MAX_INPUT_BYTES) });
    let associated_data = try_crypto!(unsafe { required_bytes(associated_data, MAX_INPUT_BYTES) });
    let ciphertext =
        try_crypto!(unsafe { required_bytes(ciphertext, MAX_DERIVED_AEAD_BYTES + AEAD_TAG_BYTES) });
    crypto_result(
        with_current_process(|process| {
            with_owned_resource(process, secret, ResourceKind::SecretBytes, |secret| {
                derived_aead_open_material(
                    &SystemProvider,
                    secret,
                    salt,
                    associated_data,
                    ciphertext,
                )
            })
            .map_err(resource_failure)?
        })
        .map(|plaintext| bytes_value(&plaintext)),
    )
}

fn allocate_mlkem_key_pair(
    private_material: Zeroizing<Box<[u8]>>,
    public_key: &[u8],
) -> *mut MeshResult {
    let public_bytes = bytes_value(public_key);
    let key_pair = allocate_value(MeshMlKemKeyPair {
        private_key: ptr::null_mut(),
        public_key: MeshMlKemPublicKey {
            bytes: public_bytes,
        },
    });
    let result = alloc_result(0, key_pair.cast());
    let private_key = try_crypto!(with_current_process(move |process| {
        insert_owned_resource(process, ResourceKind::MlKemPrivateKey, private_material)
            .map_err(resource_failure)
    }));
    unsafe { (*key_pair).private_key = private_key };
    result
}

/// Generate an actor-owned ML-KEM-768 decapsulation key and its public key.
#[no_mangle]
pub extern "C" fn mesh_crypto_mlkem_generate() -> *mut MeshResult {
    let (private_key, public_key) = try_crypto!(mlkem_key_material(&SystemProvider));
    allocate_mlkem_key_pair(private_key, &public_key)
}

/// Construct an actor-owned ML-KEM-768 key pair from an exact 64-byte seed.
#[no_mangle]
pub extern "C" fn mesh_crypto_mlkem_from_seed(seed: *const MeshBytes) -> *mut MeshResult {
    let seed = try_crypto!(unsafe {
        exact_bytes::<MLKEM_PRIVATE_SEED_BYTES>(seed, CryptoErrorTag::InvalidLength)
    });
    let public_key = mlkem_public_key(seed);
    allocate_mlkem_key_pair(
        Zeroizing::new(seed.to_vec().into_boxed_slice()),
        &public_key,
    )
}

fn mlkem_from_secret_for_process(
    process: &mut Process,
    material: *const MeshSecretHandle,
) -> Result<(*mut MeshSecretHandle, Vec<u8>), CryptoFailure> {
    let mut public_key = Vec::new();
    let private_key = consume_and_retype_owned_resource(
        process,
        material,
        ResourceKind::SecretBytes,
        ResourceKind::MlKemPrivateKey,
        |bytes| {
            if bytes.len() != MLKEM_PRIVATE_SEED_BYTES {
                return Err(failure(
                    CryptoErrorTag::InvalidKey,
                    MLKEM_PRIVATE_SEED_BYTES as i64,
                    bytes.len() as i64,
                ));
            }
            public_key = mlkem_public_key(bytes);
            Ok(())
        },
    )
    .map_err(retype_failure)?;
    Ok((private_key, public_key))
}

/// Consume exactly 64 secret bytes and retype them as an ML-KEM-768 private key.
#[no_mangle]
pub extern "C" fn mesh_crypto_mlkem_from_secret(
    material: *const MeshSecretHandle,
) -> *mut MeshResult {
    let (private_key, public_key) = try_crypto!(with_current_process(|process| {
        mlkem_from_secret_for_process(process, material)
    }));
    let public_bytes = bytes_value(&public_key);
    let key_pair = allocate_value(MeshMlKemKeyPair {
        private_key,
        public_key: MeshMlKemPublicKey {
            bytes: public_bytes,
        },
    });
    ok_result(key_pair)
}

/// Encapsulate to an exact ML-KEM-768 public key.
#[no_mangle]
pub extern "C" fn mesh_crypto_mlkem_encapsulate(
    public_key: *const MeshMlKemPublicKey,
) -> *mut MeshResult {
    let public_key =
        try_crypto!(unsafe { exact_bytes((*public_key).bytes, CryptoErrorTag::InvalidPublicKey) });
    let (ciphertext, shared_secret) =
        try_crypto!(mlkem_encapsulate_material(&SystemProvider, public_key));
    let ciphertext = bytes_value(&ciphertext);
    let output = allocate_value(MeshTuple2Pointers {
        len: 2,
        first: ciphertext,
        second: ptr::null_mut(),
    });
    let result = alloc_result(0, output.cast());
    let shared_secret = try_crypto!(with_current_process(move |process| {
        insert_owned_resource(process, ResourceKind::SecretBytes, shared_secret)
            .map_err(resource_failure)
    }));
    unsafe { (*output).second = shared_secret };
    result
}

/// Decapsulate an ML-KEM-768 ciphertext with an actor-owned private key.
#[no_mangle]
pub extern "C" fn mesh_crypto_mlkem_decapsulate(
    private_key: *const MeshSecretHandle,
    ciphertext: *const MeshMlKemCiphertext,
) -> *mut MeshResult {
    let ciphertext =
        try_crypto!(unsafe { exact_bytes((*ciphertext).bytes, CryptoErrorTag::InvalidLength) });
    crypto_result(with_current_process(|process| {
        let shared_secret = with_owned_resource(
            process,
            private_key,
            ResourceKind::MlKemPrivateKey,
            |private_seed| mlkem_decapsulate_material(private_seed, ciphertext),
        )
        .map_err(resource_failure)?;
        insert_owned_resource(process, ResourceKind::SecretBytes, shared_secret)
            .map_err(resource_failure)
    }))
}

#[cfg(test)]
fn signing_generate_for_process(
    process: &mut Process,
    provider: &impl CryptoProvider,
) -> Result<GeneratedSigningKeyPair, CryptoFailure> {
    let (private_key, public_key) = signing_key_material(provider)?;
    let private_key = insert_owned_resource(process, ResourceKind::SigningPrivateKey, private_key)
        .map_err(resource_failure)?;
    Ok(GeneratedSigningKeyPair {
        private_key,
        public_key,
    })
}

fn signing_key_material(
    provider: &impl CryptoProvider,
) -> Result<(Zeroizing<Box<[u8]>>, [u8; 32]), CryptoFailure> {
    let mut private_key = Zeroizing::new(vec![0; 32].into_boxed_slice());
    provider
        .fill_random(&mut private_key)
        .map_err(provider_failure)?;
    let private_array = <&[u8; 32]>::try_from(&private_key[..]).expect("a 32-byte private key");
    let public_key = provider.ed25519_public(private_array);
    Ok((private_key, public_key))
}

/// Generate an actor-owned signing private key and its public key.
#[no_mangle]
pub extern "C" fn mesh_crypto_signing_generate() -> *mut MeshResult {
    let (private_material, public_key) = try_crypto!(signing_key_material(&SystemProvider));
    allocate_signing_key_pair(private_material, public_key)
}

fn allocate_signing_key_pair(
    private_material: Zeroizing<Box<[u8]>>,
    public_key: [u8; 32],
) -> *mut MeshResult {
    let public_bytes = bytes_value(&public_key);
    let key_pair = allocate_value(MeshSigningKeyPair {
        private_key: ptr::null_mut(),
        public_key: MeshSigningPublicKey {
            bytes: public_bytes,
        },
    });
    let result = alloc_result(0, key_pair.cast());
    let private_key = try_crypto!(with_current_process(move |process| {
        insert_owned_resource(process, ResourceKind::SigningPrivateKey, private_material)
            .map_err(resource_failure)
    }));
    unsafe { (*key_pair).private_key = private_key };
    result
}

/// Construct an actor-owned signing key pair from an exact 32-byte Ed25519 seed.
#[no_mangle]
pub extern "C" fn mesh_crypto_signing_from_seed(seed: *const MeshBytes) -> *mut MeshResult {
    let seed = try_crypto!(unsafe { exact_bytes::<32>(seed, CryptoErrorTag::InvalidLength) });
    let public_key = SystemProvider.ed25519_public(seed);
    allocate_signing_key_pair(Zeroizing::new(seed.to_vec().into_boxed_slice()), public_key)
}

fn signing_from_secret_for_process(
    process: &mut Process,
    provider: &impl CryptoProvider,
    material: *const MeshSecretHandle,
) -> Result<(*mut MeshSecretHandle, [u8; 32]), CryptoFailure> {
    let mut public_key = [0; 32];
    let private_key = consume_and_retype_owned_resource(
        process,
        material,
        ResourceKind::SecretBytes,
        ResourceKind::SigningPrivateKey,
        |bytes| {
            let private_key = <&[u8; 32]>::try_from(bytes)
                .map_err(|_| failure(CryptoErrorTag::InvalidKey, 32, bytes.len() as i64))?;
            public_key = provider.ed25519_public(private_key);
            Ok(())
        },
    )
    .map_err(retype_failure)?;
    Ok((private_key, public_key))
}

/// Consume exactly 32 secret bytes and retype them as an Ed25519 signing private key.
#[no_mangle]
pub extern "C" fn mesh_crypto_signing_from_secret(
    material: *const MeshSecretHandle,
) -> *mut MeshResult {
    let (private_key, public_key) = try_crypto!(with_current_process(|process| {
        signing_from_secret_for_process(process, &SystemProvider, material)
    }));
    let public_bytes = bytes_value(&public_key);
    let key_pair = allocate_value(MeshSigningKeyPair {
        private_key,
        public_key: MeshSigningPublicKey {
            bytes: public_bytes,
        },
    });
    ok_result(key_pair)
}

fn sign_for_process(
    process: &Process,
    provider: &impl CryptoProvider,
    private_key: *const MeshSecretHandle,
    message: *const MeshBytes,
) -> Result<[u8; 64], CryptoFailure> {
    let message = unsafe { required_bytes(message, MAX_INPUT_BYTES) }?;
    with_owned_resource(
        process,
        private_key,
        ResourceKind::SigningPrivateKey,
        |private_key| {
            let private_key = <&[u8; 32]>::try_from(private_key)
                .map_err(|_| failure(CryptoErrorTag::InvalidKey, 32, private_key.len() as i64))?;
            provider
                .ed25519_sign(private_key, message)
                .map_err(provider_failure)
        },
    )
    .map_err(resource_failure)?
}

/// Sign bounded binary input with an actor-owned Ed25519 private key.
#[no_mangle]
pub extern "C" fn mesh_crypto_sign(
    private_key: *const MeshSecretHandle,
    message: *const MeshBytes,
) -> *mut MeshResult {
    let signature = try_crypto!(with_current_process(|process| {
        sign_for_process(process, &SystemProvider, private_key, message)
    }));
    let bytes = bytes_value(&signature);
    ok_result(allocate_value(MeshSignature { bytes }))
}

fn verify_with_provider(
    provider: &impl CryptoProvider,
    public_key: *const MeshSigningPublicKey,
    message: *const MeshBytes,
    signature: *const MeshSignature,
) -> Result<bool, CryptoFailure> {
    let public_key = unsafe { exact_bytes((*public_key).bytes, CryptoErrorTag::InvalidPublicKey) }?;
    let message = unsafe { required_bytes(message, MAX_INPUT_BYTES) }?;
    let signature = unsafe { exact_bytes((*signature).bytes, CryptoErrorTag::InvalidSignature) }?;
    provider
        .ed25519_verify(public_key, message, signature)
        .map_err(provider_failure)
}

/// Verify an Ed25519 signature, returning `Ok(false)` for valid-sized mismatches.
#[no_mangle]
pub extern "C" fn mesh_crypto_verify(
    public_key: *const MeshSigningPublicKey,
    message: *const MeshBytes,
    signature: *const MeshSignature,
) -> *mut MeshResult {
    crypto_result(
        verify_with_provider(&SystemProvider, public_key, message, signature).map(allocate_value),
    )
}

fn aead_key_for_process(
    process: &mut Process,
    material: *const MeshSecretHandle,
) -> Result<*mut MeshSecretHandle, CryptoFailure> {
    consume_and_retype_owned_resource(
        process,
        material,
        ResourceKind::SecretBytes,
        ResourceKind::AeadKey,
        |bytes| {
            if bytes.len() == 32 {
                Ok(())
            } else {
                Err(failure(CryptoErrorTag::InvalidKey, 32, bytes.len() as i64))
            }
        },
    )
    .map_err(retype_failure)
}

/// Consume `SecretBytes` and retype exactly 32 bytes as an AEAD key.
#[no_mangle]
pub extern "C" fn mesh_crypto_aead_key(material: *const MeshSecretHandle) -> *mut MeshResult {
    crypto_result(with_current_process(|process| {
        aead_key_for_process(process, material)
    }))
}

fn aead_seal_for_process(
    process: &Process,
    provider: &impl CryptoProvider,
    key: *const MeshSecretHandle,
    nonce: *const MeshBytes,
    associated_data: *const MeshBytes,
    plaintext: *const MeshBytes,
) -> Result<Vec<u8>, CryptoFailure> {
    let nonce = unsafe { exact_bytes::<AEAD_NONCE_BYTES>(nonce, CryptoErrorTag::InvalidLength) }?;
    let associated_data = unsafe { required_bytes(associated_data, MAX_INPUT_BYTES) }?;
    let plaintext = unsafe { required_bytes(plaintext, MAX_INPUT_BYTES) }?;
    with_owned_resource(process, key, ResourceKind::AeadKey, |key| {
        let key = <&[u8; 32]>::try_from(key)
            .map_err(|_| failure(CryptoErrorTag::InvalidKey, 32, key.len() as i64))?;
        provider
            .chacha20poly1305_seal(key, nonce, associated_data, plaintext)
            .map_err(provider_failure)
    })
    .map_err(resource_failure)?
}

/// Encrypt and authenticate bounded binary input with ChaCha20-Poly1305.
#[no_mangle]
pub extern "C" fn mesh_crypto_aead_seal(
    key: *const MeshSecretHandle,
    nonce: *const MeshBytes,
    associated_data: *const MeshBytes,
    plaintext: *const MeshBytes,
) -> *mut MeshResult {
    crypto_result(
        with_current_process(|process| {
            aead_seal_for_process(
                process,
                &SystemProvider,
                key,
                nonce,
                associated_data,
                plaintext,
            )
        })
        .map(|ciphertext| bytes_value(&ciphertext)),
    )
}

fn aead_open_for_process(
    process: &Process,
    provider: &impl CryptoProvider,
    key: *const MeshSecretHandle,
    nonce: *const MeshBytes,
    associated_data: *const MeshBytes,
    ciphertext: *const MeshBytes,
) -> Result<Zeroizing<Vec<u8>>, CryptoFailure> {
    let ciphertext = unsafe { required_bytes(ciphertext, MAX_AEAD_CIPHERTEXT_BYTES) }?;
    let mut plaintext = Zeroizing::new(Vec::from(ciphertext));
    let nonce = unsafe { exact_bytes::<AEAD_NONCE_BYTES>(nonce, CryptoErrorTag::InvalidLength) }?;
    let associated_data = unsafe { required_bytes(associated_data, MAX_INPUT_BYTES) }?;
    let operation = with_owned_resource(process, key, ResourceKind::AeadKey, |key| {
        let key = <&[u8; 32]>::try_from(key)
            .map_err(|_| failure(CryptoErrorTag::InvalidKey, 32, key.len() as i64))?;
        provider
            .chacha20poly1305_open(key, nonce, associated_data, &mut plaintext)
            .map_err(provider_failure)
    })
    .map_err(resource_failure)?;
    operation?;
    Ok(plaintext)
}

/// Authenticate and decrypt ChaCha20-Poly1305 ciphertext.
#[no_mangle]
pub extern "C" fn mesh_crypto_aead_open(
    key: *const MeshSecretHandle,
    nonce: *const MeshBytes,
    associated_data: *const MeshBytes,
    ciphertext: *const MeshBytes,
) -> *mut MeshResult {
    crypto_result(
        with_current_process(|process| {
            aead_open_for_process(
                process,
                &SystemProvider,
                key,
                nonce,
                associated_data,
                ciphertext,
            )
        })
        .map(|plaintext| bytes_value(&plaintext)),
    )
}

// ── Blind RSA (profile BR1) ───────────────────────────────────────────

/// The BR1 key a public key wrapper holds: only the exact RFC 9578 SPKI of a
/// 2,048-bit key with e = 65,537.
unsafe fn blind_rsa_public_key(
    public_key: *const MeshBlindRsaPublicKey,
) -> Result<blind_rsa::Br1PublicKey, CryptoFailure> {
    let spki = valid_bytes((*public_key).bytes).ok_or_else(|| {
        failure(
            CryptoErrorTag::InvalidPublicKey,
            blind_rsa::SPKI_BYTES as i64,
            -1,
        )
    })?;
    blind_rsa::public_key_from_spki(spki)
}

fn blind_rsa_public_key_value(spki: &[u8]) -> *mut MeshResult {
    let bytes = bytes_value(spki);
    ok_result(allocate_value(MeshBlindRsaPublicKey { bytes }))
}

/// Parse an RFC 9578 SPKI (RSASSA-PSS, SHA-384, 2,048 bits, e = 65,537).
#[no_mangle]
pub extern "C" fn mesh_crypto_blind_rsa_public_from_spki(
    spki: *const MeshBytes,
) -> *mut MeshResult {
    let spki = try_crypto!(unsafe { valid_bytes(spki) }.ok_or_else(|| failure(
        CryptoErrorTag::InvalidPublicKey,
        blind_rsa::SPKI_BYTES as i64,
        -1
    )))
    .to_vec();
    try_crypto!(blind_rsa::public_key_from_spki(&spki));
    blind_rsa_public_key_value(&spki)
}

/// Blind a message of at most 64 KiB: the 256-byte blinded message for the
/// issuer and the actor-owned state that finalizes its signature.
#[no_mangle]
pub extern "C" fn mesh_crypto_blind_rsa_blind(
    public_key: *const MeshBlindRsaPublicKey,
    message: *const MeshBytes,
) -> *mut MeshResult {
    let key = try_crypto!(unsafe { blind_rsa_public_key(public_key) });
    let message = try_crypto!(unsafe { required_bytes(message, MAX_INPUT_BYTES) });
    let blind_rsa::Blinded { blinded, inverse } =
        try_crypto!(blind_rsa::blind(&SystemProvider, &key, message));
    let blinded = bytes_value(&blinded);
    let output = allocate_value(MeshBlindRsaBlinded {
        blinded,
        state: ptr::null_mut(),
    });
    let result = alloc_result(0, output.cast());
    let state = try_crypto!(with_current_process(move |process| {
        insert_owned_resource(process, ResourceKind::BlindRsaBlindingState, inverse)
            .map_err(resource_failure)
    }));
    unsafe { (*output).state = state };
    result
}

/// Unblind the issuer's 256-byte blind signature with a blinding state,
/// which is consumed on every path. The signature is returned only if it
/// verifies for `message` under the key.
#[no_mangle]
pub extern "C" fn mesh_crypto_blind_rsa_finalize(
    public_key: *const MeshBlindRsaPublicKey,
    message: *const MeshBytes,
    blind_signature: *const MeshBytes,
    state: *const MeshSecretHandle,
) -> *mut MeshResult {
    let inverse = try_crypto!(with_current_process(|process| {
        consume_owned_resource(process, state, ResourceKind::BlindRsaBlindingState)
            .map_err(resource_failure)
    }));
    let key = try_crypto!(unsafe { blind_rsa_public_key(public_key) });
    let message = try_crypto!(unsafe { required_bytes(message, MAX_INPUT_BYTES) });
    let blind_signature = try_crypto!(unsafe { valid_bytes(blind_signature) }.ok_or_else(|| {
        failure(
            CryptoErrorTag::InvalidSignature,
            blind_rsa::MODULUS_BYTES as i64,
            -1,
        )
    }));
    crypto_result(
        blind_rsa::finalize(&key, message, blind_signature, &inverse)
            .map(|signature| bytes_value(&signature)),
    )
}

fn blind_rsa_verify_values(
    public_key: *const MeshBlindRsaPublicKey,
    message: *const MeshBytes,
    signature: *const MeshBytes,
) -> Result<bool, CryptoFailure> {
    let key = unsafe { blind_rsa_public_key(public_key) }?;
    let message = unsafe { required_bytes(message, MAX_INPUT_BYTES) }?;
    let signature = unsafe {
        exact_bytes::<{ blind_rsa::MODULUS_BYTES }>(signature, CryptoErrorTag::InvalidSignature)
    }?;
    Ok(blind_rsa::verify(&key, message, signature))
}

/// Verify an RSASSA-PSS-SHA384 signature: `Ok(false)` for a 256-byte
/// signature that does not verify.
#[no_mangle]
pub extern "C" fn mesh_crypto_blind_rsa_verify(
    public_key: *const MeshBlindRsaPublicKey,
    message: *const MeshBytes,
    signature: *const MeshBytes,
) -> *mut MeshResult {
    crypto_result(blind_rsa_verify_values(public_key, message, signature).map(allocate_value))
}

/// Generate an actor-owned 2,048-bit blind RSA private key (servers only).
#[no_mangle]
pub extern "C" fn mesh_crypto_blind_rsa_generate() -> *mut MeshResult {
    try_crypto!(blind_rsa::server_target());
    let key = try_crypto!(blind_rsa::signer::generate());
    crypto_result(with_current_process(move |process| {
        insert_owned_resource(process, ResourceKind::BlindRsaSecretKey, key)
            .map_err(resource_failure)
    }))
}

fn blind_rsa_from_secret_for_process(
    process: &mut Process,
    material: *const MeshSecretHandle,
) -> Result<*mut MeshSecretHandle, CryptoFailure> {
    // Consumed whatever happens next, as `consume` promises.
    let pkcs8 = consume_owned_resource(process, material, ResourceKind::SecretBytes)
        .map_err(resource_failure)?;
    blind_rsa::server_target()?;
    let key = blind_rsa::signer::import(&pkcs8)?;
    drop(pkcs8);
    insert_owned_resource(process, ResourceKind::BlindRsaSecretKey, key).map_err(resource_failure)
}

/// Consume PKCS#8 DER secret bytes into a blind RSA private key: exactly
/// 2,048 bits, e = 65,537, consistent parts (servers only).
#[no_mangle]
pub extern "C" fn mesh_crypto_blind_rsa_from_secret(
    material: *const MeshSecretHandle,
) -> *mut MeshResult {
    crypto_result(with_current_process(|process| {
        blind_rsa_from_secret_for_process(process, material)
    }))
}

/// The public key of an actor-owned blind RSA private key (servers only).
#[no_mangle]
pub extern "C" fn mesh_crypto_blind_rsa_public(
    private_key: *const MeshSecretHandle,
) -> *mut MeshResult {
    try_crypto!(blind_rsa::server_target());
    let modulus = try_crypto!(with_current_process(|process| {
        with_owned_resource(
            process,
            private_key,
            ResourceKind::BlindRsaSecretKey,
            blind_rsa::signer::public_modulus,
        )
        .map_err(resource_failure)?
    }));
    blind_rsa_public_key_value(&blind_rsa::spki_for_modulus(&modulus))
}

/// Sign a 256-byte blinded message below n with an actor-owned blind RSA
/// private key (servers only). The signature is checked before it is
/// returned.
#[no_mangle]
pub extern "C" fn mesh_crypto_blind_rsa_sign(
    private_key: *const MeshSecretHandle,
    blinded: *const MeshBytes,
) -> *mut MeshResult {
    try_crypto!(blind_rsa::server_target());
    let blinded =
        try_crypto!(unsafe { required_bytes(blinded, blind_rsa::MODULUS_BYTES) }).to_vec();
    let signature = try_crypto!(with_current_process(|process| {
        with_owned_resource(
            process,
            private_key,
            ResourceKind::BlindRsaSecretKey,
            |pkcs8| blind_rsa::signer::sign(pkcs8, &blinded),
        )
        .map_err(resource_failure)?
    }));
    ok_result(bytes_value(&signature))
}

/// Crypto.hmac_sha512(key, msg) -> String
///
/// Returns the HMAC-SHA512 of `msg` keyed with `key`, as a lowercase hex string.
/// RFC 2202 test vector: hmac_sha512("Jefe", "what do ya want for nothing?")
///   = "164b7a7bfcf819e2e395fbe73b56e0a387bd64222e831fd610270cd7ea2505549758bf75c05a994a6d034f65f8f0e6fdcaeab1a34d4a6b4b636e070a38bce737"
#[no_mangle]
pub extern "C" fn mesh_crypto_hmac_sha512(
    key: *const MeshString,
    msg: *const MeshString,
) -> *mut MeshString {
    unsafe {
        let mut mac = <HmacSha512 as Mac>::new_from_slice((*key).as_bytes())
            .expect("HMAC takes a key of any length");
        mac.update((*msg).as_bytes());
        hex_string(&mac.finalize().into_bytes())
    }
}

/// Crypto.uuid4() -> String
///
/// Generates a random RFC 4122 v4 UUID using cryptographically random bytes.
/// Format: 8-4-4-4-12 hex characters separated by hyphens (36 characters total).
/// Version nibble set to 4 (0100), variant bits set to 10xx.
///
/// Uses rand 0.9 API: rand::rng().fill_bytes() (NOT rand::thread_rng() — removed in 0.9).
#[no_mangle]
pub extern "C" fn mesh_crypto_uuid4() -> *mut MeshString {
    mesh_str(&uuid4())
}

pub(crate) fn uuid4() -> String {
    let mut bytes = [0u8; 16];
    rand::rng().fill_bytes(&mut bytes);
    // RFC 4122 version 4 (0b0100) + variant 10xx (0b10xx)
    bytes[6] = (bytes[6] & 0x0f) | 0x40;
    bytes[8] = (bytes[8] & 0x3f) | 0x80;
    format!(
        "{:02x}{:02x}{:02x}{:02x}-{:02x}{:02x}-{:02x}{:02x}-{:02x}{:02x}-{:02x}{:02x}{:02x}{:02x}{:02x}{:02x}",
        bytes[0], bytes[1], bytes[2], bytes[3],
        bytes[4], bytes[5],
        bytes[6], bytes[7],
        bytes[8], bytes[9],
        bytes[10], bytes[11], bytes[12], bytes[13], bytes[14], bytes[15]
    )
}

// ── Standard library: Base64 functions (Phase 135) ─────────────────────────

/// Base64.encode(s) -> String
///
/// Returns the standard Base64-encoded form of `s` using the RFC 4648 standard
/// alphabet with `=` padding characters. Example: encode("hello") = "aGVsbG8="
#[no_mangle]
pub extern "C" fn mesh_base64_encode(s: *const MeshString) -> *mut MeshString {
    mesh_str(&general_purpose::STANDARD.encode(unsafe { (*s).as_bytes() }))
}

/// Base64.decode(s) -> Result<String, String>
///
/// Decodes a standard Base64 string. Tries padded first, then unpadded (lenient).
/// Validates that decoded bytes are valid UTF-8.
/// Returns Err("invalid base64") if decoding fails, Err("invalid utf-8") if not UTF-8.
#[no_mangle]
pub extern "C" fn mesh_base64_decode(s: *const MeshString) -> *mut MeshResult {
    decoded_text(decode_base64(unsafe { (*s).as_str() }), "invalid base64")
}

/// Base64.encode_url(s) -> String
///
/// Returns the URL-safe Base64-encoded form of `s` using the RFC 4648 URL-safe
/// alphabet without padding characters. Example: encode_url("hello") = "aGVsbG8"
#[no_mangle]
pub extern "C" fn mesh_base64_encode_url(s: *const MeshString) -> *mut MeshString {
    mesh_str(&general_purpose::URL_SAFE_NO_PAD.encode(unsafe { (*s).as_bytes() }))
}

/// Base64.decode_url(s) -> Result<String, String>
///
/// Decodes a URL-safe Base64 string (no padding). Validates UTF-8 after decoding.
/// Returns Err("invalid base64") if decoding fails, Err("invalid utf-8") if not UTF-8.
#[no_mangle]
pub extern "C" fn mesh_base64_decode_url(s: *const MeshString) -> *mut MeshResult {
    let decoded = general_purpose::URL_SAFE_NO_PAD.decode(unsafe { (*s).as_str() });
    decoded_text(decoded.ok(), "invalid base64")
}

// ── Standard library: Hex functions (Phase 135) ────────────────────────────

/// Hex.encode(s) -> String
///
/// Returns the lowercase hexadecimal encoding of the bytes of `s`.
/// Example: encode("hi") = "6869"
#[no_mangle]
pub extern "C" fn mesh_hex_encode(s: *const MeshString) -> *mut MeshString {
    hex_string(unsafe { (*s).as_bytes() })
}

/// Hex.decode(s) -> Result<String, String>
///
/// Decodes a hex string (case-insensitive) to the string it represents.
/// Rejects odd-length strings and strings with non-hex characters.
/// Validates that decoded bytes are valid UTF-8.
/// Returns Err("invalid hex") if parsing fails, Err("invalid utf-8") if not UTF-8.
#[no_mangle]
pub extern "C" fn mesh_hex_decode(s: *const MeshString) -> *mut MeshResult {
    decoded_text(decode_hex(unsafe { (*s).as_str() }), "invalid hex")
}

/// The text a legacy decoder's bytes spell: `Err(invalid)` when it could not
/// decode them, `Err("invalid utf-8")` when they are not text.
fn decoded_text(decoded: Option<Vec<u8>>, invalid: &str) -> *mut MeshResult {
    let Some(decoded) = decoded else {
        return err_result(invalid);
    };
    match std::str::from_utf8(&decoded) {
        Ok(text) => alloc_result(0, mesh_str(text).cast()),
        Err(_) => err_result("invalid utf-8"),
    }
}

/// Exercise provider-backed cryptographic boundaries without runtime handles.
#[cfg(feature = "fuzzing")]
pub fn fuzz_crypto_boundaries(data: &[u8]) {
    let input = &data[..data.len().min(MAX_INPUT_BYTES)];
    let provider = SystemProvider;
    let key = provider.sha256(input);
    let salt = provider.sha256(&key);

    let _ = provider.sha512(input);
    let mut hmac = [0; 32];
    let _ = provider.hmac_sha256(&key, input, &mut hmac);
    let mut derived = vec![0; input.first().copied().unwrap_or(31) as usize % 64 + 1];
    let _ = provider.hkdf_sha256(&key, &salt, input, &mut derived);

    if input.first().copied().unwrap_or_default() & 0x1f == 1 {
        let memory_kib = input.get(1).copied().unwrap_or(32) as u32 % 80;
        let iterations = input.get(2).copied().unwrap_or(1) as u32 % 12;
        let parallelism = input.get(3).copied().unwrap_or(1) as u32 % 10;
        let output_length = input.get(4).copied().unwrap_or(32) as usize % 80;
        let argon_salt = &input[..input.len().min(65)];
        let mut output = Zeroizing::new(vec![0xaa; output_length]);
        let _ = provider.argon2id(
            &key,
            argon_salt,
            memory_kib,
            iterations,
            parallelism,
            &mut output,
        );
    }

    let x25519_public = provider.x25519_public(&key);
    let mut shared = [0; 32];
    let _ = provider.x25519_shared(&key, &x25519_public, &mut shared);
    let _ = provider.x25519_shared(&key, &salt, &mut shared);

    let signing_public = provider.ed25519_public(&key);
    if let Ok(signature) = provider.ed25519_sign(&key, input) {
        let _ = provider.ed25519_verify(&signing_public, input, &signature);
        let arbitrary_signature = provider.sha512(input);
        let _ = provider.ed25519_verify(&salt, input, &arbitrary_signature);
    }

    let nonce: [u8; 12] = salt[..12].try_into().unwrap();
    let associated_data = &input[..input.len() / 2];
    if let Ok(ciphertext) = provider.chacha20poly1305_seal(&key, &nonce, associated_data, input) {
        let mut valid = Zeroizing::new(ciphertext);
        let _ = provider.chacha20poly1305_open(&key, &nonce, associated_data, &mut valid);
    }
    let mut arbitrary = Zeroizing::new(input.to_vec());
    let _ = provider.chacha20poly1305_open(&key, &nonce, associated_data, &mut arbitrary);

    // Keep expensive KEM/HPKE paths sparse while still giving libFuzzer a
    // stable selector it can learn to preserve.
    if input.first().copied().unwrap_or_default() & 0x1f == 0 {
        let mut entropy = [0; MLKEM_PRIVATE_SEED_BYTES];
        entropy[..32].copy_from_slice(&key);
        entropy[32..].copy_from_slice(&salt);
        let fixed = FixedProvider::with_random(&entropy);
        let public_key = mlkem_public_key(&entropy);
        if let Ok((ciphertext, _)) =
            mlkem_encapsulate_material(&fixed, public_key.as_slice().try_into().unwrap())
        {
            let _ = mlkem_decapsulate_material(&entropy, ciphertext.as_slice().try_into().unwrap());
        }

        let info = &input[..input.len().min(MAX_HPKE_INFO_BYTES)];
        if let Ok(sealed) = hpke_seal_material(&fixed, &x25519_public, info, associated_data, input)
        {
            let _ = hpke_open_material(&fixed, &key, info, associated_data, &sealed);
        }
        let _ = hpke_open_material(&fixed, &key, info, associated_data, input);
    }

    // Blind RSA: SPKI parsing always; blinding, finalizing, verifying and
    // (on servers) import and signing rejection on a selector, as they cost
    // modular exponentiations.
    let _ = blind_rsa::public_key_from_spki(input);
    if input.first().copied().unwrap_or_default() & 0x1f == 2 {
        blind_rsa::fuzz_blind_rsa_boundaries(input);
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::actor::{Priority, Process, ProcessId};
    use crate::bytes::{mesh_bytes_new, MeshBytes};
    use crate::crypto::provider::FixedProvider;
    use crate::gc::mesh_rt_init;
    use crate::secret::{
        destroy_owned, insert_owned_resource, with_owned_resource, ResourceError, ResourceKind,
    };
    use zeroize::Zeroizing;

    #[repr(C)]
    struct CryptoErrorLayout {
        tag: u8,
        padding: [u8; 7],
        expected: i64,
        actual: i64,
    }

    #[test]
    fn crypto_v2_public_abi_matches_64_bit_layout() {
        let _: extern "C" fn(*const MeshBytes) -> *mut MeshBytes = mesh_crypto_sha256;
        let _: extern "C" fn(*const MeshBytes) -> *mut MeshBytes = mesh_crypto_sha512;
        let _: extern "C" fn(*const MeshBytes) -> *mut MeshString = mesh_crypto_sha256_hex;
        let _: extern "C" fn(*const MeshBytes) -> *mut MeshString = mesh_crypto_sha512_hex;
        let _: extern "C" fn(i64) -> *mut MeshResult = mesh_crypto_random_bytes;
        let _: extern "C" fn(*const MeshSecretHandle, *const MeshBytes) -> *mut MeshResult =
            mesh_crypto_hmac_sha256;
        let _: extern "C" fn(*const MeshSecretHandle, *const MeshBytes) -> *mut MeshResult =
            mesh_crypto_hmac_sha256_tag;
        let _: extern "C" fn(
            *const MeshSecretHandle,
            *const MeshBytes,
            *const MeshBytes,
            i64,
        ) -> *mut MeshResult = mesh_crypto_hkdf_sha256;
        let _: extern "C" fn(
            *const MeshSecretHandle,
            *const MeshBytes,
            i64,
            i64,
            i64,
            i64,
        ) -> *mut MeshResult = mesh_crypto_argon2id;
        let _: extern "C" fn() -> *mut MeshResult = mesh_crypto_x25519_generate;
        let _: extern "C" fn(*const MeshBytes) -> *mut MeshResult = mesh_crypto_x25519_from_seed;
        let _: extern "C" fn(*const MeshSecretHandle) -> *mut MeshResult =
            mesh_crypto_x25519_from_secret;
        let _: extern "C" fn(*const MeshSecretHandle) -> *mut MeshResult =
            mesh_crypto_x25519_public;
        let _: extern "C" fn(
            *const MeshSecretHandle,
            *const MeshX25519PublicKey,
        ) -> *mut MeshResult = mesh_crypto_x25519_shared;
        let _: extern "C" fn(
            *const MeshX25519PublicKey,
            *const MeshBytes,
            *const MeshBytes,
            *const MeshBytes,
        ) -> *mut MeshResult = mesh_crypto_hpke_seal;
        let _: extern "C" fn(
            *const MeshSecretHandle,
            *const MeshBytes,
            *const MeshBytes,
            *const MeshBytes,
        ) -> *mut MeshResult = mesh_crypto_hpke_open;
        let _: extern "C" fn(
            *const MeshX25519PublicKey,
            *const MeshBytes,
            *const MeshBytes,
            *const MeshSecretHandle,
        ) -> *mut MeshResult = mesh_crypto_hpke_seal_secret;
        let _: extern "C" fn(
            *const MeshSecretHandle,
            *const MeshBytes,
            *const MeshBytes,
            *const MeshBytes,
        ) -> *mut MeshResult = mesh_crypto_hpke_open_secret;
        let _: extern "C" fn() -> *mut MeshResult = mesh_crypto_mlkem_generate;
        let _: extern "C" fn(*const MeshBytes) -> *mut MeshResult = mesh_crypto_mlkem_from_seed;
        let _: extern "C" fn(*const MeshSecretHandle) -> *mut MeshResult =
            mesh_crypto_mlkem_from_secret;
        let _: extern "C" fn(*const MeshMlKemPublicKey) -> *mut MeshResult =
            mesh_crypto_mlkem_encapsulate;
        let _: extern "C" fn(
            *const MeshSecretHandle,
            *const MeshMlKemCiphertext,
        ) -> *mut MeshResult = mesh_crypto_mlkem_decapsulate;
        let _: extern "C" fn() -> *mut MeshResult = mesh_crypto_signing_generate;
        let _: extern "C" fn(*const MeshBytes) -> *mut MeshResult = mesh_crypto_signing_from_seed;
        let _: extern "C" fn(*const MeshSecretHandle) -> *mut MeshResult =
            mesh_crypto_signing_from_secret;
        let _: extern "C" fn(*const MeshSecretHandle, *const MeshBytes) -> *mut MeshResult =
            mesh_crypto_sign;
        let _: extern "C" fn(
            *const MeshSigningPublicKey,
            *const MeshBytes,
            *const MeshSignature,
        ) -> *mut MeshResult = mesh_crypto_verify;
        let _: extern "C" fn(*const MeshSecretHandle) -> *mut MeshResult = mesh_crypto_aead_key;
        let _: extern "C" fn(
            *const MeshSecretHandle,
            *const MeshBytes,
            *const MeshBytes,
            *const MeshBytes,
        ) -> *mut MeshResult = mesh_crypto_aead_seal;
        let _: extern "C" fn(
            *const MeshSecretHandle,
            *const MeshBytes,
            *const MeshBytes,
            *const MeshBytes,
        ) -> *mut MeshResult = mesh_crypto_aead_open;
        let _: extern "C" fn() -> *mut MeshResult = mesh_crypto_blind_rsa_generate;
        let _: extern "C" fn(*const MeshSecretHandle) -> *mut MeshResult =
            mesh_crypto_blind_rsa_from_secret;
        let _: extern "C" fn(*const MeshSecretHandle) -> *mut MeshResult =
            mesh_crypto_blind_rsa_public;
        let _: extern "C" fn(*const MeshBytes) -> *mut MeshResult =
            mesh_crypto_blind_rsa_public_from_spki;
        let _: extern "C" fn(*const MeshBlindRsaPublicKey, *const MeshBytes) -> *mut MeshResult =
            mesh_crypto_blind_rsa_blind;
        let _: extern "C" fn(*const MeshSecretHandle, *const MeshBytes) -> *mut MeshResult =
            mesh_crypto_blind_rsa_sign;
        let _: extern "C" fn(
            *const MeshBlindRsaPublicKey,
            *const MeshBytes,
            *const MeshBytes,
            *const MeshSecretHandle,
        ) -> *mut MeshResult = mesh_crypto_blind_rsa_finalize;
        let _: extern "C" fn(
            *const MeshBlindRsaPublicKey,
            *const MeshBytes,
            *const MeshBytes,
        ) -> *mut MeshResult = mesh_crypto_blind_rsa_verify;
        assert_eq!(
            [
                std::mem::size_of::<MeshBlindRsaPublicKey>(),
                std::mem::size_of::<MeshBlindRsaBlinded>(),
                std::mem::offset_of!(MeshBlindRsaBlinded, blinded),
                std::mem::offset_of!(MeshBlindRsaBlinded, state),
                CryptoErrorTag::UnsupportedTarget as usize,
                ResourceKind::BlindRsaSecretKey as usize,
                ResourceKind::BlindRsaBlindingState as usize,
            ],
            [8, 16, 0, 8, 10, 9, 10]
        );

        assert_eq!(
            [
                std::mem::size_of::<usize>(),
                std::mem::size_of::<MeshResult>(),
                std::mem::align_of::<MeshResult>(),
                std::mem::size_of::<MeshSecretHandle>(),
                std::mem::size_of::<MeshX25519PublicKey>(),
                std::mem::size_of::<MeshX25519KeyPair>(),
                std::mem::offset_of!(MeshX25519KeyPair, public_key),
                std::mem::size_of::<MeshMlKemPublicKey>(),
                std::mem::size_of::<MeshMlKemCiphertext>(),
                std::mem::size_of::<MeshMlKemKeyPair>(),
                std::mem::offset_of!(MeshMlKemKeyPair, public_key),
                std::mem::size_of::<MeshTuple2Pointers>(),
                std::mem::offset_of!(MeshTuple2Pointers, first),
                std::mem::offset_of!(MeshTuple2Pointers, second),
                std::mem::size_of::<MeshSigningPublicKey>(),
                std::mem::size_of::<MeshSignature>(),
                std::mem::size_of::<MeshSigningKeyPair>(),
                std::mem::offset_of!(MeshSigningKeyPair, public_key),
                std::mem::size_of::<CryptoErrorLayout>(),
                std::mem::align_of::<CryptoErrorLayout>(),
                std::mem::size_of::<bool>(),
            ],
            [8, 16, 8, 12, 8, 16, 8, 8, 8, 16, 8, 24, 8, 16, 8, 8, 16, 8, 24, 8, 1,]
        );
    }

    #[test]
    fn random_bytes_rejects_negative_length_with_typed_error() {
        mesh_rt_init();

        let result = mesh_crypto_random_bytes(-1);

        unsafe {
            let error = &*((*result).value as *const CryptoErrorLayout);
            assert_eq!(
                ((*result).tag, error.tag, error.expected, error.actual),
                (
                    1,
                    CryptoErrorTag::InvalidLength as u8,
                    MAX_RANDOM_BYTES as i64,
                    -1
                )
            );
        }
    }

    #[test]
    fn random_bytes_rejects_length_above_ceiling() {
        mesh_rt_init();

        let result = mesh_crypto_random_bytes(MAX_RANDOM_BYTES as i64 + 1);

        unsafe {
            let error = &*((*result).value as *const CryptoErrorLayout);
            assert_eq!(
                (error.tag, error.expected, error.actual),
                (
                    CryptoErrorTag::InvalidLength as u8,
                    MAX_RANDOM_BYTES as i64,
                    MAX_RANDOM_BYTES as i64 + 1
                )
            );
        }
    }

    #[test]
    fn random_bytes_maps_provider_failure_to_entropy_unavailable() {
        let Err(error) = random_bytes_with_provider(&FixedProvider::entropy_failure(), 32) else {
            panic!("provider entropy failure was ignored");
        };

        assert_eq!(error.tag as u8, CryptoErrorTag::EntropyUnavailable as u8);
    }

    #[test]
    fn sha256_returns_raw_digest_bytes() {
        mesh_rt_init();
        let input = mesh_bytes_new(b"abc".as_ptr(), 3);

        let digest: *mut MeshBytes = mesh_crypto_sha256(input);

        let expected = [
            0xba, 0x78, 0x16, 0xbf, 0x8f, 0x01, 0xcf, 0xea, 0x41, 0x41, 0x40, 0xde, 0x5d, 0xae,
            0x22, 0x23, 0xb0, 0x03, 0x61, 0xa3, 0x96, 0x17, 0x7a, 0x9c, 0xb4, 0x10, 0xff, 0x61,
            0xf2, 0x00, 0x15, 0xad,
        ];
        assert_eq!(unsafe { (*digest).as_slice() }, expected);
    }

    #[test]
    fn hash_hex_exports_return_lowercase_text() {
        mesh_rt_init();
        let input = mesh_bytes_new(b"abc".as_ptr(), 3);

        let sha256 = mesh_crypto_sha256_hex(input);
        let sha512 = mesh_crypto_sha512_hex(input);

        unsafe {
            assert_eq!(
                ((*sha256).as_str(), (*sha512).as_str()),
                (
                    "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",
                    "ddaf35a193617abacc417349ae20413112e6fa4e89a97ea20a9eeee64b55d39a2\
                     192992a274fc1a836ba3c23a3feebbd454d4423643ce80e2a9ac94fa54ca49f"
                )
            );
        }
    }

    #[test]
    fn direct_hashes_reject_null_but_accept_input_above_the_fallible_api_bound() {
        mesh_rt_init();
        let oversized_data = vec![0u8; MAX_INPUT_BYTES + 1];
        let oversized = mesh_bytes_new(oversized_data.as_ptr(), oversized_data.len() as u64);

        assert!(mesh_crypto_sha256(ptr::null()).is_null());
        assert!(mesh_crypto_sha512(ptr::null()).is_null());
        assert_eq!(unsafe { (*mesh_crypto_sha256(oversized)).len }, 32);
        assert_eq!(unsafe { (*mesh_crypto_sha512(oversized)).len }, 64);
        assert!(!mesh_crypto_sha256_hex(oversized).is_null());
        assert!(!mesh_crypto_sha512_hex(oversized).is_null());
    }

    #[test]
    fn random_bytes_returns_requested_length() {
        mesh_rt_init();

        let result = mesh_crypto_random_bytes(32);

        unsafe {
            assert_eq!((*result).tag, 0);
            assert_eq!((*((*result).value as *const MeshBytes)).len, 32);
        }
    }

    #[test]
    fn hmac_sha256_returns_an_actor_owned_secret() {
        mesh_rt_init();
        let owner = ProcessId(70_001);
        let mut process = Process::new(owner, Priority::Normal);
        let key = insert_owned_resource(
            &mut process,
            ResourceKind::SecretBytes,
            Zeroizing::new(vec![0x2a; 32].into_boxed_slice()),
        )
        .expect("insert HMAC key");
        let message = mesh_bytes_new(b"message".as_ptr(), 7);

        let Ok(output) = hmac_sha256_for_process(&mut process, &SystemProvider, key, message)
        else {
            panic!("HMAC output failed");
        };
        let length = with_owned_resource(&process, output, ResourceKind::SecretBytes, |bytes| {
            bytes.len()
        })
        .expect("read HMAC output");

        assert_eq!(length, 32);
        destroy_owned(owner);
    }

    /// A MAC tag is public: RFC 4231 cases 1, 2 and 6 come back as `Bytes`,
    /// the key stays with its owner, and a key that is not a secret is refused.
    #[test]
    fn hmac_sha256_tag_matches_rfc4231_and_leaves_the_key_owned() {
        mesh_rt_init();
        let owner = ProcessId(70_011);
        let mut process = Process::new(owner, Priority::Normal);
        let hex = |value: &[u8]| {
            value
                .iter()
                .map(|byte| format!("{byte:02x}"))
                .collect::<String>()
        };
        for (key, message, tag) in [
            (
                vec![0x0b; 20],
                b"Hi There".to_vec(),
                "b0344c61d8db38535ca8afceaf0bf12b881dc200c9833da726e9376c2e32cff7",
            ),
            (
                b"Jefe".to_vec(),
                b"what do ya want for nothing?".to_vec(),
                "5bdcc146bf60754e6a042426089575c75a003f089d2739839dec58b964ec3843",
            ),
            (
                vec![0xaa; 131],
                b"Test Using Larger Than Block-Size Key - Hash Key First".to_vec(),
                "60e431591ee0b67f0d8a26aacbf5b77f8e0bc6213728c5140546040f0ee37f54",
            ),
        ] {
            let key = insert_owned_resource(
                &mut process,
                ResourceKind::SecretBytes,
                Zeroizing::new(key.into_boxed_slice()),
            )
            .expect("insert HMAC key");
            let message = mesh_bytes_new(message.as_ptr(), message.len() as u64);
            let output = hmac_sha256_tag_for_process(&process, &SystemProvider, key, message)
                .expect("HMAC tag");
            assert_eq!(hex(&output), tag);
            assert!(
                with_owned_resource(&process, key, ResourceKind::SecretBytes, |_| ()).is_ok(),
                "the key is borrowed"
            );
        }
        let not_secret = insert_owned_resource(
            &mut process,
            ResourceKind::SigningPrivateKey,
            Zeroizing::new(vec![1; 32].into_boxed_slice()),
        )
        .expect("insert signing key");
        let message = mesh_bytes_new(b"m".as_ptr(), 1);
        let error = hmac_sha256_tag_for_process(&process, &SystemProvider, not_secret, message)
            .err()
            .expect("refused");
        assert_eq!(error.tag, CryptoErrorTag::InvalidKey);
        destroy_owned(owner);
    }

    #[test]
    fn hkdf_sha256_returns_the_requested_secret_length() {
        mesh_rt_init();
        let owner = ProcessId(70_002);
        let mut process = Process::new(owner, Priority::Normal);
        let input_key = insert_owned_resource(
            &mut process,
            ResourceKind::SecretBytes,
            Zeroizing::new(vec![0x0b; 22].into_boxed_slice()),
        )
        .expect("insert HKDF input key");
        let salt = mesh_bytes_new(b"salt".as_ptr(), 4);
        let info = mesh_bytes_new(b"mesh-test".as_ptr(), 9);

        let Ok(output) =
            hkdf_sha256_for_process(&mut process, &SystemProvider, input_key, salt, info, 42)
        else {
            panic!("HKDF output failed");
        };
        let length = with_owned_resource(&process, output, ResourceKind::SecretBytes, |bytes| {
            bytes.len()
        })
        .expect("read HKDF output");

        assert_eq!(length, 42);
        destroy_owned(owner);
    }

    #[test]
    fn argon2id_returns_an_actor_owned_secret() {
        mesh_rt_init();
        let owner = ProcessId(70_020);
        let mut process = Process::new(owner, Priority::Normal);
        let password = insert_owned_resource(
            &mut process,
            ResourceKind::SecretBytes,
            Zeroizing::new(b"password".to_vec().into_boxed_slice()),
        )
        .expect("insert Argon2id password");
        let salt = mesh_bytes_new(b"somesalt".as_ptr(), 8);

        let Ok(output) =
            argon2id_for_process(&mut process, &SystemProvider, password, salt, 32, 3, 1, 32)
        else {
            panic!("Argon2id derivation failed");
        };
        let length = with_owned_resource(&process, output, ResourceKind::SecretBytes, |bytes| {
            bytes.len()
        })
        .expect("read Argon2id output");

        assert_eq!(length, 32);
        destroy_owned(owner);
    }

    #[test]
    fn argon2id_rejects_parameters_outside_public_bounds() {
        let mut process = Process::new(ProcessId(70_021), Priority::Normal);
        let short_salt = mesh_bytes_new([0u8; 7].as_ptr(), 7);
        let long_salt = mesh_bytes_new([0u8; 65].as_ptr(), 65);
        let cases = [
            (ptr::null(), 32, 3, 0, 32, 1, 0),
            (ptr::null(), 32, 3, 9, 32, 8, 9),
            (ptr::null(), 31, 3, 4, 32, 32, 31),
            (ptr::null(), 65_537, 3, 1, 32, 65_536, 65_537),
            (ptr::null(), 32, 0, 1, 32, 1, 0),
            (ptr::null(), 32, 11, 1, 32, 10, 11),
            (ptr::null(), 32, 3, 1, 15, 16, 15),
            (ptr::null(), 32, 3, 1, 65, 64, 65),
            (short_salt, 32, 3, 1, 32, 8, 7),
            (long_salt, 32, 3, 1, 32, 64, 65),
        ];

        for (salt, memory, iterations, parallelism, output, expected, actual) in cases {
            let Err(error) = argon2id_for_process(
                &mut process,
                &SystemProvider,
                ptr::null(),
                salt,
                memory,
                iterations,
                parallelism,
                output,
            ) else {
                panic!("invalid Argon2id parameters were accepted");
            };
            assert_eq!(
                (error.tag, error.expected, error.actual),
                (CryptoErrorTag::InvalidLength, expected, actual),
            );
        }
    }

    #[test]
    fn hkdf_sha256_rejects_output_outside_rfc5869_bounds() {
        let mut process = Process::new(ProcessId(70_012), Priority::Normal);

        let Err(empty) = hkdf_sha256_for_process(
            &mut process,
            &SystemProvider,
            ptr::null(),
            ptr::null(),
            ptr::null(),
            0,
        ) else {
            panic!("zero-length HKDF output was accepted");
        };
        let Err(oversized) = hkdf_sha256_for_process(
            &mut process,
            &SystemProvider,
            ptr::null(),
            ptr::null(),
            ptr::null(),
            MAX_HKDF_OUTPUT_BYTES as i64 + 1,
        ) else {
            panic!("oversized HKDF output was accepted");
        };

        assert_eq!(
            (
                empty.tag as u8,
                empty.actual,
                oversized.tag as u8,
                oversized.actual,
            ),
            (
                CryptoErrorTag::InvalidLength as u8,
                0,
                CryptoErrorTag::InvalidLength as u8,
                MAX_HKDF_OUTPUT_BYTES as i64 + 1,
            )
        );
    }

    #[test]
    fn x25519_generation_keeps_private_material_actor_owned() {
        mesh_rt_init();
        let owner = ProcessId(70_003);
        let mut process = Process::new(owner, Priority::Normal);
        let entropy = [0x42; 32];
        let provider = FixedProvider::with_random(&entropy);

        let Ok(generated) = x25519_generate_for_process(&mut process, &provider) else {
            panic!("X25519 generation failed");
        };
        let private_length = with_owned_resource(
            &process,
            generated.private_key,
            ResourceKind::X25519PrivateKey,
            |bytes| bytes.len(),
        )
        .expect("read generated private key");
        let Ok(derived_public) =
            x25519_public_for_process(&process, &SystemProvider, generated.private_key)
        else {
            panic!("derive generated X25519 public key failed");
        };

        assert_eq!((private_length, derived_public), (32, generated.public_key));
        destroy_owned(owner);
    }

    #[test]
    fn x25519_shared_agrees_for_both_keypairs() {
        mesh_rt_init();
        let owner = ProcessId(70_004);
        let mut process = Process::new(owner, Priority::Normal);
        let alice_entropy = [0x31; 32];
        let bob_entropy = [0x72; 32];
        let Ok(alice) =
            x25519_generate_for_process(&mut process, &FixedProvider::with_random(&alice_entropy))
        else {
            panic!("Alice X25519 generation failed");
        };
        let Ok(bob) =
            x25519_generate_for_process(&mut process, &FixedProvider::with_random(&bob_entropy))
        else {
            panic!("Bob X25519 generation failed");
        };
        let alice_public_bytes = mesh_bytes_new(alice.public_key.as_ptr(), 32);
        let bob_public_bytes = mesh_bytes_new(bob.public_key.as_ptr(), 32);
        let alice_public = MeshX25519PublicKey {
            bytes: alice_public_bytes,
        };
        let bob_public = MeshX25519PublicKey {
            bytes: bob_public_bytes,
        };

        let Ok(alice_shared) = x25519_shared_for_process(
            &mut process,
            &SystemProvider,
            alice.private_key,
            &bob_public,
        ) else {
            panic!("Alice shared secret failed");
        };
        let Ok(bob_shared) = x25519_shared_for_process(
            &mut process,
            &SystemProvider,
            bob.private_key,
            &alice_public,
        ) else {
            panic!("Bob shared secret failed");
        };
        let secrets_match = with_owned_resource(
            &process,
            alice_shared,
            ResourceKind::SecretBytes,
            |alice_bytes| {
                with_owned_resource(
                    &process,
                    bob_shared,
                    ResourceKind::SecretBytes,
                    |bob_bytes| alice_bytes == bob_bytes,
                )
            },
        )
        .expect("read Alice shared secret")
        .expect("read Bob shared secret");

        assert!(secrets_match);
        destroy_owned(owner);
    }

    #[test]
    fn hpke_base_mode_matches_rfc9180_a2_1_sequence_zero() {
        fn hex(value: &str) -> Vec<u8> {
            value
                .as_bytes()
                .chunks_exact(2)
                .map(|chunk| u8::from_str_radix(std::str::from_utf8(chunk).unwrap(), 16).unwrap())
                .collect()
        }

        let input_key_material =
            hex("909a9b35d3dc4713a5e72a4da274b55d3d3821a37e5d099e74a647db583a904b");
        let recipient_public_key: [u8; 32] =
            hex("4310ee97d88cc1f088a5576c77ab0cf5c3ac797f3d95139c6c84b5429c59662a")
                .try_into()
                .unwrap();
        let recipient_private_key: [u8; 32] =
            hex("8057991eef8f1f1af18f4a9491d16a1ce333f695d4db8e38da75975c4478e0fb")
                .try_into()
                .unwrap();
        let info = hex("4f6465206f6e2061204772656369616e2055726e");
        let plaintext = hex("4265617574792069732074727574682c20747275746820626561757479");
        let associated_data = hex("436f756e742d30");
        let expected = hex(
            "1afa08d3dec047a643885163f1180476fa7ddb54c6a8029ea33f95796bf2ac4a\
             1c5250d8034ec2b784ba2cfd69dbdb8af406cfe3ff938e131f0def8c8b60b4db\
             21993c62ce81883d2dd1b51a28",
        );
        let provider = FixedProvider::with_random(&input_key_material);

        let Ok(sealed) = hpke_seal_material(
            &provider,
            &recipient_public_key,
            &info,
            &associated_data,
            &plaintext,
        ) else {
            panic!("RFC 9180 seal failed");
        };
        assert_eq!(sealed, expected);
        let Ok(opened) = hpke_open_material(
            &provider,
            &recipient_private_key,
            &info,
            &associated_data,
            &sealed,
        ) else {
            panic!("RFC 9180 open failed");
        };
        assert_eq!(&opened[..], plaintext);

        let mut tampered = sealed;
        *tampered.last_mut().unwrap() ^= 1;
        assert!(matches!(
            hpke_open_material(
                &provider,
                &recipient_private_key,
                &info,
                &associated_data,
                &tampered,
            ),
            Err(CryptoFailure {
                tag: CryptoErrorTag::AuthenticationFailed,
                ..
            })
        ));
    }

    #[test]
    fn hpke_export_matches_rfc9180_a2_1_exported_values() {
        fn hex(value: &str) -> Vec<u8> {
            value
                .as_bytes()
                .chunks_exact(2)
                .map(|chunk| u8::from_str_radix(std::str::from_utf8(chunk).unwrap(), 16).unwrap())
                .collect()
        }

        let input_key_material =
            hex("909a9b35d3dc4713a5e72a4da274b55d3d3821a37e5d099e74a647db583a904b");
        let provider = FixedProvider::with_random(&input_key_material);
        let recipient_public_key: [u8; 32] =
            hex("4310ee97d88cc1f088a5576c77ab0cf5c3ac797f3d95139c6c84b5429c59662a")
                .try_into()
                .unwrap();
        let recipient_private_key: [u8; 32] =
            hex("8057991eef8f1f1af18f4a9491d16a1ce333f695d4db8e38da75975c4478e0fb")
                .try_into()
                .unwrap();
        let info = hex("4f6465206f6e2061204772656369616e2055726e");
        let Ok((sealed, sender_secret)) =
            hpke_seal_keeping_secret(&provider, &recipient_public_key, &info, b"", b"pt")
        else {
            panic!("RFC 9180 seal failed");
        };
        let Ok((_, receiver_secret)) =
            hpke_open_keeping_secret(&provider, &recipient_private_key, &info, b"", &sealed)
        else {
            panic!("RFC 9180 open failed");
        };
        for (context, expected) in [
            (
                "",
                "4bbd6243b8bb54cec311fac9df81841b6fd61f56538a775e7c80a9f40160606e",
            ),
            (
                "00",
                "8c1df14732580e5501b00f82b10a1647b40713191b7c1240ac80e2b68808ba69",
            ),
            (
                "54657374436f6e74657874",
                "5acb09211139c43b3090489a9da433e8a30ee7188ba8b0a9a1ccf0c229283e53",
            ),
        ] {
            let context = hex(context);
            for shared_secret in [&sender_secret, &receiver_secret] {
                assert_eq!(
                    &hpke_export(&provider, shared_secret, &info, &context)[..],
                    hex(expected)
                );
            }
        }
    }

    #[test]
    fn derived_aead_matches_an_independent_derivation_and_takes_large_messages() {
        // Expected from Node (OpenSSL): HKDF-SHA-256 with salt 0x22 * 64 over
        // secret 0x11 * 32, labels "key" and "nonce", then ChaCha20-Poly1305.
        let secret = [0x11; 32];
        let salt = [0x22; 64];
        let Ok(sealed) =
            derived_aead_seal_material(&SystemProvider, &secret, &salt, b"", b"OHTTP response")
        else {
            panic!("derived seal failed");
        };
        assert_eq!(
            sealed,
            b"\x81\x06\x83\x21\x19\x38\xfc\xe0\x25\x72\x22\x42\x3d\x79\x50\xb5\
              \xf6\x40\x5c\x2a\xb9\x19\xe5\xdf\xed\x07\x29\xcb\xd8\x36"
        );
        let large = vec![7; MAX_DERIVED_AEAD_BYTES];
        let Ok(sealed_large) =
            derived_aead_seal_material(&SystemProvider, &secret, &salt, b"", &large)
        else {
            panic!("large derived seal failed");
        };
        let Ok(opened) =
            derived_aead_open_material(&SystemProvider, &secret, &salt, b"", &sealed_large)
        else {
            panic!("large derived open failed");
        };
        assert_eq!(&opened[..], &large[..]);
        let mut tampered = sealed_large;
        tampered[0] ^= 1;
        assert!(matches!(
            derived_aead_open_material(&SystemProvider, &secret, &salt, b"", &tampered),
            Err(CryptoFailure {
                tag: CryptoErrorTag::AuthenticationFailed,
                ..
            })
        ));
        assert!(matches!(
            derived_aead_open_material(&SystemProvider, &secret, &[0x23; 64], b"", &sealed),
            Err(CryptoFailure {
                tag: CryptoErrorTag::AuthenticationFailed,
                ..
            })
        ));
        assert!(derived_aead_seal_material(
            &SystemProvider,
            &secret,
            &salt,
            b"",
            &vec![0; MAX_DERIVED_AEAD_BYTES + 1]
        )
        .is_err());
    }

    /// The published release vector (NIST ACVP keyGen tcId 26) at the
    /// runtime level; Morse's `scripts/prove-m14.sh` runs this test by name.
    /// `mlkem_tests` checks every ACVP ML-KEM-768 case.
    #[test]
    fn nist_acvp_mlkem768_keygen_tc26_matches_public_key() {
        let vector: serde_json::Value = serde_json::from_str(include_str!(
            "../../../tests/vectors/mlkem/mlkem768-keygen-acvp-tc26.json"
        ))
        .expect("ML-KEM vector file");
        let hex = |field: &serde_json::Value| {
            crate::bytes::decode_hex(field.as_str().expect("a hex string")).expect("hex")
        };
        let seed = [hex(&vector["input"]["d"]), hex(&vector["input"]["z"])].concat();
        assert_eq!(
            mlkem_public_key(&seed),
            hex(&vector["expected"]["public_key"])
        );
    }

    #[test]
    fn mlkem768_round_trip_keeps_seed_and_shared_secret_zeroizing() {
        let seed_entropy = [0x41; 64];
        let encapsulation_entropy = [0x73; 32];
        let Ok((private_seed, public_key)) =
            mlkem_key_material(&FixedProvider::with_random(&seed_entropy))
        else {
            panic!("ML-KEM key generation failed");
        };
        let Ok((ciphertext, sender_secret)) = mlkem_encapsulate_material(
            &FixedProvider::with_random(&encapsulation_entropy),
            public_key.as_slice().try_into().unwrap(),
        ) else {
            panic!("ML-KEM encapsulation failed");
        };
        let receiver_secret =
            mlkem_decapsulate_material(&private_seed, ciphertext.as_slice().try_into().unwrap());

        assert_eq!(
            (
                private_seed.len(),
                public_key.len(),
                ciphertext.len(),
                sender_secret.as_ref(),
            ),
            (64, 1184, 1088, receiver_secret.as_ref())
        );
    }

    #[test]
    fn x25519_rejects_malformed_public_key_wrapper() {
        mesh_rt_init();
        let short_key = [0u8; 31];
        let public_key = MeshX25519PublicKey {
            bytes: mesh_bytes_new(short_key.as_ptr(), short_key.len() as u64),
        };

        let Err(error) = (unsafe { x25519_public_key_bytes(&public_key) }) else {
            panic!("malformed X25519 public key was accepted");
        };

        assert_eq!(
            (error.tag as u8, error.expected, error.actual),
            (CryptoErrorTag::InvalidPublicKey as u8, 32, 31)
        );
    }

    #[test]
    fn x25519_secret_constructor_matches_rfc7748_and_consumes_source() {
        mesh_rt_init();
        let owner = ProcessId(70_019);
        let mut process = Process::new(owner, Priority::Normal);
        let private_key = [
            0x77, 0x07, 0x6d, 0x0a, 0x73, 0x18, 0xa5, 0x7d, 0x3c, 0x16, 0xc1, 0x72, 0x51, 0xb2,
            0x66, 0x45, 0xdf, 0x4c, 0x2f, 0x87, 0xeb, 0xc0, 0x99, 0x2a, 0xb1, 0x77, 0xfb, 0xa5,
            0x1d, 0xb9, 0x2c, 0x2a,
        ];
        let expected_public_key = [
            0x85, 0x20, 0xf0, 0x09, 0x89, 0x30, 0xa7, 0x54, 0x74, 0x8b, 0x7d, 0xdc, 0xb4, 0x3e,
            0xf7, 0x5a, 0x0d, 0xbf, 0x3a, 0x0d, 0x26, 0x38, 0x1a, 0xf4, 0xeb, 0xa4, 0xa9, 0x8e,
            0xaa, 0x9b, 0x4e, 0x6a,
        ];
        let source = insert_owned_resource(
            &mut process,
            ResourceKind::SecretBytes,
            Zeroizing::new(private_key.to_vec().into_boxed_slice()),
        )
        .expect("insert X25519 material");

        let Ok((derived_private_key, public_key)) =
            x25519_from_secret_for_process(&mut process, &SystemProvider, source)
        else {
            panic!("derive X25519 keypair failed");
        };

        assert_eq!(public_key, expected_public_key);
        assert_eq!(
            with_owned_resource(&process, source, ResourceKind::SecretBytes, |_| ()),
            Err(ResourceError::StaleHandle)
        );
        assert!(with_owned_resource(
            &process,
            derived_private_key,
            ResourceKind::X25519PrivateKey,
            |_| ()
        )
        .is_ok());
        destroy_owned(owner);
    }

    #[test]
    fn secret_key_constructors_consume_sources_rejected_for_invalid_length() {
        mesh_rt_init();
        let owner = ProcessId(70_020);
        let mut process = Process::new(owner, Priority::Normal);
        let signing_source = insert_owned_resource(
            &mut process,
            ResourceKind::SecretBytes,
            Zeroizing::new(vec![0x51; 31].into_boxed_slice()),
        )
        .expect("insert invalid signing material");
        let signing_error =
            signing_from_secret_for_process(&mut process, &SystemProvider, signing_source)
                .expect_err("invalid signing material was accepted");
        assert_eq!(
            (
                signing_error.tag as u8,
                signing_error.expected,
                signing_error.actual,
                with_owned_resource(&process, signing_source, ResourceKind::SecretBytes, |_| (),),
            ),
            (
                CryptoErrorTag::InvalidKey as u8,
                32,
                31,
                Err(ResourceError::StaleHandle),
            )
        );

        let mlkem_source = insert_owned_resource(
            &mut process,
            ResourceKind::SecretBytes,
            Zeroizing::new(vec![0x52; MLKEM_PRIVATE_SEED_BYTES - 1].into_boxed_slice()),
        )
        .expect("insert invalid ML-KEM material");
        let mlkem_error = mlkem_from_secret_for_process(&mut process, mlkem_source)
            .expect_err("invalid ML-KEM material was accepted");
        assert_eq!(
            (
                mlkem_error.tag as u8,
                mlkem_error.expected,
                mlkem_error.actual,
                with_owned_resource(&process, mlkem_source, ResourceKind::SecretBytes, |_| (),),
            ),
            (
                CryptoErrorTag::InvalidKey as u8,
                MLKEM_PRIVATE_SEED_BYTES as i64,
                MLKEM_PRIVATE_SEED_BYTES as i64 - 1,
                Err(ResourceError::StaleHandle),
            )
        );
        destroy_owned(owner);
    }

    #[test]
    fn signing_round_trip_verifies() {
        mesh_rt_init();
        let owner = ProcessId(70_005);
        let mut process = Process::new(owner, Priority::Normal);
        let entropy = [0x55; 32];
        let Ok(generated) =
            signing_generate_for_process(&mut process, &FixedProvider::with_random(&entropy))
        else {
            panic!("signing key generation failed");
        };
        let public_bytes = mesh_bytes_new(generated.public_key.as_ptr(), 32);
        let public_key = MeshSigningPublicKey {
            bytes: public_bytes,
        };
        let message = mesh_bytes_new(b"signed message".as_ptr(), 14);
        let Ok(signature_bytes) =
            sign_for_process(&process, &SystemProvider, generated.private_key, message)
        else {
            panic!("signing failed");
        };
        let signature = MeshSignature {
            bytes: mesh_bytes_new(signature_bytes.as_ptr(), 64),
        };

        let Ok(verified) = verify_with_provider(&SystemProvider, &public_key, message, &signature)
        else {
            panic!("verification input should be valid");
        };

        assert!(verified);
        destroy_owned(owner);
    }

    #[test]
    fn signing_seed_requires_exactly_32_bytes() {
        mesh_rt_init();

        for seed in [&b"short"[..], &[0u8; 33][..]] {
            let input = mesh_bytes_new(seed.as_ptr(), seed.len() as u64);
            let result = mesh_crypto_signing_from_seed(input);
            let (result_tag, error) = unsafe {
                (
                    (*result).tag,
                    &*((*result).value as *const CryptoErrorLayout),
                )
            };

            assert_eq!(
                (result_tag, error.tag, error.expected, error.actual),
                (
                    1,
                    CryptoErrorTag::InvalidLength as u8,
                    32,
                    seed.len() as i64
                )
            );
        }
    }

    #[test]
    fn x25519_seed_requires_exactly_32_bytes() {
        mesh_rt_init();

        for seed in [&b"short"[..], &[0u8; 33][..]] {
            let input = mesh_bytes_new(seed.as_ptr(), seed.len() as u64);
            let result = mesh_crypto_x25519_from_seed(input);
            let (result_tag, error) = unsafe {
                (
                    (*result).tag,
                    &*((*result).value as *const CryptoErrorLayout),
                )
            };

            assert_eq!(
                (result_tag, error.tag, error.expected, error.actual),
                (
                    1,
                    CryptoErrorTag::InvalidLength as u8,
                    32,
                    seed.len() as i64
                )
            );
        }
    }

    #[test]
    fn mlkem768_rejects_noncanonical_seed_public_key_and_ciphertext_lengths() {
        mesh_rt_init();

        for seed in [&[0u8; 63][..], &[0u8; 65][..]] {
            let input = mesh_bytes_new(seed.as_ptr(), seed.len() as u64);
            let result = mesh_crypto_mlkem_from_seed(input);
            let (result_tag, error) = unsafe {
                (
                    (*result).tag,
                    &*((*result).value as *const CryptoErrorLayout),
                )
            };
            assert_eq!(
                (result_tag, error.tag, error.expected, error.actual),
                (
                    1,
                    CryptoErrorTag::InvalidLength as u8,
                    MLKEM_PRIVATE_SEED_BYTES as i64,
                    seed.len() as i64,
                )
            );
        }

        let short_public = [0u8; MLKEM_PUBLIC_KEY_BYTES - 1];
        let public_key = MeshMlKemPublicKey {
            bytes: mesh_bytes_new(short_public.as_ptr(), short_public.len() as u64),
        };
        let result = mesh_crypto_mlkem_encapsulate(&public_key);
        let error = unsafe { &*((*result).value as *const CryptoErrorLayout) };
        assert_eq!(
            (error.tag, error.expected, error.actual),
            (
                CryptoErrorTag::InvalidPublicKey as u8,
                MLKEM_PUBLIC_KEY_BYTES as i64,
                short_public.len() as i64,
            )
        );

        let short_ciphertext = [0u8; MLKEM_CIPHERTEXT_BYTES - 1];
        let ciphertext = MeshMlKemCiphertext {
            bytes: mesh_bytes_new(short_ciphertext.as_ptr(), short_ciphertext.len() as u64),
        };
        let result = mesh_crypto_mlkem_decapsulate(ptr::null(), &ciphertext);
        let error = unsafe { &*((*result).value as *const CryptoErrorLayout) };
        assert_eq!(
            (error.tag, error.expected, error.actual),
            (
                CryptoErrorTag::InvalidLength as u8,
                MLKEM_CIPHERTEXT_BYTES as i64,
                short_ciphertext.len() as i64,
            )
        );
    }

    #[test]
    fn private_key_use_rejects_a_different_actor_owner() {
        mesh_rt_init();
        let owner = ProcessId(70_010);
        let other = ProcessId(70_011);
        let mut owner_process = Process::new(owner, Priority::Normal);
        let other_process = Process::new(other, Priority::Normal);
        let entropy = [0x29; 32];
        let Ok(generated) =
            signing_generate_for_process(&mut owner_process, &FixedProvider::with_random(&entropy))
        else {
            panic!("signing key generation failed");
        };
        let message = mesh_bytes_new(b"message".as_ptr(), 7);

        let Err(error) = sign_for_process(
            &other_process,
            &SystemProvider,
            generated.private_key,
            message,
        ) else {
            panic!("foreign actor used private key");
        };
        let owner_still_has_key = with_owned_resource(
            &owner_process,
            generated.private_key,
            ResourceKind::SigningPrivateKey,
            |bytes| bytes.len() == 32,
        )
        .expect("owner key disappeared after rejected access");

        assert_eq!(
            (error.tag as u8, owner_still_has_key),
            (CryptoErrorTag::SecretDestroyed as u8, true)
        );
        destroy_owned(owner);
    }

    #[test]
    fn verify_returns_false_for_a_valid_sized_bad_signature() {
        mesh_rt_init();
        let owner = ProcessId(70_006);
        let mut process = Process::new(owner, Priority::Normal);
        let entropy = [0x37; 32];
        let Ok(generated) =
            signing_generate_for_process(&mut process, &FixedProvider::with_random(&entropy))
        else {
            panic!("signing key generation failed");
        };
        let public_key = MeshSigningPublicKey {
            bytes: mesh_bytes_new(generated.public_key.as_ptr(), 32),
        };
        let message = mesh_bytes_new(b"message".as_ptr(), 7);
        let Ok(mut signature_bytes) =
            sign_for_process(&process, &SystemProvider, generated.private_key, message)
        else {
            panic!("signing failed");
        };
        signature_bytes[0] ^= 1;
        let signature = MeshSignature {
            bytes: mesh_bytes_new(signature_bytes.as_ptr(), 64),
        };

        let Ok(verified) = verify_with_provider(&SystemProvider, &public_key, message, &signature)
        else {
            panic!("valid-sized signature should not be a typed error");
        };

        assert!(!verified);
        destroy_owned(owner);
    }

    #[test]
    fn verify_rejects_a_malformed_signature_with_typed_error() {
        mesh_rt_init();
        let public_data = [0u8; 32];
        let public_key = MeshSigningPublicKey {
            bytes: mesh_bytes_new(public_data.as_ptr(), 32),
        };
        let message = mesh_bytes_new(b"message".as_ptr(), 7);
        let short_signature = [0u8; 63];
        let signature = MeshSignature {
            bytes: mesh_bytes_new(short_signature.as_ptr(), short_signature.len() as u64),
        };

        let Err(error) = verify_with_provider(&SystemProvider, &public_key, message, &signature)
        else {
            panic!("malformed signature was not rejected");
        };

        assert_eq!(
            (error.tag as u8, error.expected, error.actual),
            (CryptoErrorTag::InvalidSignature as u8, 64, 63)
        );
    }

    #[test]
    fn aead_key_rejection_still_consumes_source_secret() {
        mesh_rt_init();
        let owner = ProcessId(70_007);
        let mut process = Process::new(owner, Priority::Normal);
        let source = insert_owned_resource(
            &mut process,
            ResourceKind::SecretBytes,
            Zeroizing::new(vec![0x91; 31].into_boxed_slice()),
        )
        .expect("insert invalid AEAD material");

        let Err(error) = aead_key_for_process(&mut process, source) else {
            panic!("invalid AEAD material was accepted");
        };
        let old_handle = with_owned_resource(&process, source, ResourceKind::SecretBytes, |_| ());

        assert_eq!(
            (error.tag as u8, old_handle),
            (
                CryptoErrorTag::InvalidKey as u8,
                Err(ResourceError::StaleHandle)
            )
        );
        destroy_owned(owner);
    }

    #[test]
    fn aead_seal_and_open_round_trip() {
        mesh_rt_init();
        let owner = ProcessId(70_008);
        let mut process = Process::new(owner, Priority::Normal);
        let source = insert_owned_resource(
            &mut process,
            ResourceKind::SecretBytes,
            Zeroizing::new(vec![0x44; 32].into_boxed_slice()),
        )
        .expect("insert AEAD material");
        let Ok(key) = aead_key_for_process(&mut process, source) else {
            panic!("valid AEAD material rejected");
        };
        let nonce_data = [0x22u8; 12];
        let nonce = mesh_bytes_new(nonce_data.as_ptr(), 12);
        let associated_data = mesh_bytes_new(b"context".as_ptr(), 7);
        let plaintext = mesh_bytes_new(b"secret plaintext".as_ptr(), 16);

        let Ok(ciphertext) = aead_seal_for_process(
            &process,
            &SystemProvider,
            key,
            nonce,
            associated_data,
            plaintext,
        ) else {
            panic!("AEAD seal failed");
        };
        let ciphertext = mesh_bytes_new(ciphertext.as_ptr(), ciphertext.len() as u64);
        let Ok(opened) = aead_open_for_process(
            &process,
            &SystemProvider,
            key,
            nonce,
            associated_data,
            ciphertext,
        ) else {
            panic!("AEAD open failed");
        };

        assert_eq!(&opened[..], b"secret plaintext");
        destroy_owned(owner);
    }

    #[test]
    fn aead_rejects_nonstandard_nonce_length_before_key_use() {
        mesh_rt_init();
        let process = Process::new(ProcessId(70_013), Priority::Normal);
        let nonce_data = [0u8; 11];
        let nonce = mesh_bytes_new(nonce_data.as_ptr(), nonce_data.len() as u64);
        let empty = mesh_bytes_new(ptr::null(), 0);

        let Err(error) =
            aead_seal_for_process(&process, &SystemProvider, ptr::null(), nonce, empty, empty)
        else {
            panic!("nonstandard AEAD nonce was accepted");
        };

        assert_eq!(
            (error.tag as u8, error.expected, error.actual),
            (CryptoErrorTag::InvalidLength as u8, 12, 11)
        );
    }

    #[test]
    fn aead_open_reports_authentication_failure_without_plaintext() {
        mesh_rt_init();
        let owner = ProcessId(70_009);
        let mut process = Process::new(owner, Priority::Normal);
        let source = insert_owned_resource(
            &mut process,
            ResourceKind::SecretBytes,
            Zeroizing::new(vec![0x64; 32].into_boxed_slice()),
        )
        .expect("insert AEAD material");
        let Ok(key) = aead_key_for_process(&mut process, source) else {
            panic!("valid AEAD material rejected");
        };
        let nonce_data = [0x32u8; 12];
        let nonce = mesh_bytes_new(nonce_data.as_ptr(), 12);
        let associated_data = mesh_bytes_new(b"context".as_ptr(), 7);
        let plaintext = mesh_bytes_new(b"private".as_ptr(), 7);
        let Ok(mut ciphertext) = aead_seal_for_process(
            &process,
            &SystemProvider,
            key,
            nonce,
            associated_data,
            plaintext,
        ) else {
            panic!("AEAD seal failed");
        };
        let last = ciphertext.len() - 1;
        ciphertext[last] ^= 1;
        let ciphertext = mesh_bytes_new(ciphertext.as_ptr(), ciphertext.len() as u64);

        let Err(error) = aead_open_for_process(
            &process,
            &SystemProvider,
            key,
            nonce,
            associated_data,
            ciphertext,
        ) else {
            panic!("tampered ciphertext released plaintext");
        };

        assert_eq!(error.tag as u8, CryptoErrorTag::AuthenticationFailed as u8);
        destroy_owned(owner);
    }

    /// Only pairs of hex digits decode: a sign, a letter whose lowercase
    /// form is longer, or a character split across two pairs is refused.
    #[test]
    fn hex_decode_refuses_anything_but_hex_digit_pairs() {
        mesh_rt_init();
        for text in ["+f", "-1", "0é0", "İİ", "é"] {
            let result = mesh_hex_decode(mesh_str(text));
            unsafe {
                assert_eq!((*result).tag, 1, "{text:?} decoded");
                assert_eq!(
                    (*((*result).value as *const MeshString)).as_str(),
                    "invalid hex"
                );
            }
        }
        let result = mesh_hex_decode(mesh_str("4A6f"));
        unsafe { assert_eq!((*((*result).value as *const MeshString)).as_str(), "Jo") };
    }

    fn created<T>(result: *mut MeshResult) -> *mut T {
        let result = unsafe { &*result };
        assert_eq!(result.tag, 0, "expected Ok");
        result.value.cast()
    }

    /// The error's tag, expected and actual values.
    fn refused(result: *mut MeshResult) -> (u8, i64, i64) {
        let result = unsafe { &*result };
        assert_eq!(result.tag, 1, "expected Err");
        let error = unsafe { &*result.value.cast::<CryptoErrorLayout>() };
        (error.tag, error.expected, error.actual)
    }

    fn tag_of(result: *mut MeshResult) -> u8 {
        refused(result).0
    }

    fn bytes(data: &[u8]) -> *mut MeshBytes {
        mesh_bytes_new(data.as_ptr(), data.len() as u64)
    }

    fn contents<'a>(bytes: *const MeshBytes) -> &'a [u8] {
        unsafe { (*bytes).as_slice() }
    }

    /// A secret of the calling actor holding `data`.
    fn secret(data: &[u8]) -> *mut MeshSecretHandle {
        let process = crate::actor::current_process().expect("an actor");
        let mut process = process.lock();
        let material = Zeroizing::new(data.to_vec().into_boxed_slice());
        insert_owned_resource(&mut process, ResourceKind::SecretBytes, material).expect("secret")
    }

    /// What a resource of the calling actor holds.
    fn revealed(handle: *const MeshSecretHandle, kind: ResourceKind) -> Vec<u8> {
        let process = crate::actor::current_process().expect("an actor");
        let process = process.lock();
        with_owned_resource(&process, handle, kind, <[u8]>::to_vec).expect("live resource")
    }

    /// Entry points that act for the calling actor refuse to run off one,
    /// without making or keeping anything.
    #[test]
    fn crypto_entry_points_need_a_calling_actor() {
        mesh_rt_init();
        let internal = CryptoErrorTag::InternalFailure as u8;
        let message = bytes(b"message");
        assert_eq!(
            tag_of(mesh_crypto_hmac_sha256(ptr::null(), message)),
            internal
        );
        assert_eq!(tag_of(mesh_crypto_x25519_generate()), internal);
        assert_eq!(tag_of(mesh_crypto_mlkem_generate()), internal);
        assert_eq!(tag_of(mesh_crypto_signing_generate()), internal);
        assert_eq!(tag_of(mesh_crypto_aead_key(ptr::null())), internal);
    }

    /// Every provider and retype failure has the CryptoError it documents,
    /// and an exact-length input is refused with the length it had.
    #[test]
    fn failures_map_to_the_documented_crypto_errors() {
        mesh_rt_init();
        let tags = [
            ProviderError::EntropyUnavailable,
            ProviderError::InvalidLength,
            ProviderError::ResourceLimitExceeded,
            ProviderError::InvalidPublicKey,
            ProviderError::AuthenticationFailed,
        ]
        .map(|error| provider_failure(error).tag);
        assert_eq!(
            tags,
            [
                CryptoErrorTag::EntropyUnavailable,
                CryptoErrorTag::InternalFailure,
                CryptoErrorTag::ResourceLimitExceeded,
                CryptoErrorTag::InvalidPublicKey,
                CryptoErrorTag::AuthenticationFailed,
            ]
        );
        let removed = || Zeroizing::new(vec![0; 4].into_boxed_slice());
        let rejected = failure(CryptoErrorTag::InvalidKey, 32, 4);
        assert_eq!(
            [
                retype_failure(RetypeError::Resource(ResourceError::WrongKind)),
                retype_failure(RetypeError::Rejected {
                    error: rejected,
                    removed: removed(),
                }),
                retype_failure(RetypeError::GenerationExhausted { removed: removed() }),
            ]
            .map(|error| error.tag),
            [
                CryptoErrorTag::InvalidKey,
                CryptoErrorTag::InvalidKey,
                CryptoErrorTag::ResourceLimitExceeded,
            ]
        );
        assert_eq!(
            [
                ResourceError::ResourceLimitExceeded,
                ResourceError::WrongKind,
                ResourceError::StaleHandle,
                ResourceError::WrongOwner,
                ResourceError::OwnerExited,
            ]
            .map(|error| resource_failure(error).tag),
            [
                CryptoErrorTag::ResourceLimitExceeded,
                CryptoErrorTag::InvalidKey,
                CryptoErrorTag::SecretDestroyed,
                CryptoErrorTag::SecretDestroyed,
                CryptoErrorTag::SecretDestroyed,
            ]
        );
        assert_eq!(
            unsafe { exact_bytes::<12>(ptr::null(), CryptoErrorTag::InvalidLength) },
            Err(failure(CryptoErrorTag::InvalidLength, 12, -1))
        );
        assert_eq!(
            unsafe { required_bytes(ptr::null(), 4) },
            Err(failure(CryptoErrorTag::InvalidLength, 4, -1))
        );
        assert!(mesh_crypto_sha256_hex(ptr::null()).is_null());
        assert!(mesh_crypto_sha512_hex(ptr::null()).is_null());
        let Err(error) = random_bytes_with_provider(&FixedProvider::with_random(&[]), 1) else {
            panic!("a provider without entropy filled a buffer");
        };
        assert_eq!(error.tag, CryptoErrorTag::InternalFailure);
    }

    /// Each key agreement, encryption and signature entry point, called as
    /// a Mesh program calls it: what one side makes, the other opens.
    #[test]
    fn crypto_entry_points_round_trip_for_the_calling_actor() {
        mesh_rt_init();
        crate::secret::as_test_actor(|_| unsafe {
            let key = secret(&[0x11; 32]);
            let mac = created(mesh_crypto_hmac_sha256(key, bytes(b"message")));
            assert_eq!(revealed(mac, ResourceKind::SecretBytes).len(), 32);
            let salt = bytes(b"somesalt");
            let derived = created(mesh_crypto_hkdf_sha256(key, salt, bytes(b"info"), 16));
            assert_eq!(revealed(derived, ResourceKind::SecretBytes).len(), 16);
            let hashed = created(mesh_crypto_argon2id(key, salt, 8, 1, 1, 16));
            assert_eq!(revealed(hashed, ResourceKind::SecretBytes).len(), 16);

            let alice: *mut MeshX25519KeyPair = created(mesh_crypto_x25519_generate());
            let bob: *mut MeshX25519KeyPair =
                created(mesh_crypto_x25519_from_seed(bytes(&[2; 32])));
            let carol: *mut MeshX25519KeyPair =
                created(mesh_crypto_x25519_from_secret(secret(&[2; 32])));
            assert_eq!(
                contents((*bob).public_key.bytes),
                contents((*carol).public_key.bytes)
            );
            let public: *mut MeshX25519PublicKey =
                created(mesh_crypto_x25519_public((*alice).private_key));
            assert_eq!(
                contents((*public).bytes),
                contents((*alice).public_key.bytes)
            );
            let ours = created(mesh_crypto_x25519_shared(
                (*alice).private_key,
                &(*bob).public_key,
            ));
            let theirs = created(mesh_crypto_x25519_shared(
                (*carol).private_key,
                &(*alice).public_key,
            ));
            assert_eq!(
                revealed(ours, ResourceKind::SecretBytes),
                revealed(theirs, ResourceKind::SecretBytes)
            );
            let low_order = MeshX25519PublicKey {
                bytes: bytes(&[0; 32]),
            };
            assert_eq!(
                refused(mesh_crypto_x25519_shared((*alice).private_key, &low_order)),
                (CryptoErrorTag::InvalidPublicKey as u8, 32, 32)
            );

            let (info, aad) = (bytes(b"info"), bytes(b"aad"));
            let sealed = created(mesh_crypto_hpke_seal(
                &(*bob).public_key,
                info,
                aad,
                bytes(b"hello"),
            ));
            let opened = created(mesh_crypto_hpke_open((*bob).private_key, info, aad, sealed));
            assert_eq!(contents(opened), b"hello");
            let sealed_key = created(mesh_crypto_hpke_seal_secret(
                &(*bob).public_key,
                info,
                aad,
                key,
            ));
            let opened_key = created(mesh_crypto_hpke_open_secret(
                (*carol).private_key,
                info,
                aad,
                sealed_key,
            ));
            assert_eq!(revealed(opened_key, ResourceKind::SecretBytes), [0x11; 32]);
            let context = bytes(b"message/bhttp response");
            let exported_seal: *mut MeshTuple2Pointers = created(mesh_crypto_hpke_seal_export(
                &(*bob).public_key,
                info,
                aad,
                bytes(b"request"),
                context,
            ));
            let exported_open: *mut MeshTuple2Pointers = created(mesh_crypto_hpke_open_export(
                (*carol).private_key,
                info,
                aad,
                (*exported_seal).first,
                context,
            ));
            assert_eq!(contents((*exported_open).first), b"request");
            let sender_export = revealed((*exported_seal).second, ResourceKind::SecretBytes);
            assert_eq!(sender_export.len(), 32);
            assert_eq!(
                sender_export,
                revealed((*exported_open).second, ResourceKind::SecretBytes)
            );
            let salt = bytes(&[9; 64]);
            let response = created(mesh_crypto_hkdf_aead_seal(
                (*exported_open).second,
                salt,
                aad,
                bytes(b"response"),
            ));
            let read = created(mesh_crypto_hkdf_aead_open(
                (*exported_seal).second,
                salt,
                aad,
                response,
            ));
            assert_eq!(contents(read), b"response");
            assert_eq!(
                tag_of(mesh_crypto_hkdf_aead_open(key, salt, aad, response)),
                CryptoErrorTag::AuthenticationFailed as u8
            );
            let authentication = CryptoErrorTag::AuthenticationFailed as u8;
            let other_info = bytes(b"other");
            assert_eq!(
                tag_of(mesh_crypto_hpke_open(
                    (*bob).private_key,
                    other_info,
                    aad,
                    sealed
                )),
                authentication
            );
            assert_eq!(
                tag_of(mesh_crypto_hpke_open_secret(
                    (*bob).private_key,
                    other_info,
                    aad,
                    sealed
                )),
                authentication
            );
            assert_eq!(
                refused(mesh_crypto_hpke_open(
                    (*bob).private_key,
                    info,
                    aad,
                    bytes(&[0; 47])
                )),
                (CryptoErrorTag::InvalidLength as u8, 48, 47)
            );
            assert_eq!(
                tag_of(mesh_crypto_hpke_open(
                    (*bob).private_key,
                    info,
                    aad,
                    bytes(&[0; 48])
                )),
                CryptoErrorTag::InvalidPublicKey as u8
            );
            assert_eq!(
                tag_of(mesh_crypto_hpke_seal(&low_order, info, aad, aad)),
                CryptoErrorTag::InvalidPublicKey as u8
            );
            assert_eq!(
                tag_of(mesh_crypto_hpke_seal_secret(
                    &(*bob).public_key,
                    info,
                    aad,
                    ptr::null()
                )),
                CryptoErrorTag::SecretDestroyed as u8
            );

            let receiver: *mut MeshMlKemKeyPair = created(mesh_crypto_mlkem_generate());
            let seeded: *mut MeshMlKemKeyPair =
                created(mesh_crypto_mlkem_from_seed(bytes(&[4; 64])));
            let retyped: *mut MeshMlKemKeyPair =
                created(mesh_crypto_mlkem_from_secret(secret(&[4; 64])));
            assert_eq!(
                contents((*seeded).public_key.bytes),
                contents((*retyped).public_key.bytes)
            );
            let encapsulated: *mut MeshTuple2Pointers =
                created(mesh_crypto_mlkem_encapsulate(&(*receiver).public_key));
            let ciphertext = MeshMlKemCiphertext {
                bytes: (*encapsulated).first,
            };
            let recovered = created(mesh_crypto_mlkem_decapsulate(
                (*receiver).private_key,
                &ciphertext,
            ));
            assert_eq!(
                revealed(recovered, ResourceKind::SecretBytes),
                revealed((*encapsulated).second, ResourceKind::SecretBytes)
            );
            let unreduced = MeshMlKemPublicKey {
                bytes: bytes(&[0xff; MLKEM_PUBLIC_KEY_BYTES]),
            };
            assert_eq!(
                tag_of(mesh_crypto_mlkem_encapsulate(&unreduced)),
                CryptoErrorTag::InvalidPublicKey as u8
            );
            assert_eq!(
                tag_of(mesh_crypto_mlkem_decapsulate(ptr::null(), &ciphertext)),
                CryptoErrorTag::SecretDestroyed as u8
            );

            let signer: *mut MeshSigningKeyPair = created(mesh_crypto_signing_generate());
            let seeded: *mut MeshSigningKeyPair =
                created(mesh_crypto_signing_from_seed(bytes(&[5; 32])));
            let retyped: *mut MeshSigningKeyPair =
                created(mesh_crypto_signing_from_secret(secret(&[5; 32])));
            assert_eq!(
                contents((*seeded).public_key.bytes),
                contents((*retyped).public_key.bytes)
            );
            let message = bytes(b"message");
            let signature: *mut MeshSignature =
                created(mesh_crypto_sign((*signer).private_key, message));
            let verified: *mut bool = created(mesh_crypto_verify(
                &(*signer).public_key,
                message,
                signature,
            ));
            assert!(*verified);
            let not_a_point = (0u8..=255)
                .map(|byte| [byte; 32])
                .find(|candidate| ed25519_dalek::VerifyingKey::from_bytes(candidate).is_err())
                .expect("an encoding off the curve");
            let off_curve = MeshSigningPublicKey {
                bytes: bytes(&not_a_point),
            };
            assert_eq!(
                refused(mesh_crypto_verify(&off_curve, message, signature)),
                (CryptoErrorTag::InvalidPublicKey as u8, 32, 32)
            );

            let aead = created(mesh_crypto_aead_key(secret(&[6; 32])));
            let nonce = bytes(&[0; AEAD_NONCE_BYTES]);
            let sealed = created(mesh_crypto_aead_seal(aead, nonce, aad, message));
            let opened = created(mesh_crypto_aead_open(aead, nonce, aad, sealed));
            assert_eq!(contents(opened), b"message");
            assert_eq!(
                tag_of(mesh_crypto_aead_open(aead, nonce, info, sealed)),
                authentication
            );
        });
    }

    fn blind_rsa_vector(name: &str) -> Vec<u8> {
        let document: serde_json::Value = serde_json::from_str(include_str!(
            "../../../tests/vectors/blind-rsa/rfc9578-type2.json"
        ))
        .expect("RFC 9578 vector file");
        crate::bytes::decode_hex(document["vectors"][0][name].as_str().expect("field"))
            .expect("hex")
    }

    /// The RFC 9578 issuer key as PKCS#8 DER.
    fn blind_rsa_issuer_pkcs8() -> Vec<u8> {
        let pem = String::from_utf8(blind_rsa_vector("skI")).expect("PEM");
        let body: String = pem
            .lines()
            .filter(|line| !line.starts_with("-----"))
            .collect();
        crate::bytes::decode_base64(&body).expect("PEM base64")
    }

    fn owned_count() -> usize {
        let process = crate::actor::current_process().expect("an actor");
        let owner = process.lock().pid;
        crate::secret::owned_secret_count_for_test(owner)
    }

    /// Blind RSA as a Mesh program calls it: the RFC 9578 issuer key imports
    /// from secret bytes, its public key is the vector's SPKI, a token input
    /// blinds, signs, finalizes and verifies, and each state finalizes once.
    #[test]
    #[cfg(any(target_os = "linux", target_os = "macos"))]
    fn blind_rsa_entry_points_round_trip_for_the_calling_actor() {
        mesh_rt_init();
        crate::secret::as_test_actor(|_| unsafe {
            let spki = blind_rsa_vector("pkI");
            let public: *mut MeshBlindRsaPublicKey =
                created(mesh_crypto_blind_rsa_public_from_spki(bytes(&spki)));
            assert_eq!(contents((*public).bytes), spki.as_slice());

            let issuer = created(mesh_crypto_blind_rsa_from_secret(secret(
                &blind_rsa_issuer_pkcs8(),
            )));
            let derived: *mut MeshBlindRsaPublicKey = created(mesh_crypto_blind_rsa_public(issuer));
            assert_eq!(contents((*derived).bytes), spki.as_slice());

            let token_input = bytes(&blind_rsa_vector("token")[..98]);
            let blinded: *mut MeshBlindRsaBlinded =
                created(mesh_crypto_blind_rsa_blind(public, token_input));
            assert_eq!(contents((*blinded).blinded).len(), 256);
            let states = owned_count();
            let blind_signature = created(mesh_crypto_blind_rsa_sign(issuer, (*blinded).blinded));
            let signature: *mut MeshBytes = created(mesh_crypto_blind_rsa_finalize(
                public,
                token_input,
                blind_signature,
                (*blinded).state,
            ));
            assert_eq!(owned_count(), states - 1, "finalize consumed the state");
            let verified: *mut bool =
                created(mesh_crypto_blind_rsa_verify(public, token_input, signature));
            assert!(*verified);
            assert_eq!(
                refused(mesh_crypto_blind_rsa_finalize(
                    public,
                    token_input,
                    blind_signature,
                    (*blinded).state
                ))
                .0,
                CryptoErrorTag::SecretDestroyed as u8
            );

            let generated = created(mesh_crypto_blind_rsa_generate());
            let generated_public: *mut MeshBlindRsaPublicKey =
                created(mesh_crypto_blind_rsa_public(generated));
            let reparsed: *mut MeshBlindRsaPublicKey = created(
                mesh_crypto_blind_rsa_public_from_spki((*generated_public).bytes),
            );
            let blinded: *mut MeshBlindRsaBlinded =
                created(mesh_crypto_blind_rsa_blind(reparsed, token_input));
            let blind_signature =
                created(mesh_crypto_blind_rsa_sign(generated, (*blinded).blinded));
            let signature: *mut MeshBytes = created(mesh_crypto_blind_rsa_finalize(
                generated_public,
                token_input,
                blind_signature,
                (*blinded).state,
            ));
            let verified: *mut bool = created(mesh_crypto_blind_rsa_verify(
                generated_public,
                token_input,
                signature,
            ));
            let other_key: *mut bool =
                created(mesh_crypto_blind_rsa_verify(public, token_input, signature));
            assert!(*verified && !*other_key);
        });
    }

    /// Each blind RSA entry point refuses what the profile excludes with its
    /// documented error, and consumed arguments are gone on failure too.
    #[test]
    #[cfg(any(target_os = "linux", target_os = "macos"))]
    fn blind_rsa_entry_points_refuse_with_typed_errors() {
        mesh_rt_init();
        crate::secret::as_test_actor(|_| unsafe {
            let spki = blind_rsa_vector("pkI");
            let public: *mut MeshBlindRsaPublicKey =
                created(mesh_crypto_blind_rsa_public_from_spki(bytes(&spki)));
            let message = bytes(b"token input");
            let public_key = CryptoErrorTag::InvalidPublicKey as u8;
            assert_eq!(
                refused(mesh_crypto_blind_rsa_public_from_spki(bytes(&spki[1..]))),
                (public_key, 342, 341)
            );
            assert_eq!(
                refused(mesh_crypto_blind_rsa_public_from_spki(ptr::null())),
                (public_key, 342, -1)
            );
            let forged = MeshBlindRsaPublicKey {
                bytes: bytes(&[0; 342]),
            };
            assert_eq!(
                tag_of(mesh_crypto_blind_rsa_blind(&forged, message)),
                public_key
            );
            assert_eq!(
                tag_of(mesh_crypto_blind_rsa_verify(
                    &forged,
                    message,
                    bytes(&[0; 256])
                )),
                public_key
            );
            let oversized = vec![0u8; MAX_INPUT_BYTES + 1];
            assert_eq!(
                refused(mesh_crypto_blind_rsa_blind(public, bytes(&oversized))),
                (
                    CryptoErrorTag::InvalidLength as u8,
                    MAX_INPUT_BYTES as i64,
                    MAX_INPUT_BYTES as i64 + 1
                )
            );
            let signature = CryptoErrorTag::InvalidSignature as u8;
            assert_eq!(
                refused(mesh_crypto_blind_rsa_verify(
                    public,
                    message,
                    bytes(&[0; 255])
                )),
                (signature, 256, 255)
            );
            let rejected: *mut bool = created(mesh_crypto_blind_rsa_verify(
                public,
                message,
                bytes(&[1; 256]),
            ));
            assert!(!*rejected);

            // A failed finalize still consumes its state.
            let blinded: *mut MeshBlindRsaBlinded =
                created(mesh_crypto_blind_rsa_blind(public, message));
            let before = owned_count();
            assert_eq!(
                refused(mesh_crypto_blind_rsa_finalize(
                    &forged,
                    message,
                    bytes(&[1; 256]),
                    (*blinded).state
                ))
                .0,
                public_key
            );
            assert_eq!(owned_count(), before - 1);
            let blinded: *mut MeshBlindRsaBlinded =
                created(mesh_crypto_blind_rsa_blind(public, message));
            assert_eq!(
                refused(mesh_crypto_blind_rsa_finalize(
                    public,
                    message,
                    bytes(&[1; 255]),
                    (*blinded).state
                )),
                (signature, 256, 255)
            );
            assert_eq!(owned_count(), before - 1);

            // Signing: a blinded message of the wrong length or not below n.
            let issuer = created(mesh_crypto_blind_rsa_from_secret(secret(
                &blind_rsa_issuer_pkcs8(),
            )));
            let length = CryptoErrorTag::InvalidLength as u8;
            let modulus = spki[81..81 + 256].to_vec();
            assert_eq!(
                refused(mesh_crypto_blind_rsa_sign(issuer, bytes(&[1; 255]))),
                (length, 256, 255)
            );
            assert_eq!(
                refused(mesh_crypto_blind_rsa_sign(issuer, bytes(&[1; 257]))),
                (length, 256, 257)
            );
            assert_eq!(
                refused(mesh_crypto_blind_rsa_sign(issuer, bytes(&modulus))),
                (length, 256, 256)
            );

            // Import consumes its secret bytes even when it refuses them.
            let before = owned_count();
            let wrong = secret(&blind_rsa_issuer_pkcs8()[..1000]);
            assert_eq!(
                tag_of(mesh_crypto_blind_rsa_from_secret(wrong)),
                CryptoErrorTag::InvalidKey as u8
            );
            assert_eq!(owned_count(), before);
            let destroyed = CryptoErrorTag::SecretDestroyed as u8;
            assert_eq!(tag_of(mesh_crypto_blind_rsa_from_secret(wrong)), destroyed);
            // A destroyed key: stale for every operation.
            let doomed = created(mesh_crypto_blind_rsa_from_secret(secret(
                &blind_rsa_issuer_pkcs8(),
            )));
            crate::secret::mesh_resource_destroy(doomed);
            assert_eq!(tag_of(mesh_crypto_blind_rsa_public(doomed)), destroyed);
            assert_eq!(
                tag_of(mesh_crypto_blind_rsa_sign(doomed, bytes(&[0; 256]))),
                destroyed
            );
            // A key handle is not a blinding state, nor the reverse.
            let blinded: *mut MeshBlindRsaBlinded =
                created(mesh_crypto_blind_rsa_blind(public, message));
            let wrong_kind = CryptoErrorTag::InvalidKey as u8;
            assert_eq!(
                tag_of(mesh_crypto_blind_rsa_sign(
                    (*blinded).state,
                    bytes(&[0; 256])
                )),
                wrong_kind
            );
            assert_eq!(
                tag_of(mesh_crypto_blind_rsa_finalize(
                    public,
                    message,
                    bytes(&[0; 256]),
                    issuer
                )),
                wrong_kind
            );
        });
    }

    /// A key or blinding state belongs to the actor that made it: another
    /// actor cannot sign with it or finalize with it, and it stays usable
    /// for its owner.
    #[test]
    #[cfg(any(target_os = "linux", target_os = "macos"))]
    fn blind_rsa_resources_refuse_a_different_actor() {
        mesh_rt_init();
        let owner = ProcessId(70_030);
        let other = Process::new(ProcessId(70_031), Priority::Normal);
        let mut process = Process::new(owner, Priority::Normal);
        let key = blind_rsa::signer::import(&blind_rsa_issuer_pkcs8()).expect("import");
        let key = insert_owned_resource(&mut process, ResourceKind::BlindRsaSecretKey, key)
            .expect("insert key");
        let state = insert_owned_resource(
            &mut process,
            ResourceKind::BlindRsaBlindingState,
            Zeroizing::new(vec![1; 256].into_boxed_slice()),
        )
        .expect("insert state");
        for (handle, kind) in [
            (key, ResourceKind::BlindRsaSecretKey),
            (state, ResourceKind::BlindRsaBlindingState),
        ] {
            assert_eq!(
                with_owned_resource(&other, handle, kind, |_| ()),
                Err(ResourceError::StaleHandle)
            );
            assert_eq!(
                consume_owned_resource(&other, handle, kind),
                Err(ResourceError::StaleHandle)
            );
            assert!(with_owned_resource(&process, handle, kind, |_| ()).is_ok());
        }
        assert_eq!(destroy_owned(owner), 2);
    }

    /// Secret leaks: a PKCS#8 import that fails, a refused signature and a
    /// finalize that fails leave no sentinel byte in their errors, the
    /// runtime's error record or AWS-LC's error queue, and the consumed
    /// material is gone from the table.
    #[test]
    #[cfg(any(target_os = "linux", target_os = "macos"))]
    // `expect_err` would print an accepted key.
    #[allow(clippy::err_expect)]
    fn blind_rsa_failures_do_not_leak_sentinel_material() {
        mesh_rt_init();
        let sentinel = b"mesh-secret-leak-sentinel";
        let leaked = |text: &str| {
            text.contains("mesh-secret-leak-sentinel")
                || text.contains(&format!("{:?}", &sentinel[..]))
                || text.contains(
                    &sentinel
                        .iter()
                        .map(|byte| format!("{byte:02x}"))
                        .collect::<String>(),
                )
        };
        crate::secret::as_test_actor(|_| unsafe {
            // A PKCS#8 shell whose private key is the sentinel.
            let mut pkcs8 = blind_rsa_issuer_pkcs8();
            for (index, byte) in pkcs8[300..].iter_mut().enumerate() {
                *byte = sentinel[index % sentinel.len()];
            }
            let before = owned_count();
            let result = mesh_crypto_blind_rsa_from_secret(secret(&pkcs8));
            let record = std::slice::from_raw_parts((*result).value.cast::<u8>(), 24);
            assert_eq!(refused(result).0, CryptoErrorTag::InvalidKey as u8);
            assert!(!record
                .windows(4)
                .any(|window| sentinel.windows(4).any(|s| s == window)));
            assert_eq!(owned_count(), before, "the secret was consumed");
            let direct = blind_rsa::signer::import(&pkcs8).err().expect("refused");
            assert!(!leaked(&format!("{direct:?}")));
            assert_eq!(aws_lc_sys::ERR_peek_error(), 0);

            let issuer = created(mesh_crypto_blind_rsa_from_secret(secret(
                &blind_rsa_issuer_pkcs8(),
            )));
            let spki = blind_rsa_vector("pkI");
            let refused_sign = blind_rsa::signer::sign(&blind_rsa_issuer_pkcs8(), &spki[81..337])
                .err()
                .expect("n is out of range");
            assert!(!leaked(&format!("{refused_sign:?}")));
            assert_eq!(
                tag_of(mesh_crypto_blind_rsa_sign(issuer, bytes(&spki[81..337]))),
                CryptoErrorTag::InvalidLength as u8
            );

            let public: *mut MeshBlindRsaPublicKey =
                created(mesh_crypto_blind_rsa_public_from_spki(bytes(&spki)));
            let blinded: *mut MeshBlindRsaBlinded =
                created(mesh_crypto_blind_rsa_blind(public, bytes(b"input")));
            let before = owned_count();
            let failure = blind_rsa::finalize(
                &blind_rsa::public_key_from_spki(&spki).expect("key"),
                b"input",
                &[1; 256],
                &[0xa5; 256],
            )
            .err()
            .expect("does not verify");
            assert!(!leaked(&format!("{failure:?}")));
            assert_eq!(
                tag_of(mesh_crypto_blind_rsa_finalize(
                    public,
                    bytes(b"input"),
                    bytes(&[1; 256]),
                    (*blinded).state
                )),
                CryptoErrorTag::InvalidSignature as u8
            );
            assert_eq!(owned_count(), before - 1, "the state was destroyed");
        });
    }

    /// The client half of blind RSA runs on every target; the server half
    /// (key generation and import, the public key of a private key, signing,
    /// sealing an issuer key) is `UnsupportedTarget` wherever AWS-LC is not
    /// compiled, and import still consumes its secret bytes there.
    #[test]
    fn blind_rsa_entry_points_follow_the_target() {
        mesh_rt_init();
        let server = cfg!(any(target_os = "linux", target_os = "macos"));
        let unsupported = CryptoErrorTag::UnsupportedTarget as u8;
        crate::secret::as_test_actor(|_| unsafe {
            let spki = blind_rsa_vector("pkI");
            let token = blind_rsa_vector("token");
            let public: *mut MeshBlindRsaPublicKey =
                created(mesh_crypto_blind_rsa_public_from_spki(bytes(&spki)));
            let (input, authenticator) = (bytes(&token[..98]), bytes(&token[98..]));
            let verified: *mut bool =
                created(mesh_crypto_blind_rsa_verify(public, input, authenticator));
            assert!(*verified);
            let blinded: *mut MeshBlindRsaBlinded =
                created(mesh_crypto_blind_rsa_blind(public, input));
            let before = owned_count();
            assert_eq!(
                tag_of(mesh_crypto_blind_rsa_finalize(
                    public,
                    input,
                    bytes(&[1; 256]),
                    (*blinded).state
                )),
                CryptoErrorTag::InvalidSignature as u8
            );
            assert_eq!(owned_count(), before - 1);

            let generated = mesh_crypto_blind_rsa_generate();
            let before = owned_count();
            let imported = mesh_crypto_blind_rsa_from_secret(secret(&blind_rsa_issuer_pkcs8()));
            if server {
                let key = created(imported);
                created::<MeshSecretHandle>(generated);
                assert_eq!(owned_count(), before + 1);
                created::<MeshBlindRsaPublicKey>(mesh_crypto_blind_rsa_public(key));
            } else {
                assert_eq!(tag_of(generated), unsupported);
                assert_eq!(tag_of(imported), unsupported);
                assert_eq!(owned_count(), before, "import consumed its secret bytes");
                let stale = secret(&[0; 1]);
                crate::secret::mesh_resource_destroy(stale);
                assert_eq!(tag_of(mesh_crypto_blind_rsa_public(stale)), unsupported);
                assert_eq!(
                    tag_of(mesh_crypto_blind_rsa_sign(stale, bytes(&[0; 256]))),
                    unsupported
                );
                let wrapping_key = created(crate::storage_wrapping::mesh_storage_key_ephemeral());
                assert_eq!(
                    tag_of(
                        crate::storage_wrapping::mesh_blind_rsa_secret_key_seal_for_storage(
                            stale,
                            wrapping_key,
                            bytes(&[0; 123])
                        )
                    ),
                    unsupported
                );
                assert_eq!(
                    tag_of(
                        crate::storage_wrapping::mesh_blind_rsa_secret_key_unseal_from_storage(
                            bytes(&[0; 67]),
                            wrapping_key,
                            bytes(&[0; 123])
                        )
                    ),
                    unsupported
                );
            }
        });
    }

    /// The legacy String helpers: RFC 4231's HMAC-SHA-512 vector, a v4 UUID,
    /// and each codec's round trip and refusals.
    #[test]
    fn legacy_string_helpers_encode_and_refuse() {
        mesh_rt_init();
        let text = |value: *mut MeshString| unsafe { (*value).as_str().to_string() };
        let decoded = |result: *mut MeshResult| unsafe {
            let result = &*result;
            ((result.tag), text(result.value.cast()))
        };
        assert_eq!(
            text(mesh_crypto_hmac_sha512(
                mesh_str("Jefe"),
                mesh_str("what do ya want for nothing?")
            )),
            "164b7a7bfcf819e2e395fbe73b56e0a387bd64222e831fd610270cd7ea250554\
             9758bf75c05a994a6d034f65f8f0e6fdcaeab1a34d4a6b4b636e070a38bce737"
        );
        let uuid = text(mesh_crypto_uuid4());
        assert_eq!((uuid.len(), &uuid[14..15]), (36, "4"));
        assert!(matches!(&uuid[19..20], "8" | "9" | "a" | "b"));

        let hello = mesh_str("hello");
        assert_eq!(
            decoded(mesh_base64_decode(mesh_base64_encode(hello))),
            (0, "hello".to_string())
        );
        assert_eq!(
            decoded(mesh_base64_decode(mesh_str("aGVsbG8"))),
            (0, "hello".to_string())
        );
        assert_eq!(
            decoded(mesh_base64_decode_url(mesh_base64_encode_url(hello))),
            (0, "hello".to_string())
        );
        assert_eq!(
            decoded(mesh_hex_decode(mesh_hex_encode(hello))),
            (0, "hello".to_string())
        );
        for refused in [
            mesh_base64_decode(mesh_str("!")),
            mesh_base64_decode_url(mesh_str("!")),
        ] {
            assert_eq!(decoded(refused), (1, "invalid base64".to_string()));
        }
        for not_text in [
            mesh_base64_decode(mesh_str("/w==")),
            mesh_base64_decode_url(mesh_str("_w")),
            mesh_hex_decode(mesh_str("ff")),
        ] {
            assert_eq!(decoded(not_text), (1, "invalid utf-8".to_string()));
        }
    }
}
