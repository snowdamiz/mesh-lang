//! GC-managed string operations for the Mesh runtime.
//!
//! Strings in Mesh are length-prefixed, UTF-8, GC-managed values. The layout
//! is `{ len: u64, data: [u8; len] }` -- the data bytes immediately follow
//! the length field in memory.
//!
//! Runtime-created text is a leaf in the per-actor heap. The raw native
//! constructor uses conservative allocation. Both use the global arena
//! outside actor context.

use std::io::Write;
use std::ptr;

use crate::collections::list::{mesh_list_builder_new, mesh_list_builder_push};
use crate::gc::{alloc_actor_leaf, mesh_gc_alloc_actor};
use crate::option::alloc_option;

/// A GC-managed Mesh string.
///
/// Layout: `[u64 len][u8 data...]` -- the `data` bytes immediately follow
/// the `len` field in memory. This struct only declares the `len` field;
/// the data is accessed by pointer arithmetic past the struct.
#[repr(C)]
pub struct MeshString {
    pub len: u64,
    // data bytes follow immediately after this struct in memory
}

impl MeshString {
    /// Size of the header (the `len` field).
    const HEADER_SIZE: usize = std::mem::size_of::<u64>();

    /// Get a pointer to the data bytes following the header.
    ///
    /// # Safety
    ///
    /// Caller must ensure `self` points to a valid MeshString allocation
    /// with at least `self.len` bytes following the header.
    pub unsafe fn data_ptr(&self) -> *const u8 {
        (self as *const Self as *const u8).add(Self::HEADER_SIZE)
    }

    /// Get a mutable pointer to the data bytes following the header.
    ///
    /// # Safety
    ///
    /// Caller must ensure `self` points to a valid, mutable MeshString
    /// allocation with at least `self.len` bytes following the header.
    pub unsafe fn data_ptr_mut(&mut self) -> *mut u8 {
        (self as *mut Self as *mut u8).add(Self::HEADER_SIZE)
    }

    /// View the string data as a byte slice.
    ///
    /// # Safety
    ///
    /// Caller must ensure the MeshString was properly initialized with
    /// valid UTF-8 data of length `self.len`.
    pub unsafe fn as_bytes(&self) -> &[u8] {
        std::slice::from_raw_parts(self.data_ptr(), self.len as usize)
    }

    /// View the string data as a `&str`.
    ///
    /// # Safety
    ///
    /// Caller must ensure the MeshString contains valid UTF-8.
    pub unsafe fn as_str(&self) -> &str {
        std::str::from_utf8_unchecked(self.as_bytes())
    }
}

/// Create a new GC-managed Mesh string from raw bytes.
///
/// Allocates `sizeof(u64) + len` bytes from the GC arena, copies `data`
/// into the allocation, and returns a pointer to the new `MeshString`.
///
/// # Safety
///
/// `data` must point to at least `len` valid bytes. If `data` is null,
/// the string data is zeroed.
#[no_mangle]
pub extern "C" fn mesh_string_new(data: *const u8, len: u64) -> *mut MeshString {
    unsafe { copy_string(data, len, false) }
}

unsafe fn allocate(len: u64, leaf: bool) -> *mut MeshString {
    let total = MeshString::HEADER_SIZE as u64 + len;
    let allocation = if leaf {
        alloc_actor_leaf(total, 8)
    } else {
        mesh_gc_alloc_actor(total, 8)
    };
    let string = allocation.cast::<MeshString>();
    (*string).len = len;
    string
}

unsafe fn copy_string(data: *const u8, len: u64, leaf: bool) -> *mut MeshString {
    let string = allocate(len, leaf);
    if !data.is_null() && len > 0 {
        ptr::copy_nonoverlapping(data, (*string).data_ptr_mut(), len as usize);
    }
    string
}

/// The text of the Mesh string at `pointer`.
pub(crate) unsafe fn text_of<'a, T>(pointer: *const T) -> &'a str {
    (*pointer.cast::<MeshString>()).as_str()
}

/// A new Mesh string holding `text`.
pub(crate) fn mesh_str(text: &str) -> *mut MeshString {
    unsafe { copy_string(text.as_ptr(), text.len() as u64, true) }
}

/// Concatenate two Mesh strings, returning a new GC-managed string.
#[no_mangle]
pub extern "C" fn mesh_string_concat(
    a: *const MeshString,
    b: *const MeshString,
) -> *mut MeshString {
    unsafe {
        let a_len = (*a).len;
        let b_len = (*b).len;
        let new_len = a_len + b_len;
        let result = allocate(new_len, true);
        let dst = (*result).data_ptr_mut();
        ptr::copy_nonoverlapping((*a).data_ptr(), dst, a_len as usize);
        ptr::copy_nonoverlapping((*b).data_ptr(), dst.add(a_len as usize), b_len as usize);
        result
    }
}

/// Convert an i64 integer to a GC-managed Mesh string.
#[no_mangle]
pub extern "C" fn mesh_int_to_string(val: i64) -> *mut MeshString {
    // Format on the stack: every `"${n}"` lands here, and `to_string` would
    // allocate and free a heap `String` just to be copied. i64::MIN is 20 bytes.
    let mut buf = [0u8; 20];
    let mut remaining = &mut buf[..];
    write!(remaining, "{val}").expect("an i64 fits in 20 bytes");
    let len = 20 - remaining.len();
    unsafe { copy_string(buf.as_ptr(), len as u64, true) }
}

/// Convert an f64 float to a GC-managed Mesh string. A whole number keeps
/// its `.0` (`42.0`, never `42`; `1.0e20`, never `1e20`) so a Float always
/// reads as one.
#[no_mangle]
pub extern "C" fn mesh_float_to_string(val: f64) -> *mut MeshString {
    let mut s = format!("{val:?}");
    if let Some(e) = s.find('e') {
        if !s[..e].contains('.') {
            s.insert_str(e, ".0");
        }
    }
    mesh_str(&s)
}

/// Convert a boolean (i8: 0 = false, non-zero = true) to a GC-managed Mesh string.
#[no_mangle]
pub extern "C" fn mesh_bool_to_string(val: i8) -> *mut MeshString {
    let s = if val != 0 { "true" } else { "false" };
    mesh_str(s)
}

/// Identity function for string-to-string conversion.
///
/// Used as a callback for collection Display when elements are strings.
/// Takes a u64 (which is a MeshString pointer cast to u64) and returns
/// it as a `*mut MeshString`. This allows collection to_string helpers
/// to use a uniform callback signature `fn(u64) -> *mut u8`.
#[no_mangle]
pub extern "C" fn mesh_string_to_string(val: u64) -> *mut MeshString {
    val as *mut MeshString
}

/// `s` as `inspect()` shows it: in quotes, with the characters a string
/// literal escapes (`"`, `\`, newline, tab, carriage return, NUL) escaped.
#[no_mangle]
pub extern "C" fn mesh_string_inspect(s: *const MeshString) -> *mut MeshString {
    let text = unsafe { (*s).as_str() };
    let mut out = String::with_capacity(text.len() + 2);
    out.push('"');
    for c in text.chars() {
        match c {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\t' => out.push_str("\\t"),
            '\r' => out.push_str("\\r"),
            '\0' => out.push_str("\\0"),
            c => out.push(c),
        }
    }
    out.push('"');
    mesh_str(&out)
}

/// Print a Mesh string to stdout (no trailing newline).
#[no_mangle]
pub extern "C" fn mesh_print(s: *const MeshString) {
    unsafe { write_stdout((*s).as_str(), "") }
}

/// Print a Mesh string to stdout with a trailing newline.
#[no_mangle]
pub extern "C" fn mesh_println(s: *const MeshString) {
    unsafe { write_stdout((*s).as_str(), "\n") }
}

/// Write to stdout and flush. The runtime ignores SIGPIPE (a server must
/// outlive a client that hung up), so a closed stdout shows up here as an
/// error: the program then ends as SIGPIPE would have ended it (`prog | head`
/// stays quiet). `print!` would panic, and these functions cannot unwind.
fn write_stdout(text: &str, end: &str) {
    write_to(&mut std::io::stdout().lock(), text, end)
}

/// `write_stdout` to `out`. An error other than a closed pipe (a full disk,
/// a non-blocking pipe with no room) loses the text, as C's `printf` does.
fn write_to(out: &mut impl Write, text: &str, end: &str) {
    let written = out
        .write_all(text.as_bytes())
        .and_then(|()| out.write_all(end.as_bytes()))
        .and_then(|()| out.flush());
    if let Err(error) = written {
        if error.kind() == std::io::ErrorKind::BrokenPipe {
            crate::panic::die_of_sigpipe();
        }
    }
}

// ── String operations (Phase 8) ──────────────────────────────────────────

/// Return the number of Unicode codepoints in the string (NOT byte length).
#[no_mangle]
pub extern "C" fn mesh_string_length(s: *const MeshString) -> i64 {
    unsafe { (*s).as_str().chars().count() as i64 }
}

/// Codepoint-based slice (0-indexed, exclusive end). Clamps to bounds.
#[no_mangle]
pub extern "C" fn mesh_string_slice(s: *const MeshString, start: i64, end: i64) -> *mut MeshString {
    unsafe {
        let text = (*s).as_str();
        let char_count = text.chars().count();
        let start = (start.max(0) as usize).min(char_count);
        let end = (end.max(0) as usize).min(char_count).max(start);
        let sliced: String = text.chars().skip(start).take(end - start).collect();
        mesh_str(&sliced)
    }
}

/// Returns 1 if haystack contains needle, 0 otherwise.
#[no_mangle]
pub extern "C" fn mesh_string_contains(
    haystack: *const MeshString,
    needle: *const MeshString,
) -> i8 {
    unsafe {
        if (*haystack).as_str().contains((*needle).as_str()) {
            1
        } else {
            0
        }
    }
}

/// Returns 1 if string starts with prefix, 0 otherwise.
#[no_mangle]
pub extern "C" fn mesh_string_starts_with(s: *const MeshString, prefix: *const MeshString) -> i8 {
    unsafe {
        if (*s).as_str().starts_with((*prefix).as_str()) {
            1
        } else {
            0
        }
    }
}

/// Returns 1 if string ends with suffix, 0 otherwise.
#[no_mangle]
pub extern "C" fn mesh_string_ends_with(s: *const MeshString, suffix: *const MeshString) -> i8 {
    unsafe {
        if (*s).as_str().ends_with((*suffix).as_str()) {
            1
        } else {
            0
        }
    }
}

/// Trim whitespace from both sides.
#[no_mangle]
pub extern "C" fn mesh_string_trim(s: *const MeshString) -> *mut MeshString {
    unsafe {
        let trimmed = (*s).as_str().trim();
        mesh_str(trimmed)
    }
}

/// Remove leading whitespace.
#[no_mangle]
pub extern "C" fn mesh_string_trim_start(s: *const MeshString) -> *mut MeshString {
    mesh_str(unsafe { (*s).as_str() }.trim_start())
}

/// Remove trailing whitespace.
#[no_mangle]
pub extern "C" fn mesh_string_trim_end(s: *const MeshString) -> *mut MeshString {
    mesh_str(unsafe { (*s).as_str() }.trim_end())
}

/// `text` `count` times over; "" for a count of zero or less.
#[no_mangle]
pub extern "C-unwind" fn mesh_string_repeat(
    text: *const MeshString,
    count: i64,
) -> *mut MeshString {
    let text = unsafe { (*text).as_str() };
    let count = usize::try_from(count).unwrap_or(0);
    if text
        .len()
        .checked_mul(count)
        .is_none_or(|length| length > isize::MAX as usize)
    {
        crate::panic::raise(format_args!(
            "String.repeat: {count} copies of {} bytes do not fit in a string",
            text.len()
        ));
    }
    mesh_str(&text.repeat(count))
}

/// Convert to uppercase.
#[no_mangle]
pub extern "C" fn mesh_string_to_upper(s: *const MeshString) -> *mut MeshString {
    unsafe {
        let upper = (*s).as_str().to_uppercase();
        mesh_str(&upper)
    }
}

/// Convert to lowercase.
#[no_mangle]
pub extern "C" fn mesh_string_to_lower(s: *const MeshString) -> *mut MeshString {
    unsafe {
        let lower = (*s).as_str().to_lowercase();
        mesh_str(&lower)
    }
}

/// Replace all occurrences of `from` with `to` in the string.
#[no_mangle]
pub extern "C" fn mesh_string_replace(
    s: *const MeshString,
    from: *const MeshString,
    to: *const MeshString,
) -> *mut MeshString {
    unsafe {
        let result = (*s).as_str().replace((*from).as_str(), (*to).as_str());
        mesh_str(&result)
    }
}

/// Compare two Mesh strings for equality. Returns 1 if equal, 0 otherwise.
#[no_mangle]
pub extern "C" fn mesh_string_eq(a: *const MeshString, b: *const MeshString) -> i8 {
    unsafe {
        if (*a).as_str() == (*b).as_str() {
            1
        } else {
            0
        }
    }
}

/// Order two Mesh strings: -1, 0 or 1. Byte order, which for UTF-8 is code
/// point order.
#[no_mangle]
pub extern "C" fn mesh_string_compare(a: *const MeshString, b: *const MeshString) -> i64 {
    unsafe { (*a).as_str().cmp((*b).as_str()) as i64 }
}

// ── String split/join/parse operations (Phase 46 Plan 02) ────────────

/// Split a string by a delimiter, returning a List<String>.
///
/// Uses the list builder API to construct the result list efficiently.
#[no_mangle]
pub extern "C" fn mesh_string_split(s: *const MeshString, delim: *const MeshString) -> *mut u8 {
    unsafe {
        let text = (*s).as_str();
        let delimiter = (*delim).as_str();
        let parts: Vec<&str> = text.split(delimiter).collect();
        let mut list = mesh_list_builder_new(parts.len() as i64);
        for part in &parts {
            let mesh_str = mesh_str(part);
            list = mesh_list_builder_push(list, mesh_str as u64);
        }
        list
    }
}

/// Join a list of strings with a separator, returning a new String.
///
/// Reads list elements as MeshString pointers (stored as u64 in the list).
#[no_mangle]
pub extern "C" fn mesh_string_join(list: *mut u8, sep: *const MeshString) -> *mut u8 {
    unsafe {
        let (count, slots) = crate::collections::list::list_slots(list);
        let slots = std::slice::from_raw_parts(slots, count);
        let Some((&first, rest)) = slots.split_first() else {
            return allocate(0, true).cast();
        };
        let first = first as *const MeshString;
        let rest = rest.iter().map(|&slot| slot as *const MeshString);
        let separator_len = (*sep).len;
        let len = join_byte_len(
            (*first).len,
            separator_len,
            rest.clone().map(|part| (*part).len),
        )
        .expect("String.join: result too large");

        // Actor heaps store the allocation size in a u32. The global arena
        // can hold larger allocations on 64-bit targets.
        if len + MeshString::HEADER_SIZE as u64 > u32::MAX as u64 {
            assert!(
                crate::actor::stack::with_allocation_process(|_| ()).is_none(),
                "String.join: result too large for the actor heap"
            );
        }

        // Allocation can request GC but collection waits for a safepoint in
        // compiled code. The immutable slots and input bodies stay live here.
        let result = allocate(len, true);
        let mut dst = result.cast::<u8>().add(MeshString::HEADER_SIZE);
        let mut copy = |part: *const MeshString, len: usize| {
            ptr::copy_nonoverlapping(part.cast::<u8>().add(MeshString::HEADER_SIZE), dst, len);
            dst = dst.add(len);
        };
        copy(first, (*first).len as usize);
        for part in rest {
            copy(sep, separator_len as usize);
            copy(part, (*part).len as usize);
        }
        result.cast()
    }
}

fn join_byte_len(
    first: u64,
    separator: u64,
    mut rest: impl ExactSizeIterator<Item = u64>,
) -> Option<u64> {
    // The largest rounded actor page must fit in a Rust allocation, including
    // both headers. This also leaves room for the arena's alignment padding.
    const MAX_PAYLOAD: u64 = ((isize::MAX as usize & !7)
        - crate::actor::heap::GC_HEADER_SIZE
        - MeshString::HEADER_SIZE) as u64;
    let separators = separator.checked_mul(rest.len() as u64)?;
    let len = rest.try_fold(first.checked_add(separators)?, u64::checked_add)?;
    (len <= MAX_PAYLOAD).then_some(len)
}

/// Parse a string to an integer, returning Option<Int>.
///
/// Returns Some(n) on success (tag 0), None on failure (tag 1).
#[no_mangle]
pub extern "C" fn mesh_string_to_int(s: *const MeshString) -> *mut u8 {
    unsafe {
        let text = (*s).as_str().trim();
        match text.parse::<i64>() {
            Ok(val) => alloc_option(0, crate::io::box_scalar(val)) as *mut u8,
            Err(_) => alloc_option(1, std::ptr::null_mut()) as *mut u8,
        }
    }
}

/// Parse a string to a float, returning Option<Float>.
///
/// Returns Some(f) on success (tag 0), None on failure (tag 1).
/// CRITICAL: Uses f64::to_bits() to store the float as its bit pattern
/// in the u64 value field of MeshOption.
#[no_mangle]
pub extern "C" fn mesh_string_to_float(s: *const MeshString) -> *mut u8 {
    unsafe {
        let text = (*s).as_str().trim();
        match text.parse::<f64>() {
            Ok(val) => alloc_option(0, crate::io::box_scalar(f64::to_bits(val))) as *mut u8,
            Err(_) => alloc_option(1, std::ptr::null_mut()) as *mut u8,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::collections::list::{
        mesh_list_append, mesh_list_drop, mesh_list_from_array, string_list,
    };
    use crate::gc::mesh_rt_init;

    #[test]
    fn join_allocates_fresh_strings_and_reads_only_visible_slots() {
        let sep = mesh_str("\0🙂");
        let mut prefix = mesh_list_builder_new(8);
        for text in ["ignored", "é", ""] {
            prefix = mesh_list_builder_push(prefix, mesh_str(text) as u64);
        }
        let view = mesh_list_drop(prefix, 1);
        let extended = mesh_list_append(view, mesh_str("水") as u64);
        for (list, separator, expected) in [
            (prefix, sep, "ignored\0🙂é\0🙂"),
            (view, sep, "é\0🙂"),
            (extended, sep, "é\0🙂\0🙂水"),
            (extended, mesh_str(""), "é水"),
            (mesh_list_drop(extended, 2), sep, "水"),
        ] {
            let result = mesh_string_join(list, separator).cast::<MeshString>();
            assert_eq!(unsafe { (*result).as_str() }, expected);
        }

        let empty = string_list::<&str>(&[]);
        let a = mesh_string_join(empty, sep).cast::<MeshString>();
        let b = mesh_string_join(empty, sep).cast::<MeshString>();
        assert_ne!(a, b);
        assert_eq!(unsafe { (*a).as_str() }, "");
        assert_eq!(unsafe { (*b).as_str() }, "");

        let singleton = mesh_list_from_array([sep as u64].as_ptr(), 1);
        let a = mesh_string_join(singleton, sep).cast::<MeshString>();
        assert_ne!(a, sep);
        assert_eq!(unsafe { (*a).as_str() }, "\0🙂");
    }

    #[test]
    fn join_copies_raw_bytes_to_an_actor_leaf() {
        use crate::actor::process::{Priority, Process, ProcessId};
        use crate::actor::stack;
        use std::sync::Arc;

        let pid = ProcessId(1);
        let process = Arc::new(parking_lot::Mutex::new(Process::new(pid, Priority::Normal)));
        process.lock().collects_at_safepoints = true;
        stack::set_current_process(pid, &process);
        let child = mesh_gc_alloc_actor(8, 8);
        let word = (child as u64).to_ne_bytes();
        let first = mesh_string_new(word.as_ptr(), 8);
        let last = mesh_string_new([0u8, 0xff].as_ptr(), 2);
        let sep = mesh_string_new([0xfeu8, 0].as_ptr(), 2);
        let list = mesh_list_from_array([first as u64, last as u64].as_ptr(), 2);
        let _ = mesh_gc_alloc_actor(512 * 1024, 8);
        assert!(process.lock().heap.should_collect());
        let result = mesh_string_join(list, sep);
        stack::clear_current_pid();

        // A root into the text retains the result. The address encoded in
        // the text does not retain the object it happens to name.
        let body = unsafe { result.add(MeshString::HEADER_SIZE) };
        let roots = [body as u64];
        let top = roots.as_ptr().cast();
        let bottom = unsafe { roots.as_ptr().add(roots.len()) }.cast();
        let mut process = process.lock();
        process.heap.collect(bottom, top);
        assert_eq!(process.heap.live_allocation_size(child), None);
        assert_eq!(process.heap.live_allocation_size(result), Some(20));
        let bytes = unsafe { std::slice::from_raw_parts(body, 12) };
        assert_eq!(&bytes[..8], &word);
        assert_eq!(&bytes[8..], &[0xfe, 0, 0, 0xff]);
    }

    #[test]
    fn join_sizes_are_checked_before_allocation() {
        assert_eq!(join_byte_len(1, 2, [3, 5].into_iter()), Some(13));
        assert_eq!(join_byte_len(1, u64::MAX, [].into_iter()), Some(1));
        assert_eq!(join_byte_len(1, u64::MAX, [0, 0].into_iter()), None);
        assert_eq!(join_byte_len(u64::MAX, 0, [1].into_iter()), None);
        assert_eq!(join_byte_len(isize::MAX as u64, 0, [].into_iter()), None);
    }

    /// Output goes out text first, then its ending; a write error other
    /// than a closed pipe returns rather than ending the program.
    #[test]
    fn output_is_written_and_other_write_errors_return() {
        struct Full;
        impl Write for Full {
            fn write(&mut self, _: &[u8]) -> std::io::Result<usize> {
                Err(std::io::ErrorKind::StorageFull.into())
            }
            fn flush(&mut self) -> std::io::Result<()> {
                Ok(())
            }
        }
        let mut out = Vec::new();
        write_to(&mut out, "line", "\n");
        assert_eq!(out, b"line\n");
        write_to(&mut Full, "line", "\n");
    }

    #[test]
    fn inspect_escapes_carriage_returns_and_nul() {
        mesh_rt_init();
        let shown = mesh_string_inspect(mesh_str("a\r\0b"));
        assert_eq!(unsafe { (*shown).as_str() }, "\"a\\r\\0b\"");
    }

    /// `String.repeat`: the text so many times over, nothing for a count
    /// of zero or less, and a Mesh panic for a length no string can have.
    #[test]
    fn repeat_repeats_and_refuses_what_cannot_fit() {
        crate::gc::mesh_rt_init();
        let text = |value: *mut MeshString| unsafe { (*value).as_str().to_string() };
        assert_eq!(text(mesh_string_repeat(mesh_str("ab"), 3)), "ababab");
        assert_eq!(text(mesh_string_repeat(mesh_str("ab"), 0)), "");
        assert_eq!(text(mesh_string_repeat(mesh_str("ab"), -4)), "");
        let overflow = std::panic::catch_unwind(|| mesh_string_repeat(mesh_str("ab"), i64::MAX));
        let message = overflow.expect_err("an overflowing length panics");
        assert!(
            crate::panic::MeshPanic::of(&*message)
                .is_some_and(|panic| panic.reason().contains("do not fit in a string")),
            "{message:?}"
        );
    }

    #[test]
    fn test_string_new_and_read() {
        mesh_rt_init();
        let data = b"hello";
        let s = mesh_string_new(data.as_ptr(), data.len() as u64);
        unsafe {
            assert_eq!((*s).len, 5);
            assert_eq!((*s).as_str(), "hello");
        }
    }

    #[test]
    fn test_string_concat() {
        mesh_rt_init();
        let a = mesh_string_new(b"hello ".as_ptr(), 6);
        let b = mesh_string_new(b"world".as_ptr(), 5);
        let result = mesh_string_concat(a, b);
        unsafe {
            assert_eq!((*result).len, 11);
            assert_eq!((*result).as_str(), "hello world");
        }
    }

    #[test]
    fn test_int_to_string() {
        mesh_rt_init();
        let s = mesh_int_to_string(42);
        unsafe {
            assert_eq!((*s).as_str(), "42");
        }
    }

    #[test]
    fn test_string_compare_orders_by_bytes() {
        mesh_rt_init();
        let text = |s: &str| mesh_string_new(s.as_ptr(), s.len() as u64) as *const MeshString;
        assert_eq!(mesh_string_compare(text("apple"), text("banana")), -1);
        assert_eq!(mesh_string_compare(text("pear"), text("pear")), 0);
        assert_eq!(mesh_string_compare(text("pears"), text("pear")), 1);
        assert_eq!(mesh_string_compare(text(""), text("a")), -1);
    }

    #[test]
    fn test_int_to_string_extremes() {
        mesh_rt_init();
        for val in [0, i64::MAX, i64::MIN] {
            let s = mesh_int_to_string(val);
            assert_eq!(unsafe { (*s).as_str() }, val.to_string());
        }
    }

    #[test]
    fn test_int_to_string_negative() {
        mesh_rt_init();
        let s = mesh_int_to_string(-123);
        unsafe {
            assert_eq!((*s).as_str(), "-123");
        }
    }

    #[test]
    fn test_float_to_string() {
        mesh_rt_init();
        let s = mesh_float_to_string(2.75);
        unsafe {
            let text = (*s).as_str();
            assert!(text.starts_with("2.75"), "got: {}", text);
        }
        // A Float reads as one in exponent form too (it printed `1e20`).
        for (val, text) in [
            (1.0e20, "1.0e20"),
            (1.5e-7, "1.5e-7"),
            (-2.0e300, "-2.0e300"),
        ] {
            let s = mesh_float_to_string(val);
            assert_eq!(unsafe { (*s).as_str() }, text);
        }
    }

    #[test]
    fn test_bool_to_string() {
        mesh_rt_init();
        let t = mesh_bool_to_string(1);
        let f = mesh_bool_to_string(0);
        unsafe {
            assert_eq!((*t).as_str(), "true");
            assert_eq!((*f).as_str(), "false");
        }
    }

    #[test]
    fn test_empty_string() {
        mesh_rt_init();
        let s = mesh_string_new(std::ptr::null(), 0);
        unsafe {
            assert_eq!((*s).len, 0);
            assert_eq!((*s).as_str(), "");
        }
    }

    // ── Phase 8 string operation tests ─────────────────────────────────

    #[test]
    fn test_string_length() {
        mesh_rt_init();
        let s = mesh_string_new(b"hello".as_ptr(), 5);
        assert_eq!(mesh_string_length(s), 5);
    }

    #[test]
    fn test_string_length_unicode() {
        mesh_rt_init();
        // "cafe\u{0301}" = "cafe\u{0301}" -- 5 codepoints, but more bytes
        let text = "caf\u{00e9}"; // 4 codepoints, e-with-accent is 2 bytes
        let s = mesh_string_new(text.as_ptr(), text.len() as u64);
        assert_eq!(mesh_string_length(s), 4);
    }

    #[test]
    fn test_string_length_empty() {
        mesh_rt_init();
        let s = mesh_string_new(std::ptr::null(), 0);
        assert_eq!(mesh_string_length(s), 0);
    }

    #[test]
    fn test_string_slice() {
        mesh_rt_init();
        let s = mesh_string_new(b"hello world".as_ptr(), 11);
        let sliced = mesh_string_slice(s, 0, 5);
        unsafe {
            assert_eq!((*sliced).as_str(), "hello");
        }
    }

    #[test]
    fn test_string_slice_clamp() {
        mesh_rt_init();
        let s = mesh_string_new(b"abc".as_ptr(), 3);
        // Out of bounds clamps
        let sliced = mesh_string_slice(s, -5, 100);
        unsafe {
            assert_eq!((*sliced).as_str(), "abc");
        }
    }

    #[test]
    fn test_string_contains() {
        mesh_rt_init();
        let hay = mesh_string_new(b"hello world".as_ptr(), 11);
        let needle = mesh_string_new(b"world".as_ptr(), 5);
        let missing = mesh_string_new(b"xyz".as_ptr(), 3);
        assert_eq!(mesh_string_contains(hay, needle), 1);
        assert_eq!(mesh_string_contains(hay, missing), 0);
    }

    #[test]
    fn test_string_starts_with() {
        mesh_rt_init();
        let s = mesh_string_new(b"hello world".as_ptr(), 11);
        let prefix = mesh_string_new(b"hello".as_ptr(), 5);
        let wrong = mesh_string_new(b"world".as_ptr(), 5);
        assert_eq!(mesh_string_starts_with(s, prefix), 1);
        assert_eq!(mesh_string_starts_with(s, wrong), 0);
    }

    #[test]
    fn test_string_ends_with() {
        mesh_rt_init();
        let s = mesh_string_new(b"hello world".as_ptr(), 11);
        let suffix = mesh_string_new(b"world".as_ptr(), 5);
        let wrong = mesh_string_new(b"hello".as_ptr(), 5);
        assert_eq!(mesh_string_ends_with(s, suffix), 1);
        assert_eq!(mesh_string_ends_with(s, wrong), 0);
    }

    #[test]
    fn test_string_trim() {
        mesh_rt_init();
        let s = mesh_string_new(b"  hello  ".as_ptr(), 9);
        let trimmed = mesh_string_trim(s);
        unsafe {
            assert_eq!((*trimmed).as_str(), "hello");
        }
    }

    #[test]
    fn test_string_to_upper() {
        mesh_rt_init();
        let s = mesh_string_new(b"hello".as_ptr(), 5);
        let upper = mesh_string_to_upper(s);
        unsafe {
            assert_eq!((*upper).as_str(), "HELLO");
        }
    }

    #[test]
    fn test_string_to_lower() {
        mesh_rt_init();
        let s = mesh_string_new(b"HELLO".as_ptr(), 5);
        let lower = mesh_string_to_lower(s);
        unsafe {
            assert_eq!((*lower).as_str(), "hello");
        }
    }

    #[test]
    fn test_string_replace() {
        mesh_rt_init();
        let s = mesh_string_new(b"hello world".as_ptr(), 11);
        let from = mesh_string_new(b"world".as_ptr(), 5);
        let to = mesh_string_new(b"mesh".as_ptr(), 4);
        let result = mesh_string_replace(s, from, to);
        unsafe {
            assert_eq!((*result).as_str(), "hello mesh");
        }
    }

    #[test]
    fn test_string_eq() {
        mesh_rt_init();
        let a = mesh_string_new(b"hello".as_ptr(), 5);
        let b = mesh_string_new(b"hello".as_ptr(), 5);
        let c = mesh_string_new(b"world".as_ptr(), 5);
        assert_eq!(mesh_string_eq(a, b), 1);
        assert_eq!(mesh_string_eq(a, c), 0);
    }
}
