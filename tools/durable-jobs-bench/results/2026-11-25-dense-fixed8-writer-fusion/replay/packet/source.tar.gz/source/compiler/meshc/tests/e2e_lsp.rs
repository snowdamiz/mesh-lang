//! End-to-end JSON-RPC tests for `meshc lsp` against manifest-driven
//! override-entry projects.
//!
//! Proves that a real LSP process behaves correctly on:
//! - override-entry projects rooted by `mesh.toml` + `lib/start.mpl`
//! - clean and broken diagnostics publication over stdio JSON-RPC
//! - semantic provider requests that cross the project module graph
//! - document formatting through the shared formatter path
//! - signature help as an editor assist surface

#[path = "support/test_artifacts.rs"]
mod artifacts;

use std::collections::VecDeque;
use std::fs;
use std::io::{BufRead, BufReader, Write};
use std::path::{Component, Path, PathBuf};
use std::process::{Child, ChildStdin, Command, Stdio};
use std::sync::{mpsc, Arc, Mutex};
use std::thread;
use std::time::{Duration, Instant};

use serde_json::{json, Value};

const MESSAGE_TIMEOUT: Duration = Duration::from_secs(8);
/// The first message waits for the server to start too, which a host that
/// assesses each new process (macOS under cargo) can hold for seconds.
const FIRST_MESSAGE_TIMEOUT: Duration = Duration::from_secs(60);
const DEFAULT_ENTRYPOINT: &str = "main.mpl";

fn meshc_bin() -> PathBuf {
    PathBuf::from(env!("CARGO_BIN_EXE_meshc"))
}

fn artifact_dir(test_name: &str) -> PathBuf {
    artifacts::artifact_dir("lsp", test_name)
}

fn file_uri(path: &Path) -> String {
    format!("file://{}", path.to_string_lossy())
}

fn write_file(path: &Path, contents: &str) -> Result<(), String> {
    let Some(parent) = path.parent() else {
        return Err(format!(
            "File '{}' is missing a parent directory",
            path.display()
        ));
    };
    fs::create_dir_all(parent)
        .map_err(|error| format!("Failed to create '{}': {error}", parent.display()))?;
    fs::write(path, contents)
        .map_err(|error| format!("Failed to write '{}': {error}", path.display()))
}

fn validate_relative_fixture_path(path: &str) -> Result<(), String> {
    let path = Path::new(path);
    if path.is_absolute() {
        return Err(format!(
            "Fixture path '{}' must stay relative to the temp project root",
            path.display()
        ));
    }

    for component in path.components() {
        match component {
            Component::ParentDir | Component::RootDir | Component::Prefix(_) => {
                return Err(format!(
                    "Fixture path '{}' escapes the temp project root",
                    path.display()
                ));
            }
            Component::CurDir | Component::Normal(_) => {}
        }
    }

    Ok(())
}

fn package_manifest(name: &str, entrypoint: &str) -> String {
    format!("[package]\nname = \"{name}\"\nversion = \"0.1.0\"\nentrypoint = \"{entrypoint}\"\n")
}

fn source_position(source: &str, needle: &str, occurrence: usize) -> (u64, u64) {
    let (byte_index, _) = source
        .match_indices(needle)
        .nth(occurrence)
        .unwrap_or_else(|| {
            panic!(
                "could not find occurrence {} of {:?} in source",
                occurrence, needle
            )
        });
    let prefix = &source[..byte_index];
    let line = prefix.bytes().filter(|byte| *byte == b'\n').count() as u64;
    let character = prefix
        .rsplit('\n')
        .next()
        .map(|segment| segment.chars().count())
        .unwrap_or_else(|| prefix.chars().count()) as u64;
    (line, character)
}

fn pretty_json(value: &Value) -> String {
    serde_json::to_string_pretty(value).unwrap_or_else(|_| value.to_string())
}

#[derive(Debug)]
struct OverrideProjectFixture {
    _tempdir: tempfile::TempDir,
    project_dir: PathBuf,
    entry_path: PathBuf,
    entry_uri: String,
    entry_source: String,
    nested_support_path: PathBuf,
    nested_support_uri: String,
    nested_support_source: String,
    artifacts: PathBuf,
}

struct OverrideProjectSpec<'a> {
    name: &'a str,
    manifest_entrypoint: &'a str,
    entry_path: &'a str,
    nested_support_path: &'a str,
    files: &'a [(&'a str, &'a str)],
}

fn write_override_project_fixture(
    test_name: &str,
    spec: &OverrideProjectSpec<'_>,
) -> Result<OverrideProjectFixture, String> {
    validate_relative_fixture_path(spec.manifest_entrypoint)?;
    validate_relative_fixture_path(spec.entry_path)?;
    validate_relative_fixture_path(spec.nested_support_path)?;

    let artifacts = artifact_dir(test_name);
    let tempdir =
        tempfile::tempdir().map_err(|error| format!("Failed to create temp dir: {error}"))?;
    let project_dir = tempdir.path().join(spec.name);
    fs::create_dir_all(&project_dir)
        .map_err(|error| format!("Failed to create '{}': {error}", project_dir.display()))?;

    write_file(
        &project_dir.join("mesh.toml"),
        &package_manifest(spec.name, spec.manifest_entrypoint),
    )?;

    for (relative_path, contents) in spec.files {
        validate_relative_fixture_path(relative_path)?;
        write_file(&project_dir.join(relative_path), contents)?;
    }

    let expected_entry = project_dir.join(spec.entry_path);
    if !expected_entry.is_file() {
        return Err(format!(
            "Fixture '{}' is missing expected executable entry '{}'; refusing to run a malformed acceptance project.",
            spec.name, spec.entry_path
        ));
    }

    let expected_nested_support = project_dir.join(spec.nested_support_path);
    if !expected_nested_support.is_file() {
        return Err(format!(
            "Fixture '{}' is missing nested support module '{}'; refusing to run a malformed acceptance project.",
            spec.name, spec.nested_support_path
        ));
    }

    artifacts::archive_directory_tree(&project_dir, &artifacts.join("project"));

    let project_dir = fs::canonicalize(&project_dir).map_err(|error| {
        format!(
            "Failed to canonicalize '{}': {error}",
            project_dir.display()
        )
    })?;
    let entry_path = fs::canonicalize(&expected_entry).map_err(|error| {
        format!(
            "Failed to canonicalize '{}': {error}",
            expected_entry.display()
        )
    })?;
    let nested_support_path = fs::canonicalize(&expected_nested_support).map_err(|error| {
        format!(
            "Failed to canonicalize '{}': {error}",
            expected_nested_support.display()
        )
    })?;
    let entry_source = fs::read_to_string(&entry_path)
        .map_err(|error| format!("Failed to read '{}': {error}", entry_path.display()))?;
    let nested_support_source = fs::read_to_string(&nested_support_path).map_err(|error| {
        format!(
            "Failed to read '{}': {error}",
            nested_support_path.display()
        )
    })?;

    artifacts::write_artifact(
        &artifacts.join("fixture-paths.txt"),
        format!(
            "project_dir: {}\nentry_path: {}\nnested_support_path: {}\n",
            project_dir.display(),
            entry_path.display(),
            nested_support_path.display()
        ),
    );

    Ok(OverrideProjectFixture {
        _tempdir: tempdir,
        project_dir,
        entry_uri: file_uri(&entry_path),
        entry_path,
        entry_source,
        nested_support_uri: file_uri(&nested_support_path),
        nested_support_path,
        nested_support_source,
        artifacts,
    })
}

fn override_only_nested_fixture(test_name: &str) -> Result<OverrideProjectFixture, String> {
    let spec = OverrideProjectSpec {
        name: "override-entry-lsp-project",
        manifest_entrypoint: "lib/start.mpl",
        entry_path: "lib/start.mpl",
        nested_support_path: "lib/support/message.mpl",
        files: &[
            (
                "lib/start.mpl",
                "from Lib.Support.Message import message\n\nfn main() do\n  let rendered = message()\n  println(\"proof=#{rendered}\")\nend\n",
            ),
            (
                "lib/support/message.mpl",
                "pub fn message() -> String do\n  \"nested-support\"\nend\n",
            ),
        ],
    };

    write_override_project_fixture(test_name, &spec)
}

fn override_precedence_nested_fixture(test_name: &str) -> Result<OverrideProjectFixture, String> {
    let spec = OverrideProjectSpec {
        name: "override-precedence-lsp-project",
        manifest_entrypoint: "lib/start.mpl",
        entry_path: "lib/start.mpl",
        nested_support_path: "lib/support/message.mpl",
        files: &[
            (
                DEFAULT_ENTRYPOINT,
                "fn main() do\n  println(\"default-root-main\")\nend\n",
            ),
            (
                "lib/start.mpl",
                "from Lib.Support.Message import message\n\nfn main() do\n  println(message())\nend\n",
            ),
            (
                "lib/support/message.mpl",
                "pub fn message() -> String do\n  \"override-precedence\"\nend\n",
            ),
        ],
    };

    write_override_project_fixture(test_name, &spec)
}

fn read_json_rpc_message(reader: &mut impl BufRead) -> Result<Option<Value>, String> {
    let mut content_length = None;

    loop {
        let mut line = String::new();
        let bytes = reader
            .read_line(&mut line)
            .map_err(|error| format!("failed to read JSON-RPC header: {error}"))?;
        if bytes == 0 {
            return Ok(None);
        }
        if line == "\r\n" {
            break;
        }
        if let Some(value) = line.strip_prefix("Content-Length:") {
            let parsed = value.trim().parse::<usize>().map_err(|error| {
                format!("invalid JSON-RPC Content-Length header {line:?}: {error}")
            })?;
            content_length = Some(parsed);
        }
    }

    let len = content_length.ok_or_else(|| "missing JSON-RPC Content-Length header".to_string())?;
    let mut body = vec![0; len];
    reader
        .read_exact(&mut body)
        .map_err(|error| format!("failed to read JSON-RPC body (len={len}): {error}"))?;
    serde_json::from_slice(&body).map(Some).map_err(|error| {
        format!(
            "failed to parse JSON-RPC body as JSON: {error}; raw body: {}",
            String::from_utf8_lossy(&body)
        )
    })
}

enum LspEvent {
    Message(Value),
    ReadError(String),
}

struct LspSession {
    child: Child,
    stdin: ChildStdin,
    rx: mpsc::Receiver<LspEvent>,
    pending: VecDeque<Value>,
    stderr: Arc<Mutex<String>>,
    trace: Arc<Mutex<Vec<String>>>,
    artifacts: PathBuf,
    session_label: String,
    next_id: u64,
    /// Whether the server has said anything yet.
    started: bool,
}

impl LspSession {
    fn new(cwd: &Path, artifacts: PathBuf, session_label: &str) -> Self {
        let mut child = Command::new(meshc_bin())
            .current_dir(cwd)
            .arg("lsp")
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::piped())
            .spawn()
            .unwrap_or_else(|error| {
                panic!(
                    "failed to spawn meshc lsp in {} (artifacts: {}): {error}",
                    cwd.display(),
                    artifacts.display()
                )
            });

        let stdin = child.stdin.take().expect("meshc lsp stdin should be piped");
        let stdout = child
            .stdout
            .take()
            .expect("meshc lsp stdout should be piped");
        let stderr_reader = child
            .stderr
            .take()
            .expect("meshc lsp stderr should be piped");

        let trace = Arc::new(Mutex::new(Vec::new()));
        let stdout_trace = Arc::clone(&trace);
        let (tx, rx) = mpsc::channel();
        thread::spawn(move || {
            let mut reader = BufReader::new(stdout);
            loop {
                match read_json_rpc_message(&mut reader) {
                    Ok(Some(message)) => {
                        stdout_trace
                            .lock()
                            .unwrap()
                            .push(format!("<<< {}", pretty_json(&message)));
                        if tx.send(LspEvent::Message(message)).is_err() {
                            break;
                        }
                    }
                    Ok(None) => break,
                    Err(error) => {
                        stdout_trace
                            .lock()
                            .unwrap()
                            .push(format!("!!! stdout read error: {error}"));
                        let _ = tx.send(LspEvent::ReadError(error));
                        break;
                    }
                }
            }
        });

        let stderr = Arc::new(Mutex::new(String::new()));
        let stderr_capture = Arc::clone(&stderr);
        thread::spawn(move || {
            let mut reader = BufReader::new(stderr_reader);
            loop {
                let mut line = String::new();
                match reader.read_line(&mut line) {
                    Ok(0) => break,
                    Ok(_) => stderr_capture.lock().unwrap().push_str(&line),
                    Err(error) => {
                        stderr_capture
                            .lock()
                            .unwrap()
                            .push_str(&format!("[stderr read error] {error}\n"));
                        break;
                    }
                }
            }
        });

        Self {
            child,
            stdin,
            rx,
            pending: VecDeque::new(),
            stderr,
            trace,
            artifacts,
            session_label: session_label.to_string(),
            next_id: 1,
            started: false,
        }
    }

    fn request(&mut self, method: &str, params: Value) -> Value {
        let id = self.next_id;
        self.next_id += 1;
        self.send(&json!({
            "jsonrpc": "2.0",
            "id": id,
            "method": method,
            "params": params,
        }));

        self.recv_response(id, method)
    }

    fn request_without_params(&mut self, method: &str) -> Value {
        let id = self.next_id;
        self.next_id += 1;
        self.send(&json!({
            "jsonrpc": "2.0",
            "id": id,
            "method": method,
        }));

        self.recv_response(id, method)
    }

    fn recv_response(&mut self, id: u64, method: &str) -> Value {
        let response = self.recv_matching(&format!("response for {method}"), |message| {
            message.get("id").and_then(Value::as_u64) == Some(id)
        });

        if let Some(error) = response.get("error") {
            self.persist_observability();
            panic!(
                "{method} returned JSON-RPC error: {}\n{}",
                error,
                self.failure_context(&format!("response for {method}"))
            );
        }

        response
    }

    fn notify(&mut self, method: &str, params: Value) {
        self.send(&json!({
            "jsonrpc": "2.0",
            "method": method,
            "params": params,
        }));
    }

    fn send(&mut self, message: &Value) {
        self.trace
            .lock()
            .unwrap()
            .push(format!(">>> {}", pretty_json(message)));

        let body = serde_json::to_vec(message).expect("JSON-RPC payload should serialize");
        let header = format!("Content-Length: {}\r\n\r\n", body.len());
        self.stdin
            .write_all(header.as_bytes())
            .expect("failed to write JSON-RPC header");
        self.stdin
            .write_all(&body)
            .expect("failed to write JSON-RPC body");
        self.stdin.flush().expect("failed to flush JSON-RPC body");
    }

    fn recv_matching<F>(&mut self, label: &str, mut predicate: F) -> Value
    where
        F: FnMut(&Value) -> bool,
    {
        if let Some(index) = self.pending.iter().position(&mut predicate) {
            return self
                .pending
                .remove(index)
                .expect("pending index should exist");
        }

        let timeout = if self.started {
            MESSAGE_TIMEOUT
        } else {
            FIRST_MESSAGE_TIMEOUT
        };
        let deadline = Instant::now() + timeout;
        loop {
            let remaining = deadline
                .checked_duration_since(Instant::now())
                .unwrap_or_else(|| Duration::from_millis(0));
            if remaining.is_zero() {
                self.persist_observability();
                panic!(
                    "timed out waiting for {label}\n{}",
                    self.failure_context(label)
                );
            }

            match self.rx.recv_timeout(remaining) {
                Ok(LspEvent::Message(message)) => {
                    self.started = true;
                    if predicate(&message) {
                        return message;
                    }
                    self.pending.push_back(message);
                }
                Ok(LspEvent::ReadError(error)) => {
                    self.persist_observability();
                    panic!(
                        "meshc lsp emitted malformed JSON-RPC while waiting for {label}: {error}\n{}",
                        self.failure_context(label)
                    );
                }
                Err(mpsc::RecvTimeoutError::Timeout) => {
                    self.persist_observability();
                    panic!(
                        "timed out waiting for {label}\n{}",
                        self.failure_context(label)
                    );
                }
                Err(mpsc::RecvTimeoutError::Disconnected) => {
                    self.persist_observability();
                    panic!(
                        "meshc lsp stdout disconnected while waiting for {label}\n{}",
                        self.failure_context(label)
                    );
                }
            }
        }
    }

    fn wait_for_diagnostics(&mut self, uri: &str, phase: &str) -> Vec<Value> {
        let label = format!("publishDiagnostics for {uri} during {phase}");
        let message = self.recv_matching(&label, |value| {
            value.get("method").and_then(Value::as_str) == Some("textDocument/publishDiagnostics")
                && value
                    .get("params")
                    .and_then(|params| params.get("uri"))
                    .and_then(Value::as_str)
                    == Some(uri)
        });

        let diagnostics = if let Some(diagnostics) = message
            .get("params")
            .and_then(|params| params.get("diagnostics"))
            .and_then(Value::as_array)
            .cloned()
        {
            diagnostics
        } else {
            self.persist_observability();
            panic!(
                "publishDiagnostics for {uri} during {phase} did not include a diagnostics array; raw message: {}\n{}",
                pretty_json(&message),
                self.failure_context(&label)
            );
        };

        println!(
            "[e2e_lsp] phase={phase} uri={uri} diagnostics={}",
            diagnostics.len()
        );
        diagnostics
    }

    fn stderr_output(&self) -> String {
        self.stderr.lock().unwrap().clone()
    }

    fn trace_output(&self) -> String {
        let trace = self.trace.lock().unwrap();
        if trace.is_empty() {
            "<empty trace>".to_string()
        } else {
            trace.join("\n")
        }
    }

    fn child_status_line(&mut self) -> String {
        match self.child.try_wait() {
            Ok(Some(status)) => format!("child_status: {:?}", status.code()),
            Ok(None) => "child_status: still running".to_string(),
            Err(error) => format!("child_status: unavailable ({error})"),
        }
    }

    fn persist_observability(&self) {
        artifacts::write_artifact(
            &self
                .artifacts
                .join(format!("{}.trace.log", self.session_label)),
            self.trace_output(),
        );
        artifacts::write_artifact(
            &self
                .artifacts
                .join(format!("{}.stderr.log", self.session_label)),
            self.stderr_output(),
        );
    }

    fn failure_context(&mut self, label: &str) -> String {
        let artifacts = self.artifacts.display().to_string();
        let child_status = self.child_status_line();
        let pending = format!("{:?}", self.pending);
        let stderr = self.stderr_output();
        let trace = self.trace_output();

        format!(
            "phase: {label}\nartifacts: {artifacts}\n{child_status}\npending messages: {pending}\nstderr:\n{stderr}\ntrace:\n{trace}"
        )
    }
}

impl LspSession {
    /// Say `exit`, as an editor does, with stdin left open: whether the
    /// server then ends within `within`.
    fn exits_within(&mut self, within: Duration) -> bool {
        // Not `notify`, which panics on a failed write: the server may be gone.
        let body = json!({"jsonrpc": "2.0", "method": "exit"}).to_string();
        let _ = write!(self.stdin, "Content-Length: {}\r\n\r\n{body}", body.len());
        let _ = self.stdin.flush();
        let deadline = Instant::now() + within;
        while Instant::now() < deadline {
            if matches!(self.child.try_wait(), Ok(Some(_))) {
                return true;
            }
            thread::sleep(Duration::from_millis(20));
        }
        false
    }
}

impl Drop for LspSession {
    /// Ask the server to exit, so it ends normally (and a
    /// coverage-instrumented build writes what it recorded); kill it only if
    /// it has not ended within a few seconds.
    fn drop(&mut self) {
        self.exits_within(Duration::from_secs(5));
        let _ = self.child.kill();
        let _ = self.child.wait();
        self.persist_observability();
    }
}

#[test]
fn override_entry_fixture_rejects_missing_configured_entry_file() {
    let spec = OverrideProjectSpec {
        name: "broken-override-entry-lsp-project",
        manifest_entrypoint: "lib/start.mpl",
        entry_path: "lib/start.mpl",
        nested_support_path: "lib/support/message.mpl",
        files: &[(
            "lib/support/message.mpl",
            "pub fn message() -> String do\n  \"nested-support\"\nend\n",
        )],
    };

    let error = write_override_project_fixture("fixture-missing-entry", &spec)
        .expect_err("fixture writer should reject a missing override entry file");

    assert!(error.contains("lib/start.mpl"), "unexpected error: {error}");
    assert!(
        error.contains("malformed acceptance project"),
        "unexpected error: {error}"
    );
}

#[test]
fn override_entry_fixture_rejects_invalid_relative_paths() {
    let spec = OverrideProjectSpec {
        name: "invalid-relative-path-lsp-project",
        manifest_entrypoint: "lib/start.mpl",
        entry_path: "lib/start.mpl",
        nested_support_path: "../escape/support.mpl",
        files: &[(
            "lib/start.mpl",
            "fn main() do\n  println(\"invalid\")\nend\n",
        )],
    };

    let error = write_override_project_fixture("fixture-invalid-relative-path", &spec)
        .expect_err("fixture writer should reject paths that escape the temp project root");

    assert!(error.contains("escapes the temp project root"), "{error}");
}

#[test]
fn override_entry_fixture_supports_override_precedence_layout() {
    let fixture = override_precedence_nested_fixture("fixture-override-precedence")
        .expect("override-precedence fixture should materialize cleanly");

    assert!(
        fixture.project_dir.join(DEFAULT_ENTRYPOINT).is_file(),
        "override-precedence fixture should keep a root main.mpl for the precedence boundary"
    );
    assert!(
        fixture.entry_path.is_file(),
        "override-precedence fixture should keep the manifest-selected entry file"
    );
    assert!(
        fixture.nested_support_path.is_file(),
        "override-precedence fixture should keep the nested support module"
    );
}

#[test]
fn read_json_rpc_message_rejects_malformed_payload() {
    let body = "{\"jsonrpc\":\"2.0\",\"id\":1,\"result\":";
    let framed = format!("Content-Length: {}\r\n\r\n{}", body.len(), body);
    let mut cursor = std::io::Cursor::new(framed.into_bytes());

    let error = read_json_rpc_message(&mut cursor)
        .expect_err("malformed JSON-RPC payloads should fail instead of being treated as EOF");

    assert!(
        error.contains("failed to parse JSON-RPC body as JSON"),
        "unexpected parser error: {error}"
    );
}

#[test]
fn lsp_json_rpc_override_entry_flow() {
    let fixture = override_only_nested_fixture("override-entry-flow")
        .unwrap_or_else(|error| panic!("override-entry fixture should materialize: {error}"));
    let message_call = "message()";
    let (message_call_line, message_call_character) =
        source_position(&fixture.entry_source, message_call, 0);

    let mut session = LspSession::new(
        &fixture.project_dir,
        fixture.artifacts.clone(),
        "override-entry",
    );

    let initialize = session.request(
        "initialize",
        json!({
            "processId": Value::Null,
            "rootUri": file_uri(&fixture.project_dir),
            "capabilities": {},
        }),
    );
    assert_eq!(
        initialize["result"]["capabilities"]["hoverProvider"].as_bool(),
        Some(true),
        "initialize should advertise hover support for override-entry projects: {initialize:?}"
    );

    session.notify("initialized", json!({}));

    println!(
        "[e2e_lsp] phase=override-entry didOpen uri={} path={}",
        fixture.entry_uri,
        fixture.entry_path.display()
    );
    session.notify(
        "textDocument/didOpen",
        json!({
            "textDocument": {
                "uri": fixture.entry_uri,
                "languageId": "mesh",
                "version": 1,
                "text": fixture.entry_source,
            }
        }),
    );
    let entry_diagnostics =
        session.wait_for_diagnostics(&fixture.entry_uri, "override-entry didOpen entry");
    assert!(
        entry_diagnostics.is_empty(),
        "override-entry entry file should open cleanly through live JSON-RPC, got diagnostics: {:?}\nartifacts: {}",
        entry_diagnostics,
        fixture.artifacts.display()
    );

    println!(
        "[e2e_lsp] phase=override-entry didOpen uri={} path={}",
        fixture.nested_support_uri,
        fixture.nested_support_path.display()
    );
    session.notify(
        "textDocument/didOpen",
        json!({
            "textDocument": {
                "uri": fixture.nested_support_uri,
                "languageId": "mesh",
                "version": 1,
                "text": fixture.nested_support_source,
            }
        }),
    );
    let support_diagnostics = session.wait_for_diagnostics(
        &fixture.nested_support_uri,
        "override-entry didOpen nested support",
    );
    assert!(
        support_diagnostics.is_empty(),
        "override-entry nested support file should open cleanly through live JSON-RPC, got diagnostics: {:?}\nartifacts: {}",
        support_diagnostics,
        fixture.artifacts.display()
    );

    let hover = session.request(
        "textDocument/hover",
        json!({
            "textDocument": { "uri": fixture.entry_uri },
            "position": {
                "line": message_call_line,
                "character": message_call_character,
            },
        }),
    );
    println!(
        "[e2e_lsp] phase=override-entry provider=hover uri={} response={}",
        fixture.entry_uri,
        pretty_json(&hover)
    );
    let hover_contents = hover["result"]["contents"]["value"]
        .as_str()
        .unwrap_or_default();
    assert!(
        hover.get("result").is_some() && !hover_contents.is_empty(),
        "override-entry hover should return type information for the imported nested helper, got: {}\nartifacts: {}",
        pretty_json(&hover),
        fixture.artifacts.display()
    );
    assert!(
        hover_contents.contains("String"),
        "override-entry hover should prove nested import typing instead of falling back to empty local analysis, got: {}\nartifacts: {}",
        pretty_json(&hover),
        fixture.artifacts.display()
    );

    let shutdown = session.request_without_params("shutdown");
    assert!(
        shutdown.get("result").is_some(),
        "shutdown should return a JSON-RPC result for override-entry flow, got: {shutdown:?}"
    );
    // It kept reading stdin after `exit` until the client closed it.
    assert!(
        session.exits_within(Duration::from_secs(5)),
        "the server should end when told to exit\n{}",
        session.failure_context("exit")
    );
}
