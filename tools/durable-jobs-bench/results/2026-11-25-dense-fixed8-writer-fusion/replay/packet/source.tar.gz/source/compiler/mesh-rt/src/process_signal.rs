//! Async-signal-safe shutdown notification for containerized applications.

use std::sync::atomic::{AtomicBool, Ordering};

static SHUTDOWN_REQUESTED: AtomicBool = AtomicBool::new(false);

pub(crate) fn shutdown_requested() -> bool {
    SHUTDOWN_REQUESTED.load(Ordering::SeqCst)
}

#[cfg(unix)]
extern "C" fn request_shutdown_from_signal(_signal: libc::c_int) {
    SHUTDOWN_REQUESTED.store(true, Ordering::SeqCst);
}

/// Write the coverage profile now, in a coverage build (`--cfg
/// mesh_coverage`): a process a signal ends runs no exit hook to write it.
/// Anywhere else, nothing.
pub(crate) fn write_coverage_profile() {
    #[cfg(all(mesh_coverage, unix))]
    unsafe {
        extern "C" {
            fn __llvm_profile_write_file() -> libc::c_int;
        }
        __llvm_profile_write_file();
    }
}

/// Coverage builds write the coverage profile when a program is told to
/// stop: test harnesses and `docker stop` end servers with SIGTERM. A
/// program that handles the signals itself replaces this and exits the
/// ordinary way, which writes it.
#[cfg(all(mesh_coverage, unix))]
pub(crate) fn install_coverage_flush() {
    use std::sync::atomic::AtomicI32;
    // A descriptor kept for the profile to be written with: a server stopped
    // for having run out of them has none left to open its file.
    static SPARE: AtomicI32 = AtomicI32::new(-1);
    extern "C" fn flush_and_exit(signal: libc::c_int) {
        unsafe { libc::close(SPARE.load(Ordering::SeqCst)) };
        write_coverage_profile();
        unsafe { libc::_exit(128 + signal) };
    }
    unsafe {
        if SPARE.load(Ordering::SeqCst) < 0 {
            SPARE.store(
                libc::open(c"/dev/null".as_ptr(), libc::O_RDONLY),
                Ordering::SeqCst,
            );
        }
        let handler = flush_and_exit as *const () as libc::sighandler_t;
        libc::signal(libc::SIGINT, handler);
        libc::signal(libc::SIGTERM, handler);
    }
}

#[no_mangle]
pub extern "C" fn mesh_process_install_shutdown_signals() {
    #[cfg(unix)]
    unsafe {
        let handler = request_shutdown_from_signal as *const () as libc::sighandler_t;
        libc::signal(libc::SIGINT, handler);
        libc::signal(libc::SIGTERM, handler);
    }
}

#[no_mangle]
pub extern "C" fn mesh_process_shutdown_requested() -> i8 {
    shutdown_requested() as i8
}

#[no_mangle]
pub extern "C" fn mesh_process_request_shutdown() {
    SHUTDOWN_REQUESTED.store(true, Ordering::SeqCst);
}

#[no_mangle]
pub extern "C" fn mesh_process_exit(code: i64) -> ! {
    // A status out of range is a failure, 1.
    std::process::exit(u8::try_from(code).map_or(1, i32::from))
}

#[cfg(all(test, unix))]
mod tests {
    use super::*;

    #[test]
    fn signal_handler_only_sets_the_shutdown_flag() {
        SHUTDOWN_REQUESTED.store(false, Ordering::SeqCst);
        request_shutdown_from_signal(libc::SIGTERM);
        assert_eq!(mesh_process_shutdown_requested(), 1);
        SHUTDOWN_REQUESTED.store(false, Ordering::SeqCst);
    }
}
