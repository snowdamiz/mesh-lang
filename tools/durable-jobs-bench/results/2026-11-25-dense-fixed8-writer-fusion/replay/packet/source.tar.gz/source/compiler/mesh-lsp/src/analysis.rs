//! Document analysis: the shared frontend's view of a document, and the
//! positions an editor speaks in.
//!
//! A document is checked as `meshc check` checks it, and each file that
//! parses is linted as `meshc lint` lints it: in its project, with the
//! editor's open documents read in place of their files, or on its own
//! outside any project. LSP positions are 0-based lines and UTF-16 code
//! units, converted against the analyzed text.

use std::collections::HashMap;
use std::path::{Path, PathBuf};

use rowan::TextRange;
use tower_lsp::lsp_types::{self, Position, Range, Url};

use mesh_diagnostics::{Code, Diagnostic, SourceFile};
use mesh_pkg::frontend::{self, CheckOptions, Frontend, Target};
use mesh_pkg::manifest::DEFAULT_ENTRYPOINT;
use mesh_typeck::ty::Ty;
use mesh_typeck::TypeckResult;

/// The result of analyzing a Mesh document.
pub struct AnalysisResult {
    /// Everything the frontend found: the document's, and those of the
    /// project's other files.
    pub diagnostics: Vec<Diagnostic>,
    /// The text analyzed, which `parse` and `typeck` describe: the document,
    /// or for a test file the program `meshc test` makes of it, which keeps
    /// every line and column of the document but not its byte offsets.
    /// Positions are converted against it.
    pub file: SourceFile,
    /// The parse result, kept for further queries.
    pub parse: mesh_parser::Parse,
    /// The type-check result, kept for hover queries.
    pub typeck: TypeckResult,
    /// Whether the project loaded before checking (false when manifest
    /// loading or test preprocessing failed early).
    pub loaded: bool,
    /// The project's entry file path when a project analysis loaded it.
    pub entry: Option<PathBuf>,
}

#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
pub(crate) enum ProjectRole {
    Project,
    TestHelper,
    TestFile,
}

pub(crate) fn project_role(root: &Path, path: &Path) -> ProjectRole {
    let Ok(relative) = path.strip_prefix(root) else {
        return ProjectRole::Project;
    };
    let is_test_file = relative
        .file_name()
        .and_then(|name| name.to_str())
        .is_some_and(|name| name.ends_with(".test.mpl"));
    if is_test_file {
        ProjectRole::TestFile
    } else if relative.starts_with("tests") {
        ProjectRole::TestHelper
    } else {
        ProjectRole::Project
    }
}

impl AnalysisResult {
    pub fn source(&self) -> &str {
        self.file.text().unwrap_or_default()
    }

    /// The diagnostics to publish on the document, whose URI is `uri`.
    pub fn lsp_diagnostics(&self, uri: &Url) -> Vec<lsp_types::Diagnostic> {
        let uri_for = |path: &Path| {
            if path == self.file.path() {
                Some(uri.clone())
            } else {
                Url::from_file_path(path).ok()
            }
        };
        crate::diagnostics::by_uri(&self.diagnostics, &self.file, &uri_for)
            .remove(uri)
            .unwrap_or_default()
            .into_iter()
            .map(|diagnostic| diagnostic.lsp)
            .collect()
    }
}

/// Analyze a Mesh document: the frontend's diagnostics, and the parse and
/// type check of the document for queries.
///
/// This is the main entry point called by the LSP server on didOpen/didChange.
/// When the URI belongs to a Mesh project (an ancestor contains `mesh.toml`),
/// the project is checked, with `open_documents` read in place of their files.
pub fn analyze_document(
    uri: &str,
    source: &str,
    open_documents: &[(String, String)],
) -> AnalysisResult {
    let path = canonical_file_path(uri);
    if let Some(path) = &path {
        if let Some(root) = find_project_root(path) {
            return analyze_in_project(&root, path, source, open_documents);
        }
    }
    // A buffer that is not a file is named as a lone file is built.
    let path = path.unwrap_or_else(|| PathBuf::from(DEFAULT_ENTRYPOINT));
    let target = Target::Source {
        path: &path,
        text: source,
    };
    let checked = check_and_lint(target, &CheckOptions::cli());
    // A lone file's module is named by its file name.
    let module = Path::new(path.file_name().unwrap_or(DEFAULT_ENTRYPOINT.as_ref()));
    module_analysis(checked, None, module).unwrap_or_else(|(diagnostics, loaded, entry)| {
        analysis_alone(diagnostics, &path, source, loaded, entry)
    })
}

fn analyze_in_project(
    root: &Path,
    path: &Path,
    source: &str,
    open_documents: &[(String, String)],
) -> AnalysisResult {
    let mut overlays = HashMap::new();
    for (open_uri, open_source) in open_documents {
        if let Some(open_path) = canonical_file_path(open_uri) {
            overlays.insert(open_path, open_source.clone());
        }
    }
    overlays.insert(path.to_path_buf(), source.to_string());

    let relative = path
        .strip_prefix(root)
        .expect("the project root is an ancestor of the document");
    // A test file is not a module: `meshc test` compiles it on its own,
    // with the project's modules, the helpers under `tests/` and the test
    // builtins.
    let role = project_role(root, path);
    let options = CheckOptions {
        test_builtins: matches!(role, ProjectRole::TestFile | ProjectRole::TestHelper),
        ..CheckOptions::editor(&overlays)
    };
    let target = if role == ProjectRole::TestFile {
        Target::TestFile { root, test: path }
    } else {
        Target::Project { root }
    };
    let checked = check_and_lint(target, &options);
    let entry_root = (role != ProjectRole::TestFile).then_some(root);
    module_analysis(checked, entry_root, relative).unwrap_or_else(
        |(mut diagnostics, loaded, entry)| {
            if loaded {
                diagnostics.insert(
                    0,
                    Diagnostic::in_file(
                        Code::ModuleUnreadable,
                        &SourceFile::new(path, source),
                        format!(
                            "Document '{}' was not discovered under project root '{}'",
                            path.display(),
                            root.display()
                        ),
                    )
                    .with_repair(
                        "Place the document in the project outside hidden directories and nested packages.",
                    ),
                );
            }
            analysis_alone(diagnostics, path, source, loaded, entry)
        },
    )
}

/// What `meshc check` reports for `target`, with what `meshc lint` reports
/// for each of its files that parses.
fn check_and_lint(target: Target<'_>, options: &CheckOptions<'_>) -> Frontend {
    let mut checked = frontend::check(target, options);
    let lints: Vec<Diagnostic> = checked
        .lintable()
        .flat_map(|(parse, file)| mesh_lint::lint(parse, file))
        .collect();
    checked.extend(lints);
    checked
}

/// The module at `relative` (to the project root) of the checked project;
/// the diagnostics alone when the project did not load or has no such
/// module.
fn module_analysis(
    checked: Frontend,
    entry_root: Option<&Path>,
    relative: &Path,
) -> Result<AnalysisResult, (Vec<Diagnostic>, bool, Option<PathBuf>)> {
    let Frontend {
        diagnostics,
        analysis,
    } = checked;
    let Some(mut analysis) = analysis else {
        return Err((diagnostics, false, None));
    };
    let entry = entry_root.and_then(|root| {
        analysis.entry.as_ref().map(|rel| {
            let path = root.join(rel);
            std::fs::canonicalize(&path).unwrap_or(path)
        })
    });
    let Some(idx) = analysis
        .project
        .graph
        .modules
        .iter()
        .position(|module| module.path == relative)
    else {
        return Err((diagnostics, true, entry));
    };
    Ok(AnalysisResult {
        diagnostics,
        file: analysis.files.swap_remove(idx),
        parse: analysis.project.module_parses.swap_remove(idx),
        typeck: analysis.checked.typeck.swap_remove(idx),
        loaded: true,
        entry,
    })
}

/// `diagnostics`, with the document parsed and checked on its own for
/// queries.
fn analysis_alone(
    diagnostics: Vec<Diagnostic>,
    path: &Path,
    source: &str,
    loaded: bool,
    entry: Option<PathBuf>,
) -> AnalysisResult {
    let parse = mesh_parser::parse(source);
    let typeck = mesh_typeck::check(&parse);
    AnalysisResult {
        diagnostics,
        file: SourceFile::new(path, source),
        parse,
        typeck,
        loaded,
        entry,
    }
}

/// The LSP range of a syntax tree range: tree offsets are source offsets.
pub fn text_range_to_range(file: &SourceFile, range: TextRange) -> Range {
    Range::new(
        offset_to_position(file, range.start().into()),
        offset_to_position(file, range.end().into()),
    )
}

/// The LSP position of byte `offset` of `file`; past the end, the end.
pub fn offset_to_position(file: &SourceFile, offset: usize) -> Position {
    let end = file.text().map_or(0, str::len);
    let (line, character) = file
        .utf16_position(offset.min(end) as u32)
        .unwrap_or_default();
    Position::new(line, character)
}

/// The byte offset of an LSP position in `file`. A character past the end
/// of its line is the line's end; a line past the end of the file has no
/// offset.
pub fn position_to_offset(file: &SourceFile, position: &Position) -> Option<usize> {
    file.offset_of_utf16(position.line, position.character)
        .map(|offset| offset as usize)
}

/// Look up the inferred type at a given LSP position.
///
/// Searches the typeck result's type map for the smallest range that contains
/// the given byte offset. Returns the type formatted as a string.
pub fn type_at_position(
    file: &SourceFile,
    typeck: &TypeckResult,
    position: &Position,
) -> Option<String> {
    let offset = position_to_offset(file, position)?;
    let target_offset = rowan::TextSize::from(offset as u32);

    // Find the smallest range containing this offset.
    let mut best: Option<(TextRange, &Ty)> = None;
    for (range, ty) in &typeck.types {
        if range.contains(target_offset) || range.start() == target_offset {
            match &best {
                Some((best_range, _)) if range.len() < best_range.len() => {
                    best = Some((*range, ty));
                }
                None => {
                    best = Some((*range, ty));
                }
                _ => {}
            }
        }
    }

    best.map(|(_, ty)| ty.with_named_vars().to_string())
}

pub(crate) fn canonical_file_path(uri: &str) -> Option<PathBuf> {
    let url = Url::parse(uri).ok()?;
    let path = url.to_file_path().ok()?;
    Some(canonicalize_lossy(path))
}

fn canonicalize_lossy(path: PathBuf) -> PathBuf {
    if let Ok(canon) = std::fs::canonicalize(&path) {
        return canon;
    }
    let mut suffix = Vec::new();
    let mut current = path.as_path();
    while let Some(name) = current.file_name() {
        suffix.push(name.to_os_string());
        let Some(parent) = current.parent() else {
            return path;
        };
        if let Ok(mut canon) = std::fs::canonicalize(parent) {
            for component in suffix.into_iter().rev() {
                canon.push(component);
            }
            return canon;
        }
        current = parent;
    }
    path
}

/// The nearest directory above the document holding a mesh.toml: one of
/// its ancestors as spelled, so the document's path is under it even when
/// the document is not on disk and could not be canonicalized.
pub(crate) fn find_project_root(path: &Path) -> Option<PathBuf> {
    path.ancestors()
        .skip(1)
        .find(|dir| dir.join("mesh.toml").exists())
        .map(Path::to_path_buf)
}

#[cfg(test)]
mod tests {
    use super::*;
    use mesh_pkg::manifest::{resolve_entrypoint, Manifest};
    use mesh_pkg::project::build_project;
    use tower_lsp::lsp_types::{Diagnostic, DiagnosticSeverity, NumberOrString};

    /// An analysis, with the diagnostics published on the document.
    struct Published {
        diagnostics: Vec<Diagnostic>,
        file: SourceFile,
        parse: mesh_parser::Parse,
        typeck: TypeckResult,
    }

    fn published(uri: &str, source: &str, open_documents: &[(String, String)]) -> Published {
        let result = analyze_document(uri, source, open_documents);
        Published {
            diagnostics: result.lsp_diagnostics(&Url::parse(uri).unwrap()),
            file: result.file,
            parse: result.parse,
            typeck: result.typeck,
        }
    }

    fn published_on(open_path: &Path, source: &str, target_path: &Path) -> Vec<Diagnostic> {
        let result = analyze_document(&file_uri(open_path), source, &[]);
        let uri_for = |path: &Path| Url::from_file_path(path).ok();
        let target_uri = Url::from_file_path(target_path.canonicalize().unwrap()).unwrap();
        crate::diagnostics::by_uri(&result.diagnostics, &result.file, &uri_for)
            .remove(&target_uri)
            .unwrap_or_default()
            .into_iter()
            .map(|diagnostic| diagnostic.lsp)
            .collect()
    }

    fn file(text: &str) -> SourceFile {
        SourceFile::new("", text)
    }

    fn package_manifest(name: &str) -> String {
        format!(
            "[package]\nname = \"{}\"\nversion = \"1.0.0\"\n\n[dependencies]\n",
            name
        )
    }

    fn file_uri(path: &std::path::Path) -> String {
        Url::from_file_path(path)
            .expect("path should convert to file URI")
            .to_string()
    }

    fn entrypoint_manifest(name: &str, entrypoint: &str) -> String {
        format!(
            "[package]\nname = \"{name}\"\nversion = \"1.0.0\"\nentrypoint = \"{entrypoint}\"\n\n[dependencies]\n"
        )
    }

    fn write_mesh_project(
        manifest: Option<&str>,
        files: &[(&str, &str)],
        open_relative_path: &str,
    ) -> (tempfile::TempDir, PathBuf, PathBuf, String) {
        let tmp = tempfile::tempdir().unwrap();
        let project_dir = tmp.path().join("project");
        std::fs::create_dir_all(&project_dir).unwrap();

        if let Some(manifest) = manifest {
            std::fs::write(project_dir.join("mesh.toml"), manifest).unwrap();
        }

        for (relative_path, contents) in files {
            let full_path = project_dir.join(relative_path);
            if let Some(parent) = full_path.parent() {
                std::fs::create_dir_all(parent).unwrap();
            }
            std::fs::write(&full_path, contents).unwrap();
        }

        let open_path = project_dir.join(open_relative_path);
        let source = std::fs::read_to_string(&open_path).unwrap();
        (tmp, project_dir, open_path, source)
    }

    fn diagnostic_messages(result: &Published) -> Vec<&str> {
        result
            .diagnostics
            .iter()
            .map(|diag| diag.message.as_str())
            .collect()
    }

    fn entry_module(
        graph: &mesh_common::module_graph::ModuleGraph,
    ) -> &mesh_common::module_graph::ModuleInfo {
        graph
            .modules
            .iter()
            .find(|module| module.is_entry)
            .expect("project graph should contain an entry module")
    }

    fn source_declared_work_project_main_source() -> &'static str {
        "fn main() do\n  nil\nend\n"
    }

    fn source_declared_public_work_source() -> &'static str {
        "@cluster pub fn handle_submit(payload :: String) -> String do\n  payload\nend\n\n@cluster(3) pub fn handle_retry(payload :: String) -> String do\n  payload\nend\n"
    }

    fn source_declared_private_work_source() -> &'static str {
        "@cluster fn hidden_submit(payload :: String) -> String do\n  payload\nend\n"
    }

    fn removed_clustered_work_source() -> &'static str {
        "clustered(work) pub fn handle_submit(payload :: String) -> String do\n  payload\nend\n"
    }

    fn removed_cluster_manifest(name: &str) -> String {
        format!(
            "{}\n[cluster]\nenabled = true\ndeclarations = [\n  {{ kind = \"work\", target = \"Work.handle_submit\" }},\n]\n",
            package_manifest(name)
        )
    }

    fn write_source_declared_work_project(
        manifest: &str,
        work_source: &str,
    ) -> (tempfile::TempDir, PathBuf, String) {
        let tmp = tempfile::tempdir().unwrap();
        let project_dir = tmp.path().join("project");
        let work_path = project_dir.join("work.mpl");
        std::fs::create_dir_all(&project_dir).unwrap();
        std::fs::write(project_dir.join("mesh.toml"), manifest).unwrap();
        std::fs::write(
            project_dir.join("main.mpl"),
            source_declared_work_project_main_source(),
        )
        .unwrap();
        std::fs::write(&work_path, work_source).unwrap();
        (tmp, work_path, work_source.to_string())
    }

    fn clustered_route_wrapper_main_source() -> &'static str {
        "from Api.Todos import handle_list_todos\n\npub fn handle_local(req :: Request) -> Response do\n  HTTP.response(200, \"ok\")\nend\n\nfn build() do\n  let router = HTTP.router()\n  let router = HTTP.on_get(router, \"/local\", HTTP.clustered(handle_local))\n  router |> HTTP.on_get(\"/todos\", HTTP.clustered(handle_list_todos))\nend\n\nfn main() do\n  let _ = build()\n  nil\nend\n"
    }

    fn clustered_route_wrapper_todos_source() -> &'static str {
        "pub fn handle_list_todos(req :: Request) -> Response do\n  HTTP.response(200, \"todos\")\nend\n\nfn hidden_todos(req :: Request) -> Response do\n  HTTP.response(200, \"hidden\")\nend\n"
    }

    fn write_clustered_route_wrapper_project() -> (tempfile::TempDir, PathBuf, String) {
        let tmp = tempfile::tempdir().unwrap();
        let project_dir = tmp.path().join("project");
        let main_path = project_dir.join("main.mpl");
        std::fs::create_dir_all(project_dir.join("api")).unwrap();
        std::fs::write(
            project_dir.join("mesh.toml"),
            package_manifest("clustered-routes"),
        )
        .unwrap();
        std::fs::write(&main_path, clustered_route_wrapper_main_source()).unwrap();
        std::fs::write(
            project_dir.join("api/todos.mpl"),
            clustered_route_wrapper_todos_source(),
        )
        .unwrap();
        (
            tmp,
            main_path,
            clustered_route_wrapper_main_source().to_string(),
        )
    }

    fn assert_decorator_anchored_range(diag: &Diagnostic) {
        assert_eq!(diag.range.start, Position::new(0, 0));
        assert!(
            diag.range.end.line > diag.range.start.line
                || diag.range.end.character > diag.range.start.character,
            "expected clustered diagnostic to cover a non-empty decorator span, got {:?}",
            diag.range
        );
    }

    // ── Entrypoint-aware project analysis ────────────────────────────────

    #[test]
    fn find_project_root_uses_manifest_ancestor() {
        let manifest = entrypoint_manifest("manifest-root", "app.mpl");
        let (_tmp, project_dir, open_path, _source) = write_mesh_project(
            Some(&manifest),
            &[
                ("app.mpl", "fn main() do\n  0\nend\n"),
                ("nested/main.mpl", "fn main() do\n  1\nend\n"),
                (
                    "nested/support.mpl",
                    "pub fn label() -> String do\n  \"nested\"\nend\n",
                ),
            ],
            "nested/support.mpl",
        );

        assert_eq!(find_project_root(&open_path), Some(project_dir));
    }

    /// A document not saved yet cannot be canonicalized; the project it is
    /// under is still its project, even through a symlink.
    #[cfg(unix)]
    #[test]
    fn unsaved_documents_under_a_symlink_belong_to_their_project() {
        let (tmp, project_dir, _open_path, _source) = write_mesh_project(
            Some(&package_manifest("linked")),
            &[("main.mpl", "fn main() do\n  1\nend\n")],
            "main.mpl",
        );
        let link = tmp.path().join("link");
        std::os::unix::fs::symlink(&project_dir, &link).unwrap();

        let result = published(&file_uri(&link.join("draft.mpl")), "fn draft() = 1\n", &[]);
        assert!(
            diagnostic_messages(&result)[0].contains("was not discovered under project root"),
            "{:?}",
            diagnostic_messages(&result)
        );
    }

    #[test]
    fn override_only_project_marks_nested_entry_executable_and_analyzes_cleanly() {
        let manifest = entrypoint_manifest("override-only", "lib/start.mpl");
        let (_tmp, project_dir, open_path, source) = write_mesh_project(
            Some(&manifest),
            &[
                (
                    "lib/start.mpl",
                    "from Lib.Support import label\n\nfn main() do\n  println(label())\nend\n",
                ),
                (
                    "lib/support.mpl",
                    "pub fn label() -> String do\n  \"nested-support\"\nend\n",
                ),
            ],
            "lib/start.mpl",
        );

        let manifest = Manifest::from_file(&project_dir.join("mesh.toml")).unwrap();
        let entry_relative_path = resolve_entrypoint(&project_dir, Some(&manifest)).unwrap();
        let project = build_project(
            &project_dir,
            &entry_relative_path,
            &[],
            false,
            &mesh_pkg::project::read_file,
        )
        .unwrap();
        let entry = entry_module(&project.graph);

        assert_eq!(entry_relative_path, PathBuf::from("lib/start.mpl"));
        assert_eq!(entry.path, PathBuf::from("lib/start.mpl"));
        assert_eq!(entry.name, "Lib.Start");
        assert_eq!(
            project
                .graph
                .modules
                .iter()
                .filter(|module| module.is_entry)
                .count(),
            1
        );

        let result = published(&file_uri(&open_path), &source, &[]);
        let messages = diagnostic_messages(&result);
        assert!(
            messages.is_empty(),
            "override-only project should analyze cleanly without a root main.mpl, got: {:?}",
            messages
        );
    }

    #[test]
    fn override_precedence_keeps_root_main_path_derived_but_not_executable() {
        let manifest = entrypoint_manifest("override-precedence", "lib/start.mpl");
        let (_tmp, project_dir, open_path, source) = write_mesh_project(
            Some(&manifest),
            &[
                ("main.mpl", "fn main() do\n  0\nend\n"),
                (
                    "lib/start.mpl",
                    "from App import label\n\nfn main() do\n  println(label())\nend\n",
                ),
                (
                    "app.mpl",
                    "pub fn label() -> String do\n  \"override-app\"\nend\n",
                ),
            ],
            "lib/start.mpl",
        );

        let manifest = Manifest::from_file(&project_dir.join("mesh.toml")).unwrap();
        let entry_relative_path = resolve_entrypoint(&project_dir, Some(&manifest)).unwrap();
        let project = build_project(
            &project_dir,
            &entry_relative_path,
            &[],
            false,
            &mesh_pkg::project::read_file,
        )
        .unwrap();
        let entry = entry_module(&project.graph);
        let root_main = project
            .graph
            .modules
            .iter()
            .find(|module| module.path == Path::new(DEFAULT_ENTRYPOINT))
            .expect("root main.mpl should still be discovered");

        assert_eq!(entry.path, PathBuf::from("lib/start.mpl"));
        assert_eq!(entry.name, "Lib.Start");
        assert_eq!(
            project
                .graph
                .modules
                .iter()
                .filter(|module| module.is_entry)
                .count(),
            1
        );
        assert_eq!(root_main.name, "Main");
        assert!(
            !root_main.is_entry,
            "root main.mpl should not stay executable"
        );

        let result = published(&file_uri(&open_path), &source, &[]);
        let messages = diagnostic_messages(&result);
        assert!(
            messages.is_empty(),
            "override-precedence project should analyze cleanly, got: {:?}",
            messages
        );
    }

    #[test]
    fn missing_configured_entry_reports_project_diagnostic() {
        let manifest = entrypoint_manifest("broken-entry", "lib/start.mpl");
        let (_tmp, project_dir, open_path, source) = write_mesh_project(
            Some(&manifest),
            &[(
                "app.mpl",
                "pub fn label() -> String do\n  \"still-clean-alone\"\nend\n",
            )],
            "app.mpl",
        );

        let diagnostics = published_on(&open_path, &source, &project_dir.join("mesh.toml"));
        let [diagnostic] = diagnostics.as_slice() else {
            panic!("expected one manifest diagnostic, got {diagnostics:?}");
        };
        assert_eq!(
            diagnostic.code,
            Some(NumberOrString::String("M0003".into()))
        );
        assert!(diagnostic.message.contains("Entrypoint 'lib/start.mpl'"));
        assert_eq!(diagnostic.range.start, Position::new(0, 0));
    }

    #[test]
    fn invalid_manifest_entrypoint_reports_project_diagnostic() {
        let manifest = entrypoint_manifest("escaping-entry", "../escape.mpl");
        let (_tmp, project_dir, open_path, source) = write_mesh_project(
            Some(&manifest),
            &[(
                "lib/support.mpl",
                "pub fn label() -> String do\n  \"still-clean-alone\"\nend\n",
            )],
            "lib/support.mpl",
        );

        let diagnostics = published_on(&open_path, &source, &project_dir.join("mesh.toml"));
        let [diagnostic] = diagnostics.as_slice() else {
            panic!("expected one manifest diagnostic, got {diagnostics:?}");
        };
        assert_eq!(
            diagnostic.code,
            Some(NumberOrString::String("M0002".into()))
        );
        assert!(diagnostic.message.contains("stay within the project root"));
        assert_eq!(diagnostic.range.start, Position::new(3, 13));
    }

    // ── Clustered cutover contract ────────────────────────────────────

    #[test]
    fn source_decorated_work_still_analyzes_without_diagnostics() {
        let (_tmp, work_path, source) = write_source_declared_work_project(
            &package_manifest("clustered-source-proof"),
            source_declared_public_work_source(),
        );

        let result = published(&file_uri(&work_path), &source, &[]);
        let messages = result
            .diagnostics
            .iter()
            .map(|diag| diag.message.as_str())
            .collect::<Vec<_>>();

        assert!(
            messages.is_empty(),
            "expected clean diagnostics for valid source-decorated work, got: {:?}",
            messages
        );
    }

    #[test]
    fn removed_manifest_cluster_section_reports_project_diagnostic() {
        let (_tmp, work_path, source) = write_source_declared_work_project(
            &removed_cluster_manifest("clustered-source-proof"),
            source_declared_public_work_source(),
        );

        let diagnostics = published_on(&work_path, &source, &work_path.with_file_name("mesh.toml"));
        let [diagnostic] = diagnostics.as_slice() else {
            panic!("expected one manifest diagnostic, got {diagnostics:?}");
        };
        assert_eq!(
            diagnostic.code,
            Some(NumberOrString::String("M0002".into()))
        );
        assert!(diagnostic
            .message
            .contains("`[cluster]` manifest sections are no longer supported"));
        assert_eq!(diagnostic.range.start, Position::new(6, 0));
    }

    #[test]
    fn removed_clustered_work_reports_parse_diagnostic_at_source_range() {
        let (_tmp, work_path, source) = write_source_declared_work_project(
            &package_manifest("clustered-source-proof"),
            removed_clustered_work_source(),
        );

        let result = published(&file_uri(&work_path), &source, &[]);
        let diag = result
            .diagnostics
            .iter()
            .find(|diag| {
                diag.message
                    .contains("`clustered(work)` declarations are not supported")
            })
            .unwrap_or_else(|| {
                panic!(
                    "expected removed clustered(work) diagnostic, got: {:?}",
                    result
                        .diagnostics
                        .iter()
                        .map(|diag| (&diag.message, diag.range))
                        .collect::<Vec<_>>()
                )
            });

        assert_eq!(diag.range.start.line, 0);
        assert!(
            diag.range.end.line > diag.range.start.line
                || diag.range.end.character > diag.range.start.character,
            "expected non-empty removed-syntax source range, got {:?}",
            diag.range
        );
    }

    #[test]
    fn source_decorated_work_analyzes_without_diagnostics() {
        let (_tmp, work_path, source) = write_source_declared_work_project(
            &package_manifest("clustered-source-proof"),
            source_declared_public_work_source(),
        );

        let result = published(&file_uri(&work_path), &source, &[]);
        let messages = result
            .diagnostics
            .iter()
            .map(|diag| diag.message.as_str())
            .collect::<Vec<_>>();

        assert!(
            messages.is_empty(),
            "expected clean diagnostics for valid source-decorated work, got: {:?}",
            messages
        );
    }

    #[test]
    fn private_source_decorator_reports_declaration_range() {
        let (_tmp, work_path, source) = write_source_declared_work_project(
            &package_manifest("clustered-source-proof"),
            source_declared_private_work_source(),
        );

        let result = published(&file_uri(&work_path), &source, &[]);
        let diag = result
            .diagnostics
            .iter()
            .find(|diag| {
                diag.message.contains("private function")
                    && diag.message.contains("Work.hidden_submit")
                    && diag.message.contains("source `@cluster` decorator")
            })
            .unwrap_or_else(|| {
                panic!(
                    "expected private decorated work diagnostic, got: {:?}",
                    result
                        .diagnostics
                        .iter()
                        .map(|diag| (&diag.message, diag.range))
                        .collect::<Vec<_>>()
                )
            });

        assert_decorator_anchored_range(diag);
    }

    #[test]
    fn manifest_source_duplicate_reports_declaration_range() {
        let (_tmp, work_path, source) = write_source_declared_work_project(
            &removed_cluster_manifest("clustered-source-proof"),
            source_declared_public_work_source(),
        );

        let diagnostics = published_on(&work_path, &source, &work_path.with_file_name("mesh.toml"));
        let [diagnostic] = diagnostics.as_slice() else {
            panic!("expected one manifest diagnostic, got {diagnostics:?}");
        };
        assert_eq!(
            diagnostic.code,
            Some(NumberOrString::String("M0002".into()))
        );
        assert!(diagnostic
            .message
            .contains("`[cluster]` manifest sections are no longer supported"));
        assert_eq!(diagnostic.range.start, Position::new(6, 0));
    }

    // ── The editor sees the program meshc builds ─────────────────────────

    /// A module that implements another's `pub interface` without importing
    /// it is checked after that module, as meshc orders them; the editor
    /// checked `App` first and reported `Area` unknown.
    #[test]
    fn a_module_implementing_an_unimported_interface_analyzes_cleanly() {
        let (_tmp, _project_dir, open_path, source) = write_mesh_project(
            Some(&package_manifest("shapes")),
            &[
                ("shapes.mpl", "pub interface Area do\n  fn area(self) -> Int\nend\n"),
                (
                    "app.mpl",
                    "pub struct Square do\n  side :: Int\nend\n\nimpl Area for Square do\n  fn area(self) -> Int do\n    self.side * self.side\n  end\nend\n",
                ),
                ("main.mpl", "fn main() do\n  println(\"ok\")\nend\n"),
            ],
            "app.mpl",
        );
        let result = published(&file_uri(&open_path), &source, &[]);
        assert!(
            result.diagnostics.is_empty(),
            "{:?}",
            diagnostic_messages(&result)
        );
    }

    /// A file outside any project is analyzed as meshc builds a directory
    /// holding only it: its module blocks are modules (the editor reported
    /// `import Geo` unknown), and a `let` outside a function is an error.
    #[test]
    fn a_document_outside_a_project_is_built_like_one() {
        let source = "import Geo\n\nmodule Geo do\n  pub fn area(w :: Int, h :: Int) -> Int do\n    w * h\n  end\nend\n\nfn main() do\n  println(\"${Geo.area(1, 2)}\")\nend\n";
        let result = published("file:///nowhere/main.mpl", source, &[]);
        assert!(
            result.diagnostics.is_empty(),
            "{:?}",
            diagnostic_messages(&result)
        );
        let result = published("file:///nowhere/main.mpl", "let x = 1\n", &[]);
        assert_eq!(
            diagnostic_messages(&result),
            ["`let x` outside a function is not supported\nhelp: move it into the function that uses it, or make it a function: `fn x() do ... end`"]
        );
    }

    /// A document that cannot be analyzed as a module of its project says
    /// why, first thing.
    #[test]
    fn documents_that_cannot_be_analyzed_as_modules_say_why() {
        // A standalone file whose module blocks conflict.
        let result = published(
            "file:///nowhere/main.mpl",
            "module A do\nend\n\nmodule A do\nend\n",
            &[],
        );
        assert!(
            diagnostic_messages(&result)[0].contains("conflicts"),
            "{:?}",
            diagnostic_messages(&result)
        );
        // An editor buffer that is not a file is analyzed on its own.
        let result = published("untitled:Untitled-1", "fn main() do\n  1\nend\n", &[]);
        assert!(
            result.diagnostics.is_empty(),
            "{:?}",
            diagnostic_messages(&result)
        );

        for (files, open, target, code, expected) in [
            (
                vec![
                    ("a.mpl", "import B\n\npub fn a() = 1\n"),
                    ("b.mpl", "import A\n\npub fn b() = 2\n"),
                    ("main.mpl", "fn main() do\n  1\nend\n"),
                ],
                "b.mpl",
                "a.mpl",
                "M0201",
                "Circular dependency",
            ),
            (
                vec![
                    ("main.mpl", "fn main() do\n  1\nend\n"),
                    (".scratch/note.mpl", "fn note() = 1\n"),
                ],
                ".scratch/note.mpl",
                ".scratch/note.mpl",
                "M0202",
                "was not discovered",
            ),
            (
                vec![
                    ("main.mpl", "fn main() do\n  1\nend\n"),
                    (
                        "math.test.mpl",
                        "describe(\"math\") do\n  teardown do\n    1\n  end\n  teardown do\n    2\n  end\nend\n",
                    ),
                ],
                "math.test.mpl",
                "math.test.mpl",
                "P0401",
                "one `teardown`",
            ),
            (
                vec![
                    ("main.mpl", "fn main() do\n  1\nend\n"),
                    ("mesh.lock", "not a lockfile"),
                ],
                "main.mpl",
                "mesh.lock",
                "M0101",
                "Failed to parse lockfile",
            ),
        ] {
            let (_tmp, project_dir, open_path, source) =
                write_mesh_project(Some(&package_manifest("failing")), &files, open);
            let diagnostics = published_on(&open_path, &source, &project_dir.join(target));
            let [diagnostic] = diagnostics.as_slice() else {
                panic!("expected one {code} diagnostic in {target}, got {diagnostics:?}");
            };
            assert!(diagnostic.message.contains(expected), "{diagnostic:?}");
            assert_eq!(diagnostic.code, Some(NumberOrString::String(code.into())));
            if code == "P0401" {
                assert_eq!(diagnostic.range.start, Position::new(4, 2));
                assert_eq!(diagnostic.range.end, Position::new(4, 10));
            }
            if code == "M0201" {
                let labels = diagnostic.related_information.as_ref().unwrap();
                assert_eq!(labels.len(), 2);
                for (label, file) in labels.iter().zip(["a.mpl", "b.mpl"]) {
                    let path = project_dir.join(file).canonicalize().unwrap();
                    assert_eq!(label.location.uri, Url::from_file_path(path).unwrap());
                    assert_eq!(label.location.range, Range::new(Position::new(0, 0), Position::new(0, 8)));
                }
            }
        }
    }

    /// A test file is linted as written, as `meshc lint` lints it: a test
    /// in a `describe` starts its own nesting, though the program generated
    /// from it nests the test inside an `if` and a closure.
    #[test]
    fn a_test_file_is_linted_as_written() {
        let test = "describe(\"math\") do\n  test(\"deep\") do\n    let ready = true\n    if ready do\n      if ready do\n        if ready do\n          if ready == true do\n            assert(true)\n          end\n        end\n      end\n    end\n  end\nend\n";
        let (_tmp, _project_dir, open_path, source) = write_mesh_project(
            Some(&package_manifest("lint")),
            &[("main.mpl", "fn main() do\nend\n"), ("math.test.mpl", test)],
            "math.test.mpl",
        );
        let result = published(&file_uri(&open_path), &source, &[]);
        let found: Vec<_> = result
            .diagnostics
            .iter()
            .map(|diagnostic| (diagnostic.code.clone(), diagnostic.range))
            .collect();
        assert_eq!(
            found,
            [(
                Some(NumberOrString::String("L0004".into())),
                Range::new(Position::new(6, 13), Position::new(6, 26))
            )],
            "{:?}",
            diagnostic_messages(&result)
        );
    }

    #[test]
    fn warnings_are_reported_as_warnings() {
        let result = published(
            "file:///nowhere/main.mpl",
            "fn main() do\n  case 1 do\n    _ -> 1\n    2 -> 2\n  end\nend\n",
            &[],
        );
        assert!(
            result
                .diagnostics
                .iter()
                .any(|diagnostic| diagnostic.severity == Some(DiagnosticSeverity::WARNING)),
            "{:?}",
            diagnostic_messages(&result)
        );
    }

    /// An open document is read as the editor holds it, not as it was saved.
    #[test]
    fn open_documents_are_read_in_place_of_their_files() {
        let (_tmp, project_dir, open_path, source) = write_mesh_project(
            Some(&package_manifest("overlays")),
            &[
                (
                    "main.mpl",
                    "from Util import helper\n\nfn main() do\n  println(helper())\nend\n",
                ),
                ("util.mpl", "pub fn other() = 1\n"),
            ],
            "main.mpl",
        );
        let saved = published(&file_uri(&open_path), &source, &[]);
        assert!(!saved.diagnostics.is_empty());
        let open = [(
            file_uri(&project_dir.join("util.mpl")),
            "pub fn helper() -> String do\n  \"h\"\nend\n".to_string(),
        )];
        let edited = published(&file_uri(&open_path), &source, &open);
        assert!(
            edited.diagnostics.is_empty(),
            "{:?}",
            diagnostic_messages(&edited)
        );
    }

    /// meshc refuses a `let` outside a function; the editor said nothing.
    #[test]
    fn a_top_level_let_is_reported_in_a_project() {
        let (_tmp, _project_dir, open_path, source) = write_mesh_project(
            Some(&package_manifest("lets")),
            &[(
                "main.mpl",
                "let limit = 3\n\nfn main() do\n  println(\"${limit}\")\nend\n",
            )],
            "main.mpl",
        );
        let result = published(&file_uri(&open_path), &source, &[]);
        assert!(
            diagnostic_messages(&result)
                .iter()
                .any(|message| message.contains("`let limit` outside a function")),
            "{:?}",
            diagnostic_messages(&result)
        );
    }

    // ── Scoped installed package regressions ────────────────────────────

    #[test]
    fn scoped_installed_package_analyzes_cleanly() {
        let tmp = tempfile::tempdir().unwrap();
        let project_dir = tmp.path().join("consumer");
        let package_root = project_dir.join(".mesh/packages/acme/greeter@1.0.0");
        let main_path = project_dir.join("main.mpl");

        std::fs::create_dir_all(package_root.join("support")).unwrap();
        std::fs::write(project_dir.join("mesh.toml"), package_manifest("consumer")).unwrap();
        std::fs::write(
            &main_path,
            "from Support.Message import message\n\nfn main() do\n  println(message())\nend\n",
        )
        .unwrap();
        std::fs::write(
            package_root.join("mesh.toml"),
            package_manifest("acme/greeter"),
        )
        .unwrap();
        std::fs::write(package_root.join("main.mpl"), "fn main() do\n  0\nend\n").unwrap();
        std::fs::write(
            package_root.join("support/message.mpl"),
            "pub fn message() -> String do\n  \"hello from package\"\nend\n",
        )
        .unwrap();

        let source = std::fs::read_to_string(&main_path).unwrap();
        let result = published(&file_uri(&main_path), &source, &[]);
        let messages = result
            .diagnostics
            .iter()
            .map(|diag| diag.message.as_str())
            .collect::<Vec<_>>();

        assert!(
            messages.is_empty(),
            "scoped installed packages should analyze without diagnostics, got: {:?}",
            messages
        );
    }

    #[test]
    fn scoped_installed_package_flat_layout_analyzes_cleanly() {
        let tmp = tempfile::tempdir().unwrap();
        let project_dir = tmp.path().join("consumer");
        let package_root = project_dir.join(".mesh/packages/greeter@1.0.0");
        let main_path = project_dir.join("main.mpl");

        std::fs::create_dir_all(&package_root).unwrap();
        std::fs::write(project_dir.join("mesh.toml"), package_manifest("consumer")).unwrap();
        std::fs::write(
            &main_path,
            "from Greeting import message\n\nfn main() do\n  println(message())\nend\n",
        )
        .unwrap();
        std::fs::write(package_root.join("mesh.toml"), package_manifest("greeter")).unwrap();
        std::fs::write(
            package_root.join("greeting.mpl"),
            "pub fn message() -> String do\n  \"hello from flat package\"\nend\n",
        )
        .unwrap();

        let source = std::fs::read_to_string(&main_path).unwrap();
        let result = published(&file_uri(&main_path), &source, &[]);
        let messages = result
            .diagnostics
            .iter()
            .map(|diag| diag.message.as_str())
            .collect::<Vec<_>>();

        assert!(
            messages.is_empty(),
            "flat installed packages should analyze without diagnostics, got: {:?}",
            messages
        );
    }

    #[test]
    fn clustered_route_wrapper_project_keeps_imported_origin_metadata() {
        let (_tmp, main_path, source) = write_clustered_route_wrapper_project();

        let result = published(&file_uri(&main_path), &source, &[]);
        let messages = result
            .diagnostics
            .iter()
            .map(|diag| diag.message.as_str())
            .collect::<Vec<_>>();

        assert!(
            messages.is_empty(),
            "expected clean diagnostics for valid clustered route wrappers, got: {:?}",
            messages
        );

        let metadata = result
            .typeck
            .clustered_route_wrappers
            .values()
            .find(|metadata| metadata.runtime_name == "Api.Todos.handle_list_todos")
            .unwrap_or_else(|| {
                panic!(
                    "expected imported clustered route metadata, got: {:?}",
                    result
                        .typeck
                        .clustered_route_wrappers
                        .values()
                        .map(|metadata| {
                            (
                                metadata.runtime_name.as_str(),
                                metadata.defining_module.as_deref(),
                                metadata.replication_count.value,
                            )
                        })
                        .collect::<Vec<_>>()
                )
            });

        assert_eq!(metadata.defining_module.as_deref(), Some("Api.Todos"));
        assert_eq!(metadata.replication_count.value, 2);
    }

    #[test]
    fn clustered_route_wrapper_reports_wrapper_range_in_lsp() {
        let source = "pub fn handle(req :: Request) -> Response do\n  HTTP.response(200, \"ok\")\nend\n\nfn build() do\n  let wrapped = HTTP.clustered(handle)\n  wrapped\nend\n";
        let result = published("file:///test.mpl", source, &[]);
        let diag = result
            .diagnostics
            .iter()
            .find(|diag| diag.message.contains("HTTP.clustered"))
            .unwrap_or_else(|| {
                panic!(
                    "expected clustered-route diagnostic, got: {:?}",
                    result
                        .diagnostics
                        .iter()
                        .map(|diag| (&diag.message, diag.range))
                        .collect::<Vec<_>>()
                )
            });

        let wrapper_start = source
            .find("HTTP.clustered")
            .expect("wrapper text should exist");
        assert_eq!(
            diag.range.start,
            offset_to_position(&file(source), wrapper_start)
        );
        assert!(
            diag.range.end.line > diag.range.start.line
                || diag.range.end.character > diag.range.start.character,
            "expected wrapper diagnostic to cover a non-empty range, got {:?}",
            diag.range
        );
    }

    // ── Diagnostic Tests ──────────────────────────────────────────────────

    #[test]
    fn analyze_valid_source_no_diagnostics() {
        let source = "fn main() do\n  let x = 42\n  x\nend\n";
        let result = published("file:///test.mpl", source, &[]);
        assert!(
            result.diagnostics.is_empty(),
            "Valid source should produce no diagnostics, got: {:?}",
            result
                .diagnostics
                .iter()
                .map(|d| &d.message)
                .collect::<Vec<_>>()
        );
    }

    #[test]
    fn analyze_valid_function_no_diagnostics() {
        let source = "fn add(a, b) do\na + b\nend";
        let result = published("file:///test.mpl", source, &[]);
        assert!(
            result.diagnostics.is_empty(),
            "Valid function should produce no diagnostics, got: {:?}",
            result
                .diagnostics
                .iter()
                .map(|d| &d.message)
                .collect::<Vec<_>>()
        );
    }

    #[test]
    fn analyze_type_error_produces_diagnostic() {
        // Using an undefined variable should produce a type error diagnostic.
        let source = "let x = undefined_var";
        let result = published("file:///test.mpl", source, &[]);
        assert!(
            !result.diagnostics.is_empty(),
            "Type error should produce at least one diagnostic"
        );
        let diag = &result.diagnostics[0];
        assert_eq!(diag.severity, Some(DiagnosticSeverity::ERROR));
        assert_eq!(diag.source.as_deref(), Some("mesh"));
    }

    #[test]
    fn analyze_type_error_has_range() {
        // The diagnostic range should point to the error location.
        let source = "let x = undefined_var";
        let result = published("file:///test.mpl", source, &[]);
        assert!(!result.diagnostics.is_empty());
        let diag = &result.diagnostics[0];
        // The error is for "undefined_var" which is on line 0.
        assert_eq!(diag.range.start.line, 0);
    }

    #[test]
    fn analyze_resource_violation_produces_diagnostic() {
        let source = "fn misuse(secret :: SecretBytes) do\n  let moved = secret\n  secret\nend";
        let result = published("file:///test.mpl", source, &[]);

        assert!(result.diagnostics.iter().any(|diagnostic| {
            diagnostic.severity == Some(DiagnosticSeverity::ERROR)
                && diagnostic
                    .message
                    .contains("resource `secret` was used after it moved")
        }));
    }

    /// An impl's errors are shown at the impl: a duplicate impl had no place
    /// in the source and was not shown at all.
    #[test]
    fn analyze_impl_errors_are_shown_at_the_impl() {
        let source = "interface Sized do\n  fn size(self) -> Int\nend\n\
                      impl Sized for Int do\n  fn size(self) -> Int do\n    1\n  end\nend\n\
                      impl Sized for Int do\n  fn size(self) -> Int do\n    2\n  end\nend\n";
        let result = published("file:///test.mpl", source, &[]);
        let duplicate = result
            .diagnostics
            .iter()
            .find(|diagnostic| diagnostic.message.starts_with("duplicate impl"))
            .expect("the duplicate impl is shown");
        assert_eq!(duplicate.range.start, Position::new(8, 0));
        assert_eq!(duplicate.range.end, Position::new(8, 21));
    }

    #[test]
    fn analyze_multiple_errors_all_reported() {
        // Two undefined variables should produce at least two diagnostics.
        let source = "let x = undef1\nlet y = undef2";
        let result = published("file:///test.mpl", source, &[]);
        assert!(
            result.diagnostics.len() >= 2,
            "Expected at least 2 diagnostics, got {}",
            result.diagnostics.len()
        );
    }

    #[test]
    fn analyze_parse_error_produces_diagnostic() {
        // A parse error (incomplete expression) should produce a diagnostic.
        // Note: `fn do end` is now valid syntax (no-params closure, Phase 12-01).
        // Use a clearly invalid expression instead.
        let source = "let x = + +";
        let result = published("file:///test.mpl", source, &[]);
        assert!(
            !result.diagnostics.is_empty(),
            "Parse error should produce at least one diagnostic"
        );
        let diag = &result.diagnostics[0];
        assert_eq!(diag.severity, Some(DiagnosticSeverity::ERROR));
    }

    // ── Hover Tests ───────────────────────────────────────────────────────

    #[test]
    fn hover_names_a_generic_type_variables() {
        let source = "fn pick(x, y) do\n  x\nend\n";
        let result = published("file:///test.mpl", source, &[]);
        let ty = type_at_position(
            &result.file,
            &result.typeck,
            &Position {
                line: 1,
                character: 2,
            },
        );
        assert_eq!(ty.as_deref(), Some("a"));
        let whole = type_at_position(
            &result.file,
            &result.typeck,
            &Position {
                line: 0,
                character: 4,
            },
        )
        .unwrap();
        assert!(!whole.contains('?'), "{whole}");
    }

    #[test]
    fn hover_integer_literal() {
        let source = "fn main() do\n  let x = 42\n  x\nend\n";
        let result = published("file:///test.mpl", source, &[]);
        let ty = type_at_position(
            &result.file,
            &result.typeck,
            &Position {
                line: 1,
                character: 11,
            },
        );
        assert_eq!(ty.as_deref(), Some("Int"));
    }

    #[test]
    fn hover_over_empty_space_returns_none() {
        // Hovering over whitespace or at end of file should return None.
        let source = "let x = 42";
        let result = published("file:///test.mpl", source, &[]);
        // Position past end of source.
        let ty = type_at_position(
            &result.file,
            &result.typeck,
            &Position {
                line: 5,
                character: 0,
            },
        );
        assert!(ty.is_none(), "Hover past end should return None");
    }

    // ── Go-to-definition Tests ────────────────────────────────────────────

    #[test]
    fn goto_def_function_defined_then_called() {
        let source = "fn greet(name) do\nname\nend\nlet msg = greet(42)";
        let result = published("file:///test.mpl", source, &[]);
        let root = result.parse.syntax();
        // Find the call to "greet" in `greet(42)`.
        let call_offset = source.rfind("greet").unwrap();
        let def = crate::definition::find_definition(&root, call_offset);
        // The fn definition, not the call: "greet" in "fn greet" is at 3.
        assert_eq!(def.map(|range| usize::from(range.start())), Some(3));
    }

    #[test]
    fn goto_def_let_binding_used_later() {
        let source = "let count = 10\nlet doubled = count + count";
        let result = published("file:///test.mpl", source, &[]);
        let root = result.parse.syntax();
        // Find "count" in the second let binding.
        let second_count = source.find("count + count").unwrap();
        let def = crate::definition::find_definition(&root, second_count);
        // "let count" -- "count" starts at offset 4.
        assert_eq!(def.map(|range| usize::from(range.start())), Some(4));
    }

    #[test]
    fn goto_def_variable_shadowing_inner_scope() {
        let source = "fn test() do\nlet x = 1\nfn inner() do\nlet x = 2\nlet y = x\nend\nend";
        let result = published("file:///test.mpl", source, &[]);
        let root = result.parse.syntax();
        let y_binding = source.find("let y = x").unwrap();
        let x_use = y_binding + "let y = ".len();
        let def = crate::definition::find_definition(&root, x_use);
        let inner_x = source.find("let x = 2").unwrap() + "let ".len();
        assert_eq!(
            def.map(|range| usize::from(range.start())),
            Some(inner_x),
            "Should resolve to inner binding, not outer"
        );
    }

    #[test]
    fn goto_def_unknown_identifier_returns_none() {
        let source = "let y = completely_unknown";
        let result = published("file:///test.mpl", source, &[]);
        let root = result.parse.syntax();
        let unknown_offset = source.find("completely_unknown").unwrap();
        let def = crate::definition::find_definition(&root, unknown_offset);
        assert!(def.is_none(), "Unknown identifier should return None");
    }

    #[test]
    fn goto_def_struct_name_resolves() {
        let source = "struct Point do\nx :: Int\nend";
        let result = published("file:///test.mpl", source, &[]);
        let root = result.parse.syntax();
        // Definition search for "Point" at the struct def should find itself.
        let point_offset = source.find("Point").unwrap();
        // "Point" at the definition site is in a NAME node, not NAME_REF,
        // so it won't resolve to anything (it IS the definition).
        let def = crate::definition::find_definition(&root, point_offset);
        // This should return None since the user is clicking on the definition itself.
        assert!(
            def.is_none(),
            "Clicking on definition site should return None"
        );
    }

    // ── Position Conversion Tests ─────────────────────────────────────────

    #[test]
    fn offset_to_position_first_line() {
        let source = "hello world";
        let pos = offset_to_position(&file(source), 0);
        assert_eq!(
            pos,
            Position {
                line: 0,
                character: 0
            }
        );

        let pos = offset_to_position(&file(source), 5);
        assert_eq!(
            pos,
            Position {
                line: 0,
                character: 5
            }
        );
    }

    #[test]
    fn offset_to_position_multiline() {
        let source = "line1\nline2\nline3";
        // 'l' of line2 is at offset 6
        let pos = offset_to_position(&file(source), 6);
        assert_eq!(
            pos,
            Position {
                line: 1,
                character: 0
            }
        );

        // 'l' of line3 is at offset 12
        let pos = offset_to_position(&file(source), 12);
        assert_eq!(
            pos,
            Position {
                line: 2,
                character: 0
            }
        );

        // 'i' of line2 is at offset 7
        let pos = offset_to_position(&file(source), 7);
        assert_eq!(
            pos,
            Position {
                line: 1,
                character: 1
            }
        );
    }

    #[test]
    fn offset_to_position_at_end() {
        let source = "ab\ncd";
        let pos = offset_to_position(&file(source), 5);
        assert_eq!(
            pos,
            Position {
                line: 1,
                character: 2
            }
        );
    }

    #[test]
    fn position_to_offset_single_line() {
        let source = "hello";
        assert_eq!(
            position_to_offset(
                &file(source),
                &Position {
                    line: 0,
                    character: 0
                }
            ),
            Some(0)
        );
        assert_eq!(
            position_to_offset(
                &file(source),
                &Position {
                    line: 0,
                    character: 3
                }
            ),
            Some(3)
        );
        assert_eq!(
            position_to_offset(
                &file(source),
                &Position {
                    line: 0,
                    character: 5
                }
            ),
            Some(5)
        );
    }

    #[test]
    fn position_to_offset_multiline() {
        let source = "abc\ndef\nghi";
        // First char of line 2 (0-indexed) at (1, 0).
        assert_eq!(
            position_to_offset(
                &file(source),
                &Position {
                    line: 1,
                    character: 0
                }
            ),
            Some(4)
        );
        // First char of line 3 at (2, 0).
        assert_eq!(
            position_to_offset(
                &file(source),
                &Position {
                    line: 2,
                    character: 0
                }
            ),
            Some(8)
        );
    }

    #[test]
    fn position_to_offset_stays_on_its_line() {
        // A character past the end of a line counted on into the next lines.
        let source = "ab\ncdef\né𝄞x\n";
        let at = |line, character| position_to_offset(&file(source), &Position { line, character });
        assert_eq!(at(0, 10), Some(2));
        assert_eq!(at(1, 2), Some(5));
        // `é` is one UTF-16 unit, `𝄞` two.
        assert_eq!(at(2, 1), Some(10));
        assert_eq!(at(2, 3), Some(14));
        assert_eq!(at(2, 9), Some(15));
        assert_eq!(at(3, 0), Some(16));
        assert_eq!(at(4, 0), None);
    }

    #[test]
    fn position_to_offset_roundtrip() {
        let source = "hello\nworld\nfoo";
        for offset in 0..source.len() {
            let pos = offset_to_position(&file(source), offset);
            let back = position_to_offset(&file(source), &pos);
            assert_eq!(
                back,
                Some(offset),
                "Roundtrip failed for offset {} (pos {:?})",
                offset,
                pos
            );
        }
    }

    #[test]
    fn position_past_eof_returns_none() {
        let source = "hello";
        let result = position_to_offset(
            &file(source),
            &Position {
                line: 5,
                character: 0,
            },
        );
        assert!(result.is_none(), "Position past EOF should return None");
    }

    #[test]
    fn a_test_file_is_analyzed_as_meshc_test_compiles_it() {
        // It was analyzed as a plain module that was not in the project:
        // `test`, `assert_eq` and its imports were errors in the editor.
        let tmp = tempfile::tempdir().unwrap();
        let project_dir = tmp.path().join("app");
        std::fs::create_dir_all(project_dir.join("tests")).unwrap();
        std::fs::write(project_dir.join("mesh.toml"), package_manifest("app")).unwrap();
        std::fs::write(project_dir.join("main.mpl"), "fn main() do\nend\n").unwrap();
        std::fs::write(
            project_dir.join("greeting.mpl"),
            "pub fn message() -> String do\n  \"hello\"\nend\n",
        )
        .unwrap();
        let test_path = project_dir.join("tests/greeting.test.mpl");
        let source = "from Greeting import message\n\ndescribe(\"greeting\") do\n  setup do\n    let expected = \"hello\"\n  end\n  test(\"says hello\") do\n    assert_eq(message(), expected)\n  end\nend\n";
        std::fs::write(&test_path, source).unwrap();

        let result = published(&file_uri(&test_path), source, &[]);
        assert!(result.diagnostics.is_empty(), "{:?}", result.diagnostics);
        // Hover converts positions against the analyzed program: line 8,
        // `expected`, is a String there too.
        let hover = type_at_position(&result.file, &result.typeck, &Position::new(7, 26));
        assert_eq!(hover.as_deref(), Some("String"));

        // An error is reported where it is in the test file.
        let broken = source.replace(
            "assert_eq(message(), expected)",
            "assert_eq(message() + 1, expected)",
        );
        let result = published(&file_uri(&test_path), &broken, &[]);
        assert_eq!(result.diagnostics.len(), 1, "{:?}", result.diagnostics);
        assert_eq!(result.diagnostics[0].range.start.line, 7);
    }

    #[test]
    fn a_path_dependency_analyzes_cleanly() {
        // The LSP found installed packages only: a module of a path
        // dependency was "module not found" in the editor.
        let tmp = tempfile::tempdir().unwrap();
        let project_dir = tmp.path().join("consumer");
        let library = tmp.path().join("library");
        let main_path = project_dir.join("main.mpl");
        std::fs::create_dir_all(&project_dir).unwrap();
        std::fs::create_dir_all(&library).unwrap();
        std::fs::write(
            project_dir.join("mesh.toml"),
            "[package]\nname = \"consumer\"\nversion = \"1.0.0\"\n\n[dependencies]\nlibrary = { path = \"../library\" }\n",
        )
        .unwrap();
        std::fs::write(library.join("mesh.toml"), package_manifest("library")).unwrap();
        std::fs::write(
            library.join("greeting.mpl"),
            "pub fn message() -> String do\n  \"hello\"\nend\n",
        )
        .unwrap();
        std::fs::write(
            &main_path,
            "from Greeting import message\n\nfn main() do\n  println(message())\nend\n",
        )
        .unwrap();

        let source = std::fs::read_to_string(&main_path).unwrap();
        let result = published(&file_uri(&main_path), &source, &[]);
        assert!(result.diagnostics.is_empty(), "{:?}", result.diagnostics);
    }

    #[test]
    fn a_module_block_is_checked_in_its_file() {
        let tmp = tempfile::tempdir().unwrap();
        let project_dir = tmp.path().join("app");
        let main_path = project_dir.join("main.mpl");
        std::fs::create_dir_all(&project_dir).unwrap();
        std::fs::write(project_dir.join("mesh.toml"), package_manifest("app")).unwrap();
        let source = "import Billing\n\nmodule Billing do\n  pub fn total() -> Int do\n    \"no\" + nope\n  end\nend\n\nfn main() do\n  println(\"${Billing.total()}\")\nend\n";
        std::fs::write(&main_path, source).unwrap();

        let result = published(&file_uri(&main_path), source, &[]);
        let messages: Vec<&str> = result
            .diagnostics
            .iter()
            .map(|diag| diag.message.as_str())
            .collect();
        assert!(
            messages.iter().any(|message| message.contains("nope")),
            "{messages:?}"
        );
        assert!(
            !messages.iter().any(|message| message.contains("Billing")),
            "{messages:?}"
        );
    }
}
