//! Stable embedding boundary for static and dynamic Mesh libraries.
//!
//! Each invocation owns a short-lived runtime process. Only copied response
//! bytes cross the ABI; persistent state belongs in storage or spawned actors.

use std::ffi::c_void;
use std::panic::{catch_unwind, AssertUnwindSafe};
use std::ptr;

use mesh_diagnostics::{Code, Diagnostic};
use parking_lot::{Mutex, RwLock};
use zeroize::Zeroizing;

use crate::actor::{self, stack, ProcessId};
use crate::bytes::{mesh_bytes_new, MeshBytes};
use crate::gc::mesh_rt_init;
use crate::io::{alloc_result, err_result, MeshResult};
use crate::string::MeshString;

pub const MESH_LIBRARY_ABI_VERSION: u32 = 1;
pub const MESH_LIBRARY_OK: i32 = 0;
pub const MESH_LIBRARY_ERR_INVALID_ARGUMENT: i32 = 1;
pub const MESH_LIBRARY_ERR_NOT_INITIALIZED: i32 = 2;
pub const MESH_LIBRARY_ERR_BUSY: i32 = 3;
pub const MESH_LIBRARY_ERR_PANIC: i32 = 4;
pub const MESH_LIBRARY_ERR_HOST_CALLBACK: i32 = 5;
pub const MESH_LIBRARY_ERR_OUTPUT_TOO_LARGE: i32 = 6;
pub const MESH_LIBRARY_ERR_ABI: i32 = 7;
pub const MESH_LIBRARY_ERR_CALLBACK_MISSING: i32 = 8;
pub const MESH_LIBRARY_ERR_APPLICATION: i32 = 9;

// ponytail: one fixed 1 MiB host buffer; add negotiated sizing if mobile payloads exceed it.
const MAX_BOUNDARY_BYTES: usize = 1024 * 1024;

/// A call the host made wrongly, which the runtime refuses. A panic was
/// reported as it was raised, and an `Err` result is the function's
/// answer, so neither is one.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Refusal {
    InvalidArgument,
    NotInitialized,
    Busy,
    OutputTooLarge,
    AbiMismatch,
}

impl Refusal {
    /// The status the call returns.
    fn status(self) -> i32 {
        match self {
            Refusal::InvalidArgument => MESH_LIBRARY_ERR_INVALID_ARGUMENT,
            Refusal::NotInitialized => MESH_LIBRARY_ERR_NOT_INITIALIZED,
            Refusal::Busy => MESH_LIBRARY_ERR_BUSY,
            Refusal::OutputTooLarge => MESH_LIBRARY_ERR_OUTPUT_TOO_LARGE,
            Refusal::AbiMismatch => MESH_LIBRARY_ERR_ABI,
        }
    }

    /// The diagnostic code that explains it.
    fn code(self) -> Code {
        match self {
            Refusal::InvalidArgument => Code::LibraryInvalidArgument,
            Refusal::NotInitialized => Code::LibraryNotInitialized,
            Refusal::Busy => Code::LibraryBusy,
            Refusal::OutputTooLarge => Code::LibraryOutputTooLarge,
            Refusal::AbiMismatch => Code::LibraryAbiMismatch,
        }
    }
}

/// Refuse a call, saying why on stderr, and return its status. The caller
/// holds no lock: a host whose stderr blocks must not stall another call
/// or the shutdown.
fn refused(refusal: Refusal, message: impl Into<String>) -> i32 {
    crate::panic::report(&Diagnostic::new(refusal.code(), message));
    refusal.status()
}

#[repr(C)]
#[derive(Debug, Default)]
pub struct MeshLibraryBytes {
    pub data: *mut u8,
    pub len: u64,
}

#[repr(C)]
pub struct MeshLibraryCallResult {
    pub tag: u8,
    pub _padding: [u8; 7],
    pub value: *mut u8,
}

pub type MeshLibraryEntrypoint =
    unsafe extern "C-unwind" fn(*mut MeshBytes, *mut MeshLibraryCallResult);
pub type MeshLibraryHostCallback = unsafe extern "C" fn(
    context: *mut c_void,
    input: *const u8,
    input_len: u64,
    output: *mut u8,
    output_capacity: u64,
    output_len: *mut u64,
) -> i32;

#[repr(C)]
pub struct MeshLibraryHostCallbacksV1 {
    pub abi_version: u32,
    pub struct_size: u32,
    pub context: *mut c_void,
    pub secure_store_put: Option<MeshLibraryHostCallback>,
    pub secure_store_get: Option<MeshLibraryHostCallback>,
    pub secure_store_delete: Option<MeshLibraryHostCallback>,
    pub push_get_token: Option<MeshLibraryHostCallback>,
    pub background_schedule: Option<MeshLibraryHostCallback>,
    pub network_state: Option<MeshLibraryHostCallback>,
    pub monotonic_clock: Option<MeshLibraryHostCallback>,
    pub wall_clock: Option<MeshLibraryHostCallback>,
    pub log_redacted: Option<MeshLibraryHostCallback>,
}

impl Default for MeshLibraryHostCallbacksV1 {
    fn default() -> Self {
        Self {
            abi_version: MESH_LIBRARY_ABI_VERSION,
            struct_size: std::mem::size_of::<Self>() as u32,
            context: ptr::null_mut(),
            secure_store_put: None,
            secure_store_get: None,
            secure_store_delete: None,
            push_get_token: None,
            background_schedule: None,
            network_state: None,
            monotonic_clock: None,
            wall_clock: None,
            log_redacted: None,
        }
    }
}

#[derive(Clone, Copy)]
struct RegisteredCallbacks {
    context: usize,
    secure_store_put: Option<MeshLibraryHostCallback>,
    secure_store_get: Option<MeshLibraryHostCallback>,
    secure_store_delete: Option<MeshLibraryHostCallback>,
    push_get_token: Option<MeshLibraryHostCallback>,
    background_schedule: Option<MeshLibraryHostCallback>,
    network_state: Option<MeshLibraryHostCallback>,
    monotonic_clock: Option<MeshLibraryHostCallback>,
    wall_clock: Option<MeshLibraryHostCallback>,
    log_redacted: Option<MeshLibraryHostCallback>,
}

impl RegisteredCallbacks {
    fn callback(self, capability: u32) -> Option<MeshLibraryHostCallback> {
        match capability {
            1 => self.secure_store_put,
            2 => self.secure_store_get,
            3 => self.secure_store_delete,
            4 => self.push_get_token,
            5 => self.background_schedule,
            6 => self.network_state,
            7 => self.monotonic_clock,
            8 => self.wall_clock,
            9 => self.log_redacted,
            _ => None,
        }
    }
}

enum Lifecycle {
    New,
    Running(ProcessId),
    Shutdown,
}

static LIFECYCLE: Mutex<Lifecycle> = Mutex::new(Lifecycle::New);
static CALL_LOCK: Mutex<()> = Mutex::new(());
static HOST_CALLBACKS: RwLock<Option<RegisteredCallbacks>> = RwLock::new(None);

struct CallContext {
    pid: ProcessId,
    previous_pid: Option<ProcessId>,
}

impl Drop for CallContext {
    fn drop(&mut self) {
        if let Some(scheduler) = actor::GLOBAL_SCHEDULER.get() {
            scheduler.finalize_host_process(self.pid);
        }
        stack::clear_current_pid();
        if let Some(pid) = self.previous_pid {
            stack::set_current_pid(pid);
        }
    }
}

#[no_mangle]
pub extern "C" fn mesh_library_init() -> i32 {
    let mut lifecycle = LIFECYCLE.lock();
    match *lifecycle {
        Lifecycle::Running(_) => {}
        Lifecycle::Shutdown => {
            drop(lifecycle);
            return refused(
                Refusal::NotInitialized,
                "mesh_library_init: the library was shut down, and cannot start again in this process",
            );
        }
        Lifecycle::New => {
            mesh_rt_init();
            actor::mesh_rt_init_actor(1);
            // The thread that starts the scheduler gets the main process; one
            // that finds it started gets a process of its own.
            let pid = stack::get_current_pid().unwrap_or_else(|| {
                let pid = actor::global_scheduler().create_main_process();
                stack::set_current_pid(pid);
                pid
            });
            *lifecycle = Lifecycle::Running(pid);
        }
    }
    MESH_LIBRARY_OK
}

#[no_mangle]
pub extern "C" fn mesh_library_shutdown() -> i32 {
    let _call = CALL_LOCK.lock();
    let mut lifecycle = LIFECYCLE.lock();
    let Lifecycle::Running(pid) = *lifecycle else {
        return MESH_LIBRARY_OK;
    };

    if let Some(scheduler) = actor::GLOBAL_SCHEDULER.get() {
        scheduler.finalize_host_process(pid);
        scheduler.signal_shutdown();
        scheduler.wait();
    }
    if stack::get_current_pid() == Some(pid) {
        stack::clear_current_pid();
    }
    *HOST_CALLBACKS.write() = None;
    *lifecycle = Lifecycle::Shutdown;
    MESH_LIBRARY_OK
}

#[no_mangle]
pub extern "C" fn mesh_library_register_host_callbacks(
    callbacks: *const MeshLibraryHostCallbacksV1,
) -> i32 {
    if callbacks.is_null() {
        return refused(
            Refusal::InvalidArgument,
            "mesh_library_register_host_callbacks: the callback table is NULL",
        );
    }
    let callbacks = unsafe { &*callbacks };
    let size = std::mem::size_of::<MeshLibraryHostCallbacksV1>();
    if callbacks.abi_version != MESH_LIBRARY_ABI_VERSION || callbacks.struct_size as usize != size {
        return refused(
            Refusal::AbiMismatch,
            format!(
                "mesh_library_register_host_callbacks: the callback table has abi_version {} and struct_size {}; this runtime takes abi_version {MESH_LIBRARY_ABI_VERSION} and struct_size {size}",
                callbacks.abi_version, callbacks.struct_size
            ),
        );
    }
    if !running() {
        return refused(
            Refusal::NotInitialized,
            "mesh_library_register_host_callbacks: mesh_library_init has not started the library",
        );
    }

    *HOST_CALLBACKS.write() = Some(RegisteredCallbacks {
        context: callbacks.context as usize,
        secure_store_put: callbacks.secure_store_put,
        secure_store_get: callbacks.secure_store_get,
        secure_store_delete: callbacks.secure_store_delete,
        push_get_token: callbacks.push_get_token,
        background_schedule: callbacks.background_schedule,
        network_state: callbacks.network_state,
        monotonic_clock: callbacks.monotonic_clock,
        wall_clock: callbacks.wall_clock,
        log_redacted: callbacks.log_redacted,
    });
    MESH_LIBRARY_OK
}

pub(crate) fn secure_store_get_raw(input: &[u8], output: &mut [u8]) -> Result<usize, i32> {
    call_raw_host_callback(2, input, output)
}

pub(crate) fn secure_store_put_raw(input: &[u8]) -> Result<(), i32> {
    let mut ignored = [0u8; 1];
    call_raw_host_callback(1, input, &mut ignored).map(|_| ())
}

pub(crate) fn secure_store_delete_raw(input: &[u8]) -> Result<(), i32> {
    call_raw_host_callback(3, input, &mut []).map(|_| ())
}

fn call_raw_host_callback(capability: u32, input: &[u8], output: &mut [u8]) -> Result<usize, i32> {
    // Its callers pass storage records of a few dozen bytes.
    debug_assert!(input.len() <= MAX_BOUNDARY_BYTES && output.len() <= MAX_BOUNDARY_BYTES);
    // No callbacks at all is a missing callback too, not status 2: a host's
    // secure store answers 2 for "not found", which callers act on.
    let callbacks = (*HOST_CALLBACKS.read()).ok_or(MESH_LIBRARY_ERR_CALLBACK_MISSING)?;
    let callback = callbacks
        .callback(capability)
        .ok_or(MESH_LIBRARY_ERR_CALLBACK_MISSING)?;
    let mut output_len = 0u64;
    let status = unsafe {
        callback(
            callbacks.context as *mut c_void,
            input.as_ptr(),
            input.len() as u64,
            output.as_mut_ptr(),
            output.len() as u64,
            &mut output_len,
        )
    };
    if status != MESH_LIBRARY_OK {
        return Err(status);
    }
    written_length(output_len, output.len()).ok_or(MESH_LIBRARY_ERR_OUTPUT_TOO_LARGE)
}

/// The length a host callback says it wrote, when it fits the `capacity`
/// it was given.
fn written_length(reported: u64, capacity: usize) -> Option<usize> {
    (reported <= capacity as u64).then_some(reported as usize)
}

/// Run an exported Mesh function on `input` and hand its result to `output`.
///
/// # Safety
///
/// `input` must point to `input_len` readable bytes (or be null with a
/// length of zero), and `output` to a writable `MeshLibraryBytes`.
#[no_mangle]
pub unsafe extern "C" fn mesh_library_invoke(
    entrypoint: MeshLibraryEntrypoint,
    input: *const u8,
    input_len: u64,
    output: *mut MeshLibraryBytes,
) -> i32 {
    if output.is_null() {
        return refused(
            Refusal::InvalidArgument,
            "an exported function was called with a NULL response pointer",
        );
    }
    if input.is_null() && input_len != 0 {
        return refused(
            Refusal::InvalidArgument,
            format!("an exported function was called with a NULL request of {input_len} bytes"),
        );
    }
    (*output) = MeshLibraryBytes::default();
    if input_len > MAX_BOUNDARY_BYTES as u64 {
        return refused(
            Refusal::OutputTooLarge,
            format!(
                "the request is {input_len} bytes; a call carries at most {MAX_BOUNDARY_BYTES}"
            ),
        );
    }
    let Some(call) = CALL_LOCK.try_lock() else {
        return refused(
            Refusal::Busy,
            "an exported function was called while another call was in progress",
        );
    };
    if !running() {
        drop(call);
        return refused(
            Refusal::NotInitialized,
            "an exported function was called before mesh_library_init started the library",
        );
    }
    let status = run_exported(entrypoint, input, input_len, output);
    drop(call);
    if status == MESH_LIBRARY_ERR_OUTPUT_TOO_LARGE {
        return refused(
            Refusal::OutputTooLarge,
            format!("the result is larger than {MAX_BOUNDARY_BYTES} bytes, or the host could not allocate it"),
        );
    }
    status
}

fn running() -> bool {
    matches!(*LIFECYCLE.lock(), Lifecycle::Running(_))
}

/// Run `entrypoint` on the request as a process of its own, finalized
/// before this returns the call's status.
///
/// # Safety
///
/// As [`mesh_library_invoke`], with the library running and the call lock
/// held.
unsafe fn run_exported(
    entrypoint: MeshLibraryEntrypoint,
    input: *const u8,
    input_len: u64,
    output: *mut MeshLibraryBytes,
) -> i32 {
    // Running: mesh_library_init started the scheduler.
    let scheduler = actor::global_scheduler();

    // The byte ABI copies the result to caller-owned memory before this scope
    // ends. Reclaim the call's managed values and secrets on every exit path.
    let context = CallContext {
        pid: scheduler.create_main_process(),
        previous_pid: stack::get_current_pid(),
    };
    if let Some(process) = scheduler.get_process(context.pid) {
        process.lock().library_call = true;
    }
    stack::set_current_pid(context.pid);
    let managed_input = mesh_bytes_new(input, input_len);
    let result = catch_unwind(AssertUnwindSafe(|| {
        let mut result = MeshLibraryCallResult {
            tag: u8::MAX,
            _padding: [0; 7],
            value: ptr::null_mut(),
        };
        entrypoint(managed_input, &mut result);
        result
    }));
    match result {
        Ok(result) if result.tag == 0 => copy_mesh_value(result.value, true, output, malloc),
        Ok(result) if result.tag == 1 => {
            let status = copy_mesh_value(result.value, false, output, malloc);
            if status == MESH_LIBRARY_OK {
                MESH_LIBRARY_ERR_APPLICATION
            } else {
                status
            }
        }
        Ok(_) => MESH_LIBRARY_ERR_INVALID_ARGUMENT,
        Err(_) => MESH_LIBRARY_ERR_PANIC,
    }
}

/// The C allocator the host frees returned bytes with
/// (`mesh_library_free_returned_bytes`).
unsafe fn malloc(len: usize) -> *mut u8 {
    libc::malloc(len).cast()
}

/// Copy the Bytes (or, for an error, the String) an entry point returned into
/// `output`, in memory from `allocate`.
unsafe fn copy_mesh_value(
    value: *mut u8,
    bytes: bool,
    output: *mut MeshLibraryBytes,
    allocate: unsafe fn(usize) -> *mut u8,
) -> i32 {
    if value.is_null() {
        return MESH_LIBRARY_ERR_INVALID_ARGUMENT;
    }
    let (data, len) = if bytes {
        let value = &*value.cast::<MeshBytes>();
        (value.as_slice().as_ptr(), value.len)
    } else {
        let value = &*value.cast::<MeshString>();
        (value.data_ptr(), value.len)
    };
    if len > MAX_BOUNDARY_BYTES as u64 {
        return MESH_LIBRARY_ERR_OUTPUT_TOO_LARGE;
    }
    if len == 0 {
        return MESH_LIBRARY_OK;
    }
    let copied = allocate(len as usize);
    if copied.is_null() {
        return MESH_LIBRARY_ERR_OUTPUT_TOO_LARGE;
    }
    ptr::copy_nonoverlapping(data, copied, len as usize);
    (*output) = MeshLibraryBytes { data: copied, len };
    MESH_LIBRARY_OK
}

#[no_mangle]
pub extern "C" fn mesh_library_free_returned_bytes(bytes: *mut MeshLibraryBytes) {
    if bytes.is_null() {
        return;
    }
    unsafe {
        if !(*bytes).data.is_null() {
            libc::free((*bytes).data.cast());
        }
        *bytes = MeshLibraryBytes::default();
    }
}

#[no_mangle]
pub extern "C" fn mesh_library_host_call(
    capability: u32,
    input: *const MeshBytes,
) -> *mut MeshResult {
    let callbacks = *HOST_CALLBACKS.read();
    let Some(callbacks) = callbacks else {
        return err_result("host_callback_not_registered");
    };
    let Some(callback) = callbacks.callback(capability) else {
        return err_result("host_callback_missing");
    };
    let input = unsafe { (*input).as_slice() };
    if input.len() > MAX_BOUNDARY_BYTES {
        return err_result("host_callback_input_too_large");
    }

    let mut output = host_callback_output();
    let mut output_len = 0u64;
    let status = unsafe {
        callback(
            callbacks.context as *mut c_void,
            input.as_ptr(),
            input.len() as u64,
            output.as_mut_ptr(),
            output.len() as u64,
            &mut output_len,
        )
    };
    if status != MESH_LIBRARY_OK {
        return err_result(&format!("host_callback_failed:{capability}:{status}"));
    }
    let Some(output_len) = written_length(output_len, output.len()) else {
        return err_result("host_callback_output_too_large");
    };
    alloc_result(0, mesh_bytes_new(output.as_ptr(), output_len as u64).cast())
}

fn host_callback_output() -> Zeroizing<Vec<u8>> {
    Zeroizing::new(vec![0; MAX_BOUNDARY_BYTES])
}

macro_rules! host_entrypoint {
    ($name:ident, $capability:expr) => {
        #[no_mangle]
        pub extern "C" fn $name(input: *const MeshBytes) -> *mut MeshResult {
            mesh_library_host_call($capability, input)
        }
    };
}

host_entrypoint!(mesh_host_secure_store_put, 1);
host_entrypoint!(mesh_host_secure_store_get, 2);
host_entrypoint!(mesh_host_secure_store_delete, 3);
host_entrypoint!(mesh_host_push_get_token, 4);
host_entrypoint!(mesh_host_background_schedule, 5);
host_entrypoint!(mesh_host_network_state, 6);
host_entrypoint!(mesh_host_monotonic_clock, 7);
host_entrypoint!(mesh_host_wall_clock, 8);
host_entrypoint!(mesh_host_log_redacted, 9);

#[cfg(test)]
mod tests {
    use super::*;

    /// A host whose allocator cannot give the returned bytes their memory
    /// gets an error, not a copy into nothing.
    #[test]
    fn returned_bytes_the_host_cannot_allocate_are_an_error() {
        unsafe fn out_of_memory(_len: usize) -> *mut u8 {
            ptr::null_mut()
        }
        crate::gc::mesh_rt_init();
        let value = mesh_bytes_new(b"x".as_ptr(), 1);
        let mut output = MeshLibraryBytes::default();
        let status = unsafe { copy_mesh_value(value.cast(), true, &mut output, out_of_memory) };
        assert_eq!(status, MESH_LIBRARY_ERR_OUTPUT_TOO_LARGE);
        assert!(output.data.is_null());
    }

    /// A refusal is explained by the code numbered after its status.
    #[test]
    fn a_refusals_code_is_numbered_after_its_status() {
        for refusal in [
            Refusal::InvalidArgument,
            Refusal::NotInitialized,
            Refusal::Busy,
            Refusal::OutputTooLarge,
            Refusal::AbiMismatch,
        ] {
            assert_eq!(refusal.code().id(), format!("R02{:02}", refusal.status()));
        }
    }

    #[test]
    fn a_written_length_fits_its_capacity() {
        assert_eq!(written_length(3, 3), Some(3));
        assert_eq!(written_length(4, 3), None);
        assert_eq!(written_length(u64::MAX, usize::MAX), Some(usize::MAX));
    }

    #[test]
    fn host_callback_output_uses_zeroizing_boundary_buffer() {
        let output = host_callback_output();
        let _: &Zeroizing<Vec<u8>> = &output;

        assert_eq!(output.len(), MAX_BOUNDARY_BYTES);
    }
}
