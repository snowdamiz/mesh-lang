//! End-to-end integration tests for all Phase 10 developer tools.
//!
//! Verifies that the meshc binary's developer-facing subcommands work together:
//! - `meshc build --json` produces valid JSON diagnostics for type errors
//! - `meshc fmt` formats files, `meshc fmt --check` verifies formatting
//! - `meshc init` creates a compilable project
//! - `meshc init --clustered` creates a clustered project using only public clustered-app surfaces
//! - `meshc init --template todo-api` creates the current local SQLite Todo API starter
//! - `meshc init --template todo-api --db ...` validates the typed DB-selection seam and the SQLite-local vs Postgres-clustered split
//! - `meshc repl --help` confirms REPL subcommand availability
//! - `meshc lsp --help` confirms LSP subcommand availability

use std::path::{Path, PathBuf};
use std::process::Command;

#[path = "support/test_artifacts.rs"]
mod artifacts;

/// Locate the meshc binary built by cargo.
fn meshc_bin() -> PathBuf {
    artifacts::meshc_bin()
}

fn write_file(path: &Path, contents: &str) {
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent).unwrap();
    }
    std::fs::write(path, contents).unwrap();
}

fn write_override_entry_test_project(root: &Path) -> (PathBuf, PathBuf, PathBuf) {
    let project_dir = root.join("override-entry-project");
    let tests_dir = project_dir.join("tests");
    let test_file = tests_dir.join("override_entry.test.mpl");

    write_file(
        &project_dir.join("mesh.toml"),
        "[package]\nname = \"override-entry-project\"\nversion = \"0.1.0\"\nentrypoint = \"lib/start.mpl\"\n",
    );
    write_file(
        &project_dir.join("lib/start.mpl"),
        "from App import answer\n\nfn main() do\n  println(\"app=#{answer()}\")\nend\n",
    );
    write_file(
        &project_dir.join("app.mpl"),
        "pub fn answer() -> Int do\n  42\nend\n",
    );
    write_file(
        &tests_dir.join("support.mpl"),
        "pub fn label() -> String do\n  \"support\"\nend\n",
    );
    write_file(
        &test_file,
        "from App import answer\nfrom Tests.Support import label\n\ntest(\"override entry roots all targets the same way\") do\n  assert(answer() == 42)\n  assert(label() == \"support\")\nend\n",
    );

    (project_dir, tests_dir, test_file)
}

fn assert_meshc_test_target_reports_passes(target: &Path, expected_summary: &str) {
    let output = Command::new(meshc_bin())
        .args(["test", target.to_str().unwrap()])
        .output()
        .expect("failed to run meshc test target");

    assert!(
        output.status.success(),
        "meshc test {} failed:\nstdout: {}\nstderr: {}",
        target.display(),
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
    assert!(
        String::from_utf8_lossy(&output.stdout).contains(expected_summary),
        "expected '{}' for target {}, got:\n{}",
        expected_summary,
        target.display(),
        String::from_utf8_lossy(&output.stdout)
    );
}

fn assert_meshc_test_target_succeeds(target: &Path) {
    assert_meshc_test_target_reports_passes(target, "1 passed");
}

fn run_meshc_test_file(test_file: &Path) -> std::process::Output {
    Command::new(meshc_bin())
        .arg("test")
        .arg(test_file)
        .env("NO_COLOR", "1")
        .output()
        .expect("failed to run meshc test")
}

fn assert_local_sqlite_todo_template(project_dir: &Path, starter_name: &str) {
    let manifest_path = project_dir.join("mesh.toml");
    let main_path = project_dir.join("main.mpl");
    let config_path = project_dir.join("config.mpl");
    let work_path = project_dir.join("work.mpl");
    let readme_path = project_dir.join("README.md");
    let dockerfile_path = project_dir.join("Dockerfile");
    let dockerignore_path = project_dir.join(".dockerignore");
    let router_path = project_dir.join("api/router.mpl");
    let todos_path = project_dir.join("api/todos.mpl");
    let health_path = project_dir.join("api/health.mpl");
    let registry_path = project_dir.join("runtime/registry.mpl");
    let limiter_path = project_dir.join("services/rate_limiter.mpl");
    let storage_path = project_dir.join("storage/todos.mpl");
    let todo_type_path = project_dir.join("types/todo.mpl");
    let config_test_path = project_dir.join("tests/config.test.mpl");
    let storage_test_path = project_dir.join("tests/storage.test.mpl");

    for path in [
        &manifest_path,
        &main_path,
        &config_path,
        &readme_path,
        &dockerfile_path,
        &dockerignore_path,
        &router_path,
        &todos_path,
        &health_path,
        &registry_path,
        &limiter_path,
        &storage_path,
        &todo_type_path,
        &config_test_path,
        &storage_test_path,
    ] {
        assert!(path.exists(), "missing generated file {}", path.display());
    }
    assert!(
        !work_path.exists(),
        "sqlite starter should not emit work.mpl at {}",
        work_path.display()
    );

    let manifest = std::fs::read_to_string(&manifest_path).unwrap();
    assert!(manifest.contains("[package]"));
    assert!(manifest.contains(starter_name));
    assert!(!manifest.contains("[cluster]"));

    let main = std::fs::read_to_string(&main_path).unwrap();
    assert!(main.contains("todo_db_path_key()"));
    assert!(main.contains("start_rate_limiter"));
    assert!(main.contains("start_registry"));
    assert!(main.contains("ensure_schema"));
    assert!(main.contains("[todo-api] local config loaded"));
    assert!(main.contains("[todo-api] SQLite schema ready"));
    assert!(main.contains("[todo-api] local runtime ready"));
    assert!(main.contains("[todo-api] HTTP server starting on"));
    assert!(main.contains("resolve_db_path()"));
    assert!(main.contains("todo_rate_limit_window_seconds_key()"));
    assert!(main.contains("todo_rate_limit_max_requests_key()"));
    assert!(!main.contains("Node.start_from_env()"));
    assert!(!main.contains("BootstrapStatus"));
    assert!(!main.contains("runtime bootstrap"));
    assert!(!main.contains("HTTP.clustered("));
    assert!(!main.contains("MESH_CLUSTER_"));
    assert!(!main.contains("Work.sync_todos"));

    let config = std::fs::read_to_string(&config_path).unwrap();
    assert!(config.contains("todo_db_path_key"));
    assert!(config.contains("default_todo_db_path"));
    assert!(config.contains("invalid_positive_int"));
    assert!(config.contains("invalid_db_path"));
    assert!(config.contains("invalid_todo_id_message"));
    assert!(config.contains("title_required_message"));
    assert!(config.contains("todo_not_found_message"));

    let router = std::fs::read_to_string(&router_path).unwrap();
    assert!(router.contains("HTTP.on_get(\"/health\", handle_health)"));
    assert!(router.contains("HTTP.on_get(\"/todos\", handle_list_todos)"));
    assert!(router.contains("HTTP.on_get(\"/todos/:id\", handle_get_todo)"));
    assert!(router.contains("HTTP.on_post(\"/todos\", handle_create_todo)"));
    assert!(router.contains("HTTP.on_put(\"/todos/:id\", handle_toggle_todo)"));
    assert!(router.contains("HTTP.on_delete(\"/todos/:id\", handle_delete_todo)"));
    assert!(!router.contains("HTTP.clustered("));

    let todos = std::fs::read_to_string(&todos_path).unwrap();
    assert!(todos.contains("allow_write("));
    assert!(todos.contains("todo_error_response"));
    assert!(todos.contains("invalid_todo_id_message"));
    assert!(todos.contains("title_required_message"));
    assert!(todos.contains("pub fn handle_list_todos(_request :: Request) -> Response do"));
    assert!(todos.contains("pub fn handle_get_todo(request :: Request) -> Response do"));
    assert!(todos.contains("bad_request_response"));
    assert!(!todos.contains("HTTP.clustered("));
    assert!(!todos.contains("Work.sync_todos"));

    let health = std::fs::read_to_string(&health_path).unwrap();
    assert!(health.contains("mode: \"local\""));
    assert!(health.contains("db_backend: \"sqlite\""));
    assert!(health.contains("storage_mode: \"single-node\""));
    assert!(health.contains("db_path: get_db_path()"));
    assert!(!health.contains("clustered_handler"));

    let registry = std::fs::read_to_string(&registry_path).unwrap();
    assert!(registry.contains("Process.register(\"todo_api_registry\""));

    let limiter = std::fs::read_to_string(&limiter_path).unwrap();
    assert!(limiter.contains("service TodoWriteRateLimiter do"));
    assert!(limiter.contains("spawn(rate_window_ticker"));

    let storage = std::fs::read_to_string(&storage_path).unwrap();
    assert!(storage.contains("Todo.from_row(row)"));
    assert!(storage.contains("String.to_int(trimmed)"));
    assert!(storage.contains("CREATE TABLE IF NOT EXISTS todos"));
    assert!(storage.contains("completed INTEGER NOT NULL DEFAULT 0"));
    assert!(storage.contains("title_required_message()"));
    assert!(storage.contains("invalid_todo_id_message()"));
    assert!(storage.contains("todo_not_found_message()"));
    assert!(!storage.contains("Map.get(row,"));

    let todo_type = std::fs::read_to_string(&todo_type_path).unwrap();
    assert!(todo_type.contains("end deriving(Json, Row)"));

    let config_test = std::fs::read_to_string(&config_test_path).unwrap();
    assert!(config_test.contains("describe(\"SQLite todo-api config\")"));
    assert!(config_test.contains("TODO_DB_PATH"));
    assert!(config_test.contains("Invalid TODO_DB_PATH: expected a non-empty path"));

    let storage_test = std::fs::read_to_string(&storage_test_path).unwrap();
    assert!(storage_test.contains("describe(\"SQLite todo storage\")"));
    assert!(storage_test.contains("sample_todo"));
    assert!(storage_test.contains("create_todo"));
    assert!(storage_test.contains("list_todos"));
    assert!(storage_test.contains("ensure_schema"));

    let readme = std::fs::read_to_string(&readme_path).unwrap();
    assert!(readme
        .contains("This project was generated by `meshc init --template todo-api --db sqlite`."));
    assert!(!readme.contains("This project was generated by `meshc init --template todo-api`."));
    assert!(readme.contains("single-node SQLite Todo API"));
    assert!(readme.contains("meshc test ."));
    assert!(readme.contains("meshc init --template todo-api --db postgres my-shared-todo"));
    assert!(readme.contains("meshc init --clustered my-clustered-app"));
    assert!(readme.contains(
        "there is no `work.mpl`, `HTTP.clustered(...)`, or `meshc cluster` story in this starter"
    ));
    assert!(readme.contains("TODO_DB_PATH"));
    assert!(readme.contains(&format!("docker build -t {} .", starter_name)));
    assert!(!readme.contains("Node.start_from_env()"));
    assert!(!readme.contains("Work.sync_todos"));
    assert!(!readme.contains("meshc cluster status"));
    assert!(!readme.contains("MESH_CLUSTER_"));

    let dockerfile = std::fs::read_to_string(&dockerfile_path).unwrap();
    assert!(dockerfile.contains("FROM ubuntu:24.04"));
    assert!(dockerfile.contains(&format!("COPY output /usr/local/bin/{}", starter_name)));
    assert!(dockerfile.contains(&format!("ENTRYPOINT [\"/usr/local/bin/{}\"]", starter_name)));
    assert!(dockerfile.contains("EXPOSE 8080"));
    assert!(!dockerfile.contains("4370"));
    assert!(!dockerfile.contains("MESH_CLUSTER_PORT"));

    let dockerignore = std::fs::read_to_string(&dockerignore_path).unwrap();
    assert!(dockerignore.contains("*.sqlite3"));
    assert!(dockerignore.contains("target"));
}

// ── Error messages (--json) ──────────────────────────────────────────

#[test]
fn test_build_json_output() {
    let dir = tempfile::tempdir().unwrap();
    let project = dir.path().join("proj");
    std::fs::create_dir_all(&project).unwrap();

    // Write a Mesh file with a type error (assigning string to Int annotation).
    std::fs::write(project.join("main.mpl"), "let x :: Int = \"hello\"\n").unwrap();

    let output = Command::new(meshc_bin())
        .args(["build", "--json", project.to_str().unwrap()])
        .output()
        .expect("failed to run meshc build --json");

    assert!(
        !output.status.success(),
        "Expected build to fail on type error"
    );

    let stderr = String::from_utf8_lossy(&output.stderr);

    // stderr contains concatenated JSON objects. Use a streaming deserializer
    // to extract the first one (the type error diagnostic).
    let mut stream = serde_json::Deserializer::from_str(&stderr).into_iter::<serde_json::Value>();
    let json = stream
        .next()
        .expect("no JSON object in stderr")
        .expect("first JSON object is not valid");

    // Verify required JSON fields.
    assert!(json.get("code").is_some(), "JSON missing 'code' field");
    assert!(
        json.get("severity").is_some(),
        "JSON missing 'severity' field"
    );
    assert!(
        json.get("message").is_some(),
        "JSON missing 'message' field"
    );
    assert!(json.get("spans").is_some(), "JSON missing 'spans' field");

    // Verify the error code starts with E (type error).
    let code = json["code"].as_str().unwrap();
    assert!(
        code.starts_with('E'),
        "Expected error code starting with E, got: {}",
        code
    );

    // Verify spans array is non-empty.
    let spans = json["spans"].as_array().unwrap();
    assert!(!spans.is_empty(), "Expected at least one span");

    // Verify no ANSI escape codes in output.
    assert!(
        !stderr.contains("\x1b["),
        "JSON mode should not contain ANSI escape codes"
    );
}

#[test]
fn test_build_without_main_names_the_entrypoint() {
    // Codegen emits no C `main` without an entry function, which used to
    // surface only as the system linker's "_main not found".
    let dir = tempfile::tempdir().unwrap();
    let project = dir.path().join("proj");
    std::fs::create_dir_all(&project).unwrap();
    std::fs::write(
        project.join("main.mpl"),
        "fn helper() -> Int do\n  1\nend\n",
    )
    .unwrap();

    let output = Command::new(meshc_bin())
        .args(["build", project.to_str().unwrap()])
        .output()
        .expect("failed to run meshc build");

    assert!(!output.status.success(), "build without main must fail");
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        stderr.contains("[B0302] Error: main.mpl has no `fn main()`"),
        "stderr: {stderr}"
    );
    assert!(!stderr.contains("Linking failed"), "stderr: {stderr}");
}

#[test]
fn test_build_diagnostics_are_plain_when_piped() {
    let dir = tempfile::tempdir().unwrap();
    std::fs::write(
        dir.path().join("main.mpl"),
        "fn main() do\n  println(1 + \"a\")\nend\n",
    )
    .unwrap();

    let output = Command::new(meshc_bin())
        .args(["build", dir.path().to_str().unwrap()])
        .env_remove("NO_COLOR")
        .output()
        .expect("failed to run meshc build");

    assert!(!output.status.success());
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(stderr.contains("main.mpl"), "stderr: {stderr}");
    assert!(!stderr.contains('\u{1b}'), "stderr: {stderr}");
}

// ── Formatter ────────────────────────────────────────────────────────

#[test]
fn test_fmt_formats_file() {
    let dir = tempfile::tempdir().unwrap();
    let file = dir.path().join("test.mpl");

    // Write an unformatted Mesh file (no spaces around operator, no indentation).
    std::fs::write(&file, "fn add(a,b) do\na+b\nend").unwrap();

    let output = Command::new(meshc_bin())
        .args(["fmt", file.to_str().unwrap()])
        .output()
        .expect("failed to run meshc fmt");

    assert!(
        output.status.success(),
        "meshc fmt failed: {}",
        String::from_utf8_lossy(&output.stderr)
    );

    let contents = std::fs::read_to_string(&file).unwrap();

    // Verify the file was reformatted (canonical 2-space indent, spaces around ops).
    assert_eq!(contents, "fn add(a, b) do\n  a + b\nend\n");
}

#[test]
fn test_fmt_check_formatted() {
    let dir = tempfile::tempdir().unwrap();
    let file = dir.path().join("good.mpl");

    // Write an already-formatted file.
    std::fs::write(&file, "fn add(a, b) do\n  a + b\nend\n").unwrap();

    let output = Command::new(meshc_bin())
        .args(["fmt", "--check", file.to_str().unwrap()])
        .output()
        .expect("failed to run meshc fmt --check");

    assert!(
        output.status.success(),
        "Expected exit 0 for already-formatted file, got: {}",
        String::from_utf8_lossy(&output.stderr)
    );
}

#[test]
fn test_fmt_check_unformatted() {
    let dir = tempfile::tempdir().unwrap();
    let file = dir.path().join("bad.mpl");

    // Write an unformatted file.
    std::fs::write(&file, "fn bad(a,b) do\na+b\nend").unwrap();

    let output = Command::new(meshc_bin())
        .args(["fmt", "--check", file.to_str().unwrap()])
        .output()
        .expect("failed to run meshc fmt --check");

    assert_eq!(
        output.status.code(),
        Some(1),
        "Expected exit 1 for unformatted file"
    );

    // File should NOT be modified in check mode.
    let contents = std::fs::read_to_string(&file).unwrap();
    assert_eq!(contents, "fn bad(a,b) do\na+b\nend");
}

#[test]
fn test_fmt_idempotent() {
    let dir = tempfile::tempdir().unwrap();
    let file = dir.path().join("idem.mpl");

    // Write an unformatted file.
    std::fs::write(&file, "fn foo(x) do\nlet y = x\ny\nend").unwrap();

    // Format once.
    let output1 = Command::new(meshc_bin())
        .args(["fmt", file.to_str().unwrap()])
        .output()
        .expect("failed to run meshc fmt (first pass)");
    assert!(output1.status.success(), "First format pass failed");

    let after_first = std::fs::read_to_string(&file).unwrap();

    // Format again.
    let output2 = Command::new(meshc_bin())
        .args(["fmt", file.to_str().unwrap()])
        .output()
        .expect("failed to run meshc fmt (second pass)");
    assert!(output2.status.success(), "Second format pass failed");

    let after_second = std::fs::read_to_string(&file).unwrap();

    // Both passes should produce identical output.
    assert_eq!(
        after_first, after_second,
        "Formatting is not idempotent!\nFirst pass:\n{}\nSecond pass:\n{}",
        after_first, after_second
    );

    // Additionally verify --check agrees the file is formatted.
    let check = Command::new(meshc_bin())
        .args(["fmt", "--check", file.to_str().unwrap()])
        .output()
        .expect("failed to run meshc fmt --check after formatting");
    assert!(
        check.status.success(),
        "fmt --check disagrees after formatting: {}",
        String::from_utf8_lossy(&check.stderr)
    );
}

// ── Linter ───────────────────────────────────────────────────────────

/// `meshc lint` reports through the one diagnostic format: a parse error
/// as its `P` code, a finding as its `L` warning, and the tally last, all on
/// stderr. A warning fails the command, as a CI gate needs.
#[test]
fn test_lint_reports_findings_with_locations_and_fails() {
    let dir = tempfile::tempdir().unwrap();
    write_file(
        &dir.path().join("src/deep.mpl"),
        "fn f(a) do\n  if a do\n    1\n  else\n    if not a do\n      2\n    else\n      3\n    end\n  end\nend\n",
    );
    write_file(&dir.path().join("clean.mpl"), "fn g(a) do\n  a\nend\n");
    write_file(
        &dir.path().join("broken.mpl"),
        "fn h() do\n  let = 1\nend\n",
    );
    let broken = dir.path().join("broken.mpl");
    let deep = dir.path().join("src/deep.mpl");

    let output = Command::new(meshc_bin())
        .args(["lint", dir.path().to_str().unwrap()])
        .output()
        .expect("failed to run meshc lint");

    assert_eq!(output.status.code(), Some(1), "{output:?}");
    assert!(output.stdout.is_empty(), "{output:?}");
    let stderr = String::from_utf8_lossy(&output.stderr);
    for expected in [
        "[P0001] Error: expected identifier or pattern after `let`".to_string(),
        format!("─[ {}:2:7 ]", broken.display()),
        "  = P0001: meshc explain P0001".to_string(),
        "[L0002] Warning: this `else` holds only an `if`".to_string(),
        format!("─[ {}:4:3 ]", deep.display()),
        "this `else`".to_string(),
        "holds only this `if`".to_string(),
        "Help: Join `else` and the `if` it holds into `else if ... do`".to_string(),
        "  = L0002: meshc explain L0002".to_string(),
    ] {
        assert!(
            stderr.contains(&expected),
            "missing {expected:?} in:\n{stderr}"
        );
    }
    assert!(
        stderr.find("[P0001]") < stderr.find("[L0002]"),
        "files are linted in path order:\n{stderr}"
    );
    assert_eq!(
        stderr.lines().last(),
        Some("error: 1 error, 1 warning (P0001, L0002)"),
        "{stderr}"
    );
    assert!(
        !stderr.contains("parse-error") && !stderr.contains("problem(s) found"),
        "{stderr}"
    );

    let json = Command::new(meshc_bin())
        .args(["lint", "--json", dir.path().to_str().unwrap()])
        .output()
        .expect("failed to run meshc lint --json");
    assert_eq!(json.status.code(), Some(1), "{json:?}");
    assert!(json.stdout.is_empty(), "{json:?}");
    let found: Vec<(String, String, String, u64, u64)> = String::from_utf8_lossy(&json.stderr)
        .lines()
        .map(|line| {
            let d: serde_json::Value = serde_json::from_str(line)
                .unwrap_or_else(|e| panic!("invalid diagnostic {line:?}: {e}"));
            (
                d["code"].as_str().unwrap().to_string(),
                d["severity"].as_str().unwrap().to_string(),
                d["file"].as_str().unwrap().to_string(),
                d["line"].as_u64().unwrap(),
                d["col"].as_u64().unwrap(),
            )
        })
        .collect();
    assert_eq!(
        found,
        [
            (
                "P0001".to_string(),
                "error".to_string(),
                broken.display().to_string(),
                2,
                7
            ),
            (
                "L0002".to_string(),
                "warning".to_string(),
                deep.display().to_string(),
                4,
                3
            ),
        ]
    );
}

/// Each catalog lint example gets its own code from `meshc lint`, and its
/// fix gets nothing. Warnings alone fail the command.
#[test]
fn test_lint_reports_each_lint_code_and_passes_the_fixes() {
    let lints = [
        mesh_diagnostics::Code::DeepNesting,
        mesh_diagnostics::Code::CollapsibleElseIf,
        mesh_diagnostics::Code::PassThroughArm,
        mesh_diagnostics::Code::BoolComparison,
    ];
    let dir = tempfile::tempdir().unwrap();
    for (bad, code) in [true, false]
        .into_iter()
        .flat_map(|bad| lints.map(|code| (bad, code)))
    {
        let example = code.info().example.unwrap();
        let folder = if bad { "bad" } else { "fixed" };
        let source = if bad { example.bad } else { example.fixed };
        write_file(
            &dir.path().join(folder).join(format!("{}.mpl", code.id())),
            source,
        );
    }

    let bad = Command::new(meshc_bin())
        .args(["lint", dir.path().join("bad").to_str().unwrap()])
        .output()
        .expect("failed to run meshc lint");
    assert_eq!(bad.status.code(), Some(1), "{bad:?}");
    assert!(bad.stdout.is_empty(), "{bad:?}");
    let stderr = String::from_utf8_lossy(&bad.stderr);
    for code in lints {
        let headline = format!("[{}] Warning: ", code.id());
        assert_eq!(
            stderr.matches(&headline).count(),
            1,
            "{headline}:\n{stderr}"
        );
        let file = dir.path().join("bad").join(format!("{}.mpl", code.id()));
        assert!(
            stderr.contains(&format!("─[ {}:", file.display())),
            "{stderr}"
        );
    }
    assert_eq!(
        stderr.lines().last(),
        Some("warning: 4 warnings (L0001, L0002, L0003, L0004)"),
        "{stderr}"
    );

    let fixed = Command::new(meshc_bin())
        .args(["lint", dir.path().join("fixed").to_str().unwrap()])
        .output()
        .expect("failed to run meshc lint");
    assert!(fixed.status.success(), "{fixed:?}");
    assert!(
        fixed.stdout.is_empty() && fixed.stderr.is_empty(),
        "{fixed:?}"
    );
}

#[test]
fn test_lint_clean_file_succeeds_silently() {
    let dir = tempfile::tempdir().unwrap();
    let file = dir.path().join("clean.mpl");
    std::fs::write(&file, "fn g(a) do\n  a\nend\n").unwrap();

    for args in [vec!["lint"], vec!["lint", "--json"]] {
        let output = Command::new(meshc_bin())
            .args(&args)
            .arg(&file)
            .output()
            .expect("failed to run meshc lint");

        assert!(output.status.success(), "{args:?}: {output:?}");
        assert!(
            output.stdout.is_empty() && output.stderr.is_empty(),
            "{args:?}: {output:?}"
        );
    }
}

#[test]
fn test_fmt_writes_nothing_when_a_file_cannot_be_formatted() {
    let dir = tempfile::tempdir().unwrap();
    let unformatted = "fn add(a,b) do\na+b\nend\n";
    write_file(&dir.path().join("a.mpl"), unformatted);
    write_file(&dir.path().join("b.mpl"), "fn h() do\n  let = 1\nend\n");

    let output = Command::new(meshc_bin())
        .args(["fmt", dir.path().to_str().unwrap()])
        .output()
        .expect("failed to run meshc fmt");

    assert!(!output.status.success());
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        stderr.contains("[P") && stderr.contains("b.mpl"),
        "{stderr}"
    );
    let a = std::fs::read_to_string(dir.path().join("a.mpl")).unwrap();
    assert_eq!(a, unformatted);
}

#[test]
fn test_fmt_and_lint_skip_hidden_entries() {
    // Installed packages under `.mesh`, `.git`, and `._*` sidecar files are
    // not the project's source, as a build does not compile them either.
    let dir = tempfile::tempdir().unwrap();
    write_file(&dir.path().join("main.mpl"), "fn main() do\n  1\nend\n");
    let hidden = [
        ".mesh/packages/dep@1.0.0/dep.mpl",
        ".git/x.mpl",
        "._main.mpl",
    ];
    for path in hidden {
        write_file(&dir.path().join(path), "fn  broken(\n");
    }

    for args in [vec!["lint"], vec!["fmt", "--check"], vec!["fmt"]] {
        let output = Command::new(meshc_bin())
            .args(&args)
            .arg(dir.path())
            .output()
            .expect("failed to run meshc");
        assert!(
            output.status.success(),
            "meshc {args:?}: {}{}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );
    }
    for path in hidden {
        let source = std::fs::read_to_string(dir.path().join(path)).unwrap();
        assert_eq!(source, "fn  broken(\n");
    }
}

/// What `meshc init` writes is what a user starts from: every template is
/// formatted and lint-clean as generated.
#[test]
fn test_init_templates_are_formatted_and_lint_clean() {
    let dir = tempfile::tempdir().unwrap();
    for (name, flags) in [
        ("plain", vec![]),
        ("clustered", vec!["--clustered"]),
        ("todo_sqlite", vec!["--template", "todo-api"]),
        (
            "todo_postgres",
            vec!["--template", "todo-api", "--db", "postgres"],
        ),
    ] {
        let init = Command::new(meshc_bin())
            .arg("init")
            .args(&flags)
            .arg(name)
            .current_dir(dir.path())
            .output()
            .expect("failed to run meshc init");
        assert!(init.status.success(), "meshc init {flags:?}: {init:?}");
        for args in [vec!["fmt", "--check"], vec!["lint"]] {
            let output = Command::new(meshc_bin())
                .args(&args)
                .arg(dir.path().join(name))
                .output()
                .expect("failed to run meshc");
            assert!(
                output.status.success(),
                "meshc {args:?} on `meshc init {flags:?}`: {}{}",
                String::from_utf8_lossy(&output.stdout),
                String::from_utf8_lossy(&output.stderr)
            );
        }
    }
}

#[test]
fn test_build_parse_error_names_the_file() {
    let dir = tempfile::tempdir().unwrap();
    write_file(
        &dir.path().join("main.mpl"),
        "fn main() do\n  let = 1\nend\n",
    );

    let output = Command::new(meshc_bin())
        .args(["build", dir.path().to_str().unwrap(), "--no-color"])
        .output()
        .expect("failed to run meshc build");

    assert!(!output.status.success());
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        stderr.contains("main.mpl:2:7") && !stderr.contains("<unknown>"),
        "{stderr}"
    );
}

// ── Test runner ──────────────────────────────────────────────────────

#[test]
fn test_test_runs_tests_directory_target() {
    let dir = tempfile::tempdir().unwrap();
    let project = dir.path().join("proj");
    let tests_dir = project.join("tests");

    std::fs::create_dir_all(&tests_dir).unwrap();
    std::fs::write(
        project.join("mesh.toml"),
        "[package]\nname = \"tooling-test-project\"\nversion = \"0.1.0\"\n",
    )
    .unwrap();
    std::fs::write(
        project.join("main.mpl"),
        "fn main() do\n  println(\"app\")\nend\n",
    )
    .unwrap();
    std::fs::write(
        project.join("math.mpl"),
        "pub fn answer() -> Int do\n  42\nend\n",
    )
    .unwrap();
    std::fs::write(
        tests_dir.join("math.test.mpl"),
        "from Math import answer\n\ntest(\"directory target runs project tests\") do\n  assert(answer() == 42)\nend\n",
    )
    .unwrap();

    let output = Command::new(meshc_bin())
        .args(["test", tests_dir.to_str().unwrap()])
        .output()
        .expect("failed to run meshc test on tests directory");

    assert!(
        output.status.success(),
        "meshc test <tests-dir> failed:\nstdout: {}\nstderr: {}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );

    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(
        stdout.contains("1 passed"),
        "expected a passing file-level summary for directory-target execution, got:\n{}",
        stdout
    );
}

#[test]
fn test_test_runs_mesh_solana_path_dependency() {
    let dir = tempfile::tempdir().unwrap();
    let project = dir.path().join("project");
    let package = PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .join("../../packages/mesh-solana")
        .canonicalize()
        .unwrap();
    write_file(
        &project.join("mesh.toml"),
        &format!(
            "[package]\nname = \"solana-path-dependency-test\"\nversion = \"0.1.0\"\n\n[dependencies]\nmesh-solana = {{ path = \"{}\" }}\n",
            package.display()
        ),
    );
    write_file(&project.join("main.mpl"), "fn main() do\nend\n");
    write_file(
        &project.join("tests/solana.test.mpl"),
        r#"from Solana.Read import jitosol_mint, pubkey_string

fn capability_matches() -> Bool do
  case jitosol_mint() do
    Err(_error) -> false
    Ok(mint) -> (mint
      |> pubkey_string()) == "J1toso1uCk3RLmjorhTtrVwY9HJ7X8V9yYac6Y7kGCPn"
  end
end

test("uses the Solana path package from meshc test") do
  assert(capability_matches())
end
"#,
    );

    assert_meshc_test_target_succeeds(&project);
}

#[test]
fn test_test_project_directory_target_succeeds_for_override_entry_without_root_main() {
    let dir = tempfile::tempdir().unwrap();
    let (project_dir, _, _) = write_override_entry_test_project(dir.path());

    assert_meshc_test_target_succeeds(&project_dir);
}

#[test]
fn test_test_tests_directory_target_succeeds_for_override_entry_without_root_main() {
    let dir = tempfile::tempdir().unwrap();
    let (_, tests_dir, _) = write_override_entry_test_project(dir.path());

    assert_meshc_test_target_succeeds(&tests_dir);
}

#[test]
fn test_test_specific_file_target_succeeds_for_override_entry_without_root_main() {
    let dir = tempfile::tempdir().unwrap();
    let (_, _, test_file) = write_override_entry_test_project(dir.path());

    assert_meshc_test_target_succeeds(&test_file);
}

#[test]
fn test_test_specific_file_target_fails_closed_when_no_project_root_exists() {
    let dir = tempfile::tempdir().unwrap();
    let orphan = dir.path().join("orphan.test.mpl");
    write_file(&orphan, "test(\"orphan\") do\n  assert(true)\nend\n");

    let output = Command::new(meshc_bin())
        .args(["test", orphan.to_str().unwrap()])
        .output()
        .expect("failed to run meshc test on orphan test file");

    assert!(
        !output.status.success(),
        "meshc test should fail closed for orphan file target:\nstdout: {}\nstderr: {}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );

    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        stderr.contains("Could not resolve a Mesh project root"),
        "expected truthful wrong-root error, got:\n{}",
        stderr
    );
    assert!(stderr.contains(orphan.to_str().unwrap()), "{}", stderr);
}

#[test]
fn test_test_coverage_reports_unsupported_contract() {
    let project = tempfile::tempdir().unwrap();
    write_file(
        &project.path().join("mesh.toml"),
        "[package]\nname = \"coverage-contract\"\nversion = \"0.1.0\"\nentrypoint = \"main.mpl\"\n",
    );
    write_file(&project.path().join("main.mpl"), "fn main() do\nend\n");
    write_file(
        &project.path().join("tests/basic.test.mpl"),
        "test(\"basic\") do\n  assert(true)\nend\n",
    );

    let output = Command::new(meshc_bin())
        .args(["test", "--coverage", project.path().to_str().unwrap()])
        .output()
        .expect("failed to run meshc test --coverage");

    assert_eq!(
        output.status.code(),
        Some(1),
        "expected unsupported coverage contract to exit 1, got stdout: {} stderr: {}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );

    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        stderr.contains("coverage reporting is not implemented for `meshc test`; run the command without --coverage"),
        "expected honest unsupported coverage message, got:\n{}",
        stderr
    );
    assert!(
        !String::from_utf8_lossy(&output.stdout).contains("Coverage reporting coming soon"),
        "coverage command should no longer claim success with a placeholder"
    );
}

// ── Package manager ──────────────────────────────────────────────────

#[test]
fn test_secure_store_fixture_is_available_only_to_meshc_test() {
    let project = tempfile::tempdir().unwrap();
    write_file(
        &project.path().join("mesh.toml"),
        "[package]\nname = \"test-secure-store\"\nversion = \"0.1.0\"\n",
    );
    write_file(
        &project.path().join("main.mpl"),
        "fn main() do\n  println(\"installed=#{Test.install_in_memory_secure_store()}\")\nend\n",
    );
    write_file(
        &project.path().join("tests/secure_store.test.mpl"),
        "test(\"installs an isolated secure store\") do\n  assert(Test.install_in_memory_secure_store())\nend\n",
    );

    let build = Command::new(meshc_bin())
        .args(["build", project.path().to_str().unwrap(), "--no-color"])
        .output()
        .expect("failed to run ordinary meshc build");
    assert!(!build.status.success());
    assert!(
        String::from_utf8_lossy(&build.stderr).contains("install_in_memory_secure_store"),
        "ordinary build should reject the test builtin:\n{}",
        String::from_utf8_lossy(&build.stderr)
    );

    let test = Command::new(meshc_bin())
        .args(["test", project.path().to_str().unwrap()])
        .output()
        .expect("failed to run meshc test");
    assert!(
        test.status.success(),
        "meshc test should accept the test builtin:\nstdout: {}\nstderr: {}",
        String::from_utf8_lossy(&test.stdout),
        String::from_utf8_lossy(&test.stderr)
    );
}

#[test]
fn test_assert_eq_and_assert_ne_compare_values_of_any_shown_type() {
    // assert_eq used to type-check only Strings, rejecting the documented
    // `assert_eq(10, 5 + 5)`.
    let project = tempfile::tempdir().unwrap();
    write_file(
        &project.path().join("mesh.toml"),
        "[package]\nname = \"asserts\"\nversion = \"0.1.0\"\n",
    );
    write_file(
        &project.path().join("main.mpl"),
        "fn main() do\n  println(\"ok\")\nend\n",
    );
    let test_file = project.path().join("tests/asserts.test.mpl");
    write_file(
        &test_file,
        "test(\"values\") do\n  assert_eq(10, 5 + 5)\n  assert_ne(3, 4)\n  assert_eq(1.5, 1.5)\n  assert_eq(true, 1 < 2)\n  assert_eq([1, 2], [1, 2])\n  assert_eq(\"a\", \"a\")\nend\n",
    );
    assert_meshc_test_target_reports_passes(project.path(), "1 passed");

    // A failing comparison shows both sides as values.
    write_file(
        &test_file,
        "test(\"wrong\") do\n  assert_eq(1 + 1, 3)\nend\n",
    );
    let output = Command::new(meshc_bin())
        .args(["test", project.path().to_str().unwrap()])
        .output()
        .expect("failed to run meshc test");
    let all = format!(
        "{}{}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
    assert!(!output.status.success(), "{all}");
    assert!(
        all.contains("left:  2") && all.contains("right: 3"),
        "{all}"
    );
}

#[test]
fn test_assert_receive_matches_the_message_against_its_pattern() {
    // assert_receive used to pass on any message: receive ran its first arm
    // whatever the message was.
    let project = tempfile::tempdir().unwrap();
    write_file(
        &project.path().join("mesh.toml"),
        "[package]\nname = \"receives\"\nversion = \"0.1.0\"\n",
    );
    write_file(
        &project.path().join("main.mpl"),
        "fn main() do\n  println(\"ok\")\nend\n",
    );
    let test_file = project.path().join("tests/receives.test.mpl");
    write_file(
        &test_file,
        "test(\"literal\") do\n  send(self(), 42)\n  assert_receive 42, 500\nend\n\ntest(\"binding\") do\n  send(self(), 7)\n  assert_receive n\nend\n",
    );
    let output = Command::new(meshc_bin())
        .args(["test", project.path().to_str().unwrap()])
        .output()
        .expect("failed to run meshc test");
    let all = format!(
        "{}{}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
    assert!(output.status.success(), "{all}");
    assert!(all.contains("2 passed"), "{all}");
    assert!(
        !all.contains("redundant"),
        "the catch-all arm is generated:\n{all}"
    );

    write_file(
        &test_file,
        "test(\"other\") do\n  send(self(), 7)\n  assert_receive 42, 500\nend\n",
    );
    let output = Command::new(meshc_bin())
        .args(["test", project.path().to_str().unwrap()])
        .output()
        .expect("failed to run meshc test");
    let all = format!(
        "{}{}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
    assert!(!output.status.success(), "{all}");
    assert!(
        all.contains("assert_receive 42 received another message"),
        "{all}"
    );
}

#[test]
fn test_push_token_fixture_is_isolated_and_composes_with_secure_store() {
    let project = tempfile::tempdir().unwrap();
    write_file(
        &project.path().join("mesh.toml"),
        "[package]\nname = \"test-push-token\"\nversion = \"0.1.0\"\n",
    );
    write_file(
        &project.path().join("main.mpl"),
        "fn main() do\n  Test.set_push_token(Bytes.from_utf8(\"expo/raw/v1\"), Bytes.from_utf8(\"token\"))\nend\n",
    );
    write_file(
        &project.path().join("tests/push_token.test.mpl"),
        r#"fn assert_push_token(expected :: Bytes) do
  case Host.push_get_token(Bytes.from_utf8("expo/v1")) do
    Ok(actual) -> assert(Bytes.secure_equals(actual, expected))
    Err(_) -> assert(false)
  end
end

fn assert_secure_store_callback() do
  case Host.secure_store_delete(Bytes.from_utf8("key")) do
    Ok(_) -> assert(true)
    Err(_) -> assert(false)
  end
end

test("secure store then push token") do
  let token = Bytes.from_utf8("first")
  assert(Test.install_in_memory_secure_store())
  assert(Test.set_push_token(Bytes.from_utf8("expo/v1"), token))
  assert_secure_store_callback()
  assert_push_token(token)
end

test("push token then secure store") do
  let token = Bytes.from_utf8("second")
  assert(Test.set_push_token(Bytes.from_utf8("expo/v1"), token))
  assert(Test.install_in_memory_secure_store())
  assert_secure_store_callback()
  assert_push_token(token)
end

test("host fixtures are cleared between tests") do
  case Host.push_get_token(Bytes.from_utf8("expo/v1")) do
    Ok(_) -> assert(false)
    Err(_) -> assert(true)
  end
  case Host.secure_store_delete(Bytes.from_utf8("key")) do
    Ok(_) -> assert(false)
    Err(_) -> assert(true)
  end
end
"#,
    );

    let build = Command::new(meshc_bin())
        .args(["build", project.path().to_str().unwrap(), "--no-color"])
        .output()
        .expect("failed to run ordinary meshc build");
    assert!(!build.status.success());
    assert!(
        String::from_utf8_lossy(&build.stderr).contains("set_push_token"),
        "ordinary build should reject the push-token test builtin:\n{}",
        String::from_utf8_lossy(&build.stderr)
    );

    let test = Command::new(meshc_bin())
        .args(["test", project.path().to_str().unwrap()])
        .output()
        .expect("failed to run meshc test");
    assert!(
        test.status.success(),
        "meshc test should isolate and compose host fixtures:\nstdout: {}\nstderr: {}",
        String::from_utf8_lossy(&test.stdout),
        String::from_utf8_lossy(&test.stderr)
    );
}

#[test]
fn test_test_support_fragment_can_bridge_module_privates_only_for_meshc_test() {
    let project = tempfile::tempdir().unwrap();
    let tests_dir = project.path().join("tests");
    write_file(
        &project.path().join("mesh.toml"),
        "[package]\nname = \"test-private-bridge\"\nversion = \"0.1.0\"\n",
    );
    write_file(
        &project.path().join("main.mpl"),
        "from Account import private_value_for_test\n\nfn main() do\n  println(\"#{private_value_for_test()}\")\nend\n",
    );
    write_file(
        &project.path().join("account.mpl"),
        "fn private_value() -> Int do\n  42\nend",
    );
    write_file(
        &project.path().join("account.test-support.mpl"),
        "pub fn private_value_for_test() -> Int do\n  private_value()\nend\n",
    );
    write_file(
        &tests_dir.join("account.test.mpl"),
        "from Account import private_value_for_test\n\ntest(\"test-only bridge calls a module private\") do\n  assert(private_value_for_test() == 42)\nend\n",
    );

    let build = Command::new(meshc_bin())
        .args(["build", project.path().to_str().unwrap(), "--no-color"])
        .output()
        .expect("failed to run ordinary meshc build");
    assert!(!build.status.success());
    assert!(
        String::from_utf8_lossy(&build.stderr).contains("private_value_for_test"),
        "ordinary build should not see test-support declarations:\n{}",
        String::from_utf8_lossy(&build.stderr)
    );

    assert_meshc_test_target_succeeds(&tests_dir);
}

#[test]
fn test_init_creates_project() {
    let dir = tempfile::tempdir().unwrap();

    let output = Command::new(meshc_bin())
        .args(["init", "test-project"])
        .current_dir(dir.path())
        .output()
        .expect("failed to run meshc init");

    assert!(
        output.status.success(),
        "meshc init failed: {}",
        String::from_utf8_lossy(&output.stderr)
    );

    // Verify mesh.toml exists.
    let toml_path = dir.path().join("test-project").join("mesh.toml");
    assert!(
        toml_path.exists(),
        "mesh.toml not created at {}",
        toml_path.display()
    );

    // Verify main.mpl exists.
    let main_path = dir.path().join("test-project").join("main.mpl");
    assert!(
        main_path.exists(),
        "main.mpl not created at {}",
        main_path.display()
    );

    // Verify mesh.toml contains the project name.
    let toml_contents = std::fs::read_to_string(&toml_path).unwrap();
    assert!(
        toml_contents.contains("test-project"),
        "mesh.toml does not contain project name"
    );

    // The generated program compiles and runs.
    let project = dir.path().join("test-project");
    let binary = dir.path().join("hello-bin");
    let build = Command::new(meshc_bin())
        .args(["build", project.to_str().unwrap(), "-o"])
        .arg(&binary)
        .output()
        .expect("failed to run meshc build");
    assert!(
        build.status.success(),
        "scaffold does not build: {}",
        String::from_utf8_lossy(&build.stderr)
    );
    let run = Command::new(&binary).output().expect("run scaffold");
    assert_eq!(String::from_utf8_lossy(&run.stdout), "Hello from Mesh!\n");
}

#[test]
fn test_init_clustered_creates_project() {
    let dir = tempfile::tempdir().unwrap();

    let output = Command::new(meshc_bin())
        .args(["init", "--clustered", "clustered-project"])
        .current_dir(dir.path())
        .output()
        .expect("failed to run meshc init --clustered");

    assert!(
        output.status.success(),
        "meshc init --clustered failed: {}",
        String::from_utf8_lossy(&output.stderr)
    );

    let project_dir = dir.path().join("clustered-project");
    let toml_path = project_dir.join("mesh.toml");
    let main_path = project_dir.join("main.mpl");
    let work_path = project_dir.join("work.mpl");
    let readme_path = project_dir.join("README.md");

    assert!(toml_path.exists(), "clustered mesh.toml should exist");
    assert!(main_path.exists(), "clustered main.mpl should exist");
    assert!(work_path.exists(), "clustered work.mpl should exist");
    assert!(readme_path.exists(), "clustered README.md should exist");

    let toml_contents = std::fs::read_to_string(&toml_path).unwrap();
    assert!(toml_contents.contains("[package]"));
    assert!(toml_contents.contains("clustered-project"));
    assert!(!toml_contents.contains("[cluster]"));
    assert!(!toml_contents.contains("Work.execute_declared_work"));

    let main_contents = std::fs::read_to_string(&main_path).unwrap();
    assert_eq!(main_contents.matches("Node.start_from_env()").count(), 1);
    assert!(main_contents.contains("BootstrapStatus"));
    assert!(main_contents.contains("runtime bootstrap"));
    assert!(main_contents.contains("runtime bootstrap failed"));
    assert!(!main_contents.contains("Continuity.submit_declared_work"));
    assert!(!main_contents.contains("HTTP.serve("));
    assert!(!main_contents.contains("/health"));
    assert!(!main_contents.contains("/work"));
    assert!(!main_contents.contains("Env.get_int"));
    assert!(!main_contents.contains("Node.start("));
    assert!(!main_contents.contains("CLUSTER_PROOF_"));

    let work_contents = std::fs::read_to_string(&work_path).unwrap();
    assert!(work_contents.contains("@cluster pub fn add()"));
    assert!(!work_contents.contains("execute_declared_work"));
    assert!(!work_contents.contains("request_key"));
    assert!(!work_contents.contains("attempt_id"));
    assert!(!work_contents.contains("declared_work_runtime_name"));
    assert!(!work_contents.contains("clustered(work)"));
    assert!(work_contents.contains("1 + 1"));
    assert!(!work_contents.contains("declared_work_target"));
    assert!(!work_contents.contains("Continuity.submit_declared_work"));
    assert!(!work_contents.contains("Continuity.mark_completed"));
    assert!(!work_contents.contains("Timer.sleep"));
    assert!(!work_contents.contains("owner_node"));
    assert!(!work_contents.contains("replica_node"));

    let readme_contents = std::fs::read_to_string(&readme_path).unwrap();
    assert!(
        readme_contents.contains("mesh.toml` is package-only and intentionally omits `[cluster]`")
    );
    assert!(readme_contents.contains("Node.start_from_env()"));
    assert!(readme_contents.contains("@cluster pub fn add()"));
    assert!(readme_contents.contains("Work.add"));
    assert!(readme_contents.contains("1 + 1"));
    assert!(readme_contents.contains("meshc cluster status"));
    assert!(readme_contents.contains("meshc cluster continuity <node-name@host:port> --json"));
    assert!(readme_contents
        .contains("meshc cluster continuity <node-name@host:port> <request-key> --json"));
    assert!(readme_contents.contains("meshc cluster diagnostics"));
    assert!(readme_contents.contains("MESH_CONTINUITY_ROLE"));
    assert!(readme_contents.contains("MESH_CONTINUITY_PROMOTION_EPOCH"));
    assert!(
        readme_contents.contains("automatically starts the source-declared `@cluster` function")
    );
    assert!(!readme_contents.contains("declared_work_runtime_name()"));
    assert!(!readme_contents.contains("clustered(work)"));
    assert!(!readme_contents.contains("Continuity.submit_declared_work"));
    assert!(!readme_contents.contains("HTTP.serve("));
    assert!(!readme_contents.contains("HTTP.clustered("));
    assert!(!readme_contents.contains("/health"));
    assert!(!readme_contents.contains("/work"));
    assert!(!readme_contents.contains("Timer.sleep"));
    assert!(!readme_contents.contains("CLUSTER_PROOF_"));
}

#[test]
fn test_init_clustered_rejects_existing_directory() {
    let dir = tempfile::tempdir().unwrap();

    let first = Command::new(meshc_bin())
        .args(["init", "--clustered", "clustered-project"])
        .current_dir(dir.path())
        .output()
        .expect("failed to run initial meshc init --clustered");
    assert!(
        first.status.success(),
        "initial meshc init --clustered failed: {}",
        String::from_utf8_lossy(&first.stderr)
    );

    let second = Command::new(meshc_bin())
        .args(["init", "--clustered", "clustered-project"])
        .current_dir(dir.path())
        .output()
        .expect("failed to rerun meshc init --clustered");

    assert!(
        !second.status.success(),
        "rerunning meshc init --clustered should fail cleanly"
    );

    let stderr = String::from_utf8_lossy(&second.stderr);
    let stdout = String::from_utf8_lossy(&second.stdout);
    let combined = format!("{stdout}\n{stderr}");
    assert!(
        combined.contains("already exists"),
        "expected existing-directory collision message, got:\n{}",
        combined
    );
}

#[test]
fn test_init_todo_template_db_sqlite_default_without_flag_stays_local() {
    let dir = tempfile::tempdir().unwrap();

    let output = Command::new(meshc_bin())
        .args(["init", "--template", "todo-api", "todo-starter"])
        .current_dir(dir.path())
        .output()
        .expect("failed to run meshc init --template todo-api");

    assert!(
        output.status.success(),
        "meshc init --template todo-api failed: {}",
        String::from_utf8_lossy(&output.stderr)
    );

    let project_dir = dir.path().join("todo-starter");
    assert_local_sqlite_todo_template(&project_dir, "todo-starter");
    assert_meshc_test_target_reports_passes(&project_dir, "2 passed");
}

#[test]
fn test_init_todo_template_db_sqlite_rejects_existing_directory() {
    let dir = tempfile::tempdir().unwrap();
    std::fs::create_dir_all(dir.path().join("todo-starter")).unwrap();

    let output = Command::new(meshc_bin())
        .args(["init", "--template", "todo-api", "todo-starter"])
        .current_dir(dir.path())
        .output()
        .expect("failed to rerun meshc init --template todo-api");

    assert!(
        !output.status.success(),
        "rerunning meshc init --template todo-api should fail cleanly"
    );

    let stderr = String::from_utf8_lossy(&output.stderr);
    let stdout = String::from_utf8_lossy(&output.stdout);
    let combined = format!("{stdout}\n{stderr}");
    assert!(
        combined.contains("already exists"),
        "expected existing-directory collision message, got:\n{}",
        combined
    );
}

#[test]
fn test_init_todo_template_db_sqlite_explicit_flag_matches_local_default_contract() {
    let dir = tempfile::tempdir().unwrap();

    let output = Command::new(meshc_bin())
        .args([
            "init",
            "--template",
            "todo-api",
            "--db",
            "sqlite",
            "todo-starter",
        ])
        .current_dir(dir.path())
        .output()
        .expect("failed to run meshc init --template todo-api --db sqlite");

    assert!(
        output.status.success(),
        "meshc init --template todo-api --db sqlite failed: {}",
        String::from_utf8_lossy(&output.stderr)
    );

    let project_dir = dir.path().join("todo-starter");
    assert_local_sqlite_todo_template(&project_dir, "todo-starter");
}

#[test]
fn test_init_todo_template_db_sqlite_rejects_usage_without_todo_template() {
    let dir = tempfile::tempdir().unwrap();
    let project_dir = dir.path().join("plain-project");

    let output = Command::new(meshc_bin())
        .args(["init", "--db", "sqlite", "plain-project"])
        .current_dir(dir.path())
        .output()
        .expect("failed to run meshc init --db sqlite without template");

    assert!(
        !output.status.success(),
        "meshc init --db sqlite without --template todo-api should fail"
    );

    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(stderr.contains("`--db` is only supported"), "{}", stderr);
    assert!(stderr.contains("--template todo-api"), "{}", stderr);
    assert!(
        stderr.contains("sqlite stays the local default"),
        "{}",
        stderr
    );
    assert!(
        !project_dir.exists(),
        "unexpected project created at {}",
        project_dir.display()
    );
}

#[test]
fn test_init_todo_template_db_sqlite_rejects_clustered_todo_template_conflict() {
    let dir = tempfile::tempdir().unwrap();
    let project_dir = dir.path().join("todo-starter");

    let output = Command::new(meshc_bin())
        .args([
            "init",
            "--clustered",
            "--template",
            "todo-api",
            "--db",
            "sqlite",
            "todo-starter",
        ])
        .current_dir(dir.path())
        .output()
        .expect("failed to run meshc init --clustered --template todo-api --db sqlite");

    assert!(
        !output.status.success(),
        "clustered todo-api init should fail instead of silently ignoring flags"
    );

    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        stderr.contains("`meshc init --clustered` cannot be combined"),
        "{}",
        stderr
    );
    assert!(
        stderr.contains("--template todo-api --db postgres"),
        "{}",
        stderr
    );
    assert!(
        stderr.contains("meshc init --clustered <name>"),
        "{}",
        stderr
    );
    assert!(
        !project_dir.exists(),
        "unexpected project created at {}",
        project_dir.display()
    );
}

#[test]
fn test_init_todo_template_db_rejects_unknown_values_before_generation() {
    let dir = tempfile::tempdir().unwrap();
    let project_dir = dir.path().join("todo-starter");

    let output = Command::new(meshc_bin())
        .args([
            "init",
            "--template",
            "todo-api",
            "--db",
            "mysql",
            "todo-starter",
        ])
        .current_dir(dir.path())
        .output()
        .expect("failed to run meshc init --template todo-api --db mysql");

    assert!(
        !output.status.success(),
        "unknown todo-api db values should fail during clap parsing"
    );

    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(stderr.contains("invalid value 'mysql'"), "{}", stderr);
    assert!(stderr.contains("--db <DB>"), "{}", stderr);
    assert!(
        !project_dir.exists(),
        "unexpected project created at {}",
        project_dir.display()
    );
}

#[test]
fn test_init_todo_template_postgres_creates_migration_first_project() {
    let dir = tempfile::tempdir().unwrap();
    let project_dir = dir.path().join("todo-starter");

    let output = Command::new(meshc_bin())
        .args([
            "init",
            "--template",
            "todo-api",
            "--db",
            "postgres",
            "todo-starter",
        ])
        .current_dir(dir.path())
        .output()
        .expect("failed to run meshc init --template todo-api --db postgres");

    assert!(
        output.status.success(),
        "meshc init --template todo-api --db postgres failed: {}",
        String::from_utf8_lossy(&output.stderr)
    );

    let migration_dir = project_dir.join("migrations");
    let migration_entries: Vec<_> = std::fs::read_dir(&migration_dir)
        .expect("failed to read generated migrations dir")
        .filter_map(|entry| entry.ok())
        .collect();
    assert_eq!(
        migration_entries.len(),
        1,
        "expected exactly one generated migration, got {}",
        migration_entries.len()
    );

    let migration_name = migration_entries[0]
        .file_name()
        .to_string_lossy()
        .to_string();
    assert!(
        migration_name.ends_with("_create_todos.mpl"),
        "unexpected migration filename: {}",
        migration_name
    );

    for path in [
        project_dir.join("mesh.toml"),
        project_dir.join("main.mpl"),
        project_dir.join("work.mpl"),
        project_dir.join("config.mpl"),
        project_dir.join("README.md"),
        project_dir.join("Dockerfile"),
        project_dir.join(".dockerignore"),
        project_dir.join(".env.example"),
        project_dir.join("api/router.mpl"),
        project_dir.join("api/todos.mpl"),
        project_dir.join("api/health.mpl"),
        project_dir.join("runtime/registry.mpl"),
        project_dir.join("services/rate_limiter.mpl"),
        project_dir.join("storage/todos.mpl"),
        project_dir.join("tests/config.test.mpl"),
        project_dir.join("types/todo.mpl"),
        migration_entries[0].path(),
    ] {
        assert!(path.exists(), "missing generated file {}", path.display());
    }

    let main = std::fs::read_to_string(project_dir.join("main.mpl")).unwrap();
    assert!(main.contains("Node.start_from_env()"));
    assert!(main.contains("Pool.open(database_url, 1, 4, 5000)"));
    assert!(main.contains("database_url_key()"));
    assert!(main.contains("[todo-api] PostgreSQL pool ready"));
    assert!(main.contains("HTTP.serve(router, port)"));
    assert!(!main.contains("TODO_DB_PATH"));
    assert!(!main.contains("ensure_schema"));

    let config = std::fs::read_to_string(project_dir.join("config.mpl")).unwrap();
    assert!(config.contains("database_url_key"));
    assert!(config.contains("\"DATABASE_URL\""));
    assert!(config.contains("todo_rate_limit_window_seconds_key"));
    assert!(config.contains("todo_rate_limit_max_requests_key"));
    assert!(config.contains("Missing required environment variable"));

    let storage = std::fs::read_to_string(project_dir.join("storage/todos.mpl")).unwrap();
    assert!(storage.contains("Query.from(todos_table())"));
    assert!(storage.contains("Repo.insert_expr"));
    assert!(storage.contains("Repo.update_where_expr"));
    assert!(storage.contains("Repo.delete_where"));
    assert!(storage.contains("Pg.uuid(Expr.value(id))"));
    assert!(!storage.contains("Sqlite.open"));
    assert!(!storage.contains("CREATE TABLE IF NOT EXISTS todos"));

    let migration = std::fs::read_to_string(migration_entries[0].path()).unwrap();
    assert!(migration.contains("# Migration: create_todos"));
    assert!(migration.contains("Pg.create_extension(pool, \"pgcrypto\")"));
    assert!(migration.contains("Migration.create_table(pool,"));
    assert!(migration.contains("Migration.create_index(pool, \"todos\", [\"created_at:DESC\"], \"name:idx_todos_created_at\")"));
    assert!(!migration.contains("CREATE TABLE IF NOT EXISTS todos"));

    let readme = std::fs::read_to_string(project_dir.join("README.md")).unwrap();
    assert!(readme.contains("meshc init --template todo-api --db postgres"));
    assert!(readme.contains("meshc migrate . up"));
    assert!(readme.contains("DATABASE_URL"));
    assert!(readme.contains(".env.example"));
    assert!(readme.contains("packages the binary produced by `meshc build .`"));
    assert!(readme.contains("does not run migrations or create schema at startup"));
}

#[test]
fn test_init_todo_template_postgres_omits_sqlite_contract_markers() {
    let dir = tempfile::tempdir().unwrap();
    let project_dir = dir.path().join("todo-starter");

    let output = Command::new(meshc_bin())
        .args([
            "init",
            "--template",
            "todo-api",
            "--db",
            "postgres",
            "todo-starter",
        ])
        .current_dir(dir.path())
        .output()
        .expect("failed to run meshc init --template todo-api --db postgres");

    assert!(
        output.status.success(),
        "meshc init --template todo-api --db postgres failed: {}",
        String::from_utf8_lossy(&output.stderr)
    );

    let readme = std::fs::read_to_string(project_dir.join("README.md")).unwrap();
    let dockerfile = std::fs::read_to_string(project_dir.join("Dockerfile")).unwrap();
    let dockerignore = std::fs::read_to_string(project_dir.join(".dockerignore")).unwrap();
    let env_example = std::fs::read_to_string(project_dir.join(".env.example")).unwrap();
    let health = std::fs::read_to_string(project_dir.join("api/health.mpl")).unwrap();

    assert!(!readme.contains("TODO_DB_PATH"));
    assert!(!readme.contains("todo.sqlite3"));
    assert!(!readme.contains("ensure_schema"));
    assert!(!readme.contains("failover"));

    assert!(!dockerfile.contains("TODO_DB_PATH"));
    assert!(!dockerfile.contains("sqlite3"));
    assert!(!dockerfile.contains("VOLUME"));
    assert!(dockerfile.contains("COPY output /usr/local/bin/todo-starter"));

    assert!(!dockerignore.contains("*.sqlite3"));
    assert!(dockerignore.contains(".env"));

    assert!(env_example.contains("DATABASE_URL="));
    assert!(env_example.contains("TODO_RATE_LIMIT_WINDOW_SECONDS=60"));
    assert!(env_example.contains("TODO_RATE_LIMIT_MAX_REQUESTS=5"));
    assert!(!env_example.contains("TODO_DB_PATH"));

    assert!(health.contains("db_backend: \"postgres\""));
    assert!(health.contains("migration_strategy: \"meshc migrate\""));
    assert!(!health.contains("DATABASE_URL"));
}

// ── Update ───────────────────────────────────────────────────────────

#[test]
fn test_update_command_is_listed_in_meshc_help() {
    let output = Command::new(meshc_bin())
        .arg("--help")
        .output()
        .expect("failed to run meshc --help");

    assert!(
        output.status.success(),
        "meshc --help failed: {}",
        String::from_utf8_lossy(&output.stderr)
    );

    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(
        stdout.contains("update"),
        "meshc --help should list the update subcommand, got:\n{}",
        stdout
    );
    assert!(
        stdout.contains("Refresh installed meshc and meshpkg"),
        "meshc --help should describe the update subcommand honestly, got:\n{}",
        stdout
    );
}

#[test]
fn test_update_subcommand_help_mentions_canonical_installer_path() {
    let output = Command::new(meshc_bin())
        .args(["update", "--help"])
        .output()
        .expect("failed to run meshc update --help");

    assert!(
        output.status.success(),
        "meshc update --help failed: {}",
        String::from_utf8_lossy(&output.stderr)
    );

    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(
        stdout.contains("Refresh installed meshc and meshpkg"),
        "meshc update --help should explain the toolchain surface, got:\n{}",
        stdout
    );
    assert!(
        stdout.contains("canonical installer path"),
        "meshc update --help should mention the canonical installer path, got:\n{}",
        stdout
    );
}

// ── REPL ─────────────────────────────────────────────────────────────

#[test]
fn test_repl_help() {
    let output = Command::new(meshc_bin())
        .args(["repl", "--help"])
        .output()
        .expect("failed to run meshc repl --help");

    assert!(
        output.status.success(),
        "meshc repl --help failed: {}",
        String::from_utf8_lossy(&output.stderr)
    );

    let stdout = String::from_utf8_lossy(&output.stdout);
    // Help text should mention REPL or interactive.
    let mentions_repl =
        stdout.to_lowercase().contains("repl") || stdout.to_lowercase().contains("interactive");
    assert!(
        mentions_repl,
        "repl --help should mention REPL or interactive, got:\n{}",
        stdout
    );
}

// ── LSP ──────────────────────────────────────────────────────────────

#[test]
fn test_lsp_subcommand_exists() {
    let output = Command::new(meshc_bin())
        .args(["lsp", "--help"])
        .output()
        .expect("failed to run meshc lsp --help");

    assert!(
        output.status.success(),
        "meshc lsp --help should exit 0, got: {:?}\nstderr: {}",
        output.status.code(),
        String::from_utf8_lossy(&output.stderr)
    );
}

#[test]
fn test_mock_actor_calls_its_callback_with_each_message() {
    // The mock called its callback with the closure environment alone, so
    // the message parameter was garbage and printing it crashed the file;
    // it also exited after 100ms without a message, dropping later sends.
    let dir = tempfile::tempdir().unwrap();
    let project = dir.path().join("project");
    write_file(
        &project.join("mesh.toml"),
        "[package]\nname = \"mock-tests\"\nversion = \"0.1.0\"\n",
    );
    write_file(&project.join("main.mpl"), "fn main() do\nend\n");
    write_file(
        &project.join("tests/mock.test.mpl"),
        r##"fn shout(msg :: String) -> String do
  println("named got #{msg}")
  "ok"
end

test("closure") do
  let prefix = "closure"
  let mock = Test.mock_actor(fn msg do
    println("#{prefix} got #{msg}")
    "ok"
  end)
  send(mock, "first")
  Timer.sleep(300)
  send(mock, "second")
  Timer.sleep(50)
end

test("named") do
  let mock = Test.mock_actor(shout)
  send(mock, "hi")
  Timer.sleep(50)
end
"##,
    );
    let output = Command::new(meshc_bin())
        .args(["test", project.to_str().unwrap()])
        .output()
        .expect("failed to run meshc test");
    let stdout = String::from_utf8_lossy(&output.stdout);
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(output.status.success(), "{stdout}{stderr}");
    for line in [
        "closure got first",
        "closure got second",
        "named got hi",
        "2 passed",
    ] {
        assert!(stdout.contains(line), "missing {line:?}: {stdout}");
    }
    assert!(!stderr.contains("panicked"), "{stderr}");
}

#[test]
fn test_a_panicking_test_fails_alone() {
    // A panic in a test body (division by zero, `List.get` past the end)
    // unwound out of the runner and ended the file: the test was never
    // marked failed and the tests after it never ran. `assert_raises` did
    // not see a panic either.
    let dir = tempfile::tempdir().unwrap();
    let project = dir.path().join("project");
    write_file(
        &project.join("mesh.toml"),
        "[package]\nname = \"panicking-tests\"\nversion = \"0.1.0\"\n",
    );
    write_file(&project.join("main.mpl"), "fn main() do\nend\n");
    write_file(
        &project.join("tests/panics.test.mpl"),
        r#"fn zero() = 0

test("divides") do
  assert(10 / zero() == 1)
end

test("indexes") do
  assert(List.get([1], 5) == 1)
end

test("raises") do
  assert_raises(fn() do
    List.head(List.tail([1]))
  end)
end

test("after") do
  assert(true)
end
"#,
    );
    let output = Command::new(meshc_bin())
        .args(["test", project.to_str().unwrap()])
        .output()
        .expect("failed to run meshc test");
    let stdout = String::from_utf8_lossy(&output.stdout);
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(!output.status.success(), "{stdout}\n{stderr}");
    assert!(stdout.contains("division by zero"), "{stdout}\n{stderr}");
    assert!(
        stdout.contains("panicked: List.get: index 5 is out of bounds for a list of length 1"),
        "{stdout}\n{stderr}"
    );
    assert!(stdout.contains("✓ raises"), "{stdout}");
    assert!(stdout.contains("✓ after"), "{stdout}");
    assert!(stdout.contains("2 failed"), "{stdout}");
    assert!(stdout.contains("2 passed"), "{stdout}");
    assert!(!stderr.contains("panicked at"), "{stderr}");
}

#[test]
fn test_a_failed_assertion_ends_its_test() {
    // A failed assertion let its test run on and counted as one failed test
    // each ("2 failed, 0 passed" for one test), a failing setup still ran
    // the body, and a multi-line string in a test gained the indentation
    // of the generated function.
    let dir = tempfile::tempdir().unwrap();
    let project = dir.path().join("project");
    write_file(
        &project.join("mesh.toml"),
        "[package]\nname = \"failing-tests\"\nversion = \"0.1.0\"\n",
    );
    write_file(&project.join("main.mpl"), "fn main() do\nend\n");
    write_file(
        &project.join("tests/steps.test.mpl"),
        r#"test("stops") do
  assert_eq(1, 2)
  println("AFTER FIRST FAILURE")
  assert_eq(3, 4)
end

describe("broken setup") do
  setup do
    assert(false)
  end

  teardown do
    println("TEARDOWN AFTER BROKEN SETUP")
  end

  test("body") do
    println("BODY RAN")
  end
end

describe("resources") do
  setup do
    let resource = "R1"
  end

  teardown do
    println("TEARDOWN SAW #{resource}")
  end

  test("fails") do
    assert_eq(resource, "R2")
  end
end

test("raises") do
  assert_raises(fn() do
    assert(false)
  end)
  println("AFTER RAISES")
end

test("multi-line string") do
  let s = "a
b"
  assert_eq(s, "a\nb")
end

describe("fails twice") do
  teardown do
    assert(1 > 2)
  end

  test("body and teardown") do
    assert(2 > 3)
  end
end

test("equal sides") do
  assert_ne(1, 1)
end

test("no raise") do
  assert_raises(fn() do
    assert(true)
  end)
end

test("passes") do
  assert(true)
end
"#,
    );
    let output = Command::new(meshc_bin())
        .args(["test", project.to_str().unwrap()])
        .output()
        .expect("failed to run meshc test");
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(!output.status.success(), "{stdout}");
    assert!(!stdout.contains("AFTER FIRST FAILURE"), "{stdout}");
    assert!(!stdout.contains("BODY RAN"), "{stdout}");
    // A teardown runs after its test's body, failed or not, and sees what
    // the setup bound; a failed setup leaves nothing to tear down.
    assert!(stdout.contains("TEARDOWN SAW R1"), "{stdout}");
    assert!(!stdout.contains("TEARDOWN AFTER BROKEN SETUP"), "{stdout}");
    assert!(stdout.contains("AFTER RAISES"), "{stdout}");
    assert!(stdout.contains("assert failed: false"), "{stdout}");
    // A test that fails in its body and its teardown fails once, with both
    // messages under its name.
    assert!(
        stdout.contains("assert failed: 2 > 3\n    assert failed: 1 > 2"),
        "{stdout}"
    );
    assert!(stdout.contains("both sides equal: 1"), "{stdout}");
    assert!(
        stdout.contains("assert_raises failed: expression did not raise"),
        "{stdout}"
    );
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        stderr.contains("[T0001] Error: assert failed: false"),
        "{stderr}"
    );
    assert!(
        stderr.contains("[T0003] Error: assert_ne failed"),
        "{stderr}"
    );
    assert!(stdout.contains("6 failed"), "{stdout}");
    assert!(stdout.contains("3 passed"), "{stdout}");
}

#[test]
fn test_output_is_quiet_or_plain_as_asked() {
    // `--quiet` still printed every test name, colors went into pipes (and
    // NO_COLOR was ignored), a test's own output was glued to its
    // "running:" prefix, and a failed assert_eq said "assert_eq failed:
    // assert_eq".
    let dir = tempfile::tempdir().unwrap();
    let project = dir.path().join("project");
    write_file(
        &project.join("mesh.toml"),
        "[package]\nname = \"output-tests\"\nversion = \"0.1.0\"\n",
    );
    write_file(&project.join("main.mpl"), "fn main() do\nend\n");
    write_file(
        &project.join("tests/output.test.mpl"),
        "test(\"one\") do\n  println(\"hello from one\")\n  assert(true)\nend\n\ntest(\"two\") do\n  assert_eq(1 + 1, 3)\nend\n\ntest(\"three\") do\n  assert(true)\nend\n",
    );
    let run = |args: &[&str]| {
        let output = Command::new(meshc_bin())
            .args(args)
            .arg(&project)
            .output()
            .expect("failed to run meshc test");
        String::from_utf8_lossy(&output.stdout).to_string()
    };

    let quiet = run(&["test", "--quiet"]);
    assert!(quiet.contains(".F."), "{quiet}");
    assert!(!quiet.contains("✓"), "{quiet}");
    assert!(quiet.contains("assert_eq failed: 1 + 1 == 3"), "{quiet}");
    assert!(!quiet.contains('\u{1b}'), "{quiet}");

    let plain = run(&["test"]);
    assert!(plain.contains("hello from one\n  ✓ one\n"), "{plain}");
    assert!(plain.contains("  ✗ two\n"), "{plain}");
    assert!(
        plain.contains("      left:  2\n      right: 3\n"),
        "{plain}"
    );
    assert!(!plain.contains("running:"), "{plain}");
    assert!(!plain.contains('\u{1b}'), "{plain}");
}

#[test]
fn test_diagnostics_point_at_the_test_file() {
    // A type error in a test was reported in the generated program,
    // `/var/folders/.../main.mpl:7:13`, at a line that had moved and under
    // re-indented code.
    let dir = tempfile::tempdir().unwrap();
    let project = dir.path().join("project");
    write_file(
        &project.join("mesh.toml"),
        "[package]\nname = \"diag-tests\"\nversion = \"0.1.0\"\n",
    );
    write_file(&project.join("main.mpl"), "fn main() do\nend\n");
    write_file(
        &project.join("tests/diag.test.mpl"),
        "fn helper(x :: Int) -> Int do\n  x + 1\nend\n\ndescribe(\"group\") do\n  setup do\n    let base = 40\n  end\n\n  test(\"sees setup\") do\n    assert_eq(base + true, 42)\n  end\nend\n",
    );
    let output = Command::new(meshc_bin())
        .args(["test", project.to_str().unwrap()])
        .output()
        .expect("failed to run meshc test");
    let stdout = String::from_utf8_lossy(&output.stdout);
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(!output.status.success(), "{stdout}{stderr}");
    assert!(stderr.contains("tests/diag.test.mpl:11:15"), "{stderr}");
    assert!(
        stderr.contains("    assert_eq(base + true, 42)"),
        "{stderr}"
    );
    assert!(!stderr.contains("main.mpl"), "{stderr}");
}

/// A failed test reports its catalog code at its line of the test file,
/// as written: the assertion's `T` code, or a panic's own `R0001`. Under
/// `--json` stderr is only those diagnostics, one object per line, and
/// whatever else a test program writes there is in the run's output.
#[test]
fn test_failures_are_coded_diagnostics_at_the_test_file() {
    let dir = tempfile::tempdir().unwrap();
    let project = dir.path().join("project");
    write_file(
        &project.join("mesh.toml"),
        "[package]\nname = \"coded-tests\"\nversion = \"0.1.0\"\n",
    );
    write_file(&project.join("main.mpl"), "fn main() do\nend\n");
    write_file(
        &project.join("tests/coded.test.mpl"),
        r#"fn zero() = 0

test("equal") do
  IO.eprintln("noise on stderr")
  IO.eprintln("{\"code\":\"Z9999\",\"message\":\"not a catalog code\"}")
  assert_eq(1 + 1, 3)
end

test("divides") do
  assert(10 / zero() == 1)
end

test("raises") do
  assert_raises(fn() do
    assert(false)
  end)
end

test("receives") do
  assert_receive 42, 10
end

test("passes") do
  assert(true)
end
"#,
    );
    let run = |json: bool| {
        let mut command = Command::new(meshc_bin());
        command.arg("test").arg(&project).env("NO_COLOR", "1");
        if json {
            command.arg("--json");
        }
        let output = command.output().expect("failed to run meshc test");
        assert!(!output.status.success(), "{output:?}");
        (
            String::from_utf8_lossy(&output.stdout).to_string(),
            String::from_utf8_lossy(&output.stderr).to_string(),
        )
    };

    let (stdout, stderr) = run(false);
    assert!(stdout.contains("  ✗ equal\n"), "{stdout}");
    assert!(stdout.contains("3 failed, 2 passed"), "{stdout}");
    for (headline, location) in [
        (
            "[T0002] Error: assert_eq failed: 1 + 1 == 3",
            "tests/coded.test.mpl:6\n",
        ),
        (
            "[R0001] Error: division by zero",
            "tests/coded.test.mpl:10:10\n",
        ),
        (
            "[T0005] Error: assert_receive 42 timed out after 10ms",
            "tests/coded.test.mpl:20\n",
        ),
    ] {
        let at = stderr
            .find(headline)
            .unwrap_or_else(|| panic!("{headline}: {stderr}"));
        let report = &stderr[at..];
        let next = report[1..].find("\n[").map_or(report.len(), |end| end + 1);
        assert!(report[..next].contains(location), "{location}: {stderr}");
    }
    assert!(stderr.contains("noise on stderr"), "{stderr}");
    assert!(
        !stderr.contains("T0004"),
        "a raise inside assert_raises: {stderr}"
    );
    assert!(!stderr.contains("main.mpl"), "{stderr}");

    let (stdout, stderr) = run(true);
    assert!(stdout.contains("  ✗ equal\n"), "{stdout}");
    assert!(stdout.contains("noise on stderr\n"), "{stdout}");
    assert!(stdout.contains("Z9999"), "{stdout}");
    let diagnostics: Vec<serde_json::Value> = stderr
        .lines()
        .map(|line| {
            serde_json::from_str(line).unwrap_or_else(|e| panic!("not NDJSON ({e}): {line}"))
        })
        .collect();
    let codes: Vec<&str> = diagnostics
        .iter()
        .map(|diagnostic| diagnostic["code"].as_str().unwrap())
        .collect();
    assert_eq!(codes, ["T0002", "R0001", "T0005"], "{stderr}");
    for diagnostic in &diagnostics {
        let file = diagnostic["file"].as_str().unwrap();
        assert!(file.ends_with("tests/coded.test.mpl"), "{diagnostic}");
        assert!(diagnostic["line"].as_u64().is_some(), "{diagnostic}");
        let family = match diagnostic["code"].as_str() {
            Some("R0001") => "runtime",
            _ => "test",
        };
        assert_eq!(diagnostic["category"], family, "{diagnostic}");
    }
    assert_eq!(diagnostics[1]["col"], 10);
}

/// `test_fail_msg` passed as a value takes the one argument its type says
/// and fails its test at no place; `panic(message)` is an `R0001` at its
/// call.
#[test]
fn test_fail_msg_as_a_value_and_panic_fail_their_tests_cleanly() {
    let dir = tempfile::tempdir().unwrap();
    let project = dir.path().join("project");
    write_file(
        &project.join("mesh.toml"),
        "[package]\nname = \"values\"\nversion = \"0.1.0\"\n",
    );
    write_file(&project.join("main.mpl"), "fn main() do\nend\n");
    write_file(
        &project.join("tests/values.test.mpl"),
        "test(\"fails through a value\") do\n  let fail = test_fail_msg\n  fail(\"boom\")\nend\n\ntest(\"panics\") do\n  panic(\"kaboom\")\nend\n\ntest(\"passes\") do\n  assert(true)\nend\n",
    );
    let output = Command::new(meshc_bin())
        .args(["test", "--json"])
        .arg(&project)
        .output()
        .expect("failed to run meshc test");
    let stdout = String::from_utf8_lossy(&output.stdout);
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert_eq!(output.status.code(), Some(1), "{stdout}{stderr}");
    assert!(stdout.contains("  ✗ fails through a value\n"), "{stdout}");
    assert!(stdout.contains("2 failed, 1 passed"), "{stdout}");
    let diagnostics: Vec<serde_json::Value> = stderr
        .lines()
        .map(|line| serde_json::from_str(line).unwrap_or_else(|e| panic!("{e}: {line}")))
        .collect();
    let codes: Vec<&str> = diagnostics
        .iter()
        .map(|diagnostic| diagnostic["code"].as_str().unwrap())
        .collect();
    assert_eq!(codes, ["T0005", "R0001"], "{stderr}");
    assert_eq!(diagnostics[0]["message"], "boom");
    assert_eq!(
        (&diagnostics[0]["file"], &diagnostics[0]["line"]),
        (&serde_json::json!(""), &serde_json::Value::Null),
        "{}",
        diagnostics[0]
    );
    assert_eq!(diagnostics[1]["message"], "kaboom");
    assert!(
        diagnostics[1]["file"]
            .as_str()
            .unwrap()
            .ends_with("tests/values.test.mpl"),
        "{}",
        diagnostics[1]
    );
    assert_eq!(
        (
            diagnostics[1]["line"].as_u64(),
            diagnostics[1]["col"].as_u64()
        ),
        (Some(7), Some(3))
    );
}

/// An error a test handles explains no crash: a program that reported a
/// failed `Node.connect` and then died is still a `T0101`.
#[test]
fn test_a_handled_error_does_not_explain_a_later_crash() {
    let dir = tempfile::tempdir().unwrap();
    let project = dir.path().join("project");
    write_file(
        &project.join("mesh.toml"),
        "[package]\nname = \"handled\"\nversion = \"0.1.0\"\n",
    );
    write_file(&project.join("main.mpl"), "fn main() do\nend\n");
    write_file(
        &project.join("tests/handled.test.mpl"),
        "test(\"connects, then dies\") do\n  assert(Node.connect(\"absent@127.0.0.1:1\") == -1)\n  Process.exit(3)\nend\n",
    );
    let output = Command::new(meshc_bin())
        .args(["test", "--json"])
        .arg(&project)
        .output()
        .expect("failed to run meshc test");
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert_eq!(output.status.code(), Some(1), "{output:?}");
    let codes: Vec<String> = stderr
        .lines()
        .map(|line| {
            let diagnostic: serde_json::Value = serde_json::from_str(line).unwrap();
            diagnostic["code"].as_str().unwrap().to_string()
        })
        .collect();
    assert_eq!(codes, ["R0301", "T0101"], "{stderr}");
}

/// A test file's JSON spans and edits are byte offsets into the file as
/// written, not into the program `meshc test` makes of it, whose rewritten
/// header moved them: an editor applying the edit fixes the typo.
#[test]
fn test_file_spans_and_edits_index_the_file_as_written() {
    let dir = tempfile::tempdir().unwrap();
    let project = dir.path().join("project");
    write_file(
        &project.join("mesh.toml"),
        "[package]\nname = \"spans\"\nversion = \"0.1.0\"\n",
    );
    write_file(&project.join("main.mpl"), "fn main() do\nend\n");
    let path = project.join("tests/typo.test.mpl");
    let source = "test(\"typo\") do\n  let count = 1\n  assert(cuont == 1)\nend\n";
    write_file(&path, source);
    for args in [&["test", "--json"][..], &["check", "--tests", "--json"]] {
        let output = Command::new(meshc_bin())
            .args(args)
            .arg(&project)
            .output()
            .expect("failed to run meshc");
        assert_eq!(output.status.code(), Some(1), "{args:?}: {output:?}");
        let stderr = String::from_utf8_lossy(&output.stderr);
        let diagnostic: serde_json::Value = serde_json::from_str(stderr.trim_end())
            .unwrap_or_else(|e| panic!("{args:?}: {e}: {stderr}"));
        assert_eq!(diagnostic["code"], "E0004", "{diagnostic}");
        assert!(
            Path::new(diagnostic["file"].as_str().unwrap()).ends_with("tests/typo.test.mpl"),
            "{diagnostic}"
        );
        let slice = |value: &serde_json::Value| {
            let start = value["start"].as_u64().unwrap() as usize;
            let end = value["end"].as_u64().unwrap() as usize;
            &source[start..end]
        };
        assert_eq!(
            slice(&diagnostic["spans"][0]),
            "cuont",
            "{args:?}: {diagnostic}"
        );
        let edit = &diagnostic["edits"][0];
        assert_eq!(slice(edit), "cuont", "{args:?}: {diagnostic}");
        assert_eq!(edit["replacement"], "count", "{diagnostic}");
        assert_eq!(
            (diagnostic["line"].as_u64(), diagnostic["col"].as_u64()),
            (Some(3), Some(10))
        );
    }
}

/// A passing run is a success even when its tests crash actors on purpose;
/// those panics are still reported, and no error tally contradicts the
/// passing summary.
#[test]
fn test_a_crash_a_passing_test_provokes_fails_nothing() {
    let dir = tempfile::tempdir().unwrap();
    let project = dir.path().join("project");
    write_file(
        &project.join("mesh.toml"),
        "[package]\nname = \"crashing-actor\"\nversion = \"0.1.0\"\n",
    );
    write_file(&project.join("main.mpl"), "fn main() do\nend\n");
    write_file(
        &project.join("tests/crash.test.mpl"),
        "actor crasher() do\n  panic(\"deliberate crash\")\nend\n\ntest(\"crashes an actor\") do\n  spawn(crasher)\n  Timer.sleep(50)\n  assert(true)\nend\n",
    );
    let output = Command::new(meshc_bin())
        .args(["test", "--json"])
        .arg(&project)
        .output()
        .expect("failed to run meshc test");
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(output.status.success(), "{output:?}");
    let diagnostic: serde_json::Value = serde_json::from_str(stderr.trim_end()).unwrap();
    assert_eq!(diagnostic["code"], "R0001");
    assert_eq!(diagnostic["message"], "deliberate crash");

    let output = Command::new(meshc_bin())
        .arg("test")
        .arg(&project)
        .env("NO_COLOR", "1")
        .output()
        .expect("failed to run meshc test");
    let stdout = String::from_utf8_lossy(&output.stdout);
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(output.status.success(), "{output:?}");
    assert!(stdout.contains("1 test file passed"), "{stdout}");
    assert!(
        stderr.contains("[R0001] Error: deliberate crash"),
        "{stderr}"
    );
    assert!(!stderr.contains("error: 1 error"), "{stderr}");
}

#[test]
fn test_a_file_of_describes_runs() {
    // With no top-level test, the generated program had no `__test_body_`
    // function, and the compiler did not treat it as a test program:
    // "Undefined variable 'assert_eq'".
    let dir = tempfile::tempdir().unwrap();
    let project = dir.path().join("project");
    write_file(
        &project.join("mesh.toml"),
        "[package]\nname = \"describe-tests\"\nversion = \"0.1.0\"\n",
    );
    write_file(&project.join("main.mpl"), "fn main() do\nend\n");
    write_file(
        &project.join("tests/group.test.mpl"),
        "describe(\"group\") do\n  test(\"compares\") do\n    assert_eq(1 + 1, 2)\n  end\n  test(\"receives\") do\n    send(self(), 7)\n    assert_receive 7, 500\n  end\nend\n",
    );
    let output = Command::new(meshc_bin())
        .args(["test", project.to_str().unwrap()])
        .output()
        .expect("failed to run meshc test");
    let stdout = String::from_utf8_lossy(&output.stdout);
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(output.status.success(), "{stdout}{stderr}");
    assert!(stdout.contains("2 passed"), "{stdout}");
}

#[test]
fn test_nested_comprehension_checks_run_and_report_assertion_failures() {
    let project = tempfile::tempdir().unwrap();
    write_file(
        &project.path().join("mesh.toml"),
        "[package]\nname = \"nested-checks\"\nversion = \"0.1.0\"\n",
    );
    write_file(&project.path().join("main.mpl"), "fn main() do\nend\n");
    let test_file = project.path().join("tests/nested.test.mpl");
    let source = r#"test("nested checks") do
  for status in 100..102 do
    let eligible = true
    for left in [0, 1] do
      assert_eq(left, left)
    end
  end
end
"#;
    let run_test = |source: &str| {
        write_file(&test_file, source);
        run_meshc_test_file(&test_file)
    };

    let pass = run_test(source);
    let details = artifacts::command_output_text(&pass);
    assert_eq!(pass.status.code(), Some(0), "{details}");
    let stdout = String::from_utf8_lossy(&pass.stdout);
    assert!(stdout.contains("✓ nested checks"), "{details}");
    assert!(stdout.contains("1 test file passed"), "{details}");

    let fail = run_test(&source.replace("assert_eq(left, left)", "assert_eq(left, 0)"));
    let details = artifacts::command_output_text(&fail);
    assert_eq!(fail.status.code(), Some(1), "{details}");
    assert!(details.contains("✗ nested checks"), "{details}");
    assert!(details.contains("assert_eq failed: left == 0"), "{details}");
    assert!(
        details.contains("left:  1") && details.contains("right: 0"),
        "{details}"
    );
}

#[test]
fn test_retry_policy_nested_budget_sweep_rejects_mutants() {
    let project = tempfile::tempdir().unwrap();
    let project = project.path();
    for (path, source) in [
        ("mesh.toml", include_str!("fixtures/retry_policy/mesh.toml")),
        ("main.mpl", include_str!("fixtures/retry_policy/main.mpl")),
        (
            "tests/budget.test.mpl",
            include_str!("fixtures/retry_policy/tests/budget.test.mpl"),
        ),
    ] {
        write_file(&project.join(path), source);
    }

    let policy = include_str!("fixtures/retry_policy/policy.mpl");
    let policy_file = project.join("policy.mpl");
    let test_file = project.join("tests/budget.test.mpl");
    let test_name = "retry eligibility across HTTP statuses and remaining budgets";
    let run_policy = |source: &str| {
        write_file(&policy_file, source);
        run_meshc_test_file(&test_file)
    };
    let assert_sweep_passes = |output: &std::process::Output| {
        let details = artifacts::command_output_text(output);
        assert_eq!(output.status.code(), Some(0), "{details}");
        assert!(details.contains(&format!("✓ {test_name}")), "{details}");
        assert!(details.contains("1 test file passed"), "{details}");
    };

    assert_sweep_passes(&run_policy(policy));
    let binary = project.join(format!("retry-policy{}", std::env::consts::EXE_SUFFIX));
    let build = Command::new(meshc_bin())
        .arg("build")
        .arg(project)
        .arg("--output")
        .arg(&binary)
        .output()
        .expect("failed to build the retry policy example");
    assert!(
        build.status.success(),
        "{}",
        artifacts::command_output_text(&build)
    );
    let run = Command::new(&binary)
        .output()
        .expect("failed to run the retry policy example");
    assert!(
        run.status.success(),
        "{}",
        artifacts::command_output_text(&run)
    );
    assert_eq!(run.stdout, b"true\nfalse\ntrue\nfalse\nfalse\n");

    for (wrong_policy, actual, expected) in [
        (
            policy.replace("(status == 503 || status == 429)", "status == 503"),
            "429/1: false",
            "429/1: true",
        ),
        (
            policy.replace(
                "(status == 503 || status == 429)",
                "status == 503 || status == 429",
            ),
            "503/-1: true",
            "503/-1: false",
        ),
        (
            policy.replace("left > 0", "left == 1"),
            "429/2: false",
            "429/2: true",
        ),
    ] {
        let fail = run_policy(&wrong_policy);
        let details = artifacts::command_output_text(&fail);
        assert_eq!(fail.status.code(), Some(1), "{details}");
        assert!(details.contains(&format!("✗ {test_name}")), "{details}");
        assert!(details.contains("assert_eq failed:"), "{details}");
        assert!(details.contains(&format!("left:  {actual}")), "{details}");
        assert!(details.contains(&format!("right: {expected}")), "{details}");
    }
    assert_sweep_passes(&run_policy(policy));
}

#[test]
fn test_nested_describes_run() {
    // A describe in a describe was left as written: "Undefined variable
    // 'test'". Its tests see the outer setup and run both teardowns.
    let dir = tempfile::tempdir().unwrap();
    let project = dir.path().join("project");
    write_file(
        &project.join("mesh.toml"),
        "[package]\nname = \"nested-tests\"\nversion = \"0.1.0\"\n",
    );
    write_file(&project.join("main.mpl"), "fn main() do\nend\n");
    write_file(
        &project.join("tests/nested.test.mpl"),
        "describe(\"outer\") do\n  setup do\n    let base = 40\n  end\n  teardown do\n    println(\"OUTER DOWN\")\n  end\n  test(\"a\") do\n    assert_eq(base, 40)\n  end\n  describe(\"inner\") do\n    setup do\n      let more = base + 2\n    end\n    teardown do\n      println(\"INNER DOWN #{more}\")\n    end\n    test(\"b\") do\n      assert_eq(more, 42)\n    end\n  end\nend\n",
    );
    let output = Command::new(meshc_bin())
        .args(["test", project.to_str().unwrap()])
        .output()
        .expect("failed to run meshc test");
    let stdout = String::from_utf8_lossy(&output.stdout);
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(output.status.success(), "{stdout}{stderr}");
    assert!(stdout.contains("✓ outer > a"), "{stdout}");
    assert!(
        stdout.contains("INNER DOWN 42\nOUTER DOWN\n  ✓ outer > inner > b"),
        "{stdout}"
    );
    assert!(stdout.contains("2 passed"), "{stdout}");
}

#[test]
fn test_runner_reports_a_test_file_that_crashes() {
    // Stack overflow has its own diagnostic. An unexplained exit gets the
    // test runner's diagnostic with the failed file and exit status.
    let dir = tempfile::tempdir().unwrap();
    let project = dir.path().join("project");
    write_file(
        &project.join("mesh.toml"),
        "[package]\nname = \"crash-tests\"\nversion = \"0.1.0\"\n",
    );
    write_file(&project.join("main.mpl"), "fn main() do\nend\n");
    write_file(
        &project.join("tests/deep.test.mpl"),
        r##"fn deep(n :: Int) -> Int do
  deep(n + 1) + 1
end

test("overflows the stack") do
  assert(deep(0) > 0)
end
"##,
    );
    write_file(
        &project.join("tests/exit.test.mpl"),
        "test(\"exits early\") do\n  Process.exit(42)\nend\n",
    );
    let output = Command::new(meshc_bin())
        .args(["test", project.to_str().unwrap()])
        .output()
        .expect("failed to run meshc test");
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(stderr.contains("[R0002]"), "{stderr}");
    assert!(
        stderr.contains("[T0101] Error: the test program for 'tests/exit.test.mpl' ended without reporting a failure")
            && stderr.contains("exit status: 42"),
        "{stderr}"
    );
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(!output.status.success(), "{stdout}");
    assert!(
        stdout.contains("CRASHED") && stdout.contains("deep.test.mpl") && stdout.contains("signal"),
        "{stdout}"
    );
}

/// Runs meshc in `cwd`: whether it succeeded, and its stdout then stderr.
fn run_meshc(cwd: &Path, args: &[&str], env: &[(&str, &str)]) -> (bool, String) {
    let output = Command::new(meshc_bin())
        .args(args)
        .current_dir(cwd)
        .envs(env.iter().copied())
        .output()
        .expect("meshc runs");
    let text = format!(
        "{}{}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
    (output.status.success(), text)
}

#[test]
fn test_init_rejects_an_unknown_template() {
    let dir = tempfile::tempdir().unwrap();
    let (ok, text) = run_meshc(dir.path(), &["init", "--template", "blog", "app"], &[]);
    assert!(!ok, "{text}");
    assert!(
        text.contains(
            "[X0001] Error: unknown init template 'blog'; supported templates: todo-api.\n"
        ),
        "{text}"
    );
    let (ok, text) = run_meshc(
        dir.path(),
        &["init", "--template", "blog", "--db", "sqlite", "app"],
        &[],
    );
    assert!(!ok, "{text}");
    assert!(
        text.contains("todo-api. `--db` is only supported with `--template todo-api`."),
        "{text}"
    );
    assert!(!dir.path().join("app").exists());
}

/// `meshc deps` writes the lockfile, then skips resolution until the
/// manifest changes.
#[test]
fn test_deps_resolves_until_the_lockfile_is_fresh() {
    let dir = tempfile::tempdir().unwrap();
    let project = dir.path().join("app");
    std::fs::create_dir_all(&project).unwrap();
    let (ok, text) = run_meshc(dir.path(), &["deps", "app"], &[]);
    assert!(
        !ok && text.contains("[M0001] Error: Failed to read"),
        "{text}"
    );
    assert!(
        text.contains(&Path::new("app").join("mesh.toml").display().to_string()),
        "{text}"
    );

    let manifest = project.join("mesh.toml");
    write_file(
        &manifest,
        "[package]\nname = \"app\"\nversion = \"0.1.0\"\n",
    );
    let (ok, text) = run_meshc(&project, &["deps"], &[]);
    assert!(ok && text.contains("No dependencies"), "{text}");
    assert!(project.join("mesh.lock").is_file());
    let (ok, text) = run_meshc(&project, &["deps"], &[]);
    assert!(ok && text.contains("Dependencies up to date"), "{text}");

    write_file(
        &dir.path().join("helper/mesh.toml"),
        "[package]\nname = \"helper\"\nversion = \"0.1.0\"\n",
    );
    write_file(
        &manifest,
        "[package]\nname = \"app\"\nversion = \"0.1.0\"\n\n[dependencies]\nhelper = { path = \"../helper\" }\n",
    );
    // Newer than the lockfile, whatever the filesystem's timestamp grain.
    std::fs::File::options()
        .write(true)
        .open(&manifest)
        .unwrap()
        .set_modified(std::time::SystemTime::now() + std::time::Duration::from_secs(60))
        .unwrap();
    let (ok, text) = run_meshc(&project, &["deps"], &[]);
    assert!(ok && text.contains("Resolved 1 dependencies"), "{text}");
}

/// `meshc update` runs the installer it downloads; one it cannot download
/// is an error.
#[cfg(unix)]
#[test]
fn test_update_runs_the_installer_it_downloads() {
    use std::io::{Read, Write};

    let listener = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
    let url = format!("http://{}/install.sh", listener.local_addr().unwrap());
    let server = std::thread::spawn(move || {
        let (mut stream, _) = listener.accept().unwrap();
        let _ = stream.read(&mut [0_u8; 1024]);
        let body = "exit 0\n";
        write!(
            stream,
            "HTTP/1.1 200 OK\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{body}",
            body.len()
        )
        .unwrap();
    });
    let dir = tempfile::tempdir().unwrap();
    let (ok, text) = run_meshc(
        dir.path(),
        &["update"],
        &[("MESH_UPDATE_INSTALLER_URL", url.as_str())],
    );
    server.join().unwrap();
    assert!(
        ok && text.contains("Mesh toolchain update completed via the canonical installer."),
        "{text}"
    );

    let (ok, text) = run_meshc(
        dir.path(),
        &["update"],
        &[("MESH_UPDATE_INSTALLER_URL", "http://127.0.0.1:1/install.sh")],
    );
    assert!(
        !ok && text.starts_with("[X0301] Error: toolchain update download failed"),
        "{text}"
    );
}

#[test]
fn test_build_needs_a_project_directory() {
    let dir = tempfile::tempdir().unwrap();
    let (ok, text) = run_meshc(dir.path(), &["build", "missing"], &[]);
    assert!(
        !ok && text.contains("Project directory 'missing' does not exist"),
        "{text}"
    );
    write_file(&dir.path().join("notes.txt"), "notes");
    let (ok, text) = run_meshc(dir.path(), &["build", "notes.txt"], &[]);
    assert!(
        !ok && text.contains("'notes.txt' is not a directory"),
        "{text}"
    );

    write_file(&dir.path().join("app/main.mpl"), "fn main() do\nend\n");
    let (ok, text) = run_meshc(dir.path(), &["build", "app"], &[("MESH_RT_LIB_PATH", "")]);
    assert!(
        !ok && text.contains("MESH_RT_LIB_PATH was set but empty"),
        "{text}"
    );
}

/// A library's IR is named for the library and has no C `main`.
#[test]
fn test_library_ir_is_named_for_the_library() {
    let dir = tempfile::tempdir().unwrap();
    let project = dir.path().join("widgets");
    let fixture = Path::new(env!("CARGO_MANIFEST_DIR")).join("tests/fixtures/library");
    for file in ["mesh.toml", "main.mpl"] {
        write_file(
            &project.join(file),
            &std::fs::read_to_string(fixture.join(file)).unwrap(),
        );
    }
    let (ok, text) = run_meshc(
        dir.path(),
        &["build", "widgets", "--artifact", "staticlib", "--emit-llvm"],
        &[],
    );
    assert!(ok, "{text}");
    assert!(project.join("libwidgets.a").is_file());
    let ir = std::fs::read_to_string(project.join("libwidgets.ll")).unwrap();
    assert!(!ir.contains("define i32 @main("), "{ir}");
}

/// `meshc fmt` and `meshc lint` name what they were given when it holds no
/// source they can read.
#[cfg(unix)]
#[test]
fn test_fmt_and_lint_name_paths_without_readable_sources() {
    use std::os::unix::fs::PermissionsExt;

    let dir = tempfile::tempdir().unwrap();
    let root = dir.path();
    write_file(&root.join("notes.txt"), "notes");
    std::fs::create_dir_all(root.join("empty")).unwrap();
    write_file(&root.join("locked.mpl"), "fn main() do\nend\n");
    write_file(&root.join("sealed/main.mpl"), "fn main() do\nend\n");
    let lock = |path: &str, mode| {
        std::fs::set_permissions(root.join(path), std::fs::Permissions::from_mode(mode)).unwrap()
    };
    lock("locked.mpl", 0o000);
    lock("sealed", 0o000);
    // Permissions do not bind a privileged user.
    let enforced = std::fs::read(root.join("locked.mpl")).is_err();

    for command in ["fmt", "lint"] {
        let mut cases = vec![
            ("missing", "Path 'missing' does not exist"),
            ("notes.txt", "'notes.txt' is not a .mpl file"),
            ("/dev/null", "'/dev/null' is not a file or directory"),
            ("empty", "No .mpl files found at 'empty'"),
        ];
        if enforced {
            cases.push(("locked.mpl", "Failed to read 'locked.mpl'"));
            cases.push(("sealed", "Failed to walk directory 'sealed'"));
        }
        for (path, message) in cases {
            let (ok, text) = run_meshc(root, &[command, path], &[]);
            assert!(!ok && text.contains(message), "{command} {path}: {text}");
        }
    }
    lock("sealed", 0o755);
}

/// What `meshc test` says when there is nothing, or nothing it can run.
#[test]
fn test_test_reports_targets_it_cannot_run() {
    let dir = tempfile::tempdir().unwrap();
    let project = dir.path().join("app");
    write_file(
        &project.join("mesh.toml"),
        "[package]\nname = \"app\"\nversion = \"0.1.0\"\n",
    );
    write_file(&project.join("main.mpl"), "fn main() do\nend\n");
    write_file(&project.join("notes.txt"), "notes");

    let (ok, text) = run_meshc(&project, &["test"], &[]);
    assert!(
        !ok && text.contains("[T0103] Error: no *.test.mpl files found under '"),
        "{text}"
    );
    let (ok, text) = run_meshc(&project, &["test", "missing"], &[]);
    assert!(
        !ok && text.contains("/app/missing' does not exist"),
        "{text}"
    );
    let (ok, text) = run_meshc(&project, &["test", "notes.txt"], &[]);
    assert!(
        !ok && text.contains("notes.txt' is not a directory or a *.test.mpl file"),
        "{text}"
    );

    // A file the test DSL rejects, and a project whose path dependency is
    // gone, each fail alone.
    write_file(
        &project.join("tests/order.test.mpl"),
        "describe(\"order\") do\n  test(\"first\") do\n    assert(true)\n  end\n  setup() do\n  end\nend\n",
    );
    let (ok, text) = run_meshc(&project, &["test"], &[]);
    assert!(!ok, "{text}");
    assert!(
        text.contains("COMPILE ERROR: tests/order.test.mpl")
            && text.contains("[P0401] Error: `setup` must come before the tests of its describe")
            && text.contains("tests/order.test.mpl:5:3"),
        "{text}"
    );
    write_file(
        &project.join("tests/order.test.mpl"),
        "test(\"ok\") do\n  assert(true)\nend\n",
    );
    write_file(
        &project.join("mesh.toml"),
        "[package]\nname = \"app\"\nversion = \"0.1.0\"\n\n[dependencies]\ngone = { path = \"../gone\" }\n",
    );
    let (ok, text) = run_meshc(&project, &["test"], &[]);
    assert!(!ok, "{text}");
    assert!(
        text.contains("SETUP ERROR: tests/order.test.mpl")
            && text.contains("Failed to resolve path dependency `gone`"),
        "{text}"
    );
}

/// A bad command line is an `X0001` for a person too, exiting 2, with
/// Clap's tip and usage as notes; help and the version still print to
/// stdout and exit 0.
#[test]
fn argument_errors_are_coded_for_people_too() {
    let run = |args: &[&str]| {
        Command::new(meshc_bin())
            .args(args)
            .env("NO_COLOR", "1")
            .output()
            .unwrap()
    };
    let bad = run(&["check", "--bogus"]);
    assert_eq!(bad.status.code(), Some(2), "{bad:?}");
    assert!(bad.stdout.is_empty(), "{bad:?}");
    let stderr = String::from_utf8_lossy(&bad.stderr);
    assert!(
        stderr.starts_with("[X0001] Error: unexpected argument '--bogus' found\n"),
        "{stderr}"
    );
    assert!(stderr.contains("  Note: Usage: meshc check"), "{stderr}");
    assert!(stderr.contains("meshc explain X0001"), "{stderr}");
    for args in [&["check", "--help"][..], &["--version"]] {
        let output = run(args);
        assert!(output.status.success(), "{output:?}");
        assert!(output.stderr.is_empty(), "{output:?}");
        assert!(!output.stdout.is_empty(), "{output:?}");
    }
}

#[test]
fn json_mode_is_pure_ndjson() {
    let temp = tempfile::tempdir().unwrap();
    let root = temp.path();
    let bin = meshc_bin();
    let execute = |args: &[&str]| {
        Command::new(&bin)
            .args(args)
            .current_dir(root)
            .output()
            .unwrap()
    };
    let catalog = execute(&["--json", "explain"]);
    assert!(catalog.status.success(), "{catalog:?}");
    assert!(catalog.stderr.is_empty(), "{catalog:?}");
    let catalog: serde_json::Value = serde_json::from_slice(&catalog.stdout).unwrap();
    let codes = catalog["codes"].as_array().unwrap();
    let keys = [
        "code", "severity", "message", "file", "spans", "fix", "line", "col", "name", "category",
        "notes", "guide", "docs_url", "edits",
    ];
    let verify = |args: &[&str], expected: &[&str]| {
        let output = execute(args);
        assert_eq!(
            output.status.code(),
            Some(match expected {
                [] => 0,
                ["X0001"] => 2,
                _ => 1,
            }),
            "{output:?}"
        );
        assert!(output.stdout.is_empty(), "{args:?}: {output:?}");
        let stderr = std::str::from_utf8(&output.stderr).unwrap();
        let diagnostics: Vec<serde_json::Value> = stderr
            .lines()
            .map(|line| {
                let diagnostic: serde_json::Value = serde_json::from_str(line)
                    .unwrap_or_else(|e| panic!("{args:?}: invalid diagnostic {line:?}: {e}"));
                let object = diagnostic.as_object().unwrap();
                assert_eq!(object.len(), keys.len(), "{line}");
                for key in keys {
                    assert!(object.contains_key(key), "missing {key} in {line}");
                }
                assert!(
                    codes
                        .iter()
                        .any(|entry| entry["code"] == diagnostic["code"]),
                    "{line}"
                );
                diagnostic
            })
            .collect();
        let actual: Vec<_> = diagnostics
            .iter()
            .map(|d| d["code"].as_str().unwrap())
            .collect();
        assert_eq!(actual, expected, "{args:?}: {stderr}");
        diagnostics
    };

    let main = root.join("main.mpl");
    let clean = "fn main() do\n  println(\"ready\")\nend\n";
    write_file(&main, clean);
    verify(&["check", "--json"], &[]);
    verify(&["lint", "--json"], &[]);
    verify(&["lint", "missing", "--json"], &["X0002"]);
    assert!(!root.join("out").exists());
    verify(
        &["build", ".", "--output", "out", "--emit-llvm", "--json"],
        &[],
    );
    assert!(root.join("out").is_file());
    assert!(root.join("out.ll").is_file());
    verify(
        &["--json", "build", "main.mpl", "--output", "standalone"],
        &[],
    );

    write_file(&main, "fn main() do\n  println(1)\n");
    let diagnostics = verify(&["build", ".", "--json"], &["P0004"]);
    assert_eq!(diagnostics[0]["spans"].as_array().unwrap().len(), 2);
    verify(&["lint", "main.mpl", "--json"], &["P0004"]);
    let diagnostics = verify(&["fmt", "main.mpl", "--json"], &["P0004"]);
    assert_eq!(diagnostics[0]["file"], "main.mpl");
    assert!(!diagnostics[0]["spans"].as_array().unwrap().is_empty());

    write_file(&main, "fn main() do\n  println(missing)\nend\n");
    verify(&["build", ".", "--json"], &["E0004"]);
    let diagnostics = verify(&["check", "main.mpl", "--json"], &["E0004"]);
    assert_eq!(diagnostics[0]["file"], "main.mpl");

    write_file(&main, clean);
    write_file(&root.join("a.mpl"), "struct State do\n  a :: Int\nend\n");
    write_file(&root.join("b.mpl"), "struct State do\n  b :: String\nend\n");
    let diagnostics = verify(&["build", ".", "--json"], &["E0102"]);
    assert_eq!(diagnostics[0]["spans"].as_array().unwrap().len(), 2);
    verify(&["--json", "check"], &["E0102"]);

    for (file, result) in [("a.mpl", 1), ("b.mpl", 2)] {
        write_file(
            &root.join(file),
            &format!("pub fn same() do\n  {result}\nend\n"),
        );
    }
    verify(&["check", "--json"], &["E0103"]);
    verify(&["verify", "--list", "--json"], &["E0103"]);
    write_file(&root.join("a.mpl"), "");
    write_file(&root.join("b.mpl"), "@cluster(3)\nfn hidden() do\nend\n");
    verify(&["check", "--json"], &["CFG0001"]);
    write_file(&root.join("b.mpl"), "");

    let malformed = "[package\n";
    write_file(&root.join("mesh.toml"), malformed);
    for args in [["build", ".", "--json"].as_slice(), &["check", "--json"]] {
        let diagnostics = verify(args, &["M0002"]);
        let diagnostic = &diagnostics[0];
        let span = &diagnostic["spans"][0];
        assert!(diagnostic["file"].as_str().unwrap().ends_with("mesh.toml"));
        assert_eq!(span["file"], diagnostic["file"]);
        assert_eq!(span["line"], 1);
        assert_eq!(span["start"], malformed.find('\n').unwrap());
    }
    let standalone = root.join("example.mpl");
    for code in ["E0102", "E0103"] {
        let example = &codes.iter().find(|entry| entry["code"] == code).unwrap()["example"];
        write_file(&standalone, example["bad"].as_str().unwrap());
        verify(&["check", "example.mpl", "--json"], &[code]);
        write_file(&standalone, example["fixed"].as_str().unwrap());
        verify(&["check", "example.mpl", "--json"], &[]);
    }
    for code in ["L0001", "L0002", "L0003", "L0004"] {
        let example = &codes.iter().find(|entry| entry["code"] == code).unwrap()["example"];
        write_file(&standalone, example["bad"].as_str().unwrap());
        let diagnostics = verify(&["lint", "example.mpl", "--json"], &[code]);
        assert_eq!(diagnostics[0]["severity"], "warning");
        assert_eq!(diagnostics[0]["category"], "lint");
        write_file(&standalone, example["fixed"].as_str().unwrap());
        verify(&["--json", "lint", "example.mpl"], &[]);
    }
    let bool_comparison = &codes.iter().find(|entry| entry["code"] == "L0004").unwrap()["example"];
    write_file(&standalone, bool_comparison["bad"].as_str().unwrap());
    let diagnostics = verify(&["lint", "example.mpl", "--json"], &["L0004"]);
    assert_eq!(
        diagnostics[0]["edits"],
        serde_json::json!([{
            "file": "example.mpl",
            "start": 37,
            "end": 50,
            "replacement": "ready",
            "applicability": "machine-applicable"
        }])
    );
    verify(&["explain", "BOGUS", "--json"], &["X0102"]);
    verify(&["guide", "bogus", "--json"], &["X0101"]);
    let records = verify(&["guide", "syntx", "--json"], &["X0101"]);
    assert!(records[0]["fix"]
        .as_str()
        .unwrap()
        .contains("`meshc guide syntax`"));
    for (query, code) in [("e0001", "E0001"), ("cfg0001", "CFG0001")] {
        let records = verify(&["guide", query, "--json"], &["X0101"]);
        assert!(records[0]["fix"]
            .as_str()
            .unwrap()
            .contains(&format!("`meshc explain {code}`")));
    }
    verify(
        &["cluster", "status", "invalid-target", "--json"],
        &["X0501"],
    );
    verify(&["check", "--bogus", "--json"], &["X0001"]);
    for args in [
        &["--json", "check", "--help"][..],
        &["--json", "--version"][..],
    ] {
        let output = execute(args);
        assert!(output.status.success(), "{output:?}");
        assert!(
            output.stderr.is_empty() && !output.stdout.is_empty(),
            "{output:?}"
        );
    }

    let unformatted = "fn add(a,b) do\na+b\nend\n";
    write_file(&main, unformatted);
    let records = verify(&["fmt", "--check", "main.mpl", "--json"], &["X0201"]);
    assert_eq!(records[0]["file"], "main.mpl");
    assert!(records[0]["fix"]
        .as_str()
        .unwrap()
        .contains("`meshc fmt main.mpl`"));
    assert_eq!(std::fs::read_to_string(main).unwrap(), unformatted);
}

#[test]
fn skills_setup_supports_piped_stdin_with_explicit_targets() {
    let project = tempfile::tempdir().unwrap();
    let root = project.path();
    write_file(
        &root.join("mesh.toml"),
        "[package]\nname = \"app\"\nversion = \"0.1.0\"\n",
    );
    let subdir = root.join("src");
    std::fs::create_dir(&subdir).unwrap();
    let run = |args: &[&str]| {
        Command::new(meshc_bin())
            .args(["skills", "setup", "--json"])
            .args(args)
            .stdin(std::process::Stdio::piped())
            .current_dir(&subdir)
            .output()
            .unwrap()
    };
    for args in [&[][..], &["--yes"][..], &["--target", "codex"][..]] {
        let output = run(args);
        assert_eq!(output.status.code(), Some(1), "{output:?}");
        assert!(output.stdout.is_empty(), "{output:?}");
        let error: serde_json::Value = serde_json::from_slice(&output.stderr).unwrap();
        assert_eq!(error["code"], "X0104");
        assert!(error["fix"]
            .as_str()
            .unwrap()
            .contains("meshc skills setup --yes --target <agent>"));
        assert!(!root.join(".agents").exists());
    }

    let args = ["-y", "--target", "codex", "--target", "claude-code"];
    for _ in 0..2 {
        let output = run(&args);
        assert!(output.status.success(), "{output:?}");
        assert!(
            output.stdout.is_empty() && output.stderr.is_empty(),
            "{output:?}"
        );
        for host in [".agents", ".claude"] {
            let installed = root.join(host).join("skills/mesh");
            assert!(installed.join("SKILL.md").is_file());
            assert!(installed.join("references/diagnostics.md").is_file());
        }
    }

    let skill = root.join(".agents/skills/mesh/SKILL.md");
    write_file(&skill, "local edits");
    let conflict = run(&args);
    assert_eq!(conflict.status.code(), Some(1), "{conflict:?}");
    assert!(conflict.stdout.is_empty(), "{conflict:?}");
    let error: serde_json::Value = serde_json::from_slice(&conflict.stderr).unwrap();
    assert_eq!(error["code"], "X0103");
    assert_eq!(std::fs::read_to_string(skill).unwrap(), "local edits");
}

#[test]
fn check_tests_compiles_the_test_dsl_without_running_it() {
    let temp = tempfile::tempdir().unwrap();
    let root = temp.path();
    write_file(
        &root.join("mesh.toml"),
        "[package]\nname = \"app\"\nversion = \"0.1.0\"\n",
    );
    write_file(&root.join("main.mpl"), "fn main() do\nend\n");
    let path = "tests/example.test.mpl";
    let run = |args: &[&str]| {
        Command::new(meshc_bin())
            .args(args)
            .current_dir(root)
            .env("MESH_TEST_RT_LIB_PATH", "")
            .output()
            .unwrap()
    };
    write_file(
        &root.join(path),
        "test(\"runtime failure\") do\n  assert(false)\nend\n",
    );
    let clean = run(&["check", "--tests", "--json"]);
    assert!(
        clean.status.success() && clean.stderr.is_empty(),
        "{clean:?}"
    );

    write_file(
        &root.join(path),
        "test(\"type error\") do\n  assert(missing)\nend\n",
    );
    assert!(run(&["check"]).status.success());
    for args in [
        &["check", "--tests", "--json"][..],
        &["check", path, "--tests", "--json"],
    ] {
        let bad = run(args);
        assert_eq!(bad.status.code(), Some(1), "{bad:?}");
        assert!(bad.stdout.is_empty(), "{bad:?}");
        let diagnostic: serde_json::Value = serde_json::from_slice(&bad.stderr).unwrap();
        assert_eq!(diagnostic["code"], "E0004", "{diagnostic}");
        assert!(
            Path::new(diagnostic["file"].as_str().unwrap()).ends_with(path),
            "{diagnostic}"
        );
    }
}
