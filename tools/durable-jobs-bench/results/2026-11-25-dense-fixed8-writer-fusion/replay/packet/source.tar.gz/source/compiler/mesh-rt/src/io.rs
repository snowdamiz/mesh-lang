//! Console I/O runtime functions for the Mesh standard library.
//!
//! Provides stdin reading and stderr output. Functions match the Mesh
//! module `IO` with `read_line` and `eprintln`.

use crate::gc::mesh_gc_alloc_actor;
use crate::string::{mesh_str, MeshString};

/// Tagged result value for Mesh's Result<T, E> representation.
///
/// Layout matches the codegen layout for sum types:
/// - tag 0 = Ok (first variant)
/// - tag 1 = Err (second variant)
///
/// The value pointer points to the payload (a MeshString in both cases).
#[repr(C)]
pub struct MeshResult {
    pub tag: u8,
    pub value: *mut u8,
}

/// Allocate a MeshResult on the GC heap.
pub(crate) fn alloc_result(tag: u8, value: *mut u8) -> *mut MeshResult {
    unsafe {
        let ptr = mesh_gc_alloc_actor(
            std::mem::size_of::<MeshResult>() as u64,
            std::mem::align_of::<MeshResult>() as u64,
        ) as *mut MeshResult;
        (*ptr).tag = tag;
        (*ptr).value = value;
        ptr
    }
}

/// `Err(message)`, as the result pointer type the caller returns.
pub(crate) fn err_result<T>(message: &str) -> *mut T {
    alloc_result(1, crate::string::mesh_str(message).cast()).cast()
}

/// A scalar (an `Int`, a `Float`'s bits, an opaque integer handle) boxed as
/// the payload of a `Result` or `Option`, which is a pointer. On the GC heap
/// it lives as long as what holds it; a Rust `Box` would leak it.
pub(crate) fn box_scalar<T: Copy>(value: T) -> *mut u8 {
    unsafe {
        let payload = mesh_gc_alloc_actor(
            std::mem::size_of::<T>() as u64,
            std::mem::align_of::<T>().max(8) as u64,
        ) as *mut T;
        payload.write(value);
        payload.cast()
    }
}

/// `Ok(value)` for an `Int`.
pub(crate) fn ok_int(value: i64) -> *mut MeshResult {
    alloc_result(0, box_scalar(value))
}

/// Allocate a MeshResult on the GC heap with the given tag and value.
/// Tag 0 = Ok, tag 1 = Err.
#[no_mangle]
pub extern "C" fn mesh_alloc_result(tag: i64, value: *mut u8) -> *mut u8 {
    alloc_result(tag as u8, value) as *mut u8
}

/// Check if a MeshResult is Ok (tag == 0). Returns 1 for Ok, 0 for Err.
#[no_mangle]
pub extern "C" fn mesh_result_is_ok(result: *mut u8) -> i64 {
    let r = result as *const MeshResult;
    unsafe {
        if (*r).tag == 0 {
            1
        } else {
            0
        }
    }
}

/// Extract the value from a MeshResult (Ok or Err payload).
#[no_mangle]
pub extern "C" fn mesh_result_unwrap(result: *mut u8) -> *mut u8 {
    let r = result as *const MeshResult;
    unsafe { (*r).value }
}

/// Read a line from stdin. Returns a MeshResult (tag 0 = Ok with string,
/// tag 1 = Err with error message string).
///
/// The trailing newline is stripped from the result. At the end of input
/// the result is `Err("end of input")`: were it an empty line, a program
/// reading to the end could not tell it from a blank one, and would loop.
#[no_mangle]
pub extern "C" fn mesh_io_read_line() -> *mut MeshResult {
    read_line_from(&mut std::io::stdin().lock())
}

fn read_line_from(reader: &mut impl std::io::BufRead) -> *mut MeshResult {
    let mut input = String::new();
    match reader.read_line(&mut input) {
        Ok(0) => err_result("end of input"),
        Ok(_) => {
            // Strip trailing newline
            if input.ends_with('\n') {
                input.pop();
                if input.ends_with('\r') {
                    input.pop();
                }
            }
            let s = mesh_str(&input);
            alloc_result(0, s as *mut u8)
        }
        Err(e) => {
            let msg = e.to_string();
            let s = mesh_str(&msg);
            alloc_result(1, s as *mut u8)
        }
    }
}

/// Print a Mesh string to stderr with a trailing newline.
#[no_mangle]
pub extern "C" fn mesh_io_eprintln(s: *const MeshString) {
    unsafe {
        let text = (*s).as_str();
        eprintln!("{}", text);
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::gc::mesh_rt_init;
    use crate::string::mesh_string_new;

    /// A line comes back without its line ending, `\r\n` or `\n`; the end of
    /// input and input that is not UTF-8 are errors.
    #[test]
    fn read_line_strips_its_ending_and_refuses_what_is_not_text() {
        mesh_rt_init();
        let read = |input: &[u8]| {
            let result = read_line_from(&mut std::io::Cursor::new(input.to_vec()));
            let result = unsafe { &*result };
            let text = unsafe { (*(result.value as *const MeshString)).as_str() }.to_string();
            (result.tag, text)
        };
        assert_eq!(read(b"crlf\r\nnext"), (0, "crlf".to_string()));
        assert_eq!(read(b"lf\n"), (0, "lf".to_string()));
        assert_eq!(read(b"last"), (0, "last".to_string()));
        assert_eq!(read(b"\n"), (0, String::new()));
        assert_eq!(read(b""), (1, "end of input".to_string()));
        assert_eq!(read(b"\xff\n").0, 1);
    }

    #[test]
    fn test_alloc_result_ok() {
        mesh_rt_init();
        let s = mesh_string_new(b"hello".as_ptr(), 5);
        let result = alloc_result(0, s as *mut u8);
        unsafe {
            assert_eq!((*result).tag, 0);
            let value = (*result).value as *const MeshString;
            assert_eq!((*value).as_str(), "hello");
        }
    }

    #[test]
    fn test_alloc_result_err() {
        mesh_rt_init();
        let s = mesh_string_new(b"error".as_ptr(), 5);
        let result = alloc_result(1, s as *mut u8);
        unsafe {
            assert_eq!((*result).tag, 1);
            let value = (*result).value as *const MeshString;
            assert_eq!((*value).as_str(), "error");
        }
    }

    #[test]
    fn test_eprintln_does_not_crash() {
        mesh_rt_init();
        let s = mesh_string_new(b"test error".as_ptr(), 10);
        // Just verify it doesn't panic/crash
        mesh_io_eprintln(s);
    }
}
