//! MIR expression to LLVM IR translation.
//!
//! Implements `codegen_expr` which translates each MIR expression variant
//! into corresponding LLVM IR instructions using the alloca+mem2reg pattern
//! for control flow merges.

use inkwell::basic_block::BasicBlock;
use inkwell::intrinsics::Intrinsic;
use inkwell::types::{BasicMetadataTypeEnum, BasicType, StructType};
use inkwell::values::{
    BasicMetadataValueEnum, BasicValue, BasicValueEnum, FunctionValue, IntValue, PointerValue,
    StructValue,
};
use inkwell::IntPredicate;
use mesh_diagnostics::{Code, Diagnostic, LineCol};

use super::group_safety::GroupedSpawn;
use super::intrinsics::get_intrinsic;
use super::pattern::MatchTarget;
use super::types::{closure_type, variant_struct_type};
use super::{CodeGen, BUILT};
use crate::mir::types::mir_type_to_impl_name;
use crate::mir::{
    runtime_location, BinOp, MirChildSpec, MirExpr, MirMatchArm, MirResourceDestructor,
    MirResourceField, MirResourceMoveSource, MirSourceSpan, MirType, SpawnPlacement, UnaryOp,
};
use crate::pattern::compile::{self, compile_match};

impl<'ctx> CodeGen<'ctx> {
    /// Generate LLVM IR for a MIR expression.
    ///
    /// Returns the LLVM value representing the expression result.
    pub(crate) fn codegen_expr(
        &mut self,
        expr: &MirExpr,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        match expr {
            MirExpr::IntLit(val, _) => {
                Ok(self.context.i64_type().const_int(*val as u64, true).into())
            }

            MirExpr::FloatLit(val, _, _) => Ok(self.context.f64_type().const_float(*val).into()),

            MirExpr::BoolLit(val, _) => Ok(self
                .context
                .bool_type()
                .const_int(if *val { 1 } else { 0 }, false)
                .into()),

            MirExpr::StringLit(s, _, _) => self.codegen_string_lit(s),

            MirExpr::Var(name, ty) => self.codegen_var(name, ty),

            MirExpr::BinOp {
                op,
                lhs,
                rhs,
                source_span,
                ..
            } => self.codegen_binop(op, lhs, rhs, *source_span),

            MirExpr::UnaryOp {
                op, operand, ty, ..
            } => self.codegen_unaryop(op, operand, ty),

            MirExpr::Call {
                func,
                args,
                ty,
                source_span,
            } => {
                let value = self.codegen_call(func, args, ty, *source_span)?;
                self.end_after_never(ty)?;
                Ok(value)
            }

            MirExpr::ClosureCall {
                closure, args, ty, ..
            } => {
                let value = self.codegen_closure_call(closure, args, ty)?;
                self.end_after_never(ty)?;
                Ok(value)
            }

            MirExpr::If {
                cond,
                then_body,
                else_body,
                ty,
                ..
            } => self.codegen_if(cond, then_body, else_body, ty),

            MirExpr::Let {
                name,
                ty,
                value,
                body,
            } => self.codegen_let(name, ty, value, body),

            MirExpr::Block(exprs, _ty) => self.codegen_block(exprs),

            MirExpr::Match {
                scrutinee,
                arms,
                ty,
                source_span,
            } => self.codegen_match(scrutinee, arms, ty, *source_span),

            MirExpr::StructLit {
                name,
                fields,
                ty: _,
                ..
            } => self.codegen_struct_lit(name, fields),

            MirExpr::StructUpdate {
                base,
                overrides,
                resource_overrides,
                ty,
                ..
            } => self.codegen_struct_update(base, overrides, resource_overrides, ty),

            MirExpr::FieldAccess {
                object, field, ty, ..
            } => self.codegen_field_access(object, field, ty),

            MirExpr::ConstructVariant {
                type_name,
                variant,
                fields,
                ty: _,
                ..
            } => self.codegen_construct_variant(type_name, variant, fields),

            MirExpr::MakeClosure {
                fn_name,
                captures,
                ty: _,
                ..
            } => self.codegen_make_closure(fn_name, captures),

            MirExpr::ResourceMove { value, source, .. } => {
                self.codegen_resource_move(value, source)
            }

            MirExpr::ResourceBorrow { value, .. } => self.codegen_expr(value),

            MirExpr::ResourceDrop {
                value,
                resource_ty,
                destructor,
            }
            | MirExpr::ResourceDestroy {
                value,
                resource_ty,
                destructor,
                ..
            } => self.codegen_resource_drop(value, resource_ty, destructor),

            MirExpr::Return(inner, _) => self.codegen_return(inner),

            MirExpr::Panic {
                message,
                file,
                source_span,
            } => self.codegen_panic(message, file, *source_span),

            MirExpr::Unit => Ok(self.context.struct_type(&[], false).const_zero().into()),

            // Actor primitives
            MirExpr::ActorSpawn {
                func,
                args,
                priority,
                placement,
                terminate_callback,
                ty: _,
                source_span,
            } => self.codegen_actor_spawn(
                func,
                args,
                *priority,
                *placement,
                terminate_callback.as_deref(),
                *source_span,
            ),

            MirExpr::ActorSend {
                target,
                message,
                ty: _,
                ..
            } => self.codegen_actor_send(target, message),

            MirExpr::ActorReceive {
                handler,
                timeout_ms,
                timeout_body,
                ty,
                ..
            } => self.codegen_actor_receive(
                handler.as_ref(),
                timeout_ms.as_deref(),
                timeout_body.as_deref(),
                ty,
            ),

            MirExpr::ActorSelf { ty: _, .. } => self.codegen_actor_self(),

            MirExpr::ActorLink { target, ty: _, .. } => self.codegen_actor_link(target),

            MirExpr::Shaped { value, .. } => self.codegen_expr(value),

            MirExpr::ListLit { elements, .. } => self.codegen_list_lit(elements),

            MirExpr::While { cond, body, ty, .. } => self.codegen_while(cond, body, ty),

            MirExpr::Break => self.codegen_break(),

            MirExpr::Continue => self.codegen_continue(),

            MirExpr::ForInRange {
                var,
                start,
                end,
                filter,
                body,
                ..
            } => self.codegen_for_in_range(var, start, end, filter.as_deref(), body),

            MirExpr::ForInList {
                var,
                collection,
                filter,
                body,
                elem_ty,
                ..
            } => self.codegen_for_in_list(var, collection, filter.as_deref(), body, elem_ty),

            MirExpr::ForInMap {
                key_var,
                val_var,
                collection,
                filter,
                body,
                key_ty,
                val_ty,
                ..
            } => self.codegen_for_in_map(
                key_var,
                val_var,
                collection,
                filter.as_deref(),
                body,
                key_ty,
                val_ty,
            ),

            MirExpr::ForInSet {
                var,
                collection,
                filter,
                body,
                elem_ty,
                ..
            } => self.codegen_for_in_set(var, collection, filter.as_deref(), body, elem_ty),

            MirExpr::ForInIterator {
                var,
                iterator,
                filter,
                body,
                elem_ty,
                next_fn,
                iter_fn,
                ..
            } => self.codegen_for_in_iterator(
                var,
                iterator,
                filter.as_deref(),
                body,
                elem_ty,
                next_fn,
                iter_fn.as_deref(),
            ),

            MirExpr::SupervisorStart {
                name,
                strategy,
                max_restarts,
                max_seconds,
                children,
                ty: _,
            } => self.codegen_supervisor_start(
                name,
                *strategy,
                *max_restarts,
                *max_seconds,
                children,
            ),

            MirExpr::TailCall { args, .. } => {
                // Step 1: Evaluate ALL arguments to temporary values FIRST.
                // This is critical: if args reference current params (e.g., swap(b, a)),
                // we must read all param values before overwriting any of them.
                let mut new_vals = Vec::with_capacity(args.len());
                for arg in args.iter() {
                    new_vals.push(self.codegen_expr(arg)?);
                }

                // Step 2: Store all evaluated values into parameter allocas.
                for (slot, value) in self.tce_param_slots.clone().into_iter().zip(new_vals) {
                    self.builder
                        .build_store(slot, value)
                        .map_err(Diagnostic::internal)?;
                }

                // Step 3: Emit reduction check for preemptive scheduling.
                // Without this, tight tail-recursive loops would starve other actors.
                if self.emitting_step {
                    self.emit_reduction_check();
                    self.builder
                        .build_return(Some(&self.context.i8_type().const_int(1, false)))
                        .map_err(Diagnostic::internal)?;
                    return Ok(self.context.i64_type().const_zero().into());
                }
                let tce_loop_bb = self
                    .tce_loop_header
                    .ok_or_else(|| Diagnostic::internal("missing tail-call loop header"))?;
                // Step 4: Branch to loop header.
                if let Some(state) = self.tce_reduction_state {
                    self.emit_inline_reduction_check(state, tce_loop_bb);
                } else {
                    self.emit_reduction_check();
                    self.builder
                        .build_unconditional_branch(tce_loop_bb)
                        .expect(BUILT);
                }

                // Return a dummy value -- this block is terminated, the value is never used.
                // Use i64 zero as the dummy (same pattern as Break/Continue).
                Ok(self.context.i64_type().const_zero().into())
            }
        }
    }

    // ── Resources ────────────────────────────────────────────────────

    /// Clear the local `name`, of type `ty`, whose resource has moved or been
    /// destroyed: a later drop of it then does nothing.
    /// Empty the slot of `name`, which a move or drop just took the value
    /// of, with a zero of the slot's own type: a tuple or a boxed payload is
    /// held there as a pointer, whatever the moved value's type says. A
    /// zero of the value's type overran the slot into the frame.
    fn clear_resource_local(&mut self, name: &str) {
        let zero = self.llvm_type(&self.local_types[name]).const_zero();
        self.builder
            .build_store(self.locals[name], zero)
            .expect(BUILT);
    }

    fn codegen_resource_move(
        &mut self,
        value: &MirExpr,
        source: &MirResourceMoveSource,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let moved = self.codegen_expr(value)?;
        match source {
            MirResourceMoveSource::Slot(local) => self.clear_resource_local(local),
            MirResourceMoveSource::Projection {
                root,
                parent_ty,
                parent_destructor,
                field_index,
                nested_field_indices,
            } => {
                let aggregate = self
                    .builder
                    .build_load(
                        self.llvm_type(parent_ty),
                        self.locals[root],
                        "resource_projection_parent",
                    )
                    .expect(BUILT)
                    .into_struct_value();
                self.codegen_resource_projection_siblings(
                    aggregate,
                    parent_destructor,
                    *field_index,
                    nested_field_indices,
                );
                self.clear_resource_local(root);
            }
        }
        Ok(moved)
    }

    /// Destroy the resource fields of `aggregate` other than the one at
    /// `selected_index`, and, down the rest of the moved field's `path`, the
    /// other fields at each level.
    fn codegen_resource_projection_siblings(
        &mut self,
        aggregate: StructValue<'ctx>,
        destructor: &MirResourceDestructor,
        selected_index: u32,
        path: &[u32],
    ) {
        // A projection's parent is a struct, destroyed field by field.
        for field in destructor.fields() {
            let value = self
                .builder
                .build_extract_value(aggregate, field.index, "resource_projection_field")
                .expect(BUILT);
            match path.split_first() {
                _ if field.index != selected_index => self.codegen_field_destructor(value, field),
                Some((&next_index, rest)) => self.codegen_resource_projection_siblings(
                    value.into_struct_value(),
                    &field.destructor,
                    next_index,
                    rest,
                ),
                None => {}
            }
        }
    }

    /// Destroy `value`, the resource field `field` of an aggregate.
    fn codegen_field_destructor(&mut self, value: BasicValueEnum<'ctx>, field: &MirResourceField) {
        self.codegen_resource_destructor(value, &field.ty, &field.destructor)
    }

    /// Run `destroy` on `pointer` unless it is null (moved out already).
    fn codegen_unless_null(
        &mut self,
        pointer: PointerValue<'ctx>,
        name: &str,
        destroy: impl FnOnce(&mut Self),
    ) {
        let is_null = self
            .builder
            .build_is_null(pointer, &format!("{name}_is_null"))
            .expect(BUILT);
        let function = self.current_function();
        let destroy_block = self
            .context
            .append_basic_block(function, &format!("{name}_destroy"));
        let continue_block = self
            .context
            .append_basic_block(function, &format!("{name}_live"));
        self.builder
            .build_conditional_branch(is_null, continue_block, destroy_block)
            .expect(BUILT);
        self.builder.position_at_end(destroy_block);
        destroy(self);
        self.builder
            .build_unconditional_branch(continue_block)
            .expect(BUILT);
        self.builder.position_at_end(continue_block);
    }

    fn codegen_resource_destructor(
        &mut self,
        value: BasicValueEnum<'ctx>,
        resource_ty: &MirType,
        destructor: &MirResourceDestructor,
    ) {
        match destructor {
            MirResourceDestructor::Opaque => {
                let pointer = value.into_pointer_value();
                self.codegen_unless_null(pointer, "resource", |this| {
                    let destroy = get_intrinsic(&this.module, "mesh_resource_destroy");
                    this.builder
                        .build_call(destroy, &[pointer.into()], "")
                        .expect(BUILT);
                })
            }
            MirResourceDestructor::PgConnection => {
                let function = self.current_function();
                let continue_block = self
                    .context
                    .append_basic_block(function, "pg_connection_closed");
                let handle = if value.is_int_value() {
                    value.into_int_value()
                } else {
                    // Generic Result/Option payloads use pointer storage even
                    // when their concrete semantic value is an integer handle.
                    let boxed_handle = value.into_pointer_value();
                    let is_null = self
                        .builder
                        .build_is_null(boxed_handle, "pg_connection_box_is_empty")
                        .expect(BUILT);
                    let unbox_block = self
                        .context
                        .append_basic_block(function, "pg_connection_unbox");
                    self.builder
                        .build_conditional_branch(is_null, continue_block, unbox_block)
                        .expect(BUILT);
                    self.builder.position_at_end(unbox_block);
                    self.builder
                        .build_load(
                            self.context.i64_type(),
                            boxed_handle,
                            "pg_connection_handle",
                        )
                        .expect(BUILT)
                        .into_int_value()
                };
                let is_zero = self
                    .builder
                    .build_int_compare(
                        IntPredicate::EQ,
                        handle,
                        handle.get_type().const_zero(),
                        "pg_connection_is_closed",
                    )
                    .expect(BUILT);
                let close_block = self
                    .context
                    .append_basic_block(function, "pg_connection_close");
                self.builder
                    .build_conditional_branch(is_zero, continue_block, close_block)
                    .expect(BUILT);

                self.builder.position_at_end(close_block);
                let close = get_intrinsic(&self.module, "mesh_pg_close");
                self.builder
                    .build_call(close, &[handle.into()], "")
                    .expect(BUILT);
                self.builder
                    .build_unconditional_branch(continue_block)
                    .expect(BUILT);
                self.builder.position_at_end(continue_block);
            }
            // A tuple is a pointer to the runtime tuple, each element a slot.
            MirResourceDestructor::Aggregate(fields)
                if matches!(resource_ty, MirType::Tuple(_)) =>
            {
                let tuple = value.into_pointer_value();
                self.codegen_unless_null(tuple, "resource_tuple", |this| {
                    for field in fields {
                        let index = this.context.i64_type().const_int(field.index as u64, false);
                        let raw = this
                            .codegen_runtime_call(
                                "mesh_tuple_nth",
                                &[tuple.into(), index.into()],
                                "resource_tuple_field",
                            )
                            .into_int_value();
                        let field_value = if matches!(field.ty, MirType::Tuple(_)) {
                            this.builder
                                .build_int_to_ptr(
                                    raw,
                                    this.context.ptr_type(inkwell::AddressSpace::default()),
                                    "resource_nested_tuple",
                                )
                                .expect(BUILT)
                                .into()
                        } else {
                            let field_ptr = this
                                .materialize_tuple_element_ptr(raw, &field.ty)
                                .expect(BUILT);
                            this.builder
                                .build_load(
                                    this.llvm_type(&field.ty),
                                    field_ptr,
                                    "resource_tuple_value",
                                )
                                .expect(BUILT)
                        };
                        this.codegen_field_destructor(field_value, field);
                    }
                })
            }
            // A struct held by pointer (a boxed payload) is loaded first.
            MirResourceDestructor::Aggregate(fields) if value.is_pointer_value() => {
                let pointer = value.into_pointer_value();
                self.codegen_unless_null(pointer, "resource_aggregate", |this| {
                    let aggregate = this
                        .builder
                        .build_load(this.llvm_type(resource_ty), pointer, "resource_aggregate")
                        .expect(BUILT);
                    this.codegen_aggregate_destructor(aggregate.into_struct_value(), fields)
                })
            }
            MirResourceDestructor::Aggregate(fields) => {
                self.codegen_aggregate_destructor(value.into_struct_value(), fields)
            }
            // A value of a type that holds itself: the type's own function
            // destroys it, given the value itself, loaded when it sits in a
            // box (as a payload that recurs does).
            MirResourceDestructor::Recursive(function) => {
                let destroy = self.functions[function];
                let by_value = self.llvm_type(resource_ty);
                if value.is_pointer_value() && !by_value.is_pointer_type() {
                    let pointer = value.into_pointer_value();
                    self.codegen_unless_null(pointer, "resource_recursive", |this| {
                        let loaded = this
                            .builder
                            .build_load(by_value, pointer, "resource_recursive")
                            .expect(BUILT);
                        this.builder
                            .build_call(destroy, &[loaded.into()], "")
                            .expect(BUILT);
                    })
                } else {
                    self.builder
                        .build_call(destroy, &[value.into()], "")
                        .expect(BUILT);
                }
            }
            MirResourceDestructor::SumVariants(variants) => {
                if variants.is_empty() {
                    return;
                }
                let function = self.current_function();
                let continue_block = self
                    .context
                    .append_basic_block(function, "resource_sum_live");
                let aggregate = if value.is_pointer_value() {
                    // Moving a boxed variant payload clears its pointer before outer cleanup.
                    let pointer = value.into_pointer_value();
                    let is_null = self
                        .builder
                        .build_is_null(pointer, "resource_sum_is_null")
                        .expect(BUILT);
                    let load_block = self
                        .context
                        .append_basic_block(function, "resource_sum_load");
                    self.builder
                        .build_conditional_branch(is_null, continue_block, load_block)
                        .expect(BUILT);
                    self.builder.position_at_end(load_block);
                    self.builder
                        .build_load(self.llvm_type(resource_ty), pointer, "resource_sum")
                        .expect(BUILT)
                        .into_struct_value()
                } else {
                    value.into_struct_value()
                };
                let sum_slot = self
                    .builder
                    .build_alloca(aggregate.get_type(), "resource_sum_slot")
                    .expect(BUILT);
                self.builder.build_store(sum_slot, aggregate).expect(BUILT);
                let tag = self
                    .builder
                    .build_extract_value(aggregate, 0, "resource_sum_tag")
                    .expect(BUILT)
                    .into_int_value();

                for (index, variant) in variants.iter().enumerate() {
                    let destroy_block = self
                        .context
                        .append_basic_block(function, "resource_sum_destroy");
                    let next_block = if index + 1 == variants.len() {
                        continue_block
                    } else {
                        self.context
                            .append_basic_block(function, "resource_sum_next")
                    };
                    let is_variant = self
                        .builder
                        .build_int_compare(
                            IntPredicate::EQ,
                            tag,
                            self.context.i8_type().const_int(variant.tag as u64, false),
                            "resource_sum_is_variant",
                        )
                        .expect(BUILT);
                    self.builder
                        .build_conditional_branch(is_variant, destroy_block, next_block)
                        .expect(BUILT);

                    self.builder.position_at_end(destroy_block);
                    let overlay = variant_struct_type(
                        self.context,
                        &variant.field_types,
                        &self.struct_types,
                        &self.sum_type_layouts,
                    );
                    for field in &variant.resource_fields {
                        let field_ptr = self
                            .builder
                            .build_struct_gep(
                                overlay,
                                sum_slot,
                                field.index + 1,
                                "resource_sum_field_ptr",
                            )
                            .expect(BUILT);
                        let storage_ty = overlay
                            .get_field_type_at_index(field.index + 1)
                            .expect("a resource field is in its variant's layout");
                        let field_value = self
                            .builder
                            .build_load(storage_ty, field_ptr, "resource_sum_field")
                            .expect(BUILT);
                        self.codegen_field_destructor(field_value, field);
                    }
                    self.builder
                        .build_unconditional_branch(continue_block)
                        .expect(BUILT);
                    if next_block != continue_block {
                        self.builder.position_at_end(next_block);
                    }
                }
                self.builder.position_at_end(continue_block);
            }
        }
    }

    /// Destroy the resource `fields` of the struct value `aggregate`.
    fn codegen_aggregate_destructor(
        &mut self,
        aggregate: StructValue<'ctx>,
        fields: &[MirResourceField],
    ) {
        for field in fields {
            let field_value = self
                .builder
                .build_extract_value(aggregate, field.index, "resource_field")
                .expect(BUILT);
            self.codegen_field_destructor(field_value, field);
        }
    }

    fn codegen_resource_drop(
        &mut self,
        value: &MirExpr,
        resource_ty: &MirType,
        destructor: &MirResourceDestructor,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let owned = self.codegen_expr(value)?;
        self.codegen_resource_destructor(owned, resource_ty, destructor);
        if let MirExpr::Var(name, _) = value {
            self.clear_resource_local(name);
        }
        Ok(self.context.struct_type(&[], false).const_zero().into())
    }

    /// Emit a string literal as a static `MeshString` (`{ len, bytes }`).
    ///
    /// Mesh strings are never mutated in place and the GC ignores pointers
    /// outside its own pages, so a literal needs no allocation or copy each
    /// time it is evaluated.
    pub(crate) fn codegen_string_lit(
        &mut self,
        s: &str,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let len = self.context.i64_type().const_int(s.len() as u64, false);
        let bytes = self.context.const_string(s.as_bytes(), false);
        let literal = self
            .context
            .const_struct(&[len.into(), bytes.into()], false);

        let global = self.module.add_global(literal.get_type(), None, ".str");
        global.set_initializer(&literal);
        global.set_constant(true);
        global.set_unnamed_addr(true);
        global.set_alignment(8);

        Ok(global.as_pointer_value().into())
    }

    // ── Variable reference ───────────────────────────────────────────

    fn codegen_var(
        &mut self,
        name: &str,
        ty: &MirType,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        // Math.pi constant (Phase 43) -- accessed without parentheses as a variable
        if name == "mesh_math_pi" {
            return Ok(self
                .context
                .f64_type()
                .const_float(std::f64::consts::PI)
                .into());
        }

        // Load from local variable alloca before looking for function pointers.
        // Local bindings must shadow top-level/runtime functions; otherwise a
        // local like `node_name` can be lowered as the function `@node_name`
        // and then passed into string intrinsics as if it were a MeshString.
        if let Some(alloca) = self.locals.get(name) {
            let alloca = *alloca;
            let llvm_ty = self.llvm_type(ty);
            let val = self
                .builder
                .build_load(llvm_ty, alloca, name)
                .map_err(Diagnostic::internal)?;
            return Ok(val);
        }
        // Lowering names only bound variables and functions: this is a
        // known function or runtime intrinsic. As a value it is a closure
        // with no environment; typed `FnPtr`, the bare pointer.
        let fn_ptr = self
            .fn_item(name)
            .map(|function| function.as_global_value().as_pointer_value())
            .expect("lowering names only bound variables and functions");
        if matches!(ty, MirType::Closure(..)) {
            let null_env = self
                .context
                .ptr_type(inkwell::AddressSpace::default())
                .const_null();
            return Ok(closure_type(self.context)
                .const_named_struct(&[fn_ptr.into(), null_env.into()])
                .into());
        }
        Ok(fn_ptr.into())
    }

    /// The function `name` refers to, unless a local shadows it.
    fn fn_item(&self, name: &str) -> Option<inkwell::values::FunctionValue<'ctx>> {
        if self.locals.contains_key(name) {
            return None;
        }
        self.functions
            .get(name)
            .copied()
            .or_else(|| self.module.get_function(name))
    }

    /// `arg` as the bare function pointer the runtime expects, when it is a
    /// known function by name. Only as a Mesh value is a function a closure.
    fn fn_item_arg(&self, arg: &MirExpr) -> Option<inkwell::values::PointerValue<'ctx>> {
        match arg {
            MirExpr::Var(name, MirType::Closure(..) | MirType::FnPtr(..)) => self
                .fn_item(name)
                .map(|function| function.as_global_value().as_pointer_value()),
            _ => None,
        }
    }

    // ── Binary operations ────────────────────────────────────────────

    /// `at` places a division by zero.
    fn codegen_binop(
        &mut self,
        op: &BinOp,
        lhs: &MirExpr,
        rhs: &MirExpr,
        at: Option<MirSourceSpan>,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        // Short-circuit for boolean And/Or
        match op {
            BinOp::And => return self.codegen_short_circuit_and(lhs, rhs),
            BinOp::Or => return self.codegen_short_circuit_or(lhs, rhs),
            _ => {}
        }

        let lhs_val = self.codegen_expr(lhs)?;
        let rhs_val = self.codegen_expr(rhs)?;

        // Concat operator: list ++ or string ++
        if matches!(op, BinOp::Concat) {
            let (function, name) = match lhs.ty() {
                MirType::Ptr => ("mesh_list_concat", "list_concat"),
                _ => ("mesh_string_concat", "concat"),
            };
            return Ok(self.codegen_runtime_call(
                function,
                &[lhs_val.into(), rhs_val.into()],
                name,
            ));
        }

        // Anything else is arithmetic or a comparison of the operands
        // lowering leaves to the hardware (it calls a user type's operator
        // impl and compares other types by their own functions): Ints, pids,
        // Floats, Bools and Strings.
        match lhs.ty() {
            // A PID is its integer.
            MirType::Int | MirType::Pid(_) => self.codegen_int_binop(op, lhs_val, rhs_val, at),
            MirType::Float => self.codegen_float_binop(op, lhs_val, rhs_val),
            MirType::Bool => {
                // false < true: the bits compare unsigned.
                let predicate = int_predicate(op, false);
                self.builder
                    .build_int_compare(
                        predicate,
                        lhs_val.into_int_value(),
                        rhs_val.into_int_value(),
                        "bcmp",
                    )
                    .map(Into::into)
                    .map_err(Diagnostic::internal)
            }
            _ => self.codegen_string_compare(op, lhs_val, rhs_val),
        }
    }

    /// Call the runtime function `name` for the value it returns. Code is
    /// only generated inside a function body, where the builder is always
    /// positioned, and each runtime function called this way returns a value.
    pub(super) fn codegen_runtime_call(
        &self,
        name: &str,
        args: &[BasicMetadataValueEnum<'ctx>],
        value_name: &str,
    ) -> BasicValueEnum<'ctx> {
        let function = get_intrinsic(&self.module, name);
        self.builder
            .build_call(function, args, value_name)
            .expect("the builder is positioned in a function body")
            .try_as_basic_value()
            .basic()
            .unwrap_or_else(|| panic!("{name} returns a value"))
    }

    fn codegen_int_binop(
        &mut self,
        op: &BinOp,
        lhs: BasicValueEnum<'ctx>,
        rhs: BasicValueEnum<'ctx>,
        at: Option<MirSourceSpan>,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let l = lhs.into_int_value();
        let r = rhs.into_int_value();
        let result = match op {
            BinOp::Add => self.builder.build_int_add(l, r, "add"),
            BinOp::Sub => self.builder.build_int_sub(l, r, "sub"),
            BinOp::Mul => self.builder.build_int_mul(l, r, "mul"),
            BinOp::Div | BinOp::Mod => return Ok(self.codegen_int_div(op, l, r, at)?.into()),
            _ => self
                .builder
                .build_int_compare(int_predicate(op, true), l, r, "cmp"),
        };
        result.map(Into::into).map_err(Diagnostic::internal)
    }

    fn codegen_float_binop(
        &mut self,
        op: &BinOp,
        lhs: BasicValueEnum<'ctx>,
        rhs: BasicValueEnum<'ctx>,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let l = lhs.into_float_value();
        let r = rhs.into_float_value();
        let result: Result<BasicValueEnum<'ctx>, _> = match op {
            BinOp::Add => self.builder.build_float_add(l, r, "fadd").map(Into::into),
            BinOp::Sub => self.builder.build_float_sub(l, r, "fsub").map(Into::into),
            BinOp::Mul => self.builder.build_float_mul(l, r, "fmul").map(Into::into),
            BinOp::Div => self.builder.build_float_div(l, r, "fdiv").map(Into::into),
            BinOp::Mod => self.builder.build_float_rem(l, r, "fmod").map(Into::into),
            _ => {
                use inkwell::FloatPredicate::*;
                let predicate = match op {
                    BinOp::Eq => OEQ,
                    BinOp::NotEq => UNE,
                    BinOp::Lt => OLT,
                    BinOp::Gt => OGT,
                    BinOp::LtEq => OLE,
                    _ => OGE,
                };
                self.builder
                    .build_float_compare(predicate, l, r, "fcmp")
                    .map(Into::into)
            }
        };
        result.map_err(Diagnostic::internal)
    }
    fn codegen_short_circuit_and(
        &mut self,
        lhs: &MirExpr,
        rhs: &MirExpr,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let fn_val = self.current_function();
        let lhs_val = self.codegen_expr(lhs)?.into_int_value();
        let lhs_end_bb = self.builder.get_insert_block().unwrap();

        let rhs_bb = self.context.append_basic_block(fn_val, "and_rhs");
        let merge_bb = self.context.append_basic_block(fn_val, "and_merge");

        self.builder
            .build_conditional_branch(lhs_val, rhs_bb, merge_bb)
            .map_err(Diagnostic::internal)?;

        // RHS block
        self.builder.position_at_end(rhs_bb);
        let rhs_val = self.codegen_expr(rhs)?.into_int_value();
        let rhs_end_bb = self.builder.get_insert_block().unwrap();
        self.builder
            .build_unconditional_branch(merge_bb)
            .map_err(Diagnostic::internal)?;

        // Merge block with phi
        self.builder.position_at_end(merge_bb);
        let phi = self
            .builder
            .build_phi(self.context.bool_type(), "and_result")
            .map_err(Diagnostic::internal)?;

        let false_val = self.context.bool_type().const_int(0, false);
        phi.add_incoming(&[(&false_val, lhs_end_bb), (&rhs_val, rhs_end_bb)]);

        Ok(phi.as_basic_value())
    }

    fn codegen_short_circuit_or(
        &mut self,
        lhs: &MirExpr,
        rhs: &MirExpr,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let fn_val = self.current_function();
        let lhs_val = self.codegen_expr(lhs)?.into_int_value();

        let rhs_bb = self.context.append_basic_block(fn_val, "or_rhs");
        let merge_bb = self.context.append_basic_block(fn_val, "or_merge");

        self.builder
            .build_conditional_branch(lhs_val, merge_bb, rhs_bb)
            .map_err(Diagnostic::internal)?;

        let lhs_end_bb = self.builder.get_insert_block().unwrap();

        // RHS block
        self.builder.position_at_end(rhs_bb);
        let rhs_val = self.codegen_expr(rhs)?.into_int_value();
        let rhs_end_bb = self.builder.get_insert_block().unwrap();
        self.builder
            .build_unconditional_branch(merge_bb)
            .map_err(Diagnostic::internal)?;

        // Merge
        self.builder.position_at_end(merge_bb);
        let phi = self
            .builder
            .build_phi(self.context.bool_type(), "or_result")
            .map_err(Diagnostic::internal)?;

        let true_val = self.context.bool_type().const_int(1, false);
        phi.add_incoming(&[(&true_val, lhs_end_bb), (&rhs_val, rhs_end_bb)]);

        Ok(phi.as_basic_value())
    }

    fn codegen_string_compare(
        &mut self,
        op: &BinOp,
        lhs: BasicValueEnum<'ctx>,
        rhs: BasicValueEnum<'ctx>,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let args = [lhs.into(), rhs.into()];
        if matches!(op, BinOp::Eq | BinOp::NotEq) {
            // mesh_string_eq gives 1 when equal, 0 when not.
            let equal = self
                .codegen_runtime_call("mesh_string_eq", &args, "str_eq")
                .into_int_value();
            let predicate = match op {
                BinOp::Eq => IntPredicate::NE,
                _ => IntPredicate::EQ,
            };
            let zero = equal.get_type().const_zero();
            return self
                .builder
                .build_int_compare(predicate, equal, zero, "str_eq_bool")
                .map(Into::into)
                .map_err(Diagnostic::internal);
        }
        // mesh_string_compare gives -1, 0 or 1: compare that with zero.
        let order = self
            .codegen_runtime_call("mesh_string_compare", &args, "str_cmp")
            .into_int_value();
        let zero = order.get_type().const_zero();
        self.builder
            .build_int_compare(int_predicate(op, true), order, zero, "str_ord")
            .map(Into::into)
            .map_err(Diagnostic::internal)
    }

    // ── Unary operations ─────────────────────────────────────────────

    fn codegen_unaryop(
        &mut self,
        op: &UnaryOp,
        operand: &MirExpr,
        _ty: &MirType,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let val = self.codegen_expr(operand)?;
        match op {
            // Lowering calls a user type's Neg impl; the hardware negates
            // an Int or a Float.
            UnaryOp::Neg if val.is_int_value() => Ok(self
                .builder
                .build_int_neg(val.into_int_value(), "neg")
                .map_err(Diagnostic::internal)?
                .into()),
            UnaryOp::Neg => Ok(self
                .builder
                .build_float_neg(val.into_float_value(), "fneg")
                .map_err(Diagnostic::internal)?
                .into()),
            UnaryOp::Not => {
                let bool_val = val.into_int_value();
                Ok(self
                    .builder
                    .build_not(bool_val, "not")
                    .map_err(Diagnostic::internal)?
                    .into())
            }
        }
    }

    // ── Function calls ───────────────────────────────────────────────

    /// A call of a builtin that compiles to something other than a call of
    /// its runtime function with the evaluated arguments, or `None`. Each
    /// argument is evaluated once, here.
    fn codegen_builtin_call(
        &mut self,
        name: &str,
        args: &[MirExpr],
        ty: &MirType,
        at: Option<MirSourceSpan>,
    ) -> Result<Option<BasicValueEnum<'ctx>>, Diagnostic> {
        let value = match name {
            "__mesh_uniform_decode" => {
                let raw = self.codegen_expr(&args[0])?.into_int_value();
                self.convert_from_list_element(raw, ty)
            }
            "__mesh_uniform_encode" => {
                let value = self.codegen_expr(&args[0])?;
                self.convert_to_list_element(value, args[0].ty())?.into()
            }
            // A service's call helper: `mesh_service_call(pid, tag, args...)`.
            "mesh_service_call" => self.codegen_service_call_helper(args, ty)?,
            // A service's cast helper, the one caller of `mesh_actor_send`
            // (`send` is `ActorSend`): `mesh_actor_send(pid, tag, args...)`.
            "mesh_actor_send" => self.codegen_service_cast_helper(args)?,
            "mesh_node_start" => self.codegen_node_start(args)?,
            "mesh_panic_str_at" => self.codegen_panic_str(&args[0], at)?,
            "mesh_node_monitor" | "mesh_process_monitor" => self.codegen_monitor(args, name)?,
            "mesh_node_connect" | "mesh_global_whereis" | "mesh_global_unregister" => {
                self.codegen_node_string_call(args, name)?
            }
            "mesh_node_spawn" => self.codegen_node_spawn(args, 0, at)?,
            "mesh_node_spawn_link" => self.codegen_node_spawn(args, 1, at)?,
            "mesh_global_register" => self.codegen_global_register(args)?,
            // Strings compare by their bytes, not their pointers.
            "mesh_list_contains" if matches!(args[1].ty(), MirType::String) => {
                let list = self.codegen_expr(&args[0])?;
                let element = self.codegen_expr(&args[1])?;
                let found = self
                    .codegen_runtime_call(
                        "mesh_list_contains_str",
                        &[list.into(), element.into()],
                        "list_contains_str",
                    )
                    .into_int_value();
                self.builder
                    .build_int_truncate(found, self.context.bool_type(), "list_contains_bool")
                    .map_err(Diagnostic::internal)?
                    .into()
            }
            "mesh_int_to_float" => {
                let int_val = self.codegen_expr(&args[0])?.into_int_value();
                self.builder
                    .build_signed_int_to_float(int_val, self.context.f64_type(), "int_to_float")
                    .map_err(Diagnostic::internal)?
                    .into()
            }
            "mesh_float_to_int" => {
                let float_val = self.codegen_expr(&args[0])?.into_float_value();
                self.saturating_float_to_int(float_val, "float_to_int")?
                    .into()
            }
            _ => {
                let int = matches!(args.first().map(MirExpr::ty), Some(MirType::Int));
                let Some((intrinsic, to_int)) = math_intrinsic(name, int) else {
                    return Ok(None);
                };
                let mut values = Vec::with_capacity(args.len() + 1);
                for arg in args {
                    values.push(self.codegen_expr(arg)?.into());
                }
                if intrinsic == "llvm.abs" {
                    // The absolute value of the smallest Int is itself, not poison.
                    values.push(self.context.bool_type().const_zero().into());
                }
                let overload = if int {
                    self.context.i64_type().into()
                } else {
                    self.context.f64_type().into()
                };
                let result = self.codegen_llvm_intrinsic(intrinsic, overload, &values)?;
                if to_int {
                    self.saturating_float_to_int(result.into_float_value(), "float_to_int")?
                        .into()
                } else {
                    result
                }
            }
        };
        Ok(Some(value))
    }

    /// Call the LLVM intrinsic `name` overloaded for `overload`.
    fn codegen_llvm_intrinsic(
        &mut self,
        name: &str,
        overload: inkwell::types::BasicTypeEnum<'ctx>,
        args: &[BasicMetadataValueEnum<'ctx>],
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let declaration = Intrinsic::find(name)
            .and_then(|intrinsic| intrinsic.get_declaration(&self.module, &[overload]))
            .ok_or_else(|| Diagnostic::internal(format!("{name} not found")))?;
        self.builder
            .build_call(declaration, args, name.trim_start_matches("llvm."))
            .map_err(Diagnostic::internal)?
            .try_as_basic_value()
            .basic()
            .ok_or_else(|| Diagnostic::internal(format!("{name} returned void")))
    }

    /// `word`, what the runtime function `name` returned, as a value of type
    /// `ty`. The runtime returns a `Bool` as a wider integer, and other
    /// values it keeps in uniform slots (`mesh_list_get`, `mesh_map_get`) as
    /// the slot's word: a `Float`'s bits, a pointer, or a pointer to a boxed
    /// struct or sum, which a tuple field holds inline when it fits.
    fn runtime_word_as(
        &mut self,
        name: &str,
        word: inkwell::values::IntValue<'ctx>,
        ty: &MirType,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let error = |e: inkwell::builder::BuilderError| Diagnostic::internal(e);
        Ok(match ty {
            MirType::Bool => self
                .builder
                .build_int_truncate(word, self.context.bool_type(), "to_bool")
                .map_err(error)?
                .into(),
            MirType::Float => self
                .builder
                .build_bit_cast(word, self.context.f64_type(), "i64_to_f64")
                .map_err(error)?,
            MirType::Struct(_) | MirType::SumType(_) | MirType::Closure(..)
                if matches!(
                    name,
                    "mesh_tuple_first" | "mesh_tuple_second" | "mesh_tuple_nth"
                ) =>
            {
                let element = self.materialize_tuple_element_ptr(word, ty)?;
                self.builder
                    .build_load(self.llvm_type(ty), element, "tuple_element")
                    .map_err(error)?
            }
            MirType::Struct(_) | MirType::SumType(_) | MirType::Closure(..) => {
                self.convert_from_list_element(word, ty)
            }
            MirType::String | MirType::Ptr => self
                .builder
                .build_int_to_ptr(
                    word,
                    self.context.ptr_type(inkwell::AddressSpace::default()),
                    "i64_to_ptr",
                )
                .map_err(error)?
                .into(),
            _ => word.into(),
        })
    }

    fn direct_utf8_byte_length_input<'mir>(
        &self,
        length: &MirExpr,
        args: &'mir [MirExpr],
    ) -> Option<&'mir MirExpr> {
        let [MirExpr::Call {
            func: convert,
            args: source,
            ty: MirType::Ptr,
            ..
        }] = args
        else {
            return None;
        };
        let [text] = source.as_slice() else {
            return None;
        };
        let is_runtime = |callee: &MirExpr, symbol, param, result| {
            matches!(callee, MirExpr::Var(name, MirType::FnPtr(params, ret))
                if name == symbol && params.as_slice() == [param] && **ret == result
                    && !self.locals.contains_key(name) && !self.functions.contains_key(name))
        };
        // from_utf8 copies the string's byte slice into a temporary Bytes.
        // Keep the calls on targets where forming that slice narrows the u64 header to usize.
        (*text.ty() == MirType::String
            && is_runtime(length, "mesh_bytes_length", MirType::Ptr, MirType::Int)
            && is_runtime(
                convert,
                "mesh_bytes_from_utf8",
                MirType::String,
                MirType::Ptr,
            )
            && self
                .target_machine
                .get_target_data()
                .get_pointer_byte_size(None)
                == 8)
            .then_some(text)
    }

    fn codegen_call(
        &mut self,
        func: &MirExpr,
        args: &[MirExpr],
        ty: &MirType,
        at: Option<MirSourceSpan>,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        if let MirExpr::Var(name, _) = func {
            if name == "mesh_bytes_length" && *ty == MirType::Int {
                if let Some(text) = self.direct_utf8_byte_length_input(func, args) {
                    let text = self.codegen_expr(text)?.into_pointer_value();
                    return Ok(self.codegen_string_byte_length(text)?.into());
                }
            }
            if let Some(value) = self.codegen_builtin_call(name, args, ty, at)? {
                return Ok(value);
            }
        }

        // Check if this is a user-defined function (declared via MirFunction).
        // User functions accept closure params as {ptr, ptr} structs directly.
        // Runtime intrinsics expect closures split into separate (fn_ptr, env_ptr) args.
        let is_user_fn = if let MirExpr::Var(name, _) = func {
            self.functions.contains_key(name)
        } else {
            false
        };

        // Compile arguments, splitting closure structs into (fn_ptr, env_ptr) pairs
        // only for runtime intrinsics that expect separate pointer arguments.
        //
        // A function that may receive a closure has to declare the pair, as
        // mesh_http_route and mesh_ws_serve do: otherwise the closure is boxed
        // and the box passed as the function pointer.
        let target_fn = if let MirExpr::Var(name, _) = func {
            self.functions
                .get(name)
                .copied()
                .or_else(|| self.module.get_function(name))
        } else {
            None
        };
        // Which closure/FnPtr arguments go as a pair: those the declared
        // signature has two pointer parameters for, where the arguments after
        // them still fit. A closure passed as a value (`List.reduce`'s initial
        // accumulator, an `i64` slot) stays whole beside a callback that is
        // split.
        let is_closure_like = |arg: &MirExpr| {
            !is_user_fn && matches!(arg.ty(), MirType::Closure(_, _) | MirType::FnPtr(_, _))
        };
        let expand: Vec<bool> = match target_fn {
            Some(target) => {
                let params = target.get_type().get_param_types();
                let is_ptr = |i: usize| params.get(i).is_some_and(|p| p.is_pointer_type());
                let mut position = 0;
                args.iter()
                    .enumerate()
                    .map(|(i, arg)| {
                        let pair = is_closure_like(arg)
                            && is_ptr(position)
                            && is_ptr(position + 1)
                            && params.len().saturating_sub(position + 2) >= args.len() - i - 1;
                        position += if pair { 2 } else { 1 };
                        pair
                    })
                    .collect()
            }
            // No declared function: a function value, which takes its
            // arguments as Mesh values (a runtime function is one through
            // its wrapper, `wrap_builtin_values`), or `__mesh_make_tuple`,
            // whose arguments are the tuple's elements.
            None => vec![false; args.len()],
        };

        let mut arg_vals: Vec<BasicMetadataValueEnum<'ctx>> = Vec::new();
        for (arg, &should_expand_closures) in args.iter().zip(&expand) {
            // A named function goes to the runtime as the bare pointer it
            // always was -- unless the parameter is a uniform `i64` value slot
            // (`Map.put`, `List.append`), which stores it as the closure value
            // that reading it back expects.
            let wants_pointer = should_expand_closures
                || target_fn
                    .and_then(|f| f.get_type().get_param_types().get(arg_vals.len()).copied())
                    .is_some_and(|param| param.is_pointer_type());
            let fn_item = if is_user_fn || !wants_pointer {
                None
            } else {
                self.fn_item_arg(arg)
            };
            let val = match fn_item {
                Some(fn_ptr) => fn_ptr.into(),
                None => self.codegen_expr(arg)?,
            };
            if fn_item.is_some() && should_expand_closures {
                // Runtime expects (fn_ptr, env_ptr) pairs; env_ptr is null for
                // a function that takes no environment.
                let null = self
                    .context
                    .ptr_type(inkwell::AddressSpace::default())
                    .const_null();
                arg_vals.extend::<[BasicMetadataValueEnum<'ctx>; 2]>([val.into(), null.into()]);
            } else if should_expand_closures {
                // A closure value `{ fn_ptr, env_ptr }`, as its two pointers.
                let closure = val.into_struct_value();
                for (index, name) in [(0, "fn_ptr"), (1, "env_ptr")] {
                    let part = self
                        .builder
                        .build_extract_value(closure, index, name)
                        .map_err(Diagnostic::internal)?;
                    arg_vals.push(part.into());
                }
            } else {
                // A value whose representation differs from the parameter's
                // (a boxed `Option` from the runtime handed to a by-value
                // `{ i8, ptr }` parameter, or the reverse) is converted the
                // way a `let` binding converts it.
                let val = match target_fn
                    .and_then(|f| f.get_type().get_param_types().get(arg_vals.len()).copied())
                    .and_then(|param_ty| inkwell::types::BasicTypeEnum::try_from(param_ty).ok())
                {
                    Some(param_ty) if param_ty != val.get_type() => {
                        self.coerce_value_to_type(val, param_ty)?
                    }
                    _ => val,
                };
                arg_vals.push(val.into());
            }
        }

        if let MirExpr::Var(name, _) = func {
            // Synthetic tuple allocation intrinsic.
            // __mesh_make_tuple(elem0, elem1, ...) -> ptr
            // Allocates { u64 len, u64[N] elements } on the GC heap.
            if name == "__mesh_make_tuple" {
                return self.codegen_make_tuple(&arg_vals);
            }
            // Job.async(f) / Job.map(list, f): the job actor exits once it has
            // sent its result, so a result that is a reference comes with its
            // shape (`job_result_shape`) and the caller receives its own copy.
            // The callback, in its uniform-slot adapter, is the last argument.
            // Channel.try_send of a value that references heap objects: the
            // slot goes with its shape (`resolve_channel_send`).
            let shaped = match name.as_str() {
                "mesh_job_async" | "mesh_job_map" => args.last(),
                "mesh_channel_try_send" => args.get(1),
                _ => None,
            };
            if let Some(MirExpr::Shaped { shape, .. }) = shaped {
                let null = self
                    .context
                    .ptr_type(inkwell::AddressSpace::default())
                    .const_null();
                arg_vals.push(self.shape_table_for_element(shape).unwrap_or(null).into());
                return Ok(self.codegen_runtime_call(
                    &format!("{name}_shaped"),
                    &arg_vals,
                    "shaped",
                ));
            }
            // Timer.send_after(pid, ms, msg) -> mesh_timer_send_after(pid, ms, msg_ptr, msg_size)
            // The 3rd arg (msg) needs message serialization like codegen_actor_send.
            if name == "mesh_timer_send_after" {
                return self.codegen_timer_send_after(args, &arg_vals);
            }
        }

        // Check if it's a direct call to a known function
        if let MirExpr::Var(name, _) = func {
            if let Some(fn_val) = self.functions.get(name).copied() {
                let coerced_args =
                    self.coerce_arguments(&arg_vals, &fn_val.get_type().get_param_types())?;
                let call = self
                    .builder
                    .build_call(fn_val, &coerced_args, "call")
                    .map_err(Diagnostic::internal)?;

                // Insert reduction check after function call
                self.emit_reduction_check();

                if matches!(ty, MirType::Unit) {
                    return Ok(self.context.struct_type(&[], false).const_zero().into());
                }

                let result = call
                    .try_as_basic_value()
                    .basic()
                    .ok_or_else(|| Diagnostic::internal("Function call returned void"))?;

                // User function returning struct when MIR expects Ptr (e.g.,
                // From conversion returning a struct that goes into Result's
                // { i8, ptr } Err variant). Heap-allocate the struct and return
                // a pointer so it survives the current stack frame.
                if let (MirType::Ptr, BasicValueEnum::StructValue(sv)) = (ty, result) {
                    return self.box_value(sv.into(), "struct_to_ptr");
                }

                return Ok(result);
            }

            // Check if it's a runtime intrinsic (don't add reduction check for runtime calls)
            if let Some(fn_val) = self.module.get_function(name) {
                let jobs_operation = match name.as_str() {
                    "mesh_jobs_start" => Some("Jobs.start"),
                    "mesh_jobs_start_effects_v1" => Some("Jobs.start_effects"),
                    "mesh_jobs_drain" => Some("Jobs.drain"),
                    _ => None,
                };
                if let Some(operation) = jobs_operation {
                    let handler = args
                        .get(2)
                        .and_then(MirExpr::var_name)
                        .and_then(|name| self.fn_item(name))
                        .ok_or_else(|| {
                            self.diagnostic_at(
                                at,
                                Code::InvalidJobsStart,
                                format!("`{operation}` needs a named handler"),
                                "the handler is not a named function",
                            )
                            .with_repair(format!(
                                "Define a named top-level function with type `fn(String) -> String` and pass it directly to `{operation}`."
                            ))
                        })?;
                    let symbol = handler.get_name().to_string_lossy().into_owned();
                    self.jobs_handlers.insert(symbol, handler);
                }
                let coerced_args =
                    self.coerce_arguments(&arg_vals, &fn_val.get_type().get_param_types())?;
                let call = self
                    .builder
                    .build_call(fn_val, &coerced_args, "call")
                    .map_err(Diagnostic::internal)?;

                if matches!(ty, MirType::Unit) {
                    return Ok(self.context.struct_type(&[], false).const_zero().into());
                }

                let result = call
                    .try_as_basic_value()
                    .basic()
                    .ok_or_else(|| Diagnostic::internal("Function call returned void"))?;
                return match result {
                    BasicValueEnum::IntValue(word) => self.runtime_word_as(name, word, ty),
                    // A scalar handed back as a pointer-sized word
                    // (`Changeset.valid`'s Bool) is that word.
                    BasicValueEnum::PointerValue(word)
                        if matches!(
                            ty,
                            MirType::Int | MirType::Bool | MirType::Float | MirType::Pid(_)
                        ) =>
                    {
                        let word = self
                            .builder
                            .build_ptr_to_int(word, self.context.i64_type(), "word")
                            .map_err(Diagnostic::internal)?;
                        self.runtime_word_as(name, word, ty)
                    }
                    other => Ok(other),
                };
            }
        }

        // A function value (`x |> f`, where `f` is a local) carries its
        // environment; only a bare pointer is called directly.
        if matches!(func.ty(), MirType::Closure(..)) {
            return self.codegen_closure_call(func, args, ty);
        }

        // Indirect call through a function pointer
        let fn_ptr = self.codegen_expr(func)?;
        let ret_ty = self.llvm_type(ty);
        let param_types: Vec<inkwell::types::BasicMetadataTypeEnum<'ctx>> =
            args.iter().map(|a| self.llvm_type(a.ty()).into()).collect();
        let fn_type = ret_ty.fn_type(&param_types, false);

        let call = self
            .builder
            .build_indirect_call(fn_type, fn_ptr.into_pointer_value(), &arg_vals, "icall")
            .map_err(Diagnostic::internal)?;

        // Insert reduction check after indirect call
        self.emit_reduction_check();

        call.try_as_basic_value()
            .basic()
            .ok_or_else(|| Diagnostic::internal("Indirect call returned void"))
    }

    // ── Closure calls ────────────────────────────────────────────────

    fn codegen_closure_call(
        &mut self,
        closure: &MirExpr,
        args: &[MirExpr],
        ty: &MirType,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let closure_val = self.codegen_expr(closure)?;
        let closure_ty = closure_type(self.context);

        // Alloca for the closure struct so we can GEP into it
        let closure_alloca = self
            .builder
            .build_alloca(closure_ty, "closure_tmp")
            .map_err(Diagnostic::internal)?;
        self.builder
            .build_store(closure_alloca, closure_val)
            .map_err(Diagnostic::internal)?;

        // Load fn_ptr (field 0)
        let fn_ptr_ptr = self
            .builder
            .build_struct_gep(closure_ty, closure_alloca, 0, "fn_ptr_ptr")
            .map_err(Diagnostic::internal)?;
        let fn_ptr = self
            .builder
            .build_load(
                self.context.ptr_type(inkwell::AddressSpace::default()),
                fn_ptr_ptr,
                "fn_ptr",
            )
            .map_err(Diagnostic::internal)?;

        // Load env_ptr (field 1)
        let env_ptr_ptr = self
            .builder
            .build_struct_gep(closure_ty, closure_alloca, 1, "env_ptr_ptr")
            .map_err(Diagnostic::internal)?;
        let env_ptr = self
            .builder
            .build_load(
                self.context.ptr_type(inkwell::AddressSpace::default()),
                env_ptr_ptr,
                "env_ptr",
            )
            .map_err(Diagnostic::internal)?;

        let ptr_ty = self.context.ptr_type(inkwell::AddressSpace::default());
        let fn_ptr = fn_ptr.into_pointer_value();
        let env_ptr = env_ptr.into_pointer_value();
        let mut user_args: Vec<BasicMetadataValueEnum<'ctx>> = Vec::new();
        let mut user_param_types: Vec<inkwell::types::BasicMetadataTypeEnum<'ctx>> = Vec::new();
        // The callee's own parameter types decide the representation each
        // argument is passed in (a runtime `Option` box becomes the by-value
        // `{ i8, ptr }` a Mesh function receives).
        let (declared_params, _) = closure
            .ty()
            .function_parts()
            .expect("the type checker calls only functions");
        for (arg, param_ty) in args.iter().zip(declared_params.to_vec()) {
            // A tuple is passed as the pointer to its heap block, as every
            // function declares a tuple parameter.
            let param_ty = match param_ty {
                MirType::Tuple(_) => MirType::Ptr,
                other => other,
            };
            let expected = self.llvm_type(&param_ty);
            let val = self.codegen_expr(arg)?;
            let val = if val.get_type() != expected {
                self.coerce_value_to_type(val, expected)?
            } else {
                val
            };
            user_args.push(val.into());
            user_param_types.push(expected.into());
        }
        let ret_ty = self.llvm_type(ty);

        // A null environment marks a plain function used as a value
        // (`codegen_var`): it takes no `__env` parameter. The runtime's
        // higher-order functions follow the same convention.
        let fn_val = self.current_function();
        let bare_bb = self.context.append_basic_block(fn_val, "fn_value_bare");
        let closure_bb = self.context.append_basic_block(fn_val, "fn_value_closure");
        let merge_bb = self.context.append_basic_block(fn_val, "fn_value_merge");
        let is_bare = self
            .builder
            .build_is_null(env_ptr, "env_is_null")
            .map_err(Diagnostic::internal)?;
        self.builder
            .build_conditional_branch(is_bare, bare_bb, closure_bb)
            .map_err(Diagnostic::internal)?;

        self.builder.position_at_end(bare_bb);
        let bare_call = self
            .builder
            .build_indirect_call(
                ret_ty.fn_type(&user_param_types, false),
                fn_ptr,
                &user_args,
                "fncall",
            )
            .map_err(Diagnostic::internal)?;
        self.builder
            .build_unconditional_branch(merge_bb)
            .map_err(Diagnostic::internal)?;

        self.builder.position_at_end(closure_bb);
        let mut closure_param_types = vec![ptr_ty.into()];
        closure_param_types.extend(user_param_types);
        let mut closure_args: Vec<BasicMetadataValueEnum<'ctx>> = vec![env_ptr.into()];
        closure_args.extend(user_args);
        let closure_call = self
            .builder
            .build_indirect_call(
                ret_ty.fn_type(&closure_param_types, false),
                fn_ptr,
                &closure_args,
                "clscall",
            )
            .map_err(Diagnostic::internal)?;
        self.builder
            .build_unconditional_branch(merge_bb)
            .map_err(Diagnostic::internal)?;

        self.builder.position_at_end(merge_bb);
        if matches!(ty, MirType::Unit) {
            self.emit_reduction_check();
            return Ok(self.context.struct_type(&[], false).const_zero().into());
        }

        let (bare_val, closure_val) = bare_call
            .try_as_basic_value()
            .basic()
            .zip(closure_call.try_as_basic_value().basic())
            .ok_or_else(|| Diagnostic::internal("Closure call returned void"))?;
        // The phi has to lead its block, so the reduction check follows it.
        let result = self
            .builder
            .build_phi(ret_ty, "fn_value_result")
            .map_err(Diagnostic::internal)?;
        result.add_incoming(&[(&bare_val, bare_bb), (&closure_val, closure_bb)]);
        self.emit_reduction_check();
        Ok(result.as_basic_value())
    }

    // ── If/else expression ───────────────────────────────────────────

    fn codegen_if(
        &mut self,
        cond: &MirExpr,
        then_body: &MirExpr,
        else_body: &MirExpr,
        ty: &MirType,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let fn_val = self.current_function();
        let cond_val = self.codegen_expr(cond)?.into_int_value();

        // LLVM br requires an i1 condition. If the condition is a wider integer
        // (e.g., i64 from mesh_result_is_ok), truncate to i1 (nonzero = true).
        let cond_i1 = if cond_val.get_type().get_bit_width() != 1 {
            self.builder
                .build_int_truncate(cond_val, self.context.bool_type(), "cond_i1")
                .map_err(Diagnostic::internal)?
        } else {
            cond_val
        };

        // An `if`'s type is its value's runtime type: a tuple is `Ptr`.
        let result_ty = self.llvm_type(ty);
        let result_alloca = self
            .builder
            .build_alloca(result_ty, "if_result")
            .map_err(Diagnostic::internal)?;

        let then_bb = self.context.append_basic_block(fn_val, "then");
        let else_bb = self.context.append_basic_block(fn_val, "else");
        let merge_bb = self.context.append_basic_block(fn_val, "if_merge");

        self.builder
            .build_conditional_branch(cond_i1, then_bb, else_bb)
            .map_err(Diagnostic::internal)?;

        // Then branch
        self.builder.position_at_end(then_bb);
        let then_val = self.codegen_expr(then_body)?;
        // Only store result and branch if block is not already terminated
        // (break/continue/return may have terminated the block)
        if self.block_is_open() {
            let then_val = self.coerce_value_to_type(then_val, result_ty)?;
            self.builder
                .build_store(result_alloca, then_val)
                .map_err(Diagnostic::internal)?;
            self.builder
                .build_unconditional_branch(merge_bb)
                .map_err(Diagnostic::internal)?;
        }

        // Else branch
        self.builder.position_at_end(else_bb);
        let else_val = self.codegen_expr(else_body)?;
        if self.block_is_open() {
            let else_val = self.coerce_value_to_type(else_val, result_ty)?;
            self.builder
                .build_store(result_alloca, else_val)
                .map_err(Diagnostic::internal)?;
            self.builder
                .build_unconditional_branch(merge_bb)
                .map_err(Diagnostic::internal)?;
        }

        self.merged_value(merge_bb, result_ty, result_alloca, "if_val")
    }

    /// The value the branches into `merge_bb` left in `slot`, continuing
    /// there. When none of them reaches it (each ended in a `return`,
    /// `break`, `continue` or panic) the block is unreachable, and so is
    /// what follows: no value is read.
    fn merged_value(
        &self,
        merge_bb: inkwell::basic_block::BasicBlock<'ctx>,
        ty: inkwell::types::BasicTypeEnum<'ctx>,
        slot: PointerValue<'ctx>,
        name: &str,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        self.builder.position_at_end(merge_bb);
        if merge_bb.get_first_use().is_none() {
            self.builder
                .build_unreachable()
                .map_err(Diagnostic::internal)?;
            return Ok(ty.const_zero());
        }
        self.builder
            .build_load(ty, slot, name)
            .map_err(Diagnostic::internal)
    }

    /// A call of type Never does not return: its block ends there.
    fn end_after_never(&self, ty: &MirType) -> Result<(), Diagnostic> {
        if *ty == MirType::Never && self.block_is_open() {
            self.builder
                .build_unreachable()
                .map_err(Diagnostic::internal)?;
        }
        Ok(())
    }

    // ── Let binding ──────────────────────────────────────────────────

    fn codegen_let(
        &mut self,
        name: &str,
        ty: &MirType,
        value: &MirExpr,
        body: &MirExpr,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let val = self.codegen_expr(value)?;
        // A runtime function returns a struct or sum value (a `MeshResult`
        // from `mesh_file_read`, a nested struct from `from_json`) as a
        // pointer to it: the variable holds the value.
        let val =
            if matches!(ty, MirType::SumType(_) | MirType::Struct(_)) && val.is_pointer_value() {
                self.builder
                    .build_load(self.llvm_type(ty), val.into_pointer_value(), "deref_sum")
                    .map_err(Diagnostic::internal)?
            } else {
                val
            };
        let saved = self.bind_local(name, ty, val)?;
        let result = self.codegen_expr(body)?;
        self.restore_locals(vec![saved]);
        Ok(result)
    }

    // ── Block expression ─────────────────────────────────────────────

    fn codegen_block(&mut self, exprs: &[MirExpr]) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let mut result = self.context.struct_type(&[], false).const_zero().into();
        for expr in exprs {
            // What follows a `break`, `continue`, `return` or panic never runs.
            if !self.block_is_open() {
                break;
            }
            result = self.codegen_expr(expr)?;
        }
        Ok(result)
    }

    // ── Pattern match ────────────────────────────────────────────────

    /// A value no arm accepts panics at `at`.
    fn codegen_match(
        &mut self,
        scrutinee: &MirExpr,
        arms: &[MirMatchArm],
        ty: &MirType,
        at: Option<MirSourceSpan>,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        // `case (a, b) do (0, y) -> .. end` (and a clause function's
        // parameters) match the values as columns, without building the tuple.
        if let MirExpr::Call { func, args, .. } = scrutinee {
            if matches!(func.as_ref(), MirExpr::Var(name, _) if name == "__mesh_make_tuple")
                && compile::arms_match_columns(arms, args.len())
            {
                return self.codegen_match_columns(args, arms, ty, at);
            }
        }

        // Evaluate the scrutinee
        let scrutinee_val = self.codegen_expr(scrutinee)?;
        let scrutinee_ty = scrutinee.ty();

        // Alloca for the scrutinee so pattern codegen can GEP into it.
        // For runtime-returned sum types (heap pointers), the value was already
        // dereferenced at the let binding site, so here it's a proper struct value.
        let scrutinee_llvm_ty = self.llvm_type(scrutinee_ty);
        let scrutinee_alloca = if matches!(scrutinee_ty, MirType::SumType(_))
            && scrutinee_val.is_pointer_value()
            && !scrutinee_llvm_ty.is_pointer_type()
        {
            // Rare case: scrutinee is a direct pointer to a sum type
            // (e.g., inline case on a function call result). Use it directly.
            scrutinee_val.into_pointer_value()
        } else {
            let alloca = self
                .builder
                .build_alloca(scrutinee_llvm_ty, "scrutinee")
                .map_err(Diagnostic::internal)?;
            self.builder
                .build_store(alloca, scrutinee_val)
                .map_err(Diagnostic::internal)?;
            alloca
        };

        // Compile pattern to decision tree. A failure names the function.
        let fn_name = self.current_function_name();
        let tree = compile_match(scrutinee_ty, arms, &fn_name, 0, &self.sum_type_defs);

        // Alloca for the match result
        let result_ty = self.llvm_type(ty);
        let result_alloca = self
            .builder
            .build_alloca(result_ty, "match_result")
            .map_err(Diagnostic::internal)?;

        let fn_val = self.current_function();
        let merge_bb = self.context.append_basic_block(fn_val, "match_merge");

        // Generate code for the decision tree
        self.codegen_decision_tree(
            &tree,
            MatchTarget {
                scrutinee: scrutinee_alloca,
                scrutinee_ty,
                arms,
                result_ty: ty,
                result: result_alloca,
                merge_bb,
                at,
            },
        )?;

        self.merged_value(merge_bb, result_ty, result_alloca, "match_val")
    }

    /// Match `arms` against several values at once, held in a stack struct
    /// (see `compile::compile_match_columns`).
    fn codegen_match_columns(
        &mut self,
        values: &[MirExpr],
        arms: &[MirMatchArm],
        ty: &MirType,
        at: Option<MirSourceSpan>,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let column_types: Vec<MirType> = values.iter().map(|value| value.ty().clone()).collect();
        let scrutinee_ty = MirType::Tuple(column_types.clone());
        let struct_ty = self.llvm_type(&scrutinee_ty).into_struct_type();
        let scrutinee_alloca = self
            .builder
            .build_alloca(struct_ty, "columns")
            .map_err(Diagnostic::internal)?;
        for (index, (value, column_ty)) in values.iter().zip(&column_types).enumerate() {
            let value = self.codegen_expr(value)?;
            // A runtime function returns an Option or a Result as a pointer
            // to it; the column holds the value, as `codegen_match` reads
            // one through the pointer. Its tag was read from the pointer's
            // low byte, so `(String.to_int(s), n)` never matched `Some`.
            let column_llvm = self.llvm_type(column_ty);
            let value = if value.is_pointer_value() && !column_llvm.is_pointer_type() {
                self.builder
                    .build_load(column_llvm, value.into_pointer_value(), "column_value")
                    .map_err(Diagnostic::internal)?
            } else {
                value
            };
            let slot = self
                .builder
                .build_struct_gep(struct_ty, scrutinee_alloca, index as u32, "column")
                .map_err(Diagnostic::internal)?;
            self.builder
                .build_store(slot, value)
                .map_err(Diagnostic::internal)?;
        }

        let fn_name = self.current_function_name();
        let tree =
            compile::compile_match_columns(&column_types, arms, &fn_name, 0, &self.sum_type_defs);
        let result_ty = self.llvm_type(ty);
        let result_alloca = self
            .builder
            .build_alloca(result_ty, "match_result")
            .map_err(Diagnostic::internal)?;
        let merge_bb = self
            .context
            .append_basic_block(self.current_function(), "match_merge");
        self.codegen_decision_tree(
            &tree,
            MatchTarget {
                scrutinee: scrutinee_alloca,
                scrutinee_ty: &scrutinee_ty,
                arms,
                result_ty: ty,
                result: result_alloca,
                merge_bb,
                at,
            },
        )?;
        self.merged_value(merge_bb, result_ty, result_alloca, "match_val")
    }

    // ── Struct literal ───────────────────────────────────────────────

    /// A struct literal: each field's value, evaluated in the order the
    /// literal writes them, stored in the field its name gives. A field the
    /// literal leaves out (a schema's timestamps) is zero.
    fn codegen_struct_lit(
        &mut self,
        name: &str,
        fields: &[(String, MirExpr)],
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let (struct_ty, declared) = self.struct_layout(&MirType::Struct(name.to_string()));

        let alloca = self
            .builder
            .build_alloca(struct_ty, "struct_lit")
            .map_err(Diagnostic::internal)?;
        self.builder
            .build_store(alloca, struct_ty.const_zero())
            .map_err(Diagnostic::internal)?;

        for (field_name, field_expr) in fields {
            let val = self.codegen_expr(field_expr)?;
            let index = declared
                .iter()
                .position(|(declared_name, _)| declared_name == field_name)
                .expect("the type checker admits only a struct's own fields");
            let field_ptr = self
                .builder
                .build_struct_gep(struct_ty, alloca, index as u32, "field_ptr")
                .map_err(Diagnostic::internal)?;
            self.builder
                .build_store(field_ptr, val)
                .map_err(Diagnostic::internal)?;
        }

        let result = self
            .builder
            .build_load(struct_ty.as_basic_type_enum(), alloca, "struct_val")
            .map_err(Diagnostic::internal)?;

        Ok(result)
    }

    // ── Struct update ─────────────────────────────────────────────────

    /// The LLVM type and fields of the struct type `ty` (a field access or a
    /// struct update is on a struct, as the type checker has it).
    fn struct_layout(&self, ty: &MirType) -> (StructType<'ctx>, Vec<(String, MirType)>) {
        let name = mir_type_to_impl_name(ty);
        (
            self.struct_types[&name],
            self.mir_struct_defs[&name].clone(),
        )
    }

    /// `base` with the fields `overrides` names replaced. A replaced field
    /// that holds a resource destroys its old value.
    fn codegen_struct_update(
        &mut self,
        base: &MirExpr,
        overrides: &[(String, MirExpr)],
        resource_overrides: &[MirResourceField],
        ty: &MirType,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let (_, field_defs) = self.struct_layout(ty);
        let base_val = self.codegen_expr(base)?.into_struct_value();
        let mut updated = base_val;
        for (index, (field_name, _)) in field_defs.iter().enumerate() {
            let Some((_, replacement)) = overrides.iter().find(|(name, _)| name == field_name)
            else {
                continue;
            };
            let index = index as u32;
            let replacement = self.codegen_expr(replacement)?;
            if let Some(resource) = resource_overrides.iter().find(|r| r.index == index) {
                let old_value = self
                    .builder
                    .build_extract_value(base_val, index, "old_resource")
                    .map_err(Diagnostic::internal)?;
                self.codegen_field_destructor(old_value, resource);
            }
            updated = self
                .builder
                .build_insert_value(updated, replacement, index, "struct_update")
                .map_err(Diagnostic::internal)?
                .into_struct_value();
        }
        Ok(updated.into())
    }

    // ── Field access ─────────────────────────────────────────────────

    fn codegen_field_access(
        &mut self,
        object: &MirExpr,
        field: &str,
        ty: &MirType,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let obj_val = self.codegen_expr(object)?;
        let (struct_ty, fields) = self.struct_layout(object.ty());
        let field_idx = fields
            .iter()
            .position(|(name, _)| name == field)
            .ok_or_else(|| {
                Diagnostic::internal(format!("no field `{field}` in {:?}", object.ty()))
            })?;

        let alloca = self
            .builder
            .build_alloca(struct_ty.as_basic_type_enum(), "obj_tmp")
            .map_err(Diagnostic::internal)?;
        self.builder
            .build_store(alloca, obj_val)
            .map_err(Diagnostic::internal)?;

        let field_ptr = self
            .builder
            .build_struct_gep(struct_ty, alloca, field_idx as u32, "field_ptr")
            .map_err(Diagnostic::internal)?;

        let result_ty = self.llvm_type(ty);
        let result = self
            .builder
            .build_load(result_ty, field_ptr, "field_val")
            .map_err(Diagnostic::internal)?;

        Ok(result)
    }

    // ── Sum type variant construction ────────────────────────────────

    fn codegen_construct_variant(
        &mut self,
        type_name: &str,
        variant: &str,
        fields: &[MirExpr],
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let sum_layout = self
            .lookup_sum_type_layout(type_name)
            .ok_or_else(|| Diagnostic::internal(format!("Unknown sum type '{}'", type_name)))?;
        let sum_layout = *sum_layout;

        let sum_def = self
            .lookup_sum_type_def(type_name)
            .ok_or_else(|| Diagnostic::internal(format!("Unknown sum type def '{}'", type_name)))?
            .clone();

        let variant_def = sum_def
            .variants
            .iter()
            .find(|v| v.name == variant)
            .ok_or_else(|| {
                Diagnostic::internal(format!("Unknown variant '{}.{}'", type_name, variant))
            })?;

        let tag = variant_def.tag;

        // Alloca the sum type
        let alloca = self
            .builder
            .build_alloca(sum_layout.as_basic_type_enum(), "variant")
            .map_err(Diagnostic::internal)?;

        // Store the tag at field 0
        let tag_ptr = self
            .builder
            .build_struct_gep(sum_layout, alloca, 0, "tag_ptr")
            .map_err(Diagnostic::internal)?;
        self.builder
            .build_store(tag_ptr, self.context.i8_type().const_int(tag as u64, false))
            .map_err(Diagnostic::internal)?;

        // Store fields: create variant overlay struct type and GEP into it
        if !fields.is_empty() {
            let field_types: Vec<MirType> = variant_def.fields.clone();
            let variant_ty = variant_struct_type(
                self.context,
                &field_types,
                &self.struct_types,
                &self.sum_type_layouts,
            );

            // Store each field via the variant overlay.
            // Generic builtin Result/Option constructors often use the canonical
            // {i8, ptr} layout even when the source-level payload is scalar
            // (e.g. Ok(1) for Result<Int, String>). In those cases we must box
            // the payload before storing it so callers can safely treat the slot
            // as a pointer during pattern matching / try-lowering.
            for (i, field_expr) in fields.iter().enumerate() {
                let val = self.codegen_expr(field_expr)?;
                let expected_field_ty = field_types.get(i).unwrap_or(field_expr.ty());
                let val = if matches!(expected_field_ty, MirType::Ptr | MirType::Struct(_))
                    && !val.is_pointer_value()
                {
                    self.box_value(val, "variant_box")?
                } else {
                    val
                };

                // GEP into the variant overlay: field 0 is tag, field 1+ are data fields
                let field_ptr = self
                    .builder
                    .build_struct_gep(variant_ty, alloca, (i + 1) as u32, "vfield_ptr")
                    .map_err(Diagnostic::internal)?;
                self.builder
                    .build_store(field_ptr, val)
                    .map_err(Diagnostic::internal)?;
            }
        }

        // Load the complete sum type value
        let result = self
            .builder
            .build_load(sum_layout.as_basic_type_enum(), alloca, "variant_val")
            .map_err(Diagnostic::internal)?;

        Ok(result)
    }

    /// Box a non-pointer sum payload on the GC heap so generic {i8, ptr}
    /// sum layouts (like builtin Result/Option) can safely carry scalar
    /// values such as Int, Bool, and Float.
    pub(super) fn box_value(
        &self,
        val: BasicValueEnum<'ctx>,
        name: &str,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let size = val.get_type().size_of().expect("a value's type has a size");
        let heap_ptr = self.gc_alloc(size, name);
        self.builder
            .build_store(heap_ptr, val)
            .map_err(Diagnostic::internal)?;
        Ok(heap_ptr.into())
    }

    /// `size` bytes on the GC heap, 8-aligned.
    fn gc_alloc(&self, size: IntValue<'ctx>, name: &str) -> PointerValue<'ctx> {
        let align = self.context.i64_type().const_int(8, false);
        self.codegen_runtime_call("mesh_gc_alloc_actor", &[size.into(), align.into()], name)
            .into_pointer_value()
    }

    /// A buffer on the GC heap holding `words`.
    fn heap_words(
        &mut self,
        words: &[IntValue<'ctx>],
        name: &str,
    ) -> Result<PointerValue<'ctx>, Diagnostic> {
        let i64_ty = self.context.i64_type();
        let buffer = self.gc_alloc(i64_ty.const_int(8 * words.len() as u64, false), name);
        for (index, &word) in words.iter().enumerate() {
            let slot = unsafe {
                self.builder
                    .build_gep(
                        i64_ty,
                        buffer,
                        &[i64_ty.const_int(index as u64, false)],
                        "word",
                    )
                    .map_err(Diagnostic::internal)?
            };
            self.builder
                .build_store(slot, word)
                .map_err(Diagnostic::internal)?;
        }
        Ok(buffer)
    }

    /// `args` as the called function's `params` take them, where the MIR
    /// value and the declared parameter differ in representation: a narrower
    /// integer is widened, a word is a pointer or a pointer a word (runtime
    /// functions keep any value as a word), a `Float` goes into such a word
    /// bit for bit, a unit is zero or null, and a struct goes boxed where a
    /// pointer or a word is taken.
    fn coerce_arguments(
        &mut self,
        args: &[BasicMetadataValueEnum<'ctx>],
        params: &[BasicMetadataTypeEnum<'ctx>],
    ) -> Result<Vec<BasicMetadataValueEnum<'ctx>>, Diagnostic> {
        let mut coerced = args.to_vec();
        for (arg, param) in coerced.iter_mut().zip(params) {
            *arg = self.coerce_argument(*arg, *param)?;
        }
        Ok(coerced)
    }

    fn coerce_argument(
        &mut self,
        arg: BasicMetadataValueEnum<'ctx>,
        param: BasicMetadataTypeEnum<'ctx>,
    ) -> Result<BasicMetadataValueEnum<'ctx>, Diagnostic> {
        use BasicMetadataTypeEnum as Param;
        use BasicMetadataValueEnum as Arg;
        let error = |e: inkwell::builder::BuilderError| Diagnostic::internal(e);
        Ok(match (arg, param) {
            (Arg::IntValue(value), Param::IntType(param))
                if value.get_type().get_bit_width() < param.get_bit_width() =>
            {
                self.builder
                    .build_int_z_extend(value, param, "zext_arg")
                    .map_err(error)?
                    .into()
            }
            (Arg::PointerValue(value), Param::IntType(param)) if param.get_bit_width() == 64 => {
                self.builder
                    .build_ptr_to_int(value, param, "ptr_to_i64")
                    .map_err(error)?
                    .into()
            }
            (Arg::FloatValue(value), Param::IntType(param)) if param.get_bit_width() == 64 => self
                .builder
                .build_bit_cast(value, param, "f64_to_i64")
                .map_err(error)?
                .into(),
            (Arg::StructValue(unit), Param::IntType(param))
                if unit.get_type().count_fields() == 0 =>
            {
                param.const_zero().into()
            }
            (Arg::StructValue(value), Param::IntType(param)) if param.get_bit_width() == 64 => {
                let boxed = self.box_value(value.into(), "arg_struct_heap")?;
                self.builder
                    .build_ptr_to_int(boxed.into_pointer_value(), param, "struct_ptr_to_i64")
                    .map_err(error)?
                    .into()
            }
            (arg, _) => arg,
        })
    }

    // ── Closure creation ─────────────────────────────────────────────

    fn codegen_make_closure(
        &mut self,
        fn_name: &str,
        captures: &[MirExpr],
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let cls_ty = closure_type(self.context);

        // Get the function pointer
        let fn_val = self.functions.get(fn_name).ok_or_else(|| {
            Diagnostic::internal(format!("Closure function '{}' not found", fn_name))
        })?;
        let fn_ptr = fn_val.as_global_value().as_pointer_value();

        // Allocate environment on GC heap.
        // Mesh closures always have __env as first param, so env_ptr must be
        // non-null even for zero-capture closures. This ensures runtime HOFs
        // (map, filter, reduce) use the closure calling convention fn(env, ...).
        let env_ptr = if captures.is_empty() {
            // No captures -> allocate a minimal 8-byte env (non-null sentinel).
            self.gc_alloc(self.context.i64_type().const_int(8, false), "env_dummy")
        } else {
            // The env struct: a pointer to the shape table that describes it
            // (so it can be copied to another actor), then the captures. The
            // closure function reads it back the same way (`compile_function`).
            let mut env_fields: Vec<inkwell::types::BasicTypeEnum<'ctx>> = vec![self
                .context
                .ptr_type(inkwell::AddressSpace::default())
                .into()];
            env_fields.extend(captures.iter().map(|c| self.llvm_type(c.ty())));
            let env_struct_ty = self.context.struct_type(&env_fields, false);
            let capture_shapes: Vec<_> = captures.iter().map(|c| self.message_shape(c)).collect();
            let env_shape = self.shape_table_for_env(&capture_shapes, env_struct_ty);

            // Calculate size via target data
            let target_data = self.target_machine.get_target_data();
            let env_size = target_data.get_store_size(&env_struct_ty);

            let env_ptr_val = self.gc_alloc(
                self.context.i64_type().const_int(env_size, false),
                "env_raw",
            );
            // Fresh memory is zeroed: no table means nothing to copy.
            if let Some(env_shape) = env_shape {
                self.builder
                    .build_store(env_ptr_val, env_shape)
                    .map_err(Diagnostic::internal)?;
            }

            // Store each captured value into the env struct
            for (i, cap_expr) in captures.iter().enumerate() {
                let val = self.codegen_expr(cap_expr)?;
                let field_ptr = self
                    .builder
                    .build_struct_gep(env_struct_ty, env_ptr_val, i as u32 + 1, "cap_ptr")
                    .map_err(Diagnostic::internal)?;
                self.builder
                    .build_store(field_ptr, val)
                    .map_err(Diagnostic::internal)?;
            }

            env_ptr_val
        };

        // Pack into closure struct { fn_ptr, env_ptr }
        let closure_alloca = self
            .builder
            .build_alloca(cls_ty, "closure")
            .map_err(Diagnostic::internal)?;

        let fn_slot = self
            .builder
            .build_struct_gep(cls_ty, closure_alloca, 0, "fn_slot")
            .map_err(Diagnostic::internal)?;
        self.builder
            .build_store(fn_slot, fn_ptr)
            .map_err(Diagnostic::internal)?;

        let env_slot = self
            .builder
            .build_struct_gep(cls_ty, closure_alloca, 1, "env_slot")
            .map_err(Diagnostic::internal)?;
        self.builder
            .build_store(env_slot, env_ptr)
            .map_err(Diagnostic::internal)?;

        let result = self
            .builder
            .build_load(cls_ty.as_basic_type_enum(), closure_alloca, "closure_val")
            .map_err(Diagnostic::internal)?;

        Ok(result)
    }

    // ── Return ───────────────────────────────────────────────────────

    fn codegen_return(&mut self, inner: &MirExpr) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let val = self.codegen_expr(inner)?;
        // The value in the function's own return representation, as a
        // function's last expression is (`compile_function`).
        let ret_ty = self
            .current_function()
            .get_type()
            .get_return_type()
            .expect("a Mesh function returns a value");
        let return_val = self.coerce_value_to_type(val, ret_ty)?;

        self.builder
            .build_return(Some(&return_val))
            .map_err(Diagnostic::internal)?;
        // Return a dummy value since we've already emitted a return
        Ok(self.context.struct_type(&[], false).const_zero().into())
    }

    // ── Actor primitives ──────────────────────────────────────────────

    fn codegen_actor_spawn(
        &mut self,
        func: &MirExpr,
        args: &[MirExpr],
        priority: u8,
        placement: SpawnPlacement,
        terminate_callback: Option<&MirExpr>,
        at: Option<MirSourceSpan>,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let ptr_ty = self.context.ptr_type(inkwell::AddressSpace::default());
        let i64_ty = self.context.i64_type();

        // Get function pointer for the actor entry function: by name, since a
        // function evaluated as a value is a closure.
        let entry_name = func
            .var_name()
            .expect("the type checker spawns an actor by its name (E0089)");
        let entry = self.fn_item(entry_name).ok_or_else(|| {
            Diagnostic::internal(format!("unresolved spawn entry `{entry_name}`"))
        })?;
        let fn_ptr = entry.as_global_value().as_pointer_value();
        let terminate = terminate_callback
            .map(|callback| {
                let name = callback
                    .var_name()
                    .ok_or_else(|| Diagnostic::internal("expected a named terminate callback"))?;
                self.module.get_function(name).ok_or_else(|| {
                    Diagnostic::internal(format!("unresolved terminate callback `{name}`"))
                })
            })
            .transpose()?;

        // Serialize arguments into a buffer of 8-byte slots, which is how the
        // actor wrapper reads them back. An aggregate that fits a word travels
        // as its bits and a larger one in a box (see `coerce_to_i64`); packing
        // structs at their full size put every later argument at an offset the
        // wrapper never looked at.
        let (args_ptr, args_size) = if args.is_empty() {
            (ptr_ty.const_null(), i64_ty.const_int(0, false))
        } else {
            let slots: Vec<inkwell::values::IntValue<'ctx>> = args
                .iter()
                .map(|a| {
                    let value = self.codegen_expr(a)?;
                    self.coerce_to_i64(value)
                })
                .collect::<Result<Vec<_>, _>>()?;
            // On the GC heap, not the stack: the actor reads them after the
            // caller returns. The runtime recognises a buffer on the
            // spawner's heap, copies it for the new actor and keeps what its
            // words point at alive, so this buffer is ordinary garbage once
            // the call returns.
            let buffer = self.heap_words(&slots, "spawn_args")?;
            (buffer, i64_ty.const_int(8 * slots.len() as u64, false))
        };

        // With a shape the new actor gets its own copy of what the arguments
        // reference; without one they are all plain values.
        let shapes: Vec<_> = args.iter().map(|arg| self.message_shape(arg)).collect();
        let shape = self.shape_table_for_slots(&shapes);
        let mut spawn_args: Vec<BasicMetadataValueEnum<'ctx>> =
            vec![fn_ptr.into(), args_ptr.into(), args_size.into()];
        let spawn_fn = match placement {
            SpawnPlacement::Grouped => {
                let expected = super::types::llvm_fn_type(
                    self.context,
                    &[MirType::Ptr, MirType::Ptr],
                    &MirType::Unit,
                    &self.struct_types,
                    &self.sum_type_layouts,
                );
                if terminate.is_some_and(|callback| callback.get_type() != expected) {
                    return Err(Diagnostic::internal(format!(
                        "invalid terminate callback signature for `{entry_name}`"
                    )));
                }
                self.grouped_spawns.push(GroupedSpawn {
                    entry,
                    terminate,
                    at,
                });
                spawn_args.push(shape.unwrap_or_else(|| ptr_ty.const_null()).into());
                let callback = terminate
                    .map(|callback| callback.as_global_value().as_pointer_value())
                    .unwrap_or_else(|| ptr_ty.const_null());
                spawn_args.push(callback.into());
                "mesh_actor_spawn_grouped"
            }
            SpawnPlacement::Shared => {
                spawn_args.push(
                    self.context
                        .i8_type()
                        .const_int(priority as u64, false)
                        .into(),
                );
                if let Some(shape) = shape {
                    spawn_args.push(shape.into());
                    "mesh_actor_spawn_shaped"
                } else {
                    "mesh_actor_spawn"
                }
            }
        };
        let pid_val = self.codegen_runtime_call(spawn_fn, &spawn_args, "pid");

        if (match placement {
            SpawnPlacement::Grouped => self.grouped_step_enabled,
            SpawnPlacement::Shared => self.movable_step_enabled,
        }) && terminate.is_none()
            && args
                .iter()
                .all(|arg| super::grouped_step::frame_word(arg.ty()))
        {
            self.step_sites.push(super::grouped_step::SpawnSite {
                actor: entry_name.to_owned(),
                original: fn_ptr,
                args: args_ptr,
                size: args_size,
                shape: shape.unwrap_or_else(|| ptr_ty.const_null()),
                pid: pid_val.into_int_value(),
                shared_priority: (placement == SpawnPlacement::Shared).then_some(priority),
            });
        }

        if let (SpawnPlacement::Shared, Some(callback)) = (placement, terminate) {
            let cb_ptr = callback.as_global_value().as_pointer_value();
            let set_terminate_fn = get_intrinsic(&self.module, "mesh_actor_set_terminate");
            self.builder
                .build_call(set_terminate_fn, &[pid_val.into(), cb_ptr.into()], "")
                .map_err(Diagnostic::internal)?;
        }

        Ok(pid_val)
    }

    fn codegen_actor_send(
        &mut self,
        target: &MirExpr,
        message: &MirExpr,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        // Evaluate the target PID (i64).
        let target_val = self.codegen_expr(target)?.into_int_value();

        let msg_val = self.codegen_expr(message)?;
        let (msg_ptr, msg_size, shape_table) = self.message_bytes(message, msg_val)?;

        // A message that references heap values points into this actor's heap.
        // The shape table tells the runtime where, so the receiver gets a copy.
        // Call mesh_actor_send[_shaped](target_pid, msg_ptr, msg_size[, shape])
        let mut send_args: Vec<BasicMetadataValueEnum<'ctx>> =
            vec![target_val.into(), msg_ptr.into(), msg_size.into()];
        let send_fn = match shape_table {
            Some(shape_table) => {
                send_args.push(shape_table.into());
                "mesh_actor_send_shaped"
            }
            None => "mesh_actor_send",
        };
        Ok(self.codegen_runtime_call(send_fn, &send_args, "send_status"))
    }

    /// `value`, what `message` evaluated to, as the runtime takes a message: a
    /// pointer to its bytes on the stack, their size, and the shape table
    /// when it references heap values. Unit is no bytes.
    fn message_bytes(
        &mut self,
        message: &MirExpr,
        value: BasicValueEnum<'ctx>,
    ) -> Result<
        (
            inkwell::values::PointerValue<'ctx>,
            inkwell::values::IntValue<'ctx>,
            Option<inkwell::values::PointerValue<'ctx>>,
        ),
        Diagnostic,
    > {
        let i64_ty = self.context.i64_type();
        if matches!(message.ty(), MirType::Unit) {
            let null = self
                .context
                .ptr_type(inkwell::AddressSpace::default())
                .const_null();
            return Ok((null, i64_ty.const_int(0, false), None));
        }
        let msg_ty = self.llvm_type(message.ty());
        let shape_table = self.shape_table_for_value(&self.message_shape(message), msg_ty);
        let msg_alloca = self
            .builder
            .build_alloca(msg_ty, "msg_buf")
            .map_err(Diagnostic::internal)?;
        self.builder
            .build_store(msg_alloca, value)
            .map_err(Diagnostic::internal)?;
        let size = self
            .target_machine
            .get_target_data()
            .get_store_size(&msg_ty);
        Ok((msg_alloca, i64_ty.const_int(size, false), shape_table))
    }

    /// `Process.monitor(pid, message)` and `Node.monitor(name, message)`: the
    /// runtime keeps its own copy of the message for when the monitor fires.
    fn codegen_monitor(
        &mut self,
        args: &[MirExpr],
        intrinsic_name: &str,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        // The type checker gives each monitor its target and its message.
        let (target, message) = (&args[0], &args[1]);
        let target_val = self.codegen_expr(target)?;
        let mut call_args: Vec<BasicMetadataValueEnum<'ctx>> =
            if intrinsic_name == "mesh_node_monitor" {
                let (name_ptr, name_len) = self.codegen_unpack_string(target_val)?;
                vec![name_ptr.into(), name_len.into()]
            } else {
                vec![target_val.into()]
            };
        let msg_val = self.codegen_expr(message)?;
        let (msg_ptr, msg_size, shape_table) = self.message_bytes(message, msg_val)?;
        let null = self
            .context
            .ptr_type(inkwell::AddressSpace::default())
            .const_null();
        call_args.extend::<[BasicMetadataValueEnum<'ctx>; 3]>([
            msg_ptr.into(),
            msg_size.into(),
            shape_table.unwrap_or(null).into(),
        ]);
        Ok(self.codegen_runtime_call(intrinsic_name, &call_args, "monitor"))
    }

    /// Codegen for Timer.send_after(pid, ms, msg).
    ///
    /// Serializes the message (3rd arg) to (ptr, size) like codegen_actor_send,
    /// then calls mesh_timer_send_after(pid, ms, msg_ptr, msg_size).
    fn codegen_timer_send_after(
        &mut self,
        args: &[MirExpr],
        evaluated: &[BasicMetadataValueEnum<'ctx>],
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        // The caller has already evaluated the arguments. Evaluating them
        // again here ran the message expression, and its side effects, twice.
        let value = |index: usize| {
            BasicValueEnum::try_from(evaluated[index]).expect("an argument is a value")
        };
        let (pid_val, ms_val, msg_val) = (value(0), value(1), value(2));
        let (pid_val, ms_val) = (pid_val.into_int_value(), ms_val.into_int_value());
        let (msg_ptr, msg_size, shape_table) = self.message_bytes(&args[2], msg_val)?;

        // Call mesh_timer_send_after[_shaped](pid, ms, msg_ptr, msg_size[, shape])
        let mut call_args: Vec<BasicMetadataValueEnum<'ctx>> = vec![
            pid_val.into(),
            ms_val.into(),
            msg_ptr.into(),
            msg_size.into(),
        ];
        let send_after_fn = match shape_table {
            Some(shape_table) => {
                call_args.push(shape_table.into());
                "mesh_timer_send_after_shaped"
            }
            None => "mesh_timer_send_after",
        };
        self.builder
            .build_call(get_intrinsic(&self.module, send_after_fn), &call_args, "")
            .map_err(Diagnostic::internal)?;

        // Returns Unit.
        Ok(self.context.struct_type(&[], false).const_zero().into())
    }

    /// Load the byte count at offset zero of a MeshString.
    fn codegen_string_byte_length(
        &self,
        string: PointerValue<'ctx>,
    ) -> Result<IntValue<'ctx>, Diagnostic> {
        self.builder
            .build_load(self.context.i64_type(), string, "str_len")
            .map(|length| length.into_int_value())
            .map_err(Diagnostic::internal)
    }

    // ── Phase 67: Node distribution codegen helpers ──────────────────────

    /// Extract raw (data_ptr, len) from a MeshString pointer.
    ///
    /// MeshString layout: `{ len: u64, data_bytes... }`.
    /// - `len` is at offset 0 (first 8 bytes)
    /// - `data_ptr` is at `string_ptr + 8` (bytes following the header)
    fn codegen_unpack_string(
        &mut self,
        string_val: BasicValueEnum<'ctx>,
    ) -> Result<
        (
            inkwell::values::PointerValue<'ctx>,
            inkwell::values::IntValue<'ctx>,
        ),
        Diagnostic,
    > {
        let i64_ty = self.context.i64_type();
        let string_ptr = string_val.into_pointer_value();

        let len_val = self.codegen_string_byte_length(string_ptr)?;

        // Data pointer is string_ptr + 8 bytes (after the u64 len field).
        let eight = i64_ty.const_int(8, false);
        let data_ptr = unsafe {
            self.builder
                .build_gep(self.context.i8_type(), string_ptr, &[eight], "str_data")
                .map_err(Diagnostic::internal)?
        };

        Ok((data_ptr, len_val))
    }

    /// Codegen for Node.start(name, cookie).
    ///
    /// Unpacks two MeshString args into (ptr, len) pairs and calls
    /// mesh_node_start(name_ptr, name_len, cookie_ptr, cookie_len).
    fn codegen_node_start(&mut self, args: &[MirExpr]) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let name_val = self.codegen_expr(&args[0])?;
        let cookie_val = self.codegen_expr(&args[1])?;

        let (name_ptr, name_len) = self.codegen_unpack_string(name_val)?;
        let (cookie_ptr, cookie_len) = self.codegen_unpack_string(cookie_val)?;

        Ok(self.codegen_runtime_call(
            "mesh_node_start",
            &[
                name_ptr.into(),
                name_len.into(),
                cookie_ptr.into(),
                cookie_len.into(),
            ],
            "node_start",
        ))
    }

    /// Codegen for Node functions taking a single string arg (connect, monitor).
    ///
    /// Unpacks the MeshString arg into (ptr, len) and calls the given intrinsic.
    fn codegen_node_string_call(
        &mut self,
        args: &[MirExpr],
        intrinsic_name: &str,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let str_val = self.codegen_expr(&args[0])?;
        let (data_ptr, data_len) = self.codegen_unpack_string(str_val)?;

        Ok(self.codegen_runtime_call(
            intrinsic_name,
            &[data_ptr.into(), data_len.into()],
            "node_call",
        ))
    }

    /// Codegen for Global.register(name, pid).
    ///
    /// Unpacks the first string argument to (ptr, len), passes the second argument
    /// (pid as i64) through directly. Calls mesh_global_register(name_ptr, name_len, pid).
    fn codegen_global_register(
        &mut self,
        args: &[MirExpr],
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        // Unpack string argument (name)
        let str_val = self.codegen_expr(&args[0])?;
        let (name_ptr, name_len) = self.codegen_unpack_string(str_val)?;

        // Second argument is pid (i64)
        let pid_val = self.codegen_expr(&args[1])?;

        Ok(self.codegen_runtime_call(
            "mesh_global_register",
            &[name_ptr.into(), name_len.into(), pid_val.into()],
            "global_register",
        ))
    }

    /// Runtime `REMOTE_SPAWN_ARG_*` tag for a remotely transferable value type.
    /// Must stay in sync with the decoder in `mesh-rt/src/dist/node.rs`.
    pub(crate) fn remote_spawn_arg_tag(&self, ty: &MirType) -> Option<u8> {
        match ty {
            MirType::Int => Some(1),
            MirType::Float => Some(2),
            MirType::Bool => Some(3),
            MirType::String => Some(4),
            MirType::Pid(_) => Some(5),
            MirType::Unit => Some(6),
            _ => None,
        }
    }

    /// Codegen for Node.spawn / Node.spawn_link.
    ///
    /// Node.spawn(node_name, func_ref, args...) compiles to:
    ///   mesh_node_spawn(node_ptr, node_len, fn_name_ptr, fn_name_len, args_ptr, args_size, link_flag)
    ///
    /// The function reference (args[1]) is a MirExpr::Var whose name is the function name.
    /// Instead of evaluating it as a function pointer, we emit the function name as a
    /// string constant. The remaining args (args[2..]) are packed into an i64 array
    /// (same as local actor spawn).
    fn codegen_node_spawn(
        &mut self,
        args: &[MirExpr],
        link_flag: u8,
        at: Option<MirSourceSpan>,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let i64_ty = self.context.i64_type();
        let i8_ty = self.context.i8_type();
        let ptr_ty = self.context.ptr_type(inkwell::AddressSpace::default());

        // args[0] = node name (String expression).
        let node_val = self.codegen_expr(&args[0])?;
        let (node_ptr, node_len) = self.codegen_unpack_string(node_val)?;

        // args[1] = the function the remote node starts, which it looks up by
        // name: one defined at the top level, not a closure.
        let (fn_name, expected_arg_types) = match &args[1] {
            MirExpr::Var(name, MirType::FnPtr(params, _) | MirType::Closure(params, _)) => {
                (name.clone(), params.clone())
            }
            closure => {
                return Err(self.diagnostic_at(
                    closure.source_span().or(at),
                    Code::NodeSpawnArgument,
                    "`Node.spawn` needs a function defined at the top level: the remote node \
                     starts it by name",
                    "not a top-level function",
                ))
            }
        };

        // Create a global string constant for the function name.
        let fn_name_global = self
            .builder
            .build_global_string_ptr(&fn_name, "spawn_fn_name")
            .map_err(Diagnostic::internal)?;
        let fn_name_len = i64_ty.const_int(fn_name.len() as u64, false);

        // args[2..] = actor arguments. Pack raw values into a u64 array (same as
        // local spawn) and pass a parallel type-tag array so the runtime can deep-copy
        // remote-safe values like Strings instead of treating them as local pointers.
        let spawn_args = &args[2..];
        let (args_ptr, args_size, arg_tags_ptr, arg_count) = if spawn_args.is_empty() {
            (
                ptr_ty.const_null(),
                i64_ty.const_int(0, false),
                ptr_ty.const_null(),
                i64_ty.const_int(0, false),
            )
        } else {
            let arg_types: Vec<MirType> = spawn_args
                .iter()
                .enumerate()
                .map(|(i, arg)| expected_arg_types.get(i).unwrap_or(arg.ty()).clone())
                .collect();
            let arg_tags = spawn_args
                .iter()
                .zip(&arg_types)
                .enumerate()
                .map(|(index, (arg, ty))| {
                    self.remote_spawn_arg_tag(ty).ok_or_else(|| {
                        self.diagnostic_at(
                            arg.source_span().or(at),
                            Code::NodeSpawnArgument,
                            format!(
                                "argument {} of the actor `Node.spawn` starts cannot cross to \
                                 another node",
                                index + 1
                            ),
                            "not an `Int`, `Float`, `Bool`, `String`, `Pid`, or `()`",
                        )
                    })
                })
                .collect::<Result<Vec<u8>, _>>()?;
            // Each argument as its raw word, the way a list slot holds it.
            let mut arg_vals = Vec::with_capacity(spawn_args.len());
            for (arg, ty) in spawn_args.iter().zip(&arg_types) {
                let value = self.codegen_expr(arg)?;
                arg_vals.push(self.convert_to_list_element(value, ty)?);
            }

            let buffer = self.heap_words(&arg_vals, "spawn_args")?;
            let tags: Vec<_> = arg_tags
                .iter()
                .map(|&tag| i8_ty.const_int(tag as u64, false))
                .collect();
            let tags = i8_ty.const_array(&tags);
            let tag_buf_ptr = self
                .builder
                .build_alloca(tags.get_type(), "spawn_arg_tags")
                .map_err(Diagnostic::internal)?;
            self.builder
                .build_store(tag_buf_ptr, tags)
                .map_err(Diagnostic::internal)?;

            (
                buffer,
                i64_ty.const_int(8 * arg_vals.len() as u64, false),
                tag_buf_ptr,
                i64_ty.const_int(arg_tags.len() as u64, false),
            )
        };

        let link_val = i8_ty.const_int(link_flag as u64, false);

        // Call mesh_node_spawn(node_ptr, node_len, fn_name_ptr, fn_name_len,
        //                      args_ptr, args_size, arg_tags_ptr, arg_count, link_flag)
        Ok(self.codegen_runtime_call(
            "mesh_node_spawn",
            &[
                node_ptr.into(),
                node_len.into(),
                fn_name_global.as_pointer_value().into(),
                fn_name_len.into(),
                args_ptr.into(),
                args_size.into(),
                arg_tags_ptr.into(),
                arg_count.into(),
                link_val.into(),
            ],
            "remote_pid",
        ))
    }

    fn codegen_actor_receive(
        &mut self,
        handler: Option<&(String, MirType, Box<MirExpr>)>,
        timeout_ms: Option<&MirExpr>,
        timeout_body: Option<&MirExpr>,
        result_ty: &MirType,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let i64_ty = self.context.i64_type();

        // Evaluate timeout: -1 for infinite wait, or the specified value.
        let timeout_val = if let Some(timeout_expr) = timeout_ms {
            self.codegen_expr(timeout_expr)?.into_int_value()
        } else {
            // Infinite wait: -1
            i64_ty.const_int(u64::MAX, true) // -1 as i64
        };

        if let (None, Some(body)) = (handler, timeout_body) {
            let wait = get_intrinsic(&self.module, "mesh_actor_wait_timeout");
            self.builder
                .build_call(wait, &[timeout_val.into()], "")
                .map_err(Diagnostic::internal)?;
            return self.codegen_expr(body);
        }

        // The handler binds the message type, independent of what its body returns.
        let scalar_ty = handler.and_then(|(_, binding_ty, _)| match binding_ty {
            MirType::Int | MirType::Bool | MirType::Pid(_) | MirType::Float => {
                Some(self.llvm_type(binding_ty))
            }
            _ => None,
        });
        let msg_ptr = if let Some(ty) = scalar_ty {
            let width = self.target_machine.get_target_data().get_store_size(&ty);
            // hoist_static_allocas moves this fixed-size slot to the entry block.
            let slot = self
                .builder
                .build_alloca(i64_ty, "recv_scalar")
                .map_err(Diagnostic::internal)?;
            slot.as_instruction_value()
                .unwrap()
                .set_alignment(8)
                .map_err(Diagnostic::internal)?;
            self.codegen_runtime_call(
                "mesh_actor_receive_scalar",
                &[
                    timeout_val.into(),
                    i64_ty.const_int(width, false).into(),
                    slot.into(),
                ],
                "scalar_ptr",
            )
        } else {
            self.codegen_runtime_call("mesh_actor_receive", &[timeout_val.into()], "msg_ptr")
        }
        .into_pointer_value();

        // When timeout_body is present, we need null-check branching:
        //   [mesh_actor_receive] -> [is_null?] -> timeout_bb (null) / msg_bb (non-null) -> recv_merge_bb
        // An untimed receive also returns null during scheduler shutdown.
        if let Some(timeout_expr) = timeout_body {
            let fn_val = self.current_function();
            let result_llvm_ty = self.llvm_type(result_ty);
            let result_alloca = self
                .builder
                .build_alloca(result_llvm_ty, "recv_result")
                .map_err(Diagnostic::internal)?;

            let timeout_bb = self.context.append_basic_block(fn_val, "timeout_bb");
            let msg_bb = self.context.append_basic_block(fn_val, "msg_bb");
            let recv_merge_bb = self.context.append_basic_block(fn_val, "recv_merge_bb");

            // Null check: timeout fires when mesh_actor_receive returns null.
            let is_null = self
                .builder
                .build_is_null(msg_ptr, "msg_is_null")
                .map_err(Diagnostic::internal)?;
            self.builder
                .build_conditional_branch(is_null, timeout_bb, msg_bb)
                .map_err(Diagnostic::internal)?;

            // timeout_bb: execute the timeout body expression.
            self.builder.position_at_end(timeout_bb);
            let timeout_val = self.codegen_expr(timeout_expr)?;
            if self.block_is_open() {
                self.builder
                    .build_store(result_alloca, timeout_val)
                    .map_err(Diagnostic::internal)?;
                self.builder
                    .build_unconditional_branch(recv_merge_bb)
                    .map_err(Diagnostic::internal)?;
            }

            // msg_bb: process the received message (existing logic).
            self.builder.position_at_end(msg_bb);
            let msg_result = self.codegen_recv_handler(handler, msg_ptr, result_ty, scalar_ty)?;
            if self.block_is_open() {
                self.builder
                    .build_store(result_alloca, msg_result)
                    .map_err(Diagnostic::internal)?;
                self.builder
                    .build_unconditional_branch(recv_merge_bb)
                    .map_err(Diagnostic::internal)?;
            }

            self.merged_value(recv_merge_bb, result_llvm_ty, result_alloca, "recv_val")
        } else {
            let function = self.current_function();
            let stopped = self.context.append_basic_block(function, "receive_stopped");
            let received = self.context.append_basic_block(function, "receive_message");
            let empty = self
                .builder
                .build_is_null(msg_ptr, "receive_empty")
                .map_err(Diagnostic::internal)?;
            self.builder
                .build_conditional_branch(empty, stopped, received)
                .map_err(Diagnostic::internal)?;
            self.builder.position_at_end(stopped);
            let stop = get_intrinsic(&self.module, "mesh_actor_stop");
            self.builder
                .build_call(stop, &[], "")
                .map_err(Diagnostic::internal)?;
            self.builder
                .build_unreachable()
                .map_err(Diagnostic::internal)?;
            self.builder.position_at_end(received);
            self.codegen_recv_handler(handler, msg_ptr, result_ty, scalar_ty)
        }
    }

    /// Load the message data from the received message pointer.
    /// Message layout: [u64 type_tag (8 bytes), u64 data_len (8 bytes), u8... data]
    fn codegen_recv_load_message(
        &mut self,
        msg_ptr: inkwell::values::PointerValue<'ctx>,
        result_ty: &MirType,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let i64_ty = self.context.i64_type();
        let ptr_ty = self.context.ptr_type(inkwell::AddressSpace::default());

        // Skip the 16-byte header to get to the data.
        let data_ptr = unsafe {
            self.builder
                .build_gep(
                    self.context.i8_type(),
                    msg_ptr,
                    &[i64_ty.const_int(16, false)],
                    "data_ptr",
                )
                .map_err(Diagnostic::internal)?
        };

        // Load the message data as the expected type.
        let msg_val: BasicValueEnum<'ctx> = match result_ty {
            MirType::Int => self
                .builder
                .build_load(i64_ty, data_ptr, "msg_int")
                .map_err(Diagnostic::internal)?,
            MirType::Float => self
                .builder
                .build_load(self.context.f64_type(), data_ptr, "msg_float")
                .map_err(Diagnostic::internal)?,
            MirType::Bool => self
                .builder
                .build_load(self.context.i8_type(), data_ptr, "msg_bool")
                .map_err(Diagnostic::internal)?,
            MirType::String => self
                .builder
                .build_load(ptr_ty, data_ptr, "msg_string")
                .map_err(Diagnostic::internal)?,
            _ => self
                .builder
                .build_load(i64_ty, data_ptr, "msg_data")
                .map_err(Diagnostic::internal)?,
        };

        Ok(msg_val)
    }

    /// The received message as a value of the pattern variable's own type.
    ///
    /// `msg_val` is the first word of the message, loaded for the receive
    /// expression's result type. That is all a word-sized message needs, but
    /// a struct or a sum type with a payload is wider, and binding the word
    /// truncated it. Wider values are copied out of the message instead, into
    /// a zeroed temporary and never past the delivered length, so a shorter
    /// message than the type expects reads as zeroes rather than out of bounds.
    fn codegen_recv_message_as(
        &mut self,
        msg_ptr: inkwell::values::PointerValue<'ctx>,
        ty: &MirType,
        msg_val: BasicValueEnum<'ctx>,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        if matches!(ty, MirType::Unit | MirType::Never) {
            return Ok(msg_val);
        }
        let llvm_ty = self.llvm_type(ty);
        let size = self
            .target_machine
            .get_target_data()
            .get_store_size(&llvm_ty);
        let i64_ty = self.context.i64_type();
        let i8_ty = self.context.i8_type();
        if size <= 8 {
            if msg_val.get_type() == llvm_ty {
                return Ok(msg_val);
            }
            // `msg_val` was loaded for the receive's result type; read the
            // word again as the message's own type.
            let data_ptr = unsafe {
                self.builder
                    .build_gep(i8_ty, msg_ptr, &[i64_ty.const_int(16, false)], "msg_word")
                    .map_err(Diagnostic::internal)?
            };
            return self
                .builder
                .build_load(llvm_ty, data_ptr, "msg_value")
                .map_err(Diagnostic::internal);
        }

        // Message layout: [u64 type_tag][u64 data_len][data...]
        let (len_ptr, data_ptr) = unsafe {
            (
                self.builder
                    .build_gep(i8_ty, msg_ptr, &[i64_ty.const_int(8, false)], "len_ptr")
                    .map_err(Diagnostic::internal)?,
                self.builder
                    .build_gep(i8_ty, msg_ptr, &[i64_ty.const_int(16, false)], "wide_ptr")
                    .map_err(Diagnostic::internal)?,
            )
        };
        let delivered = self
            .builder
            .build_load(i64_ty, len_ptr, "data_len")
            .map_err(Diagnostic::internal)?
            .into_int_value();
        let wanted = i64_ty.const_int(size, false);
        let shorter = self
            .builder
            .build_int_compare(IntPredicate::ULT, delivered, wanted, "msg_is_short")
            .map_err(Diagnostic::internal)?;
        let copied = self
            .builder
            .build_select(shorter, delivered, wanted, "msg_bytes")
            .map_err(Diagnostic::internal)?
            .into_int_value();

        let wide = self
            .builder
            .build_alloca(llvm_ty, "msg_wide")
            .map_err(Diagnostic::internal)?;
        self.builder
            .build_store(wide, llvm_ty.const_zero())
            .map_err(Diagnostic::internal)?;
        self.builder
            .build_memcpy(wide, 8, data_ptr, 8, copied)
            .map_err(Diagnostic::internal)?;
        self.builder
            .build_load(llvm_ty, wide, "msg_value")
            .map_err(Diagnostic::internal)
    }

    /// Bind the received message to the handler's variable and run its
    /// body; without a handler the message is the value.
    fn codegen_recv_handler(
        &mut self,
        handler: Option<&(String, MirType, Box<MirExpr>)>,
        msg_ptr: inkwell::values::PointerValue<'ctx>,
        result_ty: &MirType,
        scalar_ty: Option<inkwell::types::BasicTypeEnum<'ctx>>,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let msg_val = if let Some(ty) = scalar_ty {
            self.builder
                .build_load(ty, msg_ptr, "msg_scalar")
                .map_err(Diagnostic::internal)?
        } else {
            let value = self.codegen_recv_load_message(msg_ptr, result_ty)?;
            match handler {
                Some((_, ty, _)) => self.codegen_recv_message_as(msg_ptr, ty, value)?,
                None => value,
            }
        };
        let Some((name, _, body)) = handler else {
            return Ok(msg_val);
        };
        let alloca = self
            .builder
            .build_alloca(msg_val.get_type(), name)
            .map_err(Diagnostic::internal)?;
        self.builder
            .build_store(alloca, msg_val)
            .map_err(Diagnostic::internal)?;
        self.locals.insert(name.clone(), alloca);
        self.codegen_expr(body)
    }

    /// Integer `/` and `%`. Dividing by zero panics; `Int.MIN / -1` wraps to
    /// `Int.MIN` (and its remainder is 0) like the other Int operators. A bare
    /// `sdiv`/`srem` is undefined behaviour in both cases.
    fn codegen_int_div(
        &mut self,
        op: &BinOp,
        l: inkwell::values::IntValue<'ctx>,
        r: inkwell::values::IntValue<'ctx>,
        at: Option<MirSourceSpan>,
    ) -> Result<inkwell::values::IntValue<'ctx>, Diagnostic> {
        let int_ty = r.get_type();
        let function = self.current_function();
        let zero_bb = self.context.append_basic_block(function, "div_by_zero");
        let ok_bb = self.context.append_basic_block(function, "div_ok");
        let is_zero = self
            .builder
            .build_int_compare(IntPredicate::EQ, r, int_ty.const_zero(), "div_is_zero")
            .map_err(Diagnostic::internal)?;
        self.builder
            .build_conditional_branch(is_zero, zero_bb, ok_bb)
            .map_err(Diagnostic::internal)?;

        self.builder.position_at_end(zero_bb);
        self.codegen_panic("division by zero", &self.current_function_name(), at)?;

        self.builder.position_at_end(ok_bb);
        let minus_one = int_ty.const_all_ones();
        let is_minus_one = self
            .builder
            .build_int_compare(IntPredicate::EQ, r, minus_one, "div_by_minus_one")
            .map_err(Diagnostic::internal)?;
        let divisor = self
            .builder
            .build_select(is_minus_one, int_ty.const_int(1, false), r, "divisor")
            .map_err(Diagnostic::internal)?
            .into_int_value();
        let (value, by_minus_one) = if matches!(op, BinOp::Div) {
            let quotient = self
                .builder
                .build_int_signed_div(l, divisor, "div")
                .map_err(Diagnostic::internal)?;
            let negated = self
                .builder
                .build_int_sub(int_ty.const_zero(), l, "div_neg")
                .map_err(Diagnostic::internal)?;
            (quotient, negated)
        } else {
            let remainder = self
                .builder
                .build_int_signed_rem(l, divisor, "mod")
                .map_err(Diagnostic::internal)?;
            (remainder, int_ty.const_zero())
        };
        Ok(self
            .builder
            .build_select(is_minus_one, by_minus_one, value, "div_result")
            .map_err(Diagnostic::internal)?
            .into_int_value())
    }

    /// Float to Int that saturates: NaN is 0, and values beyond the Int range
    /// clamp to its ends. A plain `fptosi` is poison there, which the optimizer
    /// turns into garbage.
    fn saturating_float_to_int(
        &mut self,
        value: inkwell::values::FloatValue<'ctx>,
        name: &str,
    ) -> Result<inkwell::values::IntValue<'ctx>, Diagnostic> {
        let intrinsic = Intrinsic::find("llvm.fptosi.sat")
            .ok_or_else(|| Diagnostic::internal("llvm.fptosi.sat not found"))?;
        let decl = intrinsic
            .get_declaration(
                &self.module,
                &[
                    self.context.i64_type().into(),
                    self.context.f64_type().into(),
                ],
            )
            .ok_or_else(|| Diagnostic::internal("Failed to get llvm.fptosi.sat declaration"))?;
        Ok(self
            .builder
            .build_call(decl, &[value.into()], name)
            .map_err(Diagnostic::internal)?
            .try_as_basic_value()
            .basic()
            .ok_or_else(|| Diagnostic::internal("fptosi.sat returned void"))?
            .into_int_value())
    }

    fn codegen_actor_self(&mut self) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        Ok(self.codegen_runtime_call("mesh_actor_self", &[], "self_pid"))
    }

    fn codegen_actor_link(&mut self, target: &MirExpr) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        // Evaluate the target PID.
        let target_val = self.codegen_expr(target)?.into_int_value();

        // Call mesh_actor_link(target_pid)
        let link_fn = get_intrinsic(&self.module, "mesh_actor_link");
        self.builder
            .build_call(link_fn, &[target_val.into()], "")
            .map_err(Diagnostic::internal)?;

        // Link returns Unit.
        Ok(self.context.struct_type(&[], false).const_zero().into())
    }

    // ── While loop ────────────────────────────────────────────────────

    fn codegen_while(
        &mut self,
        cond: &MirExpr,
        body: &MirExpr,
        _ty: &MirType,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let fn_val = self.current_function();

        // Create basic blocks: cond_check, body, merge
        let cond_bb = self.context.append_basic_block(fn_val, "while_cond");
        let body_bb = self.context.append_basic_block(fn_val, "while_body");
        let merge_bb = self.context.append_basic_block(fn_val, "while_merge");

        // Push loop context for break/continue
        self.loop_stack.push((cond_bb, merge_bb));

        // Branch from current block to cond_check
        self.builder
            .build_unconditional_branch(cond_bb)
            .map_err(Diagnostic::internal)?;

        // -- Condition check block --
        self.builder.position_at_end(cond_bb);
        let cond_val = self.codegen_expr(cond)?.into_int_value();
        self.builder
            .build_conditional_branch(cond_val, body_bb, merge_bb)
            .map_err(Diagnostic::internal)?;

        // -- Body block --
        self.builder.position_at_end(body_bb);
        let _body_val = self.codegen_expr(body)?;

        // After body codegen, if block is NOT terminated (break/continue may have terminated it),
        // emit reduction check and branch back to cond_check (the back-edge).
        if self.block_is_open() {
            self.emit_reduction_check();
            self.builder
                .build_unconditional_branch(cond_bb)
                .map_err(Diagnostic::internal)?;
        }

        // Pop loop context
        self.loop_stack.pop();

        // Position at merge block
        self.builder.position_at_end(merge_bb);

        // While returns Unit
        Ok(self.context.struct_type(&[], false).const_zero().into())
    }

    // ── For-in range loop ──────────────────────────────────────────────

    fn codegen_for_in_range(
        &mut self,
        var: &str,
        start_expr: &MirExpr,
        end_expr: &MirExpr,
        filter: Option<&MirExpr>,
        body: &MirExpr,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let start = self.codegen_expr(start_expr)?.into_int_value();
        let end = self.codegen_expr(end_expr)?.into_int_value();
        // The list holds max(0, end - start) values.
        let zero = self.context.i64_type().const_zero();
        let diff = self
            .builder
            .build_int_sub(end, start, "range_diff")
            .map_err(Diagnostic::internal)?;
        let is_positive = self
            .builder
            .build_int_compare(IntPredicate::SGT, diff, zero, "is_positive")
            .map_err(Diagnostic::internal)?;
        let range_len = self
            .builder
            .build_select(is_positive, diff, zero, "range_len")
            .map_err(Diagnostic::internal)?
            .into_int_value();
        self.codegen_indexed_comprehension(
            (start, end),
            range_len,
            &[(var, &MirType::Int)],
            filter,
            body,
            |_, index| Ok(vec![index.into()]),
        )
    }

    /// A for-in loop: the list of `body`'s values for the elements `filter`
    /// keeps, with `vars` bound to each element's values.
    ///
    /// In the loop's header, `header` branches to the body block it is given
    /// while there is an element and to the exit block after the last; in
    /// the body block, `element` turns what it returned into the value of
    /// each of `vars`. `advance` moves to the next element in the latch,
    /// where `continue` goes; `break` leaves with the list so far.
    #[allow(clippy::too_many_arguments)]
    fn codegen_comprehension<T>(
        &mut self,
        capacity: IntValue<'ctx>,
        vars: &[(&str, &MirType)],
        filter: Option<&MirExpr>,
        body: &MirExpr,
        header: impl FnOnce(&mut Self, BasicBlock<'ctx>, BasicBlock<'ctx>) -> Result<T, Diagnostic>,
        element: impl FnOnce(&mut Self, T) -> Result<Vec<BasicValueEnum<'ctx>>, Diagnostic>,
        advance: impl FnOnce(&mut Self) -> Result<(), Diagnostic>,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let fn_val = self.current_function();
        let ptr_ty = self.context.ptr_type(inkwell::AddressSpace::default());
        // The list builder moves when it grows, so it lives in a slot.
        let list =
            self.codegen_runtime_call("mesh_list_builder_new", &[capacity.into()], "result_list");
        let result = self
            .builder
            .build_alloca(ptr_ty, "result_alloca")
            .map_err(Diagnostic::internal)?;
        self.builder
            .build_store(result, list)
            .map_err(Diagnostic::internal)?;

        let header_bb = self.context.append_basic_block(fn_val, "forin_header");
        let body_bb = self.context.append_basic_block(fn_val, "forin_body");
        let latch_bb = self.context.append_basic_block(fn_val, "forin_latch");
        let merge_bb = self.context.append_basic_block(fn_val, "forin_merge");
        self.builder
            .build_unconditional_branch(header_bb)
            .map_err(Diagnostic::internal)?;
        self.builder.position_at_end(header_bb);
        let current = header(self, body_bb, merge_bb)?;

        self.builder.position_at_end(body_bb);
        let values = element(self, current)?;
        let mut saved = Vec::with_capacity(vars.len());
        for (&(name, ty), value) in vars.iter().zip(values) {
            saved.push(self.bind_local(name, ty, value)?);
        }
        self.loop_stack.push((latch_bb, merge_bb));
        if let Some(filter) = filter {
            let keep = self.codegen_expr(filter)?.into_int_value();
            let keep_bb = self.context.append_basic_block(fn_val, "forin_do_body");
            self.builder
                .build_conditional_branch(keep, keep_bb, latch_bb)
                .map_err(Diagnostic::internal)?;
            self.builder.position_at_end(keep_bb);
        }
        let value = self.codegen_expr(body)?;
        // A body that ends in `break`, `continue` or `return` has left.
        if self.block_is_open() {
            let value = self.convert_to_list_element(value, body.result_ty())?;
            let list = self
                .builder
                .build_load(ptr_ty, result, "res_list")
                .map_err(Diagnostic::internal)?;
            let pushed = self.codegen_runtime_call(
                "mesh_list_builder_push",
                &[list.into(), value.into()],
                "res_list_pushed",
            );
            self.builder
                .build_store(result, pushed)
                .map_err(Diagnostic::internal)?;
            self.builder
                .build_unconditional_branch(latch_bb)
                .map_err(Diagnostic::internal)?;
        }
        self.loop_stack.pop();
        self.restore_locals(saved);

        self.builder.position_at_end(latch_bb);
        advance(self)?;
        self.emit_reduction_check();
        self.builder
            .build_unconditional_branch(header_bb)
            .map_err(Diagnostic::internal)?;

        self.builder.position_at_end(merge_bb);
        self.builder
            .build_load(ptr_ty, result, "forin_result")
            .map_err(Diagnostic::internal)
    }

    /// A for-in loop over the indexes from `start` up to `end`: `element`
    /// reads the loop variables' values at an index.
    fn codegen_indexed_comprehension(
        &mut self,
        (start, end): (IntValue<'ctx>, IntValue<'ctx>),
        capacity: IntValue<'ctx>,
        vars: &[(&str, &MirType)],
        filter: Option<&MirExpr>,
        body: &MirExpr,
        element: impl FnOnce(&mut Self, IntValue<'ctx>) -> Result<Vec<BasicValueEnum<'ctx>>, Diagnostic>,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let i64_ty = self.context.i64_type();
        let counter = self
            .builder
            .build_alloca(i64_ty, "forin_counter")
            .map_err(Diagnostic::internal)?;
        self.builder
            .build_store(counter, start)
            .map_err(Diagnostic::internal)?;
        self.codegen_comprehension(
            capacity,
            vars,
            filter,
            body,
            |cg, body_bb, merge_bb| {
                let index = cg
                    .builder
                    .build_load(i64_ty, counter, "idx")
                    .map_err(Diagnostic::internal)?
                    .into_int_value();
                let more = cg
                    .builder
                    .build_int_compare(IntPredicate::SLT, index, end, "forin_cmp")
                    .map_err(Diagnostic::internal)?;
                cg.builder
                    .build_conditional_branch(more, body_bb, merge_bb)
                    .map_err(Diagnostic::internal)?;
                Ok(index)
            },
            element,
            |cg| {
                let index = cg
                    .builder
                    .build_load(i64_ty, counter, "idx_latch")
                    .map_err(Diagnostic::internal)?
                    .into_int_value();
                let next = cg
                    .builder
                    .build_int_add(index, i64_ty.const_int(1, false), "idx_next")
                    .map_err(Diagnostic::internal)?;
                cg.builder
                    .build_store(counter, next)
                    .map_err(Diagnostic::internal)?;
                Ok(())
            },
        )
    }

    fn codegen_break(&mut self) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let (_, merge_bb) = self
            .loop_stack
            .last()
            .copied()
            .ok_or_else(|| Diagnostic::internal("break outside loop"))?;

        self.builder
            .build_unconditional_branch(merge_bb)
            .map_err(Diagnostic::internal)?;

        // Return a dummy Unit value (unreachable code after break)
        Ok(self.context.struct_type(&[], false).const_zero().into())
    }

    fn codegen_continue(&mut self) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let (cond_bb, _) = self
            .loop_stack
            .last()
            .copied()
            .ok_or_else(|| Diagnostic::internal("continue outside loop"))?;

        // Continue is also a back-edge -- emit reduction check
        self.emit_reduction_check();

        self.builder
            .build_unconditional_branch(cond_bb)
            .map_err(Diagnostic::internal)?;

        // Return a dummy Unit value (unreachable code after continue)
        Ok(self.context.struct_type(&[], false).const_zero().into())
    }

    // ── Reduction check ─────────────────────────────────────────────────

    /// Coerce a value to the 8-byte word that carries it in an argument slot
    /// (spawn arguments, service arguments and replies): an aggregate that
    /// fits a word travels as its bits, a larger one in a box, and anything
    /// else as `coerce_argument` makes it a word.
    fn coerce_to_i64(
        &mut self,
        val: BasicValueEnum<'ctx>,
    ) -> Result<inkwell::values::IntValue<'ctx>, Diagnostic> {
        let i64_ty = self.context.i64_type();
        let BasicValueEnum::StructValue(sv) = val else {
            return Ok(self
                .coerce_argument(val.into(), i64_ty.into())?
                .into_int_value());
        };
        let size = self
            .target_machine
            .get_target_data()
            .get_store_size(&sv.get_type());
        if size > 8 {
            let boxed = self.box_value(sv.into(), "arg_box")?.into_pointer_value();
            return self
                .builder
                .build_ptr_to_int(boxed, i64_ty, "arg_box_to_i64")
                .map_err(Diagnostic::internal);
        }
        // Zeroed first: the bits are narrower than the word read back.
        let alloca = self
            .builder
            .build_alloca(i64_ty, "struct_tmp")
            .map_err(Diagnostic::internal)?;
        self.builder
            .build_store(alloca, i64_ty.const_zero())
            .map_err(Diagnostic::internal)?;
        self.builder
            .build_store(alloca, sv)
            .map_err(Diagnostic::internal)?;
        Ok(self
            .builder
            .build_load(i64_ty, alloca, "struct_to_i64")
            .map_err(Diagnostic::internal)?
            .into_int_value())
    }

    /// The value of LLVM type `ty` that `coerce_to_i64` made the word `word`.
    fn word_as(
        &mut self,
        word: inkwell::values::IntValue<'ctx>,
        ty: inkwell::types::BasicTypeEnum<'ctx>,
        name: &str,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let error = |e: inkwell::builder::BuilderError| Diagnostic::internal(e);
        let ptr_ty = self.context.ptr_type(inkwell::AddressSpace::default());
        Ok(match ty {
            inkwell::types::BasicTypeEnum::IntType(int_ty) if int_ty.get_bit_width() < 64 => self
                .builder
                .build_int_truncate(word, int_ty, name)
                .map_err(error)?
                .into(),
            inkwell::types::BasicTypeEnum::FloatType(float_ty) => self
                .builder
                .build_bit_cast(word, float_ty, name)
                .map_err(error)?,
            inkwell::types::BasicTypeEnum::PointerType(_) => self
                .builder
                .build_int_to_ptr(word, ptr_ty, name)
                .map_err(error)?
                .into(),
            inkwell::types::BasicTypeEnum::StructType(struct_ty) => {
                let size = self
                    .target_machine
                    .get_target_data()
                    .get_store_size(&struct_ty);
                let source = if size > 8 {
                    self.builder
                        .build_int_to_ptr(word, ptr_ty, name)
                        .map_err(error)?
                } else {
                    let slot = self
                        .builder
                        .build_alloca(word.get_type(), name)
                        .map_err(error)?;
                    self.builder.build_store(slot, word).map_err(error)?;
                    slot
                };
                self.builder
                    .build_load(struct_ty, source, name)
                    .map_err(error)?
            }
            _ => word.into(),
        })
    }

    /// Emit a call to mesh_reduction_check() for preemptive scheduling.
    ///
    /// Inserted after function call sites and closure calls to enable
    /// cooperative preemption of actor processes.
    fn emit_reduction_check(&self) {
        let name = if self.emitting_step {
            "mesh_step_charge"
        } else {
            "mesh_reduction_check"
        };
        let check_fn = get_intrinsic(&self.module, name);
        let _ = self.builder.build_call(check_fn, &[], "");
    }

    fn emit_inline_reduction_check(&self, state: PointerValue<'ctx>, next: BasicBlock<'ctx>) {
        let function = next.get_parent().expect("a loop belongs to its function");
        let slow = self.context.append_basic_block(function, "reduction_slow");
        let debit = self.context.append_basic_block(function, "reduction_debit");
        let word = self.context.i32_type();
        let remaining = self
            .builder
            .build_load(word, state, "reduction_remaining")
            .expect(BUILT)
            .into_int_value();
        // mesh_reduction_state_v1 exposes a counter for actors and a GC request
        // word for hosts. The zero case uses the original safepoint and leaves
        // the slot untouched so the runtime can distinguish yield from GC.
        self.builder
            .build_switch(
                remaining,
                debit,
                &[(word.const_zero(), slow), (word.const_all_ones(), next)],
            )
            .expect(BUILT);
        self.builder.position_at_end(debit);
        let remaining = self
            .builder
            .build_int_sub(remaining, word.const_int(1, false), "reduction_next")
            .expect(BUILT);
        self.builder.build_store(state, remaining).expect(BUILT);
        self.builder.build_unconditional_branch(next).expect(BUILT);

        self.builder.position_at_end(slow);
        self.emit_reduction_check();
        self.builder.build_unconditional_branch(next).expect(BUILT);
    }

    // ── Supervisor start ──────────────────────────────────────────────

    fn codegen_supervisor_start(
        &mut self,
        name: &str,
        strategy: u8,
        max_restarts: u32,
        max_seconds: u64,
        children: &[MirChildSpec],
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let i64_ty = self.context.i64_type();

        // Build the binary config buffer for mesh_supervisor_start.
        // Format: strategy(u8) + max_restarts(u32 LE) + max_seconds(u64 LE) +
        //         child_count(u32 LE) + for each child:
        //           id_len(u32 LE) + id_bytes + fn_ptr_placeholder(u64) +
        //           start_args_ptr(u64 LE=0) + start_args_size(u64 LE=0) +
        //           restart_type(u8) + shutdown_type(u8) +
        //           shutdown_timeout_ms(u64 LE) + child_type(u8)
        let mut config_bytes: Vec<u8> = Vec::new();

        // Strategy (1 byte)
        config_bytes.push(strategy);

        // Max restarts (4 bytes LE)
        config_bytes.extend_from_slice(&max_restarts.to_le_bytes());

        // Max seconds (8 bytes LE)
        config_bytes.extend_from_slice(&max_seconds.to_le_bytes());

        // Child count (4 bytes LE)
        config_bytes.extend_from_slice(&(children.len() as u32).to_le_bytes());

        // For each child, we need to embed an offset/placeholder for the function pointer.
        // The fn_ptr will be patched at runtime or we can store a function index.
        // For now, store the child spec metadata; the start function is referenced by name.
        let mut fn_ptr_offsets: Vec<(usize, String)> = Vec::new();

        for child in children {
            // id_len (4 bytes LE)
            let id_bytes = child.id.as_bytes();
            config_bytes.extend_from_slice(&(id_bytes.len() as u32).to_le_bytes());
            // id_bytes
            config_bytes.extend_from_slice(id_bytes);

            // fn_ptr placeholder (8 bytes) -- we'll patch this with a relocation.
            let fn_ptr_offset = config_bytes.len();
            fn_ptr_offsets.push((fn_ptr_offset, child.start_fn.clone()));
            config_bytes.extend_from_slice(&0u64.to_le_bytes()); // placeholder

            // start_args_ptr (8 bytes LE) -- a child's entry evaluates its actor's
            // arguments itself, so it is started with none.
            config_bytes.extend_from_slice(&0u64.to_le_bytes());

            // start_args_size (8 bytes LE)
            config_bytes.extend_from_slice(&0u64.to_le_bytes());

            // restart_type (1 byte)
            config_bytes.push(child.restart_type);

            // shutdown_type (1 byte) + shutdown_timeout_ms (8 bytes LE)
            if child.shutdown_ms == 0 {
                config_bytes.push(0); // brutal_kill
                config_bytes.extend_from_slice(&0u64.to_le_bytes());
            } else {
                config_bytes.push(1); // timeout(ms)
                config_bytes.extend_from_slice(&child.shutdown_ms.to_le_bytes());
            }

            // child_type (1 byte)
            config_bytes.push(child.child_type);
        }

        // Create a global constant for the config buffer.
        let config_data = self.context.const_string(&config_bytes, false);
        let config_name = format!(".sup_config_{}", name);
        let config_global = self
            .module
            .add_global(config_data.get_type(), None, &config_name);
        config_global.set_initializer(&config_data);
        config_global.set_constant(true);
        config_global.set_unnamed_addr(true);

        // For each child spec, we need to store the function pointer into the config buffer.
        // We do this at runtime by writing the fn_ptr into the config buffer copy on the stack.
        // Actually, since the config is a global constant, we can't patch it.
        // Instead, let's allocate a stack copy and patch fn_ptrs there.
        let config_size = config_bytes.len() as u64;
        let config_size_val = i64_ty.const_int(config_size, false);

        // Allocate stack copy of the config.
        let config_arr_ty = self.context.i8_type().array_type(config_size as u32);
        let config_alloca = self
            .builder
            .build_alloca(config_arr_ty, "sup_config")
            .map_err(Diagnostic::internal)?;

        // Memcpy from global to stack.
        let config_global_ptr = config_global.as_pointer_value();
        self.builder
            .build_memcpy(
                config_alloca,
                1,
                config_global_ptr,
                1,
                i64_ty.const_int(config_size, false),
            )
            .map_err(Diagnostic::internal)?;

        // Patch function pointers into the stack copy.
        for (offset, fn_name) in &fn_ptr_offsets {
            let fn_ptr_val = self.functions[fn_name].as_global_value().as_pointer_value();

            // Convert fn_ptr to i64.
            let fn_ptr_int = self
                .builder
                .build_ptr_to_int(fn_ptr_val, i64_ty, "fn_ptr_int")
                .map_err(Diagnostic::internal)?;

            // GEP to the offset in the config buffer.
            let offset_val = self.context.i32_type().const_int(*offset as u64, false);
            let zero = self.context.i32_type().const_int(0, false);
            let elem_ptr = unsafe {
                self.builder
                    .build_gep(
                        config_arr_ty,
                        config_alloca,
                        &[zero, offset_val],
                        "fn_ptr_slot",
                    )
                    .map_err(Diagnostic::internal)?
            };

            // Store the fn_ptr as i64 into the config buffer.
            self.builder
                .build_store(elem_ptr, fn_ptr_int)
                .map_err(Diagnostic::internal)?;
        }

        // Call mesh_supervisor_start(config_ptr, config_size) -> i64 (PID)
        Ok(self.codegen_runtime_call(
            "mesh_supervisor_start",
            &[config_alloca.into(), config_size_val.into()],
            "sup_pid",
        ))
    }

    // ── Panic ────────────────────────────────────────────────────────

    /// `text` as a constant global's bytes: their address and length.
    fn const_text(&self, text: &str, name: &str) -> (PointerValue<'ctx>, IntValue<'ctx>) {
        let value = self.context.const_string(text.as_bytes(), false);
        let global = self.module.add_global(value.get_type(), None, name);
        global.set_initializer(&value);
        global.set_constant(true);
        let len = self.context.i64_type().const_int(text.len() as u64, false);
        (global.as_pointer_value(), len)
    }

    /// The 1-based line and column of `at` as `i32` arguments.
    fn line_col_args(&self, at: LineCol) -> [BasicMetadataValueEnum<'ctx>; 2] {
        let i32_ty = self.context.i32_type();
        [
            i32_ty.const_int(u64::from(at.line), false).into(),
            i32_ty.const_int(u64::from(at.col), false).into(),
        ]
    }

    /// `panic(message)` at `at`, through `mesh_panic_str_at`; where the
    /// place is not known, through `mesh_panic_str`.
    fn codegen_panic_str(
        &mut self,
        message: &MirExpr,
        at: Option<MirSourceSpan>,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let message = self.codegen_expr(message)?;
        let (panic_fn, args) = match runtime_location(&self.files, at) {
            Some((file, at)) => {
                let (file_ptr, file_len) = self.const_text(&file, ".panic_file");
                let mut args = vec![message.into(), file_ptr.into(), file_len.into()];
                args.extend(self.line_col_args(at));
                (get_intrinsic(&self.module, "mesh_panic_str_at"), args)
            }
            None => (
                get_intrinsic(&self.module, "mesh_panic_str"),
                vec![message.into()],
            ),
        };
        self.builder
            .build_call(panic_fn, &args, "")
            .map_err(Diagnostic::internal)?;
        Ok(self.context.struct_type(&[], false).const_zero().into())
    }

    /// Panic with `message` at `at`, through `mesh_panic_at`; where the
    /// place is not known, through `mesh_panic`, naming `function`.
    pub(crate) fn codegen_panic(
        &mut self,
        message: &str,
        function: &str,
        at: Option<MirSourceSpan>,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let location = runtime_location(&self.files, at);
        let (panic_fn, file, place) = match &location {
            Some((file, at)) => (
                get_intrinsic(&self.module, "mesh_panic_at"),
                file.as_str(),
                Some(*at),
            ),
            None => (get_intrinsic(&self.module, "mesh_panic"), function, None),
        };

        let (msg_ptr, msg_len) = self.const_text(message, ".panic_msg");
        let (file_ptr, file_len) = self.const_text(file, ".panic_file");
        let mut args: Vec<BasicMetadataValueEnum<'ctx>> = vec![
            msg_ptr.into(),
            msg_len.into(),
            file_ptr.into(),
            file_len.into(),
        ];
        match place {
            Some(at) => args.extend(self.line_col_args(at)),
            // The function's name is not a file: line 0 says so.
            None => args.push(self.context.i32_type().const_zero().into()),
        }

        self.builder
            .build_call(panic_fn, &args, "")
            .map_err(Diagnostic::internal)?;

        self.builder
            .build_unreachable()
            .map_err(Diagnostic::internal)?;

        // Return a dummy value (unreachable)
        Ok(self.context.i8_type().const_int(0, false).into())
    }

    // ── Service codegen ─────────────────────────────────────────────────

    /// Generate the service loop function body.
    ///
    /// The loop:
    /// 1. Calls mesh_actor_receive(-1) to get a raw message pointer
    /// 2. Extracts type_tag from data offset 0
    /// 3. Extracts caller_pid from data offset 8
    /// 4. Extracts handler args from data offset 16+
    /// 5. Dispatches to the appropriate handler based on type_tag
    /// 6. For call handlers: replies to caller, then tail-calls loop with new state
    /// 7. For cast handlers: tail-calls loop with new state
    pub(crate) fn codegen_service_loop(
        &mut self,
        call_handlers: &[(u64, String, usize)],
        cast_handlers: &[(u64, String, usize)],
    ) -> Result<(), Diagnostic> {
        let i64_ty = self.context.i64_type();
        let ptr_ty = self.context.ptr_type(inkwell::AddressSpace::default());
        let i8_ty = self.context.i8_type();

        let fn_val = self.current_function();

        // Every handler takes the state (the init function's result) first:
        // a struct, a pointer or a word.
        let all_handlers: Vec<(u64, FunctionValue<'ctx>, usize, bool)> = call_handlers
            .iter()
            .map(|handler| (handler, true))
            .chain(cast_handlers.iter().map(|handler| (handler, false)))
            .map(|((tag, name, nargs), is_call)| (*tag, self.functions[name], *nargs, is_call))
            .collect();
        let state_llvm_ty: inkwell::types::BasicTypeEnum<'ctx> = all_handlers
            .first()
            .and_then(|(_, handler, _, _)| handler.get_type().get_param_types().first().copied())
            .and_then(|state| inkwell::types::BasicTypeEnum::try_from(state).ok())
            .unwrap_or(i64_ty.into());

        // The service loop function receives a ptr to the args buffer, whose
        // first slot is the initial state.
        let args_ptr_val = self
            .builder
            .build_load(ptr_ty, self.locals["__args_ptr"], "args_ptr_val")
            .map_err(Diagnostic::internal)?
            .into_pointer_value();
        let init_word = self
            .builder
            .build_load(i64_ty, args_ptr_val, "init_state_word")
            .map_err(Diagnostic::internal)?
            .into_int_value();
        let init_state = self.word_as(init_word, state_llvm_ty, "init_state")?;

        // Create a state alloca to hold the mutable state across iterations.
        let state_alloca = self
            .builder
            .build_alloca(state_llvm_ty, "__state")
            .map_err(Diagnostic::internal)?;
        self.builder
            .build_store(state_alloca, init_state)
            .map_err(Diagnostic::internal)?;

        // Create the loop block.
        let loop_bb = self.context.append_basic_block(fn_val, "loop");
        self.builder
            .build_unconditional_branch(loop_bb)
            .map_err(Diagnostic::internal)?;
        self.builder.position_at_end(loop_bb);

        // Load the current state from the state alloca.
        let state_val = self
            .builder
            .build_load(state_llvm_ty, state_alloca, "state")
            .map_err(Diagnostic::internal)?;

        // Call mesh_actor_receive(-1) -> ptr (blocks until message arrives).
        let timeout = i64_ty.const_int(u64::MAX, true); // -1
        let msg_ptr = self
            .codegen_runtime_call("mesh_actor_receive", &[timeout.into()], "msg_ptr")
            .into_pointer_value();

        // Check for null (shutdown signal). If null, exit the loop.
        let exit_bb = self.context.append_basic_block(fn_val, "exit_loop");
        let continue_bb = self.context.append_basic_block(fn_val, "continue_loop");
        let is_null = self
            .builder
            .build_is_null(msg_ptr, "msg_is_null")
            .map_err(Diagnostic::internal)?;
        self.builder
            .build_conditional_branch(is_null, exit_bb, continue_bb)
            .map_err(Diagnostic::internal)?;

        // Exit block: return from the service loop function.
        self.builder.position_at_end(exit_bb);
        self.builder
            .build_return(Some(&self.context.struct_type(&[], false).const_zero()))
            .map_err(Diagnostic::internal)?;

        // Continue block: process the message normally.
        self.builder.position_at_end(continue_bb);

        // Message layout after the 16-byte header: [u64 type_tag][u64 caller_pid][i64... args]
        // The word at `offset` bytes into the message's data.
        let data_word = |this: &mut Self, offset: u64, name: &str| {
            let word_ptr = unsafe {
                this.builder
                    .build_gep(
                        i8_ty,
                        msg_ptr,
                        &[i64_ty.const_int(16 + offset, false)],
                        name,
                    )
                    .map_err(Diagnostic::internal)?
            };
            this.builder
                .build_load(i64_ty, word_ptr, name)
                .map(|word| word.into_int_value())
                .map_err(Diagnostic::internal)
        };
        let type_tag = data_word(self, 0, "type_tag")?;
        let caller_pid = data_word(self, 8, "caller_pid")?;

        // Dispatch on type_tag; an unknown tag loops again with the state unchanged.
        let default_bb = self.context.append_basic_block(fn_val, "default");
        let handler_blocks: Vec<_> = all_handlers
            .iter()
            .map(|(tag, ..)| {
                let block = self
                    .context
                    .append_basic_block(fn_val, &format!("handler_{tag}"));
                (i64_ty.const_int(*tag, false), block)
            })
            .collect();
        self.builder
            .build_switch(type_tag, default_bb, &handler_blocks)
            .map_err(Diagnostic::internal)?;
        self.builder.position_at_end(default_bb);
        self.builder
            .build_unconditional_branch(loop_bb)
            .map_err(Diagnostic::internal)?;

        // Generate code for each handler.
        for ((_, handler_fn, num_args, is_call), (_, bb)) in
            all_handlers.iter().zip(&handler_blocks)
        {
            self.builder.position_at_end(*bb);
            let param_types = handler_fn.get_type().get_param_types();

            // The state, then the arguments from the message's slots (the
            // handler's parameters after the state), each a word
            // `coerce_to_i64` made.
            let mut handler_args: Vec<BasicMetadataValueEnum<'ctx>> = vec![state_val.into()];
            for (arg_idx, param_ty) in param_types.iter().skip(1).take(*num_args).enumerate() {
                let name = format!("arg_{arg_idx}");
                let word = data_word(self, 16 + 8 * arg_idx as u64, &name)?;
                let param_ty =
                    inkwell::types::BasicTypeEnum::try_from(*param_ty).map_err(|_| {
                        Diagnostic::internal(format!("handler parameter {arg_idx} is not a value"))
                    })?;
                handler_args.push(self.word_as(word, param_ty, &name)?.into());
            }

            // Call the handler function.
            let handler_result = self
                .builder
                .build_call(*handler_fn, &handler_args, "handler_result")
                .map_err(Diagnostic::internal)?
                .try_as_basic_value()
                .basic()
                .ok_or_else(|| Diagnostic::internal("Handler returned void"))?;

            // A cast handler returns the new state; a call handler the tuple
            // `(new_state, reply)`.
            let new_state = if *is_call {
                let result_ptr = handler_result.into_pointer_value();
                let new_state_word = self
                    .codegen_runtime_call("mesh_tuple_first", &[result_ptr.into()], "new_state")
                    .into_int_value();
                let reply_val = self
                    .codegen_runtime_call("mesh_tuple_second", &[result_ptr.into()], "reply")
                    .into_int_value();

                // Send reply to caller: mesh_service_reply(caller_pid, &reply, 8)
                let reply_alloca = self
                    .builder
                    .build_alloca(i64_ty, "reply_buf")
                    .map_err(Diagnostic::internal)?;
                self.builder
                    .build_store(reply_alloca, reply_val)
                    .map_err(Diagnostic::internal)?;
                let reply_size = i64_ty.const_int(8, false);

                // The reply is one tuple slot. What it references must outlive
                // this service changing state or exiting, so the caller gets a
                // copy; the call helper carries the reply's shape.
                let handler_name = handler_fn.get_name().to_string_lossy();
                let helper_name = handler_name.replacen("_handle_call_", "_call_", 1);
                let shape_table = self
                    .mir_functions
                    .iter()
                    .find(|f| f.name == helper_name)
                    .and_then(|helper| {
                        self.shape_table_for_slots(&[self.message_shape(&helper.body)])
                    });
                let mut reply_args: Vec<BasicMetadataValueEnum<'ctx>> =
                    vec![caller_pid.into(), reply_alloca.into(), reply_size.into()];
                let service_reply_fn = match shape_table {
                    Some(shape_table) => {
                        reply_args.push(shape_table.into());
                        "mesh_service_reply_shaped"
                    }
                    None => "mesh_service_reply",
                };
                self.builder
                    .build_call(
                        get_intrinsic(&self.module, service_reply_fn),
                        &reply_args,
                        "",
                    )
                    .map_err(Diagnostic::internal)?;
                self.word_as(new_state_word, state_llvm_ty, "new_state")?
            } else {
                handler_result
            };

            // Update the state alloca and branch back to loop.
            self.builder
                .build_store(state_alloca, new_state)
                .map_err(Diagnostic::internal)?;
            self.builder
                .build_unconditional_branch(loop_bb)
                .map_err(Diagnostic::internal)?;
        }

        Ok(())
    }

    /// Generate an actor wrapper function body that deserializes arguments from
    /// a raw pointer buffer and calls the actual actor body function.
    ///
    /// The runtime calls actor entry functions with `extern "C" fn(*const u8)`.
    /// The wrapper loads each argument from the args buffer at 8-byte offsets
    /// (matching the serialization in `codegen_actor_spawn`) and calls the
    /// typed body function.
    pub(crate) fn codegen_actor_wrapper(
        &mut self,
        wrapper_name: &str,
        body_fn_name: &str,
    ) -> Result<(), Diagnostic> {
        let i64_ty = self.context.i64_type();
        let ptr_ty = self.context.ptr_type(inkwell::AddressSpace::default());
        let body_fn = self.functions[body_fn_name];
        let args_ptr_val = self
            .builder
            .build_load(ptr_ty, self.locals["__args_ptr"], "args_ptr_val")
            .map_err(Diagnostic::internal)?
            .into_pointer_value();

        // Each argument is a word `coerce_to_i64` made, in 8-byte slots.
        let body_param_types = body_fn.get_type().get_param_types();
        let mut call_args: Vec<BasicMetadataValueEnum<'ctx>> = Vec::new();
        for (i, param_ty) in body_param_types.iter().enumerate() {
            let name = format!("arg_{i}");
            let slot = unsafe {
                self.builder
                    .build_gep(
                        i64_ty,
                        args_ptr_val,
                        &[i64_ty.const_int(i as u64, false)],
                        &name,
                    )
                    .map_err(Diagnostic::internal)?
            };
            let word = self
                .builder
                .build_load(i64_ty, slot, &name)
                .map_err(Diagnostic::internal)?
                .into_int_value();
            let param_ty = inkwell::types::BasicTypeEnum::try_from(*param_ty)
                .map_err(|_| Diagnostic::internal(format!("actor parameter {i} is not a value")))?;
            call_args.push(self.word_as(word, param_ty, &name)?.into());
        }

        // Call the body function with deserialized arguments.
        self.builder
            .build_call(body_fn, &call_args, "body_call")
            .map_err(Diagnostic::internal)?;

        // A declared work wrapper's body takes the request key and attempt id
        // it reports its completion with (`generate_declared_work_wrapper`).
        if wrapper_name.starts_with("__declared_work_") {
            let complete_declared_work =
                get_intrinsic(&self.module, "mesh_continuity_complete_declared_work");
            self.builder
                .build_call(
                    complete_declared_work,
                    &[call_args[0], call_args[1]],
                    "declared_work_complete",
                )
                .map_err(Diagnostic::internal)?;
        }

        // Return Unit (empty struct).
        let unit_val = self.context.struct_type(&[], false).const_zero();
        self.builder
            .build_return(Some(&unit_val))
            .map_err(Diagnostic::internal)?;

        Ok(())
    }

    /// A runtime tuple of `elements` on the GC heap: its length, then a
    /// word for each element.
    fn codegen_make_tuple(
        &mut self,
        elements: &[BasicMetadataValueEnum<'ctx>],
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let mut words = vec![self
            .context
            .i64_type()
            .const_int(elements.len() as u64, false)];
        for &element in elements {
            let value = BasicValueEnum::try_from(element).expect("a tuple element is a value");
            words.push(self.coerce_to_i64(value)?);
        }
        Ok(self.heap_words(&words, "tuple_ptr")?.into())
    }

    /// Shape table for service handler arguments, which travel as 8-byte
    /// slots; a null pointer when none of them references the heap.
    fn service_args_shape(&self, args: &[MirExpr]) -> inkwell::values::PointerValue<'ctx> {
        let shapes: Vec<_> = args.iter().map(|arg| self.message_shape(arg)).collect();
        self.shape_table_for_slots(&shapes).unwrap_or_else(|| {
            self.context
                .ptr_type(inkwell::AddressSpace::default())
                .const_null()
        })
    }

    /// Takes MIR args: [pid, tag, ...handler_args]
    /// Packs into a message buffer: [u64 handler_args[0], handler_args[1], ...]
    /// Calls mesh_service_call(pid, tag, payload_ptr, payload_size) -> ptr
    /// Loads the reply from the returned pointer and converts based on expected type.
    fn codegen_service_call_helper(
        &mut self,
        args: &[MirExpr],
        reply_ty: &MirType,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let i64_ty = self.context.i64_type();
        let ptr_ty = self.context.ptr_type(inkwell::AddressSpace::default());
        let i8_ty = self.context.i8_type();

        // First arg is pid, second is tag, rest are handler args.
        let pid_val = self.codegen_expr(&args[0])?.into_int_value();
        let tag_val = self.codegen_expr(&args[1])?.into_int_value();

        // Compile handler args and coerce all values to i64 for the payload buffer.
        // Pointers become ptrtoint, bools become zext, etc.
        let handler_args: Vec<_> = args[2..]
            .iter()
            .map(|a| {
                let v = self.codegen_expr(a)?;
                self.coerce_to_i64(v)
            })
            .collect::<Result<Vec<_>, _>>()?;

        // Build payload buffer: [i64 arg0, i64 arg1, ...]
        let payload_size = handler_args.len() * 8;
        let (payload_ptr, payload_size_val) = if handler_args.is_empty() {
            (ptr_ty.const_null(), i64_ty.const_int(0, false))
        } else {
            let arr_ty = i64_ty.array_type(handler_args.len() as u32);
            let buf = self
                .builder
                .build_alloca(arr_ty, "call_payload")
                .map_err(Diagnostic::internal)?;

            for (i, arg) in handler_args.iter().enumerate() {
                let idx = self.context.i32_type().const_int(i as u64, false);
                let zero = self.context.i32_type().const_int(0, false);
                let elem_ptr = unsafe {
                    self.builder
                        .build_gep(arr_ty, buf, &[zero, idx], "payload_elem")
                        .map_err(Diagnostic::internal)?
                };
                self.builder
                    .build_store(elem_ptr, *arg)
                    .map_err(Diagnostic::internal)?;
            }

            (buf, i64_ty.const_int(payload_size as u64, false))
        };

        // Call mesh_service_call_shaped(pid, tag, payload_ptr, payload_size, shape) -> ptr
        let shape_table = self.service_args_shape(&args[2..]);
        let result_ptr = self
            .codegen_runtime_call(
                "mesh_service_call_shaped",
                &[
                    pid_val.into(),
                    tag_val.into(),
                    payload_ptr.into(),
                    payload_size_val.into(),
                    shape_table.into(),
                ],
                "call_result",
            )
            .into_pointer_value();

        // The reply is a raw message pointer. The data after the 16-byte header
        // is the reply value (i64).
        let reply_data_ptr = unsafe {
            self.builder
                .build_gep(
                    i8_ty,
                    result_ptr,
                    &[i64_ty.const_int(16, false)],
                    "reply_data",
                )
                .map_err(Diagnostic::internal)?
        };
        let reply_i64 = self
            .builder
            .build_load(i64_ty, reply_data_ptr, "reply_i64")
            .map_err(Diagnostic::internal)?
            .into_int_value();

        // The reply is the handler's reply tuple slot, a word `coerce_to_i64`
        // made of the reply value.
        let reply_llvm_ty = self.llvm_type(reply_ty);
        self.word_as(reply_i64, reply_llvm_ty, "reply")
    }

    /// Generate a service cast helper function body.
    ///
    /// Takes MIR args: [pid, tag, ...handler_args]
    /// Packs into a message buffer: [u64 tag][u64 0 (no caller)][i64 handler_args...]
    /// Calls mesh_actor_send(pid, msg_ptr, msg_size).
    fn codegen_service_cast_helper(
        &mut self,
        args: &[MirExpr],
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let i64_ty = self.context.i64_type();

        // First arg is pid, second is tag, rest are handler args.
        let pid_val = self.codegen_expr(&args[0])?.into_int_value();
        let tag_val = self.codegen_expr(&args[1])?.into_int_value();

        // Compile handler args and coerce all values to i64 for the message buffer.
        let handler_args: Vec<_> = args[2..]
            .iter()
            .map(|a| {
                let v = self.codegen_expr(a)?;
                self.coerce_to_i64(v)
            })
            .collect::<Result<Vec<_>, _>>()?;

        // Build message buffer: [u64 type_tag][u64 0 (no caller)][i64 handler_args...]
        let num_elements = 2 + handler_args.len(); // tag + caller_pid + args
        let arr_ty = i64_ty.array_type(num_elements as u32);
        let buf = self
            .builder
            .build_alloca(arr_ty, "cast_msg")
            .map_err(Diagnostic::internal)?;

        // Store type_tag.
        let zero = self.context.i32_type().const_int(0, false);
        let tag_ptr = unsafe {
            self.builder
                .build_gep(arr_ty, buf, &[zero, zero], "tag_slot")
                .map_err(Diagnostic::internal)?
        };
        self.builder
            .build_store(tag_ptr, tag_val)
            .map_err(Diagnostic::internal)?;

        // Store caller_pid = 0 (fire-and-forget, no reply expected).
        let one = self.context.i32_type().const_int(1, false);
        let caller_ptr = unsafe {
            self.builder
                .build_gep(arr_ty, buf, &[zero, one], "caller_slot")
                .map_err(Diagnostic::internal)?
        };
        self.builder
            .build_store(caller_ptr, i64_ty.const_int(0, false))
            .map_err(Diagnostic::internal)?;

        // Store handler args.
        for (i, arg) in handler_args.iter().enumerate() {
            let idx = self.context.i32_type().const_int((i + 2) as u64, false);
            let elem_ptr = unsafe {
                self.builder
                    .build_gep(arr_ty, buf, &[zero, idx], "arg_slot")
                    .map_err(Diagnostic::internal)?
            };
            self.builder
                .build_store(elem_ptr, *arg)
                .map_err(Diagnostic::internal)?;
        }

        let msg_size = i64_ty.const_int((num_elements * 8) as u64, false);

        // Call mesh_service_cast_shaped(pid, msg_ptr, msg_size, shape).
        let shape_table = self.service_args_shape(&args[2..]);
        let send_fn = get_intrinsic(&self.module, "mesh_service_cast_shaped");
        self.builder
            .build_call(
                send_fn,
                &[
                    pid_val.into(),
                    buf.into(),
                    msg_size.into(),
                    shape_table.into(),
                ],
                "",
            )
            .map_err(Diagnostic::internal)?;

        // Cast returns Unit.
        Ok(self.context.struct_type(&[], false).const_zero().into())
    }

    // ── List literal codegen ─────────────────────────────────────────

    fn codegen_list_lit(
        &mut self,
        elements: &[MirExpr],
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        // Placeholder: will be fully implemented in Task 2.
        // For now, stack-allocate an i64 array and call mesh_list_from_array.
        let i64_type = self.context.i64_type();
        let ptr_type = self.context.ptr_type(inkwell::AddressSpace::default());
        let count = elements.len();
        let array_type = i64_type.array_type(count as u32);
        let array_alloca = self
            .builder
            .build_alloca(array_type, "list_arr")
            .map_err(Diagnostic::internal)?;

        for (i, elem) in elements.iter().enumerate() {
            let val = self.codegen_expr(elem)?;
            // Convert value to i64 for uniform list storage.
            let val_as_i64 = self.convert_to_list_element(val, elem.ty())?;
            let idx = self.context.i32_type().const_int(i as u64, false);
            let zero = self.context.i32_type().const_int(0, false);
            let gep = unsafe {
                self.builder
                    .build_gep(array_type, array_alloca, &[zero, idx], "elem_ptr")
                    .map_err(Diagnostic::internal)?
            };
            self.builder
                .build_store(gep, val_as_i64)
                .map_err(Diagnostic::internal)?;
        }

        let array_ptr = self
            .builder
            .build_pointer_cast(array_alloca, ptr_type, "arr_ptr")
            .map_err(Diagnostic::internal)?;
        let count_val = i64_type.const_int(count as u64, false);

        Ok(self.codegen_runtime_call(
            "mesh_list_from_array",
            &[array_ptr.into(), count_val.into()],
            "list",
        ))
    }

    /// Convert a value to i64 for uniform list element storage.
    /// Bool (i1) -> zero-extend to i64
    /// Float (f64) -> bitcast to i64
    /// Ptr -> ptrtoint to i64
    /// Int (i64) -> use directly
    fn convert_to_list_element(
        &mut self,
        val: BasicValueEnum<'ctx>,
        mir_ty: &MirType,
    ) -> Result<inkwell::values::IntValue<'ctx>, Diagnostic> {
        let i64_type = self.context.i64_type();
        // A unit value (`{}`) has no bits to store; whatever MIR calls it.
        if matches!(val, BasicValueEnum::StructValue(sv) if sv.get_type().count_fields() == 0) {
            return Ok(i64_type.const_int(0, false));
        }
        match mir_ty {
            MirType::Bool => {
                let bool_val = val.into_int_value();
                self.builder
                    .build_int_z_extend(bool_val, i64_type, "bool_to_i64")
                    .map_err(Diagnostic::internal)
            }
            MirType::Float => {
                let float_val = val.into_float_value();
                let cast_result = self
                    .builder
                    .build_bit_cast(float_val, i64_type, "float_to_i64")
                    .map_err(Diagnostic::internal)?;
                Ok(cast_result.into_int_value())
            }
            // A tuple is a pointer to the runtime tuple.
            MirType::String | MirType::Ptr | MirType::FnPtr(_, _) | MirType::Tuple(_) => {
                let ptr_val = val.into_pointer_value();
                self.builder
                    .build_ptr_to_int(ptr_val, i64_type, "ptr_to_i64")
                    .map_err(Diagnostic::internal)
            }
            MirType::Struct(_) | MirType::SumType(_) | MirType::Closure(_, _) => {
                // An aggregate sits in the uniform slot boxed.
                let boxed = self.box_value(val, "heap_alloc")?.into_pointer_value();
                self.builder
                    .build_ptr_to_int(boxed, i64_type, "struct_ptr_to_i64")
                    .map_err(Diagnostic::internal)
            }
            // An Int or a Pid word. A unit value was stored above, and a
            // value that never comes into being is never stored.
            _ => Ok(val.into_int_value()),
        }
    }

    /// Convert an i64 value from the runtime back to a typed BasicValueEnum.
    /// This is the inverse of `convert_to_list_element`.
    pub(super) fn convert_from_list_element(
        &mut self,
        val: inkwell::values::IntValue<'ctx>,
        target_ty: &MirType,
    ) -> BasicValueEnum<'ctx> {
        let ptr_type = self.context.ptr_type(inkwell::AddressSpace::default());
        match target_ty {
            MirType::Int | MirType::Pid(_) => val.into(),
            MirType::Bool => self
                .builder
                .build_int_truncate(val, self.context.bool_type(), "i64_to_bool")
                .expect(BUILT)
                .into(),
            MirType::Float => self
                .builder
                .build_bit_cast(val, self.context.f64_type(), "i64_to_float")
                .expect(BUILT),
            // A tuple is a pointer to the runtime tuple.
            MirType::String | MirType::Ptr | MirType::FnPtr(_, _) | MirType::Tuple(_) => self
                .builder
                .build_int_to_ptr(val, ptr_type, "i64_to_ptr")
                .expect(BUILT)
                .into(),
            MirType::Struct(_) | MirType::SumType(_) | MirType::Closure(_, _) => {
                let ptr_val = self
                    .builder
                    .build_int_to_ptr(val, ptr_type, "i64_to_boxed_ptr")
                    .expect(BUILT);
                self.builder
                    .build_load(self.llvm_type(target_ty), ptr_val, "boxed_value")
                    .expect(BUILT)
            }
            // The unit value; no slot holds a value that never comes into
            // being, so none is read as one.
            MirType::Unit | MirType::Never => {
                self.context.struct_type(&[], false).const_zero().into()
            }
        }
    }

    // ── For-in over a List, Map or Set ───────────────────────────────

    fn codegen_for_in_list(
        &mut self,
        var: &str,
        collection: &MirExpr,
        filter: Option<&MirExpr>,
        body: &MirExpr,
        elem_ty: &MirType,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let list = self.codegen_expr(collection)?;
        let len = self
            .codegen_runtime_call("mesh_list_length", &[list.into()], "len")
            .into_int_value();
        let start = self.context.i64_type().const_zero();
        self.codegen_indexed_comprehension(
            (start, len),
            len,
            &[(var, elem_ty)],
            filter,
            body,
            |cg, index| {
                let raw = cg.codegen_runtime_call(
                    "mesh_list_get",
                    &[list.into(), index.into()],
                    "raw_elem",
                );
                Ok(vec![
                    cg.convert_from_list_element(raw.into_int_value(), elem_ty)
                ])
            },
        )
    }

    #[allow(clippy::too_many_arguments)]
    fn codegen_for_in_map(
        &mut self,
        key_var: &str,
        val_var: &str,
        collection: &MirExpr,
        filter: Option<&MirExpr>,
        body: &MirExpr,
        key_ty: &MirType,
        val_ty: &MirType,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let map = self.codegen_expr(collection)?;
        let len = self
            .codegen_runtime_call("mesh_map_size", &[map.into()], "map_len")
            .into_int_value();
        let start = self.context.i64_type().const_zero();
        self.codegen_indexed_comprehension(
            (start, len),
            len,
            &[(key_var, key_ty), (val_var, val_ty)],
            filter,
            body,
            |cg, index| {
                let args = [map.into(), index.into()];
                let key = cg.codegen_runtime_call("mesh_map_entry_key", &args, "raw_key");
                let value = cg.codegen_runtime_call("mesh_map_entry_value", &args, "raw_val");
                Ok(vec![
                    cg.convert_from_list_element(key.into_int_value(), key_ty),
                    cg.convert_from_list_element(value.into_int_value(), val_ty),
                ])
            },
        )
    }

    fn codegen_for_in_set(
        &mut self,
        var: &str,
        collection: &MirExpr,
        filter: Option<&MirExpr>,
        body: &MirExpr,
        elem_ty: &MirType,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let set = self.codegen_expr(collection)?;
        let len = self
            .codegen_runtime_call("mesh_set_size", &[set.into()], "set_len")
            .into_int_value();
        let start = self.context.i64_type().const_zero();
        self.codegen_indexed_comprehension(
            (start, len),
            len,
            &[(var, elem_ty)],
            filter,
            body,
            |cg, index| {
                let raw = cg.codegen_runtime_call(
                    "mesh_set_element_at",
                    &[set.into(), index.into()],
                    "raw_elem",
                );
                Ok(vec![
                    cg.convert_from_list_element(raw.into_int_value(), elem_ty)
                ])
            },
        )
    }

    // ── For-in over an Iterable or Iterator ──────────────────────────

    #[allow(clippy::too_many_arguments)]
    fn codegen_for_in_iterator(
        &mut self,
        var: &str,
        iterable: &MirExpr,
        filter: Option<&MirExpr>,
        body: &MirExpr,
        elem_ty: &MirType,
        next_fn: &str,
        iter_fn: Option<&str>,
    ) -> Result<BasicValueEnum<'ctx>, Diagnostic> {
        let i64_ty = self.context.i64_type();
        let i8_ty = self.context.i8_type();
        let ptr_ty = self.context.ptr_type(inkwell::AddressSpace::default());
        // An Iterable gives its iterator. An Iterator is its own (a runtime
        // handle, or a user struct passed to its `next` by value).
        let iterable = self.codegen_expr(iterable)?;
        let iterator = match iter_fn {
            Some(iter_fn) => self.codegen_runtime_call(iter_fn, &[iterable.into()], "iter"),
            None => iterable,
        };
        self.codegen_comprehension(
            i64_ty.const_zero(),
            &[(var, elem_ty)],
            filter,
            body,
            |cg, body_bb, merge_bb| {
                // A runtime iterator returns a pointer to its `Option`
                // (`{ tag, value }`, tag 0 for Some). A user `next` returns
                // it by value, with a scalar payload boxed; it is spilled to
                // read it the same way.
                let next = cg.codegen_runtime_call(next_fn, &[iterator.into()], "next_result");
                let (option, option_ty, boxed) = match next {
                    BasicValueEnum::StructValue(option) => {
                        let option_ty = option.get_type();
                        let slot = cg
                            .builder
                            .build_alloca(option_ty, "next_option")
                            .map_err(Diagnostic::internal)?;
                        cg.builder
                            .build_store(slot, option)
                            .map_err(Diagnostic::internal)?;
                        (slot, option_ty, true)
                    }
                    other => (
                        other.into_pointer_value(),
                        cg.context
                            .struct_type(&[i8_ty.into(), ptr_ty.into()], false),
                        false,
                    ),
                };
                let tag_ptr = cg
                    .builder
                    .build_struct_gep(option_ty, option, 0, "tag_ptr")
                    .map_err(Diagnostic::internal)?;
                let tag = cg
                    .builder
                    .build_load(i8_ty, tag_ptr, "tag")
                    .map_err(Diagnostic::internal)?
                    .into_int_value();
                let is_some = cg
                    .builder
                    .build_int_compare(IntPredicate::EQ, tag, i8_ty.const_zero(), "is_some")
                    .map_err(Diagnostic::internal)?;
                cg.builder
                    .build_conditional_branch(is_some, body_bb, merge_bb)
                    .map_err(Diagnostic::internal)?;
                Ok((option, option_ty, boxed))
            },
            |cg, (option, option_ty, boxed)| {
                let value_ptr = cg
                    .builder
                    .build_struct_gep(option_ty, option, 1, "value_ptr")
                    .map_err(Diagnostic::internal)?;
                let raw = cg
                    .builder
                    .build_load(ptr_ty, value_ptr, "raw_value")
                    .map_err(Diagnostic::internal)?
                    .into_pointer_value();
                // A boxed payload holds the value itself behind the pointer.
                // A runtime iterator hands over the element's collection
                // slot, which holds a scalar's bits or a pointer to a boxed
                // struct or sum value.
                let value = if boxed && !matches!(elem_ty, MirType::Ptr | MirType::String) {
                    cg.builder
                        .build_load(cg.llvm_type(elem_ty), raw, "unboxed_elem")
                        .map_err(Diagnostic::internal)?
                } else {
                    let slot = cg
                        .builder
                        .build_ptr_to_int(raw, i64_ty, "elem_slot")
                        .map_err(Diagnostic::internal)?;
                    cg.convert_from_list_element(slot, elem_ty)
                };
                Ok(vec![value])
            },
            |_| Ok(()),
        )
    }
}

/// The predicate of the comparison `op` (`==`, `!=`, `<`, `>`, `<=` or `>=`)
/// on signed or unsigned integers.
fn int_predicate(op: &BinOp, signed: bool) -> IntPredicate {
    use IntPredicate::*;
    let (signed_predicate, unsigned_predicate) = match op {
        BinOp::Eq => (EQ, EQ),
        BinOp::NotEq => (NE, NE),
        BinOp::Lt => (SLT, ULT),
        BinOp::Gt => (SGT, UGT),
        BinOp::LtEq => (SLE, ULE),
        _ => (SGE, UGE),
    };
    if signed {
        signed_predicate
    } else {
        unsigned_predicate
    }
}

/// The LLVM intrinsic the Math builtin `name` is, overloaded for `Int` when
/// `int` (else `Float`), and whether its float result is rounded to an `Int`.
fn math_intrinsic(name: &str, int: bool) -> Option<(&'static str, bool)> {
    Some(match (name, int) {
        ("mesh_math_abs", true) => ("llvm.abs", false),
        ("mesh_math_abs", false) => ("llvm.fabs", false),
        ("mesh_math_min", true) => ("llvm.smin", false),
        ("mesh_math_min", false) => ("llvm.minnum", false),
        ("mesh_math_max", true) => ("llvm.smax", false),
        ("mesh_math_max", false) => ("llvm.maxnum", false),
        ("mesh_math_pow", _) => ("llvm.pow", false),
        ("mesh_math_sqrt", _) => ("llvm.sqrt", false),
        ("mesh_math_floor", _) => ("llvm.floor", true),
        ("mesh_math_ceil", _) => ("llvm.ceil", true),
        ("mesh_math_round", _) => ("llvm.round", true),
        _ => return None,
    })
}
