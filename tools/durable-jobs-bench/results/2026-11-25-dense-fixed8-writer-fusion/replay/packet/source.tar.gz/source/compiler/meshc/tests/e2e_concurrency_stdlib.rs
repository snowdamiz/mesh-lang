//! End-to-end integration tests for Mesh concurrency standard library (Phase 9).
//!
//! Tests Service and Job constructs through the full compiler pipeline:
//! Mesh source -> parse -> typecheck -> MIR -> LLVM codegen -> native binary -> run.
//!
//! Tests use generous timeouts (30s) because:
//! - Each test compiles a fresh binary to a temp directory
//! - macOS Gatekeeper/XProtect adds ~1s first-run delay per unique binary
//! - When tests run in parallel, Gatekeeper checks serialize, so the Nth
//!   binary may wait up to N seconds before it even starts executing
//! - With 11 tests, worst-case startup delay is ~11s plus execution time

use std::path::{Path, PathBuf};
use std::process::Command;
use std::time::Duration;

#[path = "support/test_artifacts.rs"]
mod artifacts;

/// Helper: compile a Mesh source and run the binary with a timeout.
/// Returns stdout on success. Panics on compilation failure or timeout.
fn compile_and_run_with_timeout(source: &str, timeout_secs: u64) -> String {
    let out = compile_and_run_output(source, timeout_secs);
    assert!(
        out.status.success(),
        "binary execution failed with exit code {:?}:\nstdout: {}\nstderr: {}",
        out.status.code(),
        String::from_utf8_lossy(&out.stdout),
        String::from_utf8_lossy(&out.stderr)
    );
    String::from_utf8_lossy(&out.stdout).to_string()
}

/// Helper: compile a Mesh source and run the binary with a timeout, whatever
/// its exit status. Panics on compilation failure or timeout.
fn compile_and_run_output(source: &str, timeout_secs: u64) -> std::process::Output {
    let temp_dir = tempfile::tempdir().expect("failed to create temp dir");
    let project_dir = temp_dir.path().join("project");
    std::fs::create_dir_all(&project_dir).expect("failed to create project dir");

    let main_mesh = project_dir.join("main.mpl");
    std::fs::write(&main_mesh, source).expect("failed to write main.mpl");

    // Build with meshc
    let meshc = find_meshc();
    let output = Command::new(&meshc)
        .args(["build", project_dir.to_str().unwrap()])
        .output()
        .expect("failed to invoke meshc");

    assert!(
        output.status.success(),
        "meshc build failed:\nstdout: {}\nstderr: {}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );

    // Run the compiled binary with a timeout
    let binary = project_dir.join("project");
    let child = Command::new(&binary)
        .stdout(std::process::Stdio::piped())
        .stderr(std::process::Stdio::piped())
        .spawn()
        .unwrap_or_else(|e| panic!("failed to spawn binary at {}: {}", binary.display(), e));

    artifacts::wait_with_timeout(child, Duration::from_secs(timeout_secs))
        .unwrap_or_else(|msg| panic!("{}", msg))
}

/// Read a test fixture from the tests/e2e/ directory.
fn read_fixture(name: &str) -> String {
    let manifest_dir = env!("CARGO_MANIFEST_DIR");
    let fixture_path = Path::new(manifest_dir)
        .parent()
        .unwrap()
        .parent()
        .unwrap()
        .join("tests")
        .join("e2e")
        .join(name);
    std::fs::read_to_string(&fixture_path)
        .unwrap_or_else(|e| panic!("failed to read fixture {}: {}", fixture_path.display(), e))
}

fn find_meshc() -> PathBuf {
    artifacts::meshc_bin()
}

// ── Service E2E Tests ──────────────────────────────────────────────────

/// Test: Counter service with start, call (GetCount, Increment), and cast (Reset).
/// Exercises: service definition, init, call with reply, cast fire-and-forget.
#[test]
fn e2e_service_counter() {
    let source = read_fixture("service_counter.mpl");
    let output = compile_and_run_with_timeout(&source, 30);
    assert_eq!(output, "10\n15\n0\n");
}

/// Test: Service with multiple call/cast operations.
/// Exercises: multiple handler dispatch on type tags.
#[test]
fn e2e_service_call_cast() {
    let source = read_fixture("service_call_cast.mpl");
    let output = compile_and_run_with_timeout(&source, 30);
    assert_eq!(output, "100\n200\n0\n");
}

/// Test: Accumulator service proving state persistence across calls.
/// Exercises: functional state management (handler receives state, returns new state).
#[test]
fn e2e_service_state_management() {
    let source = read_fixture("service_state_management.mpl");
    let output = compile_and_run_with_timeout(&source, 30);
    assert_eq!(output, "6\n");
}

// ── Service Return Type E2E Tests ─────────────────────────────────────

/// Test: Service returning and accepting Bool (not Int).
/// Exercises: Bool truncation path (i64 -> i1) in codegen_service_call_helper.
#[test]
fn e2e_service_bool_return() {
    let source = read_fixture("service_bool_return.mpl");
    let output = compile_and_run_with_timeout(&source, 30);
    assert_eq!(output, "true\ntrue\nfalse\nenabled:true\ndisabled:false\n");
}

/// Test: Service returning String (pointer type) via inttoptr conversion.
/// Exercises: String/Ptr reply path in codegen_service_call_helper.
#[test]
fn e2e_service_string_return() {
    let source = read_fixture("service_string_return.mpl");
    let output = compile_and_run_with_timeout(&source, 30);
    assert_eq!(output, "hello\nworld\n");
}

/// A service call waits for its reply, not for whatever reaches the caller
/// first: a message the caller has queued, or a job's result on `main`.
#[test]
fn e2e_service_call_takes_only_its_reply() {
    let source = r#"
service Answer do
  fn init(n :: Int) -> Int do
    n
  end

  call Get() :: Int do |n|
    (n, n)
  end
end

fn ask(me) -> Int do
  let svc = Answer.start(42)
  send(me, 99)
  let v = Answer.get(svc)
  println("reply ${v}")
  0
end

actor asker() do
  receive do
    start -> ask(self())
  end
  receive do
    n -> println("mailbox ${n}")
  end
end

fn main() do
  let pid = spawn(asker)
  send(pid, 1)
  Timer.sleep(300)
  let svc = Answer.start(7)
  let job = Job.async(fn () -> 8 end)
  Timer.sleep(100)
  println("main reply ${Answer.get(svc)}")
  case Job.await(job) do
    Ok(n) -> println("job ${n}")
    Err(e) -> println("job error ${e}")
  end
end
"#;
    let output = compile_and_run_with_timeout(source, 30);
    assert_eq!(output, "reply 42\nmailbox 99\nmain reply 7\njob 8\n");
}

/// A call to a service that has stopped panics in the caller, instead of
/// reading a reply that never came.
#[test]
fn e2e_service_call_to_a_stopped_service_panics() {
    let source = r#"
service Fragile do
  fn init(n :: Int) -> Int do
    n
  end

  call Get() :: Int do |n|
    (n, n)
  end

  cast Crash() do |n|
    panic("handler failed")
    n
  end
end

fn main() do
  let svc = Fragile.start(42)
  println("get ${Fragile.get(svc)}")
  Fragile.crash(svc)
  Timer.sleep(200)
  println("after crash ${Fragile.get(svc)}")
end
"#;
    let output = compile_and_run_output(source, 30);
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert_eq!(output.status.code(), Some(101), "{stderr}");
    assert_eq!(String::from_utf8_lossy(&output.stdout), "get 42\n");
    assert!(
        stderr.contains("the service stopped before it replied"),
        "{stderr}"
    );
}

/// A service that stops while it handles a call panics its caller, which
/// would otherwise wait for good.
#[test]
fn e2e_service_stopping_during_a_call_panics_the_caller() {
    let source = r#"
service Fragile do
  fn init(n :: Int) -> Int do
    n
  end

  call Crash() :: Int do |n|
    panic("handler failed")
    (n, n)
  end
end

fn main() do
  let svc = Fragile.start(42)
  println("crash replied ${Fragile.crash(svc)}")
end
"#;
    let output = compile_and_run_output(source, 30);
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert_eq!(output.status.code(), Some(101), "{stderr}");
    assert_eq!(String::from_utf8_lossy(&output.stdout), "");
    assert!(stderr.contains("handler failed"), "{stderr}");
    assert!(
        stderr.contains("the service stopped before it replied"),
        "{stderr}"
    );
}

/// An actor still waiting on a service call when `main` returns stops, as
/// one waiting in `receive` does, and the program ends normally.
#[test]
fn e2e_service_call_pending_at_exit_stops_the_caller() {
    let source = r#"
service Blocker do
  fn init(n :: Int) -> Int do
    n
  end

  call Block() :: Int do |n|
    Timer.sleep(100000)
    (n, n)
  end
end

actor caller() do
  receive do
    go -> Blocker.block(Blocker.start(1))
  end
  println("unreachable")
end

fn main() do
  let pid = spawn(caller)
  send(pid, 1)
  Timer.sleep(200)
  println("main done")
end
"#;
    let output = compile_and_run_with_timeout(source, 30);
    assert_eq!(output, "main done\n");
}

// ── Job E2E Tests ──────────────────────────────────────────────────────

/// Test: Job.await returns the requested job when completions arrive out of order.
#[test]
fn e2e_job_async_await() {
    let source = read_fixture("job_async_await.mpl");
    let output = compile_and_run_with_timeout(&source, 30);
    assert_eq!(output, "1\n2\n");
}

/// A job that fails is an `Err` to whoever awaits it, `main` or an actor,
/// which goes on; `Job.map` reports the failed element and the others; a
/// slow job is a timeout first and its result later. (`main` waited for
/// good on a failed job, and an actor died with it.)
#[test]
fn e2e_job_failures_come_back_as_errors() {
    let source = r##"
fn fail(n :: Int) -> Int do
  if n == 2 do
    panic("job two failed")
  else
    n * 10
  end
end

fn sleepy() -> Int do
  Timer.sleep(300)
  7
end

fn report(label :: String, result) do
  case result do
    Ok(n) -> println("#{label} ok #{n}")
    Err(e) -> println("#{label} err #{e}")
  end
end

actor awaiter() do
  report("actor", Job.await(Job.async(fn () -> fail(2) end)))
  println("actor goes on")
end

fn main() do
  report("main", Job.await(Job.async(fn () -> fail(2) end)))
  List.map(Job.map([1, 2, 3], fn (n) -> fail(n) end), fn (r) -> report("map", r) end)
  let slow = Job.async(fn () -> sleepy() end)
  report("early", Job.await_timeout(slow, 10))
  report("late", Job.await(slow))
  spawn(awaiter)
  Timer.sleep(300)
end
"##;
    let output = compile_and_run_with_timeout(source, 30);
    let failure = "err Mesh panic: job two failed";
    assert_eq!(
        output,
        format!(
            "main {failure}\nmap ok 10\nmap {failure}\nmap ok 30\nearly err timeout\n\
             late ok 7\nactor {failure}\nactor goes on\n"
        )
    );
}

/// A job's result the actor never awaits is not one of its messages: its
/// `receive` gets the String sent to it (it read the result as one).
#[test]
fn e2e_receive_passes_over_an_unawaited_job_result() {
    let source = r##"
actor listener() do
  let job = Job.async(fn () -> 5 end)
  Timer.sleep(100)
  receive do
    text -> println("got #{text}")
  end
end

fn main() do
  let pid :: Pid<String> = spawn(listener)
  Timer.sleep(200)
  send(pid, "hello")
  Timer.sleep(200)
end
"##;
    let output = compile_and_run_with_timeout(source, 30);
    assert_eq!(output, "got hello\n");
}

// ── Receive-with-timeout E2E Tests ──────────────────────────────────

/// Test: receive timeout fires when no message arrives within the deadline.
/// Exercises: receive do msg -> msg after 50 -> 99 end returns 99 on timeout.
#[test]
fn test_receive_after_timeout_fires() {
    let source = r#"
actor worker() do
  let result = receive do
    msg -> msg
  after 50 -> 99 end
  println("${result}")
end

fn main() do
  spawn(worker)
end
"#;
    let output = compile_and_run_with_timeout(source, 30);
    assert_eq!(output.trim(), "99");
}

/// Test: message arrives before timeout, so the arm body runs (not timeout body).
/// Exercises: receive do msg -> msg after 5000 -> 99 end with immediate send returns 42.
#[test]
fn test_receive_after_message_arrives_before_timeout() {
    let source = r#"
actor worker() do
  let result = receive do
    msg -> msg
  after 5000 -> 99 end
  println("${result}")
end

fn main() do
  let pid = spawn(worker)
  send(pid, 42)
end
"#;
    let output = compile_and_run_with_timeout(source, 30);
    assert_eq!(output.trim(), "42");
}

/// Test: timeout body returns String type (verifies type unification end-to-end).
/// Exercises: receive do msg -> msg after 50 -> "timeout" end returns the string.
#[test]
fn test_receive_after_timeout_returns_string() {
    let source = r#"
actor worker() do
  let result = receive do
    msg -> msg
  after 50 -> "timeout" end
  println(result)
end

fn main() do
  spawn(worker)
end
"#;
    let output = compile_and_run_with_timeout(source, 30);
    assert_eq!(output.trim(), "timeout");
}

// ── Timer E2E Tests (Phase 44 Plan 02) ──────────────────────────────

/// Test: Timer.sleep(ms) suspends the actor and resumes after the delay.
/// Verifies sleep returns without hanging and doesn't crash.
#[test]
fn test_timer_sleep_basic() {
    let source = r#"
fn main() do
  Timer.sleep(50)
  println("awake")
end
"#;
    let output = compile_and_run_with_timeout(source, 30);
    assert_eq!(output.trim(), "awake");
}

/// Test: Timer.sleep doesn't block other actors. Spawns two actors: one sleeps
/// 50ms then prints "slow", the other prints "fast" immediately. Both should complete.
#[test]
fn test_timer_sleep_does_not_block_other_actors() {
    let source = r#"
actor slow() do
  Timer.sleep(50)
  println("slow")
end

actor fast() do
  println("fast")
end

fn main() do
  spawn(slow)
  spawn(fast)
  Timer.sleep(150)
end
"#;
    let output = compile_and_run_with_timeout(source, 30);
    assert!(
        output.contains("fast"),
        "Expected 'fast' in output: {}",
        output
    );
    assert!(
        output.contains("slow"),
        "Expected 'slow' in output: {}",
        output
    );
}

/// Test: Timer.send_after delivers a delayed message to the target actor.
/// The worker receives the message (99) before the 5000ms timeout.
#[test]
fn test_timer_send_after_delivers_message() {
    let source = r#"
actor worker() do
  let result = receive do
    msg -> msg
  after 5000 -> 0 end
  println("${result}")
end

fn main() do
  let pid = spawn(worker)
  Timer.send_after(pid, 50, 99)
  Timer.sleep(200)
end
"#;
    let output = compile_and_run_with_timeout(source, 30);
    assert_eq!(output.trim(), "99");
}

/// Test: Timer.send_after respects delay timing. The message is scheduled for 200ms
/// but the receive has a 5000ms timeout. The message should arrive and be received
/// rather than the timeout firing. This proves the delay is finite (not infinite).
#[test]
fn test_timer_send_after_arrives_after_delay() {
    let source = r#"
actor worker() do
  let result = receive do
    msg -> msg
  after 5000 -> 0 end
  println("${result}")
end

fn main() do
  let pid = spawn(worker)
  Timer.send_after(pid, 100, 77)
  Timer.sleep(500)
end
"#;
    let output = compile_and_run_with_timeout(source, 30);
    assert_eq!(output.trim(), "77");
}

#[test]
fn actor_send_returns_an_observable_delivery_status() {
    artifacts::ensure_mesh_rt_staticlib();
    let source = r#"
actor sink() do
  receive do
    _ -> println("received")
  end
end

fn main() do
  let pid = spawn(sink)
  let status :: Int = send(pid, 42)
  println(Int.to_string(status))
  Timer.sleep(100)
end
"#;
    let output = compile_and_run_with_timeout(source, 30);
    assert!(output.lines().any(|line| line == "0"), "{output}");
    assert!(output.lines().any(|line| line == "received"), "{output}");
}
