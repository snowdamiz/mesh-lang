//! Mid-level IR (MIR) definitions and lowering.
//!
//! The MIR is a desugared, closure-converted, monomorphized representation
//! that sits between the typed Rowan CST and LLVM IR. All types are concrete
//! (no type variables), closures are lifted to top-level functions with explicit
//! capture lists, pipe operators are desugared to function calls, and string
//! interpolation is compiled to runtime concat chains.

pub mod lower;
pub mod mono;
pub mod types;

pub use mesh_parser::ast::expr::SpawnPlacement;

use std::fmt;

use mesh_common::span::Span;
use mesh_diagnostics::{Code, Diagnostic, LineCol, SourceFile};
use rustc_hash::FxHashMap;

/// Delimits a sum instantiation's base name if it contains underscores.
/// Mesh identifiers cannot contain this character.
pub(crate) const SUM_LAYOUT_NAME_SEPARATOR: char = '$';

/// Generic sum layouts and variants are registered under their base names.
pub fn sum_type_base(name: &str) -> &str {
    if let Some((base, _)) = name
        .strip_prefix(SUM_LAYOUT_NAME_SEPARATOR)
        .and_then(|name| name.split_once(SUM_LAYOUT_NAME_SEPARATOR))
    {
        return base;
    }
    name.split_once('_').map_or(name, |(base, _)| base)
}

/// What `map` holds for the sum type `name`, or else for its base type.
pub(crate) fn by_sum_type_name<'a, V>(map: &'a FxHashMap<String, V>, name: &str) -> Option<&'a V> {
    map.get(name).or_else(|| map.get(sum_type_base(name)))
}

// ── MirModule ─────────────────────────────────────────────────────────

/// Top-level compilation unit containing all functions, structs, and sum types.
#[derive(Debug, Clone)]
pub struct MirModule {
    /// All functions (including lifted closure functions).
    pub functions: Vec<MirFunction>,
    /// Bodyless functions implemented by package-owned native archives.
    pub native_functions: Vec<MirNativeFunction>,
    /// Struct type definitions.
    pub structs: Vec<MirStructDef>,
    /// Sum type definitions.
    pub sum_types: Vec<MirSumTypeDef>,
    /// Name of main() function if present.
    pub entry_function: Option<String>,
    /// Service dispatch tables for codegen.
    pub service_dispatch: ServiceDispatch,
    /// Every actor's entry function. Another node may spawn any of them by
    /// name, so none is pruned as unreachable.
    pub actors: Vec<MirActor>,
    /// The source names and definitions of the functions, actors, and
    /// structs the program defines, by MIR name.
    pub symbols: FxHashMap<String, MirSymbol>,
}

/// How a message names a definition the program wrote, and where it is.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct MirSymbol {
    /// The name as the source spells it, with its module in a project:
    /// `Math.add`, `add/2` for an arity overload.
    pub source_name: String,
    /// The name where it is defined.
    pub definition: Option<MirSourceSpan>,
}

#[derive(Debug, Clone)]
pub struct MirActor {
    pub entry: String,
    pub terminate: Option<String>,
}

/// Maps each service loop function's name to its call and cast handlers:
/// (type_tag, handler_fn_name, num_args), in tag order.
pub type ServiceDispatch =
    std::collections::HashMap<String, (Vec<(u64, String, usize)>, Vec<(u64, String, usize)>)>;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct MirNativeFunction {
    /// Mesh-visible, module-qualified binding name.
    pub name: String,
    /// Exact external C symbol in the linked static archive.
    pub symbol: String,
    pub params: Vec<(String, MirType)>,
    pub return_type: MirType,
}

// ── MirFunction ───────────────────────────────────────────────────────

/// A function in MIR -- either a user-defined function, a lifted closure,
/// or a monomorphized generic instantiation.
#[derive(Debug, Clone)]
pub struct MirFunction {
    /// Mangled name (e.g., "identity_Int" for monomorphized generics).
    pub name: String,
    /// Parameter names and their concrete types.
    pub params: Vec<(String, MirType)>,
    /// Concrete return type.
    pub return_type: MirType,
    /// Function body expression.
    pub body: MirExpr,
    /// If true, this is a lifted closure function; first param is env_ptr.
    pub is_closure_fn: bool,
    /// Captured variables (for closure functions only).
    pub captures: Vec<(String, MirType)>,
    /// Whether the function body contains TailCall nodes (set by TCE rewrite pass).
    /// When true, codegen wraps the function body in a loop.
    pub has_tail_calls: bool,
}

// ── MirType ───────────────────────────────────────────────────────────

/// A concrete MIR type. No type variables remain -- all types are fully resolved.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub enum MirType {
    /// 64-bit signed integer.
    Int,
    /// 64-bit floating point.
    Float,
    /// Boolean (i8, 0 or 1).
    Bool,
    /// GC-managed string pointer.
    String,
    /// Unit type (void / empty tuple).
    Unit,
    /// Tuple of concrete types.
    Tuple(Vec<MirType>),
    /// Named struct reference.
    Struct(std::string::String),
    /// Named sum type reference.
    SumType(std::string::String),
    /// Known function pointer: params -> return.
    FnPtr(Vec<MirType>, Box<MirType>),
    /// Closure: {fn_ptr, env_ptr} with params -> return.
    Closure(Vec<MirType>, Box<MirType>),
    /// Raw pointer (for env_ptr, etc.).
    Ptr,
    /// Bottom type (never returns).
    Never,
    /// Actor PID, optionally typed with message type.
    /// Pid(None) = untyped Pid, Pid(Some(T)) = Pid<T>.
    Pid(Option<Box<MirType>>),
}

impl MirType {
    /// The parameter and result types of a function pointer or closure.
    pub fn function_parts(&self) -> Option<(&[MirType], &MirType)> {
        match self {
            MirType::FnPtr(params, ret) | MirType::Closure(params, ret) => Some((params, ret)),
            _ => None,
        }
    }
}

/// Where the heap references are inside a value that crosses actors.
///
/// `MirType` erases what a collection holds (`List<String>` is just `Ptr`), so
/// this is built during lowering from the type checker's full types. Codegen
/// maps it onto real offsets and boxing, and the runtime uses the result to
/// give the receiving actor its own copy; see `mesh-rt`'s `msg_shape`.
#[derive(Debug, Clone, PartialEq)]
pub enum MsgShape {
    /// No heap references: Int, Float, Bool, function pointers, handles.
    Scalar,
    /// A pid: plain bits to a copy on this node; a copy for another node
    /// names the node the process is on.
    Pid,
    /// Pointer to a string `{len, bytes}`, String or Atom. A literal lives in
    /// the program's constant data, where a copy for another node reads it.
    String,
    /// Pointer to another object with no references inside: Bytes, wide ints, Range.
    Leaf,
    /// List or Set of the element shape.
    List(Box<MsgShape>),
    Map(Box<MsgShape>, Box<MsgShape>),
    Tuple(Vec<MsgShape>),
    Queue(Box<MsgShape>),
    /// Self-describing JSON tree.
    Json,
    /// By-value struct: its MIR name and each field's shape, in declaration order.
    Struct(String, Vec<MsgShape>),
    /// By-value sum type: its MIR name and each variant's name and field shapes.
    Sum(String, Vec<(String, Vec<MsgShape>)>),
    /// The enclosing struct or sum type of this name, for recursive types.
    Recur(String),
    /// A function value `{fn, env}`. Its type does not say what it captured,
    /// but its environment does: it starts with a pointer to its own shape.
    Closure,
    /// A reference whose layout the type does not describe (an opaque runtime
    /// object, an unresolved type). It is not copied; the heap that owns it
    /// keeps it alive for the receiver.
    Shared,
}

impl MsgShape {
    /// True when the value holds no heap references at all.
    pub fn is_scalar(&self) -> bool {
        match self {
            MsgShape::Scalar => true,
            MsgShape::Tuple(_) => false,
            MsgShape::Struct(_, fields) => fields.iter().all(MsgShape::is_scalar),
            MsgShape::Sum(_, variants) => variants
                .iter()
                .all(|(_, fields)| fields.iter().all(MsgShape::is_scalar)),
            _ => false,
        }
    }
}

/// Runtime destruction plan retained after nominal resource types lower to LLVM-level pointers.
#[derive(Debug, Clone)]
pub enum MirResourceDestructor {
    /// A trusted opaque runtime handle destroyed by `mesh_resource_destroy`.
    Opaque,
    /// A raw PostgreSQL connection handle closed by `mesh_pg_close`.
    PgConnection,
    /// A by-value tuple or struct containing resource-bearing fields.
    Aggregate(Vec<MirResourceField>),
    /// A general tagged union whose resource-bearing variants require distinct
    /// field layouts and destruction plans.
    SumVariants(Vec<MirResourceVariant>),
    /// A value of a type that holds itself (through a box), whose plan
    /// would never end inline: destroyed by the generated function named,
    /// which runs the type's own plan.
    Recursive(std::string::String),
}

impl MirResourceDestructor {
    /// The resource fields an aggregate destroys; any other destructor
    /// destroys its value whole and has none.
    pub fn fields(&self) -> &[MirResourceField] {
        match self {
            MirResourceDestructor::Aggregate(fields) => fields,
            _ => &[],
        }
    }

    /// The generated functions this plan calls to destroy the values of
    /// types that hold themselves.
    pub fn functions(&self, out: &mut Vec<std::string::String>) {
        match self {
            MirResourceDestructor::Recursive(function) => out.push(function.clone()),
            MirResourceDestructor::Aggregate(fields) => fields
                .iter()
                .for_each(|field| field.destructor.functions(out)),
            MirResourceDestructor::SumVariants(variants) => variants
                .iter()
                .flat_map(|variant| &variant.resource_fields)
                .for_each(|field| field.destructor.functions(out)),
            MirResourceDestructor::Opaque | MirResourceDestructor::PgConnection => {}
        }
    }
}

#[derive(Debug, Clone)]
pub struct MirResourceField {
    pub index: u32,
    pub ty: MirType,
    pub destructor: MirResourceDestructor,
}

#[derive(Debug, Clone)]
pub struct MirResourceVariant {
    pub tag: u8,
    /// Every field is retained so codegen can reconstruct the variant overlay.
    pub field_types: Vec<MirType>,
    /// Only affine fields need destruction.
    pub resource_fields: Vec<MirResourceField>,
}

#[derive(Debug, Clone)]
pub enum MirResourceMoveSource {
    /// Move out of the named local or parameter, which is cleared.
    Slot(String),
    /// Move one field of the struct in the local `root` and destroy every
    /// other resource-bearing field in it; `root` is cleared.
    Projection {
        root: String,
        parent_ty: MirType,
        parent_destructor: MirResourceDestructor,
        field_index: u32,
        /// Additional field indices for a projection rooted below the first field.
        /// Keeping the full path lets codegen destroy siblings at every aggregate level
        /// before invalidating the one root slot.
        nested_field_indices: Vec<u32>,
    },
}

impl fmt::Display for MirType {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            MirType::Int => write!(f, "Int"),
            MirType::Float => write!(f, "Float"),
            MirType::Bool => write!(f, "Bool"),
            MirType::String => write!(f, "String"),
            MirType::Unit => write!(f, "Unit"),
            MirType::Tuple(elems) => {
                write!(f, "(")?;
                for (i, e) in elems.iter().enumerate() {
                    if i > 0 {
                        write!(f, ", ")?;
                    }
                    write!(f, "{}", e)?;
                }
                write!(f, ")")
            }
            MirType::Struct(name) => write!(f, "{}", name),
            MirType::SumType(name) => write!(f, "{}", name),
            MirType::FnPtr(params, ret) => {
                write!(f, "fn(")?;
                for (i, p) in params.iter().enumerate() {
                    if i > 0 {
                        write!(f, ", ")?;
                    }
                    write!(f, "{}", p)?;
                }
                write!(f, ") -> {}", ret)
            }
            MirType::Closure(params, ret) => {
                write!(f, "closure(")?;
                for (i, p) in params.iter().enumerate() {
                    if i > 0 {
                        write!(f, ", ")?;
                    }
                    write!(f, "{}", p)?;
                }
                write!(f, ") -> {}", ret)
            }
            MirType::Ptr => write!(f, "Ptr"),
            MirType::Never => write!(f, "Never"),
            MirType::Pid(None) => write!(f, "Pid"),
            MirType::Pid(Some(msg_ty)) => write!(f, "Pid<{}>", msg_ty),
        }
    }
}

// ── MirExpr ───────────────────────────────────────────────────────────

/// The source index assigned by the caller of MIR lowering.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct MirSourceId(pub usize);

/// A byte range in the file that supplied a lowered expression.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct MirSourceSpan {
    pub file: MirSourceId,
    pub span: Span,
}

/// The file `at` is in, named as `files` name it, and its 1-based line and
/// column: what compiled code passes the runtime for a failure it places.
pub fn runtime_location(
    files: &[SourceFile],
    at: Option<MirSourceSpan>,
) -> Option<(String, LineCol)> {
    let at = at?;
    let file = files.get(at.file.0)?;
    Some((
        file.path().display().to_string(),
        file.line_col(at.span.start)?,
    ))
}

/// `code` at `at`, in its file among `files` (which `MirSourceId` indexes),
/// or about no file when the location or its file is unknown.
pub fn diagnostic_at(
    files: &[SourceFile],
    at: Option<MirSourceSpan>,
    code: Code,
    message: impl Into<String>,
    label: impl Into<String>,
) -> Diagnostic {
    match at.and_then(|at| Some((files.get(at.file.0)?, at.span))) {
        Some((file, span)) => Diagnostic::in_file(code, file, message).at(span, label),
        None => Diagnostic::new(code, message),
    }
}

/// A MIR expression node. Each variant carries its resolved type.
#[derive(Debug, Clone)]
pub enum MirExpr {
    /// Integer literal.
    IntLit(i64, MirType),
    /// Float literal.
    FloatLit(f64, MirType, Option<MirSourceSpan>),
    /// Boolean literal.
    BoolLit(bool, MirType),
    /// String literal value.
    StringLit(std::string::String, MirType, Option<MirSourceSpan>),
    /// Variable reference.
    Var(std::string::String, MirType),
    /// Binary operation.
    BinOp {
        source_span: Option<MirSourceSpan>,
        op: BinOp,
        lhs: Box<MirExpr>,
        rhs: Box<MirExpr>,
        ty: MirType,
    },
    /// Unary operation.
    UnaryOp {
        source_span: Option<MirSourceSpan>,
        op: UnaryOp,
        operand: Box<MirExpr>,
        ty: MirType,
    },
    /// Direct function call.
    Call {
        source_span: Option<MirSourceSpan>,
        func: Box<MirExpr>,
        args: Vec<MirExpr>,
        ty: MirType,
    },
    /// Call through a closure (closure = {fn_ptr, env_ptr}).
    ClosureCall {
        source_span: Option<MirSourceSpan>,
        closure: Box<MirExpr>,
        args: Vec<MirExpr>,
        ty: MirType,
    },
    /// If-then-else expression.
    If {
        source_span: Option<MirSourceSpan>,
        cond: Box<MirExpr>,
        then_body: Box<MirExpr>,
        else_body: Box<MirExpr>,
        ty: MirType,
    },
    /// Let binding with continuation body.
    Let {
        name: std::string::String,
        /// Type of the binding's initializer.
        ty: MirType,
        value: Box<MirExpr>,
        body: Box<MirExpr>,
    },
    /// Sequence of expressions; last is the value.
    Block(Vec<MirExpr>, MirType),
    /// Pattern match (NOT yet compiled to decision tree -- that is Plan 03).
    Match {
        source_span: Option<MirSourceSpan>,
        scrutinee: Box<MirExpr>,
        arms: Vec<MirMatchArm>,
        ty: MirType,
    },
    /// Struct literal construction.
    StructLit {
        source_span: Option<MirSourceSpan>,
        name: std::string::String,
        fields: Vec<(std::string::String, MirExpr)>,
        ty: MirType,
    },
    /// Struct update: copy base struct and overwrite specific fields.
    StructUpdate {
        source_span: Option<MirSourceSpan>,
        base: Box<MirExpr>,
        overrides: Vec<(std::string::String, MirExpr)>,
        /// Resource-bearing base fields replaced by this update. Codegen destroys
        /// their old values after the replacement expression succeeds.
        resource_overrides: Vec<MirResourceField>,
        ty: MirType,
    },
    /// Field access on a struct.
    FieldAccess {
        source_span: Option<MirSourceSpan>,
        object: Box<MirExpr>,
        field: std::string::String,
        ty: MirType,
    },
    /// Construct a variant of a sum type.
    ConstructVariant {
        source_span: Option<MirSourceSpan>,
        type_name: std::string::String,
        variant: std::string::String,
        fields: Vec<MirExpr>,
        ty: MirType,
    },
    /// Create a closure object: {fn_ptr -> fn_name, env_ptr -> captures}.
    MakeClosure {
        source_span: Option<MirSourceSpan>,
        fn_name: std::string::String,
        captures: Vec<MirExpr>,
        ty: MirType,
    },
    /// Transfer ownership of an affine resource value out of its source slot.
    ResourceMove {
        source_span: Option<MirSourceSpan>,
        value: Box<MirExpr>,
        ty: MirType,
        source: MirResourceMoveSource,
    },
    /// Read an affine resource for the duration of a call without transferring it.
    ResourceBorrow {
        source_span: Option<MirSourceSpan>,
        value: Box<MirExpr>,
        ty: MirType,
    },
    /// Compiler-inserted destruction of a still-owned resource at scope exit.
    ResourceDrop {
        value: Box<MirExpr>,
        resource_ty: MirType,
        destructor: MirResourceDestructor,
    },
    /// Source-level, explicit destruction of a resource.
    ResourceDestroy {
        source_span: Option<MirSourceSpan>,
        value: Box<MirExpr>,
        resource_ty: MirType,
        destructor: MirResourceDestructor,
    },
    /// Return from function.
    Return(Box<MirExpr>, Option<MirSourceSpan>),
    /// Runtime panic with message, raised in the function `file` names, at
    /// `source_span` when it is known.
    Panic {
        message: std::string::String,
        file: std::string::String,
        source_span: Option<MirSourceSpan>,
    },
    /// Unit value (empty tuple).
    Unit,

    // ── Actor primitives ──────────────────────────────────────────────
    /// Spawn a new actor process.
    ActorSpawn {
        source_span: Option<MirSourceSpan>,
        /// The function to run as the actor body.
        func: Box<MirExpr>,
        /// Arguments to pass (initial state).
        args: Vec<MirExpr>,
        /// Priority level for shared placement (0=high, 1=normal, 2=low).
        priority: u8,
        placement: SpawnPlacement,
        /// Optional terminate callback function.
        /// When present, this is a function that takes (state, reason) and runs cleanup.
        terminate_callback: Option<Box<MirExpr>>,
        /// Result type (Pid).
        ty: MirType,
    },
    /// Send a message to an actor.
    ActorSend {
        source_span: Option<MirSourceSpan>,
        /// Target actor PID.
        target: Box<MirExpr>,
        /// Message to send.
        message: Box<MirExpr>,
        /// Observable delivery status code.
        ty: MirType,
    },
    /// A value about to cross to another actor, with the shape of the heap
    /// references inside it. Evaluates to `value`; only the send, timer and
    /// service-call sites look at `shape`.
    Shaped {
        value: Box<MirExpr>,
        shape: MsgShape,
    },
    /// Receive a message (blocking). With a handler `(name, message type,
    /// body)`, the message is bound to `name` for `body`, which matches on
    /// it; without one the message itself is the value.
    ActorReceive {
        source_span: Option<MirSourceSpan>,
        handler: Option<(String, MirType, Box<MirExpr>)>,
        /// Timeout in milliseconds (None = infinite wait).
        timeout_ms: Option<Box<MirExpr>>,
        /// Timeout body (executed if timeout fires).
        timeout_body: Option<Box<MirExpr>>,
        /// Result type.
        ty: MirType,
    },
    /// Get own PID.
    ActorSelf {
        source_span: Option<MirSourceSpan>,
        ty: MirType,
    },
    /// Link to another actor for supervision.
    ActorLink {
        source_span: Option<MirSourceSpan>,
        target: Box<MirExpr>,
        ty: MirType,
    },

    // ── Supervisor primitives ──────────────────────────────────────
    /// List literal: [e1, e2, ...]
    ListLit {
        source_span: Option<MirSourceSpan>,
        elements: Vec<MirExpr>,
        ty: MirType,
    },

    // ── Loop primitives ──────────────────────────────────────────────
    /// While loop: evaluates condition, if true executes body and repeats. Returns Unit.
    While {
        source_span: Option<MirSourceSpan>,
        cond: Box<MirExpr>,
        body: Box<MirExpr>,
        ty: MirType, // Always MirType::Unit
    },
    /// Break: exit the innermost enclosing loop.
    Break,
    /// Continue: skip to the next iteration of the innermost enclosing loop.
    Continue,

    // ── TCE primitives ──────────────────────────────────────────────
    /// Self-recursive tail call (rewritten from Call during TCE pass).
    /// Codegen compiles this as parameter reassignment + branch to loop header.
    TailCall {
        source_span: Option<MirSourceSpan>,
        /// Arguments for the recursive call (assigned to function parameters).
        args: Vec<MirExpr>,
        /// Result type (function return type, but ty() returns Never since it branches).
        ty: MirType,
    },

    /// For-in loop over an integer range: `for var in start..end do body end`.
    /// Desugared to integer counter iteration with no heap allocation.
    ForInRange {
        source_span: Option<MirSourceSpan>,
        /// Loop variable name.
        var: String,
        /// Start value (inclusive).
        start: Box<MirExpr>,
        /// End value (exclusive).
        end: Box<MirExpr>,
        /// Optional filter expression (`when condition`).
        filter: Option<Box<MirExpr>>,
        /// Loop body.
        body: Box<MirExpr>,
        /// Result type (Ptr for comprehension semantics).
        ty: MirType,
    },

    /// For-in loop over a List: `for var in list do body end`.
    /// Desugared to indexed iteration with list builder.
    ForInList {
        source_span: Option<MirSourceSpan>,
        var: String,
        collection: Box<MirExpr>,
        /// Optional filter expression (`when condition`).
        filter: Option<Box<MirExpr>>,
        body: Box<MirExpr>,
        elem_ty: MirType,
        ty: MirType,
    },

    /// For-in loop over a Map: `for {k, v} in map do body end`.
    /// Desugared to indexed iteration over map entries.
    ForInMap {
        source_span: Option<MirSourceSpan>,
        key_var: String,
        val_var: String,
        collection: Box<MirExpr>,
        /// Optional filter expression (`when condition`).
        filter: Option<Box<MirExpr>>,
        body: Box<MirExpr>,
        key_ty: MirType,
        val_ty: MirType,
        ty: MirType,
    },

    /// For-in loop over a Set: `for var in set do body end`.
    /// Desugared to indexed iteration over set elements.
    ForInSet {
        source_span: Option<MirSourceSpan>,
        var: String,
        collection: Box<MirExpr>,
        /// Optional filter expression (`when condition`).
        filter: Option<Box<MirExpr>>,
        body: Box<MirExpr>,
        elem_ty: MirType,
        ty: MirType,
    },

    /// For-in loop over any type implementing Iterable/Iterator.
    /// Desugared to repeated next() calls with Option tag checking.
    ForInIterator {
        source_span: Option<MirSourceSpan>,
        /// Loop variable name.
        var: String,
        /// The Iterable, or the Iterator itself.
        iterator: Box<MirExpr>,
        /// Optional filter expression (`when condition`).
        filter: Option<Box<MirExpr>>,
        /// Loop body.
        body: Box<MirExpr>,
        /// Resolved element type (Item type for the concrete iterator type).
        elem_ty: MirType,
        /// The function that advances the iterator: a user impl's
        /// `Iterator__next__TypeName`, or the runtime's generic `next`.
        next_fn: String,
        /// The function that gives an Iterable's iterator (`iter()`); none
        /// when the value is its own iterator.
        iter_fn: Option<String>,
        /// Result type (Ptr for comprehension semantics -- list of body results).
        ty: MirType,
    },

    /// Start a supervisor with configured strategy, limits, and child specs.
    SupervisorStart {
        /// Supervisor name (for registration and debugging).
        name: String,
        /// Strategy enum value: 0=one_for_one, 1=one_for_all, 2=rest_for_one, 3=simple_one_for_one.
        strategy: u8,
        /// Max restarts within the time window.
        max_restarts: u32,
        /// Time window in seconds.
        max_seconds: u64,
        /// Child specs as MIR-level representations.
        children: Vec<MirChildSpec>,
        /// Result type (always Pid).
        ty: MirType,
    },
}

/// The expressions directly inside `$expr`, borrowed shared or (with `mut`)
/// mutably: `children` and `children_mut` are the one list.
macro_rules! child_exprs {
    ($expr:expr, $child:ty, $iter:ident, $as_ref:ident, $as_deref:ident $(, $mut:tt)?) => {{
        let mut children: Vec<$child> = Vec::new();
        match $expr {
            MirExpr::IntLit(..)
            | MirExpr::FloatLit(..)
            | MirExpr::BoolLit(..)
            | MirExpr::StringLit(..)
            | MirExpr::Var(..)
            | MirExpr::Panic { .. }
            | MirExpr::Unit
            | MirExpr::ActorSelf { .. }
            | MirExpr::Break
            | MirExpr::Continue
            | MirExpr::SupervisorStart { .. } => {}
            MirExpr::BinOp { lhs, rhs, .. } => {
                children.push(lhs);
                children.push(rhs);
            }
            MirExpr::UnaryOp { operand, .. } => children.push(operand),
            MirExpr::Call { func, args, .. } => {
                children.push(func);
                children.extend(args.$iter());
            }
            MirExpr::ClosureCall { closure, args, .. } => {
                children.push(closure);
                children.extend(args.$iter());
            }
            MirExpr::If {
                cond,
                then_body,
                else_body,
                ..
            } => {
                children.push(cond);
                children.push(then_body);
                children.push(else_body);
            }
            MirExpr::Let { value, body, .. } => {
                children.push(value);
                children.push(body);
            }
            MirExpr::Block(exprs, _)
            | MirExpr::ListLit {
                elements: exprs, ..
            } => children.extend(exprs.$iter()),
            MirExpr::Match {
                scrutinee, arms, ..
            } => {
                children.push(scrutinee);
                for arm in arms {
                    children.extend(arm.guard.$as_ref());
                    children.push(&$($mut)? arm.body);
                }
            }
            MirExpr::StructLit { fields, .. } => {
                children.extend(fields.$iter().map(|(_, value)| value))
            }
            MirExpr::StructUpdate {
                base, overrides, ..
            } => {
                children.push(base);
                children.extend(overrides.$iter().map(|(_, value)| value));
            }
            MirExpr::FieldAccess { object, .. } => children.push(object),
            MirExpr::ConstructVariant { fields, .. } => children.extend(fields.$iter()),
            MirExpr::MakeClosure { captures, .. } => children.extend(captures.$iter()),
            MirExpr::ResourceMove { value, .. }
            | MirExpr::ResourceBorrow { value, .. }
            | MirExpr::ResourceDrop { value, .. }
            | MirExpr::ResourceDestroy { value, .. }
            | MirExpr::Shaped { value, .. }
            | MirExpr::Return(value, _) => children.push(value),
            MirExpr::ActorSpawn {
                func,
                args,
                terminate_callback,
                ..
            } => {
                children.push(func);
                children.extend(args.$iter());
                children.extend(terminate_callback.$as_deref());
            }
            MirExpr::ActorSend {
                target, message, ..
            } => {
                children.push(target);
                children.push(message);
            }
            MirExpr::ActorReceive {
                handler,
                timeout_ms,
                timeout_body,
                ..
            } => {
                children.extend(handler.$iter().map(|(_, _, body)| &$($mut)? **body));
                children.extend(timeout_ms.$as_deref());
                children.extend(timeout_body.$as_deref());
            }
            MirExpr::ActorLink { target, .. } => children.push(target),
            MirExpr::While { cond, body, .. } => {
                children.push(cond);
                children.push(body);
            }
            MirExpr::TailCall { args, .. } => children.extend(args.$iter()),
            MirExpr::ForInRange {
                start,
                end,
                filter,
                body,
                ..
            } => {
                children.push(start);
                children.push(end);
                children.extend(filter.$as_deref());
                children.push(body);
            }
            MirExpr::ForInList {
                collection,
                filter,
                body,
                ..
            }
            | MirExpr::ForInMap {
                collection,
                filter,
                body,
                ..
            }
            | MirExpr::ForInSet {
                collection,
                filter,
                body,
                ..
            }
            | MirExpr::ForInIterator {
                iterator: collection,
                filter,
                body,
                ..
            } => {
                children.push(collection);
                children.extend(filter.$as_deref());
                children.push(body);
            }
        }
        children
    }};
}

// The qualifier on the returned reference follows the input reference.
macro_rules! expression_source_span {
    ($expression:expr) => {
        match $expression {
            MirExpr::BinOp { source_span, .. }
            | MirExpr::UnaryOp { source_span, .. }
            | MirExpr::Call { source_span, .. }
            | MirExpr::ClosureCall { source_span, .. }
            | MirExpr::TailCall { source_span, .. }
            | MirExpr::If { source_span, .. }
            | MirExpr::Match { source_span, .. }
            | MirExpr::StructLit { source_span, .. }
            | MirExpr::StructUpdate { source_span, .. }
            | MirExpr::FieldAccess { source_span, .. }
            | MirExpr::ConstructVariant { source_span, .. }
            | MirExpr::MakeClosure { source_span, .. }
            | MirExpr::ResourceMove { source_span, .. }
            | MirExpr::ResourceBorrow { source_span, .. }
            | MirExpr::ResourceDestroy { source_span, .. }
            | MirExpr::ActorSpawn { source_span, .. }
            | MirExpr::ActorSend { source_span, .. }
            | MirExpr::ActorReceive { source_span, .. }
            | MirExpr::ActorSelf { source_span, .. }
            | MirExpr::ActorLink { source_span, .. }
            | MirExpr::ListLit { source_span, .. }
            | MirExpr::While { source_span, .. }
            | MirExpr::ForInRange { source_span, .. }
            | MirExpr::ForInList { source_span, .. }
            | MirExpr::ForInMap { source_span, .. }
            | MirExpr::ForInSet { source_span, .. }
            | MirExpr::ForInIterator { source_span, .. }
            | MirExpr::FloatLit(_, _, source_span)
            | MirExpr::StringLit(_, _, source_span)
            | MirExpr::Return(_, source_span) => Some(source_span),
            _ => None,
        }
    };
}

impl MirExpr {
    pub(crate) fn set_source_span(&mut self, location: MirSourceSpan) {
        if let Some(slot) = expression_source_span!(self) {
            slot.get_or_insert(location);
        }
    }

    /// Source expression that produced this MIR operation, if recorded.
    pub fn source_span(&self) -> Option<MirSourceSpan> {
        expression_source_span!(self).copied().flatten()
    }

    /// The expressions directly inside this one (match arm guards and
    /// bodies included).
    pub fn children(&self) -> Vec<&MirExpr> {
        child_exprs!(self, &MirExpr, iter, as_ref, as_deref)
    }

    /// The expressions directly inside this one, for passes that rewrite
    /// every sub-expression (match arm guards and bodies included).
    pub fn children_mut(&mut self) -> Vec<&mut MirExpr> {
        child_exprs!(self, &mut MirExpr, iter_mut, as_mut, as_deref_mut, mut)
    }

    /// This expression and every one inside it.
    pub fn descendants(&self) -> Vec<&MirExpr> {
        let mut all = vec![self];
        let mut next = 0;
        while let Some(expr) = all.get(next).copied() {
            all.extend(expr.children());
            next += 1;
        }
        all
    }

    /// The name this expression is, when it is a variable.
    pub fn var_name(&self) -> Option<&str> {
        match self {
            MirExpr::Var(name, _) => Some(name),
            _ => None,
        }
    }

    /// Get the stored type. For a `let`, this is the binding's type.
    pub fn ty(&self) -> &MirType {
        match self {
            MirExpr::IntLit(_, ty) => ty,
            MirExpr::FloatLit(_, ty, _) => ty,
            MirExpr::BoolLit(_, ty) => ty,
            MirExpr::StringLit(_, ty, _) => ty,
            MirExpr::Var(_, ty) => ty,
            MirExpr::BinOp { ty, .. } => ty,
            MirExpr::UnaryOp { ty, .. } => ty,
            MirExpr::Call { ty, .. } => ty,
            MirExpr::ClosureCall { ty, .. } => ty,
            MirExpr::If { ty, .. } => ty,
            MirExpr::Let { ty, .. } => ty,
            MirExpr::Block(_, ty) => ty,
            MirExpr::Match { ty, .. } => ty,
            MirExpr::StructLit { ty, .. } => ty,
            MirExpr::StructUpdate { ty, .. } => ty,
            MirExpr::FieldAccess { ty, .. } => ty,
            MirExpr::ConstructVariant { ty, .. } => ty,
            MirExpr::MakeClosure { ty, .. } => ty,
            MirExpr::ResourceMove { ty, .. } => ty,
            MirExpr::ResourceBorrow { ty, .. } => ty,
            MirExpr::ResourceDrop { .. } => &MirType::Unit,
            MirExpr::ResourceDestroy { .. } => &MirType::Unit,
            MirExpr::Return(_, _) => &MirType::Never,
            MirExpr::Panic { .. } => &MirType::Never,
            MirExpr::Unit => &MirType::Unit,
            MirExpr::ActorSpawn { ty, .. } => ty,
            MirExpr::ActorSend { ty, .. } => ty,
            MirExpr::Shaped { value, .. } => value.ty(),
            MirExpr::ActorReceive { ty, .. } => ty,
            MirExpr::ActorSelf { ty, .. } => ty,
            MirExpr::ActorLink { ty, .. } => ty,
            MirExpr::ListLit { ty, .. } => ty,
            MirExpr::While { ty, .. } => ty,
            MirExpr::Break => &MirType::Never,
            MirExpr::Continue => &MirType::Never,
            MirExpr::TailCall { .. } => &MirType::Never,
            MirExpr::ForInRange { ty, .. } => ty,
            MirExpr::ForInList { ty, .. } => ty,
            MirExpr::ForInMap { ty, .. } => ty,
            MirExpr::ForInSet { ty, .. } => ty,
            MirExpr::ForInIterator { ty, .. } => ty,
            MirExpr::SupervisorStart { ty, .. } => ty,
        }
    }

    /// Type of the value produced by this expression. A `let` produces its
    /// continuation's value, and a block already carries its tail's type.
    pub(crate) fn result_ty(&self) -> &MirType {
        match self {
            MirExpr::Let { body, .. } => body.result_ty(),
            _ => self.ty(),
        }
    }
}

/// A child specification in a supervisor's MIR representation.
#[derive(Debug, Clone)]
pub struct MirChildSpec {
    /// Child identifier string.
    pub id: String,
    /// Name of the start function (actor entry function).
    pub start_fn: String,
    /// Restart type: 0=permanent, 1=transient, 2=temporary.
    pub restart_type: u8,
    /// Shutdown timeout in milliseconds (0 = brutal_kill).
    pub shutdown_ms: u64,
    /// Child type: 0=worker, 1=supervisor.
    pub child_type: u8,
}

// ── MirMatchArm ───────────────────────────────────────────────────────

/// A match arm in MIR with pattern, optional guard, and body.
#[derive(Debug, Clone)]
pub struct MirMatchArm {
    /// The pattern to match.
    pub pattern: MirPattern,
    /// Optional guard expression.
    pub guard: Option<MirExpr>,
    /// The arm body.
    pub body: MirExpr,
}

// ── MirPattern ────────────────────────────────────────────────────────

/// A MIR pattern for match expressions.
#[derive(Debug, Clone)]
pub enum MirPattern {
    /// Matches anything, binds nothing.
    Wildcard,
    /// Binds a name to the matched value.
    Var(std::string::String, MirType),
    /// Matches a literal value.
    Literal(MirLiteral),
    /// Matches a sum type constructor with sub-patterns.
    Constructor {
        type_name: std::string::String,
        variant: std::string::String,
        fields: Vec<MirPattern>,
        bindings: Vec<(std::string::String, MirType)>,
    },
    /// Matches a tuple with sub-patterns.
    Tuple(Vec<MirPattern>),
    /// Matches a struct by its fields: every field of struct `name`, in
    /// declaration order, with the field's type (a field the source pattern
    /// leaves out is a `Wildcard`).
    Struct {
        name: std::string::String,
        fields: Vec<(std::string::String, MirType, MirPattern)>,
    },
    /// Or-pattern: matches if any alternative matches.
    Or(Vec<MirPattern>),
    /// List cons pattern: matches non-empty list, binding head element and tail list.
    ListCons {
        head: Box<MirPattern>,
        tail: Box<MirPattern>,
        elem_ty: MirType,
    },
    /// `[]`: matches the empty list.
    ListNil,
    /// `inner as name`: binds the whole matched value and matches `inner`.
    As {
        name: std::string::String,
        ty: MirType,
        inner: Box<MirPattern>,
    },
}

// ── MirLiteral ────────────────────────────────────────────────────────

/// A literal value used in patterns.
#[derive(Debug, Clone)]
pub enum MirLiteral {
    Int(i64),
    Float(f64),
    Bool(bool),
    String(std::string::String),
}

// ── BinOp / UnaryOp ──────────────────────────────────────────────────

/// Binary operators.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum BinOp {
    // Arithmetic
    Add,
    Sub,
    Mul,
    Div,
    Mod,
    // Comparison
    Eq,
    NotEq,
    Lt,
    Gt,
    LtEq,
    GtEq,
    // Boolean
    And,
    Or,
    // String
    Concat,
}

/// Unary operators.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum UnaryOp {
    /// Arithmetic negation.
    Neg,
    /// Boolean negation.
    Not,
}

// ── MirStructDef ──────────────────────────────────────────────────────

/// A struct type definition in MIR.
#[derive(Debug, Clone)]
pub struct MirStructDef {
    /// Struct name.
    pub name: std::string::String,
    /// Field names and their concrete types.
    pub fields: Vec<(std::string::String, MirType)>,
}

// ── MirSumTypeDef ─────────────────────────────────────────────────────

/// A sum type definition in MIR.
#[derive(Debug, Clone)]
pub struct MirSumTypeDef {
    /// Sum type name.
    pub name: std::string::String,
    /// Variant definitions with sequential tag assignments.
    pub variants: Vec<MirVariantDef>,
}

/// A single variant in a MIR sum type definition.
#[derive(Debug, Clone)]
pub struct MirVariantDef {
    /// Variant name.
    pub name: std::string::String,
    /// Field types (positional).
    pub fields: Vec<MirType>,
    /// Tag value (0, 1, 2, ...).
    pub tag: u8,
}

#[cfg(test)]
mod tests {
    use super::{MirExpr, MirResourceDestructor, MirResourceField, MirType};

    /// Errors name MIR types as written here.
    #[test]
    fn mir_types_display_as_their_names() {
        let int = || Box::new(MirType::Int);
        let shown = [
            MirType::Int,
            MirType::Float,
            MirType::Bool,
            MirType::String,
            MirType::Unit,
            MirType::Tuple(vec![MirType::Int, MirType::String]),
            MirType::Struct("Point".to_string()),
            MirType::SumType("Option_Int".to_string()),
            MirType::FnPtr(vec![MirType::Int, MirType::Bool], int()),
            MirType::Closure(vec![MirType::Ptr, MirType::Int], int()),
            MirType::Ptr,
            MirType::Never,
            MirType::Pid(None),
            MirType::Pid(Some(int())),
        ]
        .map(|ty| ty.to_string());
        assert_eq!(
            shown,
            [
                "Int",
                "Float",
                "Bool",
                "String",
                "Unit",
                "(Int, String)",
                "Point",
                "Option_Int",
                "fn(Int, Bool) -> Int",
                "closure(Ptr, Int) -> Int",
                "Ptr",
                "Never",
                "Pid",
                "Pid<Int>",
            ]
        );
    }

    /// A drop is Unit; a panic and a tail call never finish, whatever the
    /// call's own result type; a link and a supervisor's start are what
    /// lowering typed them.
    #[test]
    fn expressions_that_carry_no_type_have_theirs() {
        let unit = || Box::new(MirExpr::Unit);
        let pid = MirType::Pid(None);
        let cases = [
            (
                MirExpr::ResourceDrop {
                    value: unit(),
                    resource_ty: MirType::Ptr,
                    destructor: MirResourceDestructor::Opaque,
                },
                MirType::Unit,
            ),
            (
                MirExpr::Panic {
                    message: "boom".to_string(),
                    file: "main.mpl".to_string(),
                    source_span: None,
                },
                MirType::Never,
            ),
            (
                MirExpr::TailCall {
                    source_span: None,
                    args: Vec::new(),
                    ty: MirType::Int,
                },
                MirType::Never,
            ),
            (
                MirExpr::ActorLink {
                    source_span: None,
                    target: unit(),
                    ty: MirType::Int,
                },
                MirType::Int,
            ),
            (
                MirExpr::SupervisorStart {
                    name: "Pool".to_string(),
                    strategy: 0,
                    max_restarts: 3,
                    max_seconds: 5,
                    children: Vec::new(),
                    ty: pid.clone(),
                },
                pid,
            ),
        ];
        for (expr, ty) in cases {
            assert_eq!(expr.ty(), &ty, "{expr:?}");
        }
    }

    /// An aggregate's fields are what it destroys; a destructor of a whole
    /// value has none.
    #[test]
    fn only_an_aggregate_destructor_has_fields() {
        let field = MirResourceField {
            index: 1,
            ty: MirType::Ptr,
            destructor: MirResourceDestructor::Opaque,
        };
        let aggregate = MirResourceDestructor::Aggregate(vec![field]);
        assert_eq!(aggregate.fields().len(), 1);
        assert_eq!(aggregate.fields()[0].index, 1);
        for whole in [
            MirResourceDestructor::Opaque,
            MirResourceDestructor::PgConnection,
            MirResourceDestructor::SumVariants(Vec::new()),
        ] {
            assert!(whole.fields().is_empty(), "{whole:?}");
        }
    }

    /// A function type's parts, and none for any other type.
    #[test]
    fn function_types_have_parameters_and_a_result() {
        let params = vec![MirType::Int, MirType::String];
        for ty in [
            MirType::FnPtr(params.clone(), Box::new(MirType::Bool)),
            MirType::Closure(params.clone(), Box::new(MirType::Bool)),
        ] {
            assert_eq!(
                ty.function_parts(),
                Some((params.as_slice(), &MirType::Bool))
            );
        }
        assert_eq!(MirType::Ptr.function_parts(), None);
    }
}
