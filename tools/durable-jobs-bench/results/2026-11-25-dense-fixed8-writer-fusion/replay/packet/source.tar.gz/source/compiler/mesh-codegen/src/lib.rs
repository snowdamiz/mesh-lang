//! LLVM code generation for the Mesh compiler.
//!
//! This crate transforms a typed Mesh program (represented by the parser's
//! `Parse` and the type checker's `TypeckResult`) into native machine code
//! via LLVM, using the Inkwell safe bindings.
//!
//! ## Architecture
//!
//! - [`mir`]: Mid-level IR definitions and lowering from typed AST
//! - [`pattern`]: Pattern match compilation to decision trees
//! - [`codegen`]: LLVM IR generation from MIR
//!
//! ## Pipeline
//!
//! ```text
//! Parse + TypeckResult -> MIR -> DecisionTree -> LLVM IR -> Object file -> Native binary
//! ```

// Lowering and code generation thread their state through many parameters,
// some intermediate shapes are spelled out where they are built, and every
// failure carries a whole diagnostic.
#![allow(
    clippy::result_large_err,
    clippy::too_many_arguments,
    clippy::type_complexity
)]

pub mod codegen;
pub mod declared;
pub mod link;
pub mod mir;
pub mod pattern;

pub use declared::{
    declared_route_wrapper_name, prepare_clustered_route_handler_plan,
    prepare_declared_runtime_handlers, prepare_startup_work_registrations, DeclaredHandlerKind,
    DeclaredHandlerPlanEntry, DeclaredRuntimeRegistration, StartupWorkRegistration,
};
pub use mir::lower::{imported_specializations, verification_function_symbol};

use std::collections::{HashMap, HashSet};
use std::path::{Path, PathBuf};

use inkwell::context::Context;
use mesh_diagnostics::{Code, Diagnostic, SourceFile};

use codegen::CodeGen;
use mir::lower::lower_to_mir;
use mir::mono::monomorphize;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct LibraryExport {
    pub function: String,
    pub symbol: String,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum LibraryArtifact {
    Static,
    Dynamic,
}

pub(crate) mod build_trace {
    use std::path::{Path, PathBuf};

    use serde_json::{json, Map, Value};

    const TRACE_ENV: &str = "MESH_BUILD_TRACE_PATH";

    fn trace_path() -> Option<PathBuf> {
        std::env::var_os(TRACE_ENV).map(PathBuf::from)
    }

    /// The trace so far: empty when there is none or it is not a JSON object.
    fn read_trace(path: &Path) -> Map<String, Value> {
        std::fs::read_to_string(path)
            .ok()
            .and_then(|raw| serde_json::from_str::<Value>(&raw).ok())
            .and_then(|value| value.as_object().cloned())
            .unwrap_or_default()
    }

    fn write_trace(path: &Path, doc: &Map<String, Value>) {
        if let Some(parent) = path.parent() {
            let _ = std::fs::create_dir_all(parent);
        }
        let rendered = serde_json::to_string_pretty(doc).expect("a JSON object always renders");
        let _ = std::fs::write(path, rendered);
    }

    pub(crate) fn update<F>(mutate: F)
    where
        F: FnOnce(&mut Map<String, Value>),
    {
        let Some(path) = trace_path() else {
            return;
        };
        let mut doc = read_trace(&path);
        mutate(&mut doc);
        write_trace(&path, &doc);
    }

    pub(crate) fn set_compile_context(output: &Path, object: &Path, target_triple: Option<&str>) {
        update(|doc| {
            doc.insert(
                "buildOutputPath".to_string(),
                json!(output.display().to_string()),
            );
            doc.insert(
                "objectPath".to_string(),
                json!(object.display().to_string()),
            );
            doc.insert(
                "requestedTargetTriple".to_string(),
                target_triple
                    .map(|value| json!(value))
                    .unwrap_or(Value::Null),
            );
            doc.insert(
                "llvmSys211Prefix".to_string(),
                std::env::var("LLVM_SYS_211_PREFIX")
                    .map(Value::from)
                    .unwrap_or(Value::Null),
            );
            doc.insert(
                "cargoTargetDir".to_string(),
                std::env::var("CARGO_TARGET_DIR")
                    .map(Value::from)
                    .unwrap_or(Value::Null),
            );
            doc.insert(
                "meshRtLibPath".to_string(),
                std::env::var("MESH_RT_LIB_PATH")
                    .map(Value::from)
                    .unwrap_or(Value::Null),
            );
            doc.insert("lastStage".to_string(), json!("compile-start"));
            doc.insert("success".to_string(), json!(false));
        });
    }

    pub(crate) fn set_stage(stage: &str) {
        update(|doc| {
            doc.insert("lastStage".to_string(), json!(stage));
        });
    }

    pub(crate) fn mark_object_emission_started() {
        update(|doc| {
            doc.insert("lastStage".to_string(), json!("emit-object"));
            doc.insert("objectEmissionStarted".to_string(), json!(true));
            doc.insert("objectEmissionCompleted".to_string(), json!(false));
        });
    }

    pub(crate) fn mark_object_emitted(object: &Path) {
        update(|doc| {
            doc.insert("lastStage".to_string(), json!("object-emitted"));
            doc.insert("objectEmissionCompleted".to_string(), json!(true));
            doc.insert("objectExistsAfterEmit".to_string(), json!(object.exists()));
        });
    }

    pub(crate) fn set_link_context(
        display_target: &str,
        runtime_path: Option<&Path>,
        runtime_exists: Option<bool>,
        linker_program: Option<&Path>,
    ) {
        update(|doc| {
            doc.insert("displayTarget".to_string(), json!(display_target));
            doc.insert(
                "runtimeLibraryPath".to_string(),
                runtime_path
                    .map(|path| json!(path.display().to_string()))
                    .unwrap_or(Value::Null),
            );
            doc.insert(
                "runtimeLibraryExists".to_string(),
                runtime_exists.map(Value::from).unwrap_or(Value::Null),
            );
            doc.insert(
                "linkerProgram".to_string(),
                linker_program
                    .map(|path| json!(path.display().to_string()))
                    .unwrap_or(Value::Null),
            );
        });
    }

    pub(crate) fn mark_link_started() {
        update(|doc| {
            doc.insert("lastStage".to_string(), json!("invoke-linker"));
            doc.insert("linkStarted".to_string(), json!(true));
            doc.insert("linkCompleted".to_string(), json!(false));
        });
    }

    pub(crate) fn mark_link_completed() {
        update(|doc| {
            doc.insert("lastStage".to_string(), json!("link-completed"));
            doc.insert("linkCompleted".to_string(), json!(true));
        });
    }

    pub(crate) fn mark_success() {
        update(|doc| {
            doc.insert("lastStage".to_string(), json!("compile-succeeded"));
            doc.insert("success".to_string(), json!(true));
            doc.remove("error");
        });
    }

    pub(crate) fn record_error(error: &mesh_diagnostics::Diagnostic) {
        update(|doc| {
            doc.insert("error".to_string(), json!(crate::error_text(error)));
        });
    }
}

/// `error` as one text: `[CODE] message`, then each note on a line.
pub(crate) fn error_text(error: &Diagnostic) -> String {
    let mut text = format!("[{}] {}", error.code().id(), error.message());
    for note in error.notes() {
        text.push('\n');
        text.push_str(note);
    }
    text
}

/// Lower a parsed and type-checked Mesh program to MIR.
///
/// This runs the full MIR lowering pipeline: AST-to-MIR conversion (with
/// pipe desugaring, string interpolation compilation, and closure conversion),
/// followed by the monomorphization pass.
///
/// # Errors
///
/// Returns the first error MIR lowering reports.
pub fn lower_to_mir_module(
    parse: &mesh_parser::Parse,
    typeck: &mesh_typeck::TypeckResult,
) -> Result<mir::MirModule, Diagnostic> {
    let empty_pub_fns = HashSet::new();
    let empty_inferred_fn_usage_types: HashMap<String, Vec<mesh_typeck::ty::Ty>> = HashMap::new();
    lower_to_mir(
        parse,
        typeck,
        "",
        &empty_pub_fns,
        &empty_inferred_fn_usage_types,
    )
    .map(|mut module| {
        monomorphize(&mut module);
        module
    })
}

/// Lower one module of a project to MIR without monomorphization, which
/// needs the merged program's entry point; the project's other modules are
/// there for the default methods its impls may inherit.
pub fn lower_module_to_mir_raw<'a>(
    parse: &'a mesh_parser::Parse,
    typeck: &'a mesh_typeck::TypeckResult,
    module_name: &str,
    pub_fns: &HashSet<String>,
    inferred_fn_usage_types: &HashMap<String, Vec<mesh_typeck::ty::Ty>>,
    other_modules: &[(&'a mesh_parser::Parse, &'a mesh_typeck::TypeckResult)],
) -> Result<mir::MirModule, Diagnostic> {
    mir::lower::lower_module_to_mir(
        parse,
        typeck,
        module_name,
        pub_fns,
        inferred_fn_usage_types,
        other_modules,
    )
}

/// A single-module program's LLVM IR, written to `output`, for the tests.
#[cfg(test)]
fn compile_to_llvm_ir(
    parse: &mesh_parser::Parse,
    typeck: &mesh_typeck::TypeckResult,
    output: &Path,
    target_triple: Option<&str>,
) -> Result<(), Diagnostic> {
    let mir = lower_to_mir_module(parse, typeck)?;

    let context = Context::create();
    let mut codegen = CodeGen::new(&context, "mesh_module", 0, target_triple)?;
    codegen.compile(&mir)?;

    codegen.emit_llvm_ir(output)?;
    Ok(())
}

// ── Multi-Module Compilation (Phase 39) ────────────────────────────────

/// What code generation compiles: the program, what the build declares
/// around it, and the files its diagnostics point into.
#[derive(Clone, Copy)]
pub struct CodegenInput<'a> {
    pub mir: &'a mir::MirModule,
    pub declared_handlers: &'a [DeclaredRuntimeRegistration],
    pub startup_work_registrations: &'a [StartupWorkRegistration],
    pub autonomous_config_json: Option<&'a str>,
    pub library_exports: &'a [LibraryExport],
    /// Each source file by `MirSourceId`.
    pub files: &'a [SourceFile],
}

impl<'a> CodegenInput<'a> {
    /// `mir` alone: nothing declared or exported, and no file to point into.
    pub fn new(mir: &'a mir::MirModule) -> Self {
        Self {
            mir,
            declared_handlers: &[],
            startup_work_registrations: &[],
            autonomous_config_json: None,
            library_exports: &[],
            files: &[],
        }
    }

    /// A code generator set up for this input, before it compiles the MIR.
    fn codegen<'ctx>(
        &self,
        context: &'ctx Context,
        module_name: &str,
        opt_level: u8,
        target_triple: Option<&str>,
    ) -> Result<CodeGen<'ctx>, Diagnostic> {
        let mut codegen = CodeGen::new(context, module_name, opt_level, target_triple)?;
        codegen.set_declared_handlers(self.declared_handlers);
        codegen.set_startup_work_registrations(self.startup_work_registrations);
        codegen.set_autonomous_config_json(self.autonomous_config_json);
        codegen.set_library_exports(self.library_exports);
        codegen.set_source_files(self.files);
        Ok(codegen)
    }
}

/// Compile a pre-built MIR module to a native binary.
///
/// This accepts a MIR module directly (already lowered and optionally merged
/// from multiple source modules) and produces a native executable.
pub fn compile_mir_to_binary(
    input: CodegenInput<'_>,
    output: &Path,
    opt_level: u8,
    target_triple: Option<&str>,
    runtime_flavor: link::RuntimeFlavor,
    rt_lib_path: Option<&Path>,
    native_archives: &[PathBuf],
) -> Result<(), Diagnostic> {
    let obj_path = output.with_extension("o");
    build_trace::set_compile_context(output, &obj_path, target_triple);
    let link_plan = match runtime_flavor {
        link::RuntimeFlavor::Standard => {
            link::prepare_link_with_native(target_triple, rt_lib_path, native_archives)
        }
        link::RuntimeFlavor::Test => {
            link::prepare_test_link_with_native(target_triple, rt_lib_path, native_archives)
        }
    }?;

    let result: Result<(), Diagnostic> = (|| -> Result<(), Diagnostic> {
        build_trace::set_stage("pre-llvm-init");
        let context = Context::create();
        let mut codegen = input.codegen(&context, "mesh_module", opt_level, target_triple)?;

        build_trace::set_stage("compile-llvm-module");
        codegen.compile(input.mir)?;

        build_trace::set_stage("run-optimization-passes");
        codegen.run_optimization_passes(opt_level)?;

        build_trace::mark_object_emission_started();
        codegen.emit_object(&obj_path)?;
        build_trace::mark_object_emitted(&obj_path);

        link::link_with_plan(&obj_path, output, &link_plan)?;
        Ok(())
    })();

    finish_trace(result)
}

/// Record how the build ended in the build trace.
fn finish_trace(result: Result<(), Diagnostic>) -> Result<(), Diagnostic> {
    result
        .inspect(|()| build_trace::mark_success())
        .inspect_err(build_trace::record_error)
}

pub fn compile_mir_to_library(
    input: CodegenInput<'_>,
    artifact: LibraryArtifact,
    output: &Path,
    opt_level: u8,
    target_triple: Option<&str>,
    rt_lib_path: Option<&Path>,
    native_archives: &[PathBuf],
) -> Result<(), Diagnostic> {
    if input.library_exports.is_empty() {
        return Err(Diagnostic::new(
            Code::ArtifactEntryMissing,
            "library artifacts require at least one `@export` function",
        )
        .with_repair(
            "Mark a public function `@export(\"symbol\")` for a host to call, or build an executable from a program with `fn main()`.",
        ));
    }
    let obj_path = output.with_extension("o");
    build_trace::set_compile_context(output, &obj_path, target_triple);
    let link_plan = link::prepare_link_with_native(target_triple, rt_lib_path, native_archives)?;

    let result = (|| {
        let context = Context::create();
        let mut codegen = input.codegen(&context, "mesh_library", opt_level, target_triple)?;

        let mut library_mir = input.mir.clone();
        library_mir.entry_function = None;
        codegen.compile(&library_mir)?;
        codegen.run_optimization_passes(opt_level)?;
        codegen.emit_object(&obj_path)?;
        match artifact {
            LibraryArtifact::Static => link::archive_with_plan(&obj_path, output, &link_plan),
            LibraryArtifact::Dynamic => link::link_dynamic_with_plan(&obj_path, output, &link_plan),
        }
    })();

    finish_trace(result)
}

/// Compile a pre-built MIR module to LLVM IR text.
pub fn compile_mir_to_llvm_ir(
    input: CodegenInput<'_>,
    output: &Path,
    opt_level: u8,
    target_triple: Option<&str>,
) -> Result<(), Diagnostic> {
    let context = Context::create();
    let mut codegen = input.codegen(&context, "mesh_module", opt_level, target_triple)?;
    codegen.compile(input.mir)?;
    codegen.emit_llvm_ir(output)
}

/// Merge multiple MIR modules into a single module.
///
/// Functions, struct definitions, and sum type definitions from all modules
/// are combined. The entry function is taken from the designated entry module.
/// Duplicate struct/sum type definitions (e.g., builtins registered in every
/// module) are deduplicated by name.
///
/// After merging, runs the monomorphization pass to eliminate unreachable
/// functions (which requires the entry point from the merged module).
pub fn merge_mir_modules(
    modules: Vec<mir::MirModule>,
    entry_module_idx: usize,
    extra_reachable_fns: &[String],
) -> mir::MirModule {
    use std::collections::HashSet;

    let mut merged = mir::MirModule {
        functions: Vec::new(),
        native_functions: Vec::new(),
        structs: Vec::new(),
        sum_types: Vec::new(),
        entry_function: None,
        service_dispatch: std::collections::HashMap::new(),
        actors: Vec::new(),
        symbols: Default::default(),
    };

    let mut seen_functions: HashSet<String> = HashSet::new();
    let mut seen_native_functions: HashSet<String> = HashSet::new();
    let mut seen_structs: HashSet<String> = HashSet::new();
    let mut seen_sum_types: HashSet<String> = HashSet::new();

    // Process entry module first so its lowered `mesh_main` wins if multiple
    // modules define a source-level `fn main()`.
    if let Some(entry) = modules.get(entry_module_idx) {
        merged.entry_function = entry.entry_function.clone();
    }

    let mut merge_module = |module: &mir::MirModule| {
        for func in &module.functions {
            if seen_functions.insert(func.name.clone()) {
                merged.functions.push(func.clone());
            }
        }
        for function in &module.native_functions {
            if seen_native_functions.insert(function.name.clone()) {
                merged.native_functions.push(function.clone());
            }
        }
        for s in &module.structs {
            if seen_structs.insert(s.name.clone()) {
                merged.structs.push(s.clone());
            }
        }
        for st in &module.sum_types {
            if seen_sum_types.insert(st.name.clone()) {
                merged.sum_types.push(st.clone());
            }
        }
        for (key, value) in &module.service_dispatch {
            merged
                .service_dispatch
                .entry(key.clone())
                .or_insert_with(|| value.clone());
        }
        merged.actors.extend(module.actors.iter().cloned());
        for (name, symbol) in &module.symbols {
            merged
                .symbols
                .entry(name.clone())
                .or_insert_with(|| symbol.clone());
        }
    };

    if let Some(entry) = modules.get(entry_module_idx) {
        merge_module(entry);
    }

    for (idx, module) in modules.iter().enumerate() {
        if idx == entry_module_idx {
            continue;
        }
        merge_module(module);
    }

    // Imported grouped spawns must certify the same callbacks as local spawns.
    let mut actors = std::collections::HashMap::new();
    for actor in &merged.actors {
        actors
            .entry(actor.entry.as_str())
            .or_insert(actor.terminate.as_ref());
    }
    if actors.values().any(Option::is_some) {
        let mut expressions: Vec<_> = merged
            .functions
            .iter_mut()
            .map(|function| &mut function.body)
            .collect();
        while let Some(expr) = expressions.pop() {
            if let mir::MirExpr::ActorSpawn {
                func,
                placement: mir::SpawnPlacement::Grouped,
                terminate_callback,
                ..
            } = expr
            {
                if let Some(callback) = func
                    .var_name()
                    .and_then(|name| actors.get(name))
                    .copied()
                    .flatten()
                {
                    *terminate_callback = Some(Box::new(mir::MirExpr::Var(
                        callback.clone(),
                        mir::MirType::FnPtr(
                            vec![mir::MirType::Ptr, mir::MirType::Ptr],
                            Box::new(mir::MirType::Unit),
                        ),
                    )));
                }
            }
            expressions.extend(expr.children_mut());
        }
    }

    // Run monomorphization on the merged module to eliminate unreachable
    // functions (builtins like Ord__compare__String that are generated in
    // every module but only used if referenced from main).
    // Keep manifest-declared executable symbols alive even if the local Mesh
    // entrypoint never references them directly; declared-handler preparation
    // runs after merge and still needs those lowered functions available.
    crate::mir::mono::monomorphize_with_roots(&mut merged, extra_reachable_fns);

    merged
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::mir::{MirExpr, MirFunction, MirModule, MirType};
    use std::fs;
    use std::time::{SystemTime, UNIX_EPOCH};

    /// The LLVM IR of `source`, a program that type-checks cleanly.
    fn llvm_of(source: &str) -> String {
        let parse = mesh_parser::parse(source);
        let typeck = mesh_typeck::check(&parse);
        assert!(typeck.errors.is_empty(), "{:?}", typeck.errors);
        let stamp = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("system clock before unix epoch")
            .as_nanos();
        let ll_path = std::env::temp_dir().join(format!("mesh-codegen-test-{stamp}.ll"));
        compile_to_llvm_ir(&parse, &typeck, &ll_path, None).expect("failed to emit llvm");
        let llvm = fs::read_to_string(&ll_path).expect("failed to read emitted llvm");
        let _ = fs::remove_file(&ll_path);
        llvm
    }

    fn jobs_handler_key<'a>(llvm: &'a str, symbol: &str) -> &'a str {
        let global = format!("@jobs_handler_{symbol} = ");
        llvm.lines()
            .find_map(|line| {
                let (_, string) = line.strip_prefix(&global)?.split_once(" c\"")?;
                let (name, _) = string.split_once("\\00\"")?;
                Some(name)
            })
            .unwrap_or_else(|| panic!("missing registry key for {symbol}"))
    }

    #[test]
    fn indexed_sum_uses_one_llvm_layout_for_all_lengths() {
        use mesh_typeck::ty::{NatIndex, Ty};

        let source = r#"
type Indexed_Vec<n :: Nat, T> do
  Empty -> Indexed_Vec<0, T>
  Push<k :: Nat>(T, Indexed_Vec<k, T>) -> Indexed_Vec<Succ<k>, T>
end

fn first<T, n :: Nat>(values :: Indexed_Vec<Succ<n>, T>) -> T do
  case values do
    Push(head, _) -> head
  end
end

fn rest<T, n :: Nat>(values :: Indexed_Vec<Succ<n>, T>) -> Indexed_Vec<n, T> do
  case values do
    Push(_, tail) -> tail
  end
end

fn main() -> Int do
  let one :: Indexed_Vec<1, Int> = Push(10, Empty)
  let two :: Indexed_Vec<2, Int> = Push(32, one)
  first(two) + first(rest(two))
end
"#;
        let parse = mesh_parser::parse(source);
        assert!(parse.ok(), "{:?}", parse.errors());
        let typeck = mesh_typeck::check(&parse);
        assert!(typeck.errors.is_empty(), "{:?}", typeck.errors);
        let (mut mir, signatures) = mir::lower::lower_module_to_mir_with_signatures(
            &parse,
            &typeck,
            "",
            &HashSet::new(),
            &HashMap::new(),
            &[],
            |_| Some(mir::MirSourceId(0)),
        )
        .unwrap();

        let mut lengths = Vec::new();
        for signature in signatures
            .iter()
            .filter(|entry| entry.source_name == "first")
        {
            let Ty::Fun(params, result) = &signature.signature else {
                panic!("{signature:?}");
            };
            assert_eq!(**result, Ty::int());
            assert!(params[0].con().unwrap().indexed_origin.is_some());
            let [Ty::Nat(NatIndex::Literal(length)), element] =
                params[0].args_of("Indexed_Vec").unwrap()
            else {
                panic!("{params:?}");
            };
            assert_eq!(*element, Ty::int());
            lengths.push(*length);
        }
        lengths.sort_unstable();
        assert_eq!(lengths, [1, 2]);
        let rest = signatures
            .iter()
            .find(|entry| entry.source_name == "rest")
            .unwrap();
        let rest_case = "case values do\n    Push(_, tail) -> tail\n  end";
        let start = source.find(rest_case).unwrap() as u32;
        let case_range =
            rowan::TextRange::new(start.into(), (start + rest_case.len() as u32).into());
        assert_eq!(
            rest.expression_types[&case_range]
                .args_of("Indexed_Vec")
                .unwrap(),
            [Ty::Nat(NatIndex::Literal(1)), Ty::int()],
        );

        let vec_layouts: Vec<_> = mir
            .sum_types
            .iter()
            .filter(|layout| layout.name.starts_with("Indexed_Vec"))
            .collect();
        assert_eq!(vec_layouts.len(), 1);
        assert_eq!(vec_layouts[0].name, "Indexed_Vec");
        assert_eq!(
            vec_layouts[0].variants[1].fields,
            [MirType::Ptr, MirType::Ptr]
        );

        monomorphize(&mut mir);
        let context = Context::create();
        let mut codegen = CodeGen::new(&context, "indexed", 0, None).unwrap();
        codegen.compile(&mir).unwrap();
        let llvm = codegen.get_llvm_ir();
        let calls: Vec<_> = llvm
            .lines()
            .filter(|line| line.contains("call i64 @first"))
            .collect();
        assert_eq!(calls.len(), 2, "{calls:?}");
        let argument_type = |call: &str| {
            let (_, argument) = call.split_once('(').unwrap();
            argument
                .strip_suffix(')')
                .unwrap()
                .rsplit_once(' ')
                .unwrap()
                .0
                .to_owned()
        };
        let layout = argument_type(calls[0]);
        assert!(layout.starts_with("{ i8, ["), "{layout}");
        assert_eq!(argument_type(calls[1]), layout);
        assert!(
            llvm.lines()
                .any(|line| line.contains(&format!("load {layout}, ptr %boxed_variant_payload"))),
            "rest does not load its boxed {layout} payload"
        );
    }

    #[test]
    fn durable_jobs_emit_native_calls_and_a_bare_runner_callback() {
        let llvm = llvm_of(
            r#"
from Jobs import start

fn handle(job :: String) -> String do job end

fn transaction_body(conn :: borrow PgConn) -> Result<String, String> do
  Jobs.enqueue_in(conn, "app", "{}")
end

fn exercise(pool :: PoolHandle, runner :: Int) do
  let _ = Jobs.migrate(pool)
  let _ = Jobs.enqueue(pool, "app", "{}")
  let _ = Repo.transaction(pool, transaction_body)
  let _ = Jobs.control(pool, "app", "{}")
  let _ = pool |> start("{}", handle)
  let _ = Jobs.stop(runner, 100)
  let _ = Jobs.join(runner)
  let _ = Jobs.read_events(runner, 32)
  Jobs.status(runner)
end

fn main() do
  case Pool.open("postgres://localhost/db", 1, 2, 100) do
    Ok(pool) -> inspect(exercise(pool, 1))
    Err(error) -> error
  end
end
"#,
        );
        assert!(!llvm.contains("call ptr @mesh_jobs_start_effects_v1("));
        assert!(!llvm.contains("call ptr @mesh_jobs_effect_v1("));
        for (symbol, arguments) in [
            ("migrate", "i64"),
            ("enqueue", "i64, ptr, ptr"),
            ("enqueue_in", "i64, ptr, ptr"),
            ("control", "i64, ptr, ptr"),
            ("start", "i64, ptr, ptr, ptr"),
            ("stop", "i64, i64"),
            ("join", "i64"),
            ("status", "i64"),
            ("read_events", "i64, i64"),
        ] {
            assert!(llvm.contains(&format!("declare ptr @mesh_jobs_{symbol}({arguments})")));
            assert!(llvm.contains(&format!("call ptr @mesh_jobs_{symbol}(")));
        }
        assert!(
            llvm.lines()
                .any(|line| line.contains("call ptr @mesh_jobs_start(")
                    && line.ends_with("ptr @handle, ptr null)")),
            "{llvm}"
        );
    }

    #[test]
    fn compiled_jobs_effect_fixture_uses_the_versioned_abi() {
        let llvm = llvm_of(include_str!(
            "../../../scripts/fixtures/jobs-effect-compiled/main.mpl"
        ));
        assert!(
            llvm.lines().any(|line| {
                line.contains("call ptr @mesh_jobs_start_effects_v1(")
                    && line.contains("ptr @handler, ptr null, ptr")
            }),
            "{llvm}"
        );
        assert!(llvm.contains("call ptr @mesh_jobs_effect_v1("));
        assert!(llvm.contains("call void @mesh_jobs_register_handler("));
        assert!(llvm.contains("call void @mesh_jobs_enter_worker("));
    }

    #[test]
    fn durable_jobs_register_resolved_handlers_before_startup() {
        use mesh_typeck::{ImportContext, ModuleExports};

        let workers = mesh_parser::parse("pub fn imported(job :: String) -> String do job end");
        let workers_typeck = mesh_typeck::check(&workers);
        assert!(
            workers_typeck.errors.is_empty(),
            "{:?}",
            workers_typeck.errors
        );
        let exports = mesh_typeck::collect_exports(&workers, &workers_typeck);
        let mut imports = ImportContext::empty();
        imports.module_exports.insert(
            "Workers".to_string(),
            ModuleExports::new("Workers".to_string(), &exports),
        );
        let main = mesh_parser::parse(
            r#"
import Workers
from Workers import imported
from Jobs import start

actor boot() do () end
fn ordinary(job :: String) -> String do job end
fn local(job :: String) -> String do ordinary(job) end
fn unreachable(job :: String) -> String do job end

fn dead_runner(pool :: PoolHandle) do Jobs.start(pool, "{}", unreachable) end

fn run(pool :: PoolHandle) do
  let _ = Jobs.start(pool, "{}", Workers.imported)
  let _ = imported |3> Jobs.start(pool, "{}")
  pool |> start("{}", local)
end

fn main() do
  case Pool.open("postgres://localhost/db", 1, 2, 100) do
    Ok(pool) -> inspect(run(pool))
    Err(error) -> error
  end
end
"#,
        );
        assert!(main.ok(), "{:?}", main.errors());
        let main_typeck = mesh_typeck::check_with_imports(&main, &imports);
        assert!(main_typeck.errors.is_empty(), "{:?}", main_typeck.errors);

        let workers = lower_module_to_mir_raw(
            &workers,
            &workers_typeck,
            "Workers",
            &exports.functions.keys().cloned().collect(),
            &HashMap::new(),
            &[],
        )
        .unwrap();
        let main = lower_module_to_mir_raw(
            &main,
            &main_typeck,
            "Main",
            &HashSet::new(),
            &HashMap::new(),
            &[],
        )
        .unwrap();
        let mir = merge_mir_modules(vec![workers, main], 1, &[]);
        let context = Context::create();
        let mut codegen = CodeGen::new(&context, "jobs", 0, None).unwrap();
        codegen.set_declared_handlers(&[DeclaredRuntimeRegistration {
            runtime_registration_name: "Main.boot".into(),
            executable_symbol: "boot".into(),
            replication_count: 1,
        }]);
        codegen.set_startup_work_registrations(&[StartupWorkRegistration {
            runtime_registration_name: "Main.boot".into(),
        }]);
        codegen.compile(&mir).unwrap();
        let llvm = codegen.get_llvm_ir();

        let registrations: Vec<_> = llvm
            .lines()
            .map(str::trim)
            .filter(|line| line.starts_with("call void @mesh_jobs_register_handler("))
            .collect();
        assert_eq!(registrations, [
            "call void @mesh_jobs_register_handler(ptr @jobs_handler_Main__local, i64 28, ptr @Main__local)",
            "call void @mesh_jobs_register_handler(ptr @jobs_handler_imported, i64 25, ptr @imported)",
        ]);
        let local_key = jobs_handler_key(&llvm, "Main__local");
        let fingerprint = local_key.strip_suffix(":Main__local").unwrap();
        assert_eq!(fingerprint.len(), 16);
        assert!(fingerprint.bytes().all(|byte| byte.is_ascii_hexdigit()));
        assert_eq!(
            jobs_handler_key(&llvm, "imported"),
            format!("{fingerprint}:imported")
        );
        assert!(llvm.contains("call ptr @Main__ordinary("));
        let starts: Vec<_> = llvm
            .lines()
            .filter(|line| line.contains("call ptr @mesh_jobs_start("))
            .collect();
        assert_eq!(starts.len(), 3);
        assert!(starts[0].ends_with("ptr @imported, ptr null)"));
        assert!(starts[1].ends_with("ptr @imported, ptr null)"));
        assert!(starts[2].ends_with("ptr @Main__local, ptr null)"));

        let (_, wrapper) = llvm.split_once("define i32 @main(i32 %0, ptr %1)").unwrap();
        let startup_order = [
            "call void @mesh_rt_init()",
            "call void @mesh_rt_init_actor(",
            "call void @mesh_register_function(",
            "call void @mesh_register_declared_handler(",
            "call void @mesh_register_startup_work(",
            registrations[0],
            registrations[1],
            "call void @mesh_jobs_enter_worker(i32 %0, ptr %1)",
            "call void @mesh_run_main(",
            "call void @mesh_trigger_startup_work()",
        ];
        let mut remaining = wrapper;
        for call in startup_order {
            let (_, after) = remaining
                .split_once(call)
                .unwrap_or_else(|| panic!("missing or out of order: {call}\n{wrapper}"));
            remaining = after;
        }
    }

    #[test]
    fn durable_jobs_keys_change_with_compiled_code() {
        let source = r#"
fn handler(_job :: String) -> String do "first build" end

fn main() do
  case Pool.open("postgres://localhost/db", 1, 2, 100) do
    Ok(pool) -> inspect(Jobs.start(pool, "{}", handler))
    Err(error) -> error
  end
end
"#;
        let first = llvm_of(source);
        let repeated = llvm_of(source);
        let changed = llvm_of(&source.replace("first build", "other build"));
        let key = jobs_handler_key(&first, "handler");
        assert_eq!(jobs_handler_key(&repeated, "handler"), key);
        assert_ne!(jobs_handler_key(&changed, "handler"), key);
    }

    #[test]
    fn merge_mir_modules_prefers_entry_module_mesh_main_when_multiple_modules_define_main() {
        let merged = merge_mir_modules(
            vec![
                MirModule {
                    functions: vec![MirFunction {
                        name: "mesh_main".to_string(),
                        params: Vec::new(),
                        return_type: MirType::Int,
                        body: MirExpr::IntLit(1, MirType::Int),
                        is_closure_fn: false,
                        captures: Vec::new(),
                        has_tail_calls: false,
                    }],
                    structs: Vec::new(),
                    sum_types: Vec::new(),
                    entry_function: Some("mesh_main".to_string()),
                    service_dispatch: std::collections::HashMap::new(),
                    actors: Vec::new(),
                    native_functions: Vec::new(),
                    symbols: Default::default(),
                },
                MirModule {
                    functions: vec![MirFunction {
                        name: "mesh_main".to_string(),
                        params: Vec::new(),
                        return_type: MirType::Int,
                        body: MirExpr::IntLit(2, MirType::Int),
                        is_closure_fn: false,
                        captures: Vec::new(),
                        has_tail_calls: false,
                    }],
                    structs: Vec::new(),
                    sum_types: Vec::new(),
                    entry_function: Some("mesh_main".to_string()),
                    service_dispatch: std::collections::HashMap::new(),
                    actors: Vec::new(),
                    native_functions: Vec::new(),
                    symbols: Default::default(),
                },
            ],
            1,
            &[],
        );

        let entry = merged
            .functions
            .iter()
            .find(|function| function.name == "mesh_main")
            .expect("merged MIR should retain mesh_main");

        assert_eq!(merged.entry_function.as_deref(), Some("mesh_main"));
        match &entry.body {
            MirExpr::IntLit(value, MirType::Int) => assert_eq!(*value, 2),
            other => panic!("expected entry mesh_main body from entry module, got {other:?}"),
        }
    }

    #[test]
    fn llvm_codegen_prefers_local_string_binding_over_same_named_function() {
        let source = r#"
fn node_name() -> String do
  "fn"
end

fn request_registry_name_for_node(node_name :: String) -> String do
  if String.length(node_name) > 0 do
    "cluster_proof_work_requests@#{node_name}"
  else
    "cluster_proof_work_requests"
  end
end

fn main() do
  request_registry_name_for_node("peer")
end
"#;
        let llvm = llvm_of(source);

        let request_fn = llvm
            .split("define ptr @request_registry_name_for_node")
            .nth(1)
            .and_then(|rest| rest.split("define ").next())
            .expect("request_registry_name_for_node body missing from llvm");

        assert!(
            request_fn.contains("mesh_string_length(ptr %"),
            "expected request_registry_name_for_node to pass a local pointer into mesh_string_length, got:\n{request_fn}"
        );
        assert!(
            !request_fn.contains("mesh_string_length(ptr @node_name)"),
            "request_registry_name_for_node must not pass the same-named function symbol to mesh_string_length:\n{request_fn}"
        );
        assert!(
            !request_fn.contains("mesh_string_concat(ptr %str, ptr @node_name)"),
            "request_registry_name_for_node must interpolate the local binding, not the function symbol:\n{request_fn}"
        );
    }

    #[test]
    fn native_binding_lowers_to_an_external_symbol_declaration() {
        let source = r#"
@native("mesh_math_add")
pub fn add(left :: Int, right :: Int) -> Int

fn main() -> Int do
  20 |> add(22)
end
"#;
        let llvm = llvm_of(source);

        assert!(
            llvm.contains("declare i64 @mesh_math_add(i64, i64)"),
            "native declaration missing:\n{llvm}"
        );
        assert!(
            llvm.contains("call i64 @mesh_math_add(i64 20, i64 22)"),
            "native call missing:\n{llvm}"
        );
        assert!(!llvm.contains("define i64 @add"));
    }

    /// A move or a drop empties a resource's slot with a zero of the slot's
    /// own type. A tuple, held in its slot as a pointer, was zeroed as the
    /// whole tuple: the store overran the slot into the frame, and a later
    /// return jumped to address 0.
    #[test]
    fn a_resource_slot_is_emptied_as_its_own_type() {
        let llvm = llvm_of(
            r#"
fn pair() -> (SecretBytes, SecretBytes)!CryptoError do
  Ok((Secret.random(8)?, Secret.random(8)?))
end

fn spend(p :: (SecretBytes, SecretBytes)) do
  let (a, b) = p
  Secret.destroy(a)
  Secret.destroy(b)
end

fn main() do
  case pair() do
    Ok(p) -> spend(p)
    Err(_) -> nil
  end
end
"#,
        );
        let mut slots = std::collections::HashMap::new();
        let mut zeroed = 0;
        for line in llvm.lines().map(str::trim) {
            if line.starts_with("define ") {
                slots.clear();
            } else if let Some((slot, ty)) = line.split_once(" = alloca ") {
                slots.insert(
                    slot.to_string(),
                    ty.split(", align").next().unwrap().to_string(),
                );
            } else if let Some(store) = line.strip_prefix("store ") {
                let Some((ty, slot)) = store.split_once(" zeroinitializer, ptr ") else {
                    continue;
                };
                let slot = slot.split(',').next().unwrap();
                if let Some(slot_ty) = slots.get(slot) {
                    zeroed += 1;
                    assert_eq!(ty, slot_ty, "zeroing {slot}");
                }
            }
        }
        assert!(zeroed > 0, "no slot was emptied:\n{llvm}");
    }

    /// A resource scope whose value cannot finish (every arm of the `case`
    /// ends in the tail call) keeps no drop after it. The drop followed the
    /// `case`'s unreachable merge block, which LLVM refused as a terminator
    /// in the middle of a block.
    #[test]
    fn a_resource_scope_ending_in_tail_calls_has_nothing_after_them() {
        let llvm = llvm_of(
            r#"
fn step(s :: SecretBytes, n :: Int) -> Result<(SecretBytes, Int), String> do
  Ok((s, n))
end

fn steps(s :: consume SecretBytes, n :: Int) -> Int!String do
  if n >= 3 do
    Secret.destroy(s)
    Ok(n)
  else
    case step(s, n) do
      Err(e) -> Err(e)
      Ok(values) -> do
        let (s, m) = values
        steps(s, m + 1)
      end
    end
  end
end

fn main() do
  nil
end
"#,
        );
        assert!(llvm.contains("define"), "{llvm}");
    }
}
