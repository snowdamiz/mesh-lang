use std::thread::{self, JoinHandle};

use super::super::store::{complete_and_refill, FusedReceipt, RefillRequest};
use super::*;

struct Member {
    id: String,
    token: String,
    ready_at: Instant,
}

type Disposition = Option<Result<Settlement, JobsAckError>>;

struct Write {
    session: JobSession,
    members: Vec<Member>,
    future_slots: usize,
}

struct Receipt {
    session: JobSession,
    outcome: WriteOutcome,
}

enum WriteOutcome {
    Ordinary(Vec<Disposition>),
    Fused(Lease, FusedReceipt),
    Retry,
}

pub(super) struct GroupedWriter {
    requests: Option<SyncSender<Write>>,
    receipts: Receiver<Receipt>,
    thread: Option<JoinHandle<()>>,
    in_flight: Vec<String>,
    policy: GroupedPolicy,
    runner: u64,
    claims: usize,
    claim_slots: usize,
    claims_while_writing: usize,
    widths: [usize; MAX_COMPLETE_COHORT],
    refill_flushes: usize,
    saturated_flushes: usize,
    max_collection_us: u128,
    future_slots: usize,
    fused_submitted: usize,
    fused_with_pending: usize,
    fused_rejected: usize,
    fused_uncertain: usize,
    fused_fallback: usize,
    fused_commits: usize,
    fused_replacements: usize,
    standalone_nonempty: usize,
    fused_links: Vec<(String, Vec<String>)>,
}

impl GroupedWriter {
    pub(super) fn start(
        runner: &Runner,
        policy: GroupedPolicy,
        workers: &str,
    ) -> std::io::Result<Self> {
        let (requests, writes) = mpsc::sync_channel::<Write>(1);
        let (send, receipts) = mpsc::sync_channel(1);
        let namespace = runner.config.namespace.clone();
        let dispatcher = thread::current();
        let queue = runner
            .config
            .queues
            .keys()
            .next()
            .expect("writer queue")
            .clone();
        let workers = workers.to_owned();
        let lease_ms = runner.config.lease_ms;
        let observe = runner.events.is_some();
        let thread = thread::Builder::new()
            .name(format!("mesh-jobs-grouped-{}", runner.id))
            .spawn(move || {
                while let Ok(mut write) = writes.recv() {
                    let outcome = if write.future_slots == 0 {
                        WriteOutcome::Ordinary(settle(
                            &namespace,
                            &mut write.session,
                            &write.members,
                        ))
                    } else {
                        fuse(
                            &mut write,
                            RefillRequest {
                                namespace: &namespace,
                                queue: &queue,
                                workers: &workers,
                                lease_ms,
                                slots: 0,
                                observe,
                            },
                        )
                    };
                    if send
                        .send(Receipt {
                            session: write.session,
                            outcome,
                        })
                        .is_err()
                    {
                        break;
                    }
                    dispatcher.unpark();
                }
            })?;
        Ok(Self {
            requests: Some(requests),
            receipts,
            thread: Some(thread),
            in_flight: Vec::new(),
            policy,
            runner: runner.id,
            claims: 0,
            claim_slots: 0,
            claims_while_writing: 0,
            widths: [0; MAX_COMPLETE_COHORT],
            refill_flushes: 0,
            saturated_flushes: 0,
            max_collection_us: 0,
            future_slots: 0,
            fused_submitted: 0,
            fused_with_pending: 0,
            fused_rejected: 0,
            fused_uncertain: 0,
            fused_fallback: 0,
            fused_commits: 0,
            fused_replacements: 0,
            standalone_nonempty: 0,
            fused_links: Vec::new(),
        })
    }

    pub(super) fn busy(&self) -> bool {
        !self.in_flight.is_empty()
    }

    pub(super) fn claim_dispatched(&mut self, slots: usize) {
        self.claims += usize::from(slots != 0);
        self.claim_slots += slots;
        self.claims_while_writing += usize::from(slots != 0 && self.busy());
    }

    pub(super) fn ordinary_grants(&mut self, grants: usize) {
        self.standalone_nonempty += usize::from(grants != 0);
    }

    fn mode(&self) -> &'static str {
        match self.policy {
            GroupedPolicy::Zero => "zero",
            GroupedPolicy::Fixed8ms => "fixed8ms",
            GroupedPolicy::FusedFixed8ms => "fused_fixed8ms",
            GroupedPolicy::Refill8ms => "refill8ms",
        }
    }

    pub(super) fn enabled(&self) -> bool {
        self.requests.is_some()
    }

    pub(super) fn flush(
        &mut self,
        runner: &Runner,
        io: &mut LifecycleIo,
        attempts: &[Attempt],
        refill_due: bool,
    ) -> Option<Instant> {
        let requests = self.requests.as_ref()?;
        if self.busy() {
            return None;
        }
        let now = Instant::now();
        let hold = if self.policy == GroupedPolicy::Zero {
            Duration::ZERO
        } else {
            Duration::from_millis(8)
        };
        let mut deadline = now + hold;
        let mut eligible = {
            let state = runner.state.lock();
            if !matches!(state.phase, Phase::Running)
                || state
                    .queues
                    .values()
                    .any(|queue| !matches!(queue.phase, QueuePhase::Running))
            {
                deadline = now;
            }
            attempts
                .iter()
                .filter_map(|attempt| {
                    let ready = ready_at(&state, attempt)?;
                    let lease = attempt.lease.as_ref()?;
                    deadline = deadline.min(ready + hold).min(lease.expires_at);
                    if let Some(renewal) = lease.renew_at {
                        deadline = deadline.min(renewal);
                    }
                    Some((ready, attempt))
                })
                .collect::<Vec<_>>()
        };
        if eligible.is_empty() {
            return None;
        }
        let demand = refill_due && self.policy == GroupedPolicy::Refill8ms;
        if eligible.len() < MAX_COMPLETE_COHORT && !demand && now < deadline {
            return Some(deadline);
        }
        eligible.sort_unstable_by_key(|(ready, _)| *ready);
        let members: Vec<_> = eligible
            .iter()
            .take(MAX_COMPLETE_COHORT)
            .map(|(ready_at, attempt)| Member {
                id: attempt.id.clone(),
                token: attempt.token.clone(),
                ready_at: *ready_at,
            })
            .collect();
        let future_slots = if self.policy == GroupedPolicy::FusedFixed8ms {
            // This reservation is wholly covered by charged cohort members.
            // A queued ordinary batch remains charged on its own lane.
            let queue = runner.config.queues.keys().next().expect("writer queue");
            let mut state = runner.state.lock();
            let local = &state.queues[queue];
            if matches!(state.phase, Phase::Running)
                && matches!(local.phase, QueuePhase::Running)
                && local.next_claim <= now
                && !crate::process_signal::shutdown_requested()
                && eligible
                    .iter()
                    .take(MAX_COMPLETE_COHORT)
                    .all(|(_, attempt)| &attempt.queue == queue)
                && !attempts
                    .iter()
                    .any(|attempt| &attempt.queue == queue && attempt.blocks_claims())
            {
                let active = state
                    .jobs
                    .values()
                    .filter(|job| &job.queue == queue)
                    .count();
                let pending = state.pending_for(queue);
                let cohort = members.len();
                let total_pending = state.pending.as_ref().map_or(0, |pending| pending.slots);
                if let Err(error) = (runner.check_worker)() {
                    state.fail_launch(error, runner.config.shutdown_grace_ms);
                    0
                } else {
                    let slots = cohort
                        .min(local.limit.saturating_sub(active + pending - cohort))
                        .min(
                            MAX_IN_FLIGHT.saturating_sub(state.jobs.len() + total_pending - cohort),
                        );
                    self.fused_with_pending += usize::from(slots != 0 && pending != 0);
                    slots
                }
            } else {
                0
            }
        } else {
            0
        };
        let session = io
            .session
            .take()
            .expect("idle grouped writer owns lifecycle session");
        // The dispatcher keeps its own attempt records until an idle commit or
        // token-fenced scalar response. Only the socket moves to the writer.
        self.in_flight = members.iter().map(|member| member.token.clone()).collect();
        let oldest = members[0].ready_at;
        self.future_slots = future_slots;
        if let Err(error) = requests.try_send(Write {
            session,
            members,
            future_slots,
        }) {
            let write = match error {
                mpsc::TrySendError::Disconnected(write) | mpsc::TrySendError::Full(write) => write,
            };
            io.session = Some(write.session);
            self.in_flight.clear();
            self.future_slots = 0;
            self.requests.take();
            runner.storage_failure(
                Operation::Acknowledge,
                "Jobs grouped writer unavailable".into(),
                None,
            );
            return Some(now);
        }
        self.fused_submitted += usize::from(future_slots != 0);
        self.widths[self.in_flight.len() - 1] += 1;
        if demand {
            self.refill_flushes += 1;
            self.saturated_flushes +=
                usize::from(attempts.len() >= runner.config.queues.values().sum());
        }
        self.max_collection_us = self
            .max_collection_us
            .max(now.saturating_duration_since(oldest).as_micros());
        None
    }

    pub(super) fn receive(
        &mut self,
        runner: &Runner,
        io: &mut LifecycleIo,
        attempts: &mut Vec<Attempt>,
        freed: &mut HashSet<String>,
        start_worker: &StartWorker,
    ) {
        if !self.busy() {
            return;
        }
        let mut replacements = None;
        let outcome = match self.receipts.try_recv() {
            Ok(receipt) => {
                io.session = Some(receipt.session);
                receipt.outcome
            }
            Err(TryRecvError::Empty) => return,
            Err(TryRecvError::Disconnected) => {
                self.requests.take();
                if self.future_slots != 0 {
                    // An internal failure lost the validated provisional tokens.
                    runner.request_stop(Duration::from_millis(runner.config.shutdown_grace_ms));
                }
                WriteOutcome::Ordinary(
                    (0..self.in_flight.len())
                        .map(|_| {
                            Some(Err(JobsAckError::Unconfirmed(
                                "Jobs grouped writer disconnected during settlement".into(),
                            )))
                        })
                        .collect(),
                )
            }
        };
        self.future_slots = 0;
        let mut provisional = Vec::new().into_iter();
        let mut eligible = [false; MAX_COMPLETE_COHORT];
        let dispositions = match outcome {
            WriteOutcome::Ordinary(dispositions) => dispositions,
            WriteOutcome::Retry => {
                self.fused_rejected += 1;
                (0..self.in_flight.len()).map(|_| None).collect()
            }
            WriteOutcome::Fused(lease, receipt) => match receipt.commit {
                Ok(()) => {
                    self.fused_commits += 1;
                    self.fused_replacements += receipt.claims.len();
                    self.fused_fallback += usize::from(receipt.fallback);
                    replacements = Some((lease, receipt.claims));
                    receipt
                        .completed
                        .iter()
                        .take(self.in_flight.len())
                        .map(|done| done.then_some(Ok(Settlement::Completed)))
                        .collect()
                }
                Err(error) => {
                    self.fused_uncertain += 1;
                    let message = error.message();
                    eligible = receipt.completed;
                    provisional = receipt
                        .claims
                        .into_iter()
                        .map(|claim| (claim.id, claim.token))
                        .collect::<Vec<_>>()
                        .into_iter();
                    (0..self.in_flight.len())
                        .map(|_| Some(Err(JobsAckError::Unconfirmed(message.clone()))))
                        .collect()
                }
            },
        };
        let mut confirmed = HashSet::new();
        let mut witness_parent = None;
        for (index, (token, disposition)) in self.in_flight.drain(..).zip(dispositions).enumerate()
        {
            let attempt = attempts
                .iter_mut()
                .find(|attempt| attempt.token == token)
                .expect("in-flight settlement still owns its slot");
            attempt.submissions = 1;
            if eligible[index] {
                attempt.provisional = provisional.next();
            }
            let Some(disposition) = disposition else {
                continue;
            };
            let (duration, identity) = {
                let state = runner.state.lock();
                let job = &state.jobs[&token];
                let Execution::Acknowledging {
                    handler_duration_ms,
                    ..
                } = &job.execution
                else {
                    unreachable!("grouped writer received a reaped success");
                };
                (*handler_duration_ms, job.identity.clone())
            };
            let acknowledgement = Acknowledgement {
                submission: 1,
                handler_duration_ms: duration,
                failure_kind: None,
            };
            if !attempt.ack_result(runner, acknowledgement, identity.as_ref(), disposition) {
                if witness_parent.is_none()
                    && replacements
                        .as_ref()
                        .is_some_and(|(_, claims)| !claims.is_empty())
                    && self.fused_links.len() < 1024
                {
                    witness_parent = Some(attempt.id.clone());
                }
                confirmed.insert(token);
            }
        }
        if !confirmed.is_empty() {
            let mut state = runner.state.lock();
            attempts.retain(|attempt| {
                if !confirmed.contains(&attempt.token) {
                    return true;
                }
                state.jobs.remove(&attempt.token);
                freed.insert(attempt.queue.clone());
                false
            });
            if let Some((lease, claims)) = replacements {
                if let Some(parent) = witness_parent {
                    self.fused_links.push((
                        parent,
                        claims.iter().map(|claim| claim.id.clone()).collect(),
                    ));
                }
                let queue = runner.config.queues.keys().next().expect("writer queue");
                state.counts.observe_queued_context_bytes(
                    claims.iter().map(|claim| claim.context.len()).sum(),
                );
                for claim in claims {
                    attempts.push(launch_confirmed(
                        runner,
                        &mut state,
                        queue,
                        lease,
                        claim,
                        start_worker,
                    ));
                }
            }
        }
    }
}

fn fuse(write: &mut Write, mut request: RefillRequest<'_>) -> WriteOutcome {
    request.slots = write.future_slots;
    let keys: Vec<_> = write
        .members
        .iter()
        .map(|member| (member.id.as_str(), member.token.as_str()))
        .collect();
    match write.session.with(|db| {
        let lease = Lease::begin(Duration::from_millis(request.lease_ms))?;
        Ok(complete_and_refill(db, request, &keys).map(|receipt| (lease, receipt)))
    }) {
        Ok(Ok((lease, Some(receipt)))) => WriteOutcome::Fused(lease, receipt),
        _ => WriteOutcome::Retry,
    }
}

impl Drop for GroupedWriter {
    fn drop(&mut self) {
        self.requests.take();
        if let Some(thread) = self.thread.take() {
            let _ = thread.join();
        }
        eprintln!(
            "jobs_grouped_writer {}",
            serde_json::json!({
                "runner": self.runner,
                "mode": self.mode(),
                "confirmed_free_claims": self.claims,
                "requested_slots": self.claim_slots,
                "claims_while_writing": self.claims_while_writing,
                "cohort_submissions_by_width": self.widths,
                "refill_flushes": self.refill_flushes,
                "saturated_flushes": self.saturated_flushes,
                "max_collection_us": self.max_collection_us,
                "fused_submitted": self.fused_submitted,
                "fused_with_pending": self.fused_with_pending,
                "fused_rejected": self.fused_rejected,
                "fused_uncertain": self.fused_uncertain,
                "fused_fallback": self.fused_fallback,
                "fused_commits": self.fused_commits,
                "fused_replacements": self.fused_replacements,
                "standalone_nonempty": self.standalone_nonempty,
                "fused_links": self.fused_links,
            })
        );
    }
}

fn ready_at(state: &State, attempt: &Attempt) -> Option<Instant> {
    match &state.jobs[&attempt.token].execution {
        Execution::Acknowledging {
            reply,
            retry_at: None,
            ready_at,
            ..
        } if attempt.submissions == 0
            && attempt.lease.is_some()
            && matches!(reply.outcome().0, Outcome::Complete) =>
        {
            Some(*ready_at)
        }
        _ => None,
    }
}

fn settle(namespace: &str, session: &mut JobSession, members: &[Member]) -> Vec<Disposition> {
    if let [member] = members {
        return vec![Some(
            session
                .with(|db| {
                    Ok(finish(
                        db,
                        namespace,
                        &member.id,
                        &member.token,
                        Outcome::Complete,
                    ))
                })
                .map_err(JobsAckError::Rejected)
                .and_then(|result| result),
        )];
    }
    let keys: Vec<_> = members
        .iter()
        .map(|member| (member.id.as_str(), member.token.as_str()))
        .collect();
    match session.with(|db| Ok(complete_batch(db, namespace, &keys))) {
        Ok(Ok(completed)) => completed
            .into_iter()
            .take(members.len())
            .map(|completed| completed.then_some(Ok(Settlement::Completed)))
            .collect(),
        Ok(Err(JobsAckError::Unconfirmed(error))) => members
            .iter()
            .map(|_| Some(Err(JobsAckError::Unconfirmed(error.clone()))))
            .collect(),
        // A failed checkout or a rejected statement can use the scalar path.
        _ => members.iter().map(|_| None).collect(),
    }
}
