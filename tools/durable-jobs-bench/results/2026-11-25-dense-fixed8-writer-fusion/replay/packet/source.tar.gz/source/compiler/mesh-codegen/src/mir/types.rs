//! Type resolution: Ty -> MirType conversion.
//!
//! Converts the type checker's `Ty` representation to the concrete `MirType`
//! used in MIR. After type checking, all types should be fully resolved
//! (no remaining type variables).

use mesh_typeck::ty::{Ty, TyCon};
use mesh_typeck::TypeRegistry;

use super::lower::ty_head;
use super::{MirType, SUM_LAYOUT_NAME_SEPARATOR};

/// Convert a type checker `Ty` to a concrete `MirType`.
///
/// The `type_registry` is used to determine whether a named type is a struct
/// or a sum type.
/// The registry projects compile-time indices out of the checked type before
/// lowering its representation.
///
/// A function type always resolves to a closure `{fn, env}`, the one
/// representation a function *value* has: `env` is null for a plain named
/// function (`codegen_var`), the convention the runtime's higher-order
/// functions already follow. A bare `FnPtr` is only the type lowering gives a
/// known function it calls or hands to the runtime by name. Resolving stored
/// and pattern-bound functions to `FnPtr` made them load one word of a
/// two-word value and call it without its environment.
///
pub fn resolve_type(ty: &Ty, registry: &TypeRegistry) -> MirType {
    resolve_runtime_type(&registry.runtime_type(ty), registry)
}

fn resolve_runtime_type(ty: &Ty, registry: &TypeRegistry) -> MirType {
    match ty {
        Ty::Var(_v) => {
            // Unresolved type variables can occur when the type checker produces
            // errors or when types are not fully constrained. Fall back to Unit
            // for MIR lowering to proceed. The type error was already reported
            // during type checking.
            MirType::Unit
        }

        Ty::Nat(_) => unreachable!("a Nat index cannot occur as a runtime value type"),

        Ty::Con(con) => resolve_con(con, registry),

        Ty::Fun(params, ret) => {
            let param_types = params
                .iter()
                .map(|p| resolve_runtime_type(p, registry))
                .collect();
            let ret_type = Box::new(resolve_runtime_type(ret, registry));
            MirType::Closure(param_types, ret_type)
        }

        Ty::App(..) => {
            let (name, args) = ty_head(ty).expect("an applied type has a named head");
            resolve_app(name, args, registry)
        }

        Ty::Tuple(elems) => {
            if elems.is_empty() {
                MirType::Unit
            } else {
                let mir_elems: Vec<MirType> = elems
                    .iter()
                    .map(|e| resolve_runtime_type(e, registry))
                    .collect();
                MirType::Tuple(mir_elems)
            }
        }

        Ty::Never => MirType::Never,
    }
}

/// Resolve a type constructor (no type arguments).
fn resolve_con(con: &TyCon, registry: &TypeRegistry) -> MirType {
    // These nominal types are opaque to Mesh code, but their runtime ABI is an
    // unboxed u64 handle. Keep that representation even when a handle is also
    // registered as an affine resource for ownership checking.
    if matches!(
        con.name.as_str(),
        "SqliteConn" | "PgConn" | "PoolHandle" | "Channel"
    ) {
        return MirType::Int;
    }

    if registry.sum_type_defs.contains_key(&con.name) {
        return MirType::SumType(con.name.clone());
    }

    if registry.is_resource_name(&con.name)
        && registry
            .struct_defs
            .get(&con.name)
            .is_none_or(|definition| definition.fields.is_empty())
    {
        return MirType::Ptr;
    }

    match con.name.as_str() {
        "Int" => MirType::Int,
        "Float" => MirType::Float,
        "Bool" => MirType::Bool,
        "String" => MirType::String,
        "Unit" | "()" => MirType::Unit,
        "Pid" => MirType::Pid(None),
        // DateTime is an i64 Unix milliseconds value at the ABI level (Phase 136).
        // Must be lowered to Int to avoid LLVM opaque struct allocation errors.
        "DateTime" => MirType::Int,
        // Collection types, Json, HTTP types, and iterator handles are opaque pointers at LLVM level.
        "List" | "Map" | "Set" | "Range" | "Queue" | "Tuple" | "Json" | "Bytes"
        | "BytesError" | "SecretBytes" | "SecretMap"
        | "U64" | "U128" | "I128"
        | "Router" | "Request" | "Response"
        | "Iter" | "ListIterator" | "MapIterator" | "SetIterator" | "RangeIterator"
        // Phase 78: Adapter iterator types
        | "MapAdapterIterator" | "FilterAdapterIterator" | "TakeAdapterIterator"
        | "SkipAdapterIterator" | "EnumerateAdapterIterator" | "ZipAdapterIterator"
        // Ptr is an explicit opaque pointer type; the database builders' values
        // are opaque runtime objects of their own types.
        | "Ptr" | "Query" | "Expr" | "Changeset"
        // Phase 119: Regex is a heap-allocated opaque pointer (Box<regex::Regex> raw ptr)
        | "Regex" => MirType::Ptr,
        // Atom type resolves to String at MIR level (atoms are compile-time only, lowered to StringLit)
        "Atom" => MirType::String,
        // A `BinaryError` without the package that declares its variants (a
        // sum type, resolved above) is what the runtime hands over: a pointer
        // to its tag. As an opaque struct it had no size, and no function
        // could hold one.
        "BinaryError" if !registry.struct_defs.contains_key("BinaryError") => MirType::Ptr,
        // A struct (sum types were resolved above), or a name no definition
        // gives here, which is laid out as an opaque struct: a type of a
        // module lowered later, which a generic function here is specialized
        // at, names that module's struct.
        name => MirType::Struct(name.to_string()),
    }
}

/// Resolve a type application (e.g., Option<Int>, Result<T, E>, or user struct/sum).
fn resolve_app(base_name: &str, args: &[Ty], registry: &TypeRegistry) -> MirType {
    // Collection types are opaque pointers regardless of type parameters. So is
    // a tuple known only by its first elements (`Ty::tuple_row`): a tuple is a
    // pointer whatever it holds.
    if matches!(
        base_name,
        "List" | "Map" | "Set" | "Range" | "Queue" | "Iter" | mesh_typeck::ty::TUPLE_ROW
    ) {
        return MirType::Ptr;
    }

    // A channel is a runtime handle whatever it carries.
    if base_name == "Channel" {
        return MirType::Int;
    }

    // `Plaintext<T>` is a label the type checker follows: at run time it
    // is its value.
    if let (mesh_typeck::ty::PLAINTEXT, [inner]) = (base_name, args) {
        return resolve_runtime_type(inner, registry);
    }

    // Handle Pid<M> -> MirType::Pid(Some(M))
    if let ("Pid", [msg_ty]) = (base_name, args) {
        return MirType::Pid(Some(Box::new(resolve_runtime_type(msg_ty, registry))));
    }

    // For monomorphization: generate a mangled name from base + args
    if args.is_empty() {
        // No-arg application, e.g., Ty::App(Con("Point"), [])
        return resolve_con(&TyCon::new(base_name), registry);
    }

    let mangled_name = mangle_runtime_type_name(base_name, args, registry);

    // Check if this is a sum type or struct
    if registry.sum_type_defs.contains_key(base_name) {
        MirType::SumType(mangled_name)
    } else if registry.struct_defs.contains_key(base_name) {
        MirType::Struct(mangled_name)
    } else {
        // Fallback: treat as a sum type (Option, Result are sum types)
        MirType::SumType(mangled_name)
    }
}

/// Generate a mangled type name for a monomorphized generic type.
///
/// E.g., `Option<Int>` -> `"Option_Int"`, `Result<Int, String>` -> `"Result_Int_String"`.
pub fn mangle_type_name(base: &str, args: &[Ty], registry: &TypeRegistry) -> String {
    let args: Vec<_> = args
        .iter()
        .filter(|arg| !matches!(arg, Ty::Nat(_)))
        .map(|arg| registry.runtime_type(arg))
        .collect();
    mangle_runtime_type_name(base, &args, registry)
}

fn mangle_runtime_type_name(base: &str, args: &[Ty], registry: &TypeRegistry) -> String {
    // Unknown nominal applications also use sum layout lookup, since another
    // module can supply the definition after this module's lowering.
    let uses_sum_layout =
        registry.sum_type_defs.contains_key(base) || !registry.struct_defs.contains_key(base);
    let mut name = if !args.is_empty() && base.contains('_') && uses_sum_layout {
        format!("{SUM_LAYOUT_NAME_SEPARATOR}{base}{SUM_LAYOUT_NAME_SEPARATOR}")
    } else {
        base.to_string()
    };
    for arg in args {
        name.push('_');
        let suffix = match arg {
            Ty::Con(constructor) if registry.is_resource_name(&constructor.name) => {
                constructor.name.clone()
            }
            _ => mir_type_suffix(&resolve_runtime_type(arg, registry)),
        };
        name.push_str(&suffix);
    }
    name
}

/// Get a short suffix string for a MirType (used in name mangling).
fn mir_type_suffix(ty: &MirType) -> String {
    match ty {
        MirType::Int => "Int".to_string(),
        MirType::Float => "Float".to_string(),
        MirType::Bool => "Bool".to_string(),
        MirType::String => "String".to_string(),
        MirType::Unit => "Unit".to_string(),
        MirType::Tuple(elems) => {
            let parts: Vec<String> = elems.iter().map(mir_type_suffix).collect();
            format!("Tuple_{}", parts.join("_"))
        }
        MirType::Struct(name) | MirType::SumType(name) => name.clone(),
        // `resolve_type` makes every function type a closure.
        MirType::FnPtr(params, ret) | MirType::Closure(params, ret) => {
            let p: Vec<String> = params.iter().map(mir_type_suffix).collect();
            format!("Closure_{}_to_{}", p.join("_"), mir_type_suffix(ret))
        }
        MirType::Ptr => "Ptr".to_string(),
        MirType::Never => "Never".to_string(),
        MirType::Pid(None) => "Pid".to_string(),
        MirType::Pid(Some(msg_ty)) => format!("Pid_{}", mir_type_suffix(msg_ty)),
    }
}

/// Convert a MIR type back to a typeck `Ty` for TraitRegistry lookups.
///
/// This is the reverse of `resolve_type`: given a `MirType` produced during
/// lowering, reconstruct the `Ty` representation needed to query the
/// `TraitRegistry` (e.g., `has_impl`, `find_method_traits`).
///
/// Complex types (tuples, closures, function pointers) map to
/// `Ty::Con(TyCon::new("Unknown"))` since trait impls for those types
/// are not expected in v1.3.
pub fn mir_type_to_ty(mir_type: &MirType) -> Ty {
    match mir_type {
        MirType::Int => Ty::int(),
        MirType::Float => Ty::float(),
        MirType::String => Ty::string(),
        MirType::Bool => Ty::bool(),
        MirType::Struct(name) => Ty::Con(TyCon::new(name)),
        MirType::SumType(name) => Ty::Con(TyCon::new(name)),
        _ => Ty::Con(TyCon::new("Unknown")),
    }
}

/// Extract the type name string from a `MirType` for use in mangled names.
///
/// Used to construct the `Type` segment of `Trait__Method__Type` mangled
/// names. Returns the human-readable type name (e.g., "Int", "Point").
pub fn mir_type_to_impl_name(mir_type: &MirType) -> String {
    match mir_type {
        MirType::Int => "Int".to_string(),
        MirType::Float => "Float".to_string(),
        MirType::String => "String".to_string(),
        MirType::Bool => "Bool".to_string(),
        MirType::Struct(name) => name.clone(),
        MirType::SumType(name) => name.clone(),
        _ => "Unknown".to_string(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use mesh_typeck::ty::Ty;
    use mesh_typeck::TypeRegistry;

    fn empty_registry() -> TypeRegistry {
        TypeRegistry::new()
    }

    /// `Plaintext<T>` costs nothing at run time: it is laid out as `T`,
    /// alone or inside another type.
    #[test]
    fn plaintext_is_its_value() {
        let registry = empty_registry();
        assert_eq!(
            resolve_type(&Ty::plaintext(Ty::string()), &registry),
            MirType::String
        );
        assert_eq!(
            resolve_type(&Ty::plaintext(Ty::int()), &registry),
            MirType::Int
        );
        assert_eq!(
            resolve_type(&Ty::option(Ty::plaintext(Ty::string())), &registry),
            resolve_type(&Ty::option(Ty::string()), &registry)
        );
    }

    #[test]
    fn resolve_int() {
        let reg = empty_registry();
        assert_eq!(resolve_type(&Ty::int(), &reg), MirType::Int);
    }

    #[test]
    fn resolve_float() {
        let reg = empty_registry();
        assert_eq!(resolve_type(&Ty::float(), &reg), MirType::Float);
    }

    #[test]
    fn resolve_bool() {
        let reg = empty_registry();
        assert_eq!(resolve_type(&Ty::bool(), &reg), MirType::Bool);
    }

    #[test]
    fn resolve_string() {
        let reg = empty_registry();
        assert_eq!(resolve_type(&Ty::string(), &reg), MirType::String);
    }

    #[test]
    fn resolve_unit_tuple() {
        let reg = empty_registry();
        assert_eq!(resolve_type(&Ty::Tuple(vec![]), &reg), MirType::Unit);
    }

    #[test]
    fn resolve_tuple() {
        let reg = empty_registry();
        let ty = Ty::Tuple(vec![Ty::int(), Ty::string()]);
        assert_eq!(
            resolve_type(&ty, &reg),
            MirType::Tuple(vec![MirType::Int, MirType::String])
        );
    }

    #[test]
    fn a_function_type_is_a_closure_wherever_it_appears() {
        let reg = empty_registry();
        let callback = Ty::fun(vec![Ty::int()], Ty::string());
        let closure = MirType::Closure(vec![MirType::Int], Box::new(MirType::String));
        assert_eq!(resolve_type(&callback, &reg), closure);
        // Nested in a parameter, a tuple and a generic argument too.
        assert_eq!(
            resolve_type(&Ty::fun(vec![callback.clone()], Ty::int()), &reg),
            MirType::Closure(vec![closure.clone()], Box::new(MirType::Int))
        );
        assert_eq!(
            resolve_type(&Ty::Tuple(vec![callback.clone(), Ty::int()]), &reg),
            MirType::Tuple(vec![closure, MirType::Int])
        );
        assert_eq!(
            resolve_type(&Ty::option(callback), &reg),
            MirType::SumType("Option_Closure_Int_to_String".to_string())
        );
    }

    #[test]
    fn resolve_never() {
        let reg = empty_registry();
        assert_eq!(resolve_type(&Ty::Never, &reg), MirType::Never);
    }

    #[test]
    fn resolve_option_sum_type() {
        use mesh_typeck::{SumTypeDefInfo, VariantInfo};

        let mut reg = empty_registry();
        reg.sum_type_defs.insert(
            "Option".to_string(),
            SumTypeDefInfo {
                name: "Option".to_string(),
                generic_params: vec!["T".to_string()],
                indexed: None,
                variants: vec![
                    VariantInfo {
                        name: "Some".to_string(),
                        fields: vec![],
                        indexed: None,
                    },
                    VariantInfo {
                        name: "None".to_string(),
                        fields: vec![],
                        indexed: None,
                    },
                ],
            },
        );
        let ty = Ty::option(Ty::int());
        assert_eq!(
            resolve_type(&ty, &reg),
            MirType::SumType("Option_Int".to_string())
        );
    }

    #[test]
    fn resolve_struct_no_args() {
        use mesh_typeck::StructDefInfo;

        let mut reg = empty_registry();
        reg.struct_defs.insert(
            "Point".to_string(),
            StructDefInfo {
                name: "Point".to_string(),
                generic_params: vec![],
                fields: vec![],
                schema: None,
            },
        );

        // Ty::App(Con("Point"), []) resolves to Struct("Point")
        let ty = Ty::struct_ty("Point", vec![]);
        assert_eq!(
            resolve_type(&ty, &reg),
            MirType::Struct("Point".to_string())
        );
    }

    #[test]
    fn resolve_opaque_nominal_resource_to_ptr() {
        use mesh_typeck::StructDefInfo;

        let mut reg = empty_registry();
        reg.register_resource_type("StorageKey");
        reg.struct_defs.insert(
            "StorageKey".to_string(),
            StructDefInfo {
                name: "StorageKey".to_string(),
                generic_params: vec![],
                fields: vec![],
                schema: None,
            },
        );

        assert_eq!(
            resolve_type(&Ty::Con(TyCon::new("StorageKey")), &reg),
            MirType::Ptr
        );
    }

    #[test]
    fn resolve_registered_crypto_error_as_sum_type() {
        use mesh_typeck::SumTypeDefInfo;

        let mut reg = empty_registry();
        reg.sum_type_defs.insert(
            "CryptoError".to_string(),
            SumTypeDefInfo {
                name: "CryptoError".to_string(),
                generic_params: vec![],
                indexed: None,
                variants: vec![],
            },
        );

        assert_eq!(
            resolve_type(&Ty::crypto_error(), &reg),
            MirType::SumType("CryptoError".to_string())
        );
    }

    #[test]
    fn resolve_resource_sum_as_sum_type() {
        use mesh_typeck::SumTypeDefInfo;

        let mut reg = empty_registry();
        reg.register_resource_type("DecryptOutcome");
        reg.sum_type_defs.insert(
            "DecryptOutcome".to_string(),
            SumTypeDefInfo {
                name: "DecryptOutcome".to_string(),
                generic_params: vec![],
                indexed: None,
                variants: vec![],
            },
        );

        assert_eq!(
            resolve_type(&Ty::Con(TyCon::new("DecryptOutcome")), &reg),
            MirType::SumType("DecryptOutcome".to_string())
        );
    }

    #[test]
    fn generic_resource_result_keeps_nominal_payload_identity() {
        use mesh_typeck::SumTypeDefInfo;

        let mut reg = empty_registry();
        reg.sum_type_defs.insert(
            "Result".to_string(),
            SumTypeDefInfo {
                name: "Result".to_string(),
                generic_params: vec!["T".to_string(), "E".to_string()],
                indexed: None,
                variants: vec![],
            },
        );
        reg.sum_type_defs.insert(
            "CryptoError".to_string(),
            SumTypeDefInfo {
                name: "CryptoError".to_string(),
                generic_params: vec![],
                indexed: None,
                variants: vec![],
            },
        );

        assert_eq!(
            resolve_type(&Ty::result(Ty::secret_bytes(), Ty::crypto_error()), &reg,),
            MirType::SumType("Result_SecretBytes_CryptoError".to_string())
        );
    }

    #[test]
    fn mangle_generic_type() {
        let reg = empty_registry();
        let name = mangle_type_name("Result", &[Ty::int(), Ty::string()], &reg);
        assert_eq!(name, "Result_Int_String");
        // A function argument is named as the closure it resolves to.
        let function = Ty::Fun(vec![Ty::int()], Box::new(Ty::string()));
        let name = mangle_type_name("Box", &[function], &reg);
        assert_eq!(name, "Box_Closure_Int_to_String");
        // A value that never comes into being, and a pid of no known
        // message type.
        let name = mangle_type_name("Pair", &[Ty::Never, Ty::untyped_pid()], &reg);
        assert_eq!(name, "Pair_Never_Pid");
    }

    #[test]
    fn resolve_untyped_pid() {
        let reg = empty_registry();
        // Ty::Con("Pid") -> MirType::Pid(None)
        assert_eq!(resolve_type(&Ty::untyped_pid(), &reg), MirType::Pid(None));
    }

    #[test]
    fn resolve_typed_pid() {
        let reg = empty_registry();
        // Ty::App(Con("Pid"), [Int]) -> MirType::Pid(Some(Int))
        assert_eq!(
            resolve_type(&Ty::pid(Ty::int()), &reg),
            MirType::Pid(Some(Box::new(MirType::Int)))
        );
    }

    #[test]
    fn resolve_sqlite_conn_to_int() {
        let reg = empty_registry();
        // SqliteConn is an opaque u64 handle, lowered to MirType::Int.
        assert_eq!(
            resolve_type(&Ty::Con(TyCon::new("SqliteConn")), &reg),
            MirType::Int,
        );
    }

    #[test]
    fn resolve_registered_pg_conn_resource_to_int() {
        let mut reg = empty_registry();
        reg.register_resource_type("PgConn");

        assert_eq!(
            resolve_type(&Ty::Con(TyCon::new("PgConn")), &reg),
            MirType::Int,
            "PgConn is an affine resource at type-check time but remains a u64 ABI handle",
        );
    }

    #[test]
    fn resolve_var_falls_back_to_unit() {
        use mesh_typeck::ty::TyVar;
        let reg = empty_registry();
        // Unresolved type variables fall back to Unit for graceful degradation.
        assert_eq!(resolve_type(&Ty::Var(TyVar(0)), &reg), MirType::Unit);
    }

    // ── mir_type_to_ty tests ─────────────────────────────────────────

    #[test]
    fn mir_type_to_ty_int() {
        assert_eq!(mir_type_to_ty(&MirType::Int), Ty::int());
    }

    #[test]
    fn mir_type_to_ty_float() {
        assert_eq!(mir_type_to_ty(&MirType::Float), Ty::float());
    }

    #[test]
    fn mir_type_to_ty_string() {
        assert_eq!(mir_type_to_ty(&MirType::String), Ty::string());
    }

    #[test]
    fn mir_type_to_ty_bool() {
        assert_eq!(mir_type_to_ty(&MirType::Bool), Ty::bool());
    }

    #[test]
    fn mir_type_to_ty_struct() {
        assert_eq!(
            mir_type_to_ty(&MirType::Struct("Point".to_string())),
            Ty::Con(TyCon::new("Point"))
        );
    }

    #[test]
    fn mir_type_to_ty_sum_type() {
        assert_eq!(
            mir_type_to_ty(&MirType::SumType("Shape".to_string())),
            Ty::Con(TyCon::new("Shape"))
        );
    }

    #[test]
    fn mir_type_to_ty_unknown_fallback() {
        // Complex types fall back to Unknown.
        assert_eq!(
            mir_type_to_ty(&MirType::Unit),
            Ty::Con(TyCon::new("Unknown"))
        );
        assert_eq!(
            mir_type_to_ty(&MirType::Ptr),
            Ty::Con(TyCon::new("Unknown"))
        );
    }

    // ── mir_type_to_impl_name tests ──────────────────────────────────

    #[test]
    fn mir_type_to_impl_name_primitives() {
        assert_eq!(mir_type_to_impl_name(&MirType::Int), "Int");
        assert_eq!(mir_type_to_impl_name(&MirType::Float), "Float");
        assert_eq!(mir_type_to_impl_name(&MirType::String), "String");
        assert_eq!(mir_type_to_impl_name(&MirType::Bool), "Bool");
    }

    #[test]
    fn mir_type_to_impl_name_struct() {
        assert_eq!(
            mir_type_to_impl_name(&MirType::Struct("Point".to_string())),
            "Point"
        );
    }

    #[test]
    fn mir_type_to_impl_name_sum_type() {
        assert_eq!(
            mir_type_to_impl_name(&MirType::SumType("Shape".to_string())),
            "Shape"
        );
    }

    #[test]
    fn mir_type_to_impl_name_unknown_fallback() {
        assert_eq!(mir_type_to_impl_name(&MirType::Unit), "Unknown");
        assert_eq!(mir_type_to_impl_name(&MirType::Ptr), "Unknown");
    }
}
