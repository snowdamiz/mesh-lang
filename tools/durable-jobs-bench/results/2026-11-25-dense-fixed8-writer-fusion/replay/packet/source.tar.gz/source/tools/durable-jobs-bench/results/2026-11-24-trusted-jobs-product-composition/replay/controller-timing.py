#!/usr/bin/env python3
"""Controller entry point for granted Linode timing only."""

import argparse
from datetime import datetime, timezone
from importlib import import_module
from pathlib import Path
import re
import sys

from intake import RESULTS, compare, read, sha

ID = "2026-11-24-trusted-jobs-product-composition"
R2 = "2026-11-24-exit-confirmed-bulk-d2"
sys.path.insert(0, str(RESULTS / "2026-11-23-bulk-enqueue-v2-short/replay"))
matrix = import_module("interleave-v2")
matrix.ATTEMPT_ERRORS += (AssertionError,)


def assignment(requests, plan):
    entries = re.findall(r"^(SETUP|TIMING|RELEASED|HOLD) (\S+) (\S+)(?: (\S+))?",
                         (requests / "STATUS.md").read_text(), re.MULTILINE)
    kind, key, start, end = entries[-1]
    expected = f"{ID}-{plan}"
    assert (kind, key) == ("TIMING", expected), f"missing controller TIMING grant for {expected}"
    assert datetime.fromisoformat(start) <= datetime.now(timezone.utc) < datetime.fromisoformat(end)
    setup = read(requests / f"{ID}.released.json")
    assert setup["id"] == ID and setup["exit_status"] == 0
    decision = read(requests / f"{ID}.r2-decision.json")
    assert decision["dependency"] == R2 and decision["decision"] in ("full", "smaller")
    for path, digest in decision["receipts"].items():
        assert sha(Path(path)) == digest
    assert decision["receipts"], "the r2 decision needs independent controller evidence"
    if plan.startswith("short"):
        assert (plan == "short-smaller") == (decision["decision"] == "smaller")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("requests", type=Path)
    parser.add_argument("plan")
    parser.add_argument("qualified", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("groups", type=int, nargs="+", choices=range(1, 6))
    args = parser.parse_args()
    assignment(args.requests, args.plan)
    qualification = read(args.qualified)
    config = qualification["configuration"]
    recipe = qualification["recipe"]
    assert qualification["artifact"]["source_sha256"] == read(args.requests / f"{ID}.json")["source_archive_sha256"]
    assert config["description"].startswith(f"Trusted Jobs product {args.plan.removesuffix('-smaller')}.")
    decision = read(args.requests / f"{ID}.r2-decision.json")
    if decision["decision"] == "smaller":
        assert all(lane.get("product_mode") != "product-d2" for lane in config["lanes"].values())
    if not args.plan.startswith("short"):
        selection = read(args.requests / f"{ID}.short-selection.json")
        assert selection["manifest_sha256"] == qualification["manifest_sha256"]
        assert selection["mode"] == config["lanes"]["product"]["product_mode"]
        assert selection["short_receipts"] and all(
            sha(Path(path)) == digest for path, digest in selection["short_receipts"].items())
    def replay(path, _, block):
        return dict(scores=compare(qualification, path, block["group"]))

    matrix.replay = replay
    matrix.plan = lambda *_: iter(recipe["blocks"])
    if any(group > 2 for group in args.groups):
        for block in recipe["blocks"][:2]:
            assert matrix.select_attempt(args.output, config, block, {}), "reconcile groups 1 and 2 first"

    original = matrix.dispatch_block

    def dispatch_block(*params):
        assignment(args.requests, args.plan)
        return original(*params)

    matrix.dispatch_block = dispatch_block
    return matrix.dispatch(args.output, config, args.groups)


if __name__ == "__main__":
    sys.exit(main())
