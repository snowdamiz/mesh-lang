//! Type checking tests for actor constructs: Pid<M>, spawn, send, receive, self(), link.
//!
//! These tests verify that:
//! - Pid<M> is a valid type with correct message type tracking
//! - spawn() returns Pid<M> where M is inferred from the actor
//! - send() validates message types at compile time for typed Pid<M>
//! - send() accepts any message for untyped Pid (escape hatch)
//! - receive infers message type from arm patterns
//! - self() returns Pid<M> inside actor, errors outside
//! - Typed Pid is assignable to untyped Pid

use mesh_typeck::error::TypeError;
use mesh_typeck::ty::Ty;
use mesh_typeck::TypeckResult;

// ── Helpers ────────────────────────────────────────────────────────────

fn check_source(src: &str) -> TypeckResult {
    let parse = mesh_parser::parse(src);
    mesh_typeck::check(&parse)
}

fn assert_no_errors(result: &TypeckResult) {
    assert!(
        result.errors.is_empty(),
        "expected no errors, got: {:?}",
        result.errors
    );
}

fn assert_has_error<F: Fn(&TypeError) -> bool>(result: &TypeckResult, pred: F, desc: &str) {
    assert!(
        result.errors.iter().any(pred),
        "expected error matching `{}`, got errors: {:?}",
        desc,
        result.errors
    );
}

// ── Pid Type Representation ────────────────────────────────────────────

#[test]
fn test_pid_type_constructors() {
    // Typed Pid<Int>
    let typed = Ty::pid(Ty::int());
    assert_eq!(format!("{}", typed), "Pid<Int>");

    // Untyped Pid
    let untyped = Ty::untyped_pid();
    assert_eq!(format!("{}", untyped), "Pid");
}

// ── Actor Definition ───────────────────────────────────────────────────

#[test]
fn test_actor_def_basic() {
    // Simple actor that receives messages and recurses with updated state.
    // The message type is inferred from the pattern usage (n used in + with Int state).
    let result = check_source(
        "actor counter(state :: Int) do\nreceive do\nn -> counter(state + n)\nend\nend",
    );
    assert_no_errors(&result);
}

#[test]
fn test_actor_def_registers_in_env() {
    // After defining an actor, we should be able to reference it as a function.
    let result = check_source(
        "actor counter(state :: Int) do\nreceive do\nn -> counter(state + n)\nend\nend\nlet f = counter",
    );
    assert_no_errors(&result);
}

// ── Spawn Returns Pid<M> ──────────────────────────────────────────────

#[test]
fn test_spawn_returns_pid() {
    let result = check_source(
        "actor counter(state :: Int) do\nreceive do\nn -> counter(state + n)\nend\nend\nlet p = spawn(counter, 0)\np",
    );
    assert_no_errors(&result);
    // The result type should be Pid<...>.
    let result_ty = result.result_type.as_ref().expect("expected result type");
    let ty_str = format!("{}", result_ty);
    assert!(
        ty_str.starts_with("Pid<"),
        "expected Pid<...>, got: {}",
        ty_str
    );
}

// ── Send Type Validation ──────────────────────────────────────────────

#[test]
fn test_send_typed_pid_correct_type() {
    // Send an Int to a Pid<Int> -- should succeed.
    let result = check_source(
        "actor counter(state :: Int) do\nreceive do\nn -> counter(state + n)\nend\nend\nlet pid = spawn(counter, 0)\nsend(pid, 42)",
    );
    assert_no_errors(&result);
}

#[test]
fn test_send_returns_observable_status() {
    let result = check_source(
        "actor sink() do\nreceive do\n_ -> nil\nend\nend\nlet pid = spawn(sink)\nlet status :: Int = send(pid, 42)\nstatus",
    );
    assert_no_errors(&result);
}

#[test]
fn test_send_typed_pid_wrong_type() {
    // Send a String to a Pid<Int> -- should produce type error.
    let result = check_source(
        "actor counter(state :: Int) do\nreceive do\nn -> counter(state + n)\nend\nend\nlet pid = spawn(counter, 0)\nsend(pid, \"hello\")",
    );
    // Should produce a type error -- sending String to Pid<Int>.
    assert!(
        !result.errors.is_empty(),
        "expected type error for sending wrong type, got no errors"
    );
}

#[test]
fn test_send_untyped_pid_any_type() {
    // Untyped Pid should accept any message type (escape hatch).
    let result = check_source(
        "actor counter(state :: Int) do\nreceive do\nn -> counter(state + n)\nend\nend\nlet pid :: Pid = spawn(counter, 0)\nsend(pid, \"hello\")",
    );
    assert_no_errors(&result);
}

// ── Self Expression ───────────────────────────────────────────────────

#[test]
fn test_self_inside_actor() {
    let result = check_source(
        "actor pinger(state :: Int) do\nlet me = self()\nreceive do\nn -> pinger(state + n)\nend\nend",
    );
    assert_no_errors(&result);
}

#[test]
fn test_self_outside_actor_error() {
    let result = check_source("let me = self()");
    assert_has_error(
        &result,
        |e| matches!(e, TypeError::SelfOutsideActor { .. }),
        "SelfOutsideActor",
    );
}

// ── Receive Expression ────────────────────────────────────────────────

#[test]
fn test_receive_outside_actor_error() {
    let result = check_source("receive do\nn -> n\nend");
    assert_has_error(
        &result,
        |e| matches!(e, TypeError::ReceiveOutsideActor { .. }),
        "ReceiveOutsideActor",
    );
}

#[test]
fn test_receive_infers_message_type() {
    // The receive patterns should constrain the actor's message type.
    let result = check_source(
        "actor echo(state :: Int) do\nreceive do\nn -> echo(n)\nend\nend\nlet pid = spawn(echo, 0)\nsend(pid, 42)",
    );
    assert_no_errors(&result);
}

// ── Typed Pid Assignable to Untyped Pid ───────────────────────────────

#[test]
fn test_typed_pid_to_untyped_pid() {
    // Assigning a Pid<Int> to a variable annotated as Pid should work.
    let result = check_source(
        "actor counter(state :: Int) do\nreceive do\nn -> counter(state + n)\nend\nend\nlet typed_pid = spawn(counter, 0)\nlet untyped :: Pid = typed_pid",
    );
    assert_no_errors(&result);
}

// ── Link Expression ──────────────────────────────────────────────────

#[test]
fn test_link_returns_unit() {
    let result = check_source(
        "actor worker(state :: Int) do\nreceive do\nn -> worker(n)\nend\nend\nactor supervisor(state :: Int) do\nlet pid = spawn(worker, 0)\nlink(pid)\nreceive do\nn -> supervisor(n)\nend\nend",
    );
    assert_no_errors(&result);
}

// ── Unification: Pid Escape Hatch ────────────────────────────────────

#[test]
fn test_unify_pid_typed_with_untyped() {
    use mesh_typeck::error::ConstraintOrigin;
    use mesh_typeck::unify::InferCtx;

    let mut ctx = InferCtx::new();

    // Unifying Pid (untyped) with Pid<Int> (typed) should succeed.
    let untyped = Ty::untyped_pid();
    let typed = Ty::pid(Ty::int());
    assert!(
        ctx.unify(untyped, typed, ConstraintOrigin::Builtin).is_ok(),
        "untyped Pid should unify with Pid<Int>"
    );
}

#[test]
fn test_unify_pid_typed_with_untyped_reverse() {
    use mesh_typeck::error::ConstraintOrigin;
    use mesh_typeck::unify::InferCtx;

    let mut ctx = InferCtx::new();

    // Reverse direction: Pid<Int> with Pid should also succeed.
    let typed = Ty::pid(Ty::int());
    let untyped = Ty::untyped_pid();
    assert!(
        ctx.unify(typed, untyped, ConstraintOrigin::Builtin).is_ok(),
        "Pid<Int> should unify with untyped Pid"
    );
}

#[test]
fn test_unify_pid_typed_same_msg() {
    use mesh_typeck::error::ConstraintOrigin;
    use mesh_typeck::unify::InferCtx;

    let mut ctx = InferCtx::new();

    // Pid<Int> with Pid<Int> should succeed.
    let a = Ty::pid(Ty::int());
    let b = Ty::pid(Ty::int());
    assert!(
        ctx.unify(a, b, ConstraintOrigin::Builtin).is_ok(),
        "Pid<Int> should unify with Pid<Int>"
    );
}

#[test]
fn test_unify_pid_typed_different_msg() {
    use mesh_typeck::error::ConstraintOrigin;
    use mesh_typeck::unify::InferCtx;

    let mut ctx = InferCtx::new();

    // Pid<Int> with Pid<String> should fail.
    let a = Ty::pid(Ty::int());
    let b = Ty::pid(Ty::string());
    assert!(
        ctx.unify(a, b, ConstraintOrigin::Builtin).is_err(),
        "Pid<Int> should not unify with Pid<String>"
    );
}

/// `Process.monitor` takes the actor's `Pid`; it was typed `(Int) -> Int`, so
/// the documented `Process.monitor(pid)` did not type-check.
#[test]
fn process_monitor_takes_a_pid() {
    let result = check_source(
        "actor worker() do\n  receive do\n    n -> n + 1\n  end\nend\n\nactor watcher() do\n  let pid :: Pid<Int> = spawn(worker)\n  let reference = Process.monitor(pid, 0)\n  Process.demonitor(reference)\n  receive do\n    n -> n + 1\n  end\nend\n",
    );
    assert_no_errors(&result);

    let result = check_source(
        "actor watcher() do\n  Process.monitor(\"worker\", 0)\n  receive do\n    n -> n + 1\n  end\nend\n",
    );
    assert!(!result.errors.is_empty());
}

// ── Monitors ───────────────────────────────────────────────────────────

/// A monitor's message goes to the actor that sets it up, so it is one of
/// that actor's messages.
#[test]
fn test_monitor_message_is_the_actor_message_type() {
    let ok = check_source(
        "actor worker() do\nreceive do\nn -> n\nend\nend\n\
         actor watcher() do\nlet w :: Pid<Int> = spawn(worker)\n\
         let r = Process.monitor(w, \"worker ended\")\n\
         let n = Node.monitor(\"other@127.0.0.1:1\", \"other gone\")\n\
         receive do\ntext -> println(text)\nend\nend",
    );
    assert_no_errors(&ok);

    let mismatched = check_source(
        "actor watcher() do\nlet r = Process.monitor(self(), 1)\n\
         receive do\ntext -> println(text)\nend\nend",
    );
    assert!(
        !mismatched.errors.is_empty(),
        "an Int message for an actor that receives Strings"
    );
}

#[test]
fn test_monitor_outside_actor_error() {
    for call in [
        "Process.monitor(Process.whereis(\"x\"), 1)",
        "Node.monitor(\"a@b:1\", 1)",
    ] {
        let result = check_source(&format!("fn main() do\nlet r = {call}\nend"));
        assert_has_error(
            &result,
            |e| matches!(e, TypeError::MonitorOutsideActor { .. }),
            "MonitorOutsideActor",
        );
    }
}

/// An actor is spawned by its name: a function worked out at run time (a
/// call's result, a local holding one) has no compiled entry for the new
/// actor, and code generation refused it without a location.
#[test]
fn test_an_actor_is_spawned_by_its_name() {
    let prelude = "actor worker() do\n  receive do\n    msg -> println(\"#{msg + 1}\")\n  end\nend\n\nfn pick() do\n  worker\nend\n\n";
    for body in ["spawn(pick())", "let w = pick()\n  spawn(w)"] {
        let result = check_source(&format!("{prelude}fn main() do\n  {body}\nend\n"));
        assert_has_error(
            &result,
            |e| matches!(e, TypeError::SpawnByName { .. }),
            body,
        );
    }
    let result = check_source(&format!("{prelude}fn main() do\n  spawn(worker)\nend\n"));
    assert_no_errors(&result);
}

/// Only an actor can be spawned: a function returns no pid, and the error
/// said "expected `()`, found `Pid<_>`" of the spawn.
#[test]
fn test_only_an_actor_can_be_spawned() {
    let result = check_source(
        "fn hello() do\n  println(\"hi\")\nend\n\nfn main() do\n  spawn(hello)\nend\n",
    );
    assert_has_error(
        &result,
        |e| matches!(e, TypeError::SpawnNotActor { .. }),
        "SpawnNotActor",
    );
}
