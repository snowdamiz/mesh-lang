//! Mesh runtime library.
//!
//! This crate provides the runtime support functions that compiled Mesh
//! programs call at runtime. It is compiled as both:
//!
//! - A platform-specific static library (`libmesh_rt.a` on Unix, `mesh_rt.lib` on Windows MSVC) for linking into Mesh binaries
//! - A Rust library (`lib`) for unit testing
//!
//! ## Modules
//!
//! - [`gc`]: Arena/bump allocator for GC-managed memory (Phase 5: no collection)
//! - [`string`]: GC-managed string operations (create, concat, format, print)
//! - [`panic`]: Runtime panic handler with source locations
//! - [`actor`]: Actor runtime -- PCB, M:N scheduler, corosensei coroutines
//!
//! ## ABI Contract
//!
//! All public `extern "C"` functions in this crate form the runtime ABI.
//! Compiled Mesh programs call these functions directly via LLVM IR. The
//! function signatures must remain stable across Mesh compiler versions
//! (or at least across a single phase).

// The `extern "C"` entry points take raw pointers from generated code, which
// guarantees them; declaring each `unsafe fn` would change nothing for that
// code and only wrap every Rust caller in `unsafe`.
#![allow(clippy::not_unsafe_ptr_arg_deref)]
// Runtime state is threaded through many parameters, and some shapes are
// spelled out where they are built; errors are rare and built once.
#![allow(
    clippy::too_many_arguments,
    clippy::type_complexity,
    clippy::result_large_err,
    clippy::large_enum_variant
)]

/// `eprintln!` for the runtime: a failed write to stderr is ignored. Stderr
/// may be a pipe whose reader has gone, and `std`'s `eprintln!` panics then,
/// which aborts inside a runtime function that cannot unwind. Defined before
/// the modules, it shadows `std`'s macro throughout the crate.
macro_rules! eprintln {
    ($($arg:tt)*) => {{
        use std::io::Write as _;
        let _ = writeln!(std::io::stderr(), $($arg)*);
    }};
}

/// `eprint!` that ignores a failed write, like the runtime's `eprintln!`.
#[allow(unused_macros)]
macro_rules! eprint {
    ($($arg:tt)*) => {{
        use std::io::Write as _;
        let _ = write!(std::io::stderr(), $($arg)*);
    }};
}

pub mod actor;
pub mod bytes;
mod callback;
pub mod channel;
pub mod collections;
pub mod crypto;
pub mod datetime; // Phase 136
pub mod db;
pub mod dist;
pub mod env;
pub mod file;
pub mod finance;
pub mod gc;
pub mod hash;
pub mod http;
pub mod io;
pub mod iter;
pub(crate) mod jobs;
#[doc(hidden)]
pub use jobs::testing as jobs_testing;
pub mod json;
pub mod library;
pub mod monotonic;
pub mod option;
pub mod panic;
pub mod process_signal;
pub mod random;
pub mod regex;
pub mod secret;
pub mod secret_memory;
pub mod stack_overflow;
pub mod storage_wrapping;
pub mod string;
pub mod test; // Phase 138
pub mod wide_num;
pub mod ws;

// Re-export key functions for convenient Rust-side access and testing.
pub use actor::service::{
    mesh_service_call, mesh_service_call_shaped, mesh_service_cast_shaped, mesh_service_reply,
    mesh_service_reply_shaped,
};
pub use actor::{
    mesh_actor_link, mesh_actor_receive, mesh_actor_receive_scalar, mesh_actor_self,
    mesh_actor_send, mesh_actor_send_shaped, mesh_actor_set_terminate, mesh_actor_spawn,
    mesh_actor_spawn_shaped, mesh_actor_stop, mesh_global_register, mesh_global_unregister,
    mesh_global_whereis, mesh_node_monitor, mesh_pid_to_string, mesh_process_demonitor,
    mesh_process_monitor, mesh_reduction_check, mesh_rt_init_actor, mesh_rt_run_scheduler,
    mesh_timer_apply_after, mesh_timer_send_after, mesh_timer_send_after_shaped, mesh_timer_sleep,
};
pub use channel::{
    mesh_channel_bounded, mesh_channel_bounded_bytes, mesh_channel_byte_depth, mesh_channel_depth,
    mesh_channel_dropped, mesh_channel_recv, mesh_channel_try_send,
};
pub use collections::list::{
    mesh_list_all, mesh_list_any, mesh_list_append, mesh_list_concat, mesh_list_contains,
    mesh_list_contains_str, mesh_list_drop, mesh_list_enumerate, mesh_list_filter, mesh_list_find,
    mesh_list_flat_map, mesh_list_flatten, mesh_list_from_array, mesh_list_get, mesh_list_head,
    mesh_list_last, mesh_list_length, mesh_list_map, mesh_list_new, mesh_list_nth,
    mesh_list_reduce, mesh_list_reverse, mesh_list_sort, mesh_list_tail, mesh_list_take,
    mesh_list_zip,
};
pub use collections::map::{
    mesh_map_delete, mesh_map_eq, mesh_map_from_list, mesh_map_get, mesh_map_has_key,
    mesh_map_keys, mesh_map_merge, mesh_map_new, mesh_map_put, mesh_map_size, mesh_map_to_list,
    mesh_map_values,
};
pub use collections::queue::{
    mesh_queue_is_empty, mesh_queue_new, mesh_queue_peek, mesh_queue_pop, mesh_queue_push,
    mesh_queue_size,
};
pub use collections::range::{
    mesh_range_filter, mesh_range_length, mesh_range_map, mesh_range_new, mesh_range_to_list,
};
pub use collections::set::{
    mesh_set_add, mesh_set_contains, mesh_set_difference, mesh_set_eq, mesh_set_from_list,
    mesh_set_intersection, mesh_set_new, mesh_set_remove, mesh_set_size, mesh_set_to_list,
    mesh_set_union,
};
pub use collections::tuple::{
    mesh_tuple_first, mesh_tuple_nth, mesh_tuple_second, mesh_tuple_size,
};
pub use db::changeset::{
    mesh_changeset_cast, mesh_changeset_cast_with_types, mesh_changeset_changes,
    mesh_changeset_errors, mesh_changeset_get_change, mesh_changeset_get_error,
    mesh_changeset_valid, mesh_changeset_validate_format, mesh_changeset_validate_inclusion,
    mesh_changeset_validate_length, mesh_changeset_validate_number,
    mesh_changeset_validate_required,
};
pub use db::expr::{
    mesh_expr_add, mesh_expr_alias, mesh_expr_call, mesh_expr_case, mesh_expr_coalesce,
    mesh_expr_column, mesh_expr_div, mesh_expr_eq, mesh_expr_excluded, mesh_expr_gt, mesh_expr_gte,
    mesh_expr_lt, mesh_expr_lte, mesh_expr_mul, mesh_expr_neq, mesh_expr_null, mesh_expr_sub,
    mesh_expr_value, mesh_pg_cast, mesh_pg_crypt, mesh_pg_gen_salt, mesh_pg_int, mesh_pg_jsonb,
    mesh_pg_jsonb_contains, mesh_pg_plainto_tsquery, mesh_pg_text, mesh_pg_timestamptz,
    mesh_pg_to_tsvector, mesh_pg_ts_rank, mesh_pg_tsvector_matches, mesh_pg_uuid,
};
pub use db::json::{mesh_json_get, mesh_json_get_nested, mesh_json_is_string};
pub use db::migration::{
    mesh_migration_add_column, mesh_migration_create_index, mesh_migration_create_table,
    mesh_migration_drop_column, mesh_migration_drop_index, mesh_migration_drop_table,
    mesh_migration_execute, mesh_migration_rename_column,
};
pub use db::orm::{
    mesh_orm_build_delete, mesh_orm_build_insert, mesh_orm_build_select, mesh_orm_build_update,
};
pub use db::pg::{
    mesh_pg_close, mesh_pg_connect, mesh_pg_execute, mesh_pg_execute_values, mesh_pg_query,
    mesh_pg_query_values,
};
pub use db::pg_schema::{
    mesh_pg_create_daily_partitions_ahead, mesh_pg_create_extension, mesh_pg_create_gin_index,
    mesh_pg_create_range_partitioned_table, mesh_pg_drop_partition,
    mesh_pg_list_daily_partitions_before,
};
pub use db::pool::{
    mesh_pool_close, mesh_pool_execute, mesh_pool_execute_values, mesh_pool_open, mesh_pool_query,
    mesh_pool_query_values,
};
pub use db::query::{
    mesh_query_fragment, mesh_query_from, mesh_query_group_by, mesh_query_group_by_raw,
    mesh_query_having, mesh_query_join, mesh_query_join_as, mesh_query_limit, mesh_query_offset,
    mesh_query_order_by, mesh_query_order_by_raw, mesh_query_select, mesh_query_select_avg,
    mesh_query_select_count, mesh_query_select_count_field, mesh_query_select_expr,
    mesh_query_select_exprs, mesh_query_select_max, mesh_query_select_min, mesh_query_select_raw,
    mesh_query_select_sum, mesh_query_where, mesh_query_where_between, mesh_query_where_expr,
    mesh_query_where_in, mesh_query_where_not_in, mesh_query_where_not_null, mesh_query_where_null,
    mesh_query_where_op, mesh_query_where_or, mesh_query_where_raw, mesh_query_where_sub,
};
pub use db::repo::{
    mesh_repo_all, mesh_repo_count, mesh_repo_delete, mesh_repo_delete_where,
    mesh_repo_delete_where_returning, mesh_repo_execute_raw, mesh_repo_exists, mesh_repo_get,
    mesh_repo_get_by, mesh_repo_insert, mesh_repo_insert_changeset, mesh_repo_insert_expr,
    mesh_repo_insert_or_update, mesh_repo_insert_or_update_expr, mesh_repo_one, mesh_repo_preload,
    mesh_repo_query_raw, mesh_repo_transaction, mesh_repo_update, mesh_repo_update_changeset,
    mesh_repo_update_where, mesh_repo_update_where_expr,
};
pub use db::sqlite::{
    mesh_sqlite_close, mesh_sqlite_execute, mesh_sqlite_execute_values, mesh_sqlite_open,
    mesh_sqlite_query, mesh_sqlite_query_values,
};
pub use dist::autonomous::{
    autonomous_controller_status, embedded_autonomous_config, mesh_register_autonomous_config_json,
    register_autonomous_config_json, AutonomousControllerStatus, RuntimeAutonomousConfig,
    RuntimeCapacityDriverConfig, RuntimeContinuityConfig, RuntimeFeatureGates,
    RuntimeRoutingConfig, RuntimeSchedulerConfig, AUTONOMOUS_CONFIG_SCHEMA_VERSION,
};
pub use dist::bootstrap::{BootstrapMode, BootstrapStatus};
pub use dist::cluster_api::{
    mesh_cluster_capacity, mesh_cluster_pressure, mesh_cluster_role, mesh_cluster_state,
    mesh_cluster_telemetry,
};
pub use dist::consensus::{
    commit_consensus_command, consensus_node_id_for_stable_id, consensus_runtime_snapshot,
    ConsensusCommand, ConsensusResponse, ConsensusRuntimeSnapshot,
};
pub use dist::continuity::{
    attempt_id_from_token, continuity_registry, mesh_continuity_acknowledge_replica,
    mesh_continuity_authority_status, mesh_continuity_mark_completed, mesh_continuity_status,
    mesh_continuity_submit, mesh_continuity_submit_declared_work,
    mesh_continuity_submit_with_durability, ContinuityAuthorityStatus, ContinuityPhase,
    ContinuityRecord, ContinuityRegistry, ContinuityResult, ContinuitySnapshot,
    MeshContinuityAuthorityStatus, MeshContinuityRecord, MeshContinuitySubmitDecision,
    ReplicaStatus, SubmitDecision, SubmitOutcome, SubmitRequest,
};
pub use dist::continuity_store::{
    configured_continuity_store, prove_interrupted_snapshot_resume, CompactionOutcome,
    ContinuityStore, ContinuityStoreLimits, ContinuityStoreStats, SnapshotChunk,
    SnapshotResumeProof, SqliteContinuityStore, StoredContinuityPhase, StoredContinuityRecord,
};
pub use dist::driver_service::{
    serve_docker_driver_from_env, RemoteDockerCapacityDriver, RemoteDockerTemplate,
};
pub use dist::identity::{
    request_id_generator, validate_idempotency_key, CanonicalHttpRequest, OperationKey, RequestId,
    RequestIdGenerator,
};
pub use dist::identity_claim::{
    generate_identity_signing_material, sign_identity_claim, NodeIdentityClaim,
    CAPACITY_IDENTITY_SIGNING_KEY_ENV, IDENTITY_ENVELOPE_ENV, IDENTITY_SCHEMA_VERSION,
    IDENTITY_VERIFY_KEYS_ENV,
};
pub use dist::node::{
    mesh_node_connect, mesh_node_list, mesh_node_self, mesh_node_spawn, mesh_node_start,
    mesh_node_start_from_env, mesh_register_declared_handler, mesh_register_function,
    mesh_register_startup_work, mesh_trigger_startup_work, start_from_env as node_start_from_env,
    MeshBootstrapStatus,
};
pub use dist::operator::{
    operator_runtime_snapshot, query_operator_continuity_list_remote,
    query_operator_continuity_status_remote, query_operator_control_remote,
    query_operator_diagnostics_remote, query_operator_runtime_remote, query_operator_status_remote,
    sign_operator_control_request, OperatorAuthoritySnapshot, OperatorContinuityList,
    OperatorControlAction, OperatorControlOutcome, OperatorControlRequest, OperatorDiagnosticEntry,
    OperatorDiagnosticRecord, OperatorDiagnosticsBuffer, OperatorDiagnosticsSnapshot,
    OperatorMembershipSnapshot, OperatorNodeRuntimeSnapshot, OperatorQueryError, OperatorQueryKind,
    OperatorRuntimeSnapshot, OperatorStatusSnapshot, DEFAULT_OPERATOR_QUERY_TIMEOUT,
};
pub use dist::protocol::{
    negotiate_protocol, Capabilities, CircuitBreaker, CircuitState, MessageClass,
    NegotiatedProtocol, ProtocolEnvelope, ProtocolHello, RetryBudget,
};
pub use dist::readiness::{local_readiness_status, NodeReadinessStatus, ReadinessGate};
pub use dist::routing::{
    load_report_registry, local_load_report, select_owner, select_record_replicas,
    IneligibilityReason, LoadReportRegistry, NodeLoadReport, RoutingDecision, RoutingPolicy,
};
pub use dist::scaling::{
    capacity_operation_id, reconcile_scale_up, select_drain_candidate, Autoscaler, CapacityDriver,
    CapacityNodeLifecycle, CapacityObservation, CapacityReconcileOutcome, CapacityReconciler,
    CommittedDesiredCapacity, ControlLogEntry, ControlMutation, ControlPlaneCommitter, ControlTerm,
    ControllerQuorum, DesiredCapacity, DesiredRevision, DockerCapacityDriver, DockerDriverConfig,
    DockerEnvironmentFileMount, DrainCandidate, DrainPhase, DrainProgress, DriverOperation,
    DriverOperationState, DurableControlLog, FakeCapacityDriver, LocalScalingDecision,
    LocalScalingPolicy, LocalSchedulerAutoscaler, ObservedCapacityNode, ProcessCapacityDriver,
    ProcessDriverConfig, ReconcileNodeSafety, ScalingAction, ScalingDecision, ScalingPolicy,
    ScalingSample,
};
pub use dist::telemetry::{
    global_admission_controller, runtime_telemetry, AdmissionController, AdmissionLimits,
    AdmissionPermit, AdmissionRejection, LocalTelemetrySnapshot, NodeLifecycleState, NodeRoles,
    PressureSnapshot, QueuePermit, RuntimeTelemetry,
};
pub use env::{
    mesh_env_args, mesh_env_get, mesh_env_get_int, mesh_env_get_secret_hex,
    mesh_env_get_with_default,
};
pub use file::{
    mesh_file_append, mesh_file_delete, mesh_file_exists, mesh_file_read, mesh_file_read_bytes,
    mesh_file_rename, mesh_file_size, mesh_file_sync, mesh_file_write, mesh_file_write_bytes,
};
pub use finance::{
    mesh_checked_abs, mesh_checked_add, mesh_checked_div, mesh_checked_mul, mesh_checked_mul_div,
    mesh_checked_rescale, mesh_checked_sub,
};
pub use gc::{mesh_gc_alloc, mesh_gc_alloc_actor, mesh_rt_init};
pub use hash::{
    mesh_hash_bool, mesh_hash_combine, mesh_hash_float, mesh_hash_int, mesh_hash_string,
};
pub use http::{
    mesh_http_idempotency_key, mesh_http_request_body, mesh_http_request_header,
    mesh_http_request_id, mesh_http_request_method, mesh_http_request_path,
    mesh_http_request_query, mesh_http_response_new, mesh_http_route, mesh_http_router,
    mesh_http_serve,
};
pub use io::{mesh_io_eprintln, mesh_io_read_line};
pub use iter::{
    mesh_iter_all, mesh_iter_any, mesh_iter_count, mesh_iter_enumerate, mesh_iter_enumerate_next,
    mesh_iter_filter, mesh_iter_filter_next, mesh_iter_find, mesh_iter_generic_next, mesh_iter_map,
    mesh_iter_map_next, mesh_iter_reduce, mesh_iter_skip, mesh_iter_skip_next, mesh_iter_sum,
    mesh_iter_take, mesh_iter_take_next, mesh_iter_zip, mesh_iter_zip_next, mesh_list_collect,
    mesh_map_collect, mesh_map_collect_string_keys, mesh_set_collect, mesh_string_collect,
};
pub use json::{
    mesh_json_array_length, mesh_json_encode, mesh_json_encode_bool, mesh_json_encode_int,
    mesh_json_encode_list, mesh_json_encode_map, mesh_json_encode_string, mesh_json_from_bool,
    mesh_json_from_float, mesh_json_from_int, mesh_json_from_string, mesh_json_is_null,
    mesh_json_parse, mesh_json_value_as_bool, mesh_json_value_as_float, mesh_json_value_as_int,
};
pub use library::{
    mesh_library_free_returned_bytes, mesh_library_host_call, mesh_library_init,
    mesh_library_invoke, mesh_library_register_host_callbacks, mesh_library_shutdown,
    MeshLibraryBytes, MeshLibraryCallResult, MeshLibraryHostCallbacksV1,
};
pub use monotonic::{
    mesh_duration_millis, mesh_duration_seconds, mesh_monotonic_elapsed, mesh_monotonic_now_nanos,
};
pub use option::{alloc_option, MeshOption};
pub use panic::mesh_panic;
pub use process_signal::{
    mesh_process_exit, mesh_process_install_shutdown_signals, mesh_process_request_shutdown,
    mesh_process_shutdown_requested,
};
pub use random::{mesh_random_next_int, mesh_random_next_unit_ppm, mesh_random_seed};
pub use regex::{
    mesh_regex_captures, mesh_regex_compile, mesh_regex_from_literal, mesh_regex_match,
    mesh_regex_replace, mesh_regex_split,
};
pub use secret::{
    mesh_resource_destroy, mesh_secret_concat, mesh_secret_destroy, mesh_secret_from_bytes,
    mesh_secret_map_contains, mesh_secret_map_copy, mesh_secret_map_delete, mesh_secret_map_fork,
    mesh_secret_map_insert, mesh_secret_map_merge, mesh_secret_map_new, mesh_secret_random,
    MeshSecretHandle,
};
pub use storage_wrapping::{
    mesh_blind_rsa_secret_key_seal_for_storage, mesh_blind_rsa_secret_key_unseal_from_storage,
    mesh_mlkem_private_key_seal_for_storage, mesh_mlkem_private_key_unseal_from_storage,
    mesh_secret_map_seal_for_storage, mesh_secret_map_unseal_from_storage,
    mesh_secret_seal_for_storage, mesh_secret_unseal_from_storage,
    mesh_signing_private_key_seal_for_storage, mesh_signing_private_key_unseal_from_storage,
    mesh_storage_key_ephemeral, mesh_storage_key_from_secret, mesh_storage_key_platform,
    mesh_storage_key_provision, mesh_storage_key_seal_bytes, mesh_storage_key_unseal_bytes,
    mesh_x25519_private_key_seal_for_storage, mesh_x25519_private_key_unseal_from_storage,
};
pub use string::{
    mesh_bool_to_string, mesh_float_to_string, mesh_int_to_string, mesh_print, mesh_println,
    mesh_string_compare, mesh_string_concat, mesh_string_contains, mesh_string_ends_with,
    mesh_string_eq, mesh_string_join, mesh_string_length, mesh_string_new, mesh_string_repeat,
    mesh_string_replace, mesh_string_slice, mesh_string_split, mesh_string_starts_with,
    mesh_string_to_float, mesh_string_to_int, mesh_string_to_lower, mesh_string_to_upper,
    mesh_string_trim, mesh_string_trim_end, mesh_string_trim_start, MeshString,
};
pub use test::{
    mesh_test_assert, mesh_test_assert_eq, mesh_test_assert_ne, mesh_test_assert_raises,
    mesh_test_begin, mesh_test_cleanup_actors, mesh_test_end, mesh_test_fail_count,
    mesh_test_fail_msg, mesh_test_fail_msg_at, mesh_test_mock_actor, mesh_test_pass,
    mesh_test_pass_count, mesh_test_run_body, mesh_test_summary,
};
