//! GC allocation entry points for Mesh runtime.
//!
//! Two allocation paths exist:
//!
//! - **Global arena** (`mesh_gc_alloc`): Simple bump allocator for non-actor
//!   contexts (main thread, startup). No object headers, no collection.
//!
//! - **Per-actor heap** (`mesh_gc_alloc_actor`): GcHeader-aware allocator that
//!   prepends a 16-byte header to every allocation. Supports mark-sweep GC
//!   with free-list reuse. Falls back to the global arena when no actor
//!   context is available.
//!
//! All GC-managed values (strings, closure environments, ADT payloads) are
//! allocated via these entry points. The returned pointer is always the
//! user-visible data pointer (past any header), keeping the ABI stable.

use std::sync::Mutex;

/// Default page size: 64 KiB.
const PAGE_SIZE: usize = 64 * 1024;

/// Global arena state protected by a mutex.
///
/// Single-threaded for Phase 5, but the mutex makes the API safe to call
/// from any context without UB concerns.
struct Arena {
    /// Allocated pages. Each page is a heap-allocated byte buffer.
    pages: Vec<Vec<u8>>,
    /// Offset into the current (last) page.
    offset: usize,
}

impl Arena {
    fn new() -> Self {
        Arena {
            pages: Vec::new(),
            offset: 0,
        }
    }

    fn init(&mut self) {
        if self.pages.is_empty() {
            self.pages.push(vec![0u8; PAGE_SIZE]);
            self.offset = 0;
        }
    }

    /// Bump-allocate `size` bytes with the given alignment.
    ///
    /// Returns a pointer to the allocated region. The pointer is valid for the
    /// lifetime of the arena (i.e., until the process exits in Phase 5).
    fn alloc(&mut self, size: usize, align: usize) -> *mut u8 {
        let align = if align == 0 { 1 } else { align };

        // Ensure the arena has been initialized.
        if self.pages.is_empty() {
            self.init();
        }

        // Align the current offset within the current page.
        let current_page_len = self.pages.last().map_or(0, |p| p.len());
        let aligned_offset = (self.offset + align - 1) & !(align - 1);

        if aligned_offset + size <= current_page_len {
            // Fits in the current page.
            let page = self.pages.last_mut().unwrap();
            let ptr = page[aligned_offset..].as_mut_ptr();
            self.offset = aligned_offset + size;
            ptr
        } else {
            // Allocate a new page. If the requested size exceeds the default
            // page size, allocate a page large enough to hold it.
            let new_page_size = if size > PAGE_SIZE {
                size + align
            } else {
                PAGE_SIZE
            };
            let mut page = vec![0u8; new_page_size];
            let aligned_start = {
                let base = page.as_ptr() as usize;
                let aligned = (base + align - 1) & !(align - 1);
                aligned - base
            };
            let ptr = page[aligned_start..].as_mut_ptr();
            self.offset = aligned_start + size;
            self.pages.push(page);
            ptr
        }
    }
}

static ARENA: Mutex<Option<Arena>> = Mutex::new(None);

/// Initialize the runtime arena. Called once at program start from `main`.
///
/// # Safety
///
/// This function is safe to call multiple times; subsequent calls are no-ops.
#[no_mangle]
pub extern "C" fn mesh_rt_init() {
    #[cfg(target_os = "linux")]
    crate::jobs::apply_worker_startup_policy();
    crate::stack_overflow::install_for_current_thread();
    crate::panic::install_hook();
    #[cfg(all(mesh_coverage, unix))]
    crate::process_signal::install_coverage_flush();
    let mut guard = ARENA.lock().unwrap();
    if guard.is_none() {
        let mut arena = Arena::new();
        arena.init();
        *guard = Some(arena);
    }

    // Install ring crypto provider for TLS (PostgreSQL + ureq HTTP client).
    // Idempotent: ignore Err if already installed by another path.
    let _ = rustls::crypto::ring::default_provider().install_default();
}

/// Drop process-lifetime allocations between single-threaded fuzz iterations.
///
/// This is deliberately unavailable in production builds because every
/// pointer returned by the global arena becomes invalid immediately.
#[cfg(feature = "fuzzing")]
pub fn mesh_rt_reset_for_fuzzing() {
    *ARENA.lock().unwrap() = None;
}

/// Allocate `size` bytes with the given `align`ment from the GC arena.
///
/// Returns a pointer to zeroed memory. The pointer is valid for the lifetime
/// of the program (Phase 5 -- no collection).
///
/// # Safety
///
/// The returned pointer must not be freed by the caller. The arena owns
/// the memory.
#[no_mangle]
pub extern "C" fn mesh_gc_alloc(size: u64, align: u64) -> *mut u8 {
    let mut guard = ARENA.lock().unwrap();
    let arena = guard.get_or_insert_with(|| {
        let mut a = Arena::new();
        a.init();
        a
    });
    arena.alloc(size as usize, align as usize)
}

/// Allocate `size` bytes with the given `align`ment from the current actor's
/// per-actor heap.
///
/// If called from within an actor context (i.e., a thread running an actor
/// coroutine), allocates from that actor's heap via `ActorHeap::alloc()`,
/// which prepends a 16-byte `GcHeader`. The returned pointer is past the
/// header -- callers see only user data.
///
/// Falls back to the global arena (no header) if no actor context is available.
///
/// # Safety
///
/// The returned pointer must not be freed by the caller. The actor's heap
/// owns the memory.
#[no_mangle]
pub extern "C" fn mesh_gc_alloc_actor(size: u64, align: u64) -> *mut u8 {
    // Try to allocate from the current actor's heap.
    if let Some(ptr) = try_alloc_from_actor_heap(size as usize, align as usize, false) {
        return ptr;
    }
    // Fallback to global arena.
    mesh_gc_alloc(size, align)
}

/// Allocate a body that contains no managed references.
pub(crate) fn alloc_actor_leaf(size: u64, align: u64) -> *mut u8 {
    try_alloc_from_actor_heap(size as usize, align as usize, true)
        .unwrap_or_else(|| mesh_gc_alloc(size, align))
}

/// Attempt to allocate from the current actor's per-actor heap.
///
/// Returns `Some(ptr)` if running in an actor context and the allocation
/// succeeded. Returns `None` if no actor context is available.
fn try_alloc_from_actor_heap(size: usize, align: usize, leaf: bool) -> Option<*mut u8> {
    crate::actor::stack::with_allocation_process(|process| {
        let mut process = process.lock();
        let ptr = if leaf {
            process.heap.alloc_leaf(size, align)
        } else {
            process.heap.alloc(size, align)
        };
        // Not here: runtime functions keep fresh objects in Rust-side
        // temporaries no scan can see. Compiled code's next reduction check is
        // a point where every live value is on the stack or in a register.
        if process.collects_at_safepoints && process.heap.should_collect() {
            crate::actor::stack::request_safepoint_gc();
        }
        ptr
    })
}

/// Whether a runtime function may change the object at `ptr` in place (a
/// collection growing into its spare room): the object is in the running
/// actor's own heap, which no other thread writes and whose collector sees
/// what is stored in it, and nothing of that heap is lent out, so no other
/// thread is reading it either. An object of another heap (lent) or of the
/// global arena is not. Off an actor (a runtime thread running a callback,
/// such as an HTTP stream's) nothing is: the object may be another actor's.
pub(crate) fn may_update_in_place(ptr: *const u8) -> bool {
    use crate::actor::stack::get_current_pid;

    if get_current_pid().is_none() {
        // Unit tests run off an actor and exercise the in-place paths.
        return cfg!(test);
    }
    crate::actor::stack::with_allocation_process(|process| {
        let mut process = process.lock();
        process.heap.contains_address(ptr) && !process.heap.has_loans()
    })
    .unwrap_or(false)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_arena_basic_alloc() {
        let mut arena = Arena::new();
        arena.init();

        let ptr1 = arena.alloc(16, 8);
        assert!(!ptr1.is_null());

        let ptr2 = arena.alloc(32, 8);
        assert!(!ptr2.is_null());

        // Pointers should be different.
        assert_ne!(ptr1, ptr2);
    }

    #[test]
    fn test_arena_alignment() {
        let mut arena = Arena::new();
        arena.init();

        let ptr = arena.alloc(8, 16);
        assert!(!ptr.is_null());
        assert_eq!(ptr as usize % 16, 0, "pointer should be 16-byte aligned");
    }

    #[test]
    fn test_arena_large_alloc() {
        let mut arena = Arena::new();
        arena.init();

        // Allocate more than a page.
        let ptr = arena.alloc(128 * 1024, 8);
        assert!(!ptr.is_null());
    }

    #[test]
    fn test_gc_alloc_extern() {
        mesh_rt_init();
        let ptr = mesh_gc_alloc(64, 8);
        assert!(!ptr.is_null());
    }

    #[cfg(feature = "fuzzing")]
    #[test]
    fn fuzzing_reset_drops_the_global_arena() {
        mesh_rt_init();
        assert!(ARENA.lock().unwrap().is_some());

        mesh_rt_reset_for_fuzzing();

        assert!(ARENA.lock().unwrap().is_none());
    }

    #[test]
    fn an_arena_readies_itself_on_its_first_allocation() {
        let mut arena = Arena::new();
        assert!(!arena.alloc(8, 8).is_null());
        assert_eq!(arena.pages.len(), 1);
    }

    #[test]
    fn test_global_arena_no_headers() {
        // Global arena does NOT prepend GcHeaders -- it returns raw pointers.
        let mut arena = Arena::new();
        arena.init();

        // Write a known pattern to the arena allocation.
        let ptr = arena.alloc(8, 8);
        unsafe {
            std::ptr::write(ptr as *mut u64, 0xDEADBEEF_CAFEBABE);
        }

        // Read it back -- the pointer IS the data, no header to skip.
        let val = unsafe { *(ptr as *const u64) };
        assert_eq!(val, 0xDEADBEEF_CAFEBABE);
    }

    #[test]
    fn raw_native_string_and_bytes_constructors_remain_conservative() {
        use crate::actor::process::{Priority, Process, ProcessId};
        use crate::actor::stack;
        use std::sync::Arc;

        let pid = ProcessId(1);
        let process = Arc::new(parking_lot::Mutex::new(Process::new(pid, Priority::Normal)));
        stack::set_current_process(pid, &process);
        let string_child = mesh_gc_alloc_actor(8, 8);
        let bytes_child = mesh_gc_alloc_actor(8, 8);
        let words = [string_child as usize, bytes_child as usize];
        let raw_string = crate::string::mesh_string_new(words.as_ptr().cast(), 8);
        let raw_bytes = crate::bytes::mesh_bytes_copy_from(words[1..].as_ptr().cast(), 8);
        stack::clear_current_pid();

        let roots = [raw_string as usize, raw_bytes as usize];
        let top = roots.as_ptr().cast();
        let bottom = unsafe { roots.as_ptr().add(roots.len()) }.cast();
        let mut process = process.lock();
        process.heap.collect(bottom, top);
        assert_eq!(process.heap.live_allocation_size(string_child), Some(8));
        assert_eq!(process.heap.live_allocation_size(bytes_child), Some(8));
    }

    #[test]
    fn test_actor_heap_has_headers() {
        use crate::actor::heap::{ActorHeap, GcHeader, GC_HEADER_SIZE};

        // Actor heap DOES prepend GcHeaders to every allocation.
        let mut heap = ActorHeap::new();
        let data_ptr = heap.alloc(64, 8);

        // Back up 16 bytes to find the GcHeader.
        let header_ptr = unsafe { GcHeader::from_data_ptr(data_ptr) };
        let header = unsafe { &*header_ptr };

        // The header should have the correct size and be alive (not free).
        assert_eq!(header.size, 64);
        assert!(!header.is_free());
        assert!(!header.is_marked());

        // Verify the data pointer is exactly GC_HEADER_SIZE bytes past the header.
        assert_eq!(
            data_ptr as usize - header_ptr as usize,
            GC_HEADER_SIZE,
            "data pointer should be GC_HEADER_SIZE bytes past the header"
        );
    }
}
