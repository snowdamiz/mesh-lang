//! PostgreSQL-specific schema helpers for Mesh.
//!
//! These helpers intentionally own PostgreSQL-only DDL that should not be
//! represented by the neutral `Migration.*` surface.

use super::{execute_ddl, quote_ident};
use crate::collections::list::list_strings;
use crate::collections::list::string_list;
use crate::collections::list::{mesh_list_append, mesh_list_get, mesh_list_length, mesh_list_new};
use crate::collections::map::mesh_map_get;
use crate::db::pool::mesh_pool_query;
use crate::io::{alloc_result, err_result, MeshResult};
use crate::string::{mesh_str, text_of, MeshString};

fn quote_literal(value: &str) -> String {
    format!("'{}'", value.replace('\'', "''"))
}

fn quote_qualified_ident(value: &str, helper_name: &str) -> Result<String, String> {
    let mut parts = Vec::new();
    for part in value.split('.') {
        let trimmed = part.trim();
        if trimmed.is_empty() {
            return Err(format!(
                "{helper_name}: identifier `{value}` contains an empty segment"
            ));
        }
        parts.push(quote_ident(trimmed));
    }
    Ok(parts.join("."))
}

enum PartitionedTableEntry {
    Column { name: String, sql: String },
    Constraint(String),
}

fn render_partitioned_table_entry(
    column: &str,
    helper_name: &str,
) -> Result<PartitionedTableEntry, String> {
    let trimmed = column.trim();
    if trimmed.is_empty() {
        return Err(format!(
            "{helper_name}: invalid column definition `{column}`"
        ));
    }

    if !trimmed.contains(':') {
        return Ok(PartitionedTableEntry::Constraint(trimmed.to_string()));
    }

    let parts: Vec<&str> = trimmed.splitn(3, ':').collect();
    match parts.as_slice() {
        [name, sql_type, constraints] if !name.trim().is_empty() => {
            Ok(PartitionedTableEntry::Column {
                name: name.trim().to_string(),
                sql: format!(
                    "{} {} {}",
                    quote_ident(name.trim()),
                    sql_type.trim(),
                    constraints.trim()
                ),
            })
        }
        [name, sql_type] if !name.trim().is_empty() => Ok(PartitionedTableEntry::Column {
            name: name.trim().to_string(),
            sql: format!("{} {}", quote_ident(name.trim()), sql_type.trim()),
        }),
        _ => Err(format!(
            "{helper_name}: invalid column definition `{column}`"
        )),
    }
}

pub(crate) fn build_create_extension_sql(name: &str) -> Result<String, String> {
    let trimmed = name.trim();
    if trimmed.is_empty() {
        return Err("Pg.create_extension: extension name must not be empty".to_string());
    }
    Ok(format!(
        "CREATE EXTENSION IF NOT EXISTS {}",
        quote_ident(trimmed)
    ))
}

pub(crate) fn build_create_range_partitioned_table_sql(
    table: &str,
    columns: &[String],
    partition_column: &str,
) -> Result<String, String> {
    let table = table.trim();
    if table.is_empty() {
        return Err("Pg.create_range_partitioned_table: table name must not be empty".to_string());
    }
    let partition_column = partition_column.trim();
    if partition_column.is_empty() {
        return Err(
            "Pg.create_range_partitioned_table: partition column must not be empty".to_string(),
        );
    }

    let rendered_entries: Vec<PartitionedTableEntry> = columns
        .iter()
        .map(|column| render_partitioned_table_entry(column, "Pg.create_range_partitioned_table"))
        .collect::<Result<_, _>>()?;
    if !rendered_entries
        .iter()
        .any(|entry| matches!(entry, PartitionedTableEntry::Column { .. }))
    {
        return Err(
            "Pg.create_range_partitioned_table: at least one column is required".to_string(),
        );
    }
    if !rendered_entries.iter().any(|entry| {
        matches!(
            entry,
            PartitionedTableEntry::Column { name, .. } if name == partition_column
        )
    }) {
        return Err(format!(
            "Pg.create_range_partitioned_table: partition column `{partition_column}` is missing from `{table}`"
        ));
    }

    let column_sql = rendered_entries
        .iter()
        .map(|entry| match entry {
            PartitionedTableEntry::Column { sql, .. } => sql.as_str(),
            PartitionedTableEntry::Constraint(sql) => sql.as_str(),
        })
        .collect::<Vec<_>>()
        .join(", ");

    Ok(format!(
        "CREATE TABLE IF NOT EXISTS {} ({}) PARTITION BY RANGE ({})",
        quote_ident(table),
        column_sql,
        quote_ident(partition_column)
    ))
}

pub(crate) fn build_create_gin_index_sql(
    table: &str,
    index_name: &str,
    column: &str,
    opclass: &str,
) -> Result<String, String> {
    let table = table.trim();
    let index_name = index_name.trim();
    let column = column.trim();
    let opclass = opclass.trim();
    if table.is_empty() {
        return Err("Pg.create_gin_index: table name must not be empty".to_string());
    }
    if index_name.is_empty() {
        return Err("Pg.create_gin_index: index name must not be empty".to_string());
    }
    if column.is_empty() {
        return Err("Pg.create_gin_index: column name must not be empty".to_string());
    }
    if opclass.is_empty() {
        return Err("Pg.create_gin_index: opclass must not be empty".to_string());
    }

    Ok(format!(
        "CREATE INDEX IF NOT EXISTS {} ON {} USING GIN ({} {})",
        quote_ident(index_name),
        quote_ident(table),
        quote_ident(column),
        quote_qualified_ident(opclass, "Pg.create_gin_index")?
    ))
}

/// The partition of `parent_table` (checked non-empty) for the day
/// `offset_days` from today.
pub(crate) fn build_create_daily_partition_sql(parent_table: &str, offset_days: i64) -> String {
    format!(
        "DO $mesh$ DECLARE parent_name text := {parent}; part_date date := current_date + {offset}; part_name text := parent_name || '_' || to_char(part_date, 'YYYYMMDD'); BEGIN EXECUTE format('CREATE TABLE IF NOT EXISTS %I PARTITION OF %I FOR VALUES FROM (%L) TO (%L)', part_name, parent_name, part_date, part_date + 1); END $mesh$;",
        parent = quote_literal(parent_table),
        offset = offset_days,
    )
}

pub(crate) fn build_list_daily_partitions_before_sql() -> &'static str {
    "SELECT c.relname::text AS partition_name \
FROM pg_inherits i \
JOIN pg_class c ON c.oid = i.inhrelid \
JOIN pg_class p ON p.oid = i.inhparent \
WHERE p.relname = $1 \
  AND left(c.relname, char_length($1) + 1) = $1 || '_' \
  AND char_length(c.relname) = char_length($1) + 9 \
  AND substring(c.relname from char_length($1) + 2 for 8) ~ '^[0-9]{8}$' \
  AND to_date(substring(c.relname from char_length($1) + 2 for 8), 'YYYYMMDD') < (current_date - $2::int) \
ORDER BY c.relname"
}

pub(crate) fn build_drop_partition_sql(partition_name: &str) -> Result<String, String> {
    let trimmed = partition_name.trim();
    if trimmed.is_empty() {
        return Err("Pg.drop_partition: partition name must not be empty".to_string());
    }
    Ok(format!("DROP TABLE IF EXISTS {}", quote_ident(trimmed)))
}

#[no_mangle]
pub extern "C" fn mesh_pg_create_extension(pool: u64, name: *const MeshString) -> *mut u8 {
    unsafe { execute_ddl(pool, build_create_extension_sql(text_of(name))) }
}

#[no_mangle]
pub extern "C" fn mesh_pg_create_range_partitioned_table(
    pool: u64,
    table: *const MeshString,
    columns: *mut u8,
    partition_column: *const MeshString,
) -> *mut u8 {
    unsafe {
        let sql = build_create_range_partitioned_table_sql(
            text_of(table),
            &list_strings(columns),
            text_of(partition_column),
        );
        execute_ddl(pool, sql)
    }
}

#[no_mangle]
pub extern "C" fn mesh_pg_create_gin_index(
    pool: u64,
    table: *const MeshString,
    index_name: *const MeshString,
    column: *const MeshString,
    opclass: *const MeshString,
) -> *mut u8 {
    unsafe {
        let sql = build_create_gin_index_sql(
            text_of(table),
            text_of(index_name),
            text_of(column),
            text_of(opclass),
        );
        execute_ddl(pool, sql)
    }
}

#[no_mangle]
pub extern "C" fn mesh_pg_create_daily_partitions_ahead(
    pool: u64,
    parent_table: *const MeshString,
    days: i64,
) -> *mut u8 {
    unsafe {
        let parent_table = text_of(parent_table).trim();
        if parent_table.is_empty() {
            return err_result("Pg.create_daily_partitions_ahead: parent table must not be empty");
        }
        if days < 0 {
            return err_result(&format!(
                "Pg.create_daily_partitions_ahead: days must be non-negative, got {days}"
            ));
        }

        for offset in 0..days {
            let sql = build_create_daily_partition_sql(parent_table, offset);
            let exec_result = execute_ddl(pool, Ok(sql));
            if (*(exec_result as *const MeshResult)).tag != 0 {
                return exec_result;
            }
        }

        crate::io::ok_int(0).cast()
    }
}

#[no_mangle]
pub extern "C" fn mesh_pg_list_daily_partitions_before(
    pool: u64,
    parent_table: *const MeshString,
    max_days: i64,
) -> *mut u8 {
    unsafe {
        let parent_table = text_of(parent_table);
        if max_days < 0 {
            return err_result(&format!(
                "Pg.list_daily_partitions_before: max_days must be non-negative, got {max_days}"
            ));
        }

        let sql = build_list_daily_partitions_before_sql();
        let params = string_list(&[parent_table.to_string(), max_days.to_string()]);
        let query_result = mesh_pool_query(pool, mesh_str(sql), params);
        let result = &*(query_result as *const MeshResult);
        if result.tag != 0 {
            return query_result;
        }

        let rows = result.value;
        let partition_name_key = mesh_str("partition_name") as u64;
        let mut partitions = mesh_list_new();
        for i in 0..mesh_list_length(rows) {
            let row = mesh_list_get(rows, i) as *mut u8;
            partitions = mesh_list_append(partitions, mesh_map_get(row, partition_name_key));
        }

        alloc_result(0, partitions) as *mut u8
    }
}

#[no_mangle]
pub extern "C" fn mesh_pg_drop_partition(pool: u64, partition_name: *const MeshString) -> *mut u8 {
    unsafe { execute_ddl(pool, build_drop_partition_sql(text_of(partition_name))) }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn migration_pg_schema_build_create_extension_sql_quotes_identifier() {
        let sql = build_create_extension_sql("pgcrypto").expect("extension SQL should build");
        assert_eq!(sql, "CREATE EXTENSION IF NOT EXISTS \"pgcrypto\"");
    }

    #[test]
    fn migration_pg_schema_build_create_range_partitioned_table_sql_renders_partition_clause() {
        let sql = build_create_range_partitioned_table_sql(
            "events",
            &[
                "id:UUID:NOT NULL DEFAULT gen_random_uuid()".to_string(),
                "received_at:TIMESTAMPTZ:NOT NULL DEFAULT now()".to_string(),
            ],
            "received_at",
        )
        .expect("partitioned table SQL should build");
        assert_eq!(
            sql,
            "CREATE TABLE IF NOT EXISTS \"events\" (\"id\" UUID NOT NULL DEFAULT gen_random_uuid(), \"received_at\" TIMESTAMPTZ NOT NULL DEFAULT now()) PARTITION BY RANGE (\"received_at\")"
        );
    }

    #[test]
    fn migration_pg_schema_build_create_range_partitioned_table_sql_rejects_missing_partition_column(
    ) {
        let err = build_create_range_partitioned_table_sql(
            "events",
            &["id:UUID:PRIMARY KEY".to_string()],
            "received_at",
        )
        .expect_err("missing partition column should be rejected");
        assert_eq!(
            err,
            "Pg.create_range_partitioned_table: partition column `received_at` is missing from `events`"
        );
    }

    #[test]
    fn migration_pg_schema_build_create_range_partitioned_table_sql_allows_table_constraints() {
        let sql = build_create_range_partitioned_table_sql(
            "events",
            &[
                "id:UUID:NOT NULL DEFAULT gen_random_uuid()".to_string(),
                "received_at:TIMESTAMPTZ:NOT NULL DEFAULT now()".to_string(),
                "PRIMARY KEY (id, received_at)".to_string(),
            ],
            "received_at",
        )
        .expect("table constraints should be accepted for partitioned tables");
        assert!(sql.contains("PRIMARY KEY (id, received_at)"));
    }

    #[test]
    fn migration_pg_schema_build_create_gin_index_sql_renders_opclass() {
        let sql = build_create_gin_index_sql("events", "idx_events_tags", "tags", "jsonb_path_ops")
            .expect("GIN index SQL should build");
        assert_eq!(
            sql,
            "CREATE INDEX IF NOT EXISTS \"idx_events_tags\" ON \"events\" USING GIN (\"tags\" \"jsonb_path_ops\")"
        );
    }

    #[test]
    fn migration_pg_schema_build_create_daily_partition_sql_uses_database_clock() {
        let sql = build_create_daily_partition_sql("events", 3);
        assert!(sql.contains("part_date date := current_date + 3"));
        assert!(sql.contains("to_char(part_date, 'YYYYMMDD')"));
        assert!(sql.contains("PARTITION OF %I FOR VALUES FROM (%L) TO (%L)"));
    }

    #[test]
    fn migration_pg_schema_build_list_daily_partitions_before_sql_uses_catalog_query() {
        let sql = build_list_daily_partitions_before_sql();
        assert!(sql.contains("FROM pg_inherits"));
        assert!(sql.contains("current_date - $2::int"));
        assert!(sql.contains("left(c.relname, char_length($1) + 1) = $1 || '_'"));
    }

    #[test]
    fn migration_pg_schema_build_drop_partition_sql_quotes_identifier() {
        let sql =
            build_drop_partition_sql("events_20260216").expect("drop partition SQL should build");
        assert_eq!(sql, "DROP TABLE IF EXISTS \"events_20260216\"");
    }

    /// Listing partitions through a pool that cannot run the query returns
    /// the pool's error.
    #[test]
    fn listing_partitions_returns_the_query_error() {
        crate::gc::mesh_rt_init();
        let url = mesh_str("postgres://nobody@127.0.0.1:1/none");
        let opened = crate::db::pool::mesh_pool_open(url, 0, 1, 100);
        let pool = unsafe { *((*(opened as *const MeshResult)).value as *const u64) };
        crate::db::pool::mesh_pool_close(pool);
        let listed = mesh_pg_list_daily_partitions_before(pool, mesh_str("events"), 1);
        let result = unsafe { &*(listed as *const MeshResult) };
        assert_eq!(result.tag, 1);
        assert_eq!(unsafe { text_of(result.value) }, "pool is closed");
    }
}
