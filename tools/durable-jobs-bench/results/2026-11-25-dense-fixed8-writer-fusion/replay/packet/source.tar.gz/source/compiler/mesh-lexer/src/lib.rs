// Mesh lexer -- tokenizer for the Mesh programming language.

mod cursor;
mod error;

use cursor::Cursor;
use mesh_common::span::Span;
use mesh_common::token::{keyword_from_str, Token, TokenKind};

pub use error::{LexError, LexErrorKind, RegexError, SlotPipeError};

/// Tracks what the lexer is currently doing.
#[derive(Debug, Clone, PartialEq)]
enum LexerState {
    /// Normal top-level tokenization.
    Normal,
    /// Inside a string literal (after StringStart emitted).
    InString { triple: bool },
    /// Inside `${...}` string interpolation.
    InInterpolation { brace_depth: u32 },
}

/// The Mesh lexer. Converts source text into a stream of tokens.
///
/// Wraps a [`Cursor`] for byte-level iteration and implements
/// `Iterator<Item = Token>` so callers can consume tokens lazily
/// or collect them into a `Vec`.
///
/// Uses a state stack to handle nested string interpolation contexts.
pub struct Lexer<'src> {
    cursor: Cursor<'src>,
    #[allow(dead_code)]
    source: &'src str,
    /// Whether we have already emitted the `Eof` token.
    emitted_eof: bool,
    /// Pending tokens to emit before resuming normal lexing.
    pending: Vec<Token>,
    /// State stack for tracking nested lexing contexts.
    state_stack: Vec<LexerState>,
    /// One per `Error` token produced so far, in token order.
    errors: Vec<LexError>,
}

impl<'src> Lexer<'src> {
    /// Create a new lexer for the given source text.
    pub fn new(source: &'src str) -> Self {
        Self {
            cursor: Cursor::new(source),
            source,
            emitted_eof: false,
            pending: Vec::new(),
            state_stack: vec![LexerState::Normal],
            errors: Vec::new(),
        }
    }

    /// Convenience: tokenize the entire source into a `Vec<Token>`.
    ///
    /// The returned vector includes the final `Eof` token.
    pub fn tokenize(source: &str) -> Vec<Token> {
        Lexer::new(source).collect()
    }

    /// [`tokenize`](Self::tokenize), with why each `Error` token was
    /// rejected: the `n`th error is the `n`th `Error` token's, at its span.
    pub fn tokenize_with_errors(source: &str) -> (Vec<Token>, Vec<LexError>) {
        let mut lexer = Lexer::new(source);
        let tokens = lexer.by_ref().collect();
        (tokens, lexer.errors)
    }

    /// An `Error` token from `start` to `end`, rejected as `kind`.
    fn error(&mut self, kind: LexErrorKind, start: u32, end: u32) -> Token {
        self.errors.push(LexError {
            kind,
            span: Span::new(start, end),
        });
        Token::new(TokenKind::Error, start, end)
    }

    /// Current lexer state (top of stack).
    fn current_state(&self) -> &LexerState {
        self.state_stack
            .last()
            .expect("state stack must never be empty")
    }

    /// Produce the next token based on current state.
    fn produce_token(&mut self) -> Token {
        match self.current_state().clone() {
            LexerState::Normal => self.lex_normal(),
            LexerState::InString { triple } => self.lex_string_content(triple),
            LexerState::InInterpolation { brace_depth } => self.lex_interpolation(brace_depth),
        }
    }

    // ── Normal mode ────────────────────────────────────────────────────

    /// Tokenize in normal mode (top-level or inside interpolation expression).
    fn lex_normal(&mut self) -> Token {
        self.skip_whitespace();

        let start = self.cursor.pos();

        let Some(c) = self.cursor.peek() else {
            return Token::new(TokenKind::Eof, start, start);
        };

        match c {
            // ── Newlines ───────────────────────────────────────────────────
            '\n' => {
                self.cursor.advance();
                Token::new(TokenKind::Newline, start, self.cursor.pos())
            }
            '\r' => {
                self.cursor.advance();
                // \r\n = single Newline
                if self.cursor.peek() == Some('\n') {
                    self.cursor.advance();
                }
                Token::new(TokenKind::Newline, start, self.cursor.pos())
            }

            // ── Single-character delimiters ─────────────────────────────
            '(' => self.single_char_token(TokenKind::LParen, start),
            ')' => self.single_char_token(TokenKind::RParen, start),
            '[' => self.single_char_token(TokenKind::LBracket, start),
            ']' => self.single_char_token(TokenKind::RBracket, start),
            '{' => self.single_char_token(TokenKind::LBrace, start),
            '}' => self.single_char_token(TokenKind::RBrace, start),
            ',' => self.single_char_token(TokenKind::Comma, start),
            ';' => self.single_char_token(TokenKind::Semicolon, start),
            '@' => self.single_char_token(TokenKind::At, start),

            // ── Multi-character operators ────────────────────────────────
            '=' => self.lex_eq(start),
            '!' => self.lex_bang(start),
            '<' => self.lex_lt(start),
            '>' => self.lex_gt(start),
            '&' => self.lex_amp(start),
            '|' => self.lex_pipe(start),
            '+' => self.lex_plus(start),
            '-' => self.lex_minus(start),
            ':' => self.lex_colon(start),
            '.' => self.lex_dot(start),
            '*' => self.single_char_token(TokenKind::Star, start),
            '/' => self.single_char_token(TokenKind::Slash, start),
            '%' => self.single_char_token(TokenKind::Percent, start),

            // ── Single-character operators ─────────────────────────────
            '?' => self.single_char_token(TokenKind::Question, start),

            // ── Regex literal: ~r/pattern/flags ─────────────────────────
            '~' => {
                self.cursor.advance(); // consume '~'
                                       // Only ~r/.../ is currently valid; anything else is an error.
                if self.cursor.peek() == Some('r') {
                    self.lex_regex_literal(start)
                } else {
                    let end = self.cursor.pos();
                    self.error(LexErrorKind::InvalidRegex(RegexError::Start), start, end)
                }
            }

            // ── Comments ────────────────────────────────────────────────
            '#' => self.lex_comment(start),

            // ── Number literals ─────────────────────────────────────────
            '0'..='9' => self.lex_number(start),

            // ── String literals ─────────────────────────────────────────
            '"' => self.lex_string_start(start),

            // ── Identifiers and keywords ────────────────────────────────
            c if is_ident_start(c) => self.lex_ident(start),

            // ── Unknown character (error recovery) ──────────────────────
            _ => {
                self.cursor.advance();
                let end = self.cursor.pos();
                self.error(LexErrorKind::UnknownCharacter, start, end)
            }
        }
    }

    // ── Helpers ────────────────────────────────────────────────────────

    /// Skip whitespace characters (spaces and tabs only -- newlines are tokens).
    fn skip_whitespace(&mut self) {
        self.cursor.eat_while(|c| c == ' ' || c == '\t');
    }

    /// Consume one character and return a token of the given kind.
    fn single_char_token(&mut self, kind: TokenKind, start: u32) -> Token {
        self.cursor.advance();
        Token::new(kind, start, self.cursor.pos())
    }

    // ── Operator lexing ────────────────────────────────────────────────

    /// `=` -> `Eq`, `==` -> `EqEq`, `=>` -> `FatArrow`
    fn lex_eq(&mut self, start: u32) -> Token {
        self.cursor.advance(); // consume '='
        match self.cursor.peek() {
            Some('=') => {
                self.cursor.advance();
                Token::new(TokenKind::EqEq, start, self.cursor.pos())
            }
            Some('>') => {
                self.cursor.advance();
                Token::new(TokenKind::FatArrow, start, self.cursor.pos())
            }
            _ => Token::new(TokenKind::Eq, start, self.cursor.pos()),
        }
    }

    /// `!` -> `Bang`, `!=` -> `NotEq`
    fn lex_bang(&mut self, start: u32) -> Token {
        self.cursor.advance(); // consume '!'
        if self.cursor.peek() == Some('=') {
            self.cursor.advance();
            Token::new(TokenKind::NotEq, start, self.cursor.pos())
        } else {
            Token::new(TokenKind::Bang, start, self.cursor.pos())
        }
    }

    /// `<` -> `Lt`, `<=` -> `LtEq`, `<>` -> `Diamond`
    fn lex_lt(&mut self, start: u32) -> Token {
        self.cursor.advance(); // consume '<'
        match self.cursor.peek() {
            Some('=') => {
                self.cursor.advance();
                Token::new(TokenKind::LtEq, start, self.cursor.pos())
            }
            Some('>') => {
                self.cursor.advance();
                Token::new(TokenKind::Diamond, start, self.cursor.pos())
            }
            _ => Token::new(TokenKind::Lt, start, self.cursor.pos()),
        }
    }

    /// `>` -> `Gt`, `>=` -> `GtEq`
    fn lex_gt(&mut self, start: u32) -> Token {
        self.cursor.advance(); // consume '>'
        if self.cursor.peek() == Some('=') {
            self.cursor.advance();
            Token::new(TokenKind::GtEq, start, self.cursor.pos())
        } else {
            Token::new(TokenKind::Gt, start, self.cursor.pos())
        }
    }

    /// `&&` -> `AmpAmp`, single `&` -> `Error`
    fn lex_amp(&mut self, start: u32) -> Token {
        self.cursor.advance(); // consume '&'
        if self.cursor.peek() == Some('&') {
            self.cursor.advance();
            Token::new(TokenKind::AmpAmp, start, self.cursor.pos())
        } else {
            let end = self.cursor.pos();
            self.error(LexErrorKind::SingleAmpersand, start, end)
        }
    }

    /// `||` -> `PipePipe`, `|>` -> `Pipe`, `|N>` -> `SlotPipe(N)`, single `|` -> `Bar`
    ///
    /// For slot pipe:
    /// - `|2>` emits `SlotPipe(2)`, `|10>` emits `SlotPipe(10)`
    /// - `|0>` and `|1>` emit `Error` (invalid by design: 0 is meaningless, use `|>` for slot 1)
    fn lex_pipe(&mut self, start: u32) -> Token {
        self.cursor.advance(); // consume '|'
        match self.cursor.peek() {
            Some('|') => {
                self.cursor.advance();
                Token::new(TokenKind::PipePipe, start, self.cursor.pos())
            }
            Some('>') => {
                self.cursor.advance();
                Token::new(TokenKind::Pipe, start, self.cursor.pos())
            }
            Some(c) if c.is_ascii_digit() => {
                // Scan the digit sequence
                let digit_start = self.cursor.pos();
                self.cursor.eat_while(|c| c.is_ascii_digit());
                let digit_end = self.cursor.pos();
                let digit_str = self.cursor.slice(digit_start, digit_end);
                let n: u32 = digit_str.parse().unwrap_or(0);
                // Must be followed by '>'
                if self.cursor.peek() == Some('>') {
                    self.cursor.advance(); // consume '>'
                    let end = self.cursor.pos();
                    match n {
                        0 => self.error(
                            LexErrorKind::InvalidSlotPipe(SlotPipeError::Zero),
                            start,
                            end,
                        ),
                        1 => self.error(
                            LexErrorKind::InvalidSlotPipe(SlotPipeError::One),
                            start,
                            end,
                        ),
                        _ => Token::new(TokenKind::SlotPipe(n), start, end),
                    }
                } else {
                    let end = self.cursor.pos();
                    self.error(
                        LexErrorKind::InvalidSlotPipe(SlotPipeError::Unclosed),
                        start,
                        end,
                    )
                }
            }
            _ => Token::new(TokenKind::Bar, start, self.cursor.pos()),
        }
    }

    /// `+` -> `Plus`, `++` -> `PlusPlus`
    fn lex_plus(&mut self, start: u32) -> Token {
        self.cursor.advance(); // consume '+'
        if self.cursor.peek() == Some('+') {
            self.cursor.advance();
            Token::new(TokenKind::PlusPlus, start, self.cursor.pos())
        } else {
            Token::new(TokenKind::Plus, start, self.cursor.pos())
        }
    }

    /// `-` -> `Minus`, `->` -> `Arrow`
    fn lex_minus(&mut self, start: u32) -> Token {
        self.cursor.advance(); // consume '-'
        if self.cursor.peek() == Some('>') {
            self.cursor.advance();
            Token::new(TokenKind::Arrow, start, self.cursor.pos())
        } else {
            Token::new(TokenKind::Minus, start, self.cursor.pos())
        }
    }

    /// `:` -> `Colon`, `::` -> `ColonColon`, `:ident` -> `Atom`
    ///
    /// A `:` right after a name or a closing bracket separates a key from its
    /// value, so `x:y` in `Point { x:y }` is `x`, `:`, `y`, not `x` and the
    /// atom `:y`.
    fn lex_colon(&mut self, start: u32) -> Token {
        let after_operand = self.source[..start as usize]
            .chars()
            .next_back()
            .is_some_and(|c| is_ident_continue(c) || matches!(c, ')' | ']' | '}'));
        self.cursor.advance(); // consume ':'
        if self.cursor.peek() == Some(':') {
            self.cursor.advance();
            Token::new(TokenKind::ColonColon, start, self.cursor.pos())
        } else if !after_operand
            && self
                .cursor
                .peek()
                .is_some_and(|c| c.is_ascii_lowercase() || c == '_')
        {
            // Atom literal: `:name`, `:email`, `:asc`, `:_field`
            self.cursor.eat_while(is_ident_continue);
            Token::new(TokenKind::Atom, start, self.cursor.pos())
        } else {
            Token::new(TokenKind::Colon, start, self.cursor.pos())
        }
    }

    /// `.` -> `Dot`, `..` -> `DotDot`
    fn lex_dot(&mut self, start: u32) -> Token {
        self.cursor.advance(); // consume '.'
        if self.cursor.peek() == Some('.') {
            self.cursor.advance();
            Token::new(TokenKind::DotDot, start, self.cursor.pos())
        } else {
            Token::new(TokenKind::Dot, start, self.cursor.pos())
        }
    }

    // ── Regex literals ────────────────────────────────────────────────

    /// Lex a regex literal: `~r/pattern/flags`.
    ///
    /// Called after `~` has been consumed and `r` is at the current position.
    /// - Consumes `r`
    /// - Expects `/` opening delimiter; returns Error if absent
    /// - Reads pattern characters until an unescaped `/` (handles `\/` as literal)
    /// - Reads optional flags (`i`, `m`, `s` only); any other letter -> Error
    /// - Returns `RegexLiteral(pattern, flags)` on success
    fn lex_regex_literal(&mut self, start: u32) -> Token {
        self.cursor.advance(); // consume 'r'

        // Expect opening '/'
        if self.cursor.peek() != Some('/') {
            let end = self.cursor.pos();
            return self.error(LexErrorKind::InvalidRegex(RegexError::Start), start, end);
        }
        self.cursor.advance(); // consume '/'

        // Read pattern until unescaped '/' or EOF
        let mut pattern = String::new();
        let mut prev_was_backslash = false;
        loop {
            match self.cursor.peek() {
                None => {
                    let end = self.cursor.pos();
                    return self.error(
                        LexErrorKind::InvalidRegex(RegexError::Unterminated),
                        start,
                        end,
                    );
                }
                Some('/') if !prev_was_backslash => {
                    self.cursor.advance(); // consume closing '/'
                    break;
                }
                Some(c) => {
                    pattern.push(c);
                    prev_was_backslash = c == '\\' && !prev_was_backslash;
                    self.cursor.advance();
                }
            }
        }

        // Read flags: only 'i', 'm', 's' are valid
        let mut flags = String::new();
        loop {
            match self.cursor.peek() {
                Some(c @ ('i' | 'm' | 's')) => {
                    flags.push(c);
                    self.cursor.advance();
                }
                Some(c) if c.is_ascii_alphabetic() => {
                    self.cursor.advance();
                    let end = self.cursor.pos();
                    return self.error(LexErrorKind::InvalidRegex(RegexError::Flag), start, end);
                }
                _ => break,
            }
        }

        Token::new(
            TokenKind::RegexLiteral(pattern, flags),
            start,
            self.cursor.pos(),
        )
    }

    // ── Comments ──────────────────────────────────────────────────────

    /// Lex a comment starting with `#`.
    ///
    /// - `##!` -> `ModuleDocComment`
    /// - `##`  -> `DocComment`
    /// - `#=`  -> nestable block comment
    /// - `#`   -> `Comment`
    fn lex_comment(&mut self, start: u32) -> Token {
        self.cursor.advance(); // consume '#'

        if self.cursor.peek() == Some('#') {
            // Could be doc comment or module doc comment
            self.cursor.advance(); // consume second '#'

            if self.cursor.peek() == Some('!') {
                // Module doc comment: ##!
                self.cursor.advance(); // consume '!'
                                       // Skip optional leading space
                if self.cursor.peek() == Some(' ') {
                    self.cursor.advance();
                }
                self.cursor.eat_while(|c| c != '\n' && c != '\r');
                Token::new(TokenKind::ModuleDocComment, start, self.cursor.pos())
            } else {
                // Doc comment: ##
                // Skip optional leading space
                if self.cursor.peek() == Some(' ') {
                    self.cursor.advance();
                }
                self.cursor.eat_while(|c| c != '\n' && c != '\r');
                Token::new(TokenKind::DocComment, start, self.cursor.pos())
            }
        } else if self.cursor.peek() == Some('=') {
            // Block comment: #= ... =#
            self.lex_block_comment(start)
        } else {
            // Regular line comment: #
            // Skip optional leading space
            if self.cursor.peek() == Some(' ') {
                self.cursor.advance();
            }
            self.cursor.eat_while(|c| c != '\n' && c != '\r');
            Token::new(TokenKind::Comment, start, self.cursor.pos())
        }
    }

    /// Lex a nestable block comment `#= ... =#`.
    ///
    /// Block comments can be nested: `#= outer #= inner =# still =#` is one comment.
    /// Tracks nesting depth starting at 1 (for the opening `#=` already consumed).
    fn lex_block_comment(&mut self, start: u32) -> Token {
        self.cursor.advance(); // consume '=' (the '#' was already consumed)
        let mut depth: u32 = 1;

        loop {
            match self.cursor.peek() {
                None => {
                    let end = self.cursor.pos();
                    return self.error(LexErrorKind::UnterminatedBlockComment, start, end);
                }
                Some('#') => {
                    self.cursor.advance();
                    if self.cursor.peek() == Some('=') {
                        self.cursor.advance();
                        depth += 1;
                    }
                }
                Some('=') => {
                    self.cursor.advance();
                    if self.cursor.peek() == Some('#') {
                        self.cursor.advance();
                        depth -= 1;
                        if depth == 0 {
                            return Token::new(TokenKind::Comment, start, self.cursor.pos());
                        }
                    }
                }
                Some(_) => {
                    self.cursor.advance();
                }
            }
        }
    }

    // ── Number literals ───────────────────────────────────────────────

    /// Lex a number literal starting with a digit.
    ///
    /// Handles decimal, hex (0x), binary (0b), octal (0o), floats, and
    /// scientific notation. Underscore separators are allowed.
    fn lex_number(&mut self, start: u32) -> Token {
        let first = self.cursor.advance().unwrap(); // consume first digit

        if first == '0' {
            match self.cursor.peek() {
                Some('x' | 'X') => return self.lex_hex(start),
                Some('b' | 'B') => return self.lex_binary(start),
                Some('o' | 'O') => return self.lex_octal(start),
                _ => {}
            }
        }

        // Decimal: eat digits and underscores
        self.cursor.eat_while(|c| c.is_ascii_digit() || c == '_');

        // Check for float: `.` followed by a digit (not `..` range)
        if self.cursor.peek() == Some('.')
            && self.cursor.peek_next().is_some_and(|c| c.is_ascii_digit())
        {
            self.cursor.advance(); // consume '.'
            self.cursor.eat_while(|c| c.is_ascii_digit() || c == '_');

            // Check for scientific notation
            if matches!(self.cursor.peek(), Some('e' | 'E')) {
                self.lex_exponent();
            }

            return Token::new(TokenKind::FloatLiteral, start, self.cursor.pos());
        }

        // Check for scientific notation on integer (makes it a float)
        if matches!(self.cursor.peek(), Some('e' | 'E')) {
            self.lex_exponent();
            return Token::new(TokenKind::FloatLiteral, start, self.cursor.pos());
        }

        Token::new(TokenKind::IntLiteral, start, self.cursor.pos())
    }

    /// Lex hex digits after `0x`/`0X`.
    fn lex_hex(&mut self, start: u32) -> Token {
        self.lex_radix_digits(start)
    }

    /// Lex binary digits after `0b`/`0B`.
    fn lex_binary(&mut self, start: u32) -> Token {
        self.lex_radix_digits(start)
    }

    /// Lex octal digits after `0o`/`0O`.
    fn lex_octal(&mut self, start: u32) -> Token {
        self.lex_radix_digits(start)
    }

    /// The digits after a radix prefix. Every letter and digit belongs to
    /// the literal, so `0b102` is one (invalid) literal the checker names
    /// the bad digit of, not `0b10` followed by a stray `2`.
    fn lex_radix_digits(&mut self, start: u32) -> Token {
        self.cursor.advance(); // consume the radix letter
        self.cursor
            .eat_while(|c| c.is_ascii_alphanumeric() || c == '_');
        Token::new(TokenKind::IntLiteral, start, self.cursor.pos())
    }

    /// Lex the exponent part of a float literal: `e`/`E` followed by optional
    /// sign and digits.
    fn lex_exponent(&mut self) {
        self.cursor.advance(); // consume 'e'/'E'
        if matches!(self.cursor.peek(), Some('+' | '-')) {
            self.cursor.advance(); // consume sign
        }
        self.cursor.eat_while(|c| c.is_ascii_digit() || c == '_');
    }

    // ── String literals ───────────────────────────────────────────────

    /// Lex the opening of a string literal (`"` or `"""`).
    ///
    /// Emits `StringStart` and pushes `InString` onto the state stack.
    fn lex_string_start(&mut self, start: u32) -> Token {
        self.cursor.advance(); // consume first '"'

        // Check for triple-quote: two more '"' follow
        if self.cursor.peek() == Some('"') && self.cursor.peek_next() == Some('"') {
            self.cursor.advance(); // consume second '"'
            self.cursor.advance(); // consume third '"'
            self.state_stack.push(LexerState::InString { triple: true });
            Token::new(TokenKind::StringStart, start, self.cursor.pos())
        } else {
            self.state_stack
                .push(LexerState::InString { triple: false });
            Token::new(TokenKind::StringStart, start, self.cursor.pos())
        }
    }

    /// Lex string content when in InString state.
    ///
    /// Scans characters until finding:
    /// - `${` -> emit StringContent (if any), then InterpolationStart
    /// - closing delimiter -> emit StringContent (if any), then StringEnd
    /// - escape sequence -> include in content
    /// - EOF -> Error token
    fn lex_string_content(&mut self, triple: bool) -> Token {
        let start = self.cursor.pos();

        loop {
            match self.cursor.peek() {
                None => {
                    // Unterminated string
                    self.state_stack.pop();
                    let end = self.cursor.pos();
                    if end > start {
                        // Emit accumulated content first, then queue error
                        let error = self.error(LexErrorKind::UnterminatedString, end, end);
                        self.pending.push(error);
                        return Token::new(TokenKind::StringContent, start, end);
                    }
                    return self.error(LexErrorKind::UnterminatedString, start, end);
                }
                Some('$') if self.cursor.peek_next() == Some('{') => {
                    let content_end = self.cursor.pos();
                    self.cursor.advance(); // consume '$'
                    self.cursor.advance(); // consume '{'
                    let interp_end = self.cursor.pos();

                    // Pop InString, push InString back (we'll return to it),
                    // then push InInterpolation on top.
                    // Actually, we keep InString on the stack and push InInterpolation on top.
                    self.state_stack
                        .push(LexerState::InInterpolation { brace_depth: 0 });

                    // Queue the InterpolationStart token
                    self.pending.push(Token::new(
                        TokenKind::InterpolationStart,
                        content_end,
                        interp_end,
                    ));

                    if content_end > start {
                        // There's content before the interpolation
                        return Token::new(TokenKind::StringContent, start, content_end);
                    } else {
                        // No content before interpolation, emit InterpolationStart directly
                        return self.pending.remove(0);
                    }
                }
                Some('#') if self.cursor.peek_next() == Some('{') => {
                    let content_end = self.cursor.pos();
                    self.cursor.advance(); // consume '#'
                    self.cursor.advance(); // consume '{'
                    let interp_end = self.cursor.pos();

                    self.state_stack
                        .push(LexerState::InInterpolation { brace_depth: 0 });

                    self.pending.push(Token::new(
                        TokenKind::InterpolationStart,
                        content_end,
                        interp_end,
                    ));

                    if content_end > start {
                        return Token::new(TokenKind::StringContent, start, content_end);
                    } else {
                        return self.pending.remove(0);
                    }
                }
                Some('"') if !triple => {
                    let content_end = self.cursor.pos();
                    self.cursor.advance(); // consume closing '"'
                    let str_end = self.cursor.pos();

                    // Pop InString state
                    self.state_stack.pop();

                    // Queue StringEnd
                    self.pending
                        .push(Token::new(TokenKind::StringEnd, content_end, str_end));

                    if content_end > start {
                        return Token::new(TokenKind::StringContent, start, content_end);
                    } else {
                        // Empty content, just emit StringEnd
                        return self.pending.remove(0);
                    }
                }
                Some('"') if triple => {
                    // Check for closing """
                    if self.cursor.peek_next() == Some('"') {
                        self.cursor.advance(); // first '"'
                        self.cursor.advance(); // second '"'
                        if self.cursor.peek() == Some('"') {
                            // Found closing """. In a longer run of quotes the
                            // last three close the heredoc and the ones before
                            // them are its text, so it can end with a quote:
                            // `"""say "hi""""`.
                            self.cursor.advance(); // third '"'
                            while self.cursor.peek() == Some('"') {
                                self.cursor.advance();
                            }
                            let str_end = self.cursor.pos();
                            let content_end = str_end - 3;

                            // Pop InString state
                            self.state_stack.pop();

                            // Queue StringEnd
                            self.pending.push(Token::new(
                                TokenKind::StringEnd,
                                content_end,
                                str_end,
                            ));

                            if content_end > start {
                                return Token::new(TokenKind::StringContent, start, content_end);
                            } else {
                                return self.pending.remove(0);
                            }
                        }
                        // Only two quotes -- they're part of content, keep scanning
                        continue;
                    }
                    // Single quote inside triple-quoted string is content
                    self.cursor.advance();
                }
                Some('\\') => {
                    self.cursor.advance(); // consume '\'
                    self.cursor.advance(); // consume escaped char
                }
                Some(_) => {
                    self.cursor.advance();
                }
            }
        }
    }

    // ── Interpolation ─────────────────────────────────────────────────

    /// Lex tokens inside `${...}` interpolation, `brace_depth` braces deep.
    ///
    /// Tokenizes as in normal mode but tracks brace depth. When the closing
    /// `}` is found (at depth 0), emits InterpolationEnd and pops back to
    /// InString.
    fn lex_interpolation(&mut self, brace_depth: u32) -> Token {
        self.skip_whitespace();
        let start = self.cursor.pos();
        match self.cursor.peek() {
            // EOF inside interpolation -- error
            None => {
                self.state_stack.pop();
                self.error(LexErrorKind::UnterminatedInterpolation, start, start)
            }
            Some('{') => {
                self.set_interpolation_depth(brace_depth + 1);
                self.single_char_token(TokenKind::LBrace, start)
            }
            Some('}') if brace_depth == 0 => {
                self.cursor.advance();
                self.state_stack.pop(); // back to InString
                Token::new(TokenKind::InterpolationEnd, start, self.cursor.pos())
            }
            Some('}') => {
                self.set_interpolation_depth(brace_depth - 1);
                self.single_char_token(TokenKind::RBrace, start)
            }
            Some(_) => self.lex_normal(),
        }
    }

    /// Replace the innermost interpolation's brace depth.
    fn set_interpolation_depth(&mut self, brace_depth: u32) {
        self.state_stack.pop();
        self.state_stack
            .push(LexerState::InInterpolation { brace_depth });
    }

    // ── Identifiers and keywords ──────────────────────────────────────

    /// Lex an identifier or keyword.
    fn lex_ident(&mut self, start: u32) -> Token {
        self.cursor.advance(); // consume first char
        self.cursor.eat_while(is_ident_continue);
        let text = self.cursor.slice(start, self.cursor.pos());

        let kind = keyword_from_str(text).unwrap_or(TokenKind::Ident);
        Token::new(kind, start, self.cursor.pos())
    }
}

impl<'src> Iterator for Lexer<'src> {
    type Item = Token;

    fn next(&mut self) -> Option<Token> {
        if self.emitted_eof {
            return None;
        }

        // Drain pending tokens first (never the end of input, which is
        // produced below).
        if !self.pending.is_empty() {
            return Some(self.pending.remove(0));
        }

        let token = self.produce_token();
        if token.kind == TokenKind::Eof {
            self.emitted_eof = true;
        }
        Some(token)
    }
}

/// Whether a character can start an identifier.
fn is_ident_start(c: char) -> bool {
    c.is_alphabetic() || c == '_'
}

/// Whether a character can continue an identifier.
fn is_ident_continue(c: char) -> bool {
    c.is_alphanumeric() || c == '_'
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn lex_simple_expression() {
        let tokens = Lexer::tokenize("let x = 42");
        let kinds: Vec<_> = tokens.iter().map(|t| &t.kind).collect();
        assert_eq!(
            kinds,
            vec![
                &TokenKind::Let,
                &TokenKind::Ident,
                &TokenKind::Eq,
                &TokenKind::IntLiteral,
                &TokenKind::Eof,
            ]
        );
    }

    #[test]
    fn lex_simple_string() {
        let tokens = Lexer::tokenize(r#""hello""#);
        let kinds: Vec<_> = tokens.iter().map(|t| &t.kind).collect();
        assert_eq!(
            kinds,
            vec![
                &TokenKind::StringStart,
                &TokenKind::StringContent,
                &TokenKind::StringEnd,
                &TokenKind::Eof,
            ]
        );
    }

    #[test]
    fn lex_spans_accurate() {
        let tokens = Lexer::tokenize("let x = 42");
        // let: 0-3
        assert_eq!(tokens[0].span.start, 0);
        assert_eq!(tokens[0].span.end, 3);
        // x: 4-5
        assert_eq!(tokens[1].span.start, 4);
        assert_eq!(tokens[1].span.end, 5);
        // =: 6-7
        assert_eq!(tokens[2].span.start, 6);
        assert_eq!(tokens[2].span.end, 7);
        // 42: 8-10
        assert_eq!(tokens[3].span.start, 8);
        assert_eq!(tokens[3].span.end, 10);
    }

    #[test]
    fn lex_string_interpolation_basic() {
        let tokens = Lexer::tokenize(r#""hello ${name} world""#);
        let kinds: Vec<_> = tokens.iter().map(|t| &t.kind).collect();
        assert_eq!(
            kinds,
            vec![
                &TokenKind::StringStart,
                &TokenKind::StringContent,      // "hello "
                &TokenKind::InterpolationStart, // ${
                &TokenKind::Ident,              // name
                &TokenKind::InterpolationEnd,   // }
                &TokenKind::StringContent,      // " world"
                &TokenKind::StringEnd,
                &TokenKind::Eof,
            ]
        );
    }

    #[test]
    fn lex_nested_block_comment() {
        let tokens = Lexer::tokenize("#= outer #= inner =# still =#");
        let kinds: Vec<_> = tokens.iter().map(|t| &t.kind).collect();
        assert_eq!(kinds, vec![&TokenKind::Comment, &TokenKind::Eof,]);
    }

    #[test]
    fn lex_slot_pipe_basic() {
        let tokens = Lexer::tokenize("|2>");
        assert_eq!(tokens[0].kind, TokenKind::SlotPipe(2));
    }

    #[test]
    fn lex_slot_pipe_multidigit() {
        let tokens = Lexer::tokenize("|10>");
        assert_eq!(tokens[0].kind, TokenKind::SlotPipe(10));
    }

    #[test]
    fn lex_slot_pipe_zero_is_error() {
        let tokens = Lexer::tokenize("|0>");
        assert_eq!(tokens[0].kind, TokenKind::Error);
    }

    #[test]
    fn lex_slot_pipe_one_is_error() {
        let tokens = Lexer::tokenize("|1>");
        assert_eq!(tokens[0].kind, TokenKind::Error);
    }

    #[test]
    fn lex_regular_pipe_unchanged() {
        let tokens = Lexer::tokenize("|>");
        assert_eq!(tokens[0].kind, TokenKind::Pipe);
    }

    #[test]
    fn lex_bar_unchanged() {
        let tokens = Lexer::tokenize("|");
        assert_eq!(tokens[0].kind, TokenKind::Bar);
    }

    /// The errors of `source`, after checking that each is its `Error`
    /// token's, in order.
    fn errors(source: &str) -> Vec<(LexErrorKind, u32, u32)> {
        let (tokens, errors) = Lexer::tokenize_with_errors(source);
        let error_spans: Vec<_> = tokens
            .iter()
            .filter(|token| token.kind == TokenKind::Error)
            .map(|token| token.span)
            .collect();
        let spans: Vec<_> = errors.iter().map(|error| error.span).collect();
        assert_eq!(spans, error_spans, "{source:?}");
        assert_eq!(tokens, Lexer::tokenize(source), "{source:?}");
        errors
            .iter()
            .map(|error| (error.kind, error.span.start, error.span.end))
            .collect()
    }

    #[test]
    fn every_error_token_says_why() {
        use LexErrorKind::*;
        let cases: &[(&str, &[(LexErrorKind, u32, u32)])] = &[
            ("~x", &[(InvalidRegex(RegexError::Start), 0, 1)]),
            ("$", &[(UnknownCharacter, 0, 1)]),
            ("1 ¤ 2", &[(UnknownCharacter, 2, 4)]),
            ("a & b", &[(SingleAmpersand, 2, 3)]),
            ("x |0> f", &[(InvalidSlotPipe(SlotPipeError::Zero), 2, 5)]),
            ("x |1> f", &[(InvalidSlotPipe(SlotPipeError::One), 2, 5)]),
            (
                "x |3 f",
                &[(InvalidSlotPipe(SlotPipeError::Unclosed), 2, 4)],
            ),
            ("~rx", &[(InvalidRegex(RegexError::Start), 0, 2)]),
            ("~r/abc", &[(InvalidRegex(RegexError::Unterminated), 0, 6)]),
            ("~r/a/x", &[(InvalidRegex(RegexError::Flag), 0, 6)]),
            ("#= a #= b =#", &[(UnterminatedBlockComment, 0, 12)]),
            ("\"abc", &[(UnterminatedString, 4, 4)]),
            ("\"", &[(UnterminatedString, 1, 1)]),
            (
                "\"${x",
                &[
                    (UnterminatedInterpolation, 4, 4),
                    (UnterminatedString, 4, 4),
                ],
            ),
            (
                "a & b $ c",
                &[(SingleAmpersand, 2, 3), (UnknownCharacter, 6, 7)],
            ),
        ];
        for (source, expected) in cases {
            assert_eq!(errors(source), *expected, "{source:?}");
        }
    }

    #[test]
    fn valid_tokens_have_no_errors() {
        assert_eq!(
            errors("a && b |> f |2> g ~r/a\\/b/ims #= c =# \"${x}\""),
            []
        );
    }

    #[test]
    fn messages_name_the_rejected_text() {
        let message = |source: &str| {
            let (tokens, errors) = Lexer::tokenize_with_errors(source);
            let error = errors[0];
            let token = tokens.iter().find(|t| t.kind == TokenKind::Error).unwrap();
            let text = &source[token.span.start as usize..token.span.end as usize];
            (error.kind.code().id(), error.kind.message(text))
        };
        assert_eq!(message("¤"), ("P0101", "unknown character `¤`".to_string()));
        assert_eq!(
            message("x |1> f"),
            (
                "P0105",
                "`|1>` is not a pipe: `|>` pipes into the first argument".to_string()
            )
        );
        assert_eq!(
            message("x |4 f"),
            (
                "P0105",
                "`|4` is not a pipe: a slot pipe ends with `>`, as in `|4>`".to_string()
            )
        );
        assert_eq!(
            message("~r/a/q"),
            (
                "P0106",
                "unknown regex flag `q`: the flags are `i`, `m`, and `s`".to_string()
            )
        );
        assert_eq!(
            message("a & b"),
            (
                "P0107",
                "`&` is not an operator: logical and is `&&` or `and`".to_string()
            )
        );
    }

    #[test]
    fn lex_newlines_emitted() {
        let tokens = Lexer::tokenize("let x = 1\nlet y = 2");
        let kinds: Vec<_> = tokens.iter().map(|t| &t.kind).collect();
        assert_eq!(
            kinds,
            vec![
                &TokenKind::Let,
                &TokenKind::Ident,
                &TokenKind::Eq,
                &TokenKind::IntLiteral,
                &TokenKind::Newline,
                &TokenKind::Let,
                &TokenKind::Ident,
                &TokenKind::Eq,
                &TokenKind::IntLiteral,
                &TokenKind::Eof,
            ]
        );
    }
}
