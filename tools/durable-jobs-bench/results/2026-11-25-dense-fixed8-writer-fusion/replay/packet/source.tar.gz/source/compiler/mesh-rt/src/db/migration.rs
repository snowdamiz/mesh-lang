//! Migration DDL generation module for the Mesh runtime.
//!
//! Provides eight `extern "C"` DDL builder functions that produce correctly
//! quoted PostgreSQL DDL SQL and execute it via `Pool.execute`:
//!
//! - `mesh_migration_create_table`: CREATE TABLE IF NOT EXISTS with column defs
//! - `mesh_migration_drop_table`: DROP TABLE IF EXISTS
//! - `mesh_migration_add_column`: ALTER TABLE ADD COLUMN IF NOT EXISTS
//! - `mesh_migration_drop_column`: ALTER TABLE DROP COLUMN IF EXISTS
//! - `mesh_migration_rename_column`: ALTER TABLE RENAME COLUMN
//! - `mesh_migration_create_index`: CREATE [UNIQUE] INDEX IF NOT EXISTS
//! - `mesh_migration_drop_index`: DROP INDEX IF EXISTS
//! - `mesh_migration_execute`: Raw SQL escape hatch via Pool.execute
//!
//! All functions accept Mesh runtime types (MeshString pointers, List pointers)
//! and execute the generated DDL via `mesh_pool_execute`. SQL identifiers are
//! double-quoted per PostgreSQL convention.

use super::{execute_ddl, quote_ident, quote_name};
use crate::collections::list::list_strings;
use crate::collections::list::mesh_list_new;
use crate::db::pool::mesh_pool_execute;
use crate::string::{text_of, MeshString};

// ── Pure Rust SQL builders (testable without GC) ─────────────────────

/// A column definition as SQL: `name:TYPE` or `name:TYPE:CONSTRAINTS`
/// with the name quoted and the rest verbatim; an entry without a colon is
/// SQL already (a table constraint, or a column written out).
fn column_def_sql(def: &str) -> String {
    match def.splitn(3, ':').collect::<Vec<_>>()[..] {
        [name, sql_type, constraints] => {
            format!("{} {sql_type} {constraints}", quote_ident(name))
        }
        [name, sql_type] => format!("{} {sql_type}", quote_ident(name)),
        _ => def.to_string(),
    }
}

/// Build CREATE TABLE SQL from table name and column definitions.
///
/// Each column entry is colon-separated: `"name:TYPE:CONSTRAINTS"` (3 parts)
/// or `"name:TYPE"` (2 parts). Column names are quoted; types and constraints
/// are passed through verbatim.
///
/// Example: `["id:UUID:PRIMARY KEY", "name:TEXT:NOT NULL", "age:BIGINT"]`
/// produces: `CREATE TABLE IF NOT EXISTS "t" ("id" UUID PRIMARY KEY, "name" TEXT NOT NULL, "age" BIGINT)`
pub(crate) fn build_create_table_sql(table: &str, columns: &[String]) -> String {
    let col_defs: Vec<String> = columns.iter().map(|c| column_def_sql(c)).collect();
    format!(
        "CREATE TABLE IF NOT EXISTS {} ({})",
        quote_name(table),
        col_defs.join(", ")
    )
}

/// Build DROP TABLE SQL.
pub(crate) fn build_drop_table_sql(table: &str) -> String {
    format!("DROP TABLE IF EXISTS {}", quote_name(table))
}

/// Build ADD COLUMN SQL from table name and column definition.
///
/// Column definition uses same colon encoding as create_table.
pub(crate) fn build_add_column_sql(table: &str, column_def: &str) -> String {
    format!(
        "ALTER TABLE {} ADD COLUMN IF NOT EXISTS {}",
        quote_name(table),
        column_def_sql(column_def)
    )
}

/// Build DROP COLUMN SQL.
pub(crate) fn build_drop_column_sql(table: &str, column: &str) -> String {
    format!(
        "ALTER TABLE {} DROP COLUMN IF EXISTS {}",
        quote_name(table),
        quote_ident(column)
    )
}

/// Build RENAME COLUMN SQL.
pub(crate) fn build_rename_column_sql(table: &str, old_name: &str, new_name: &str) -> String {
    format!(
        "ALTER TABLE {} RENAME COLUMN {} TO {}",
        quote_name(table),
        quote_ident(old_name),
        quote_ident(new_name)
    )
}

/// Build CREATE INDEX SQL.
///
/// Options is a string with space-separated key:value pairs:
/// - `unique:true` -- creates a UNIQUE index
/// - `name:idx_name` -- preserves the exact index name instead of deriving one
/// - `where:condition` -- adds a WHERE clause for partial index
///
/// Each column may optionally end with `:ASC` or `:DESC`. The neutral parser
/// intentionally rejects any other suffix so PostgreSQL-specific features like
/// opclasses stay behind explicit `Pg.*` helpers.
#[derive(Debug, Default, PartialEq, Eq)]
struct CreateIndexOptions {
    is_unique: bool,
    name: Option<String>,
    where_clause: Option<String>,
}

#[derive(Debug, PartialEq, Eq)]
struct IndexColumnSpec {
    name: String,
    direction: Option<&'static str>,
}

fn parse_create_index_options(options: &str) -> Result<CreateIndexOptions, String> {
    let trimmed = options.trim();
    if trimmed.is_empty() {
        return Ok(CreateIndexOptions::default());
    }

    let (head, where_clause) = if let Some(where_start) = trimmed.find("where:") {
        (
            trimmed[..where_start].trim_end(),
            Some(trimmed[where_start + 6..].trim().to_string()),
        )
    } else {
        (trimmed, None)
    };

    let mut parsed = CreateIndexOptions {
        where_clause,
        ..CreateIndexOptions::default()
    };

    for token in head.split_whitespace() {
        let Some((key, value)) = token.split_once(':') else {
            return Err(format!(
                "Migration.create_index options: invalid token `{token}`"
            ));
        };
        match key {
            "unique" => match value {
                "true" => parsed.is_unique = true,
                "false" => parsed.is_unique = false,
                _ => {
                    return Err(format!(
                        "Migration.create_index options: unique must be `true` or `false`, got `{value}`"
                    ));
                }
            },
            "name" => {
                if value.trim().is_empty() {
                    return Err(
                        "Migration.create_index options: name must not be empty".to_string()
                    );
                }
                parsed.name = Some(value.trim().to_string());
            }
            other => {
                return Err(format!(
                    "Migration.create_index options: unsupported option `{other}`"
                ));
            }
        }
    }

    if matches!(parsed.where_clause.as_deref(), Some("")) {
        return Err("Migration.create_index options: where clause must not be empty".to_string());
    }

    Ok(parsed)
}

/// A table name's schema (if it is qualified: `audit.events`) and its
/// name in that schema.
fn schema_and_table(table: &str) -> (Option<&str>, &str) {
    match table.rsplit_once('.') {
        Some((schema, name)) => (Some(schema), name),
        None => (None, table),
    }
}

/// One index column, `name` or `name:ASC`/`name:DESC`; `helper` names the
/// Migration function for the error.
fn parse_index_column(column: &str, helper: &str) -> Result<IndexColumnSpec, String> {
    let trimmed = column.trim();
    let empty = || format!("{helper} columns: column name must not be empty");
    if trimmed.is_empty() {
        return Err(empty());
    }

    if let Some((name, suffix)) = trimmed.rsplit_once(':') {
        let name = name.trim();
        let suffix = suffix.trim();
        let direction = if suffix.eq_ignore_ascii_case("ASC") {
            Some("ASC")
        } else if suffix.eq_ignore_ascii_case("DESC") {
            Some("DESC")
        } else {
            None
        };

        if let Some(direction) = direction {
            if name.is_empty() {
                return Err(empty());
            }
            return Ok(IndexColumnSpec {
                name: name.to_string(),
                direction: Some(direction),
            });
        }

        return Err(format!(
            "{helper} columns: `{trimmed}` only supports :ASC or :DESC order suffixes"
        ));
    }

    Ok(IndexColumnSpec {
        name: trimmed.to_string(),
        direction: None,
    })
}

/// An index's columns, parsed, with the name `create_index` derives from
/// them and `drop_index` drops by: `idx_{table}_{col1}_{col2}`, the column
/// names without their order suffixes.
fn index_columns(
    table: &str,
    columns: &[String],
    helper: &str,
) -> Result<(Vec<IndexColumnSpec>, String), String> {
    let parsed: Vec<IndexColumnSpec> = columns
        .iter()
        .map(|column| parse_index_column(column, helper))
        .collect::<Result<_, _>>()?;
    if parsed.is_empty() {
        return Err(format!("{helper} columns: at least one column is required"));
    }
    let names: Vec<&str> = parsed.iter().map(|column| column.name.as_str()).collect();
    let (_, bare_table) = schema_and_table(table);
    let derived = format!("idx_{bare_table}_{}", names.join("_"));
    Ok((parsed, derived))
}

pub(crate) fn build_create_index_sql(
    table: &str,
    columns: &[String],
    options: &str,
) -> Result<String, String> {
    let parsed_options = parse_create_index_options(options)?;
    let (parsed_columns, derived_name) = index_columns(table, columns, "Migration.create_index")?;
    let index_name = parsed_options.name.unwrap_or(derived_name);

    let mut sql = String::new();
    sql.push_str("CREATE ");
    if parsed_options.is_unique {
        sql.push_str("UNIQUE ");
    }
    sql.push_str("INDEX IF NOT EXISTS ");
    sql.push_str(&quote_ident(&index_name));
    sql.push_str(" ON ");
    sql.push_str(&quote_name(table));
    sql.push_str(" (");
    let rendered_columns: Vec<String> = parsed_columns
        .iter()
        .map(|column| match column.direction {
            Some(direction) => format!("{} {}", quote_ident(&column.name), direction),
            None => quote_ident(&column.name),
        })
        .collect();
    sql.push_str(&rendered_columns.join(", "));
    sql.push(')');

    if let Some(where_clause) = parsed_options.where_clause {
        sql.push_str(" WHERE ");
        sql.push_str(&where_clause);
    }

    Ok(sql)
}

/// Build DROP INDEX SQL for the index `create_index` made on `columns`
/// (its derived name).
pub(crate) fn build_drop_index_sql(table: &str, columns: &[String]) -> Result<String, String> {
    let (_, index_name) = index_columns(table, columns, "Migration.drop_index")?;
    // The index lives in its table's schema.
    let index = match schema_and_table(table) {
        (Some(schema), _) => format!("{}.{}", quote_name(schema), quote_ident(&index_name)),
        (None, _) => quote_ident(&index_name),
    };
    Ok(format!("DROP INDEX IF EXISTS {index}"))
}

// ── Extern C wrappers ───────────────────────────────────────────────
//
// Each takes a pool handle and Mesh strings or `List<String>`s, and
// returns `Pool.execute`'s `Result<Int, String>` for its DDL, or the error
// that kept the DDL from being built.

/// Create a table with the given column definitions (a `List<String>` of
/// colon-separated definitions).
#[no_mangle]
pub extern "C" fn mesh_migration_create_table(
    pool: u64,
    table: *const MeshString,
    columns: *mut u8,
) -> *mut u8 {
    unsafe {
        let sql = build_create_table_sql(text_of(table), &list_strings(columns));
        execute_ddl(pool, Ok(sql))
    }
}

/// Drop a table.
#[no_mangle]
pub extern "C" fn mesh_migration_drop_table(pool: u64, table: *const MeshString) -> *mut u8 {
    unsafe { execute_ddl(pool, Ok(build_drop_table_sql(text_of(table)))) }
}

/// Add a column to an existing table.
#[no_mangle]
pub extern "C" fn mesh_migration_add_column(
    pool: u64,
    table: *const MeshString,
    column_def: *const MeshString,
) -> *mut u8 {
    unsafe {
        let sql = build_add_column_sql(text_of(table), text_of(column_def));
        execute_ddl(pool, Ok(sql))
    }
}

/// Drop a column from an existing table.
#[no_mangle]
pub extern "C" fn mesh_migration_drop_column(
    pool: u64,
    table: *const MeshString,
    column: *const MeshString,
) -> *mut u8 {
    unsafe {
        let sql = build_drop_column_sql(text_of(table), text_of(column));
        execute_ddl(pool, Ok(sql))
    }
}

/// Rename a column in an existing table.
#[no_mangle]
pub extern "C" fn mesh_migration_rename_column(
    pool: u64,
    table: *const MeshString,
    old_name: *const MeshString,
    new_name: *const MeshString,
) -> *mut u8 {
    unsafe {
        let sql = build_rename_column_sql(text_of(table), text_of(old_name), text_of(new_name));
        execute_ddl(pool, Ok(sql))
    }
}

/// Create an index on the given columns.
///
/// Options: `"unique:true"` for unique index, `"where:condition"` for partial.
#[no_mangle]
pub extern "C" fn mesh_migration_create_index(
    pool: u64,
    table: *const MeshString,
    columns: *mut u8,
    options: *const MeshString,
) -> *mut u8 {
    unsafe {
        let sql = build_create_index_sql(text_of(table), &list_strings(columns), text_of(options));
        execute_ddl(pool, sql)
    }
}

/// Drop an index (derived name: idx_{table}_{col1}_{col2}).
#[no_mangle]
pub extern "C" fn mesh_migration_drop_index(
    pool: u64,
    table: *const MeshString,
    columns: *mut u8,
) -> *mut u8 {
    unsafe {
        execute_ddl(
            pool,
            build_drop_index_sql(text_of(table), &list_strings(columns)),
        )
    }
}

/// Execute raw SQL (escape hatch for operations not covered by the DSL).
#[no_mangle]
pub extern "C" fn mesh_migration_execute(pool: u64, sql: *const MeshString) -> *mut u8 {
    mesh_pool_execute(pool, sql, mesh_list_new())
}

// ── Unit tests ───────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    /// An index's options and columns are refused for what is wrong with
    /// them, before any SQL is built.
    #[test]
    fn index_options_and_columns_are_refused_for_what_is_wrong() {
        let columns = ["name".to_string()];
        for (options, error) in [
            ("fast", "invalid token `fast`"),
            (
                "unique:maybe",
                "unique must be `true` or `false`, got `maybe`",
            ),
            ("name:", "name must not be empty"),
            ("fast:yes", "unsupported option `fast`"),
            ("where:  ", "where clause must not be empty"),
        ] {
            let refused = build_create_index_sql("t", &columns, options).unwrap_err();
            assert!(refused.ends_with(error), "{options}: {refused}");
        }
        assert_eq!(
            build_create_index_sql("t", &columns, "unique:false name:by_name where:x > 1"),
            Ok(
                "CREATE INDEX IF NOT EXISTS \"by_name\" ON \"t\" (\"name\") WHERE x > 1"
                    .to_string()
            )
        );
        for (column, error) in [
            (" ", "column name must not be empty"),
            (":DESC", "column name must not be empty"),
            (
                "name:UP",
                "`name:UP` only supports :ASC or :DESC order suffixes",
            ),
        ] {
            let refused = build_create_index_sql("t", &[column.to_string()], "").unwrap_err();
            assert!(refused.ends_with(error), "{column}: {refused}");
        }
        assert!(build_create_index_sql("t", &[], "").is_err());
    }

    #[test]
    fn test_build_create_table_sql() {
        let sql = build_create_table_sql(
            "users",
            &[
                "id:UUID:PRIMARY KEY".to_string(),
                "name:TEXT:NOT NULL".to_string(),
                "age:BIGINT".to_string(),
            ],
        );
        assert_eq!(
            sql,
            "CREATE TABLE IF NOT EXISTS \"users\" (\"id\" UUID PRIMARY KEY, \"name\" TEXT NOT NULL, \"age\" BIGINT)"
        );
    }

    #[test]
    fn test_build_create_table_sql_two_part_columns() {
        let sql = build_create_table_sql(
            "posts",
            &["id:SERIAL".to_string(), "title:TEXT".to_string()],
        );
        assert_eq!(
            sql,
            "CREATE TABLE IF NOT EXISTS \"posts\" (\"id\" SERIAL, \"title\" TEXT)"
        );
    }

    #[test]
    fn test_build_drop_table_sql() {
        let sql = build_drop_table_sql("users");
        assert_eq!(sql, "DROP TABLE IF EXISTS \"users\"");
    }

    #[test]
    fn test_build_add_column_sql() {
        let sql = build_add_column_sql("users", "age:BIGINT:NOT NULL DEFAULT 0");
        assert_eq!(
            sql,
            "ALTER TABLE \"users\" ADD COLUMN IF NOT EXISTS \"age\" BIGINT NOT NULL DEFAULT 0"
        );
    }

    #[test]
    fn test_build_add_column_sql_two_part() {
        let sql = build_add_column_sql("users", "bio:TEXT");
        assert_eq!(
            sql,
            "ALTER TABLE \"users\" ADD COLUMN IF NOT EXISTS \"bio\" TEXT"
        );
    }

    /// A table name may be schema-qualified, as `Repo` and `Query` read it:
    /// Migration made a table literally named "audit.events" in the current
    /// schema, which they then could not find. An index lives in its
    /// table's schema, and is named for the table alone.
    #[test]
    fn a_qualified_table_is_its_schema_and_name() {
        let table = "audit.events";
        let events = "\"audit\".\"events\"";
        assert_eq!(
            build_create_table_sql(table, &["id:INT".into()]),
            format!("CREATE TABLE IF NOT EXISTS {events} (\"id\" INT)")
        );
        assert_eq!(
            build_drop_table_sql(table),
            format!("DROP TABLE IF EXISTS {events}")
        );
        assert_eq!(
            build_add_column_sql(table, "at:DATE"),
            format!("ALTER TABLE {events} ADD COLUMN IF NOT EXISTS \"at\" DATE")
        );
        assert_eq!(
            build_drop_column_sql(table, "at"),
            format!("ALTER TABLE {events} DROP COLUMN IF EXISTS \"at\"")
        );
        assert_eq!(
            build_rename_column_sql(table, "a", "b"),
            format!("ALTER TABLE {events} RENAME COLUMN \"a\" TO \"b\"")
        );
        assert_eq!(
            build_create_index_sql(table, &["at".into()], "").unwrap(),
            format!("CREATE INDEX IF NOT EXISTS \"idx_events_at\" ON {events} (\"at\")")
        );
        assert_eq!(
            build_drop_index_sql(table, &["at".into()]).unwrap(),
            "DROP INDEX IF EXISTS \"audit\".\"idx_events_at\""
        );
    }

    /// A definition written as SQL (no colon) is added if absent too, as
    /// the docs say add_column does: it lost the IF NOT EXISTS.
    #[test]
    fn add_column_written_as_sql_is_added_if_absent() {
        assert_eq!(
            build_add_column_sql("users", "age INT NOT NULL DEFAULT 0"),
            "ALTER TABLE \"users\" ADD COLUMN IF NOT EXISTS age INT NOT NULL DEFAULT 0"
        );
    }

    #[test]
    fn test_build_drop_column_sql() {
        let sql = build_drop_column_sql("users", "age");
        assert_eq!(sql, "ALTER TABLE \"users\" DROP COLUMN IF EXISTS \"age\"");
    }

    #[test]
    fn test_build_rename_column_sql() {
        let sql = build_rename_column_sql("users", "name", "full_name");
        assert_eq!(
            sql,
            "ALTER TABLE \"users\" RENAME COLUMN \"name\" TO \"full_name\""
        );
    }

    #[test]
    fn test_build_create_index_sql() {
        let sql = build_create_index_sql("users", &["email".to_string()], "")
            .expect("plain index SQL should build");
        assert_eq!(
            sql,
            "CREATE INDEX IF NOT EXISTS \"idx_users_email\" ON \"users\" (\"email\")"
        );
    }

    #[test]
    fn test_build_create_index_sql_unique() {
        let sql = build_create_index_sql("users", &["email".to_string()], "unique:true")
            .expect("unique index SQL should build");
        assert_eq!(
            sql,
            "CREATE UNIQUE INDEX IF NOT EXISTS \"idx_users_email\" ON \"users\" (\"email\")"
        );
    }

    #[test]
    fn test_build_create_index_sql_multi_column() {
        let sql =
            build_create_index_sql("orders", &["user_id".to_string(), "status".to_string()], "")
                .expect("multi-column index SQL should build");
        assert_eq!(
            sql,
            "CREATE INDEX IF NOT EXISTS \"idx_orders_user_id_status\" ON \"orders\" (\"user_id\", \"status\")"
        );
    }

    #[test]
    fn test_build_create_index_sql_partial() {
        let sql = build_create_index_sql(
            "users",
            &["email".to_string()],
            "unique:true where:active = true",
        )
        .expect("partial index SQL should build");
        assert_eq!(
            sql,
            "CREATE UNIQUE INDEX IF NOT EXISTS \"idx_users_email\" ON \"users\" (\"email\") WHERE active = true"
        );
    }

    #[test]
    fn test_build_create_index_sql_preserves_exact_name_and_ordered_columns() {
        let sql = build_create_index_sql(
            "issues",
            &["project_id".to_string(), "last_seen:DESC".to_string()],
            "name:idx_issues_project_last_seen where:status = 'open'",
        )
        .expect("ordered named index SQL should build");
        assert_eq!(
            sql,
            "CREATE INDEX IF NOT EXISTS \"idx_issues_project_last_seen\" ON \"issues\" (\"project_id\", \"last_seen\" DESC) WHERE status = 'open'"
        );
    }

    #[test]
    fn test_build_create_index_sql_rejects_pg_only_column_suffixes() {
        let err = build_create_index_sql("events", &["tags:jsonb_path_ops".to_string()], "")
            .expect_err("PG-only opclass syntax must stay out of Migration.create_index");
        assert_eq!(
            err,
            "Migration.create_index columns: `tags:jsonb_path_ops` only supports :ASC or :DESC order suffixes"
        );
    }

    #[test]
    fn test_build_create_index_sql_rejects_unsupported_options() {
        let err = build_create_index_sql("events", &["tags".to_string()], "using:gin")
            .expect_err("PG-only index method options must stay out of Migration.create_index");
        assert_eq!(
            err,
            "Migration.create_index options: unsupported option `using`"
        );
    }

    #[test]
    fn test_build_drop_index_sql() {
        let sql = build_drop_index_sql("users", &["email".to_string()]).unwrap();
        assert_eq!(sql, "DROP INDEX IF EXISTS \"idx_users_email\"");
    }

    #[test]
    fn test_build_drop_index_sql_multi_column() {
        let sql =
            build_drop_index_sql("orders", &["user_id".to_string(), "status".to_string()]).unwrap();
        assert_eq!(sql, "DROP INDEX IF EXISTS \"idx_orders_user_id_status\"");
    }

    /// `drop_index` given the columns `create_index` was drops the index it
    /// made: an order suffix or spaces are no part of the derived name.
    #[test]
    fn drop_index_derives_the_name_create_index_did() {
        let columns = ["name:DESC".to_string(), " age ".to_string()];
        let created = build_create_index_sql("people", &columns, "").unwrap();
        assert_eq!(
            created,
            "CREATE INDEX IF NOT EXISTS \"idx_people_name_age\" ON \"people\" (\"name\" DESC, \"age\")"
        );
        assert_eq!(
            build_drop_index_sql("people", &columns).unwrap(),
            "DROP INDEX IF EXISTS \"idx_people_name_age\""
        );
        assert_eq!(
            build_drop_index_sql("people", &["name:UP".to_string()]).unwrap_err(),
            "Migration.drop_index columns: `name:UP` only supports :ASC or :DESC order suffixes"
        );
    }

    #[test]
    fn test_quote_ident_with_double_quotes() {
        // Table name with embedded double quote should be escaped
        let sql = build_drop_table_sql("my\"table");
        assert_eq!(sql, "DROP TABLE IF EXISTS \"my\"\"table\"");
    }
}
