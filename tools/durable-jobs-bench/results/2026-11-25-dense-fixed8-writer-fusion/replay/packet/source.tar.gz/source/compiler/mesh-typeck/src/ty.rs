//! Type representation for the Mesh type system.
//!
//! Defines the core `Ty` enum, type constructors (`TyCon`), type variables
//! (`TyVar`), and polymorphic type schemes (`Scheme`). These form the
//! foundation of Hindley-Milner type inference.

use std::collections::HashMap;
use std::fmt;
use std::sync::Arc;

/// A type variable, identified by a `u32` index into the unification table.
///
/// Type variables are created during inference and unified with concrete types
/// or other variables. The `ena` crate handles the union-find mechanics.
#[derive(Copy, Clone, Debug, PartialEq, Eq, Hash)]
pub struct TyVar(pub u32);

/// A type constructor -- a named type like `Int`, `String`, `Option`, etc.
///
/// Type constructors are identified by name. They can be nullary (e.g. `Int`)
/// or parameterized (e.g. `Option` with arity 1, `Result` with arity 2).
///
/// The `display_prefix` field is used ONLY for display in error messages
/// (e.g., "Geometry.Point"). It is intentionally excluded from `PartialEq`
/// to preserve type identity semantics.
#[derive(Clone, Debug)]
pub struct TyCon {
    pub name: String,
    /// Module origin for display in error messages (e.g., "Geometry").
    /// NOT used for type identity or codegen. Only affects Display output.
    pub display_prefix: Option<Box<str>>,
    /// Identity of an indexed nominal's defining module. The thin handle
    /// keeps ordinary types as small as they were before indexed nominals.
    pub indexed_origin: Option<Arc<String>>,
}

impl PartialEq for TyCon {
    fn eq(&self, other: &Self) -> bool {
        self.name == other.name && self.indexed_origin == other.indexed_origin
    }
}

impl Eq for TyCon {}

impl TyCon {
    pub fn new(name: impl Into<String>) -> Self {
        TyCon {
            name: name.into(),
            display_prefix: None,
            indexed_origin: None,
        }
    }

    pub fn with_module(name: impl Into<String>, module: impl Into<String>) -> Self {
        TyCon {
            name: name.into(),
            display_prefix: Some(module.into().into_boxed_str()),
            indexed_origin: None,
        }
    }

    pub(crate) fn indexed(name: &str, origin: &str) -> Self {
        Self {
            name: name.into(),
            display_prefix: None,
            indexed_origin: Some(Arc::new(origin.into())),
        }
    }
}

impl fmt::Display for TyCon {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(name) = crate::proof_values::display_head(&self.name) {
            return f.write_str(name);
        }
        let prefix = self.display_prefix.as_deref().or_else(|| {
            self.indexed_origin
                .as_deref()
                .map(String::as_str)
                .filter(|origin| !origin.is_empty())
        });
        if let Some(prefix) = prefix {
            write!(f, "{}.{}", prefix, self.name)
        } else {
            write!(f, "{}", self.name)
        }
    }
}

/// A Mesh type.
///
/// Represents all possible types in the Mesh type system:
/// - `Var`: an inference variable (to be resolved by unification)
/// - `Con`: a concrete type constructor (Int, String, Bool, ...)
/// - `Fun`: a function type (params -> return)
/// - `App`: a type constructor application (Option<Int>, Result<T, E>)
/// - `Tuple`: a tuple type (Int, String)
/// - `Never`: the bottom type (never returns)
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Ty {
    /// A type variable (unresolved during inference).
    Var(TyVar),
    /// A kind-Nat term, admitted only in a declared index position.
    Nat(NatIndex),
    /// A concrete type constructor.
    Con(TyCon),
    /// A function type: `(param_types) -> return_type`.
    Fun(Vec<Ty>, Box<Ty>),
    /// A type constructor applied to arguments: `Option<Int>`, `Result<T, E>`.
    App(Box<Ty>, Vec<Ty>),
    /// A tuple type: `(Int, String, Bool)`.
    Tuple(Vec<Ty>),
    /// The bottom/never type -- the type of expressions that never return.
    Never,
}

/// The first indexed nominal slice admits natural literals and successors
/// of a natural literal or variable.
#[derive(Clone, Debug, PartialEq, Eq, Hash)]
pub enum NatIndex {
    Literal(u64),
    Variable(TyVar),
    /// A named parameter in a constructor template or an annotation before
    /// the corresponding inference variable is installed.
    Parameter(String),
    Succ(Box<NatIndex>),
}

impl NatIndex {
    pub(crate) fn successor(self) -> Self {
        if let Self::Literal(value) = self {
            if let Some(value) = value.checked_add(1) {
                return Self::Literal(value);
            }
        }
        Self::Succ(Box::new(self))
    }

    pub fn predecessor(&self) -> Option<Self> {
        match self {
            Self::Literal(n) => n.checked_sub(1).map(Self::Literal),
            Self::Succ(inner) => Some(*inner.clone()),
            _ => None,
        }
    }

    pub(crate) fn leaf(&self) -> &Self {
        match self {
            Self::Succ(inner) => inner.leaf(),
            leaf => leaf,
        }
    }

    pub fn map_leaf(&self, f: impl FnOnce(&Self) -> Self) -> Self {
        match self {
            Self::Succ(inner) => inner.map_leaf(f).successor(),
            leaf => f(leaf),
        }
    }
}

impl fmt::Display for NatIndex {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Literal(value) => write!(f, "{value}"),
            Self::Variable(var) => write!(f, "?{}", var.0),
            Self::Parameter(name) => write!(f, "{name}"),
            Self::Succ(inner) => write!(f, "Succ<{inner}>"),
        }
    }
}

impl Ty {
    /// The types this one is built from, in order: a function's parameters
    /// and then its result, an application's constructor and then its
    /// arguments, a tuple's elements.
    pub fn parts(&self) -> impl Iterator<Item = &Ty> {
        let (first, middle, last): (Option<&Ty>, &[Ty], Option<&Ty>) = match self {
            Ty::Fun(params, ret) => (None, params, Some(ret)),
            Ty::App(con, args) => (Some(con), args, None),
            Ty::Tuple(elems) => (None, elems, None),
            Ty::Var(_) | Ty::Nat(_) | Ty::Con(_) | Ty::Never => (None, &[], None),
        };
        first.into_iter().chain(middle).chain(last)
    }

    /// This type with each of its `parts` replaced by `f` of it.
    pub fn map_parts(&self, mut f: impl FnMut(&Ty) -> Ty) -> Ty {
        match self {
            Ty::Fun(params, ret) => Ty::Fun(params.iter().map(&mut f).collect(), Box::new(f(ret))),
            Ty::App(con, args) => Ty::App(Box::new(f(con)), args.iter().map(f).collect()),
            Ty::Tuple(elems) => Ty::Tuple(elems.iter().map(f).collect()),
            Ty::Var(_) | Ty::Nat(_) | Ty::Con(_) | Ty::Never => self.clone(),
        }
    }

    /// The type constructor this type is, or applies: `Int` for `Int`,
    /// `List` for `List<Int>`.
    pub fn con(&self) -> Option<&TyCon> {
        match self {
            Ty::Con(c) => Some(c),
            Ty::App(con, _) => con.con(),
            _ => None,
        }
    }

    /// The name of the type constructor this type is, or applies.
    pub fn con_name(&self) -> Option<&str> {
        self.con().map(|c| c.name.as_str())
    }

    pub(crate) fn assign_indexed_origin(&mut self, origin: &str) {
        match self {
            Ty::Con(con) if con.indexed_origin.as_deref().is_some_and(String::is_empty) => {
                *con = TyCon::indexed(&con.name, origin);
            }
            Ty::App(con, args) | Ty::Fun(args, con) => {
                con.assign_indexed_origin(origin);
                for arg in args {
                    arg.assign_indexed_origin(origin);
                }
            }
            Ty::Tuple(args) => {
                for arg in args {
                    arg.assign_indexed_origin(origin);
                }
            }
            _ => {}
        }
    }

    /// The arguments of this type if it is the constructor `name` applied to
    /// them: `[Int]` for `Option<Int>` and "Option".
    pub fn args_of(&self, name: &str) -> Option<&[Ty]> {
        match self {
            Ty::App(con, args) if matches!(con.as_ref(), Ty::Con(c) if c.name == name) => {
                Some(args)
            }
            _ => None,
        }
    }

    /// This type with each constructor `replace` gives a type for replaced.
    pub fn replace_cons(&self, replace: &mut dyn FnMut(&TyCon) -> Option<Ty>) -> Ty {
        match self {
            Ty::Con(con) => replace(con).unwrap_or_else(|| self.clone()),
            Ty::Nat(index) => Ty::Nat(index.map_leaf(|leaf| {
                if let NatIndex::Parameter(name) = leaf {
                    if let Some(Ty::Nat(replacement)) = replace(&TyCon::new(name)) {
                        return replacement;
                    }
                }
                leaf.clone()
            })),
            _ => self.map_parts(|part| part.replace_cons(replace)),
        }
    }

    /// The type with its variables named `a`, `b`, ... in the order they
    /// first appear, as a reader writes a generic type: `(a) -> a`, not
    /// `(?9) -> ?9`.
    pub fn with_named_vars(&self) -> Ty {
        name_vars(self, &mut Vec::new())
    }

    /// The types with their variables named as `with_named_vars` names one
    /// type's, across all of them: a variable keeps its name in each.
    pub fn with_named_vars_across<'a>(types: impl IntoIterator<Item = &'a Ty>) -> Vec<Ty> {
        let mut seen = Vec::new();
        types
            .into_iter()
            .map(|ty| name_vars(ty, &mut seen))
            .collect()
    }

    /// This type as a diagnostic shows it: the parts inference has not
    /// determined (`?9`) as `_`.
    pub fn with_holes(&self) -> Ty {
        match self {
            Ty::Var(_) => Ty::Con(TyCon::new("_")),
            Ty::Nat(index) => Ty::Nat(index.map_leaf(|leaf| match leaf {
                NatIndex::Variable(_) => NatIndex::Parameter("_".into()),
                _ => leaf.clone(),
            })),
            _ => self.map_parts(Ty::with_holes),
        }
    }

    /// Create an `Int` type.
    pub fn int() -> Ty {
        Ty::Con(TyCon::new("Int"))
    }

    /// Create a `Float` type.
    pub fn float() -> Ty {
        Ty::Con(TyCon::new("Float"))
    }

    /// Create a `String` type.
    pub fn string() -> Ty {
        Ty::Con(TyCon::new("String"))
    }

    /// Create an opaque binary `Bytes` type.
    pub fn bytes() -> Ty {
        Ty::Con(TyCon::new("Bytes"))
    }

    pub fn db_value() -> Ty {
        Ty::Con(TyCon::new("DbValue"))
    }

    pub fn bytes_error() -> Ty {
        Ty::Con(TyCon::new("BytesError"))
    }

    pub fn binary_error() -> Ty {
        Ty::Con(TyCon::new("BinaryError"))
    }

    pub fn bytes_builder() -> Ty {
        Ty::Con(TyCon::new("BytesBuilder"))
    }

    pub fn secret_bytes() -> Ty {
        Ty::Con(TyCon::new("SecretBytes"))
    }

    /// `Plaintext<T>`: message content, which leaves only through a seal,
    /// an `@display` export or `declassify` (see `plaintext.rs`).
    pub fn plaintext(inner: Ty) -> Ty {
        Ty::App(Box::new(Ty::Con(TyCon::new(PLAINTEXT))), vec![inner])
    }

    pub fn secret_map() -> Ty {
        Ty::Con(TyCon::new("SecretMap"))
    }

    pub fn storage_key() -> Ty {
        Ty::Con(TyCon::new("StorageKey"))
    }

    pub fn crypto_error() -> Ty {
        Ty::Con(TyCon::new("CryptoError"))
    }

    pub fn x25519_private_key() -> Ty {
        Ty::Con(TyCon::new("X25519PrivateKey"))
    }

    pub fn x25519_public_key() -> Ty {
        Ty::Con(TyCon::new("X25519PublicKey"))
    }

    pub fn x25519_key_pair() -> Ty {
        Ty::Con(TyCon::new("X25519KeyPair"))
    }

    pub fn mlkem_private_key() -> Ty {
        Ty::Con(TyCon::new("MlKemPrivateKey"))
    }

    pub fn mlkem_public_key() -> Ty {
        Ty::Con(TyCon::new("MlKemPublicKey"))
    }

    pub fn mlkem_ciphertext() -> Ty {
        Ty::Con(TyCon::new("MlKemCiphertext"))
    }

    pub fn mlkem_key_pair() -> Ty {
        Ty::Con(TyCon::new("MlKemKeyPair"))
    }

    pub fn blind_rsa_secret_key() -> Ty {
        Ty::Con(TyCon::new("BlindRsaSecretKey"))
    }

    pub fn blind_rsa_blinding_state() -> Ty {
        Ty::Con(TyCon::new("BlindRsaBlindingState"))
    }

    pub fn blind_rsa_public_key() -> Ty {
        Ty::Con(TyCon::new("BlindRsaPublicKey"))
    }

    pub fn blind_rsa_blinded() -> Ty {
        Ty::Con(TyCon::new("BlindRsaBlinded"))
    }

    pub fn signing_private_key() -> Ty {
        Ty::Con(TyCon::new("SigningPrivateKey"))
    }

    pub fn signing_public_key() -> Ty {
        Ty::Con(TyCon::new("SigningPublicKey"))
    }

    pub fn signature() -> Ty {
        Ty::Con(TyCon::new("Signature"))
    }

    pub fn signing_key_pair() -> Ty {
        Ty::Con(TyCon::new("SigningKeyPair"))
    }

    pub fn aead_key() -> Ty {
        Ty::Con(TyCon::new("AeadKey"))
    }

    pub fn u64() -> Ty {
        Ty::Con(TyCon::new("U64"))
    }

    pub fn u128() -> Ty {
        Ty::Con(TyCon::new("U128"))
    }

    pub fn i128() -> Ty {
        Ty::Con(TyCon::new("I128"))
    }

    /// Create a `Json` newtype.
    ///
    /// Json auto-coerces to String at call sites (the unify function handles this).
    /// Codegen detects the "Json" name to decide how to serialize the value.
    pub fn json() -> Ty {
        Ty::Con(TyCon::new("Json"))
    }

    /// Create a `Bool` type.
    pub fn bool() -> Ty {
        Ty::Con(TyCon::new("Bool"))
    }

    /// Whether any inference variable occurs in this type.
    pub fn has_type_vars(&self) -> bool {
        self.variable().is_some() || self.parts().any(Ty::has_type_vars)
    }

    /// The variable of this leaf type or Nat term, if present.
    pub(crate) fn variable(&self) -> Option<TyVar> {
        match self {
            Ty::Var(var) => Some(*var),
            Ty::Nat(index) => match index.leaf() {
                NatIndex::Variable(var) => Some(*var),
                _ => None,
            },
            _ => None,
        }
    }

    /// Create an `Option<T>` type.
    pub fn option(inner: Ty) -> Ty {
        Ty::App(Box::new(Ty::Con(TyCon::new("Option"))), vec![inner])
    }

    /// Create a `Result<T, E>` type.
    pub fn result(ok: Ty, err: Ty) -> Ty {
        Ty::App(Box::new(Ty::Con(TyCon::new("Result"))), vec![ok, err])
    }

    /// A tuple known only by its first elements: `elems`, then whatever
    /// `tail` stands for -- a type variable, or once it is known the tuple of
    /// the remaining elements. It is what `Tuple.first(p)` can say about a `p`
    /// whose type inference has not reached yet, such as an unannotated
    /// parameter: a tuple of at least one element. `InferCtx::resolve` turns a
    /// row whose tail is known into the plain tuple.
    pub fn tuple_row(mut elems: Vec<Ty>, tail: Ty) -> Ty {
        elems.push(tail);
        Ty::App(Box::new(Ty::Con(TyCon::new(TUPLE_ROW))), elems)
    }

    /// The leading elements and the tail of a `tuple_row`.
    pub fn as_tuple_row(&self) -> Option<(&[Ty], &Ty)> {
        match self {
            Ty::App(con, args) if matches!(con.as_ref(), Ty::Con(c) if c.name == TUPLE_ROW) => {
                let (tail, elems) = args.split_last()?;
                Some((elems, tail))
            }
            _ => None,
        }
    }

    /// A row whose tail is known, as the tuple (or longer row) it stands for.
    pub fn normalize_tuple_row(self) -> Ty {
        let Some((elems, tail)) = self.as_tuple_row() else {
            return self;
        };
        let mut all = elems.to_vec();
        match tail {
            Ty::Tuple(rest) => {
                all.extend(rest.iter().cloned());
                Ty::Tuple(all)
            }
            row => match row.as_tuple_row() {
                Some((more, tail)) => {
                    all.extend(more.iter().cloned());
                    Ty::tuple_row(all, tail.clone())
                }
                None => self,
            },
        }
    }

    /// Create a function type.
    pub fn fun(params: Vec<Ty>, ret: Ty) -> Ty {
        Ty::Fun(params, Box::new(ret))
    }

    /// Create a typed `Pid<M>` type (actor identity with message type M).
    pub fn pid(msg_type: Ty) -> Ty {
        Ty::App(Box::new(Ty::Con(TyCon::new("Pid"))), vec![msg_type])
    }

    /// Create an untyped `Pid` (escape hatch -- accepts any message at runtime).
    pub fn untyped_pid() -> Ty {
        Ty::Con(TyCon::new("Pid"))
    }

    /// Create a `List<T>` type.
    /// `Iter<T>`: a lazy iterator over `T`s (`Iter.from`, `Iter.map`, ...).
    pub fn iter(elem: Ty) -> Ty {
        Ty::App(Box::new(Ty::Con(TyCon::new("Iter"))), vec![elem])
    }

    pub fn list(inner: Ty) -> Ty {
        Ty::App(Box::new(Ty::Con(TyCon::new("List"))), vec![inner])
    }

    /// Create an unparameterized `List` type (opaque pointer).
    pub fn list_untyped() -> Ty {
        Ty::Con(TyCon::new("List"))
    }

    /// Create a `Map<K, V>` type.
    pub fn map(key: Ty, value: Ty) -> Ty {
        Ty::App(Box::new(Ty::Con(TyCon::new("Map"))), vec![key, value])
    }

    /// Create an unparameterized `Map` type (opaque pointer).
    pub fn map_untyped() -> Ty {
        Ty::Con(TyCon::new("Map"))
    }

    /// Create a `Set<T>` type.
    pub fn set(inner: Ty) -> Ty {
        Ty::App(Box::new(Ty::Con(TyCon::new("Set"))), vec![inner])
    }

    /// Create a `Range` type.
    pub fn range() -> Ty {
        Ty::Con(TyCon::new("Range"))
    }

    /// Create a `Queue` type.
    pub fn queue(inner: Ty) -> Ty {
        Ty::App(Box::new(Ty::Con(TyCon::new("Queue"))), vec![inner])
    }

    /// Create a named struct type with optional type arguments.
    /// Non-generic structs: `Ty::struct_ty("Point", vec![])` -> `Point`
    /// Generic structs: `Ty::struct_ty("Pair", vec![Ty::int(), Ty::string()])` -> `Pair<Int, String>`
    pub fn struct_ty(name: &str, args: Vec<Ty>) -> Ty {
        Ty::App(Box::new(Ty::Con(TyCon::new(name))), args)
    }
}

impl fmt::Display for Ty {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Ty::Var(v) => write!(f, "?{}", v.0),
            Ty::Nat(index) => write!(f, "{index}"),
            Ty::Con(c) => write!(f, "{}", c),
            Ty::Fun(params, ret) => {
                write!(f, "(")?;
                for (i, p) in params.iter().enumerate() {
                    if i > 0 {
                        write!(f, ", ")?;
                    }
                    write!(f, "{}", p)?;
                }
                write!(f, ") -> {}", ret)
            }
            Ty::App(..) if self.as_tuple_row().is_some() => {
                let (elems, _) = self.as_tuple_row().unwrap();
                write!(f, "(")?;
                for e in elems {
                    write!(f, "{}, ", e)?;
                }
                write!(f, "..)")
            }
            Ty::App(con, args) => {
                write!(f, "{}", con)?;
                if !args.is_empty() {
                    write!(f, "<")?;
                    for (i, a) in args.iter().enumerate() {
                        if i > 0 {
                            write!(f, ", ")?;
                        }
                        write!(f, "{}", a)?;
                    }
                    write!(f, ">")?;
                }
                Ok(())
            }
            Ty::Tuple(elems) => {
                write!(f, "(")?;
                for (i, e) in elems.iter().enumerate() {
                    if i > 0 {
                        write!(f, ", ")?;
                    }
                    write!(f, "{}", e)?;
                }
                write!(f, ")")
            }
            Ty::Never => write!(f, "Never"),
        }
    }
}

/// Name of the type constructor behind `Ty::tuple_row`.
pub const TUPLE_ROW: &str = "TupleRow";

/// Name of the labeled content type, `Plaintext<T>`.
pub const PLAINTEXT: &str = "Plaintext";

/// A polymorphic type scheme: a type with universally quantified variables.
///
/// For example, the type of `identity` is `forall a. a -> a`, represented as
/// `Scheme { vars: [a], ty: Fun([Var(a)], Var(a)) }`.
#[derive(Clone, Debug)]
pub struct Scheme {
    /// The quantified (generic) type variables.
    pub vars: Vec<TyVar>,
    /// The underlying type (may reference vars).
    pub ty: Ty,
}

impl Scheme {
    /// Create a monomorphic scheme (no quantified variables).
    pub fn mono(ty: Ty) -> Self {
        Scheme {
            vars: Vec::new(),
            ty,
        }
    }

    /// Create a self-contained scheme from a resolved type by collecting all
    /// free TyVars and remapping them to sequential IDs starting from 0.
    ///
    /// This makes the scheme independent of any particular InferCtx's
    /// unification table. Essential for cross-module export: without
    /// normalization, TyVar IDs from the exporting module would index
    /// out of bounds in the importing module's unification table.
    pub fn normalize_from_ty(ty: Ty) -> Self {
        let mut free = Vec::new();
        collect_free_tyvars(&ty, &mut free);
        let mut mapping: HashMap<TyVar, TyVar> = HashMap::new();
        for var in free {
            let next = TyVar(mapping.len() as u32);
            mapping.entry(var).or_insert(next);
        }
        Scheme {
            vars: (0..mapping.len() as u32).map(TyVar).collect(),
            ty: remap_tyvars(&ty, &mapping),
        }
    }
}

/// Collect all TyVar references in a type, in order of first appearance.
fn collect_free_tyvars(ty: &Ty, out: &mut Vec<TyVar>) {
    if let Some(var) = ty.variable() {
        out.push(var);
    }
    ty.parts().for_each(|part| collect_free_tyvars(part, out));
}

/// `ty` with its variables renamed by `mapping`, which holds each of them.
fn remap_tyvars(ty: &Ty, mapping: &HashMap<TyVar, TyVar>) -> Ty {
    match ty {
        Ty::Var(v) => Ty::Var(mapping[v]),
        Ty::Nat(index) => Ty::Nat(index.map_leaf(|leaf| match leaf {
            NatIndex::Variable(var) => NatIndex::Variable(mapping[var]),
            _ => leaf.clone(),
        })),
        _ => ty.map_parts(|part| remap_tyvars(part, mapping)),
    }
}

/// `ty` with each variable named by its place in `seen`, which it joins
/// when first met: `a` to `z`, then `a1` to `z1`, and so on.
fn name_vars(ty: &Ty, seen: &mut Vec<TyVar>) -> Ty {
    let Some(var) = ty.variable() else {
        return ty.map_parts(|part| name_vars(part, seen));
    };
    let index = seen.iter().position(|v| *v == var).unwrap_or_else(|| {
        seen.push(var);
        seen.len() - 1
    });
    let letter = (b'a' + (index % 26) as u8) as char;
    let suffix = if index < 26 {
        String::new()
    } else {
        (index / 26).to_string()
    };
    let name = format!("{letter}{suffix}");
    match ty {
        Ty::Nat(index) => Ty::Nat(index.map_leaf(|_| NatIndex::Parameter(name))),
        _ => Ty::Con(TyCon::new(name)),
    }
}

// ── ena trait implementations ──────────────────────────────────────────

impl ena::unify::UnifyKey for TyVar {
    type Value = Option<Ty>;

    fn index(&self) -> u32 {
        self.0
    }

    fn from_index(u: u32) -> Self {
        TyVar(u)
    }

    fn tag() -> &'static str {
        "TyVar"
    }
}

impl ena::unify::EqUnifyValue for Ty {}
