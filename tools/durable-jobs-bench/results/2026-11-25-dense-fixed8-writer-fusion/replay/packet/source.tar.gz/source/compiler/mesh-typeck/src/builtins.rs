//! Built-in type registration.
//!
//! Registers primitive types (Int, Float, String, Bool), generic type
//! constructors (Option, Result), built-in arithmetic operators, and
//! compiler-known traits (Add, Sub, Mul, Div, Mod, Eq, Ord, Not, Iterator, Iterable) into
//! the type environment and trait registry.

use rustc_hash::FxHashMap;

use crate::env::TypeEnv;
use crate::traits::{
    AssocTypeDef, ImplDef, ImplMethodSig, TraitDef, TraitMethodSig, TraitRegistry,
};
use crate::ty::{Scheme, Ty, TyCon, TyVar};
use crate::unify::InferCtx;

fn register_wide_integer(env: &mut TypeEnv, prefix: &str, ty: Ty) {
    let result = || Ty::result(ty.clone(), Ty::string());
    env.insert(
        format!("{prefix}_parse"),
        Scheme::mono(Ty::fun(vec![Ty::string()], result())),
    );
    env.insert(
        format!("{prefix}_compare"),
        Scheme::mono(Ty::fun(vec![ty.clone(), ty.clone()], Ty::int())),
    );
    for operation in ["add", "subtract", "multiply", "divide"] {
        env.insert(
            format!("{prefix}_{operation}"),
            Scheme::mono(Ty::fun(vec![ty.clone(), ty.clone()], result())),
        );
    }
    env.insert(
        format!("{prefix}_to_int"),
        Scheme::mono(Ty::fun(
            vec![ty.clone()],
            Ty::result(Ty::int(), Ty::string()),
        )),
    );
    env.insert(
        format!("{prefix}_to_string"),
        Scheme::mono(Ty::fun(vec![ty], Ty::string())),
    );
}

pub(crate) fn crypto_functions() -> Vec<(&'static str, Scheme)> {
    let crypto_result = |value| Ty::result(value, Ty::crypto_error());

    vec![
        (
            "sha256",
            Scheme::mono(Ty::fun(vec![Ty::bytes()], Ty::bytes())),
        ),
        (
            "sha512",
            Scheme::mono(Ty::fun(vec![Ty::bytes()], Ty::bytes())),
        ),
        (
            "sha256_hex",
            Scheme::mono(Ty::fun(vec![Ty::bytes()], Ty::string())),
        ),
        (
            "sha512_hex",
            Scheme::mono(Ty::fun(vec![Ty::bytes()], Ty::string())),
        ),
        (
            "random_bytes",
            Scheme::mono(Ty::fun(vec![Ty::int()], crypto_result(Ty::bytes()))),
        ),
        (
            "hmac_sha256",
            Scheme::mono(Ty::fun(
                vec![Ty::secret_bytes(), Ty::bytes()],
                crypto_result(Ty::secret_bytes()),
            )),
        ),
        (
            "hmac_sha256_tag",
            Scheme::mono(Ty::fun(
                vec![Ty::secret_bytes(), Ty::bytes()],
                crypto_result(Ty::bytes()),
            )),
        ),
        (
            "hkdf_sha256",
            Scheme::mono(Ty::fun(
                vec![Ty::secret_bytes(), Ty::bytes(), Ty::bytes(), Ty::int()],
                crypto_result(Ty::secret_bytes()),
            )),
        ),
        (
            "argon2id",
            Scheme::mono(Ty::fun(
                vec![
                    Ty::secret_bytes(),
                    Ty::bytes(),
                    Ty::int(),
                    Ty::int(),
                    Ty::int(),
                    Ty::int(),
                ],
                crypto_result(Ty::secret_bytes()),
            )),
        ),
        (
            "x25519_generate",
            Scheme::mono(Ty::fun(vec![], crypto_result(Ty::x25519_key_pair()))),
        ),
        (
            "x25519_from_seed",
            Scheme::mono(Ty::fun(
                vec![Ty::bytes()],
                crypto_result(Ty::x25519_key_pair()),
            )),
        ),
        (
            "x25519_from_secret",
            Scheme::mono(Ty::fun(
                vec![Ty::secret_bytes()],
                crypto_result(Ty::x25519_key_pair()),
            )),
        ),
        (
            "x25519_public",
            Scheme::mono(Ty::fun(
                vec![Ty::x25519_private_key()],
                crypto_result(Ty::x25519_public_key()),
            )),
        ),
        (
            "x25519_shared",
            Scheme::mono(Ty::fun(
                vec![Ty::x25519_private_key(), Ty::x25519_public_key()],
                crypto_result(Ty::secret_bytes()),
            )),
        ),
        (
            "hpke_seal",
            Scheme::mono(Ty::fun(
                vec![
                    Ty::x25519_public_key(),
                    Ty::bytes(),
                    Ty::bytes(),
                    Ty::bytes(),
                ],
                crypto_result(Ty::bytes()),
            )),
        ),
        (
            "hpke_open",
            Scheme::mono(Ty::fun(
                vec![
                    Ty::x25519_private_key(),
                    Ty::bytes(),
                    Ty::bytes(),
                    Ty::bytes(),
                ],
                crypto_result(Ty::bytes()),
            )),
        ),
        (
            "hpke_seal_secret",
            Scheme::mono(Ty::fun(
                vec![
                    Ty::x25519_public_key(),
                    Ty::bytes(),
                    Ty::bytes(),
                    Ty::secret_bytes(),
                ],
                crypto_result(Ty::bytes()),
            )),
        ),
        (
            "hpke_open_secret",
            Scheme::mono(Ty::fun(
                vec![
                    Ty::x25519_private_key(),
                    Ty::bytes(),
                    Ty::bytes(),
                    Ty::bytes(),
                ],
                crypto_result(Ty::secret_bytes()),
            )),
        ),
        // HPKE with a 32-byte export from the context (RFC 9180 section 5.3):
        // the last argument is the exporter context.
        (
            "hpke_seal_export",
            Scheme::mono(Ty::fun(
                vec![
                    Ty::x25519_public_key(),
                    Ty::bytes(),
                    Ty::bytes(),
                    Ty::bytes(),
                    Ty::bytes(),
                ],
                crypto_result(Ty::Tuple(vec![Ty::bytes(), Ty::secret_bytes()])),
            )),
        ),
        (
            "hpke_open_export",
            Scheme::mono(Ty::fun(
                vec![
                    Ty::x25519_private_key(),
                    Ty::bytes(),
                    Ty::bytes(),
                    Ty::bytes(),
                    Ty::bytes(),
                ],
                crypto_result(Ty::Tuple(vec![Ty::bytes(), Ty::secret_bytes()])),
            )),
        ),
        // ChaCha20-Poly1305 under the key and nonce HKDF-SHA-256 derives from
        // a secret and a salt (RFC 9458 section 4.4): secret, salt, aad, input.
        (
            "hkdf_aead_seal",
            Scheme::mono(Ty::fun(
                vec![Ty::secret_bytes(), Ty::bytes(), Ty::bytes(), Ty::bytes()],
                crypto_result(Ty::bytes()),
            )),
        ),
        (
            "hkdf_aead_open",
            Scheme::mono(Ty::fun(
                vec![Ty::secret_bytes(), Ty::bytes(), Ty::bytes(), Ty::bytes()],
                crypto_result(Ty::bytes()),
            )),
        ),
        (
            "mlkem_generate",
            Scheme::mono(Ty::fun(vec![], crypto_result(Ty::mlkem_key_pair()))),
        ),
        (
            "mlkem_from_seed",
            Scheme::mono(Ty::fun(
                vec![Ty::bytes()],
                crypto_result(Ty::mlkem_key_pair()),
            )),
        ),
        (
            "mlkem_from_secret",
            Scheme::mono(Ty::fun(
                vec![Ty::secret_bytes()],
                crypto_result(Ty::mlkem_key_pair()),
            )),
        ),
        (
            "mlkem_encapsulate",
            Scheme::mono(Ty::fun(
                vec![Ty::mlkem_public_key()],
                crypto_result(Ty::Tuple(vec![Ty::mlkem_ciphertext(), Ty::secret_bytes()])),
            )),
        ),
        (
            "mlkem_decapsulate",
            Scheme::mono(Ty::fun(
                vec![Ty::mlkem_private_key(), Ty::mlkem_ciphertext()],
                crypto_result(Ty::secret_bytes()),
            )),
        ),
        (
            "signing_generate",
            Scheme::mono(Ty::fun(vec![], crypto_result(Ty::signing_key_pair()))),
        ),
        (
            "signing_from_seed",
            Scheme::mono(Ty::fun(
                vec![Ty::bytes()],
                crypto_result(Ty::signing_key_pair()),
            )),
        ),
        (
            "signing_from_secret",
            Scheme::mono(Ty::fun(
                vec![Ty::secret_bytes()],
                crypto_result(Ty::signing_key_pair()),
            )),
        ),
        (
            "sign",
            Scheme::mono(Ty::fun(
                vec![Ty::signing_private_key(), Ty::bytes()],
                crypto_result(Ty::signature()),
            )),
        ),
        (
            "verify",
            Scheme::mono(Ty::fun(
                vec![Ty::signing_public_key(), Ty::bytes(), Ty::signature()],
                crypto_result(Ty::bool()),
            )),
        ),
        (
            "aead_key",
            Scheme::mono(Ty::fun(
                vec![Ty::secret_bytes()],
                crypto_result(Ty::aead_key()),
            )),
        ),
        (
            "aead_seal",
            Scheme::mono(Ty::fun(
                vec![Ty::aead_key(), Ty::bytes(), Ty::bytes(), Ty::bytes()],
                crypto_result(Ty::bytes()),
            )),
        ),
        (
            "aead_open",
            Scheme::mono(Ty::fun(
                vec![Ty::aead_key(), Ty::bytes(), Ty::bytes(), Ty::bytes()],
                crypto_result(Ty::bytes()),
            )),
        ),
        // The seals are the exits for message content: `Plaintext<Bytes>` in,
        // ciphertext out, and back (see `plaintext.rs`).
        (
            "aead_seal_plaintext",
            Scheme::mono(Ty::fun(
                vec![
                    Ty::aead_key(),
                    Ty::bytes(),
                    Ty::bytes(),
                    Ty::plaintext(Ty::bytes()),
                ],
                crypto_result(Ty::bytes()),
            )),
        ),
        (
            "aead_open_plaintext",
            Scheme::mono(Ty::fun(
                vec![Ty::aead_key(), Ty::bytes(), Ty::bytes(), Ty::bytes()],
                crypto_result(Ty::plaintext(Ty::bytes())),
            )),
        ),
        (
            "hpke_seal_plaintext",
            Scheme::mono(Ty::fun(
                vec![
                    Ty::x25519_public_key(),
                    Ty::bytes(),
                    Ty::bytes(),
                    Ty::plaintext(Ty::bytes()),
                ],
                crypto_result(Ty::bytes()),
            )),
        ),
        (
            "hpke_open_plaintext",
            Scheme::mono(Ty::fun(
                vec![
                    Ty::x25519_private_key(),
                    Ty::bytes(),
                    Ty::bytes(),
                    Ty::bytes(),
                ],
                crypto_result(Ty::plaintext(Ty::bytes())),
            )),
        ),
        // Blind RSA, profile BR1 (RFC 9474 RSABSSA-SHA384-PSS-Deterministic).
        (
            "blind_rsa_generate",
            Scheme::mono(Ty::fun(vec![], crypto_result(Ty::blind_rsa_secret_key()))),
        ),
        (
            "blind_rsa_from_secret",
            Scheme::mono(Ty::fun(
                vec![Ty::secret_bytes()],
                crypto_result(Ty::blind_rsa_secret_key()),
            )),
        ),
        (
            "blind_rsa_public",
            Scheme::mono(Ty::fun(
                vec![Ty::blind_rsa_secret_key()],
                crypto_result(Ty::blind_rsa_public_key()),
            )),
        ),
        (
            "blind_rsa_public_from_spki",
            Scheme::mono(Ty::fun(
                vec![Ty::bytes()],
                crypto_result(Ty::blind_rsa_public_key()),
            )),
        ),
        (
            "blind_rsa_blind",
            Scheme::mono(Ty::fun(
                vec![Ty::blind_rsa_public_key(), Ty::bytes()],
                crypto_result(Ty::blind_rsa_blinded()),
            )),
        ),
        (
            "blind_rsa_sign",
            Scheme::mono(Ty::fun(
                vec![Ty::blind_rsa_secret_key(), Ty::bytes()],
                crypto_result(Ty::bytes()),
            )),
        ),
        (
            "blind_rsa_finalize",
            Scheme::mono(Ty::fun(
                vec![
                    Ty::blind_rsa_public_key(),
                    Ty::bytes(),
                    Ty::bytes(),
                    Ty::blind_rsa_blinding_state(),
                ],
                crypto_result(Ty::bytes()),
            )),
        ),
        (
            "blind_rsa_verify",
            Scheme::mono(Ty::fun(
                vec![Ty::blind_rsa_public_key(), Ty::bytes(), Ty::bytes()],
                crypto_result(Ty::bool()),
            )),
        ),
        // Non-colliding Phase 135 APIs remain temporarily available.
        (
            "hmac_sha512",
            Scheme::mono(Ty::fun(vec![Ty::string(), Ty::string()], Ty::string())),
        ),
        ("uuid4", Scheme::mono(Ty::fun(vec![], Ty::string()))),
    ]
}

/// Register all built-in types and functions into the environment.
///
/// After this call, the environment contains:
/// - Primitive types: Int, Float, String, Bool
/// - Generic constructors: Option (arity 1), Result (arity 2)
/// - Arithmetic operators: +, -, *, / for Int and Float
/// - Comparison operators (returns Bool)
/// - Logical operators (and, or, not)
///
/// And the trait registry contains compiler-known traits:
/// - Add, Sub, Mul, Div, Mod (numeric operations)
/// - Eq (equality comparison)
/// - Ord (ordering comparison)
/// - Not (logical negation)
/// - Default (zero-initialization, static method -- no self parameter)
pub fn register_builtins(
    _ctx: &mut InferCtx,
    env: &mut TypeEnv,
    trait_registry: &mut TraitRegistry,
) {
    // ── Primitive type constructors ─────────────────────────────────

    // These are registered as monomorphic schemes so they can be
    // referenced as type names in annotations.
    env.insert("Int".into(), Scheme::mono(Ty::int()));
    env.insert("Float".into(), Scheme::mono(Ty::float()));
    env.insert("String".into(), Scheme::mono(Ty::string()));
    env.insert("Bytes".into(), Scheme::mono(Ty::bytes()));
    env.insert("BytesBuilder".into(), Scheme::mono(Ty::bytes_builder()));
    env.insert("DbValue".into(), Scheme::mono(Ty::db_value()));
    env.insert("U64".into(), Scheme::mono(Ty::u64()));
    env.insert("U128".into(), Scheme::mono(Ty::u128()));
    env.insert("I128".into(), Scheme::mono(Ty::i128()));
    env.insert("Bool".into(), Scheme::mono(Ty::bool()));

    // ── Actor type constructor ────────────────────────────────────
    //
    // Pid is a type constructor with arity 1: Pid<M> where M is the
    // message type. Untyped Pid (arity 0) is also valid as an escape
    // hatch. We register the bare name so `Pid` resolves in annotations.
    env.insert("Pid".into(), Scheme::mono(Ty::untyped_pid()));

    // ── Regex type constructor (Phase 119) ──────────────────────
    //
    // Regex is an opaque type representing a compiled regex pattern.
    // Values of type Regex are produced by the ~r/pattern/flags literal.
    env.insert("Regex".into(), Scheme::mono(Ty::Con(TyCon::new("Regex"))));

    // ── I/O builtins ──────────────────────────────────────────────

    // println(String) -> () -- prints a string with trailing newline
    env.insert(
        "println".into(),
        Scheme::mono(Ty::fun(vec![Ty::string()], Ty::Tuple(vec![]))),
    );

    // panic(String) -> Never -- ends the actor, or the program, with a Mesh panic
    env.insert(
        "panic".into(),
        Scheme::mono(Ty::fun(vec![Ty::string()], Ty::Never)),
    );

    // declassify(Plaintext<T>, String) -> T -- a deliberate disclosure; the
    // reason must be a string literal, and the build report lists the site.
    let revealed = TyVar(u32::MAX - 40);
    env.insert(
        "declassify".into(),
        Scheme {
            vars: vec![revealed],
            ty: Ty::fun(
                vec![Ty::plaintext(Ty::Var(revealed)), Ty::string()],
                Ty::Var(revealed),
            ),
        },
    );

    // print(String) -> () -- prints a string without trailing newline
    env.insert(
        "print".into(),
        Scheme::mono(Ty::fun(vec![Ty::string()], Ty::Tuple(vec![]))),
    );

    // ── Default protocol: static trait method ──────────────────────
    //
    // default() -> T -- polymorphic, type resolved from call-site context.
    // Registered as a polymorphic function so typeck can unify T with the
    // target type annotation (e.g., `let x: Int = default()` -> T = Int).
    {
        let t_var = TyVar(99000);
        let t = Ty::Var(t_var);
        env.insert(
            "default".into(),
            Scheme {
                vars: vec![t_var],
                ty: Ty::fun(vec![], t),
            },
        );
    }

    // ── compare(a, b) -> Ordering ───────────────────────────────────
    //
    // Polymorphic built-in function: compare(T, T) -> Ordering.
    // At MIR level, dispatches to Ord__compare__TypeName.
    {
        let t_var = TyVar(99002);
        let t = Ty::Var(t_var);
        env.insert(
            "compare".into(),
            Scheme {
                vars: vec![t_var],
                ty: Ty::fun(vec![t.clone(), t], Ty::Con(TyCon::new("Ordering"))),
            },
        );
    }

    // ── Compiler-known traits ──────────────────────────────────────

    register_compiler_known_traits(trait_registry);

    // ── Arithmetic operators (Int) ──────────────────────────────────

    // These remain in the env for backward compatibility. The binary
    // operator inference also uses trait dispatch for type checking.
    let int_binop = Scheme::mono(Ty::fun(vec![Ty::int(), Ty::int()], Ty::int()));
    env.insert("+".into(), int_binop.clone());
    env.insert("-".into(), int_binop.clone());
    env.insert("*".into(), int_binop.clone());
    env.insert("/".into(), int_binop);

    // ── Float arithmetic ────────────────────────────────────────────

    let float_binop = Scheme::mono(Ty::fun(vec![Ty::float(), Ty::float()], Ty::float()));
    env.insert("+.".into(), float_binop.clone());
    env.insert("-.".into(), float_binop.clone());
    env.insert("*.".into(), float_binop.clone());
    env.insert("/.".into(), float_binop);

    // ── String concatenation ────────────────────────────────────────

    env.insert(
        "<>".into(),
        Scheme::mono(Ty::fun(vec![Ty::string(), Ty::string()], Ty::string())),
    );

    // ── Comparison (returns Bool) ───────────────────────────────────

    let int_cmp = Scheme::mono(Ty::fun(vec![Ty::int(), Ty::int()], Ty::bool()));
    env.insert("==".into(), int_cmp.clone());
    env.insert("!=".into(), int_cmp.clone());
    env.insert("<".into(), int_cmp.clone());
    env.insert(">".into(), int_cmp.clone());
    env.insert("<=".into(), int_cmp.clone());
    env.insert(">=".into(), int_cmp);

    // ── Logical operators ───────────────────────────────────────────

    let bool_binop = Scheme::mono(Ty::fun(vec![Ty::bool(), Ty::bool()], Ty::bool()));
    env.insert("and".into(), bool_binop.clone());
    env.insert("or".into(), bool_binop);
    env.insert(
        "not".into(),
        Scheme::mono(Ty::fun(vec![Ty::bool()], Ty::bool())),
    );

    // ── Standard library: String operations (Phase 8) ────────────────

    env.insert(
        "string_length".into(),
        Scheme::mono(Ty::fun(vec![Ty::string()], Ty::int())),
    );
    env.insert(
        "string_slice".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::string(), Ty::int(), Ty::int()],
            Ty::string(),
        )),
    );
    env.insert(
        "string_contains".into(),
        Scheme::mono(Ty::fun(vec![Ty::string(), Ty::string()], Ty::bool())),
    );
    env.insert(
        "string_starts_with".into(),
        Scheme::mono(Ty::fun(vec![Ty::string(), Ty::string()], Ty::bool())),
    );
    env.insert(
        "string_ends_with".into(),
        Scheme::mono(Ty::fun(vec![Ty::string(), Ty::string()], Ty::bool())),
    );
    env.insert(
        "string_trim".into(),
        Scheme::mono(Ty::fun(vec![Ty::string()], Ty::string())),
    );
    for trim in ["string_trim_start", "string_trim_end"] {
        env.insert(
            trim.into(),
            Scheme::mono(Ty::fun(vec![Ty::string()], Ty::string())),
        );
    }
    env.insert(
        "string_repeat".into(),
        Scheme::mono(Ty::fun(vec![Ty::string(), Ty::int()], Ty::string())),
    );
    env.insert(
        "string_to_upper".into(),
        Scheme::mono(Ty::fun(vec![Ty::string()], Ty::string())),
    );
    env.insert(
        "string_to_lower".into(),
        Scheme::mono(Ty::fun(vec![Ty::string()], Ty::string())),
    );
    env.insert(
        "string_replace".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::string(), Ty::string(), Ty::string()],
            Ty::string(),
        )),
    );
    env.insert(
        "string_split".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::string(), Ty::string()],
            Ty::list(Ty::string()),
        )),
    );
    env.insert(
        "string_join".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::list(Ty::string()), Ty::string()],
            Ty::string(),
        )),
    );
    env.insert(
        "string_to_int".into(),
        Scheme::mono(Ty::fun(vec![Ty::string()], Ty::option(Ty::int()))),
    );
    env.insert(
        "string_to_float".into(),
        Scheme::mono(Ty::fun(vec![Ty::string()], Ty::option(Ty::float()))),
    );

    // ── Standard library: File I/O functions (Phase 8) ──────────────────

    env.insert(
        "file_read".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::string()],
            Ty::result(Ty::string(), Ty::string()),
        )),
    );
    env.insert(
        "file_read_bytes".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::string(), Ty::int(), Ty::int()],
            Ty::result(Ty::bytes(), Ty::string()),
        )),
    );
    env.insert(
        "file_write_bytes".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::string(), Ty::int(), Ty::bytes(), Ty::bool()],
            Ty::result(Ty::Tuple(vec![]), Ty::string()),
        )),
    );
    env.insert(
        "file_size".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::string()],
            Ty::result(Ty::int(), Ty::string()),
        )),
    );
    env.insert(
        "file_write".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::string(), Ty::string()],
            Ty::result(Ty::Tuple(vec![]), Ty::string()),
        )),
    );
    env.insert(
        "file_append".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::string(), Ty::string()],
            Ty::result(Ty::Tuple(vec![]), Ty::string()),
        )),
    );
    env.insert(
        "file_exists".into(),
        Scheme::mono(Ty::fun(vec![Ty::string()], Ty::bool())),
    );
    env.insert(
        "file_delete".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::string()],
            Ty::result(Ty::Tuple(vec![]), Ty::string()),
        )),
    );
    env.insert(
        "file_rename".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::string(), Ty::string()],
            Ty::result(Ty::Tuple(vec![]), Ty::string()),
        )),
    );
    env.insert(
        "file_sync".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::string()],
            Ty::result(Ty::Tuple(vec![]), Ty::string()),
        )),
    );

    // ── Standard library: IO functions (Phase 8) ─────────────────────

    env.insert(
        "io_read_line".into(),
        Scheme::mono(Ty::fun(vec![], Ty::result(Ty::string(), Ty::string()))),
    );
    env.insert(
        "io_eprintln".into(),
        Scheme::mono(Ty::fun(vec![Ty::string()], Ty::Tuple(vec![]))),
    );

    // ── Standard library: Env functions (Phase 8) ────────────────────

    // Env.get(key, default) -> String
    // Module-qualified dispatch: Env.get -> prefixed "env_get" -> map_builtin_name -> mesh_env_get_with_default
    env.insert(
        "env_get_with_default".into(),
        Scheme::mono(Ty::fun(vec![Ty::string(), Ty::string()], Ty::string())),
    );
    // Env.get_int(key, default) -> Int
    env.insert(
        "env_get_int".into(),
        Scheme::mono(Ty::fun(vec![Ty::string(), Ty::int()], Ty::int())),
    );
    env.insert(
        "env_get_secret_hex".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::string()],
            Ty::result(Ty::secret_bytes(), Ty::crypto_error()),
        )),
    );
    // Env.args() -> List<String>  (bare env_args still resolves via map_builtin_name)
    env.insert(
        "env_args".into(),
        Scheme::mono(Ty::fun(vec![], Ty::list(Ty::string()))),
    );

    // ── Standard library: Regex functions (Phase 119) ─────────────────

    // Regex.compile(pattern) -> Result<Regex, String>
    // Module-qualified: Regex.compile -> prefixed "regex_compile" -> map_builtin_name -> mesh_regex_compile
    env.insert(
        "regex_compile".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::string()],
            Ty::result(Ty::Con(TyCon::new("Regex")), Ty::string()),
        )),
    );
    // Regex.is_match(rx, str) -> Bool
    env.insert(
        "regex_is_match".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::Con(TyCon::new("Regex")), Ty::string()],
            Ty::bool(),
        )),
    );
    // Regex.captures(rx, str) -> Option<List<String>>
    env.insert(
        "regex_captures".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::Con(TyCon::new("Regex")), Ty::string()],
            Ty::option(Ty::list(Ty::string())),
        )),
    );
    // Regex.replace(rx, str, replacement) -> String
    env.insert(
        "regex_replace".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::Con(TyCon::new("Regex")), Ty::string(), Ty::string()],
            Ty::string(),
        )),
    );
    // Regex.split(rx, str) -> List<String>
    env.insert(
        "regex_split".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::Con(TyCon::new("Regex")), Ty::string()],
            Ty::list(Ty::string()),
        )),
    );

    // ── Standard library: binary-safe Bytes ────────────────────────────────

    let bytes_result = || Ty::result(Ty::bytes(), Ty::string());
    let checked_bytes_result = || Ty::result(Ty::bytes(), Ty::bytes_error());
    env.insert(
        "bytes_empty".into(),
        Scheme::mono(Ty::fun(vec![], Ty::bytes())),
    );
    env.insert(
        "bytes_from_list".into(),
        Scheme::mono(Ty::fun(vec![Ty::list(Ty::int())], checked_bytes_result())),
    );
    env.insert(
        "bytes_to_list".into(),
        Scheme::mono(Ty::fun(vec![Ty::bytes()], Ty::list(Ty::int()))),
    );
    env.insert(
        "bytes_repeat".into(),
        Scheme::mono(Ty::fun(vec![Ty::int(), Ty::int()], checked_bytes_result())),
    );
    env.insert(
        "bytes_length".into(),
        Scheme::mono(Ty::fun(vec![Ty::bytes()], Ty::int())),
    );
    env.insert(
        "bytes_get".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::bytes(), Ty::int()],
            Ty::result(Ty::int(), Ty::string()),
        )),
    );
    env.insert(
        "bytes_slice".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::bytes(), Ty::int(), Ty::int()],
            bytes_result(),
        )),
    );
    env.insert(
        "bytes_concat".into(),
        Scheme::mono(Ty::fun(vec![Ty::bytes(), Ty::bytes()], bytes_result())),
    );
    env.insert(
        "bytes_secure_equals".into(),
        Scheme::mono(Ty::fun(vec![Ty::bytes(), Ty::bytes()], Ty::bool())),
    );
    env.insert(
        "bytes_from_utf8".into(),
        Scheme::mono(Ty::fun(vec![Ty::string()], Ty::bytes())),
    );
    env.insert(
        "bytes_to_utf8".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::bytes()],
            Ty::result(Ty::string(), Ty::string()),
        )),
    );
    for name in ["bytes_to_base64", "bytes_to_base58", "bytes_to_hex"] {
        env.insert(
            name.into(),
            Scheme::mono(Ty::fun(vec![Ty::bytes()], Ty::string())),
        );
    }
    for name in ["bytes_from_base64", "bytes_from_base58", "bytes_from_hex"] {
        env.insert(
            name.into(),
            Scheme::mono(Ty::fun(vec![Ty::string()], bytes_result())),
        );
    }
    env.insert(
        "bytes_read_uint_le".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::bytes(), Ty::int(), Ty::int()],
            Ty::result(Ty::string(), Ty::string()),
        )),
    );
    env.insert(
        "bytes_write_uint_le".into(),
        Scheme::mono(Ty::fun(vec![Ty::string(), Ty::int()], bytes_result())),
    );
    for name in ["bytes_read_u16_be", "bytes_read_u16_le"] {
        env.insert(
            name.into(),
            Scheme::mono(Ty::fun(
                vec![Ty::bytes(), Ty::int()],
                Ty::result(Ty::int(), Ty::bytes_error()),
            )),
        );
    }
    for name in [
        "bytes_read_u32_be",
        "bytes_read_u32_le",
        "bytes_read_u64_be",
        "bytes_read_u64_le",
    ] {
        env.insert(
            name.into(),
            Scheme::mono(Ty::fun(
                vec![Ty::bytes(), Ty::int()],
                Ty::result(Ty::u64(), Ty::bytes_error()),
            )),
        );
    }
    env.insert(
        "bytes_write_u16_be".into(),
        Scheme::mono(Ty::fun(vec![Ty::int()], checked_bytes_result())),
    );
    for name in ["bytes_write_u32_be", "bytes_write_u64_be"] {
        env.insert(
            name.into(),
            Scheme::mono(Ty::fun(vec![Ty::u64()], checked_bytes_result())),
        );
    }
    let bytes_builder = Ty::bytes_builder();
    let builder_result = |value| Ty::result(value, Ty::binary_error());
    env.insert(
        "bytes_builder_new".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::int()],
            builder_result(bytes_builder.clone()),
        )),
    );
    for name in [
        "bytes_builder_write_u8",
        "bytes_builder_write_u16_be",
        "bytes_builder_write_u32_be",
    ] {
        env.insert(
            name.into(),
            Scheme::mono(Ty::fun(
                vec![bytes_builder.clone(), Ty::int()],
                builder_result(Ty::Tuple(vec![])),
            )),
        );
    }
    env.insert(
        "bytes_builder_write_bytes".into(),
        Scheme::mono(Ty::fun(
            vec![bytes_builder.clone(), Ty::bytes()],
            builder_result(Ty::Tuple(vec![])),
        )),
    );
    env.insert(
        "bytes_builder_finish".into(),
        Scheme::mono(Ty::fun(vec![bytes_builder], builder_result(Ty::bytes()))),
    );

    env.insert(
        "secret_random".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::int()],
            Ty::result(Ty::secret_bytes(), Ty::crypto_error()),
        )),
    );
    env.insert(
        "secret_destroy".into(),
        Scheme::mono(Ty::fun(vec![Ty::secret_bytes()], Ty::Tuple(vec![]))),
    );
    env.insert(
        "secret_from_bytes".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::bytes()],
            Ty::result(Ty::secret_bytes(), Ty::crypto_error()),
        )),
    );
    env.insert(
        "secret_concat".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::secret_bytes(), Ty::secret_bytes()],
            Ty::result(Ty::secret_bytes(), Ty::crypto_error()),
        )),
    );
    env.insert(
        "storage_key_ephemeral".into(),
        Scheme::mono(Ty::fun(
            vec![],
            Ty::result(Ty::storage_key(), Ty::crypto_error()),
        )),
    );
    env.insert(
        "storage_key_platform".into(),
        Scheme::mono(Ty::fun(
            vec![],
            Ty::result(Ty::storage_key(), Ty::crypto_error()),
        )),
    );
    env.insert(
        "storage_key_from_secret".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::secret_bytes(), Ty::bytes()],
            Ty::result(Ty::storage_key(), Ty::crypto_error()),
        )),
    );
    for name in ["storage_key_seal_bytes", "storage_key_unseal_bytes"] {
        env.insert(
            name.into(),
            Scheme::mono(Ty::fun(
                vec![Ty::bytes(), Ty::storage_key(), Ty::bytes()],
                Ty::result(Ty::bytes(), Ty::crypto_error()),
            )),
        );
    }
    for (name, input, output) in [
        ("secret_seal_for_storage", Ty::secret_bytes(), Ty::bytes()),
        ("secret_map_seal_for_storage", Ty::secret_map(), Ty::bytes()),
        (
            "signing_private_key_seal_for_storage",
            Ty::signing_private_key(),
            Ty::bytes(),
        ),
        (
            "x25519_private_key_seal_for_storage",
            Ty::x25519_private_key(),
            Ty::bytes(),
        ),
        (
            "mlkem_private_key_seal_for_storage",
            Ty::mlkem_private_key(),
            Ty::bytes(),
        ),
        (
            "blind_rsa_secret_key_seal_for_storage",
            Ty::blind_rsa_secret_key(),
            Ty::bytes(),
        ),
    ] {
        env.insert(
            name.into(),
            Scheme::mono(Ty::fun(
                vec![input, Ty::storage_key(), Ty::bytes()],
                Ty::result(output, Ty::crypto_error()),
            )),
        );
    }
    for (name, output) in [
        ("secret_unseal_from_storage", Ty::secret_bytes()),
        ("secret_map_unseal_from_storage", Ty::secret_map()),
        (
            "signing_private_key_unseal_from_storage",
            Ty::signing_private_key(),
        ),
        (
            "x25519_private_key_unseal_from_storage",
            Ty::x25519_private_key(),
        ),
        (
            "mlkem_private_key_unseal_from_storage",
            Ty::mlkem_private_key(),
        ),
        (
            "blind_rsa_secret_key_unseal_from_storage",
            Ty::blind_rsa_secret_key(),
        ),
    ] {
        env.insert(
            name.into(),
            Scheme::mono(Ty::fun(
                vec![Ty::bytes(), Ty::storage_key(), Ty::bytes()],
                Ty::result(output, Ty::crypto_error()),
            )),
        );
    }
    let secret_map = Ty::secret_map();
    env.insert(
        "secret_map_new".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::int()],
            Ty::result(secret_map.clone(), Ty::crypto_error()),
        )),
    );
    env.insert(
        "secret_map_fork".into(),
        Scheme::mono(Ty::fun(
            vec![secret_map.clone()],
            Ty::result(secret_map.clone(), Ty::crypto_error()),
        )),
    );
    env.insert(
        "secret_map_insert".into(),
        Scheme::mono(Ty::fun(
            vec![secret_map.clone(), Ty::bytes(), Ty::secret_bytes()],
            Ty::result(Ty::Tuple(vec![]), Ty::crypto_error()),
        )),
    );
    env.insert(
        "secret_map_contains".into(),
        Scheme::mono(Ty::fun(vec![secret_map.clone(), Ty::bytes()], Ty::bool())),
    );
    env.insert(
        "secret_map_copy".into(),
        Scheme::mono(Ty::fun(
            vec![secret_map.clone(), Ty::bytes()],
            Ty::result(Ty::secret_bytes(), Ty::crypto_error()),
        )),
    );
    env.insert(
        "secret_map_delete".into(),
        Scheme::mono(Ty::fun(
            vec![secret_map.clone(), Ty::bytes()],
            Ty::result(Ty::Tuple(vec![]), Ty::crypto_error()),
        )),
    );
    env.insert(
        "secret_map_merge".into(),
        Scheme::mono(Ty::fun(
            vec![secret_map.clone(), secret_map],
            Ty::result(Ty::Tuple(vec![]), Ty::crypto_error()),
        )),
    );

    register_wide_integer(env, "u64", Ty::u64());
    register_wide_integer(env, "u128", Ty::u128());
    register_wide_integer(env, "i128", Ty::i128());

    // ── Standard library: Crypto V2 functions ──────────────────────────────

    for (name, scheme) in crypto_functions() {
        env.insert(format!("crypto_{name}"), scheme);
    }

    // ── Standard library: Base64 functions (Phase 135) ─────────────────────

    env.insert(
        "base64_encode".into(),
        Scheme::mono(Ty::fun(vec![Ty::string()], Ty::string())),
    );
    env.insert(
        "base64_decode".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::string()],
            Ty::result(Ty::string(), Ty::string()),
        )),
    );
    env.insert(
        "base64_encode_url".into(),
        Scheme::mono(Ty::fun(vec![Ty::string()], Ty::string())),
    );
    env.insert(
        "base64_decode_url".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::string()],
            Ty::result(Ty::string(), Ty::string()),
        )),
    );

    // ── Standard library: Hex functions (Phase 135) ─────────────────────────

    env.insert(
        "hex_encode".into(),
        Scheme::mono(Ty::fun(vec![Ty::string()], Ty::string())),
    );
    env.insert(
        "hex_decode".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::string()],
            Ty::result(Ty::string(), Ty::string()),
        )),
    );

    // ── Standard library: DateTime functions (Phase 136) ─────────────────────

    let dt_t = Ty::Con(TyCon::new("DateTime"));

    // DateTime type constructor itself (so `DateTime` resolves as a type name)
    env.insert("DateTime".into(), Scheme::mono(dt_t.clone()));

    // DateTime.utc_now() -> DateTime
    env.insert(
        "datetime_utc_now".into(),
        Scheme::mono(Ty::fun(vec![], dt_t.clone())),
    );
    // DateTime.from_iso8601(s) -> Result<DateTime, String>
    env.insert(
        "datetime_from_iso8601".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::string()],
            Ty::result(dt_t.clone(), Ty::string()),
        )),
    );
    // DateTime.to_iso8601(dt) -> String
    env.insert(
        "datetime_to_iso8601".into(),
        Scheme::mono(Ty::fun(vec![dt_t.clone()], Ty::string())),
    );
    // DateTime.from_unix_ms(ms) -> Result<DateTime, String>
    env.insert(
        "datetime_from_unix_ms".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::int()],
            Ty::result(dt_t.clone(), Ty::string()),
        )),
    );
    // DateTime.to_unix_ms(dt) -> Int
    env.insert(
        "datetime_to_unix_ms".into(),
        Scheme::mono(Ty::fun(vec![dt_t.clone()], Ty::int())),
    );
    // DateTime.from_unix_secs(s) -> Result<DateTime, String>
    env.insert(
        "datetime_from_unix_secs".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::int()],
            Ty::result(dt_t.clone(), Ty::string()),
        )),
    );
    // DateTime.to_unix_secs(dt) -> Int
    env.insert(
        "datetime_to_unix_secs".into(),
        Scheme::mono(Ty::fun(vec![dt_t.clone()], Ty::int())),
    );
    // DateTime.add(dt, n, unit) -> DateTime
    // The unit parameter uses Atom type (e.g. :day, :hour) — Atom resolves to String at MIR level.
    let atom_t = Ty::Con(TyCon::new("Atom"));
    env.insert(
        "datetime_add".into(),
        Scheme::mono(Ty::fun(
            vec![dt_t.clone(), Ty::int(), atom_t.clone()],
            dt_t.clone(),
        )),
    );
    // DateTime.diff(dt1, dt2, unit) -> Float  (NOT Int — fractional precision)
    env.insert(
        "datetime_diff".into(),
        Scheme::mono(Ty::fun(
            vec![dt_t.clone(), dt_t.clone(), atom_t],
            Ty::float(),
        )),
    );
    // DateTime.is_before(dt1, dt2) -> Bool
    env.insert(
        "datetime_is_before".into(),
        Scheme::mono(Ty::fun(vec![dt_t.clone(), dt_t.clone()], Ty::bool())),
    );
    // DateTime.is_after(dt1, dt2) -> Bool
    env.insert(
        "datetime_is_after".into(),
        Scheme::mono(Ty::fun(vec![dt_t.clone(), dt_t.clone()], Ty::bool())),
    );

    let checked_result = Ty::result(Ty::int(), Ty::string());
    for name in ["add", "sub", "mul", "div"] {
        env.insert(
            format!("checked_{name}"),
            Scheme::mono(Ty::fun(vec![Ty::int(), Ty::int()], checked_result.clone())),
        );
    }
    env.insert(
        "checked_abs".into(),
        Scheme::mono(Ty::fun(vec![Ty::int()], checked_result.clone())),
    );
    for name in ["mul_div", "rescale"] {
        env.insert(
            format!("checked_{name}"),
            Scheme::mono(Ty::fun(
                vec![Ty::int(), Ty::int(), Ty::int(), Ty::Con(TyCon::new("Atom"))],
                checked_result.clone(),
            )),
        );
    }
    env.insert(
        "monotonic_now_nanos".into(),
        Scheme::mono(Ty::fun(vec![], Ty::int())),
    );
    env.insert(
        "monotonic_elapsed".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::int(), Ty::int()],
            Ty::result(Ty::int(), Ty::string()),
        )),
    );
    for name in ["millis", "seconds"] {
        env.insert(
            format!("duration_{name}"),
            Scheme::mono(Ty::fun(
                vec![Ty::int()],
                Ty::result(Ty::int(), Ty::string()),
            )),
        );
    }
    for (name, scheme) in channel_functions() {
        env.insert(format!("channel_{name}"), scheme);
    }
    env.insert(
        "random_seed".into(),
        Scheme::mono(Ty::fun(vec![Ty::int()], Ty::int())),
    );
    env.insert(
        "random_next_int".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::int(), Ty::int(), Ty::int()],
            Ty::Tuple(vec![Ty::int(), Ty::int()]),
        )),
    );
    env.insert(
        "random_next_unit_ppm".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::int()],
            Ty::Tuple(vec![Ty::int(), Ty::int()]),
        )),
    );

    // ── Standard library: Http client builder API (Phase 137) ─────────────────
    let http_req_t = Ty::int(); // MeshRequest opaque handle is u64 -> Int ABI
    let http_resp_t = Ty::Con(TyCon::new("HttpResponse"));
    // Atom type for HTTP method (e.g. :get, :post) — lowered to String ABI at MIR level.
    let http_atom_t = Ty::Con(TyCon::new("Atom"));

    // Http.build(:method_atom, url) -> Request (Int handle)
    // First arg is Atom (e.g. :get, :post) — Atom resolves to String at MIR level.
    env.insert(
        "http_build".into(),
        Scheme::mono(Ty::fun(vec![http_atom_t, Ty::string()], http_req_t.clone())),
    );
    // Http.header(req, key, val) -> Request
    env.insert(
        "http_header".into(),
        Scheme::mono(Ty::fun(
            vec![http_req_t.clone(), Ty::string(), Ty::string()],
            http_req_t.clone(),
        )),
    );
    // Http.body(req, s) -> Request
    env.insert(
        "http_body".into(),
        Scheme::mono(Ty::fun(
            vec![http_req_t.clone(), Ty::string()],
            http_req_t.clone(),
        )),
    );
    env.insert(
        "http_body_bytes".into(),
        Scheme::mono(Ty::fun(
            vec![http_req_t.clone(), Ty::bytes()],
            http_req_t.clone(),
        )),
    );
    // Http.timeout(req, ms) -> Request
    env.insert(
        "http_timeout".into(),
        Scheme::mono(Ty::fun(
            vec![http_req_t.clone(), Ty::int()],
            http_req_t.clone(),
        )),
    );
    env.insert(
        "http_stage_timeout".into(),
        Scheme::mono(Ty::fun(
            vec![http_req_t.clone(), Ty::Con(TyCon::new("Atom")), Ty::int()],
            http_req_t.clone(),
        )),
    );
    env.insert(
        "http_max_redirects".into(),
        Scheme::mono(Ty::fun(
            vec![http_req_t.clone(), Ty::int()],
            http_req_t.clone(),
        )),
    );
    env.insert(
        "http_max_response_bytes".into(),
        Scheme::mono(Ty::fun(
            vec![http_req_t.clone(), Ty::int()],
            http_req_t.clone(),
        )),
    );
    // Http.query(req, key, val) -> Request
    env.insert(
        "http_query".into(),
        Scheme::mono(Ty::fun(
            vec![http_req_t.clone(), Ty::string(), Ty::string()],
            http_req_t.clone(),
        )),
    );
    // Http.json(req, body) -> Request
    env.insert(
        "http_json".into(),
        Scheme::mono(Ty::fun(
            vec![http_req_t.clone(), Ty::string()],
            http_req_t.clone(),
        )),
    );
    // Http.send(req) -> Result<HttpResponse, String>
    env.insert(
        "http_send".into(),
        Scheme::mono(Ty::fun(
            vec![http_req_t.clone()],
            Ty::result(http_resp_t.clone(), Ty::string()),
        )),
    );
    // HttpResponse type name available as a type annotation
    env.insert("HttpResponse".into(), Scheme::mono(http_resp_t.clone()));
    // Http.stream(req, fn(String) -> String) -> Int  (Int = cancel handle u64)
    // Callback receives chunk as String, returns atom :continue or :stop (lowered to String)
    let stream_cb_t = Ty::fun(vec![Ty::string()], Ty::string());
    env.insert(
        "http_stream".into(),
        Scheme::mono(Ty::fun(
            vec![http_req_t.clone(), stream_cb_t.clone()],
            Ty::int(), // cancel handle
        )),
    );
    env.insert(
        "http_stream_bytes".into(),
        Scheme::mono(Ty::fun(
            vec![http_req_t.clone(), Ty::fun(vec![Ty::bytes()], Ty::string())],
            Ty::int(), // cancel handle
        )),
    );
    // Http.cancel(cancel_handle) -> ()
    env.insert(
        "http_cancel".into(),
        Scheme::mono(Ty::fun(vec![Ty::int()], Ty::Tuple(vec![]))),
    );
    // Http.client() -> Int (keep-alive Agent handle)
    let http_client_handle_t = Ty::int();
    env.insert(
        "http_client".into(),
        Scheme::mono(Ty::fun(vec![], http_client_handle_t.clone())),
    );
    // Http.send_with(client, req) -> Result<HttpResponse, String>
    env.insert(
        "http_send_with".into(),
        Scheme::mono(Ty::fun(
            vec![http_client_handle_t.clone(), http_req_t.clone()],
            Ty::result(http_resp_t.clone(), Ty::string()),
        )),
    );
    // Http.client_close(client) -> ()
    env.insert(
        "http_client_close".into(),
        Scheme::mono(Ty::fun(vec![http_client_handle_t], Ty::Tuple(vec![]))),
    );
    env.insert(
        "http_retry_class".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::Con(TyCon::new("Atom")), Ty::string()],
            Ty::string(),
        )),
    );
    env.insert(
        "http_metrics".into(),
        Scheme::mono(Ty::fun(vec![], Ty::Con(TyCon::new("HttpClientMetrics")))),
    );

    // ── Scheduler-aware WebSocket client ─────────────────────────────────
    let ws_message_t = Ty::Con(TyCon::new("WsMessage"));
    env.insert("WsMessage".into(), Scheme::mono(ws_message_t.clone()));
    env.insert(
        "ws_client_options".into(),
        Scheme::mono(Ty::fun(vec![], Ty::int())),
    );
    for name in [
        "connect_timeout",
        "heartbeat_timeout",
        "max_message_bytes",
        "queue_capacity",
    ] {
        env.insert(
            format!("ws_client_{name}"),
            Scheme::mono(Ty::fun(vec![Ty::int(), Ty::int()], Ty::int())),
        );
    }
    env.insert(
        "ws_client_connect".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::string(), Ty::int()],
            Ty::result(Ty::int(), Ty::string()),
        )),
    );
    env.insert(
        "ws_client_send_text".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::int(), Ty::string()],
            Ty::result(Ty::Tuple(vec![]), Ty::string()),
        )),
    );
    env.insert(
        "ws_client_send_bytes".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::int(), Ty::bytes()],
            Ty::result(Ty::Tuple(vec![]), Ty::string()),
        )),
    );
    env.insert(
        "ws_client_recv".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::int(), Ty::int()],
            Ty::result(ws_message_t, Ty::string()),
        )),
    );
    env.insert(
        "ws_client_close".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::int(), Ty::int(), Ty::string()],
            Ty::result(Ty::Tuple(vec![]), Ty::string()),
        )),
    );
    env.insert(
        "ws_client_reconnect_delay".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::int(), Ty::int(), Ty::int(), Ty::int()],
            Ty::result(Ty::int(), Ty::string()),
        )),
    );

    // ── Continuity public API (builtin) ──────────────────────────────────────

    let continuity_authority_status_t = Ty::Con(TyCon::new("ContinuityAuthorityStatus"));
    let continuity_record_t = Ty::Con(TyCon::new("ContinuityRecord"));
    let continuity_submit_decision_t = Ty::Con(TyCon::new("ContinuitySubmitDecision"));
    let bootstrap_status_t = Ty::Con(TyCon::new("BootstrapStatus"));

    // Builtin continuity/bootstrap payload structs are available as type annotations.
    env.insert("BootstrapStatus".into(), Scheme::mono(bootstrap_status_t));
    env.insert(
        "ContinuityAuthorityStatus".into(),
        Scheme::mono(continuity_authority_status_t.clone()),
    );
    env.insert(
        "ContinuityRecord".into(),
        Scheme::mono(continuity_record_t.clone()),
    );
    env.insert(
        "ContinuitySubmitDecision".into(),
        Scheme::mono(continuity_submit_decision_t.clone()),
    );

    // Module-qualified: Continuity.submit -> prefixed "continuity_submit".
    env.insert(
        "continuity_submit".into(),
        Scheme::mono(Ty::fun(
            vec![
                Ty::string(),
                Ty::string(),
                Ty::string(),
                Ty::string(),
                Ty::string(),
                Ty::int(),
                Ty::bool(),
                Ty::bool(),
            ],
            Ty::result(continuity_submit_decision_t.clone(), Ty::string()),
        )),
    );
    env.insert(
        "continuity_submit_declared_work".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::string(), Ty::string(), Ty::string(), Ty::int()],
            Ty::result(continuity_submit_decision_t.clone(), Ty::string()),
        )),
    );
    env.insert(
        "continuity_status".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::string()],
            Ty::result(continuity_record_t.clone(), Ty::string()),
        )),
    );
    env.insert(
        "continuity_authority_status".into(),
        Scheme::mono(Ty::fun(
            vec![],
            Ty::result(continuity_authority_status_t.clone(), Ty::string()),
        )),
    );
    env.insert(
        "continuity_mark_completed".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::string(), Ty::string(), Ty::string()],
            Ty::result(continuity_record_t.clone(), Ty::string()),
        )),
    );
    env.insert(
        "continuity_acknowledge_replica".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::string(), Ty::string()],
            Ty::result(continuity_record_t, Ty::string()),
        )),
    );

    // ── Standard library: Collection types (Phase 8) ─────────────────

    // Type constructors for collection types (bare names).
    env.insert("List".into(), Scheme::mono(Ty::list_untyped()));
    env.insert("Map".into(), Scheme::mono(Ty::map_untyped()));
    env.insert("Set".into(), Scheme::mono(Ty::Con(TyCon::new("Set"))));
    env.insert("Range".into(), Scheme::mono(Ty::range()));
    env.insert("Queue".into(), Scheme::mono(Ty::Con(TyCon::new("Queue"))));

    // Use opaque types (untyped) for non-list collection function signatures.
    // At the LLVM level these are all pointers; type safety is checked by Mesh's type system.
    let map_t = Ty::map_untyped();
    let range_t = Ty::range();

    // ── Polymorphic List functions ──────────────────────────────────────
    // List functions use TyVar(91000) for T and TyVar(91001) for U
    // (avoids collision with Map's 90000/90001 and Default's 99000).
    {
        let t_var = TyVar(91000);
        let u_var = TyVar(91001);
        let t = Ty::Var(t_var);
        let u = Ty::Var(u_var);
        let list_t = Ty::list(t.clone());
        let list_u = Ty::list(u.clone());
        let t_to_u = Ty::fun(vec![t.clone()], u.clone());
        let t_to_bool = Ty::fun(vec![t.clone()], Ty::bool());
        let u_t_to_u = Ty::fun(vec![u.clone(), t.clone()], u.clone());

        // ── Prelude (bare names): map, filter, reduce, head, tail ─────────
        // These are auto-imported without module qualification.

        // map(list, fn) -> list  (bare prelude name)
        env.insert(
            "map".into(),
            Scheme {
                vars: vec![t_var, u_var],
                ty: Ty::fun(vec![list_t.clone(), t_to_u.clone()], list_u.clone()),
            },
        );
        // filter(list, fn) -> list
        env.insert(
            "filter".into(),
            Scheme {
                vars: vec![t_var],
                ty: Ty::fun(vec![list_t.clone(), t_to_bool.clone()], list_t.clone()),
            },
        );
        // reduce(list, init, fn) -> U
        env.insert(
            "reduce".into(),
            Scheme {
                vars: vec![t_var, u_var],
                ty: Ty::fun(vec![list_t.clone(), u.clone(), u_t_to_u.clone()], u.clone()),
            },
        );
        // head(list) -> T
        env.insert(
            "head".into(),
            Scheme {
                vars: vec![t_var],
                ty: Ty::fun(vec![list_t.clone()], t.clone()),
            },
        );
        // tail(list) -> List<T>
        env.insert(
            "tail".into(),
            Scheme {
                vars: vec![t_var],
                ty: Ty::fun(vec![list_t.clone()], list_t.clone()),
            },
        );

        // Also register with list_ prefix for module-qualified lowering.
        env.insert(
            "list_map".into(),
            Scheme {
                vars: vec![t_var, u_var],
                ty: Ty::fun(vec![list_t.clone(), t_to_u.clone()], list_u.clone()),
            },
        );
        env.insert(
            "list_filter".into(),
            Scheme {
                vars: vec![t_var],
                ty: Ty::fun(vec![list_t.clone(), t_to_bool.clone()], list_t.clone()),
            },
        );
        env.insert(
            "list_reduce".into(),
            Scheme {
                vars: vec![t_var, u_var],
                ty: Ty::fun(vec![list_t.clone(), u.clone(), u_t_to_u.clone()], u.clone()),
            },
        );
        env.insert(
            "list_head".into(),
            Scheme {
                vars: vec![t_var],
                ty: Ty::fun(vec![list_t.clone()], t.clone()),
            },
        );
        env.insert(
            "list_tail".into(),
            Scheme {
                vars: vec![t_var],
                ty: Ty::fun(vec![list_t.clone()], list_t.clone()),
            },
        );

        // ── List module functions ─────────────────────────────────────────

        // List.new() -> List<T>
        env.insert(
            "list_new".into(),
            Scheme {
                vars: vec![t_var],
                ty: Ty::fun(vec![], list_t.clone()),
            },
        );
        // List.length(List<T>) -> Int
        env.insert(
            "list_length".into(),
            Scheme {
                vars: vec![t_var],
                ty: Ty::fun(vec![list_t.clone()], Ty::int()),
            },
        );
        // List.append(List<T>, T) -> List<T>
        env.insert(
            "list_append".into(),
            Scheme {
                vars: vec![t_var],
                ty: Ty::fun(vec![list_t.clone(), t.clone()], list_t.clone()),
            },
        );
        // List.get(List<T>, Int) -> T
        env.insert(
            "list_get".into(),
            Scheme {
                vars: vec![t_var],
                ty: Ty::fun(vec![list_t.clone(), Ty::int()], t.clone()),
            },
        );
        // List.concat(List<T>, List<T>) -> List<T>
        env.insert(
            "list_concat".into(),
            Scheme {
                vars: vec![t_var],
                ty: Ty::fun(vec![list_t.clone(), list_t.clone()], list_t.clone()),
            },
        );
        // List.reverse(List<T>) -> List<T>
        env.insert(
            "list_reverse".into(),
            Scheme {
                vars: vec![t_var],
                ty: Ty::fun(vec![list_t.clone()], list_t.clone()),
            },
        );

        // Phase 46: sort, find, any, all, contains
        let t_t_to_int = Ty::fun(vec![t.clone(), t.clone()], Ty::int());
        env.insert(
            "list_sort".into(),
            Scheme {
                vars: vec![t_var],
                ty: Ty::fun(vec![list_t.clone(), t_t_to_int], list_t.clone()),
            },
        );
        env.insert(
            "list_find".into(),
            Scheme {
                vars: vec![t_var],
                ty: Ty::fun(
                    vec![list_t.clone(), t_to_bool.clone()],
                    Ty::option(t.clone()),
                ),
            },
        );
        env.insert(
            "list_any".into(),
            Scheme {
                vars: vec![t_var],
                ty: Ty::fun(vec![list_t.clone(), t_to_bool.clone()], Ty::bool()),
            },
        );
        env.insert(
            "list_all".into(),
            Scheme {
                vars: vec![t_var],
                ty: Ty::fun(vec![list_t.clone(), t_to_bool.clone()], Ty::bool()),
            },
        );
        env.insert(
            "list_contains".into(),
            Scheme {
                vars: vec![t_var],
                ty: Ty::fun(vec![list_t.clone(), t.clone()], Ty::bool()),
            },
        );

        // Phase 47: zip, flat_map, flatten, enumerate, take, drop, last, nth
        env.insert(
            "list_zip".into(),
            Scheme {
                vars: vec![t_var, u_var],
                ty: Ty::fun(
                    vec![list_t.clone(), list_u.clone()],
                    Ty::list(Ty::Tuple(vec![t.clone(), u.clone()])),
                ),
            },
        );
        let t_to_list_u = Ty::fun(vec![t.clone()], list_u.clone());
        env.insert(
            "list_flat_map".into(),
            Scheme {
                vars: vec![t_var, u_var],
                ty: Ty::fun(vec![list_t.clone(), t_to_list_u], list_u.clone()),
            },
        );
        env.insert(
            "list_flatten".into(),
            Scheme {
                vars: vec![t_var],
                ty: Ty::fun(vec![Ty::list(list_t.clone())], list_t.clone()),
            },
        );
        env.insert(
            "list_enumerate".into(),
            Scheme {
                vars: vec![t_var],
                ty: Ty::fun(
                    vec![list_t.clone()],
                    Ty::list(Ty::Tuple(vec![Ty::int(), t.clone()])),
                ),
            },
        );
        env.insert(
            "list_take".into(),
            Scheme {
                vars: vec![t_var],
                ty: Ty::fun(vec![list_t.clone(), Ty::int()], list_t.clone()),
            },
        );
        env.insert(
            "list_drop".into(),
            Scheme {
                vars: vec![t_var],
                ty: Ty::fun(vec![list_t.clone(), Ty::int()], list_t.clone()),
            },
        );
        env.insert(
            "list_last".into(),
            Scheme {
                vars: vec![t_var],
                ty: Ty::fun(vec![list_t.clone()], t.clone()),
            },
        );
        env.insert(
            "list_nth".into(),
            Scheme {
                vars: vec![t_var],
                ty: Ty::fun(vec![list_t.clone(), Ty::int()], t.clone()),
            },
        );
    }

    // ── Map module functions (polymorphic) ──────────────────────────────
    {
        let k_var = TyVar(90000);
        let v_var = TyVar(90001);
        let k = Ty::Var(k_var);
        let v = Ty::Var(v_var);
        let map_kv = Ty::map(k.clone(), v.clone());

        env.insert(
            "map_new".into(),
            Scheme {
                vars: vec![k_var, v_var],
                ty: Ty::fun(vec![], map_kv.clone()),
            },
        );
        env.insert(
            "map_put".into(),
            Scheme {
                vars: vec![k_var, v_var],
                ty: Ty::fun(vec![map_kv.clone(), k.clone(), v.clone()], map_kv.clone()),
            },
        );
        env.insert(
            "map_get".into(),
            Scheme {
                vars: vec![k_var, v_var],
                ty: Ty::fun(vec![map_kv.clone(), k.clone()], v.clone()),
            },
        );
        env.insert(
            "map_has_key".into(),
            Scheme {
                vars: vec![k_var, v_var],
                ty: Ty::fun(vec![map_kv.clone(), k.clone()], Ty::bool()),
            },
        );
        env.insert(
            "map_delete".into(),
            Scheme {
                vars: vec![k_var, v_var],
                ty: Ty::fun(vec![map_kv.clone(), k.clone()], map_kv.clone()),
            },
        );
        env.insert(
            "map_size".into(),
            Scheme {
                vars: vec![k_var, v_var],
                ty: Ty::fun(vec![map_kv.clone()], Ty::int()),
            },
        );
        env.insert(
            "map_keys".into(),
            Scheme {
                vars: vec![k_var, v_var],
                ty: Ty::fun(vec![map_kv.clone()], Ty::list(k.clone())),
            },
        );
        env.insert(
            "map_values".into(),
            Scheme {
                vars: vec![k_var, v_var],
                ty: Ty::fun(vec![map_kv.clone()], Ty::list(v.clone())),
            },
        );
        // Phase 47: merge, to_list, from_list
        env.insert(
            "map_merge".into(),
            Scheme {
                vars: vec![k_var, v_var],
                ty: Ty::fun(vec![map_kv.clone(), map_kv.clone()], map_kv.clone()),
            },
        );
        env.insert(
            "map_to_list".into(),
            Scheme {
                vars: vec![k_var, v_var],
                ty: Ty::fun(
                    vec![map_kv.clone()],
                    Ty::list(Ty::Tuple(vec![k.clone(), v.clone()])),
                ),
            },
        );
        env.insert(
            "map_from_list".into(),
            Scheme {
                vars: vec![k_var, v_var],
                ty: Ty::fun(
                    vec![Ty::list(Ty::Tuple(vec![k.clone(), v.clone()]))],
                    map_kv.clone(),
                ),
            },
        );
    }

    // ── Set and Queue module functions (`set_add`, `queue_push`, ...) ──

    let (set_fns, queue_fns) = set_and_queue_functions();
    for (name, scheme) in set_fns {
        env.insert(format!("set_{name}"), scheme);
    }
    for (name, scheme) in queue_fns {
        env.insert(format!("queue_{name}"), scheme);
    }

    // ── Tuple module functions ────────────────────────────────────────

    env.insert(
        "tuple_nth".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::Con(TyCon::new("Tuple")), Ty::int()],
            Ty::int(),
        )),
    );
    env.insert(
        "tuple_first".into(),
        Scheme::mono(Ty::fun(vec![Ty::Con(TyCon::new("Tuple"))], Ty::int())),
    );
    env.insert(
        "tuple_second".into(),
        Scheme::mono(Ty::fun(vec![Ty::Con(TyCon::new("Tuple"))], Ty::int())),
    );
    env.insert(
        "tuple_size".into(),
        Scheme::mono(Ty::fun(vec![Ty::Con(TyCon::new("Tuple"))], Ty::int())),
    );

    // ── Range module functions ────────────────────────────────────────
    let int_list = Ty::list(Ty::int());
    let int_to_bool = Ty::fun(vec![Ty::int()], Ty::bool());

    env.insert(
        "range_new".into(),
        Scheme::mono(Ty::fun(vec![Ty::int(), Ty::int()], range_t.clone())),
    );
    env.insert(
        "range_to_list".into(),
        Scheme::mono(Ty::fun(vec![range_t.clone()], int_list.clone())),
    );
    // `Range.map` makes a list of whatever its function returns.
    let u_var = TyVar(91001);
    env.insert(
        "range_map".into(),
        Scheme {
            vars: vec![u_var],
            ty: Ty::fun(
                vec![range_t.clone(), Ty::fun(vec![Ty::int()], Ty::Var(u_var))],
                Ty::list(Ty::Var(u_var)),
            ),
        },
    );
    env.insert(
        "range_filter".into(),
        Scheme::mono(Ty::fun(vec![range_t.clone(), int_to_bool], int_list)),
    );
    env.insert(
        "range_length".into(),
        Scheme::mono(Ty::fun(vec![range_t.clone()], Ty::int())),
    );

    // ── Standard library: JSON functions (Phase 8 Plan 04) ────────────

    // Json type is opaque (Ptr) -- pattern matching on Json sum type deferred
    let json_t = Ty::Con(TyCon::new("Json"));
    env.insert("Json".into(), Scheme::mono(json_t.clone()));

    // JSON.parse(string) -> Result<Json, String>
    env.insert(
        "json_parse".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::string()],
            Ty::result(json_t.clone(), Ty::string()),
        )),
    );
    // JSON.encode(json) -> String
    env.insert(
        "json_encode".into(),
        Scheme::mono(Ty::fun(vec![json_t.clone()], Ty::string())),
    );
    // JSON.encode_string(string) -> String
    env.insert(
        "json_encode_string".into(),
        Scheme::mono(Ty::fun(vec![Ty::string()], Ty::string())),
    );
    // JSON.encode_int(int) -> String
    env.insert(
        "json_encode_int".into(),
        Scheme::mono(Ty::fun(vec![Ty::int()], Ty::string())),
    );
    // JSON.encode_bool(bool) -> String
    env.insert(
        "json_encode_bool".into(),
        Scheme::mono(Ty::fun(vec![Ty::bool()], Ty::string())),
    );
    // JSON.encode_map(map) -> String
    env.insert(
        "json_encode_map".into(),
        Scheme::mono(Ty::fun(vec![map_t.clone()], Ty::string())),
    );
    // JSON.encode_list(list) -> String
    env.insert(
        "json_encode_list".into(),
        Scheme::mono(Ty::fun(vec![Ty::list_untyped()], Ty::string())),
    );
    env.insert(
        "json_object_get".into(),
        Scheme::mono(Ty::fun(
            vec![json_t.clone(), Ty::string()],
            Ty::result(json_t.clone(), Ty::string()),
        )),
    );
    env.insert(
        "json_array_get".into(),
        Scheme::mono(Ty::fun(
            vec![json_t.clone(), Ty::int()],
            Ty::result(json_t.clone(), Ty::string()),
        )),
    );
    env.insert(
        "json_array_length".into(),
        Scheme::mono(Ty::fun(
            vec![json_t.clone()],
            Ty::result(Ty::int(), Ty::string()),
        )),
    );
    env.insert(
        "json_is_null".into(),
        Scheme::mono(Ty::fun(vec![json_t.clone()], Ty::bool())),
    );
    for (name, value) in [
        ("json_as_int", Ty::int()),
        ("json_as_float", Ty::float()),
        ("json_as_string", Ty::string()),
        ("json_as_bool", Ty::bool()),
    ] {
        env.insert(
            name.into(),
            Scheme::mono(Ty::fun(
                vec![json_t.clone()],
                Ty::result(value, Ty::string()),
            )),
        );
    }

    // ── Standard library: HTTP functions (Phase 8 Plan 05) ────────────

    // HTTP types (opaque, resolve to MirType::Ptr at codegen level)
    let request_t = Ty::Con(TyCon::new("Request"));
    let response_t = Ty::Con(TyCon::new("Response"));
    let router_t = Ty::Con(TyCon::new("Router"));
    env.insert("Request".into(), Scheme::mono(request_t.clone()));
    env.insert("Response".into(), Scheme::mono(response_t.clone()));
    env.insert("Router".into(), Scheme::mono(router_t.clone()));

    // HTTP.router() -> Router
    env.insert(
        "http_router".into(),
        Scheme::mono(Ty::fun(vec![], router_t.clone())),
    );
    // HTTP.route(Router, String, (Request) -> Response) -> Router
    env.insert(
        "http_route".into(),
        Scheme::mono(Ty::fun(
            vec![
                router_t.clone(),
                Ty::string(),
                Ty::fun(vec![request_t.clone()], response_t.clone()),
            ],
            router_t.clone(),
        )),
    );
    // HTTP.serve(Router, Int) -> ()
    env.insert(
        "http_serve".into(),
        Scheme::mono(Ty::fun(
            vec![router_t.clone(), Ty::int()],
            Ty::Tuple(vec![]),
        )),
    );
    // HTTP.serve_tls(Router, Int, String, String) -> () (Phase 56)
    env.insert(
        "http_serve_tls".into(),
        Scheme::mono(Ty::fun(
            vec![router_t.clone(), Ty::int(), Ty::string(), Ty::string()],
            Ty::Tuple(vec![]),
        )),
    );
    // HTTP.response(Int, String) -> Response
    env.insert(
        "http_response".into(),
        Scheme::mono(Ty::fun(vec![Ty::int(), Ty::string()], response_t.clone())),
    );
    env.insert(
        "http_response_bytes".into(),
        Scheme::mono(Ty::fun(vec![Ty::int(), Ty::bytes()], response_t.clone())),
    );
    env.insert(
        "http_response_bytes_with_headers".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::int(), Ty::bytes(), Ty::map(Ty::string(), Ty::string())],
            response_t.clone(),
        )),
    );
    // HTTP.response_with_headers(Int, String, Map<K, V>) -> Response
    {
        let k_var = TyVar(92000);
        let v_var = TyVar(92001);
        let k = Ty::Var(k_var);
        let v = Ty::Var(v_var);
        let map_kv = Ty::map(k, v);
        env.insert(
            "http_response_with_headers".into(),
            Scheme {
                vars: vec![k_var, v_var],
                ty: Ty::fun(vec![Ty::int(), Ty::string(), map_kv], response_t.clone()),
            },
        );
    }
    // ── Phase 51: Method-specific routing ────────────────────────────────
    // HTTP.on_get(Router, String, Fn(Request) -> Response) -> Router
    env.insert(
        "http_on_get".into(),
        Scheme::mono(Ty::fun(
            vec![
                router_t.clone(),
                Ty::string(),
                Ty::fun(vec![request_t.clone()], response_t.clone()),
            ],
            router_t.clone(),
        )),
    );
    // HTTP.on_post(Router, String, Fn(Request) -> Response) -> Router
    env.insert(
        "http_on_post".into(),
        Scheme::mono(Ty::fun(
            vec![
                router_t.clone(),
                Ty::string(),
                Ty::fun(vec![request_t.clone()], response_t.clone()),
            ],
            router_t.clone(),
        )),
    );
    // HTTP.on_put(Router, String, Fn(Request) -> Response) -> Router
    env.insert(
        "http_on_put".into(),
        Scheme::mono(Ty::fun(
            vec![
                router_t.clone(),
                Ty::string(),
                Ty::fun(vec![request_t.clone()], response_t.clone()),
            ],
            router_t.clone(),
        )),
    );
    // HTTP.on_delete(Router, String, Fn(Request) -> Response) -> Router
    env.insert(
        "http_on_delete".into(),
        Scheme::mono(Ty::fun(
            vec![
                router_t.clone(),
                Ty::string(),
                Ty::fun(vec![request_t.clone()], response_t.clone()),
            ],
            router_t.clone(),
        )),
    );

    // ── Phase 52: HTTP.use(Router, Fn(Request, Fn(Request) -> Response) -> Response) -> Router
    env.insert(
        "http_use".into(),
        Scheme::mono(Ty::fun(
            vec![
                router_t.clone(),
                Ty::fun(
                    vec![
                        request_t.clone(),
                        Ty::fun(vec![request_t.clone()], response_t.clone()),
                    ],
                    response_t.clone(),
                ),
            ],
            router_t.clone(),
        )),
    );

    // ── Phase 53: SQLite functions ──────────────────────────────────────
    // SqliteConn opaque type -- lowered to Int (i64) at MIR level for GC safety.
    let sqlite_conn_t = Ty::Con(TyCon::new("SqliteConn"));
    env.insert("SqliteConn".into(), Scheme::mono(sqlite_conn_t.clone()));

    // Sqlite.open(String) -> Result<SqliteConn, String>
    env.insert(
        "sqlite_open".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::string()],
            Ty::result(sqlite_conn_t.clone(), Ty::string()),
        )),
    );
    // Sqlite.close(SqliteConn) -> Unit
    env.insert(
        "sqlite_close".into(),
        Scheme::mono(Ty::fun(vec![sqlite_conn_t.clone()], Ty::Tuple(vec![]))),
    );
    // Sqlite.execute(SqliteConn, String, List<String>) -> Result<Int, String>
    env.insert(
        "sqlite_execute".into(),
        Scheme::mono(Ty::fun(
            vec![sqlite_conn_t.clone(), Ty::string(), Ty::list(Ty::string())],
            Ty::result(Ty::int(), Ty::string()),
        )),
    );
    // Sqlite.query(SqliteConn, String, List<String>) -> Result<List<Map<String, String>>, String>
    env.insert(
        "sqlite_query".into(),
        Scheme::mono(Ty::fun(
            vec![sqlite_conn_t.clone(), Ty::string(), Ty::list(Ty::string())],
            Ty::result(Ty::list(Ty::map(Ty::string(), Ty::string())), Ty::string()),
        )),
    );
    env.insert(
        "sqlite_execute_values".into(),
        Scheme::mono(Ty::fun(
            vec![
                sqlite_conn_t.clone(),
                Ty::string(),
                Ty::list(Ty::db_value()),
            ],
            Ty::result(Ty::int(), Ty::string()),
        )),
    );
    env.insert(
        "sqlite_query_values".into(),
        Scheme::mono(Ty::fun(
            vec![
                sqlite_conn_t.clone(),
                Ty::string(),
                Ty::list(Ty::db_value()),
            ],
            Ty::result(
                Ty::list(Ty::map(Ty::string(), Ty::db_value())),
                Ty::string(),
            ),
        )),
    );

    // ── Phase 54: PostgreSQL functions ─────────────────────────────────────
    // PgConn opaque type -- lowered to Int (i64) at MIR level for GC safety.
    let pg_conn_t = Ty::Con(TyCon::new("PgConn"));
    env.insert("PgConn".into(), Scheme::mono(pg_conn_t.clone()));

    // Pg.connect(String) -> Result<PgConn, String>
    env.insert(
        "pg_connect".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::string()],
            Ty::result(pg_conn_t.clone(), Ty::string()),
        )),
    );
    // Pg.close(PgConn) -> Unit
    env.insert(
        "pg_close".into(),
        Scheme::mono(Ty::fun(vec![pg_conn_t.clone()], Ty::Tuple(vec![]))),
    );
    // Pg.execute(PgConn, String, List<String>) -> Result<Int, String>
    env.insert(
        "pg_execute".into(),
        Scheme::mono(Ty::fun(
            vec![pg_conn_t.clone(), Ty::string(), Ty::list(Ty::string())],
            Ty::result(Ty::int(), Ty::string()),
        )),
    );
    // Pg.query(PgConn, String, List<String>) -> Result<List<Map<String, String>>, String>
    env.insert(
        "pg_query".into(),
        Scheme::mono(Ty::fun(
            vec![pg_conn_t.clone(), Ty::string(), Ty::list(Ty::string())],
            Ty::result(Ty::list(Ty::map(Ty::string(), Ty::string())), Ty::string()),
        )),
    );
    env.insert(
        "pg_execute_values".into(),
        Scheme::mono(Ty::fun(
            vec![pg_conn_t.clone(), Ty::string(), Ty::list(Ty::db_value())],
            Ty::result(Ty::int(), Ty::string()),
        )),
    );
    env.insert(
        "pg_query_values".into(),
        Scheme::mono(Ty::fun(
            vec![pg_conn_t.clone(), Ty::string(), Ty::list(Ty::db_value())],
            Ty::result(
                Ty::list(Ty::map(Ty::string(), Ty::db_value())),
                Ty::string(),
            ),
        )),
    );

    // ── Phase 57: PG Transaction functions ──────────────────────────
    // Pg.begin(PgConn) -> Result<Unit, String>
    env.insert(
        "pg_begin".into(),
        Scheme::mono(Ty::fun(
            vec![pg_conn_t.clone()],
            Ty::result(Ty::Tuple(vec![]), Ty::string()),
        )),
    );
    // Pg.commit(PgConn) -> Result<Unit, String>
    env.insert(
        "pg_commit".into(),
        Scheme::mono(Ty::fun(
            vec![pg_conn_t.clone()],
            Ty::result(Ty::Tuple(vec![]), Ty::string()),
        )),
    );
    // Pg.rollback(PgConn) -> Result<Unit, String>
    env.insert(
        "pg_rollback".into(),
        Scheme::mono(Ty::fun(
            vec![pg_conn_t.clone()],
            Ty::result(Ty::Tuple(vec![]), Ty::string()),
        )),
    );
    // Pg.transaction(PgConn, fn(PgConn) -> Result<Unit, String>) -> Result<Unit, String>
    env.insert(
        "pg_transaction".into(),
        Scheme::mono(Ty::fun(
            vec![
                pg_conn_t.clone(),
                Ty::fun(
                    vec![pg_conn_t.clone()],
                    Ty::result(Ty::Tuple(vec![]), Ty::string()),
                ),
            ],
            Ty::result(Ty::Tuple(vec![]), Ty::string()),
        )),
    );

    // ── Phase 57: SQLite Transaction functions ──────────────────────
    // Sqlite.begin(SqliteConn) -> Result<Unit, String>
    env.insert(
        "sqlite_begin".into(),
        Scheme::mono(Ty::fun(
            vec![sqlite_conn_t.clone()],
            Ty::result(Ty::Tuple(vec![]), Ty::string()),
        )),
    );
    // Sqlite.commit(SqliteConn) -> Result<Unit, String>
    env.insert(
        "sqlite_commit".into(),
        Scheme::mono(Ty::fun(
            vec![sqlite_conn_t.clone()],
            Ty::result(Ty::Tuple(vec![]), Ty::string()),
        )),
    );
    // Sqlite.rollback(SqliteConn) -> Result<Unit, String>
    env.insert(
        "sqlite_rollback".into(),
        Scheme::mono(Ty::fun(
            vec![sqlite_conn_t.clone()],
            Ty::result(Ty::Tuple(vec![]), Ty::string()),
        )),
    );

    // ── Phase 57: Connection Pool ───────────────────────────────────
    // PoolHandle opaque type
    let pool_handle_t = Ty::Con(TyCon::new("PoolHandle"));
    env.insert("PoolHandle".into(), Scheme::mono(pool_handle_t.clone()));

    // Pool.open(String, Int, Int, Int) -> Result<PoolHandle, String>
    env.insert(
        "pool_open".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::string(), Ty::int(), Ty::int(), Ty::int()],
            Ty::result(pool_handle_t.clone(), Ty::string()),
        )),
    );
    // Pool.close(PoolHandle) -> Unit
    env.insert(
        "pool_close".into(),
        Scheme::mono(Ty::fun(vec![pool_handle_t.clone()], Ty::Tuple(vec![]))),
    );
    // Pool.query(PoolHandle, String, List<String>) -> Result<List<Map<String, String>>, String>
    env.insert(
        "pool_query".into(),
        Scheme::mono(Ty::fun(
            vec![pool_handle_t.clone(), Ty::string(), Ty::list(Ty::string())],
            Ty::result(Ty::list(Ty::map(Ty::string(), Ty::string())), Ty::string()),
        )),
    );
    // Pool.execute(PoolHandle, String, List<String>) -> Result<Int, String>
    env.insert(
        "pool_execute".into(),
        Scheme::mono(Ty::fun(
            vec![pool_handle_t.clone(), Ty::string(), Ty::list(Ty::string())],
            Ty::result(Ty::int(), Ty::string()),
        )),
    );
    env.insert(
        "pool_query_values".into(),
        Scheme::mono(Ty::fun(
            vec![
                pool_handle_t.clone(),
                Ty::string(),
                Ty::list(Ty::db_value()),
            ],
            Ty::result(
                Ty::list(Ty::map(Ty::string(), Ty::db_value())),
                Ty::string(),
            ),
        )),
    );
    env.insert(
        "pool_execute_values".into(),
        Scheme::mono(Ty::fun(
            vec![
                pool_handle_t.clone(),
                Ty::string(),
                Ty::list(Ty::db_value()),
            ],
            Ty::result(Ty::int(), Ty::string()),
        )),
    );

    // Request accessor functions
    // Request.method(Request) -> String
    env.insert(
        "request_method".into(),
        Scheme::mono(Ty::fun(vec![request_t.clone()], Ty::string())),
    );
    // Request.path(Request) -> String
    env.insert(
        "request_path".into(),
        Scheme::mono(Ty::fun(vec![request_t.clone()], Ty::string())),
    );
    // Request.body(Request) -> String
    env.insert(
        "request_body".into(),
        Scheme::mono(Ty::fun(vec![request_t.clone()], Ty::string())),
    );
    env.insert(
        "request_body_bytes".into(),
        Scheme::mono(Ty::fun(vec![request_t.clone()], Ty::bytes())),
    );
    // Request.header(Request, String) -> Option<String>
    env.insert(
        "request_header".into(),
        Scheme::mono(Ty::fun(
            vec![request_t.clone(), Ty::string()],
            Ty::option(Ty::string()),
        )),
    );
    // Request.query(Request, String) -> Option<String>
    env.insert(
        "request_query".into(),
        Scheme::mono(Ty::fun(
            vec![request_t.clone(), Ty::string()],
            Ty::option(Ty::string()),
        )),
    );
    // Request.param(Request, String) -> Option<String>
    env.insert(
        "request_param".into(),
        Scheme::mono(Ty::fun(
            vec![request_t.clone(), Ty::string()],
            Ty::option(Ty::string()),
        )),
    );
    // HTTP.request_id(Request) -> String
    env.insert(
        "http_request_id".into(),
        Scheme::mono(Ty::fun(vec![request_t.clone()], Ty::string())),
    );
    // HTTP.idempotency_key(Request) -> Option<String>
    env.insert(
        "http_idempotency_key".into(),
        Scheme::mono(Ty::fun(vec![request_t.clone()], Ty::option(Ty::string()))),
    );
    env.insert(
        "cluster_capacity".into(),
        Scheme::mono(Ty::fun(vec![], Ty::map(Ty::string(), Ty::int()))),
    );
    env.insert(
        "cluster_pressure".into(),
        Scheme::mono(Ty::fun(vec![], Ty::map(Ty::string(), Ty::string()))),
    );
    env.insert(
        "cluster_telemetry".into(),
        Scheme::mono(Ty::fun(vec![], Ty::map(Ty::string(), Ty::int()))),
    );
    env.insert(
        "cluster_role".into(),
        Scheme::mono(Ty::fun(vec![], Ty::string())),
    );
    env.insert(
        "cluster_state".into(),
        Scheme::mono(Ty::fun(vec![], Ty::string())),
    );

    // ── Phase 138: Test DSL builtins ─────────────────────────────────────────
    //
    // These builtins are available in ALL .mpl source files (not just .test.mpl).
    // They're registered globally so typeck doesn't reject them. The lowerer
    // (mesh-codegen) intercepts them in test mode and expands them to proper
    // mesh_test_assert_* runtime calls. In non-test mode they're mapped to
    // the runtime functions via map_builtin_name (no-op unless is_test_mode).
    let unit_t = Ty::Tuple(vec![]);
    let bool_t = Ty::bool();
    let str_t = Ty::string();

    // assert(cond: Bool) -> Unit
    env.insert(
        "assert".into(),
        Scheme::mono(Ty::fun(vec![bool_t.clone()], unit_t.clone())),
    );

    // assert_eq(lhs: T, rhs: T) -> Unit and assert_ne: both sides share a type,
    // and the lowerer compares them as string interpolation would show them.
    for (name, var) in [("assert_eq", TyVar(99003)), ("assert_ne", TyVar(99004))] {
        env.insert(
            name.into(),
            Scheme {
                vars: vec![var],
                ty: Ty::fun(vec![Ty::Var(var), Ty::Var(var)], unit_t.clone()),
            },
        );
    }

    // assert_raises(fn: fn() -> Unit) -> Unit
    let raise_cb = Ty::fun(vec![], unit_t.clone());
    env.insert(
        "assert_raises".into(),
        Scheme::mono(Ty::fun(vec![raise_cb], unit_t.clone())),
    );

    // test(label: String, body: fn() -> Unit) -> Unit
    let test_cb = Ty::fun(vec![], unit_t.clone());
    env.insert(
        "test".into(),
        Scheme::mono(Ty::fun(vec![str_t.clone(), test_cb], unit_t.clone())),
    );

    // describe(label: String, body: fn() -> Unit) -> Unit
    let describe_cb = Ty::fun(vec![], unit_t.clone());
    env.insert(
        "describe".into(),
        Scheme::mono(Ty::fun(vec![str_t.clone(), describe_cb], unit_t.clone())),
    );

    // setup(body: fn() -> Unit) -> Unit
    let setup_cb = Ty::fun(vec![], unit_t.clone());
    env.insert(
        "setup".into(),
        Scheme::mono(Ty::fun(vec![setup_cb], unit_t.clone())),
    );

    // teardown(body: fn() -> Unit) -> Unit
    let teardown_cb = Ty::fun(vec![], unit_t.clone());
    env.insert(
        "teardown".into(),
        Scheme::mono(Ty::fun(vec![teardown_cb], unit_t.clone())),
    );

    // test_fail_msg(msg: String) -> Unit
    // Records a test failure with the given message. Available in test body fns
    // (including those generated by the assert_receive preprocessor).
    env.insert(
        "test_fail_msg".into(),
        Scheme::mono(Ty::fun(vec![str_t.clone()], unit_t.clone())),
    );

    // test_run_body(body: fn() -> Unit) -> Unit
    // (used by the generated harness in fn main())
    let run_body_cb = Ty::fun(vec![], unit_t.clone());
    env.insert(
        "test_run_body".into(),
        Scheme::mono(Ty::fun(vec![run_body_cb], unit_t.clone())),
    );

    // test_end() -> Unit records the test's outcome.
    env.insert(
        "test_end".into(),
        Scheme::mono(Ty::fun(vec![], unit_t.clone())),
    );

    // test_begin(label: String) -> Unit
    env.insert(
        "test_begin".into(),
        Scheme::mono(Ty::fun(vec![str_t.clone()], unit_t.clone())),
    );

    // test_summary(passed: Int, failed: Int, elapsed_ms: Int) -> Unit
    env.insert(
        "test_summary".into(),
        Scheme::mono(Ty::fun(
            vec![Ty::int(), Ty::int(), Ty::int()],
            unit_t.clone(),
        )),
    );

    // test_cleanup_actors() -> Unit
    env.insert(
        "test_cleanup_actors".into(),
        Scheme::mono(Ty::fun(vec![], unit_t.clone())),
    );

    // test_pass_count() -> Int
    env.insert(
        "test_pass_count".into(),
        Scheme::mono(Ty::fun(vec![], Ty::int())),
    );

    // test_fail_count() -> Int
    env.insert(
        "test_fail_count".into(),
        Scheme::mono(Ty::fun(vec![], Ty::int())),
    );

    // assert_receive(timeout_ms: Int) -> Unit
    // Note: from typeck's perspective, assert_receive takes only a timeout argument.
    // The pattern argument is handled by the preprocessor in test_runner.rs.
    // This registration is defensive — the preprocessor transforms assert_receive
    // BEFORE typeck runs, so typeck sees a receive block, not assert_receive.
    env.insert(
        "assert_receive".into(),
        Scheme::mono(Ty::fun(vec![Ty::int()], unit_t.clone())),
    );
}

/// Register compiler-known traits and their built-in implementations.
///
/// These traits back the arithmetic and comparison operators. When the
/// inference engine encounters `a + b`, it checks that the resolved type
/// of `a` has an impl for `Add`.
fn register_compiler_known_traits(registry: &mut TraitRegistry) {
    // ── Arithmetic traits ──────────────────────────────────────────

    let arithmetic_traits = ["Add", "Sub", "Mul", "Div", "Mod"];
    for trait_name in &arithmetic_traits {
        registry.register_trait(TraitDef {
            name: trait_name.to_string(),
            methods: vec![TraitMethodSig {
                name: trait_name.to_lowercase(),
                has_self: true,
                param_count: 1,
                // The operator's result is the impl's `type Output`.
                return_type: Some(Ty::Con(TyCon::new("Self.Output"))),
                has_default_body: false,
                // The other operand, of the type, as the operator's is.
                param_types: Some(vec![Ty::Con(TyCon::new("Self"))]),
            }],
            associated_types: vec![AssocTypeDef {
                name: "Output".to_string(),
            }],
        });

        // Register impls for Int and Float.
        for (ty, ty_name) in &[(Ty::int(), "Int"), (Ty::float(), "Float")] {
            let mut methods = FxHashMap::default();
            methods.insert(
                trait_name.to_lowercase(),
                ImplMethodSig {
                    has_self: true,
                    param_count: 1,
                    return_type: Some(ty.clone()),
                    param_types: None,
                },
            );
            let mut assoc_types = FxHashMap::default();
            assoc_types.insert("Output".to_string(), ty.clone());
            let _ = registry.register_impl(ImplDef {
                trait_name: trait_name.to_string(),
                trait_type_args: vec![],
                impl_type: ty.clone(),
                impl_type_name: ty_name.to_string(),
                methods,
                associated_types: assoc_types,
            });
        }
    }

    // ── Neg trait ─────────────────────────────────────────────────

    registry.register_trait(TraitDef {
        name: "Neg".to_string(),
        methods: vec![TraitMethodSig {
            name: "neg".to_string(),
            has_self: true,
            param_count: 0,
            return_type: Some(Ty::Con(TyCon::new("Self.Output"))),
            has_default_body: false,
            param_types: None,
        }],
        associated_types: vec![AssocTypeDef {
            name: "Output".to_string(),
        }],
    });

    // Neg impls for Int and Float.
    for (ty, ty_name) in &[(Ty::int(), "Int"), (Ty::float(), "Float")] {
        let mut methods = FxHashMap::default();
        methods.insert(
            "neg".to_string(),
            ImplMethodSig {
                has_self: true,
                param_count: 0,
                return_type: Some(ty.clone()),
                param_types: None,
            },
        );
        let mut assoc_types = FxHashMap::default();
        assoc_types.insert("Output".to_string(), ty.clone());
        let _ = registry.register_impl(ImplDef {
            trait_name: "Neg".to_string(),
            trait_type_args: vec![],
            impl_type: ty.clone(),
            impl_type_name: ty_name.to_string(),
            methods,
            associated_types: assoc_types,
        });
    }

    // ── Iterator trait ──────────────────────────────────────────────

    registry.register_trait(TraitDef {
        name: "Iterator".to_string(),
        methods: vec![TraitMethodSig {
            name: "next".to_string(),
            has_self: true,
            param_count: 0,
            return_type: None, // Option<Self.Item> -- resolved per impl
            has_default_body: false,
            param_types: None,
        }],
        associated_types: vec![AssocTypeDef {
            name: "Item".to_string(),
        }],
    });

    // ── Iterable trait ─────────────────────────────────────────────

    registry.register_trait(TraitDef {
        name: "Iterable".to_string(),
        methods: vec![TraitMethodSig {
            name: "iter".to_string(),
            has_self: true,
            param_count: 0,
            return_type: None, // Self.Iter -- resolved per impl
            has_default_body: false,
            param_types: None,
        }],
        associated_types: vec![
            AssocTypeDef {
                name: "Item".to_string(),
            },
            AssocTypeDef {
                name: "Iter".to_string(),
            },
        ],
    });

    // ── Built-in Iterable impls for collections ────────────────────

    // impl Iterable for List<T>
    {
        let list_t = Ty::App(
            Box::new(Ty::Con(TyCon::new("List"))),
            vec![Ty::Con(TyCon::new("'T"))],
        );
        let mut methods = FxHashMap::default();
        methods.insert(
            "iter".to_string(),
            ImplMethodSig {
                has_self: true,
                param_count: 0,
                return_type: None,
                param_types: None,
            },
        );
        let mut assoc_types = FxHashMap::default();
        assoc_types.insert("Item".to_string(), Ty::Con(TyCon::new("'T")));
        assoc_types.insert("Iter".to_string(), Ty::Con(TyCon::new("ListIterator")));
        let _ = registry.register_impl(ImplDef {
            trait_name: "Iterable".to_string(),
            trait_type_args: vec![],
            impl_type: list_t,
            impl_type_name: "List".to_string(),
            methods,
            associated_types: assoc_types,
        });
    }

    // impl Iterator for ListIterator
    {
        let mut methods = FxHashMap::default();
        methods.insert(
            "next".to_string(),
            ImplMethodSig {
                has_self: true,
                param_count: 0,
                return_type: None,
                param_types: None,
            },
        );
        let mut assoc_types = FxHashMap::default();
        assoc_types.insert("Item".to_string(), Ty::Con(TyCon::new("'T")));
        let _ = registry.register_impl(ImplDef {
            trait_name: "Iterator".to_string(),
            trait_type_args: vec![],
            impl_type: Ty::Con(TyCon::new("ListIterator")),
            impl_type_name: "ListIterator".to_string(),
            methods,
            associated_types: assoc_types,
        });
    }

    // impl Iterable for Map<K,V>
    {
        let map_kv = Ty::App(
            Box::new(Ty::Con(TyCon::new("Map"))),
            vec![Ty::Con(TyCon::new("'K")), Ty::Con(TyCon::new("'V"))],
        );
        let mut methods = FxHashMap::default();
        methods.insert(
            "iter".to_string(),
            ImplMethodSig {
                has_self: true,
                param_count: 0,
                return_type: None,
                param_types: None,
            },
        );
        let mut assoc_types = FxHashMap::default();
        assoc_types.insert(
            "Item".to_string(),
            Ty::Tuple(vec![Ty::Con(TyCon::new("'K")), Ty::Con(TyCon::new("'V"))]),
        );
        assoc_types.insert("Iter".to_string(), Ty::Con(TyCon::new("MapIterator")));
        let _ = registry.register_impl(ImplDef {
            trait_name: "Iterable".to_string(),
            trait_type_args: vec![],
            impl_type: map_kv,
            impl_type_name: "Map".to_string(),
            methods,
            associated_types: assoc_types,
        });
    }

    // impl Iterator for MapIterator
    {
        let mut methods = FxHashMap::default();
        methods.insert(
            "next".to_string(),
            ImplMethodSig {
                has_self: true,
                param_count: 0,
                return_type: None,
                param_types: None,
            },
        );
        let mut assoc_types = FxHashMap::default();
        assoc_types.insert(
            "Item".to_string(),
            Ty::Tuple(vec![Ty::Con(TyCon::new("'K")), Ty::Con(TyCon::new("'V"))]),
        );
        let _ = registry.register_impl(ImplDef {
            trait_name: "Iterator".to_string(),
            trait_type_args: vec![],
            impl_type: Ty::Con(TyCon::new("MapIterator")),
            impl_type_name: "MapIterator".to_string(),
            methods,
            associated_types: assoc_types,
        });
    }

    // impl Iterable for Set<T>
    {
        let set_t = Ty::set(Ty::Con(TyCon::new("'T")));
        let mut methods = FxHashMap::default();
        methods.insert(
            "iter".to_string(),
            ImplMethodSig {
                has_self: true,
                param_count: 0,
                return_type: None,
                param_types: None,
            },
        );
        let mut assoc_types = FxHashMap::default();
        assoc_types.insert("Item".to_string(), Ty::Con(TyCon::new("'T")));
        assoc_types.insert("Iter".to_string(), Ty::Con(TyCon::new("SetIterator")));
        let _ = registry.register_impl(ImplDef {
            trait_name: "Iterable".to_string(),
            trait_type_args: vec![],
            impl_type: set_t,
            impl_type_name: "Set".to_string(),
            methods,
            associated_types: assoc_types,
        });
    }

    // impl Iterator for SetIterator
    {
        let mut methods = FxHashMap::default();
        methods.insert(
            "next".to_string(),
            ImplMethodSig {
                has_self: true,
                param_count: 0,
                return_type: None,
                param_types: None,
            },
        );
        let mut assoc_types = FxHashMap::default();
        assoc_types.insert("Item".to_string(), Ty::Con(TyCon::new("'T")));
        let _ = registry.register_impl(ImplDef {
            trait_name: "Iterator".to_string(),
            trait_type_args: vec![],
            impl_type: Ty::Con(TyCon::new("SetIterator")),
            impl_type_name: "SetIterator".to_string(),
            methods,
            associated_types: assoc_types,
        });
    }

    // impl Iterable for Range
    {
        let range_t = Ty::Con(TyCon::new("Range"));
        let mut methods = FxHashMap::default();
        methods.insert(
            "iter".to_string(),
            ImplMethodSig {
                has_self: true,
                param_count: 0,
                return_type: None,
                param_types: None,
            },
        );
        let mut assoc_types = FxHashMap::default();
        assoc_types.insert("Item".to_string(), Ty::int());
        assoc_types.insert("Iter".to_string(), Ty::Con(TyCon::new("RangeIterator")));
        let _ = registry.register_impl(ImplDef {
            trait_name: "Iterable".to_string(),
            trait_type_args: vec![],
            impl_type: range_t,
            impl_type_name: "Range".to_string(),
            methods,
            associated_types: assoc_types,
        });
    }

    // impl Iterator for RangeIterator
    {
        let mut methods = FxHashMap::default();
        methods.insert(
            "next".to_string(),
            ImplMethodSig {
                has_self: true,
                param_count: 0,
                return_type: None,
                param_types: None,
            },
        );
        let mut assoc_types = FxHashMap::default();
        assoc_types.insert("Item".to_string(), Ty::int());
        let _ = registry.register_impl(ImplDef {
            trait_name: "Iterator".to_string(),
            trait_type_args: vec![],
            impl_type: Ty::Con(TyCon::new("RangeIterator")),
            impl_type_name: "RangeIterator".to_string(),
            methods,
            associated_types: assoc_types,
        });
    }

    // ── Eq trait ────────────────────────────────────────────────────

    registry.register_trait(TraitDef {
        name: "Eq".to_string(),
        methods: vec![TraitMethodSig {
            name: "eq".to_string(),
            has_self: true,
            param_count: 1,
            return_type: Some(Ty::bool()),
            has_default_body: false,
            // Another value of the type.
            param_types: Some(vec![Ty::Con(TyCon::new("Self"))]),
        }],
        associated_types: vec![],
    });

    // Eq impls for Int, Float, String, Bool.
    for (ty, ty_name) in &[
        (Ty::int(), "Int"),
        (Ty::float(), "Float"),
        (Ty::string(), "String"),
        (Ty::Con(TyCon::new("Atom")), "Atom"),
        (Ty::bool(), "Bool"),
    ] {
        let mut methods = FxHashMap::default();
        methods.insert(
            "eq".to_string(),
            ImplMethodSig {
                has_self: true,
                param_count: 1,
                return_type: Some(Ty::bool()),
                param_types: None,
            },
        );
        let _ = registry.register_impl(ImplDef {
            trait_name: "Eq".to_string(),
            trait_type_args: vec![],
            impl_type: ty.clone(),
            impl_type_name: ty_name.to_string(),
            methods,
            associated_types: FxHashMap::default(),
        });
    }

    // ── Structural impls ───────────────────────────────────────────
    //
    // Tuples (by arity), unit, the collections and the built-in sum types
    // compare, order and print by their contents; the MIR lowerer generates
    // each function on demand (`eq_expr`, `cmp_fn`, `display_by_type`).
    // `'T` is a type parameter whatever the program declares: a user
    // `struct K` must not turn `Map<'K, 'V>` into a map keyed by that struct.
    let param = |name: &str| Ty::Con(TyCon::new(name));
    let mut structural: Vec<(Ty, &str, &[&str])> = vec![
        (param("Unit"), "Unit", &["Eq", "Ord", "Display", "Debug"]),
        (
            param("Ordering"),
            "Ordering",
            &["Eq", "Ord", "Display", "Debug"],
        ),
        (
            Ty::option(param("'T")),
            "Option",
            &["Eq", "Ord", "Display", "Debug"],
        ),
        (
            Ty::result(param("'T"), param("'E")),
            "Result",
            &["Eq", "Ord", "Display", "Debug"],
        ),
        (Ty::map_untyped(), "Map", &["Eq", "Debug"]),
        (Ty::map(param("'K"), param("'V")), "Map", &["Eq", "Debug"]),
        (Ty::set(param("'T")), "Set", &["Eq", "Debug"]),
        (Ty::list_untyped(), "List", &["Debug"]),
        (Ty::list(param("'T")), "List", &["Debug"]),
        // A process is its PID: compared as one, shown as `<0.12>`.
        (Ty::untyped_pid(), "Pid", &["Eq", "Display", "Debug"]),
        (Ty::pid(param("'M")), "Pid", &["Eq", "Display", "Debug"]),
        // A Json value is shown as its JSON text, and equal to another
        // holding the same (an object's keys in any order).
        (Ty::json(), "Json", &["Eq", "Display", "Debug"]),
        // Bytes are equal when they hold the same bytes (compared in
        // constant time, as `Bytes.secure_equals` does), and inspected as
        // their hex, `Bytes(0a1b)`.
        (Ty::bytes(), "Bytes", &["Eq", "Debug"]),
        // A wide integer compares and shows as the number it holds.
        (Ty::u64(), "U64", &["Eq", "Ord", "Display", "Debug"]),
        (Ty::u128(), "U128", &["Eq", "Ord", "Display", "Debug"]),
        (Ty::i128(), "I128", &["Eq", "Ord", "Display", "Debug"]),
    ];
    for arity in 0..=8u8 {
        let elems = (0..arity)
            .map(|i| param(&format!("'{}", (b'A' + i) as char)))
            .collect();
        structural.push((
            Ty::Tuple(elems),
            "Tuple",
            &["Eq", "Ord", "Display", "Debug"],
        ));
    }
    for (ty, ty_name, traits) in structural {
        for trait_name in traits {
            let mut methods = FxHashMap::default();
            let sigs: &[(&str, usize, Ty)] = match *trait_name {
                "Eq" => &[("eq", 1, Ty::bool())],
                "Ord" => &[("lt", 1, Ty::bool()), ("compare", 1, param("Ordering"))],
                "Display" => &[("to_string", 0, Ty::string())],
                _ => &[("inspect", 0, Ty::string())],
            };
            for (method, param_count, ret) in sigs {
                methods.insert(
                    method.to_string(),
                    ImplMethodSig {
                        has_self: true,
                        param_count: *param_count,
                        return_type: Some(ret.clone()),
                        param_types: None,
                    },
                );
            }
            let _ = registry.register_impl(ImplDef {
                trait_name: trait_name.to_string(),
                trait_type_args: vec![],
                impl_type: ty.clone(),
                impl_type_name: ty_name.to_string(),
                methods,
                associated_types: FxHashMap::default(),
            });
        }
    }

    // ── Ord trait ───────────────────────────────────────────────────

    registry.register_trait(TraitDef {
        name: "Ord".to_string(),
        methods: vec![
            TraitMethodSig {
                name: "lt".to_string(),
                has_self: true,
                param_count: 1,
                return_type: Some(Ty::bool()),
                has_default_body: false,
                param_types: Some(vec![Ty::Con(TyCon::new("Self"))]),
            },
            TraitMethodSig {
                name: "compare".to_string(),
                has_self: true,
                param_count: 1,
                return_type: Some(Ty::Con(TyCon::new("Ordering"))),
                has_default_body: true,
                param_types: Some(vec![Ty::Con(TyCon::new("Self"))]),
            },
        ],
        associated_types: vec![],
    });

    // Ord impls for Int, Float, String and Bool (false < true, as in tuples).
    for (ty, ty_name) in &[
        (Ty::int(), "Int"),
        (Ty::float(), "Float"),
        (Ty::string(), "String"),
        (Ty::bool(), "Bool"),
    ] {
        let mut methods = FxHashMap::default();
        methods.insert(
            "lt".to_string(),
            ImplMethodSig {
                has_self: true,
                param_count: 1,
                return_type: Some(Ty::bool()),
                param_types: None,
            },
        );
        methods.insert(
            "compare".to_string(),
            ImplMethodSig {
                has_self: true,
                param_count: 1,
                return_type: Some(Ty::Con(TyCon::new("Ordering"))),
                param_types: None,
            },
        );
        let _ = registry.register_impl(ImplDef {
            trait_name: "Ord".to_string(),
            trait_type_args: vec![],
            impl_type: ty.clone(),
            impl_type_name: ty_name.to_string(),
            methods,
            associated_types: FxHashMap::default(),
        });
    }

    // ── List Eq/Ord impls (Phase 27 Plan 01) ──────────────────────
    // Register Eq for List<T> -- parametric impl via single-letter type param "T".
    {
        let list_t = Ty::App(
            Box::new(Ty::Con(TyCon::new("List"))),
            vec![Ty::Con(TyCon::new("'T"))],
        );
        let mut eq_methods = FxHashMap::default();
        eq_methods.insert(
            "eq".to_string(),
            ImplMethodSig {
                has_self: true,
                param_count: 1,
                return_type: Some(Ty::bool()),
                param_types: None,
            },
        );
        let _ = registry.register_impl(ImplDef {
            trait_name: "Eq".to_string(),
            trait_type_args: vec![],
            impl_type: list_t.clone(),
            impl_type_name: "List".to_string(),
            methods: eq_methods,
            associated_types: FxHashMap::default(),
        });

        let mut ord_methods = FxHashMap::default();
        ord_methods.insert(
            "lt".to_string(),
            ImplMethodSig {
                has_self: true,
                param_count: 1,
                return_type: Some(Ty::bool()),
                param_types: None,
            },
        );
        ord_methods.insert(
            "compare".to_string(),
            ImplMethodSig {
                has_self: true,
                param_count: 1,
                return_type: Some(Ty::Con(TyCon::new("Ordering"))),
                param_types: None,
            },
        );
        let _ = registry.register_impl(ImplDef {
            trait_name: "Ord".to_string(),
            trait_type_args: vec![],
            impl_type: list_t,
            impl_type_name: "List".to_string(),
            methods: ord_methods,
            associated_types: FxHashMap::default(),
        });
    }

    // ── Not trait ───────────────────────────────────────────────────

    registry.register_trait(TraitDef {
        name: "Not".to_string(),
        methods: vec![TraitMethodSig {
            name: "not".to_string(),
            has_self: true,
            param_count: 0,
            return_type: Some(Ty::bool()),
            has_default_body: false,
            param_types: None,
        }],
        associated_types: vec![],
    });

    let mut not_methods = FxHashMap::default();
    not_methods.insert(
        "not".to_string(),
        ImplMethodSig {
            has_self: true,
            param_count: 0,
            return_type: Some(Ty::bool()),
            param_types: None,
        },
    );
    let _ = registry.register_impl(ImplDef {
        trait_name: "Not".to_string(),
        trait_type_args: vec![],
        impl_type: Ty::bool(),
        impl_type_name: "Bool".to_string(),
        methods: not_methods,
        associated_types: FxHashMap::default(),
    });

    // ── Display trait ──────────────────────────────────────────────
    registry.register_trait(TraitDef {
        name: "Display".to_string(),
        methods: vec![TraitMethodSig {
            name: "to_string".to_string(),
            has_self: true,
            param_count: 0, // no params besides self
            return_type: Some(Ty::string()),
            has_default_body: false,
            param_types: None,
        }],
        associated_types: vec![],
    });

    for (ty, ty_name) in &[
        (Ty::int(), "Int"),
        (Ty::float(), "Float"),
        (Ty::string(), "String"),
        (Ty::Con(TyCon::new("Atom")), "Atom"),
        (Ty::bool(), "Bool"),
    ] {
        let mut methods = FxHashMap::default();
        methods.insert(
            "to_string".to_string(),
            ImplMethodSig {
                has_self: true,
                param_count: 0,
                return_type: Some(Ty::string()),
                param_types: None,
            },
        );
        let _ = registry.register_impl(ImplDef {
            trait_name: "Display".to_string(),
            trait_type_args: vec![],
            impl_type: ty.clone(),
            impl_type_name: ty_name.to_string(),
            methods,
            associated_types: FxHashMap::default(),
        });
    }

    // ── Display/Debug for collection types (Phase 31) ──────────
    // Register Display for List<T>, Map<K,V>, Set so method dot-syntax
    // works for to_string() on collections. The actual runtime Display
    // is handled by wrap_collection_to_string in MIR lowering.
    {
        let list_t = Ty::App(
            Box::new(Ty::Con(TyCon::new("List"))),
            vec![Ty::Con(TyCon::new("'T"))],
        );
        let mut methods = FxHashMap::default();
        methods.insert(
            "to_string".to_string(),
            ImplMethodSig {
                has_self: true,
                param_count: 0,
                return_type: Some(Ty::string()),
                param_types: None,
            },
        );
        let _ = registry.register_impl(ImplDef {
            trait_name: "Display".to_string(),
            trait_type_args: vec![],
            impl_type: list_t,
            impl_type_name: "List".to_string(),
            methods,
            associated_types: FxHashMap::default(),
        });
    }
    {
        let map_kv = Ty::App(
            Box::new(Ty::Con(TyCon::new("Map"))),
            vec![Ty::Con(TyCon::new("'K")), Ty::Con(TyCon::new("'V"))],
        );
        let mut methods = FxHashMap::default();
        methods.insert(
            "to_string".to_string(),
            ImplMethodSig {
                has_self: true,
                param_count: 0,
                return_type: Some(Ty::string()),
                param_types: None,
            },
        );
        let _ = registry.register_impl(ImplDef {
            trait_name: "Display".to_string(),
            trait_type_args: vec![],
            impl_type: map_kv,
            impl_type_name: "Map".to_string(),
            methods,
            associated_types: FxHashMap::default(),
        });
    }
    {
        let set_t = Ty::set(Ty::Con(TyCon::new("'T")));
        let mut methods = FxHashMap::default();
        methods.insert(
            "to_string".to_string(),
            ImplMethodSig {
                has_self: true,
                param_count: 0,
                return_type: Some(Ty::string()),
                param_types: None,
            },
        );
        let _ = registry.register_impl(ImplDef {
            trait_name: "Display".to_string(),
            trait_type_args: vec![],
            impl_type: set_t,
            impl_type_name: "Set".to_string(),
            methods,
            associated_types: FxHashMap::default(),
        });
    }

    // ── Debug trait ──────────────────────────────────────────────
    registry.register_trait(TraitDef {
        name: "Debug".to_string(),
        methods: vec![TraitMethodSig {
            name: "inspect".to_string(),
            has_self: true,
            param_count: 0,
            return_type: Some(Ty::string()),
            has_default_body: false,
            param_types: None,
        }],
        associated_types: vec![],
    });

    // Debug impls for primitives (Int, Float, String, Bool).
    // For primitives, inspect produces the same output as to_string
    // (except String wraps in quotes -- handled at codegen).
    for (ty, ty_name) in &[
        (Ty::int(), "Int"),
        (Ty::float(), "Float"),
        (Ty::string(), "String"),
        (Ty::Con(TyCon::new("Atom")), "Atom"),
        (Ty::bool(), "Bool"),
    ] {
        let mut methods = FxHashMap::default();
        methods.insert(
            "inspect".to_string(),
            ImplMethodSig {
                has_self: true,
                param_count: 0,
                return_type: Some(Ty::string()),
                param_types: None,
            },
        );
        let _ = registry.register_impl(ImplDef {
            trait_name: "Debug".to_string(),
            trait_type_args: vec![],
            impl_type: ty.clone(),
            impl_type_name: ty_name.to_string(),
            methods,
            associated_types: FxHashMap::default(),
        });
    }

    // ── Hash trait ──────────────────────────────────────────────
    registry.register_trait(TraitDef {
        name: "Hash".to_string(),
        methods: vec![TraitMethodSig {
            name: "hash".to_string(),
            has_self: true,
            param_count: 0,
            return_type: Some(Ty::int()),
            has_default_body: false,
            param_types: None,
        }],
        associated_types: vec![],
    });

    // Hash impls for primitives (Int, Float, String, Bool).
    for (ty, ty_name) in &[
        (Ty::int(), "Int"),
        (Ty::float(), "Float"),
        (Ty::string(), "String"),
        (Ty::Con(TyCon::new("Atom")), "Atom"),
        (Ty::bool(), "Bool"),
    ] {
        let mut methods = FxHashMap::default();
        methods.insert(
            "hash".to_string(),
            ImplMethodSig {
                has_self: true,
                param_count: 0,
                return_type: Some(Ty::int()),
                param_types: None,
            },
        );
        let _ = registry.register_impl(ImplDef {
            trait_name: "Hash".to_string(),
            trait_type_args: vec![],
            impl_type: ty.clone(),
            impl_type_name: ty_name.to_string(),
            methods,
            associated_types: FxHashMap::default(),
        });
    }

    // ── Default trait ──────────────────────────────────────────────
    // Default is the first STATIC trait method in Mesh: no self parameter.
    // default() -> Self, where the return type is resolved per-impl.
    registry.register_trait(TraitDef {
        name: "Default".to_string(),
        methods: vec![TraitMethodSig {
            name: "default".to_string(),
            has_self: false,
            param_count: 0,
            return_type: None, // Self -- resolved per concrete type at call site
            has_default_body: false,
            param_types: None,
        }],
        associated_types: vec![],
    });

    // Default impls for primitives (Int, Float, String, Bool).
    // Each impl specifies the concrete return type.
    for (ty, ty_name) in &[
        (Ty::int(), "Int"),
        (Ty::float(), "Float"),
        (Ty::string(), "String"),
        (Ty::bool(), "Bool"),
    ] {
        let mut methods = FxHashMap::default();
        methods.insert(
            "default".to_string(),
            ImplMethodSig {
                has_self: false,
                param_count: 0,
                return_type: Some(ty.clone()),
                param_types: None,
            },
        );
        let _ = registry.register_impl(ImplDef {
            trait_name: "Default".to_string(),
            trait_type_args: vec![],
            impl_type: ty.clone(),
            impl_type_name: ty_name.to_string(),
            methods,
            associated_types: FxHashMap::default(),
        });
    }

    // ── From<T> trait ───────────────────────────────────────────────
    registry.register_trait(TraitDef {
        name: "From".to_string(),
        methods: vec![TraitMethodSig {
            name: "from".to_string(),
            has_self: false,
            param_count: 1,
            return_type: None, // Self -- resolved per impl
            has_default_body: false,
            param_types: None,
        }],
        associated_types: vec![],
    });

    // ── Into<T> trait ───────────────────────────────────────────────
    registry.register_trait(TraitDef {
        name: "Into".to_string(),
        methods: vec![TraitMethodSig {
            name: "into".to_string(),
            has_self: true,
            param_count: 0,
            return_type: None, // T -- the target type
            has_default_body: false,
            param_types: None,
        }],
        associated_types: vec![],
    });

    // ── TryFrom<T> trait ────────────────────────────────────────────────
    registry.register_trait(TraitDef {
        name: "TryFrom".to_string(),
        methods: vec![TraitMethodSig {
            name: "try_from".to_string(),
            has_self: false, // static method like From.from()
            param_count: 1,
            return_type: None, // Result<Self, E> -- resolved per impl
            has_default_body: false,
            param_types: None,
        }],
        associated_types: vec![],
    });

    // ── TryInto<T> trait ────────────────────────────────────────────────
    registry.register_trait(TraitDef {
        name: "TryInto".to_string(),
        methods: vec![TraitMethodSig {
            name: "try_into".to_string(),
            has_self: true, // instance method like Into.into()
            param_count: 0,
            return_type: None, // Result<T, E> -- the target type wrapped in Result
            has_default_body: false,
            param_types: None,
        }],
        associated_types: vec![],
    });

    // ── Built-in From impls ────────────────────────────────────────
    // Each registers a From impl with trait_type_args; synthetic Into
    // generation in register_impl automatically creates corresponding Into impls.

    // impl From<Int> for Float
    {
        let mut methods = FxHashMap::default();
        methods.insert(
            "from".to_string(),
            ImplMethodSig {
                has_self: false,
                param_count: 1,
                return_type: Some(Ty::float()),
                param_types: None,
            },
        );
        let _ = registry.register_impl(ImplDef {
            trait_name: "From".to_string(),
            trait_type_args: vec![Ty::int()],
            impl_type: Ty::float(),
            impl_type_name: "Float".to_string(),
            methods,
            associated_types: FxHashMap::default(),
        });
    }

    // impl From<Int> for String
    {
        let mut methods = FxHashMap::default();
        methods.insert(
            "from".to_string(),
            ImplMethodSig {
                has_self: false,
                param_count: 1,
                return_type: Some(Ty::string()),
                param_types: None,
            },
        );
        let _ = registry.register_impl(ImplDef {
            trait_name: "From".to_string(),
            trait_type_args: vec![Ty::int()],
            impl_type: Ty::string(),
            impl_type_name: "String".to_string(),
            methods,
            associated_types: FxHashMap::default(),
        });
    }

    // impl From<Float> for String
    {
        let mut methods = FxHashMap::default();
        methods.insert(
            "from".to_string(),
            ImplMethodSig {
                has_self: false,
                param_count: 1,
                return_type: Some(Ty::string()),
                param_types: None,
            },
        );
        let _ = registry.register_impl(ImplDef {
            trait_name: "From".to_string(),
            trait_type_args: vec![Ty::float()],
            impl_type: Ty::string(),
            impl_type_name: "String".to_string(),
            methods,
            associated_types: FxHashMap::default(),
        });
    }

    // impl From<Bool> for String
    {
        let mut methods = FxHashMap::default();
        methods.insert(
            "from".to_string(),
            ImplMethodSig {
                has_self: false,
                param_count: 1,
                return_type: Some(Ty::string()),
                param_types: None,
            },
        );
        let _ = registry.register_impl(ImplDef {
            trait_name: "From".to_string(),
            trait_type_args: vec![Ty::bool()],
            impl_type: Ty::string(),
            impl_type_name: "String".to_string(),
            methods,
            associated_types: FxHashMap::default(),
        });
    }
}

/// The `Channel` module: a `Channel<T>` carries values of any one type.
pub(crate) fn channel_functions() -> Vec<(&'static str, Scheme)> {
    let var = TyVar(93200);
    let t = Ty::Var(var);
    let channel = Ty::App(Box::new(Ty::Con(TyCon::new("Channel"))), vec![t.clone()]);
    let atom = Ty::Con(TyCon::new("Atom"));
    let created = Ty::result(channel.clone(), Ty::string());
    [
        (
            "bounded",
            Ty::fun(vec![Ty::int(), atom.clone()], created.clone()),
        ),
        (
            "bounded_bytes",
            Ty::fun(vec![Ty::int(), Ty::int(), atom], created),
        ),
        (
            "try_send",
            Ty::fun(
                vec![channel.clone(), t.clone()],
                Ty::result(Ty::int(), Ty::string()),
            ),
        ),
        (
            "recv",
            Ty::fun(
                vec![channel.clone(), Ty::int()],
                Ty::result(t, Ty::string()),
            ),
        ),
        ("depth", Ty::fun(vec![channel.clone()], Ty::int())),
        ("byte_depth", Ty::fun(vec![channel.clone()], Ty::int())),
        ("dropped", Ty::fun(vec![channel], Ty::int())),
    ]
    .into_iter()
    .map(|(name, ty)| {
        (
            name,
            Scheme {
                vars: vec![var],
                ty,
            },
        )
    })
    .collect()
}

/// The `Set` and `Queue` module functions, by name, over any element type:
/// `Set.add(Set<T>, T) -> Set<T>`, `Queue.pop(Queue<T>) -> (T, Queue<T>)`.
#[allow(clippy::type_complexity)]
pub(crate) fn set_and_queue_functions() -> (Vec<(&'static str, Scheme)>, Vec<(&'static str, Scheme)>)
{
    let generic = |t_var: TyVar, ty: Ty| Scheme {
        vars: vec![t_var],
        ty,
    };
    let set_var = TyVar(93000);
    let t = Ty::Var(set_var);
    let set_t = Ty::set(t.clone());
    let set_fns = [
        ("new", Ty::fun(vec![], set_t.clone())),
        (
            "add",
            Ty::fun(vec![set_t.clone(), t.clone()], set_t.clone()),
        ),
        (
            "remove",
            Ty::fun(vec![set_t.clone(), t.clone()], set_t.clone()),
        ),
        (
            "contains",
            Ty::fun(vec![set_t.clone(), t.clone()], Ty::bool()),
        ),
        ("size", Ty::fun(vec![set_t.clone()], Ty::int())),
        (
            "union",
            Ty::fun(vec![set_t.clone(), set_t.clone()], set_t.clone()),
        ),
        (
            "intersection",
            Ty::fun(vec![set_t.clone(), set_t.clone()], set_t.clone()),
        ),
        (
            "difference",
            Ty::fun(vec![set_t.clone(), set_t.clone()], set_t.clone()),
        ),
        ("to_list", Ty::fun(vec![set_t.clone()], Ty::list(t.clone()))),
        (
            "from_list",
            Ty::fun(vec![Ty::list(t.clone())], set_t.clone()),
        ),
        ("collect", Ty::fun(vec![Ty::iter(t.clone())], set_t.clone())),
    ];
    let queue_var = TyVar(93100);
    let t = Ty::Var(queue_var);
    let queue_t = Ty::queue(t.clone());
    let queue_fns = [
        ("new", Ty::fun(vec![], queue_t.clone())),
        (
            "push",
            Ty::fun(vec![queue_t.clone(), t.clone()], queue_t.clone()),
        ),
        (
            "pop",
            Ty::fun(
                vec![queue_t.clone()],
                Ty::Tuple(vec![t.clone(), queue_t.clone()]),
            ),
        ),
        ("peek", Ty::fun(vec![queue_t.clone()], t.clone())),
        ("size", Ty::fun(vec![queue_t.clone()], Ty::int())),
        ("is_empty", Ty::fun(vec![queue_t.clone()], Ty::bool())),
    ];
    (
        set_fns
            .into_iter()
            .map(|(name, ty)| (name, generic(set_var, ty)))
            .collect(),
        queue_fns
            .into_iter()
            .map(|(name, ty)| (name, generic(queue_var, ty)))
            .collect(),
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn builtins_register_primitives() {
        let mut ctx = InferCtx::new();
        let mut env = TypeEnv::new();
        let mut trait_registry = TraitRegistry::new();
        register_builtins(&mut ctx, &mut env, &mut trait_registry);

        // Check primitive types exist.
        assert!(env.lookup("Int").is_some());
        assert!(env.lookup("Float").is_some());
        assert!(env.lookup("String").is_some());
        assert!(env.lookup("Bool").is_some());
    }

    #[test]
    fn builtins_register_operators() {
        let mut ctx = InferCtx::new();
        let mut env = TypeEnv::new();
        let mut trait_registry = TraitRegistry::new();
        register_builtins(&mut ctx, &mut env, &mut trait_registry);

        // Check arithmetic operators exist.
        assert!(env.lookup("+").is_some());
        assert!(env.lookup("-").is_some());
        assert!(env.lookup("*").is_some());
        assert!(env.lookup("/").is_some());

        // Check comparison operators.
        assert!(env.lookup("==").is_some());
        assert!(env.lookup("<").is_some());
    }

    #[test]
    fn builtins_register_compiler_known_traits() {
        let mut ctx = InferCtx::new();
        let mut env = TypeEnv::new();
        let mut trait_registry = TraitRegistry::new();
        register_builtins(&mut ctx, &mut env, &mut trait_registry);

        // Check arithmetic traits.
        assert!(trait_registry.get_trait("Add").is_some());
        assert!(trait_registry.get_trait("Sub").is_some());
        assert!(trait_registry.get_trait("Eq").is_some());
        assert!(trait_registry.get_trait("Ord").is_some());

        // Check impls.
        assert!(trait_registry.has_impl("Add", &Ty::int()));
        assert!(trait_registry.has_impl("Add", &Ty::float()));
        assert!(!trait_registry.has_impl("Add", &Ty::string()));
        assert!(trait_registry.has_impl("Eq", &Ty::string()));
    }

    #[test]
    fn builtins_register_stdlib_functions() {
        let mut ctx = InferCtx::new();
        let mut env = TypeEnv::new();
        let mut trait_registry = TraitRegistry::new();
        register_builtins(&mut ctx, &mut env, &mut trait_registry);

        // String operations
        assert!(env.lookup("string_length").is_some());
        assert!(env.lookup("string_slice").is_some());
        assert!(env.lookup("string_contains").is_some());
        assert!(env.lookup("string_starts_with").is_some());
        assert!(env.lookup("string_ends_with").is_some());
        assert!(env.lookup("string_trim").is_some());
        assert!(env.lookup("string_to_upper").is_some());
        assert!(env.lookup("string_to_lower").is_some());
        assert!(env.lookup("string_replace").is_some());
        assert!(env.lookup("string_split").is_some());
        assert!(env.lookup("string_join").is_some());
        assert!(env.lookup("string_to_int").is_some());
        assert!(env.lookup("string_to_float").is_some());

        // File I/O functions
        assert!(env.lookup("file_read").is_some());
        assert!(env.lookup("file_read_bytes").is_some());
        assert!(env.lookup("file_write").is_some());
        assert!(env.lookup("file_write_bytes").is_some());
        assert!(env.lookup("file_size").is_some());
        assert!(env.lookup("file_append").is_some());
        assert!(env.lookup("file_exists").is_some());
        assert!(env.lookup("file_delete").is_some());
        assert!(env.lookup("file_rename").is_some());
        assert!(env.lookup("file_sync").is_some());

        // IO functions
        assert!(env.lookup("io_read_line").is_some());
        assert!(env.lookup("io_eprintln").is_some());

        // Env functions
        assert!(env.lookup("env_get_with_default").is_some());
        assert!(env.lookup("env_get_int").is_some());
        assert!(env.lookup("env_args").is_some());

        // Regex functions (Phase 119)
        assert!(env.lookup("regex_compile").is_some());
        assert!(env.lookup("regex_is_match").is_some());
        assert!(env.lookup("regex_captures").is_some());
        assert!(env.lookup("regex_replace").is_some());
        assert!(env.lookup("regex_split").is_some());

        // HTTP functions (Phase 8 Plan 05)
        assert!(env.lookup("http_router").is_some());
        assert!(env.lookup("http_route").is_some());
        assert!(env.lookup("http_serve").is_some());
        assert!(env.lookup("http_response").is_some());

        // Request accessors
        assert!(env.lookup("request_method").is_some());
        assert!(env.lookup("request_path").is_some());
        assert!(env.lookup("request_body").is_some());
        assert!(env.lookup("request_header").is_some());
        assert!(env.lookup("request_query").is_some());
        assert!(env.lookup("request_param").is_some());

        // Phase 51: Method-specific routing
        assert!(env.lookup("http_on_get").is_some());
        assert!(env.lookup("http_on_post").is_some());
        assert!(env.lookup("http_on_put").is_some());
        assert!(env.lookup("http_on_delete").is_some());

        // Phase 52: Middleware
        assert!(env.lookup("http_use").is_some());
    }

    #[test]
    fn display_trait_registered_for_primitives() {
        let mut ctx = InferCtx::new();
        let mut env = TypeEnv::new();
        let mut trait_registry = TraitRegistry::new();
        register_builtins(&mut ctx, &mut env, &mut trait_registry);

        // Display trait exists
        assert!(trait_registry.has_impl("Display", &Ty::int()));
        assert!(trait_registry.has_impl("Display", &Ty::float()));
        assert!(trait_registry.has_impl("Display", &Ty::string()));
        assert!(trait_registry.has_impl("Display", &Ty::bool()));

        // find_method_traits should find Display for to_string
        let traits = trait_registry.find_method_traits("to_string", &Ty::int());
        assert!(traits.contains(&"Display".to_string()));
    }

    #[test]
    fn hash_trait_registered_for_primitives() {
        let mut ctx = InferCtx::new();
        let mut env = TypeEnv::new();
        let mut trait_registry = TraitRegistry::new();
        register_builtins(&mut ctx, &mut env, &mut trait_registry);

        // Hash trait exists for all primitives
        assert!(trait_registry.has_impl("Hash", &Ty::int()));
        assert!(trait_registry.has_impl("Hash", &Ty::float()));
        assert!(trait_registry.has_impl("Hash", &Ty::string()));
        assert!(trait_registry.has_impl("Hash", &Ty::bool()));

        // find_method_traits should find Hash for hash
        let traits = trait_registry.find_method_traits("hash", &Ty::int());
        assert!(traits.contains(&"Hash".to_string()));
    }

    #[test]
    fn debug_trait_registered_for_primitives() {
        let mut ctx = InferCtx::new();
        let mut env = TypeEnv::new();
        let mut trait_registry = TraitRegistry::new();
        register_builtins(&mut ctx, &mut env, &mut trait_registry);

        // Debug trait exists for all primitives
        assert!(trait_registry.has_impl("Debug", &Ty::int()));
        assert!(trait_registry.has_impl("Debug", &Ty::float()));
        assert!(trait_registry.has_impl("Debug", &Ty::string()));
        assert!(trait_registry.has_impl("Debug", &Ty::bool()));

        // find_method_traits should find Debug for inspect
        let traits = trait_registry.find_method_traits("inspect", &Ty::int());
        assert!(traits.contains(&"Debug".to_string()));
    }

    #[test]
    fn default_trait_registered_for_primitives() {
        let mut ctx = InferCtx::new();
        let mut env = TypeEnv::new();
        let mut trait_registry = TraitRegistry::new();
        register_builtins(&mut ctx, &mut env, &mut trait_registry);

        // Default trait exists for all primitives
        assert!(trait_registry.has_impl("Default", &Ty::int()));
        assert!(trait_registry.has_impl("Default", &Ty::float()));
        assert!(trait_registry.has_impl("Default", &Ty::string()));
        assert!(trait_registry.has_impl("Default", &Ty::bool()));

        // find_method_traits should find Default for "default"
        let traits = trait_registry.find_method_traits("default", &Ty::int());
        assert!(traits.contains(&"Default".to_string()));
    }
}
