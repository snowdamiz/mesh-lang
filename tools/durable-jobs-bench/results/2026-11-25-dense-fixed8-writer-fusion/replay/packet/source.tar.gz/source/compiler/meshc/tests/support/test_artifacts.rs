#![allow(dead_code)]

use serde::{Deserialize, Serialize};
use std::any::Any;
use std::fs;
use std::io::Read;
use std::path::{Path, PathBuf};
use std::process::{Child, Command, Output};
use std::sync::OnceLock;
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct BuildOutputMetadata {
    pub source_package_dir: PathBuf,
    pub binary_path: PathBuf,
}

pub fn repo_root() -> PathBuf {
    Path::new(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .expect("meshc should live under compiler/")
        .parent()
        .expect("workspace root should contain compiler/")
        .to_path_buf()
}

/// meshc, with the runtime the programs it builds link rebuilt first: the
/// runtime cargo builds for meshc stays among its dependencies, and the one
/// meshc links is only refreshed by `cargo build -p mesh-rt`.
pub fn meshc_bin() -> PathBuf {
    ensure_mesh_rt_staticlib();
    PathBuf::from(env!("CARGO_BIN_EXE_meshc"))
}

/// Build the runtime that compiled Mesh programs link, and the test runtime
/// `meshc test` links. The compiler flags and wrapper of the cargo run that
/// started the tests are dropped: under `cargo llvm-cov` (a `RUSTC_WRAPPER`)
/// they instrument the build, a program linked with that runtime fails on the
/// missing profiler symbols, and cargo does not rebuild it once the wrapper
/// is gone.
pub fn ensure_mesh_rt_staticlib() {
    static BUILD_ONCE: OnceLock<()> = OnceLock::new();
    BUILD_ONCE.get_or_init(|| {
        let mut command = Command::new("cargo");
        command
            .current_dir(repo_root())
            .args(["build", "-p", "mesh-rt", "-p", "mesh-test-rt"]);
        for (name, _) in std::env::vars_os() {
            let name = name.to_string_lossy();
            if name.contains("RUSTFLAGS")
                || name.starts_with("RUSTC_")
                || name.contains("CARGO_LLVM_COV")
            {
                command.env_remove(name.as_ref());
            }
        }
        let output = command
            .output()
            .expect("failed to invoke cargo build -p mesh-rt -p mesh-test-rt");
        assert!(
            output.status.success(),
            "cargo build -p mesh-rt -p mesh-test-rt failed:\n{}",
            command_output_text(&output)
        );
    });
}

/// Stop a Mesh program as a service manager does: SIGTERM, then SIGKILL if it
/// still runs a few seconds later. A program ended by SIGKILL writes nothing
/// at exit, where the coverage run's runtime writes its profile on SIGTERM.
pub fn stop_child(child: &mut Child) {
    #[cfg(unix)]
    if Command::new("kill")
        .args(["-TERM", &child.id().to_string()])
        .status()
        .is_ok_and(|status| status.success())
    {
        let deadline = Instant::now() + Duration::from_secs(5);
        while Instant::now() < deadline {
            if matches!(child.try_wait(), Ok(Some(_))) {
                return;
            }
            std::thread::sleep(Duration::from_millis(20));
        }
    }
    let _ = child.kill();
    let _ = child.wait();
}

/// Time a host that assesses each new process before it starts (macOS, for
/// a child of a test cargo launched, under load) can hold a program before
/// its first instruction: 77 s has been seen with the scanner backlogged. A
/// test's run budget bounds the program; this is added to it.
pub const LAUNCH_ALLOWANCE: Duration = Duration::from_secs(180);

/// A child still running when its budget (and the launch allowance) ran out,
/// killed, with what it had printed.
#[derive(Debug)]
pub struct TimedOut {
    pub budget: Duration,
    pub output: Output,
}

impl std::fmt::Display for TimedOut {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(
            formatter,
            "binary timed out after {:?} (plus {:?} to start)\n{}",
            self.budget,
            LAUNCH_ALLOWANCE,
            command_output_text(&self.output)
        )
    }
}

/// Wait for `child` at most `budget` plus the launch allowance, reading its
/// piped output meanwhile (a full pipe would stall it), and kill it after.
pub fn wait_with_timeout(mut child: Child, budget: Duration) -> Result<Output, TimedOut> {
    fn drain(pipe: Option<impl Read + Send + 'static>) -> std::thread::JoinHandle<Vec<u8>> {
        std::thread::spawn(move || {
            let mut bytes = Vec::new();
            if let Some(mut pipe) = pipe {
                let _ = pipe.read_to_end(&mut bytes);
            }
            bytes
        })
    }
    let (stdout, stderr) = (drain(child.stdout.take()), drain(child.stderr.take()));
    let deadline = Instant::now() + budget + LAUNCH_ALLOWANCE;
    let status = loop {
        if let Some(status) = child.try_wait().expect("wait for the child") {
            break Ok(status);
        }
        if Instant::now() >= deadline {
            let _ = child.kill();
            break Err(child.wait().expect("wait for the killed child"));
        }
        std::thread::sleep(Duration::from_millis(20));
    };
    let collect = |status| Output {
        status,
        stdout: stdout.join().unwrap_or_default(),
        stderr: stderr.join().unwrap_or_default(),
    };
    match status {
        Ok(status) => Ok(collect(status)),
        Err(status) => Err(TimedOut {
            budget,
            output: collect(status),
        }),
    }
}

pub fn command_output_text(output: &Output) -> String {
    format!(
        "status: {:?}\nstdout:\n{}\nstderr:\n{}",
        output.status.code(),
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    )
}

pub fn panic_payload_to_string(payload: Box<dyn Any + Send>) -> String {
    if let Some(message) = payload.downcast_ref::<&str>() {
        (*message).to_string()
    } else if let Some(message) = payload.downcast_ref::<String>() {
        message.clone()
    } else {
        "non-string panic payload".to_string()
    }
}

pub fn artifact_dir(bucket: &str, test_name: &str) -> PathBuf {
    let stamp = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .expect("system clock should be after Unix epoch")
        .as_nanos();
    let dir = repo_root()
        .join(".tmp")
        .join(bucket)
        .join(format!("{test_name}-{stamp}"));
    fs::create_dir_all(&dir).expect("failed to create e2e artifact dir");
    dir
}

pub fn write_artifact(path: &Path, contents: impl AsRef<str>) {
    fs::write(path, contents.as_ref())
        .unwrap_or_else(|error| panic!("failed to write artifact {}: {error}", path.display()));
}

pub fn write_json_artifact(path: &Path, value: &impl Serialize) {
    write_artifact(
        path,
        serde_json::to_string_pretty(value).expect("json pretty print failed"),
    );
}

pub fn archive_directory_tree(source_dir: &Path, artifact_dir: &Path) {
    assert!(
        source_dir.is_dir(),
        "expected {} to be a directory before archiving",
        source_dir.display()
    );
    fs::create_dir_all(artifact_dir).unwrap_or_else(|error| {
        panic!(
            "failed to create archive directory {}: {error}",
            artifact_dir.display()
        )
    });

    for entry in fs::read_dir(source_dir)
        .unwrap_or_else(|error| panic!("failed to read {}: {error}", source_dir.display()))
    {
        let entry = entry
            .unwrap_or_else(|error| panic!("failed to iterate {}: {error}", source_dir.display()));
        let source_path = entry.path();
        let artifact_path = artifact_dir.join(entry.file_name());
        if source_path.is_dir() {
            archive_directory_tree(&source_path, &artifact_path);
        } else {
            if let Some(parent) = artifact_path.parent() {
                fs::create_dir_all(parent).unwrap_or_else(|error| {
                    panic!("failed to create {}: {error}", parent.display())
                });
            }
            fs::copy(&source_path, &artifact_path).unwrap_or_else(|error| {
                panic!(
                    "failed to archive {} -> {}: {error}",
                    source_path.display(),
                    artifact_path.display()
                )
            });
        }
    }
}
