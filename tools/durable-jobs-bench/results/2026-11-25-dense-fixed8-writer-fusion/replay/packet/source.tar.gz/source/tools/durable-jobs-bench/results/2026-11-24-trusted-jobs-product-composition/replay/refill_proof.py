"""Untimed public-runner and scoped PostgreSQL cuts for completion/refill."""
from contextlib import contextmanager
import os
from pathlib import Path
import signal
import sys
from unittest.mock import patch

import contract
from contract import apply
from semantic import NS, Relay, arm, cluster as baseline_cluster, rows, submit, teardown, wait

FUSED_SQL = b"FROM mesh_jobs.complete_and_refill_v1("
SCALAR_SQL = b"SELECT coalesce(mesh_jobs.settle_state($1,"
WORKERS = '[{"worker":"parity","version":1}]'
ROLE = "SET ROLE parity_subject; "


@contextmanager
def cluster(out, executable, mode):
    with baseline_cluster(out, executable, mode) as (db, subject, env):
        apply(db, "mesh", Path(__file__).with_name("candidate.sql").read_text())
        yield db, subject, dict(env, JOBS_GROUPED_WRITER="fused_fixed8ms")


def public_rows(data):
    return {name: {key: value for key, value in job.items() if key != "token"}
            for name, job in data.items()}


def sql_cut(out, executable):
    with cluster(out, executable, "dense") as (db, subject, env):
        cohort = ["settled", "cancelled", "expired", "stale"]
        ids = submit(out, subject, env, "first", [(key, {}) for key in cohort])["ids"]
        db.sql("mesh", ROLE + f"SELECT * FROM mesh_jobs.claim('{NS}', 'default', '{WORKERS}', 30000);")
        db.sql("mesh", ROLE + f"SELECT * FROM mesh_jobs.claim_batch_v1("
               f"'{NS}', 'default', '{WORKERS}', 30000, 16, NULL);")
        extra = submit(out, subject, env, "backlog", [("refill-a", {}), ("refill-b", {})])
        db.sql("mesh", f"""UPDATE mesh_jobs.jobs SET lease_expires_at_ms=0 WHERE id='{ids["expired"]}';
            UPDATE mesh_jobs.jobs SET cancel_requested_at_ms=mesh_jobs.now_ms() WHERE id='{ids["cancelled"]}';""")
        before = rows(db)
        assert all(before[key]["state"] == "executing" for key in cohort)
        tokens = [before[key]["token"] for key in cohort[:3]] + ["00000000-0000-0000-0000-000000000001"]
        args = f"'{NS}', 'default', '{WORKERS}', 30000, 4"
        keys = ",".join(ids[key] for key in cohort)
        fused = (f"SELECT status, coalesce(id, context) FROM mesh_jobs.complete_and_refill_v1("
                 f"{args}, '{{{keys}}}'::uuid[], '{{{','.join(tokens)}}}'::uuid[]);")
        result = db.sql("mesh", "BEGIN; " + ROLE + fused + " ROLLBACK;")
        assert result.splitlines()[0] == "completed|1000" and rows(db) == before, result
        result = db.sql("mesh", ROLE + fused).splitlines()
        assert len(result) == 2 and result[0] == "completed|1000", result
        replacement, = [key for key, uid in extra["ids"].items() if result[1] == f"claimed|{uid}"]
        after = rows(db)
        assert after["settled"]["state"] == "completed" and after["settled"]["token"] is None
        assert after[replacement]["state"] == "executing" and after[replacement]["attempt"] == 1
        assert after["settled"]["xid"] == after[replacement]["xid"]
        assert all(after[key] == before[key] for key in cohort[1:])
        assert sum(job["state"] == "executing" for job in after.values()) == 4

        # Namespace and queue controls fence the same ordinary admission function.
        db.sql("mesh", f"SET ROLE parity_operator; SELECT mesh_jobs.set_namespace_paused('{NS}', true);")
        ns_result = db.sql("mesh", ROLE + f"SELECT status, context FROM mesh_jobs.complete_and_refill_v1("
                           f"{args[:-1]}1, '{{{extra['ids'][replacement]}}}', '{{{after[replacement]['token']}}}');")
        assert ns_result == "completed|1" and rows(db)[replacement]["state"] == "completed", ns_result
        db.sql("mesh", f"SET ROLE parity_operator; SELECT mesh_jobs.set_namespace_paused('{NS}', false); "
                       f"SELECT mesh_jobs.queue_control('{NS}','default','pause',NULL);")
        queued = db.sql("mesh", ROLE + f"SELECT count(*) FROM mesh_jobs.claim_batch_set_v1("
                        f"'{NS}', 'default', '{WORKERS}', 30000, 16, NULL);")
        assert queued == "0"
        assert sum(job["state"] == "available" for job in rows(db).values()) == 1
        db.sql("mesh", f"""SET ROLE parity_operator;
            SELECT mesh_jobs.queue_control('{NS}','default','resume',NULL);
            SELECT mesh_jobs.queue_control('{NS}','default','scale',2);""")
        final_live = rows(db)
        single = (f"SELECT status, context FROM mesh_jobs.complete_and_refill_v1("
                  f"{args[:-1]}1, '{{{ids['stale']}}}', '{{{final_live['stale']['token']}}}');")
        with patch.object(contract, "DB", "mesh"):
            with contract.hold(db, rf"""
                SELECT mesh_jobs.queue_control('{NS}','default','scale',1) AS s \gset
                """, role="parity_operator", commit=True):
                contract.psql(db, single, database="mesh", expect="55P03")
                assert rows(db) == final_live
        # Three committed legacy leases survived the contraction. Finishing
        # one cannot replenish while the other two are still charged.
        assert db.sql("mesh", ROLE + single) == "completed|1"
        assert rows(db)["refill-b"]["state"] == "available"
        arm.h.write_json(out / "result.json", dict(rollback=True, before=public_rows(before), after=public_rows(after),
                                                  legacy_and_cursor=True, contention_rolled_back=True,
                                                  contraction_preserved=True))


def protocol(out, executable, cut):
    os.environ["PRODUCT_COMPOSITION"] = "product-d2"
    mode = "fault" if cut == "lost-commit" else "dense"
    with cluster(out, executable, mode) as (db, subject, env), Relay(db) as relay:
        if cut == "malformed-grant":
            gate = relay.arm(FUSED_SQL, corrupt_grant=True)
            fallback = relay.arm(SCALAR_SQL)
        else:
            gate = relay.arm(b"COMMIT", after_select=FUSED_SQL, drop=(cut == "lost-commit"))
            fallback = None
        log = out / "runner.log"
        child = subject.run(dict(env, JOBS_PARITY_POOL_URL=db.url("mesh", port=relay.port),
                                 PRODUCT_STOP_WITNESS="1"), 0, log)
        try:
            wait("runner ready", lambda: arm.h.runner_ready([child], [log], track=False))
            submit(out, subject, env, "occupied", [("release", {"hold_ms": 850}),
                   *((f"slower-{i}", {"hold_ms": 2600}) for i in range(3))])
            wait("four granted jobs", lambda: sum(job["state"] == "executing"
                 for job in rows(db).values()) == 4)
            submit(out, subject, env, "refill", [("next", {})])
            assert gate.hit.wait(6), "fused SELECT and COMMIT did not reach the cut"
            held = rows(db)
            old, new = held["release"], held["next"]
            assert len(old["attempts"]) == 1 and old["effect"] and old["effect"] != old["attempts"][0]
            assert new["attempts"] == [] and new["effect"] is None
            if cut == "malformed-grant":
                assert gate.witness["corrupt_grant"] and not gate.witness["idle"]
                assert old["state"] == "executing" and new["state"] == "available" and new["attempt"] == 0
                gate.release.set()
                assert fallback.hit.wait(5), "no ordinary scalar fallback after rollback"
                rolled_back = rows(db)
                assert rolled_back["release"]["state"] == "completed"
                assert rolled_back["next"] == new
                assert any(sql == "ROLLBACK" for _, sql in relay.requests)
                fallback.release.set()
            else:
                assert gate.witness["idle"] and gate.witness["command"] == "COMMIT"
                assert old["state"] == "completed" and new["state"] == "executing"
                assert new["attempt"] == 1 and old["xid"] == new["xid"]
                assert old["xid"] not in (old["attempts"][0], old["effect"])
                if cut == "stop-at-commit":
                    child.send_signal(signal.SIGTERM)
                    # The fixture's main loop reports stopping and waits for the
                    # still-held claim receipt. The signal handler fences launches.
                    wait("stop signal processed", lambda: "STOPPING" in log.read_text().splitlines())
                gate.release.set()
            if cut == "stop-at-commit":
                assert child.wait(timeout=12) == 0, log.read_text()
                final = rows(db)["next"]
                assert final["state"] == "available" and final["attempt"] == 0
                assert final["attempts"] == [] and final["effect"] is None
            else:
                wait("replacement completed", lambda: rows(db)["next"]["state"] == "completed")
                final = rows(db)["next"]
                assert final["attempt"] == 1
                assert len({final["xid"], *final["attempts"], final["effect"]}) == 3
                if cut == "lost-commit":
                    assert sum('"event":"ack_uncertain"' in line for line in log.read_text().splitlines()) == 1
                    assert any("FOR NO KEY UPDATE NOWAIT" in sql for _, sql in relay.requests)
                    assert any("released_unstarted" in sql for _, sql in relay.requests)
                arm.h.stop_runners([child], require_clean=True)
            arm.h.write_json(out / "result.json", dict(cut=cut, held=public_rows(held), final=public_rows({'next': final})['next'],
                                                      wire=gate.witness, queries=relay.requests))
        finally:
            gate.release.set()
            if fallback:
                fallback.release.set()
            if child.poll() is None:
                arm.h.stop_runners([child], require_clean=False)


def pending_ordinary(out, executable):
    with cluster(out, executable, "dense") as (db, subject, env), Relay(db) as relay:
        log = out / "runner.log"
        child = subject.run(dict(env, JOBS_PARITY_POOL_URL=db.url("mesh", port=relay.port)), 0, log)
        gates = []
        try:
            wait("runner ready", lambda: arm.h.runner_ready([child], [log], track=False))
            submit(out, subject, env, "occupied", [("release", {"hold_ms": 1150}),
                   ("slow-a", {"hold_ms": 2800}), ("slow-b", {"hold_ms": 2800})])
            wait("three started jobs", lambda: sum(bool(job["attempts"]) for job in rows(db).values()) == 3)
            ordinary = relay.arm(b"COMMIT", after_select=b"FROM mesh_jobs.claim_batch_set_v1(")
            fused = relay.arm(b"COMMIT", after_select=FUSED_SQL)
            gates += [ordinary, fused]
            submit(out, subject, env, "backlog", [("ordinary", {}), ("replacement", {})])
            assert ordinary.hit.wait(4), "ordinary COMMIT gate never opened"
            assert fused.hit.wait(4), "writer did not fuse with an outstanding ordinary reservation"
            held = rows(db)
            assert held["release"]["state"] == "completed"
            assert held["ordinary"]["state"] == held["replacement"]["state"] == "executing"
            assert held["ordinary"]["xid"] != held["replacement"]["xid"] == held["release"]["xid"]
            assert not held["ordinary"]["attempts"] and not held["replacement"]["attempts"]
            assert sum(job["state"] == "executing" for job in held.values()) == 4
            fused.release.set()
            wait("independent receipt launched fused replacement", lambda: rows(db)["replacement"]["effect"])
            assert not rows(db)["ordinary"]["attempts"]
            ordinary.release.set()
            wait("ordinary reservation retained", lambda: rows(db)["ordinary"]["effect"])
            final = rows(db)
            assert len({final["ordinary"]["effect"], final["replacement"]["effect"],
                        *final["ordinary"]["attempts"], *final["replacement"]["attempts"]}) == 4
            wait("all jobs settled", lambda: all(job["state"] == "completed" for job in rows(db).values()))
            arm.h.stop_runners([child], require_clean=True)
            arm.h.write_json(out / "result.json", dict(held=public_rows(held),
                             wires=[ordinary.witness, fused.witness], overlap=True))
        finally:
            for gate in gates:
                gate.release.set()
            if child.poll() is None:
                arm.h.stop_runners([child], require_clean=False)


if __name__ == "__main__":
    out, executable, witness = [Path(name).resolve() for name in sys.argv[1:]]
    out.mkdir()
    os.environ["PRODUCT_COMPOSITION"] = "product-d2"
    sql_cut(out / "sql-cut", executable)
    for cut in ("confirm-commit", "malformed-grant", "lost-commit", "stop-at-commit"):
        protocol(out / cut, executable, cut)
    pending_ordinary(out / "pending-ordinary", executable)
    teardown(out / "teardown-release", executable, witness, forced=False)
    teardown(out / "teardown-kill", executable, witness, forced=True)
