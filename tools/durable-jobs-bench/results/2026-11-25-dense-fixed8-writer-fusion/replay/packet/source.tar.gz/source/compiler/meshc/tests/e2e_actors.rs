//! End-to-end integration tests for the Mesh actor runtime.
//!
//! Each test compiles a .mpl program that exercises actor features,
//! runs the resulting binary, and asserts the expected stdout output.
//!
//! Actor tests use generous timeouts since they involve concurrency.

#[path = "support/test_artifacts.rs"]
mod artifacts;

use std::path::{Path, PathBuf};
use std::process::Command;
use std::sync::Mutex;
use std::time::Duration;

// ponytail: serialize compile-heavy actor proofs; remove when isolated builds stay below deadlines.
static ACTOR_E2E_LOCK: Mutex<()> = Mutex::new(());

/// Helper: compile a Mesh source and run the binary with a timeout.
/// Returns stdout on success. Panics on compilation failure or timeout.
fn compile_and_run_with_timeout(source: &str, timeout_secs: u64) -> String {
    compile_and_run(source, &[], timeout_secs)
}

/// As above, with extra `meshc build` arguments such as `--opt-level`.
fn compile_and_run(source: &str, build_args: &[&str], timeout_secs: u64) -> String {
    let _guard = ACTOR_E2E_LOCK
        .lock()
        .unwrap_or_else(|poisoned| poisoned.into_inner());
    let temp_dir = tempfile::tempdir().expect("failed to create temp dir");
    let project_dir = temp_dir.path().join("project");
    std::fs::create_dir_all(&project_dir).expect("failed to create project dir");

    let main_mesh = project_dir.join("main.mpl");
    std::fs::write(&main_mesh, source).expect("failed to write main.mpl");

    // Build with meshc
    let meshc = find_meshc();
    let output = Command::new(&meshc)
        .args(["build", project_dir.to_str().unwrap()])
        .args(build_args)
        .output()
        .expect("failed to invoke meshc");

    assert!(
        output.status.success(),
        "meshc build failed:\nstdout: {}\nstderr: {}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );

    // Run the compiled binary with a timeout
    run_actor_binary(&project_dir.join("project"), timeout_secs)
}

fn run_actor_binary(binary: &Path, timeout_secs: u64) -> String {
    let child = Command::new(binary)
        .stdout(std::process::Stdio::piped())
        .stderr(std::process::Stdio::piped())
        .spawn()
        .unwrap_or_else(|e| panic!("failed to spawn binary at {}: {}", binary.display(), e));

    let output = artifacts::wait_with_timeout(child, Duration::from_secs(timeout_secs));

    match output {
        Ok(out) => {
            assert!(
                out.status.success(),
                "binary execution failed with exit code {:?}:\nstdout: {}\nstderr: {}",
                out.status.code(),
                String::from_utf8_lossy(&out.stdout),
                String::from_utf8_lossy(&out.stderr)
            );
            String::from_utf8_lossy(&out.stdout).to_string()
        }
        Err(msg) => panic!("{}", msg),
    }
}

/// Read a test fixture from the tests/e2e/ directory.
fn read_fixture(name: &str) -> String {
    let manifest_dir = env!("CARGO_MANIFEST_DIR");
    let fixture_path = Path::new(manifest_dir)
        .parent()
        .unwrap()
        .parent()
        .unwrap()
        .join("tests")
        .join("e2e")
        .join(name);
    std::fs::read_to_string(&fixture_path)
        .unwrap_or_else(|e| panic!("failed to read fixture {}: {}", fixture_path.display(), e))
}

fn find_meshc() -> PathBuf {
    artifacts::meshc_bin()
}

#[test]
fn grouped_step_selection_and_fallback_in_generated_binaries() {
    let _guard = ACTOR_E2E_LOCK.lock().unwrap_or_else(|e| e.into_inner());
    for (level, setting, movable_setting, expect_step, expect_movable) in [
        ("2", None, None, true, true),
        ("2", Some("0"), None, false, true),
        ("2", None, Some("0"), true, false),
        ("0", None, None, false, false),
        ("0", Some("1"), Some("1"), false, false),
        ("1", None, None, false, false),
    ] {
        let dir = tempfile::tempdir().unwrap();
        let binary = dir.path().join("actors");
        std::fs::write(
            dir.path().join("main.mpl"),
            include_str!("fixtures/grouped_step.mpl"),
        )
        .unwrap();
        let mut build = Command::new(find_meshc());
        build.env_remove("MESH_GROUPED_STEP");
        build.env_remove("MESH_MOVABLE_STEP");
        if let Some(value) = movable_setting {
            build.env("MESH_MOVABLE_STEP", value);
        }
        if let Some(value) = setting {
            build.env("MESH_GROUPED_STEP", value);
        }
        let output = build
            .arg("build")
            .arg(dir.path())
            .args(["--opt-level", level, "--emit-llvm", "-o"])
            .arg(&binary)
            .output()
            .unwrap();
        assert!(
            output.status.success(),
            "{}",
            String::from_utf8_lossy(&output.stderr)
        );

        let ir = std::fs::read_to_string(binary.with_extension("ll")).unwrap();
        let case = format!(
            "O{level}, MESH_GROUPED_STEP={setting:?}, MESH_MOVABLE_STEP={movable_setting:?}"
        );
        assert_eq!(
            ir.contains("call i64 @mesh_actor_spawn_step(ptr @rotate_words,"),
            expect_step,
            "{case}"
        );
        assert_eq!(
            ir.contains("call i64 @mesh_actor_spawn_grouped(ptr @rotate_words,"),
            !expect_step,
            "{case}"
        );
        assert_eq!(
            ir.contains("call i64 @mesh_actor_spawn_movable_step(ptr @rotate_words,"),
            expect_movable,
            "{case}"
        );
        assert_eq!(
            ir.contains("call i64 @mesh_actor_spawn_shaped(ptr @rotate_words,"),
            !expect_movable,
            "{case}"
        );
        assert!(
            ir.contains("call i64 @mesh_actor_spawn_grouped(ptr @rotate_cleanup,"),
            "{case}"
        );
        #[cfg(any(target_os = "macos", target_os = "linux"))]
        {
            let symbols = Command::new("nm")
                .arg(&binary)
                .output()
                .expect("binary symbols");
            assert!(
                symbols.status.success(),
                "{case}: {}",
                String::from_utf8_lossy(&symbols.stderr)
            );
            let has_handler = String::from_utf8_lossy(&symbols.stdout)
                .lines()
                .any(|line| {
                    matches!(
                        line.split_whitespace().last(),
                        Some("rotate_words.step" | "_rotate_words.step")
                    )
                });
            assert_eq!(has_handler, expect_step || expect_movable, "{case}");
        }
        assert_eq!(
            run_actor_binary(&binary, 10).trim(),
            "1\n4\n3\n7\n10\n10",
            "{case}"
        );
    }
}

#[test]
fn grouped_actors_exchange_typed_messages_with_an_ordinary_caller() {
    let output = compile_and_run_with_timeout(
        r#"
actor child(parent :: Pid<String>, text :: String) do
  receive do
    _ -> send(parent, text)
  end
end

actor pair(requester :: Pid<String>, text :: String) do
  let peer = spawn grouped(child, self(), text)
  send(peer, 1)
  receive do
    reply -> send(requester, reply)
  end
end

actor coordinator() do
  let _ = spawn grouped(pair, self(), String.repeat("hello", 2))
  receive do
    result -> println(result)
    after 2000 -> panic("grouped actor did not reply")
  end
end

fn main() do
  spawn(coordinator)
end
"#,
        10,
    );
    assert_eq!(output.trim(), "hellohello");
}

#[test]
fn grouped_import_checks_the_terminate_callback() {
    let project = tempfile::tempdir().unwrap();
    std::fs::write(
        project.path().join("workers.mpl"),
        r#"
actor worker() do
  0
  terminate do
    println("worker stopped")
  end
end
"#,
    )
    .unwrap();
    std::fs::write(
        project.path().join("main.mpl"),
        "from Workers import worker\npub fn __terminate_worker() -> Int = 0\nfn main() do\n  spawn grouped(worker)\nend\n",
    )
    .unwrap();
    let output = Command::new(find_meshc())
        .arg("build")
        .arg(project.path())
        .output()
        .unwrap();
    let error = String::from_utf8_lossy(&output.stderr);
    assert!(!output.status.success());
    assert!(
        error.contains(
            "[E0106] Error: `spawn grouped` cannot certify the terminate callback of `worker`"
        ),
        "{error}"
    );
}

// ── Actor E2E Tests ─────────────────────────────────────────────────────

/// Test 1: Basic actor spawning and messaging.
/// An actor receives a message and prints a response.
#[test]
fn actors_basic() {
    let source = read_fixture("actors_basic.mpl");
    let output = compile_and_run_with_timeout(&source, 10);
    assert!(
        output.contains("actor received"),
        "Expected 'actor received' in output, got: {}",
        output
    );
    assert!(
        output.contains("main done"),
        "Expected 'main done' in output, got: {}",
        output
    );
}

/// Test 2: Receive with message processing.
/// Multiple actors receive messages and process them.
#[test]
fn actors_messaging() {
    let source = read_fixture("actors_messaging.mpl");
    let output = compile_and_run_with_timeout(&source, 10);
    // All three workers should print their done message
    let count = output.matches("worker done").count();
    assert!(
        count >= 3,
        "Expected at least 3 'worker done' messages, got {} in: {}",
        count,
        output
    );
}

/// Test 3: Preemptive scheduling -- a tight-loop actor does not starve others.
/// One actor does a lot of work while another waits for a message.
/// Both should complete.
#[test]
fn actors_preemption() {
    let source = read_fixture("actors_preemption.mpl");
    let output = compile_and_run_with_timeout(&source, 10);
    assert!(
        output.contains("fast done"),
        "Expected 'fast done' in output (fast actor was not starved), got: {}",
        output
    );
    assert!(
        output.contains("slow done"),
        "Expected 'slow done' in output (slow actor completed), got: {}",
        output
    );
}

/// Test 4: Process linking -- when one actor exits, linked actor is notified.
/// This tests the exit signal propagation through link().
#[test]
fn actors_linking() {
    let source = read_fixture("actors_linking.mpl");
    let output = compile_and_run_with_timeout(&source, 10);
    assert_eq!(
        output,
        "linked to a normal exit: still running\nlink test done\n"
    );
}

/// Test 5: Typed Pid prevents wrong-type sends at compile time.
/// A program that tries to send the wrong type to a typed Pid should fail.
#[test]
fn actors_typed_pid() {
    let source = read_fixture("actors_typed_pid.mpl");
    let output = compile_and_run_with_timeout(&source, 10);
    assert!(
        output.contains("typed pid ok"),
        "Expected 'typed pid ok' in output, got: {}",
        output
    );
}

/// Test 6: 100K actor benchmark -- spawn 100K actors and verify they all respond.
#[test]
fn actors_100k() {
    let source = read_fixture("actors_100k.mpl");
    let output = compile_and_run_with_timeout(&source, 30);
    assert!(
        output.contains("100000 actors done"),
        "Expected '100000 actors done' in output, got: {}",
        output
    );
}

/// Test 7: Terminate callback -- cleanup logic runs before actor exit.
#[test]
fn actors_terminate() {
    let source = read_fixture("actors_terminate.mpl");
    let output = compile_and_run_with_timeout(&source, 10);
    assert!(
        output.contains("terminate test done"),
        "Expected 'terminate test done' in output, got: {}",
        output
    );
}

/// Test 8: GC bounded memory -- a long-running actor allocates and discards
/// strings in a tight loop. With mark-sweep GC, unreachable allocations are
/// reclaimed at yield points so memory stays bounded.
#[test]
fn gc_bounded_memory() {
    let source = read_fixture("gc_bounded_memory.mpl");
    let output = compile_and_run_with_timeout(&source, 30);
    assert!(
        output.contains("gc bounded memory test done"),
        "Expected 'gc bounded memory test done' in output, got: {}",
        output
    );
}

#[test]
fn gc_preserves_live_values_held_across_collection_points() {
    let source = read_fixture("gc_live_register_roots.mpl");
    for level in ["0", "2"] {
        let output = compile_and_run(&source, &["--opt-level", level], 30);
        assert!(
            output.contains("gc live register roots preserved"),
            "live value was corrupted across collection at -O{level}: {output}"
        );
    }
}

/// A heap value passed to `spawn` is borrowed from the spawner's heap. It must
/// survive the spawner dropping its own reference and collecting repeatedly.
///
/// Built at `--opt-level 2`: unoptimized code leaves the value in a dead stack
/// slot, which the conservative collector still treats as a root, so the
/// default build would pass even without the runtime keeping the loan alive.
#[test]
fn actors_spawn_arg_survives_spawner_gc() {
    let source = read_fixture("actors_spawn_arg_survives_gc.mpl");
    let output = compile_and_run(&source, &["--opt-level", "2"], 30);
    assert_eq!(
        output.trim(),
        "payload-42",
        "spawn argument was freed and reused by the spawner"
    );
}

/// The same value handed on to a grandchild outlives the actor in the middle.
#[test]
fn actors_relayed_spawn_arg_outlives_the_relay() {
    let source = read_fixture("actors_spawn_arg_relayed.mpl");
    let output = compile_and_run(&source, &["--opt-level", "2"], 30);
    assert_eq!(
        output.trim(),
        "payload-42",
        "relayed spawn argument was freed and reused by its owner"
    );
}

/// A `String` message is copied for the receiver rather than shared with the
/// sender's heap, so it survives the sender collecting afterwards.
#[test]
fn actors_send_string_survives_sender_gc() {
    let source = read_fixture("actors_send_string_survives_gc.mpl");
    let output = compile_and_run(&source, &["--opt-level", "2"], 30);
    assert_eq!(
        output.trim(),
        "payload-42",
        "sent string was freed and reused by the sender"
    );
}

/// Run a fixture built at `--opt-level 2` and compare its output lines, in any
/// order: the actors in these fixtures finish in no particular sequence.
fn assert_lines(fixture: &str, expected: &[&str]) {
    let source = read_fixture(fixture);
    let output = compile_and_run(&source, &["--opt-level", "2"], 60);
    let mut lines: Vec<&str> = output.lines().collect();
    lines.sort_unstable();
    let mut expected = expected.to_vec();
    expected.sort_unstable();
    assert_eq!(lines, expected, "{fixture} printed:\n{output}");
}

/// Every common message shape arrives as the receiver's own copy, while the
/// sender drops each value and keeps collecting. Also covers messages wider
/// than one word, which `receive` used to truncate to their first 8 bytes, a
/// one-word struct, which a tuple field holds without a box, and a `json { }`
/// literal, a tree like any `Json`.
#[test]
fn actors_send_shapes_survive_sender_gc() {
    assert_lines(
        "actors_send_shapes_survive_gc.mpl",
        &[
            "named=named-1001",
            "pair=paired-102/7",
            "wrapped=boxjob-103/3",
            "tuple=tupled-104/4",
            "struct=struct-105/5",
            "batch=batch-a-115+batch-b-116/15",
            "list=listed-106+listed-107",
            "jobs=jobs-b-109/9",
            "map=mapped-110",
            "option=option-111",
            "result=result-112",
            "pairs=pairs-b-114/14",
            r#"json={"name":"json-117","tags":["tag-118"]}"#,
        ],
    );
}

/// A heap string handed to `Timer.send_after` is copied when the timer is set,
/// not read from the sender's heap when it fires.
#[test]
fn actors_timer_send_string_survives_sender_gc() {
    assert_lines("actors_timer_send_string_survives_gc.mpl", &["payload-42"]);
}

/// Closure- and struct-typed actor parameters, which are wider than one
/// argument slot, and a string relayed through an actor that exits at once.
#[test]
fn actors_spawn_arg_shapes_reach_their_actor() {
    assert_lines(
        "actors_spawn_arg_shapes.mpl",
        &[
            "closure=item-11/7",
            "struct=job-33x3",
            "batch=batch-44+batch-55",
            "relayed=relay-22",
        ],
    );
}

/// Service arguments and replies are copied between the caller and the
/// service: list and struct arguments, list and string replies, and a cast.
#[test]
fn service_heap_values_survive_gc() {
    assert_lines(
        "service_heap_values_survive_gc.mpl",
        &[
            "reply=stocked-2",
            "tagged=item-a-101,item-b-102,entry-103#7",
            "loaded=2:batch-105",
            "first=cast-x-104",
        ],
    );
}

/// A job's result outlives the job actor's heap: strings, lists, structs,
/// options, tuples and a closure from `Job.async`, and `Job.map` called
/// directly and through a pipe. Struct results also used to come back through the wrong
/// calling convention, and string results as a box around the pointer.
#[test]
fn job_heap_results_survive_gc() {
    assert_lines(
        "job_heap_results_survive_gc.mpl",
        &[
            "payload-42",
            "line-41+line-42",
            "report-41: a-41+b-41 = 82",
            "some inner-41",
            "pair-41 -> 43",
            "123",
            "2.5",
            "true",
            "mapped-100",
            "mapped-300",
            "piped-500",
            "mapped-report-8: m-8 = 8",
            "made-41#9",
        ],
    );
}

/// Test 9: Actors with arguments -- spawn passes initial state correctly.
/// Actors receive typed arguments, not raw buffer pointers. Tests the
/// wrapper function that deserializes args from the spawn buffer.
#[test]
fn actors_with_args() {
    let source = read_fixture("actors_with_args.mpl");
    let output = compile_and_run_with_timeout(&source, 10);
    assert!(
        output.contains("15"),
        "Expected '15' (adder initial=10 + msg=5) in output, got: {}",
        output
    );
    assert!(
        output.contains("42"),
        "Expected '42' (calculator 30 + 12) in output, got: {}",
        output
    );
    assert!(
        output.contains("args test done"),
        "Expected 'args test done' in output, got: {}",
        output
    );
}

/// PIDs compare as equal only to themselves and show as `<0.N>`; no
/// process is PID 0, which is what looking up an absent name returns.
#[test]
fn pids_compare_and_show_themselves() {
    let output = compile_and_run_with_timeout(
        r##"actor worker() do
  receive do
    msg -> println(msg)
  end
end

fn main() do
  let a = spawn(worker)
  let b = spawn(worker)
  send(a, "a done")
  send(b, "b done")
  println("same=#{a == a} different=#{a == b}")
  println("absent=#{Process.whereis("nobody")}")
  println("shown=#{String.starts_with("#{a}", "<0.")}")
end
"##,
        30,
    );
    assert!(output.contains("same=true different=false"), "{output}");
    assert!(output.contains("absent=<0.0>"), "{output}");
    assert!(output.contains("shown=true"), "{output}");
}

/// What a node that nobody else joins can do with the distribution
/// primitives, as the documentation describes: start once, fail to reach
/// an absent peer, keep a global registry, report a remote spawn that
/// cannot happen with PID 0, and monitor a node: not before this one has
/// started, and one it is not connected to at once.
#[test]
fn node_primitives_on_a_lone_node() {
    let port = std::net::TcpListener::bind("127.0.0.1:0")
        .unwrap()
        .local_addr()
        .unwrap()
        .port();
    let source = r##"actor worker(prefix :: String) do
  receive do
    msg -> println("#{prefix}: #{msg}")
  end
end

actor node_watcher(label :: String) do
  let status = Node.monitor("absent@127.0.0.1:1", "#{label}: absent node gone")
  println("#{label}_monitor=#{status}")
  let heard = receive do
    text -> text
  after 200 -> "#{label}: nothing"
  end
  println(heard)
end

actor coordinator(absent :: String) do
  let spawned = Node.spawn(absent, worker, "remote")
  send(spawned, "unheard")
  println("spawn=#{spawned}")
  let linked = Node.spawn_link(absent, worker, "linked")
  send(linked, "unheard")
  println("spawn_link=#{linked}")
end

fn await_gone(name :: String) do
  if Process.whereis(name) != Process.whereis("none-such") do
    Timer.sleep(10)
    await_gone(name)
  end
end

fn main() do
  println("self_before=[#{Node.self()}]")
  let early = spawn(node_watcher, "early")
  Process.register("early", early)
  await_gone("early")
  let name = "lone@127.0.0.1:PORT"
  let cookie = "a-development-cookie-0123456789"
  println("start=#{Node.start(name, cookie)}")
  let late = spawn(node_watcher, "late")
  Process.register("late", late)
  await_gone("late")
  println("start_again=#{Node.start(name, cookie)}")
  println("self_is_name=#{Node.self() == name}")
  println("connect=#{Node.connect("absent@127.0.0.1:1")}")
  println("nodes=#{List.length(Node.list())}")
  let pid = spawn(worker, "local")
  Process.register("worker", pid)
  println("register=#{Global.register("lone_worker", pid)}")
  println("found=#{Global.whereis("lone_worker") == pid}")
  println("unregister=#{Global.unregister("lone_worker")}")
  println("unregister_again=#{Global.unregister("lone_worker")}")
  send(pid, "hello")
  let coordinator :: Pid<String> = spawn(coordinator, "absent@127.0.0.1:1")
  Process.register("coordinator", coordinator)
  await_gone("worker")
  await_gone("coordinator")
end
"##
    .replace("PORT", &port.to_string());
    let output = compile_and_run_with_timeout(&source, 60);
    for expected in [
        "self_before=[]",
        "early_monitor=1",
        "early: nothing",
        "start=0",
        "late_monitor=0",
        "late: absent node gone",
        "start_again=-1",
        "self_is_name=true",
        "connect=-2",
        "nodes=0",
        "local: hello",
        "register=0",
        "found=true",
        "unregister=0",
        "unregister_again=1",
        "spawn=<0.0>",
        "spawn_link=<0.0>",
    ] {
        assert!(output.contains(expected), "{expected} in:\n{output}");
    }
}

/// `monitor` imported from `Process` is `Process.monitor`: typed by the
/// actor that calls it, and delivering its message. (`monitor` was a
/// reserved word, and once it was not, an import of it crashed the checker.)
#[test]
fn an_imported_monitor_is_process_monitor() {
    let source = r##"from Process import monitor

actor child() do
  receive do
    n -> println("child got #{n}")
  end
end

actor watcher() do
  let pid :: Pid<Int> = spawn(child)
  monitor(pid, "child ended")
  send(pid, 1)
  receive do
    text -> println("watcher got [#{text}]")
  end
end

fn main() do
  let w :: Pid<String> = spawn(watcher)
  Timer.sleep(1000)
end
"##;
    let output = compile_and_run(source, &[], 60);
    assert_eq!(
        output.lines().collect::<Vec<_>>(),
        ["child got 1", "watcher got [child ended]"],
        "{output}"
    );
}

/// A monitor delivers the message it was set up with, one of the watching
/// actor's own messages: when the process ends, at once when it already has,
/// and never once removed.
#[test]
fn a_monitor_delivers_its_message_when_the_process_ends() {
    let source = r##"actor child() do
  receive do
    n -> println("child got #{n}")
  end
end

actor watcher() do
  let first :: Pid<Int> = spawn(child)
  Process.monitor(first, "first ended")
  send(first, 1)
  receive do
    text -> println("watcher got [#{text}]")
  end
  Process.monitor(first, "first already ended")
  receive do
    text -> println("watcher got [#{text}]")
  end
  let second :: Pid<Int> = spawn(child)
  let reference = Process.monitor(second, "second ended")
  println("demonitor=#{Process.demonitor(reference)}")
  println("demonitor_again=#{Process.demonitor(reference)}")
  send(second, 2)
  receive do
    text -> println("unexpected [#{text}]")
  after 300 -> println("nothing after demonitor")
  end
end

fn main() do
  let w :: Pid<String> = spawn(watcher)
  Timer.sleep(1000)
end
"##;
    let output = compile_and_run(source, &["--opt-level", "2"], 60);
    assert_eq!(
        output.lines().collect::<Vec<_>>(),
        [
            "child got 1",
            "watcher got [first ended]",
            "watcher got [first already ended]",
            "demonitor=0",
            "demonitor_again=1",
            "child got 2",
            "nothing after demonitor",
        ],
        "{output}"
    );
}

#[test]
fn scalar_receives_bind_the_message_type_in_ordinary_and_grouped_actors() {
    let source = r#"
actor integer(done :: Pid<Int>) do
  let reply = receive do
    n -> n + 1
  end
  send(done, reply)
  receive do
    n -> if n != 123 do panic("received a fabricated value during shutdown") end
  end
end

actor boolean(done :: Pid<Int>) do
  let reply = receive do
    b -> if b do 42 else 0 end
  end
  send(done, reply)
end

actor floating(done :: Pid<Int>) do
  let reply = receive do
    f -> if f == -0.25 do 42 else 0 end
  end
  send(done, reply)
end

actor process_id(done :: Pid<Int>) do
  let reply = receive do
    pid -> if pid == done do 42 else 0 end
  end
  send(done, reply)
end

actor coordinate() do
  let i = SPAWN(integer, self())
  let b = SPAWN(boolean, self())
  let f = SPAWN(floating, self())
  let p = SPAWN(process_id, self())
  send(i, 41)
  send(b, true)
  send(f, -0.25)
  send(p, self())
  for i in 0..4 do
    let reply = receive do
      n -> n + 0
    after 5000 -> -1
    end
    println(reply.to_string())
  end
  let empty = receive do
    n -> n + 1
  after 0 -> 99
  end
  println(empty.to_string())
end

fn main() do
  spawn(coordinate)
end
"#;
    for spawn in ["spawn", "spawn grouped"] {
        let output = compile_and_run(&source.replace("SPAWN", spawn), &["--opt-level", "2"], 10);
        assert_eq!(
            output.lines().collect::<Vec<_>>(),
            ["42", "42", "42", "42", "99"],
            "{spawn}"
        );
    }
}

#[test]
fn timeout_only_receive_waits_and_leaves_program_messages_queued() {
    let source = r##"
actor sleeper() do
  send(self(), 17)
  Timer.send_after(self(), 5, 23)
  let start = Monotonic.now_nanos()
  let result = receive do
  after 30 -> 42
  end
  let elapsed = Monotonic.now_nanos() - start
  let first = receive do
    n -> n + 0
  after 0 -> -1
  end
  let second = receive do
    n -> n + 0
  after 1000 -> -1
  end
  println("#{result} #{first} #{second} #{elapsed >= 30000000}")
end

fn main() do
  let p = spawn(sleeper)
  Timer.sleep(100)
end
"##;
    let output = compile_and_run_with_timeout(source, 10);
    assert_eq!(output.trim(), "42 17 23 true");
}
