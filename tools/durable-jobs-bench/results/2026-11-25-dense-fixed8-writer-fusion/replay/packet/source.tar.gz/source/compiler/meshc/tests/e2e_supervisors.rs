//! End-to-end integration tests for the Mesh supervisor compiler pipeline.
//!
//! Each test compiles a .mpl program that exercises supervisor features,
//! builds it into a native binary, and verifies expected behavior.

#[path = "support/test_artifacts.rs"]
mod artifacts;

use std::path::{Path, PathBuf};
use std::process::{Command, Output};

/// Helper: compile a Mesh source file and assert it compiles successfully.
/// Returns the path to the compiled binary.
fn compile_mesh(source: &str) -> (tempfile::TempDir, PathBuf) {
    let temp_dir = tempfile::tempdir().expect("failed to create temp dir");
    let project_dir = temp_dir.path().join("project");
    std::fs::create_dir_all(&project_dir).expect("failed to create project dir");

    let main_mesh = project_dir.join("main.mpl");
    std::fs::write(&main_mesh, source).expect("failed to write main.mpl");

    // Build with meshc
    let meshc = find_meshc();
    let output = Command::new(&meshc)
        .args(["build", project_dir.to_str().unwrap()])
        .output()
        .expect("failed to invoke meshc");

    assert!(
        output.status.success(),
        "meshc build failed:\nstdout: {}\nstderr: {}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );

    let binary = project_dir.join("project");
    assert!(
        binary.exists(),
        "compiled binary not found at {}",
        binary.display()
    );

    (temp_dir, binary)
}

/// Read a test fixture from the tests/e2e/ directory.
fn read_fixture(name: &str) -> String {
    let manifest_dir = env!("CARGO_MANIFEST_DIR");
    let fixture_path = Path::new(manifest_dir)
        .parent()
        .unwrap()
        .parent()
        .unwrap()
        .join("tests")
        .join("e2e")
        .join(name);
    std::fs::read_to_string(&fixture_path)
        .unwrap_or_else(|e| panic!("failed to read fixture {}: {}", fixture_path.display(), e))
}

fn find_meshc() -> PathBuf {
    artifacts::meshc_bin()
}

/// Helper: compile a Mesh source file without asserting success.
/// Returns the raw compilation output (for negative tests).
fn compile_only(source: &str) -> Output {
    let temp_dir = tempfile::tempdir().expect("failed to create temp dir");
    let project_dir = temp_dir.path().join("project");
    std::fs::create_dir_all(&project_dir).expect("failed to create project dir");

    let main_mesh = project_dir.join("main.mpl");
    std::fs::write(&main_mesh, source).expect("failed to write main.mpl");

    let meshc = find_meshc();
    Command::new(&meshc)
        .args(["build", project_dir.to_str().unwrap()])
        .output()
        .expect("failed to invoke meshc")
}

/// Helper: run a compiled binary with a timeout and return stdout.
fn run_with_timeout(binary: &Path, timeout_secs: u64) -> String {
    let child = Command::new(binary)
        .stdout(std::process::Stdio::piped())
        .stderr(std::process::Stdio::piped())
        .spawn()
        .unwrap_or_else(|e| panic!("failed to spawn binary: {}", e));
    let output = artifacts::wait_with_timeout(child, std::time::Duration::from_secs(timeout_secs))
        .unwrap_or_else(|timed_out| panic!("{timed_out}"));

    assert!(
        output.status.success(),
        "binary failed with {}: {}",
        output.status,
        String::from_utf8_lossy(&output.stderr)
    );
    String::from_utf8_lossy(&output.stdout).to_string()
}

// ── Supervisor E2E Tests ─────────────────────────────────────────────────

/// Test: Supervisor block compiles to a native binary successfully.
///
/// This validates the full compiler pipeline: parsing supervisor blocks,
/// type checking, MIR lowering, and LLVM codegen with supervisor intrinsics.
#[test]
fn supervisor_basic() {
    let source = read_fixture("supervisor_basic.mpl");
    let (_temp_dir, binary) = compile_mesh(&source);

    // Verify the binary exists and is executable.
    assert!(binary.exists(), "compiled supervisor binary should exist");

    // Run the binary with a short timeout -- it should print and exit.
    let child = Command::new(&binary)
        .stdout(std::process::Stdio::piped())
        .stderr(std::process::Stdio::piped())
        .spawn()
        .unwrap_or_else(|e| panic!("failed to spawn binary: {}", e));
    let output = artifacts::wait_with_timeout(child, std::time::Duration::from_secs(10))
        .unwrap_or_else(|timed_out| panic!("supervisor {timed_out}"));

    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(
        stdout.contains("supervisor started"),
        "Expected 'supervisor started' in output, got: {}",
        stdout
    );
}

/// Test: one_for_all supervisor compiles and runs.
///
/// Success Criterion 2: one_for_all strategy is recognized by compiler
/// and runtime. The supervisor starts and prints expected output.
#[test]
fn supervisor_one_for_all() {
    let source = read_fixture("supervisor_one_for_all.mpl");
    let (_temp_dir, binary) = compile_mesh(&source);

    let stdout = run_with_timeout(&binary, 10);
    assert!(
        stdout.contains("one_for_all supervisor started"),
        "Expected 'one_for_all supervisor started' in output, got: {}",
        stdout
    );
}

/// Test: supervisor with restart limits compiles and runs.
///
/// Success Criterion 3: restart limits are part of the compiled supervisor
/// configuration. The supervisor starts and manages restart counting.
#[test]
fn supervisor_restart_limit() {
    let source = read_fixture("supervisor_restart_limit.mpl");
    let (_temp_dir, binary) = compile_mesh(&source);

    let stdout = run_with_timeout(&binary, 10);
    assert!(
        stdout.contains("restart limit test started"),
        "Expected 'restart limit test started' in output, got: {}",
        stdout
    );
}

/// A permanent child that panics after yielding must be restarted by its
/// one_for_one supervisor without terminating the native Mesh process.
#[test]
fn supervisor_restarts_crashed_permanent_child() {
    let source = r#"
fn deliberate_crash(0) -> Int do
  0
end

actor worker() do
  println("worker-started")
  Timer.sleep(25)
  println("worker-awake")
  deliberate_crash(1)
end

supervisor WorkerSup do
  strategy: one_for_one
  max_restarts: 3
  max_seconds: 5

  child worker do
    start: fn -> spawn(worker) end
    restart: permanent
    shutdown: 100
  end
end

fn main() do
  let _ = spawn(WorkerSup)
  Timer.sleep(750)
end
"#;
    let (_temp_dir, binary) = compile_mesh(source);
    let child = Command::new(&binary)
        .env("MESH_DIAGNOSTICS", "json")
        .stdout(std::process::Stdio::piped())
        .stderr(std::process::Stdio::piped())
        .spawn()
        .unwrap();
    let output = artifacts::wait_with_timeout(child, std::time::Duration::from_secs(10))
        .unwrap_or_else(|timed_out| panic!("{timed_out}"));
    assert!(output.status.success(), "{output:?}");
    let stdout = String::from_utf8_lossy(&output.stdout);
    let stderr = String::from_utf8_lossy(&output.stderr);

    assert!(
        stdout.matches("worker-started").count() >= 2,
        "expected a crashed permanent child to restart, got: {stdout:?}"
    );
    assert!(
        stderr.lines().any(|line| {
            serde_json::from_str::<serde_json::Value>(line)
                .is_ok_and(|report| report["code"] == "R0102")
        }),
        "{stderr}"
    );
}

/// Test: supervisor with invalid child spec is rejected at compile time.
///
/// Success Criterion 4: typed supervision validates at compile time.
/// A child spec whose start function returns Int (not Pid) produces
/// error E0018 (InvalidChildStart).
#[test]
fn supervisor_typed_error_rejected() {
    let source = read_fixture("supervisor_typed_error.mpl");
    let result = compile_only(&source);

    assert!(
        !result.status.success(),
        "Should fail to compile: start fn returns Int, not Pid"
    );

    let stderr = String::from_utf8_lossy(&result.stderr);
    let stdout = String::from_utf8_lossy(&result.stdout);
    let all_output = format!("{}{}", stdout, stderr);

    assert!(
        all_output.contains("E0018")
            || all_output.contains("must return Pid")
            || all_output.contains("InvalidChildStart"),
        "Should report child start type error (E0018).\nstdout: {}\nstderr: {}",
        stdout,
        stderr
    );
}

#[test]
fn shutdown_stops_a_receive_inside_a_closure_without_returning_to_its_caller() {
    let source = r#"
actor worker() do
  let wait_for_work = fn ->
    receive do
      _ -> println("unexpected message")
    end
  end
  wait_for_work()
  println("worker alive")
end
fn main() do
  let worker_id = spawn(worker)
  Timer.sleep(50)
  println("nested worker started")
end
"#;
    let (_temp_dir, binary) = compile_mesh(source);
    let stdout = run_with_timeout(&binary, 10);
    assert_eq!(
        stdout.trim(),
        "nested worker started",
        "shutdown returned from receive: {stdout}"
    );
}
