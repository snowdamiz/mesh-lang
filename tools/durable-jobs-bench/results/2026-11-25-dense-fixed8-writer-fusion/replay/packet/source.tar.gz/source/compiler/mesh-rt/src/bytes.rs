//! Binary-safe, GC-managed byte values for the Mesh runtime.
//!
//! `MeshBytes` deliberately has no implicit relationship with `MeshString`.
//! UTF-8 conversion is explicit and fallible in the bytes-to-string direction.

use std::ptr;

use base64::{engine::general_purpose, Engine as _};
use subtle::ConstantTimeEq;

use crate::collections::list::{
    mesh_list_builder_new, mesh_list_builder_push, mesh_list_get, mesh_list_length,
};
use crate::gc::{alloc_actor_leaf, mesh_gc_alloc_actor};
use crate::io::{alloc_result, err_result, ok_int, MeshResult};
use crate::string::{mesh_str, MeshString};
use crate::wide_num::{mesh_u64_new, mesh_u64_value, MeshWideNum};

const BASE58: &[u8; 58] = b"123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";

#[repr(C)]
pub struct MeshBytes {
    pub len: u64,
    // bytes follow immediately after this header
}

// ponytail: one 64 KiB frame ceiling; add per-actor public-byte quotas before raising it.
const MAX_BYTES_BUILDER_BYTES: usize = 64 * 1024;
const BYTES_BUILDER_MAGIC: u64 = 0x4d45_5348_4255_494c;

#[repr(u8)]
#[derive(Clone, Copy)]
enum BinaryErrorTag {
    InvalidLimit = 0,
    InvalidLength = 2,
    InvalidValue = 6,
    OutputTooLarge = 7,
}

#[derive(Clone, Copy)]
enum BuilderError {
    Invalid,
    Limit,
}

#[repr(C)]
struct MeshBinaryError {
    tag: u8,
}

#[repr(C)]
struct MeshBytesBuilder {
    magic: u64,
    len: u64,
    maximum: u64,
    finished: u8,
    _padding: [u8; 7],
    // bytes follow immediately after this header
}

impl MeshBytesBuilder {
    const HEADER_SIZE: usize = std::mem::size_of::<Self>();

    unsafe fn data_ptr(&self) -> *const u8 {
        (self as *const Self as *const u8).add(Self::HEADER_SIZE)
    }

    unsafe fn data_ptr_mut(&mut self) -> *mut u8 {
        (self as *mut Self as *mut u8).add(Self::HEADER_SIZE)
    }
}

impl MeshBytes {
    const HEADER_SIZE: usize = std::mem::size_of::<u64>();

    unsafe fn data_ptr(&self) -> *const u8 {
        (self as *const Self as *const u8).add(Self::HEADER_SIZE)
    }

    unsafe fn data_ptr_mut(&mut self) -> *mut u8 {
        (self as *mut Self as *mut u8).add(Self::HEADER_SIZE)
    }

    pub(crate) unsafe fn as_slice(&self) -> &[u8] {
        std::slice::from_raw_parts(self.data_ptr(), self.len as usize)
    }
}

fn ok_bytes(bytes: &[u8]) -> *mut MeshResult {
    alloc_result(
        0,
        mesh_bytes_new(bytes.as_ptr(), bytes.len() as u64) as *mut u8,
    )
}

fn ok_u64(value: u64) -> *mut MeshResult {
    alloc_result(0, mesh_u64_new(value).cast())
}

fn binary_error(tag: BinaryErrorTag) -> *mut MeshResult {
    let value = mesh_gc_alloc_actor(std::mem::size_of::<MeshBinaryError>() as u64, 8)
        as *mut MeshBinaryError;
    unsafe { value.write(MeshBinaryError { tag: tag as u8 }) };
    alloc_result(1, value.cast())
}

fn allocate(len: usize, leaf: bool) -> *mut MeshBytes {
    let Some(total) = MeshBytes::HEADER_SIZE.checked_add(len) else {
        return ptr::null_mut();
    };
    if total > isize::MAX as usize {
        return ptr::null_mut();
    }

    unsafe {
        let allocation = if leaf {
            alloc_actor_leaf(total as u64, 8)
        } else {
            mesh_gc_alloc_actor(total as u64, 8)
        };
        let value = allocation.cast::<MeshBytes>();
        (*value).len = len as u64;
        value
    }
}

/// A builder of at most `maximum` bytes, which is at most
/// `MAX_BYTES_BUILDER_BYTES`.
fn allocate_builder(maximum: usize) -> *mut MeshBytesBuilder {
    let total = MeshBytesBuilder::HEADER_SIZE + maximum;
    unsafe {
        let builder = mesh_gc_alloc_actor(total as u64, 8) as *mut MeshBytesBuilder;
        builder.write(MeshBytesBuilder {
            magic: BYTES_BUILDER_MAGIC,
            len: 0,
            maximum: maximum as u64,
            finished: 0,
            _padding: [0; 7],
        });
        builder
    }
}

/// Run `operation` on the builder at `pointer`, which must be a live,
/// unfinished builder allocation of the calling actor's heap. The heap finds
/// the allocation by address before anything is read through the pointer.
fn with_live_builder<R>(
    pointer: *mut MeshBytesBuilder,
    operation: impl FnOnce(&mut MeshBytesBuilder) -> Result<R, BuilderError>,
) -> Result<R, BuilderError> {
    let process = crate::actor::current_process().ok_or(BuilderError::Invalid)?;
    let process = process.lock();
    let allocation_size = process
        .heap
        .live_allocation_size(pointer.cast())
        .filter(|size| *size >= MeshBytesBuilder::HEADER_SIZE)
        .ok_or(BuilderError::Invalid)?;
    let builder = unsafe { &mut *pointer };
    let maximum = usize::try_from(builder.maximum).map_err(|_| BuilderError::Invalid)?;
    let length = usize::try_from(builder.len).map_err(|_| BuilderError::Invalid)?;
    let needed = MeshBytesBuilder::HEADER_SIZE
        .checked_add(maximum)
        .ok_or(BuilderError::Invalid)?;
    if builder.magic != BYTES_BUILDER_MAGIC
        || maximum > MAX_BYTES_BUILDER_BYTES
        || length > maximum
        || needed > allocation_size
        || builder.finished != 0
    {
        return Err(BuilderError::Invalid);
    }
    operation(builder)
}

unsafe fn append_builder(builder: &mut MeshBytesBuilder, input: &[u8]) -> Result<(), BuilderError> {
    let end = (builder.len as usize)
        .checked_add(input.len())
        .filter(|end| *end <= builder.maximum as usize)
        .ok_or(BuilderError::Limit)?;
    if !input.is_empty() {
        ptr::copy_nonoverlapping(
            input.as_ptr(),
            builder.data_ptr_mut().add(builder.len as usize),
            input.len(),
        );
    }
    builder.len = end as u64;
    Ok(())
}

fn builder_error(error: BuilderError) -> *mut MeshResult {
    match error {
        BuilderError::Invalid => binary_error(BinaryErrorTag::InvalidLength),
        BuilderError::Limit => binary_error(BinaryErrorTag::OutputTooLarge),
    }
}

fn write_builder(pointer: *mut MeshBytesBuilder, input: &[u8]) -> *mut MeshResult {
    with_live_builder(pointer, |builder| unsafe { append_builder(builder, input) })
        .map(|()| alloc_result(0, ptr::null_mut()))
        .unwrap_or_else(builder_error)
}

fn base58_encode(input: &[u8]) -> String {
    let zeroes = input.iter().take_while(|byte| **byte == 0).count();
    let mut digits = vec![0u8];
    for byte in input {
        let mut carry = *byte as u32;
        for digit in &mut digits {
            let value = (*digit as u32) * 256 + carry;
            *digit = (value % 58) as u8;
            carry = value / 58;
        }
        while carry > 0 {
            digits.push((carry % 58) as u8);
            carry /= 58;
        }
    }

    let mut encoded = String::with_capacity(zeroes + digits.len());
    encoded.extend(std::iter::repeat_n('1', zeroes));
    encoded.extend(
        digits
            .iter()
            .rev()
            .skip_while(|digit| **digit == 0)
            .map(|digit| BASE58[*digit as usize] as char),
    );
    encoded
}

fn base58_decode(input: &str) -> Result<Vec<u8>, ()> {
    let zeroes = input.bytes().take_while(|byte| *byte == b'1').count();
    let mut bytes = vec![0u8];
    for encoded in input.bytes() {
        let mut carry = BASE58
            .iter()
            .position(|candidate| *candidate == encoded)
            .ok_or(())? as u32;
        for byte in &mut bytes {
            let value = (*byte as u32) * 58 + carry;
            *byte = value as u8;
            carry = value >> 8;
        }
        while carry > 0 {
            bytes.push(carry as u8);
            carry >>= 8;
        }
    }

    let mut decoded = Vec::with_capacity(zeroes + bytes.len());
    decoded.resize(zeroes, 0);
    decoded.extend(bytes.iter().rev().skip_while(|byte| **byte == 0));
    Ok(decoded)
}

/// Native ABI constructor. `data` is borrowed only for this call.
///
/// A null `data` pointer is valid only when `len` is zero.
#[no_mangle]
pub extern "C" fn mesh_bytes_new(data: *const u8, len: u64) -> *mut MeshBytes {
    // No wider than a usize on the 64-bit targets the runtime builds for;
    // anywhere else, a length past usize is refused like one past isize.
    let len = usize::try_from(len).unwrap_or(usize::MAX);
    if data.is_null() && len != 0 {
        return ptr::null_mut();
    }
    unsafe { copy_bytes(data, len, false) }
}

unsafe fn copy_bytes(data: *const u8, len: usize, leaf: bool) -> *mut MeshBytes {
    let value = allocate(len, leaf);
    if value.is_null() {
        return ptr::null_mut();
    }

    unsafe {
        if len != 0 {
            ptr::copy_nonoverlapping(data, (*value).data_ptr_mut(), len);
        }
        value
    }
}

/// Native package ABI: copy a borrowed native buffer into a managed `Bytes`.
#[no_mangle]
pub extern "C" fn mesh_bytes_copy_from(data: *const u8, len: u64) -> *mut MeshBytes {
    mesh_bytes_new(data, len)
}

/// Native package ABI: copy a checked range into caller-owned memory.
///
/// Returns the copied byte count, or `-1` for a null pointer/out-of-bounds range.
#[no_mangle]
pub extern "C" fn mesh_bytes_copy_to(
    bytes: *const MeshBytes,
    offset: i64,
    destination: *mut u8,
    len: u64,
) -> i64 {
    if bytes.is_null() || destination.is_null() || offset < 0 || len > i64::MAX as u64 {
        return -1;
    }
    let offset = offset as u64;
    unsafe {
        if offset.checked_add(len).is_none_or(|end| end > (*bytes).len) {
            return -1;
        }
        ptr::copy_nonoverlapping(
            (*bytes).data_ptr().add(offset as usize),
            destination,
            len as usize,
        );
    }
    len as i64
}

#[no_mangle]
pub extern "C" fn mesh_bytes_empty() -> *mut MeshBytes {
    mesh_bytes_new(ptr::null(), 0)
}

#[no_mangle]
pub extern "C" fn mesh_bytes_builder_new(maximum: i64) -> *mut MeshResult {
    let Ok(maximum) = usize::try_from(maximum) else {
        return binary_error(BinaryErrorTag::InvalidLimit);
    };
    if maximum > MAX_BYTES_BUILDER_BYTES {
        return binary_error(BinaryErrorTag::InvalidLimit);
    }
    alloc_result(0, allocate_builder(maximum).cast())
}

#[no_mangle]
pub extern "C" fn mesh_bytes_builder_write_u8(builder: *mut u8, value: i64) -> *mut MeshResult {
    let Ok(value) = u8::try_from(value) else {
        return binary_error(BinaryErrorTag::InvalidValue);
    };
    write_builder(builder.cast(), &[value])
}

#[no_mangle]
pub extern "C" fn mesh_bytes_builder_write_u16_be(builder: *mut u8, value: i64) -> *mut MeshResult {
    let Ok(value) = u16::try_from(value) else {
        return binary_error(BinaryErrorTag::InvalidValue);
    };
    write_builder(builder.cast(), &value.to_be_bytes())
}

#[no_mangle]
pub extern "C" fn mesh_bytes_builder_write_u32_be(builder: *mut u8, value: i64) -> *mut MeshResult {
    let Ok(value) = u32::try_from(value) else {
        return binary_error(BinaryErrorTag::InvalidValue);
    };
    write_builder(builder.cast(), &value.to_be_bytes())
}

#[no_mangle]
pub extern "C" fn mesh_bytes_builder_write_bytes(
    builder: *mut u8,
    value: *const MeshBytes,
) -> *mut MeshResult {
    if value.is_null() {
        return binary_error(BinaryErrorTag::InvalidValue);
    }
    unsafe { write_builder(builder.cast(), (*value).as_slice()) }
}

#[no_mangle]
pub extern "C" fn mesh_bytes_builder_finish(builder: *mut u8) -> *mut MeshResult {
    // Copied out first: the Bytes cannot be allocated while the builder's
    // actor is locked.
    let finished = with_live_builder(builder.cast(), |builder| {
        let bytes = unsafe { std::slice::from_raw_parts(builder.data_ptr(), builder.len as usize) };
        builder.finished = 1;
        Ok(bytes.to_vec())
    });
    finished
        .map(|bytes| ok_bytes(&bytes))
        .unwrap_or_else(builder_error)
}

#[no_mangle]
pub extern "C" fn mesh_bytes_from_list(values: *mut u8) -> *mut MeshResult {
    if values.is_null() {
        return err_result("invalid byte list");
    }
    // A list's length is never negative, and one that fits in memory fits
    // a Bytes: `allocate` refuses only lengths past isize::MAX.
    let len = mesh_list_length(values) as usize;
    for index in 0..len {
        if mesh_list_get(values, index as i64) > u8::MAX as u64 {
            return err_result("byte value out of range");
        }
    }
    let bytes = allocate(len, true);
    unsafe {
        for index in 0..len {
            *(*bytes).data_ptr_mut().add(index) = mesh_list_get(values, index as i64) as u8;
        }
    }
    alloc_result(0, bytes.cast())
}

#[no_mangle]
pub extern "C" fn mesh_bytes_to_list(bytes: *const MeshBytes) -> *mut u8 {
    if bytes.is_null() {
        return mesh_list_builder_new(0);
    }
    unsafe {
        let mut values = mesh_list_builder_new((*bytes).len as i64);
        for byte in (*bytes).as_slice() {
            values = mesh_list_builder_push(values, *byte as u64);
        }
        values
    }
}

#[no_mangle]
pub extern "C" fn mesh_bytes_repeat(byte: i64, count: i64) -> *mut MeshResult {
    if !(0..=u8::MAX as i64).contains(&byte) {
        return err_result("byte value out of range");
    }
    let Ok(count) = usize::try_from(count) else {
        return err_result("byte count out of range");
    };
    let bytes = allocate(count, true);
    if bytes.is_null() {
        return err_result("byte length overflow");
    }
    unsafe {
        ptr::write_bytes((*bytes).data_ptr_mut(), byte as u8, count);
    }
    alloc_result(0, bytes.cast())
}

#[no_mangle]
pub extern "C" fn mesh_bytes_length(bytes: *const MeshBytes) -> i64 {
    unsafe { (*bytes).len as i64 }
}

#[no_mangle]
pub extern "C" fn mesh_bytes_get(bytes: *const MeshBytes, index: i64) -> *mut MeshResult {
    unsafe {
        if index < 0 || index as u64 >= (*bytes).len {
            return err_result("byte index out of bounds");
        }
        ok_int(*(*bytes).data_ptr().add(index as usize) as i64)
    }
}

#[no_mangle]
pub extern "C" fn mesh_bytes_slice(
    bytes: *const MeshBytes,
    start: i64,
    len: i64,
) -> *mut MeshResult {
    if start < 0 || len < 0 {
        return err_result("byte slice out of bounds");
    }
    unsafe {
        let start = start as u64;
        let len = len as u64;
        if start.checked_add(len).is_none_or(|end| end > (*bytes).len) {
            return err_result("byte slice out of bounds");
        }
        ok_bytes(std::slice::from_raw_parts(
            (*bytes).data_ptr().add(start as usize),
            len as usize,
        ))
    }
}

#[no_mangle]
pub extern "C" fn mesh_bytes_concat(
    left: *const MeshBytes,
    right: *const MeshBytes,
) -> *mut MeshResult {
    unsafe {
        let value = (*left)
            .len
            .checked_add((*right).len)
            .and_then(|len| usize::try_from(len).ok())
            .map_or(ptr::null_mut(), |len| allocate(len, false));
        if value.is_null() {
            return err_result("byte length overflow");
        }
        ptr::copy_nonoverlapping(
            (*left).data_ptr(),
            (*value).data_ptr_mut(),
            (*left).len as usize,
        );
        ptr::copy_nonoverlapping(
            (*right).data_ptr(),
            (*value).data_ptr_mut().add((*left).len as usize),
            (*right).len as usize,
        );
        alloc_result(0, value as *mut u8)
    }
}

#[no_mangle]
pub extern "C" fn mesh_bytes_secure_equals(left: *const MeshBytes, right: *const MeshBytes) -> i8 {
    unsafe {
        let left = (*left).as_slice();
        let right = (*right).as_slice();
        left.ct_eq(right).unwrap_u8() as i8
    }
}

#[no_mangle]
pub extern "C" fn mesh_bytes_from_utf8(text: *const MeshString) -> *mut MeshBytes {
    unsafe {
        let bytes = (*text).as_bytes();
        copy_bytes(bytes.as_ptr(), bytes.len(), true)
    }
}

#[no_mangle]
pub extern "C" fn mesh_bytes_to_utf8(bytes: *const MeshBytes) -> *mut MeshResult {
    unsafe {
        match std::str::from_utf8((*bytes).as_slice()) {
            Ok(text) => alloc_result(0, mesh_str(text) as *mut u8),
            Err(_) => err_result("invalid utf-8"),
        }
    }
}

#[no_mangle]
pub extern "C" fn mesh_bytes_to_base64(bytes: *const MeshBytes) -> *mut MeshString {
    mesh_str(&general_purpose::STANDARD.encode(unsafe { (*bytes).as_slice() }))
}

/// The bytes of standard base64 text, with or without its padding.
pub(crate) fn decode_base64(text: &str) -> Option<Vec<u8>> {
    general_purpose::STANDARD
        .decode(text)
        .or_else(|_| general_purpose::STANDARD_NO_PAD.decode(text))
        .ok()
}

#[no_mangle]
pub extern "C" fn mesh_bytes_from_base64(text: *const MeshString) -> *mut MeshResult {
    match decode_base64(unsafe { (*text).as_str() }) {
        Some(decoded) => ok_bytes(&decoded),
        None => err_result("invalid base64"),
    }
}

#[no_mangle]
pub extern "C" fn mesh_bytes_to_base58(bytes: *const MeshBytes) -> *mut MeshString {
    mesh_str(&base58_encode(unsafe { (*bytes).as_slice() }))
}

#[no_mangle]
pub extern "C" fn mesh_bytes_from_base58(text: *const MeshString) -> *mut MeshResult {
    unsafe {
        base58_decode((*text).as_str())
            .map(|bytes| ok_bytes(&bytes))
            .unwrap_or_else(|_| err_result("invalid base58"))
    }
}

/// Lowercase hex text of `bytes`.
pub(crate) fn hex_string(bytes: &[u8]) -> *mut MeshString {
    const HEX: &[u8; 16] = b"0123456789abcdef";
    let mut encoded = String::with_capacity(bytes.len() * 2);
    for byte in bytes {
        encoded.push(HEX[(byte >> 4) as usize] as char);
        encoded.push(HEX[(byte & 0x0f) as usize] as char);
    }
    mesh_str(&encoded)
}

#[no_mangle]
pub extern "C" fn mesh_bytes_to_hex(bytes: *const MeshBytes) -> *mut MeshString {
    hex_string(unsafe { (*bytes).as_slice() })
}

/// The bytes that pairs of hex digits of either case spell, or `None` for any
/// other text.
pub(crate) fn decode_hex(text: &str) -> Option<Vec<u8>> {
    if !text.len().is_multiple_of(2) {
        return None;
    }
    let digit = |byte: u8| (byte as char).to_digit(16);
    text.as_bytes()
        .chunks_exact(2)
        .map(|pair| Some((digit(pair[0])? << 4 | digit(pair[1])?) as u8))
        .collect()
}

#[no_mangle]
pub extern "C" fn mesh_bytes_from_hex(text: *const MeshString) -> *mut MeshResult {
    match decode_hex(unsafe { (*text).as_str() }) {
        Some(decoded) => ok_bytes(&decoded),
        None => err_result("invalid hex"),
    }
}

fn read_uint(
    bytes: *const MeshBytes,
    offset: i64,
    width: usize,
    big_endian: bool,
) -> Result<u64, &'static str> {
    if bytes.is_null() || offset < 0 {
        return Err("unsigned integer read out of bounds");
    }
    unsafe {
        let offset = offset as u64;
        if offset
            .checked_add(width as u64)
            .is_none_or(|end| end > (*bytes).len)
        {
            return Err("unsigned integer read out of bounds");
        }
        let mut encoded = [0u8; 8];
        let destination = if big_endian {
            encoded[8 - width..].as_mut_ptr()
        } else {
            encoded.as_mut_ptr()
        };
        ptr::copy_nonoverlapping((*bytes).data_ptr().add(offset as usize), destination, width);
        Ok(if big_endian {
            u64::from_be_bytes(encoded)
        } else {
            u64::from_le_bytes(encoded)
        })
    }
}

fn read_int_result(
    bytes: *const MeshBytes,
    offset: i64,
    width: usize,
    big_endian: bool,
) -> *mut MeshResult {
    read_uint(bytes, offset, width, big_endian)
        .map(|value| ok_int(value as i64))
        .unwrap_or_else(err_result)
}

fn read_u64_result(
    bytes: *const MeshBytes,
    offset: i64,
    width: usize,
    big_endian: bool,
) -> *mut MeshResult {
    read_uint(bytes, offset, width, big_endian)
        .map(ok_u64)
        .unwrap_or_else(err_result)
}

#[no_mangle]
pub extern "C" fn mesh_bytes_read_u16_be(bytes: *const MeshBytes, offset: i64) -> *mut MeshResult {
    read_int_result(bytes, offset, 2, true)
}

#[no_mangle]
pub extern "C" fn mesh_bytes_read_u16_le(bytes: *const MeshBytes, offset: i64) -> *mut MeshResult {
    read_int_result(bytes, offset, 2, false)
}

#[no_mangle]
pub extern "C" fn mesh_bytes_read_u32_be(bytes: *const MeshBytes, offset: i64) -> *mut MeshResult {
    read_u64_result(bytes, offset, 4, true)
}

#[no_mangle]
pub extern "C" fn mesh_bytes_read_u32_le(bytes: *const MeshBytes, offset: i64) -> *mut MeshResult {
    read_u64_result(bytes, offset, 4, false)
}

#[no_mangle]
pub extern "C" fn mesh_bytes_read_u64_be(bytes: *const MeshBytes, offset: i64) -> *mut MeshResult {
    read_u64_result(bytes, offset, 8, true)
}

#[no_mangle]
pub extern "C" fn mesh_bytes_read_u64_le(bytes: *const MeshBytes, offset: i64) -> *mut MeshResult {
    read_u64_result(bytes, offset, 8, false)
}

fn write_uint(value: u64, width: usize, big_endian: bool) -> *mut MeshResult {
    if width < 8 && value >= (1u64 << (width * 8)) {
        return err_result("unsigned integer does not fit width");
    }
    let encoded = if big_endian {
        value.to_be_bytes()
    } else {
        value.to_le_bytes()
    };
    if big_endian {
        ok_bytes(&encoded[8 - width..])
    } else {
        ok_bytes(&encoded[..width])
    }
}

#[no_mangle]
pub extern "C" fn mesh_bytes_write_u16_be(value: i64) -> *mut MeshResult {
    if value < 0 {
        return err_result("unsigned integer does not fit width");
    }
    write_uint(value as u64, 2, true)
}

#[no_mangle]
pub extern "C" fn mesh_bytes_write_u32_be(value: *const MeshWideNum) -> *mut MeshResult {
    unsafe { write_uint(mesh_u64_value(value), 4, true) }
}

#[no_mangle]
pub extern "C" fn mesh_bytes_write_u64_be(value: *const MeshWideNum) -> *mut MeshResult {
    unsafe { write_uint(mesh_u64_value(value), 8, true) }
}

#[no_mangle]
pub extern "C" fn mesh_bytes_read_uint_le(
    bytes: *const MeshBytes,
    offset: i64,
    width: i64,
) -> *mut MeshResult {
    if offset < 0 || !matches!(width, 1 | 2 | 4 | 8) {
        return err_result("invalid unsigned integer width or offset");
    }
    read_uint(bytes, offset, width as usize, false)
        .map(|value| {
            let value = value.to_string();
            alloc_result(0, mesh_str(&value) as *mut u8)
        })
        .unwrap_or_else(err_result)
}

#[no_mangle]
pub extern "C" fn mesh_bytes_write_uint_le(
    value: *const MeshString,
    width: i64,
) -> *mut MeshResult {
    if !matches!(width, 1 | 2 | 4 | 8) {
        return err_result("invalid unsigned integer width");
    }
    unsafe {
        let Ok(value) = (*value).as_str().parse::<u64>() else {
            return err_result("invalid unsigned integer");
        };
        write_uint(value, width as usize, false)
    }
}

#[cfg(test)]
pub(crate) mod tests {
    use super::*;
    use crate::gc::mesh_rt_init;

    fn refused(result: *mut MeshResult) -> String {
        let result = unsafe { &*result };
        assert_eq!(result.tag, 1, "expected an error");
        unsafe { (*(result.value as *const MeshString)).as_str().to_string() }
    }

    fn refused_as(result: *mut MeshResult) -> u8 {
        let result = unsafe { &*result };
        assert_eq!(result.tag, 1, "expected an error");
        unsafe { (*(result.value as *const MeshBinaryError)).tag }
    }

    /// Each constructor and writer refuses input it cannot represent, with
    /// what is wrong with it, before it allocates or writes anything.
    #[test]
    fn invalid_input_is_refused_for_what_is_wrong_with_it() {
        mesh_rt_init();
        let one = [1u8];
        assert!(
            mesh_bytes_new(ptr::null(), 3).is_null(),
            "no data for three bytes"
        );
        assert!(mesh_bytes_new(one.as_ptr(), u64::MAX).is_null());
        assert!(mesh_bytes_new(one.as_ptr(), isize::MAX as u64).is_null());
        assert_eq!(
            refused(mesh_bytes_repeat(256, 1)),
            "byte value out of range"
        );
        assert_eq!(refused(mesh_bytes_repeat(1, -1)), "byte count out of range");
        assert_eq!(
            refused(mesh_bytes_repeat(1, i64::MAX)),
            "byte length overflow"
        );
        let mut list = crate::collections::list::mesh_list_new();
        list = crate::collections::list::mesh_list_append(list, 300);
        assert_eq!(
            refused(mesh_bytes_from_list(list)),
            "byte value out of range"
        );
        assert_eq!(
            refused(mesh_bytes_from_list(ptr::null_mut())),
            "invalid byte list"
        );
        assert_eq!(refused(mesh_bytes_from_hex(mesh_str("abc"))), "invalid hex");
        assert_eq!(refused(mesh_bytes_from_hex(mesh_str("zz"))), "invalid hex");
        assert_eq!(refused(mesh_bytes_from_hex(mesh_str("0z"))), "invalid hex");
        assert_eq!(
            refused(mesh_bytes_write_uint_le(mesh_str("1"), 3)),
            "invalid unsigned integer width"
        );
        assert_eq!(
            refused(mesh_bytes_write_uint_le(mesh_str("-1"), 4)),
            "invalid unsigned integer"
        );
        assert_eq!(
            refused(mesh_bytes_write_u16_be(-1)),
            "unsigned integer does not fit width"
        );
        let huge = MeshBytes { len: u64::MAX };
        assert_eq!(
            refused(mesh_bytes_concat(&huge, &huge)),
            "byte length overflow"
        );
        let large = MeshBytes {
            len: isize::MAX as u64,
        };
        assert_eq!(
            refused(mesh_bytes_concat(&large, &large)),
            "byte length overflow"
        );

        assert_eq!(
            refused_as(mesh_bytes_builder_new(-1)),
            BinaryErrorTag::InvalidLimit as u8
        );
        assert_eq!(
            refused_as(mesh_bytes_builder_new(MAX_BYTES_BUILDER_BYTES as i64 + 1)),
            BinaryErrorTag::InvalidLimit as u8
        );
        let builder = ptr::null_mut();
        assert_eq!(
            refused_as(mesh_bytes_builder_write_u16_be(builder, 1 << 16)),
            BinaryErrorTag::InvalidValue as u8
        );
        assert_eq!(
            refused_as(mesh_bytes_builder_write_u32_be(builder, 1 << 32)),
            BinaryErrorTag::InvalidValue as u8
        );
        assert_eq!(
            refused_as(mesh_bytes_builder_write_bytes(builder, ptr::null())),
            BinaryErrorTag::InvalidValue as u8
        );
        assert_eq!(
            refused_as(mesh_bytes_builder_finish(builder)),
            BinaryErrorTag::InvalidLength as u8
        );
        let empty = mesh_bytes_to_list(ptr::null());
        assert_eq!(crate::collections::list::mesh_list_length(empty), 0);
        let mut destination = [0u8; 4];
        assert_eq!(
            mesh_bytes_copy_to(ptr::null(), 0, destination.as_mut_ptr(), 1),
            -1
        );
    }

    fn slice_of<'a>(bytes: *const MeshBytes) -> &'a [u8] {
        unsafe { (*bytes).as_slice() }
    }

    fn accepted(result: *mut MeshResult) -> *mut u8 {
        let result = unsafe { &*result };
        assert_eq!(result.tag, 0, "expected Ok");
        result.value
    }

    fn accepted_bytes<'a>(result: *mut MeshResult) -> &'a [u8] {
        slice_of(accepted(result).cast())
    }

    fn text<'a>(value: *mut MeshString) -> &'a str {
        unsafe { (*value).as_str() }
    }

    /// Every constructor, accessor and codec returns what it was given back
    /// in its own form, and refuses the input that has none.
    #[test]
    fn values_round_trip_through_every_codec() {
        mesh_rt_init();
        let bytes = mesh_bytes_copy_from([1, 2, 0xff].as_ptr(), 3);
        assert_eq!(slice_of(mesh_bytes_empty()), [] as [u8; 0]);
        let list = mesh_bytes_to_list(bytes);
        assert_eq!(accepted_bytes(mesh_bytes_from_list(list)), [1, 2, 0xff]);
        assert_eq!(accepted_bytes(mesh_bytes_repeat(7, 3)), [7, 7, 7]);
        assert_eq!(mesh_bytes_length(bytes), 3);
        assert_eq!(
            unsafe { *accepted(mesh_bytes_get(bytes, 2)).cast::<i64>() },
            0xff
        );
        for index in [-1, 3] {
            assert_eq!(
                refused(mesh_bytes_get(bytes, index)),
                "byte index out of bounds"
            );
        }
        assert_eq!(accepted_bytes(mesh_bytes_slice(bytes, 1, 2)), [2, 0xff]);
        let joined = mesh_bytes_concat(bytes, bytes);
        assert_eq!(accepted_bytes(joined), [1, 2, 0xff, 1, 2, 0xff]);
        assert_eq!(mesh_bytes_secure_equals(bytes, bytes), 1);

        let hello = mesh_bytes_from_utf8(mesh_str("héllo"));
        assert_eq!(text(accepted(mesh_bytes_to_utf8(hello)).cast()), "héllo");
        assert_eq!(refused(mesh_bytes_to_utf8(bytes)), "invalid utf-8");
        assert_eq!(text(mesh_bytes_to_base64(bytes)), "AQL/");
        for encoded in ["AQL/", "AQ", "AQ=="] {
            let decoded = mesh_bytes_from_base64(mesh_str(encoded));
            assert_eq!(accepted_bytes(decoded)[0], 1, "{encoded}");
        }
        assert_eq!(
            refused(mesh_bytes_from_base64(mesh_str("A"))),
            "invalid base64"
        );
        assert_eq!(
            refused(mesh_bytes_from_base58(mesh_str("0"))),
            "invalid base58"
        );
        assert_eq!(text(mesh_bytes_to_hex(bytes)), "0102ff");
        assert_eq!(
            accepted_bytes(mesh_bytes_from_hex(mesh_str("0102FF"))),
            [1, 2, 0xff]
        );

        let read = mesh_bytes_read_uint_le(bytes, 1, 2);
        assert_eq!(text(accepted(read).cast()), "65282");
        for (offset, width) in [(-1, 1), (0, 3)] {
            assert_eq!(
                refused(mesh_bytes_read_uint_le(bytes, offset, width)),
                "invalid unsigned integer width or offset"
            );
        }
        assert_eq!(
            refused(mesh_bytes_read_uint_le(bytes, 0, 4)),
            "unsigned integer read out of bounds"
        );
        assert_eq!(accepted_bytes(mesh_bytes_write_u16_be(0x0102)), [1, 2]);
        let large = mesh_u64_new(1 << 32);
        assert_eq!(
            refused(mesh_bytes_write_u32_be(large)),
            "unsigned integer does not fit width"
        );
        assert_eq!(
            accepted_bytes(mesh_bytes_write_u32_be(mesh_u64_new(5))),
            [0, 0, 0, 5]
        );
        assert_eq!(accepted_bytes(mesh_bytes_write_u64_be(large))[3], 1);
        let written = mesh_bytes_write_uint_le(mesh_str("258"), 2);
        assert_eq!(accepted_bytes(written), [2, 1]);
    }

    /// A builder is looked up by its address: a write does not read every
    /// object of the actor's heap, however many the actor holds.
    #[test]
    fn builder_writes_do_not_walk_the_actor_heap() {
        mesh_rt_init();
        let elapsed = crate::secret::as_test_actor(|_| {
            let builder = accepted(mesh_bytes_builder_new(MAX_BYTES_BUILDER_BYTES as i64));
            let process = crate::actor::current_process().expect("test actor");
            for _ in 0..200_000 {
                process.lock().heap.alloc(8, 8);
            }
            let start = Instant::now();
            for _ in 0..10_000 {
                accepted(mesh_bytes_builder_write_u8(builder, 7));
            }
            start.elapsed()
        });
        // Two billion header reads take the better part of a minute; ten
        // thousand lookups take milliseconds, even on a loaded host.
        assert!(
            elapsed < std::time::Duration::from_secs(2),
            "a builder write took {:?}",
            elapsed / 10_000
        );
    }

    /// A builder takes writes up to its limit, finishes once, and refuses
    /// anything that is not a live, unfinished builder of the calling actor.
    #[test]
    fn a_builder_writes_up_to_its_limit_and_finishes_once() {
        let off_actor = MeshBytesBuilder {
            magic: BYTES_BUILDER_MAGIC,
            len: 0,
            maximum: 4,
            finished: 0,
            _padding: [0; 7],
        };
        let foreign = (&off_actor as *const MeshBytesBuilder)
            .cast_mut()
            .cast::<u8>();
        mesh_rt_init();
        assert_eq!(
            refused_as(mesh_bytes_builder_write_u8(foreign, 1)),
            BinaryErrorTag::InvalidLength as u8
        );
        let written = crate::secret::as_test_actor(|_| {
            let builder = accepted(mesh_bytes_builder_new(4));
            accepted(mesh_bytes_builder_write_u8(builder, 1));
            accepted(mesh_bytes_builder_write_u16_be(builder, 0x0203));
            assert_eq!(
                refused_as(mesh_bytes_builder_write_u8(builder, 256)),
                BinaryErrorTag::InvalidValue as u8
            );
            assert_eq!(
                refused_as(mesh_bytes_builder_write_u32_be(builder, 5)),
                BinaryErrorTag::OutputTooLarge as u8
            );
            let four = mesh_bytes_copy_from([4].as_ptr(), 1);
            accepted(mesh_bytes_builder_write_bytes(builder, four));
            let written = accepted_bytes(mesh_bytes_builder_finish(builder)).to_vec();
            for refusal in [
                mesh_bytes_builder_write_u8(builder, 1),
                mesh_bytes_builder_finish(builder),
                mesh_bytes_builder_write_u8(foreign, 1),
            ] {
                assert_eq!(refused_as(refusal), BinaryErrorTag::InvalidLength as u8);
            }
            written
        });
        assert_eq!(written, [1, 2, 3, 4]);
    }
    use rand::{rngs::StdRng, Rng, SeedableRng};
    use std::hint::black_box;
    use std::time::Instant;

    #[derive(Default)]
    pub(crate) struct TimingStats {
        count: f64,
        sum: f64,
        sum_squares: f64,
    }

    impl TimingStats {
        pub(crate) fn record(&mut self, value: f64) {
            self.count += 1.0;
            self.sum += value;
            self.sum_squares += value * value;
        }

        pub(crate) fn mean(&self) -> f64 {
            self.sum / self.count
        }

        fn variance(&self) -> f64 {
            ((self.sum_squares - self.sum * self.sum / self.count) / (self.count - 1.0)).max(0.0)
        }
    }

    pub(crate) fn welch_t(left: &TimingStats, right: &TimingStats) -> f64 {
        let standard_error = (left.variance() / left.count + right.variance() / right.count).sqrt();
        if standard_error == 0.0 {
            return if left.mean() == right.mean() {
                0.0
            } else {
                f64::INFINITY
            };
        }
        ((left.mean() - right.mean()) / standard_error).abs()
    }

    fn comparison_nanos(left: *const MeshBytes, right: *const MeshBytes, repeats: usize) -> f64 {
        let start = Instant::now();
        for _ in 0..repeats {
            black_box(mesh_bytes_secure_equals(black_box(left), black_box(right)));
        }
        start.elapsed().as_nanos() as f64
    }

    #[test]
    fn welch_t_detects_separated_distributions() {
        let mut baseline = TimingStats::default();
        let mut identical = TimingStats::default();
        let mut shifted = TimingStats::default();
        for value in [1.0, 2.0, 3.0, 4.0] {
            baseline.record(value);
            identical.record(value);
            shifted.record(value + 20.0);
        }
        assert_eq!(welch_t(&baseline, &identical), 0.0);
        assert!(welch_t(&baseline, &shifted) > 10.0);
    }

    #[test]
    #[ignore = "host-sensitive release evidence; run scripts/verify-crypto-timing.sh"]
    fn secure_equals_timing_distribution() {
        mesh_rt_init();
        const LENGTH: usize = 256;
        const THRESHOLD: f64 = 10.0;

        let samples = std::env::var("MESH_TIMING_SAMPLES")
            .ok()
            .and_then(|value| value.parse::<usize>().ok())
            .unwrap_or(3_000)
            .max(200);
        let repeats = std::env::var("MESH_TIMING_REPETITIONS")
            .ok()
            .and_then(|value| value.parse::<usize>().ok())
            .unwrap_or(128)
            .max(1);

        let reference = [0xa5; LENGTH];
        let mut first_mismatch = reference;
        first_mismatch[0] ^= 1;
        let mut last_mismatch = reference;
        last_mismatch[LENGTH - 1] ^= 1;
        // Control: the same mismatch position as `first_mismatch`, in its own
        // allocation. Constant-time code must treat it exactly like
        // `first_mismatch`, so any separation measured between the two is the
        // machine talking -- contention, buffer placement, frequency drift --
        // and bounds how much of the first-vs-last separation can be believed.
        let control = first_mismatch;

        let reference = mesh_bytes_copy_from(reference.as_ptr(), LENGTH as u64);
        let first_mismatch = mesh_bytes_copy_from(first_mismatch.as_ptr(), LENGTH as u64);
        let last_mismatch = mesh_bytes_copy_from(last_mismatch.as_ptr(), LENGTH as u64);
        let control = mesh_bytes_copy_from(control.as_ptr(), LENGTH as u64);

        for _ in 0..1_024 {
            black_box(mesh_bytes_secure_equals(reference, first_mismatch));
            black_box(mesh_bytes_secure_equals(reference, last_mismatch));
            black_box(mesh_bytes_secure_equals(reference, control));
        }

        let mut first_stats = TimingStats::default();
        let mut last_stats = TimingStats::default();
        let mut control_stats = TimingStats::default();
        for sample in 0..samples {
            // Rotate the order so no group keeps a favourable position.
            let mut order = [
                (&mut first_stats, first_mismatch),
                (&mut last_stats, last_mismatch),
                (&mut control_stats, control),
            ];
            order.rotate_left(sample % 3);
            for (stats, candidate) in order {
                stats.record(comparison_nanos(reference, candidate, repeats));
            }
        }

        let t_score = welch_t(&first_stats, &last_stats);
        let control_t = welch_t(&first_stats, &control_stats);
        // A machine that cannot tell two identical workloads apart cannot be
        // trusted to say the differing one is different. Separating "no leak"
        // from "could not measure" is the point: reporting the second as the
        // first is what made this gate cry wolf on shared CI runners, where
        // the separation tracks contention -- 0.4% on a quiet host, 9% on a
        // loaded one -- rather than the mismatch position.
        let inconclusive = control_t >= THRESHOLD;
        let leaked = !inconclusive && t_score >= THRESHOLD;
        let passed = !leaked;
        println!(
            "MESH_TIMING_JSON={{\"schema_version\":2,\"boundary\":\"Bytes.secure_equals\",\"bytes_per_comparison\":{LENGTH},\"samples_per_group\":{samples},\"repetitions_per_sample\":{repeats},\"first_mismatch_mean_ns\":{:.3},\"last_mismatch_mean_ns\":{:.3},\"control_mean_ns\":{:.3},\"welch_t\":{t_score:.6},\"control_t\":{control_t:.6},\"threshold\":{THRESHOLD:.1},\"inconclusive\":{inconclusive},\"passed\":{passed}}}",
            first_stats.mean(),
            last_stats.mean(),
            control_stats.mean(),
        );
        if inconclusive {
            eprintln!(
                "warning: host too noisy to measure this boundary: two identical \
                 workloads separated by |t|={control_t:.3} (threshold {THRESHOLD:.1}), \
                 so the first-vs-last |t|={t_score:.3} proves nothing either way"
            );
        }
        assert!(
            passed,
            "secure equality timing distributions diverged: |t|={t_score:.3} \
             with a control separation of only |t|={control_t:.3}"
        );
    }

    #[test]
    fn binary_codecs_and_native_copy_round_trip() {
        mesh_rt_init();
        assert!(mesh_bytes_copy_from(ptr::null(), 1).is_null());
        let input = [0, 0xff, 0x41, 0];
        let bytes = mesh_bytes_copy_from(input.as_ptr(), input.len() as u64);
        let mut output = [0; 2];
        assert_eq!(mesh_bytes_copy_to(bytes, 1, output.as_mut_ptr(), 2), 2);
        assert_eq!(output, [0xff, 0x41]);
        assert_eq!(mesh_bytes_copy_to(bytes, 3, output.as_mut_ptr(), 2), -1);
        assert_eq!(base58_encode(b"Hello World"), "JxF12TrwUP45BMd");
        assert_eq!(base58_encode(&[0, 0, 1]), "112");
        assert_eq!(base58_decode("112"), Ok(vec![0, 0, 1]));
        assert_eq!(base58_decode("0"), Err(()));
        let short = mesh_bytes_copy_from([0].as_ptr(), 1);
        let long = mesh_bytes_copy_from([0; 257].as_ptr(), 257);
        assert_eq!(mesh_bytes_secure_equals(short, long), 0);

        unsafe {
            let encoded = mesh_bytes_to_base58(bytes);
            let decoded = mesh_bytes_from_base58(encoded);
            assert_eq!((*decoded).tag, 0);
            assert_eq!(
                (*((*decoded).value as *const MeshBytes)).as_slice(),
                input.as_slice()
            );
        }
    }

    #[test]
    fn hostile_byte_ranges_never_panic_or_bypass_bounds() {
        mesh_rt_init();
        let mut rng = StdRng::seed_from_u64(0x4d45_5348_4259_5445);

        for _ in 0..512 {
            let len = rng.random_range(0..=64usize);
            let input: Vec<u8> = (0..len).map(|_| rng.random()).collect();
            let bytes = mesh_bytes_copy_from(input.as_ptr(), len as u64);
            let offset = match rng.random_range(0..4) {
                0 => -1,
                1 => len as i64,
                2 => len as i64 + 1,
                _ => rng.random_range(0..=len as i64),
            };

            for (width, read) in [
                (2, mesh_bytes_read_u16_be as extern "C" fn(_, _) -> _),
                (2, mesh_bytes_read_u16_le),
                (4, mesh_bytes_read_u32_be),
                (4, mesh_bytes_read_u32_le),
                (8, mesh_bytes_read_u64_be),
                (8, mesh_bytes_read_u64_le),
            ] {
                let result = read(bytes, offset);
                let in_bounds = offset >= 0
                    && (offset as usize)
                        .checked_add(width)
                        .is_some_and(|end| end <= len);
                unsafe { assert_eq!((*result).tag == 0, in_bounds) };
            }

            let slice_len = rng.random_range(-1..=len as i64 + 1);
            let slice = mesh_bytes_slice(bytes, offset, slice_len);
            let in_bounds = offset >= 0
                && slice_len >= 0
                && (offset as usize)
                    .checked_add(slice_len as usize)
                    .is_some_and(|end| end <= len);
            unsafe { assert_eq!((*slice).tag == 0, in_bounds) };
        }
    }

    #[test]
    fn property_bytes_builder_never_exceeds_declared_allocation() {
        let mut rng = StdRng::seed_from_u64(0x4255_494c_4445_525f);

        for maximum in 0..=64usize {
            let words = (MeshBytesBuilder::HEADER_SIZE + maximum).div_ceil(8);
            let mut allocation = vec![0u64; words];
            let builder = allocation.as_mut_ptr().cast::<MeshBytesBuilder>();
            unsafe {
                builder.write(MeshBytesBuilder {
                    magic: BYTES_BUILDER_MAGIC,
                    len: 0,
                    maximum: maximum as u64,
                    finished: 0,
                    _padding: [0; 7],
                });
            }
            let mut expected = Vec::new();

            for _ in 0..64 {
                let input: Vec<u8> = (0..rng.random_range(0..=8)).map(|_| rng.random()).collect();
                let fits = expected
                    .len()
                    .checked_add(input.len())
                    .is_some_and(|end| end <= maximum);
                let result = unsafe { append_builder(&mut *builder, &input) };
                assert_eq!(result.is_ok(), fits);
                if fits {
                    expected.extend_from_slice(&input);
                }
                unsafe {
                    assert_eq!((*builder).len as usize, expected.len());
                    assert_eq!(
                        std::slice::from_raw_parts((*builder).data_ptr(), expected.len()),
                        expected
                    );
                }
            }
        }
    }
}
