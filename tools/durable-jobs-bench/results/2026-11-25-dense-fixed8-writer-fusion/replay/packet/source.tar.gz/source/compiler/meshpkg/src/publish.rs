use crate::registry;
use mesh_diagnostics::{Code, Diagnostic};
use std::collections::HashSet;
use std::path::{Component, Path, PathBuf};
use std::time::Duration;

use colored::Colorize;
use flate2::write::GzEncoder;
use flate2::Compression;
use indicatif::{ProgressBar, ProgressStyle};
use sha2::{Digest, Sha256};
use tar::Builder;

use mesh_pkg::Manifest;

pub fn run(project_dir: &Path, registry: &str, json_mode: bool) -> Result<(), Diagnostic> {
    // Read manifest
    let manifest_path = project_dir.join("mesh.toml");
    let manifest = Manifest::from_file(&manifest_path)?;

    let name = &manifest.package.name;
    let version = &manifest.package.version;

    // Create tarball in memory
    let (tarball_bytes, sha256) = create_tarball(project_dir)?;

    // Upload with spinner
    let msg = format!("Publishing {}@{}...", name, version);
    let description = manifest.package.description.as_deref().unwrap_or("");
    with_spinner(&msg, json_mode, || {
        upload_tarball(
            &tarball_bytes,
            &sha256,
            name,
            version,
            description,
            registry,
        )
    })?;

    if json_mode {
        println!(
            "{}",
            serde_json::json!({ "status": "ok", "name": name, "version": version, "sha256": sha256 })
        );
    } else {
        println!("{} Published {}@{}", "✓".green().bold(), name, version);
        println!("  SHA-256: {}", sha256);
    }

    Ok(())
}

fn create_tarball(project_dir: &Path) -> Result<(Vec<u8>, String), Diagnostic> {
    let archive_members = publish_archive_members(project_dir)?;
    let mut buf = Vec::new();
    {
        let enc = GzEncoder::new(&mut buf, Compression::default());
        let mut archive = Builder::new(enc);

        for member in &archive_members {
            let source_path = project_dir.join(member);
            archive
                .append_path_with_name(&source_path, member)
                .map_err(|e| {
                    Diagnostic::new(
                        Code::PathNotFound,
                        format!("Failed to add '{}' to tarball: {}", member.display(), e),
                    )
                })?;
        }

        archive
            .into_inner()
            .map_err(|e| {
                Diagnostic::new(
                    Code::PathNotFound,
                    format!("Failed to finalize tarball: {}", e),
                )
            })?
            .finish()
            .map_err(|e| {
                Diagnostic::new(
                    Code::PathNotFound,
                    format!("Failed to flush gzip stream: {}", e),
                )
            })?;
    }

    // Compute SHA-256
    let hash_bytes = Sha256::digest(&buf);
    let sha256: String = hash_bytes.iter().map(|b| format!("{:02x}", b)).collect();

    Ok((buf, sha256))
}

fn publish_archive_members(project_dir: &Path) -> Result<Vec<PathBuf>, Diagnostic> {
    let mut source_members = Vec::new();
    discover_publish_source_members(project_dir, project_dir, &mut source_members)
        .map_err(|message| Diagnostic::new(Code::PathNotFound, message))?;
    source_members.sort();

    let mut archive_members = Vec::with_capacity(source_members.len() + 1);
    archive_members.push(PathBuf::from("mesh.toml"));
    archive_members.extend(source_members);
    let manifest = Manifest::from_file(&project_dir.join("mesh.toml"))?;
    let laws = mesh_pkg::project::laws::discover(project_dir, Some(&manifest))
        .map_err(|message| Diagnostic::new(Code::ManifestInvalid, message))?;
    // Preserve explicit roots even when they contain no archive members.
    archive_members.extend(laws.roots.into_iter().filter(|root| root != Path::new(".")));
    archive_members.extend(laws.paths);
    if let Some(native) = manifest.native {
        for binding in native.bindings {
            let member = declared_package_member(project_dir, &binding)?;
            if !archive_members.contains(&member) {
                archive_members.push(member);
            }
        }
        for library in native.libraries {
            let member = declared_package_member(project_dir, &library.path)?;
            let archive = project_dir.join(&member);
            let bytes = std::fs::read(&archive).map_err(|e| {
                Diagnostic::new(
                    Code::PathNotFound,
                    failed("read native archive", &archive)(e),
                )
            })?;
            let actual = format!("{:x}", Sha256::digest(&bytes));
            if actual != library.sha256 {
                return Err(Diagnostic::new(
                    Code::NativeArchiveMissing,
                    format!(
                        "SHA-256 mismatch for native archive '{}': expected {}, got {}",
                        member.display(),
                        library.sha256,
                        actual
                    ),
                ));
            }
            archive_members.push(member);
        }
    }
    archive_members.sort();
    ensure_unique_archive_members(&archive_members)
        .map_err(|message| Diagnostic::new(Code::ManifestInvalid, message))?;

    Ok(archive_members)
}

/// A file the manifest declares, as its archive member: a file inside the
/// package, reached through no symbolic link.
fn declared_package_member(project_root: &Path, relative: &Path) -> Result<PathBuf, Diagnostic> {
    let source = mesh_pkg::checked_package_file(project_root, relative, "Declared package file")?;
    relative_archive_member_path(project_root, &source)
        .map_err(|message| Diagnostic::new(Code::PathNotFound, message))
}

/// The error for an I/O step on `path`: what it was, then why.
fn failed<'a>(doing: &'a str, path: &'a Path) -> impl FnOnce(std::io::Error) -> String + 'a {
    move |error| format!("Failed to {doing} '{}': {error}", path.display())
}

fn discover_publish_source_members(
    project_root: &Path,
    dir: &Path,
    members: &mut Vec<PathBuf>,
) -> Result<(), String> {
    let entries = std::fs::read_dir(dir).map_err(failed("read", dir))?;
    let mut child_dirs = Vec::new();

    for entry in entries {
        let entry = entry.map_err(failed("read an entry under", dir))?;
        let path = entry.path();
        let name = entry.file_name();
        let name = name.to_string_lossy();

        if name.starts_with('.') {
            continue;
        }

        let file_type = entry
            .file_type()
            .map_err(failed("inspect package path", &path))?;
        if file_type.is_symlink() {
            return Err(format!(
                "Package source path '{}' must not be a symbolic link",
                path.display()
            ));
        }

        if file_type.is_dir() {
            if dir == project_root && name == "tests" {
                continue;
            }
            if mesh_pkg::project::is_package_boundary(&path)
                .map_err(failed("inspect package boundary", &path))?
            {
                continue;
            }
            child_dirs.push(path);
            continue;
        }

        if !file_type.is_file() || path.extension().and_then(|ext| ext.to_str()) != Some("mpl") {
            continue;
        }

        if name.ends_with(".test.mpl") || name.ends_with(".test-support.mpl") {
            continue;
        }

        members.push(relative_archive_member_path(project_root, &path)?);
    }

    child_dirs.sort();
    for child_dir in child_dirs {
        discover_publish_source_members(project_root, &child_dir, members)?;
    }

    Ok(())
}

fn relative_archive_member_path(
    project_root: &Path,
    source_path: &Path,
) -> Result<PathBuf, String> {
    // Both the walk and the declared files find paths under the root.
    let relative_path = source_path
        .strip_prefix(project_root)
        .expect("a package file is under its root");
    validate_archive_member_path(relative_path, source_path)?;
    Ok(relative_path.to_path_buf())
}

fn validate_archive_member_path(relative_path: &Path, source_path: &Path) -> Result<(), String> {
    if relative_path.as_os_str().is_empty() {
        return Err(format!(
            "Refusing to archive '{}' as an empty member name",
            source_path.display()
        ));
    }

    for component in relative_path.components() {
        match component {
            Component::Normal(_) => {}
            Component::CurDir
            | Component::ParentDir
            | Component::RootDir
            | Component::Prefix(_) => {
                return Err(format!(
                    "Refusing to archive malformed member '{}' derived from '{}'",
                    relative_path.display(),
                    source_path.display()
                ));
            }
        }
    }

    Ok(())
}

fn ensure_unique_archive_members(members: &[PathBuf]) -> Result<(), String> {
    let mut seen = HashSet::new();

    for member in members {
        if !seen.insert(member.as_path()) {
            return Err(format!(
                "Refusing to archive duplicate member '{}'",
                member.display()
            ));
        }
    }

    Ok(())
}

fn upload_tarball(
    tarball: &[u8],
    sha256: &str,
    name: &str,
    version: &str,
    description: &str,
    registry: &str,
) -> Result<(), Diagnostic> {
    let token = crate::auth::read_token()
        .map_err(|message| Diagnostic::new(Code::RegistryAuthFailed, message))?;
    let url = format!("{registry}/api/v1/packages");
    let result = registry::agent()
        .post(&url)
        .header("Authorization", &format!("Bearer {}", token))
        .header("Content-Type", "application/octet-stream")
        .header("X-Package-Name", name)
        .header("X-Package-Version", version)
        .header("X-Package-SHA256", sha256)
        .header("X-Package-Description", description)
        .send(tarball);
    registry::response(result, "publish package", Some((name, version)))?;
    Ok(())
}

pub(crate) fn with_spinner<T, F: FnOnce() -> Result<T, Diagnostic>>(
    msg: &str,
    json_mode: bool,
    f: F,
) -> Result<T, Diagnostic> {
    if json_mode {
        return f();
    }
    let pb = ProgressBar::new_spinner();
    pb.set_style(
        ProgressStyle::with_template("{spinner} {msg}")
            .unwrap()
            .tick_strings(&["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏", ""]),
    );
    pb.set_message(msg.to_string());
    pb.enable_steady_tick(Duration::from_millis(80));
    let result = f();
    pb.finish_and_clear();
    result
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;

    use flate2::read::GzDecoder;
    use tar::Archive;

    fn manifest(name: &str, entrypoint: &str) -> String {
        format!(
            "[package]\nname = \"{name}\"\nversion = \"0.1.0\"\nentrypoint = \"{entrypoint}\"\n"
        )
    }

    fn write_project_file(project_dir: &Path, relative_path: &str, contents: &str) {
        let full_path = project_dir.join(relative_path);
        if let Some(parent) = full_path.parent() {
            fs::create_dir_all(parent).unwrap();
        }
        fs::write(full_path, contents).unwrap();
    }

    fn archive_member_names(project_dir: &Path) -> Vec<String> {
        let (tarball_bytes, _sha256) = create_tarball(project_dir).unwrap();
        let decoder = GzDecoder::new(tarball_bytes.as_slice());
        let mut archive = Archive::new(decoder);
        let mut members = archive
            .entries()
            .unwrap()
            .map(|entry| {
                entry
                    .unwrap()
                    .path()
                    .unwrap()
                    .to_string_lossy()
                    .replace('\\', "/")
            })
            .collect::<Vec<_>>();
        members.sort();
        members
    }

    #[test]
    fn publish_archive_round_trip_preserves_the_selected_law_inventory() {
        let temp = tempfile::tempdir().unwrap();
        let project = temp.path().join("source");
        let unpacked = temp.path().join("unpacked");
        let manifest_text = format!(
            "{}\n[verify]\nlaw_roots = [\"empty\", \"specs\", \"specs/nested\", \"tests\"]\n",
            manifest("round-trip-laws", "main.mpl")
        );
        write_project_file(&project, "mesh.toml", &manifest_text);
        write_project_file(
            &project,
            "main.mpl",
            "fn first() -> Bool do true end\nfn second() -> Bool do false end\nfn main() do nil end\n",
        );
        fs::create_dir_all(project.join("empty")).unwrap();
        write_project_file(
            &project,
            "specs/nested/first.law",
            "from Main import private first\nlaw first() -> Bool do true end\n",
        );
        write_project_file(
            &project,
            "tests/second.law",
            "from Main import private second\nlaw second() -> Bool do false end\n",
        );
        write_project_file(&project, "outside/unselected.law", "unselected");
        write_project_file(&project, "specs/.hidden/unselected.law", "hidden");
        write_project_file(
            &project,
            "specs/other/mesh.toml",
            &manifest("other", "main.mpl"),
        );
        write_project_file(&project, "specs/other/retry.law", "nested");

        let (archive, _) = create_tarball(&project).unwrap();
        Archive::new(GzDecoder::new(archive.as_slice()))
            .unpack(&unpacked)
            .unwrap();
        let inventory = |dir: &Path| {
            let manifest = Manifest::from_file(&dir.join("mesh.toml")).unwrap();
            mesh_pkg::project::laws::discover(dir, Some(&manifest)).unwrap()
        };
        let base = inventory(&project);
        let installed = inventory(&unpacked);
        assert_eq!(installed.roots, base.roots);
        assert_eq!(
            installed.paths,
            [
                PathBuf::from("specs/nested/first.law"),
                PathBuf::from("tests/second.law")
            ]
        );
        assert_eq!(installed.paths, base.paths);
        for law in installed.paths {
            assert_eq!(
                fs::read(unpacked.join(&law)).unwrap(),
                fs::read(project.join(&law)).unwrap(),
            );
        }
        assert!(!unpacked.join("outside/unselected.law").exists());
        assert!(!unpacked.join("specs/.hidden/unselected.law").exists());
        assert!(!unpacked.join("specs/other").exists());

        // Run the compiler comparison when the workspace proof supplies the
        // matching meshc binary. The archive test also runs in meshpkg alone.
        if let Some(meshc) = std::env::var_os("MESH_LAW_TEST_MESHC") {
            let list = |dir: &Path| {
                let output = std::process::Command::new(&meshc)
                    .arg("verify")
                    .arg(dir)
                    .args(["--list", "--json"])
                    .output()
                    .unwrap();
                assert!(
                    output.status.success(),
                    "{}",
                    String::from_utf8_lossy(&output.stderr)
                );
                serde_json::from_slice::<serde_json::Value>(&output.stdout).unwrap()
            };
            assert_eq!(list(&unpacked), list(&project));
        }
    }

    #[test]
    fn publish_archive_members_include_override_entry_and_nested_support_modules() {
        let tempdir = tempfile::tempdir().unwrap();
        let project_dir = tempdir.path();

        write_project_file(
            project_dir,
            "mesh.toml",
            &manifest("override-only-package", "lib/start.mpl"),
        );
        write_project_file(
            project_dir,
            "lib/start.mpl",
            "from Features.Workflows.Renderer import render\n\nfn main() do\n  render()\nend\n",
        );
        write_project_file(
            project_dir,
            "features/workflows/renderer.mpl",
            "pub fn render() -> Int do\n  42\nend\n",
        );
        write_project_file(
            project_dir,
            "lib/support/helpers.mpl",
            "pub fn label() -> String do\n  \"support\"\nend\n",
        );

        let members = archive_member_names(project_dir);

        assert_eq!(
            members,
            vec![
                "features/workflows/renderer.mpl",
                "lib/start.mpl",
                "lib/support/helpers.mpl",
                "mesh.toml",
            ],
            "unexpected archive members: {members:?}"
        );
    }

    #[test]
    fn publish_archive_members_exclude_hidden_paths_and_test_files() {
        let tempdir = tempfile::tempdir().unwrap();
        let project_dir = tempdir.path();

        write_project_file(
            project_dir,
            "mesh.toml",
            &manifest("publish-filtering", "lib/start.mpl"),
        );
        write_project_file(project_dir, "lib/start.mpl", "fn main() do\n  0\nend\n");
        write_project_file(
            project_dir,
            "lib/visible.mpl",
            "pub fn ok() -> Int do\n  1\nend\n",
        );
        write_project_file(
            project_dir,
            "lib/visible.test.mpl",
            "test(\"hidden\") do\n  assert(true)\nend\n",
        );
        write_project_file(
            project_dir,
            "lib/visible.test-support.mpl",
            "pub fn hidden_support() -> Int do\n  2\nend\n",
        );
        write_project_file(
            project_dir,
            "tests/support.mpl",
            "pub fn test_helper() -> Int do\n  3\nend\n",
        );
        write_project_file(project_dir, ".secret.mpl", "fn nope() do\n  0\nend\n");
        write_project_file(
            project_dir,
            ".hidden/secret.mpl",
            "fn nope() do\n  0\nend\n",
        );
        write_project_file(
            project_dir,
            "lib/.private/secret.mpl",
            "fn nope() do\n  0\nend\n",
        );

        let members = archive_member_names(project_dir);

        assert!(
            members.contains(&"lib/start.mpl".to_string()),
            "expected override entry to be archived, got: {members:?}"
        );
        assert!(
            members.contains(&"lib/visible.mpl".to_string()),
            "expected visible nested module to be archived, got: {members:?}"
        );
        assert!(
            !members.iter().any(|member| member.contains(".secret.mpl")
                || member.contains(".hidden/")
                || member.contains("/.private/")
                || member.starts_with("tests/")
                || member.ends_with(".test.mpl")
                || member.ends_with(".test-support.mpl")),
            "hidden or test-only files leaked into the archive: {members:?}"
        );
    }

    #[cfg(unix)]
    #[test]
    fn publish_archive_members_reject_visible_symlink_aliases() {
        use std::os::unix::fs::symlink;

        for target_name in ["tests", "outside"] {
            let tempdir = tempfile::tempdir().unwrap();
            let project_dir = tempdir.path().join("project");
            fs::create_dir(&project_dir).unwrap();
            write_project_file(
                &project_dir,
                "mesh.toml",
                &manifest("symlinked", "main.mpl"),
            );
            write_project_file(&project_dir, "main.mpl", "fn main() do\n  0\nend\n");
            write_project_file(
                &project_dir,
                "tests/support.mpl",
                "pub fn helper() -> Int do\n  1\nend\n",
            );
            write_project_file(
                tempdir.path(),
                "outside/support.mpl",
                "pub fn helper() -> Int do\n  1\nend\n",
            );
            let target = if target_name == "tests" {
                project_dir.join("tests")
            } else {
                tempdir.path().join("outside")
            };
            let alias = project_dir.join(format!("{target_name}_alias"));
            symlink(target, &alias).unwrap();

            let error = publish_archive_members(&project_dir).unwrap_err();
            let error = error.message();
            assert!(
                error.contains("symbolic link")
                    && error.contains(alias.file_name().unwrap().to_str().unwrap()),
                "unexpected error: {error}"
            );
        }
    }

    #[test]
    fn publish_archive_rejects_manifest_native_library_under_tests() {
        let tempdir = tempfile::tempdir().unwrap();
        let project_dir = tempdir.path();
        let archive = "test-only-native";
        let sha256 = format!("{:x}", Sha256::digest(archive.as_bytes()));
        write_project_file(
            project_dir,
            "mesh.toml",
            &format!(
                r#"[package]
name = "test-native"
version = "0.1.0"

[native]
abi = 1

[[native.libraries]]
target = "aarch64-apple-darwin"
path = "tests/libtest.a"
sha256 = "{sha256}"
"#,
            ),
        );
        write_project_file(project_dir, "main.mpl", "fn main() do\n  0\nend\n");
        write_project_file(project_dir, "tests/libtest.a", archive);

        let error = publish_archive_members(project_dir).unwrap_err();
        let error = error.message();
        assert!(
            error.contains("native static archive") && error.contains("tests/libtest.a"),
            "unexpected error: {error}"
        );
    }

    #[cfg(unix)]
    #[test]
    fn publish_archive_rejects_manifest_declared_native_symlinks() {
        use std::os::unix::fs::symlink;

        let tempdir = tempfile::tempdir().unwrap();
        let project_dir = tempdir.path();
        write_project_file(
            project_dir,
            "mesh.toml",
            r#"[package]
name = "symlinked-native"
version = "0.1.0"

[native]
abi = 1
bindings = [".native/helper.mpl"]
"#,
        );
        write_project_file(project_dir, "main.mpl", "fn main() do\n  0\nend\n");
        write_project_file(
            project_dir,
            "tests/helper.mpl",
            "@native(\"test_helper\")\npub fn helper() -> Int\n",
        );
        fs::create_dir(project_dir.join(".native")).unwrap();
        symlink(
            project_dir.join("tests/helper.mpl"),
            project_dir.join(".native/helper.mpl"),
        )
        .unwrap();

        let error = publish_archive_members(project_dir).unwrap_err();
        let error = error.message();
        assert!(
            error.contains("symbolic link") && error.contains(".native/helper.mpl"),
            "unexpected error: {error}"
        );
    }

    #[test]
    fn publish_archive_members_include_only_manifest_declared_native_archives() {
        let tempdir = tempfile::tempdir().unwrap();
        let project_dir = tempdir.path();
        let archive = b"native-archive";
        let sha256 = format!("{:x}", Sha256::digest(archive));
        write_project_file(
            project_dir,
            "mesh.toml",
            &format!(
                r#"[package]
name = "native-package"
version = "0.1.0"

[native]
abi = 1
bindings = ["bindings/native.mpl"]

[[native.libraries]]
target = "aarch64-apple-darwin"
path = "native/aarch64-apple-darwin/libnative.a"
sha256 = "{sha256}"
"#
            ),
        );
        write_project_file(
            project_dir,
            "bindings/native.mpl",
            "@native(\"mesh_native_value\")\npub fn value() -> Int\n",
        );
        write_project_file(
            project_dir,
            "native/aarch64-apple-darwin/libnative.a",
            "native-archive",
        );
        write_project_file(project_dir, "native/unlisted/libsecret.a", "not-published");

        let members = archive_member_names(project_dir);
        assert!(members.contains(&"bindings/native.mpl".to_string()));
        assert!(members.contains(&"native/aarch64-apple-darwin/libnative.a".to_string()));
        assert!(!members.contains(&"native/unlisted/libsecret.a".to_string()));
    }

    #[test]
    fn publish_archive_members_include_declared_bindings_the_source_walk_skips() {
        let tempdir = tempfile::tempdir().unwrap();
        let project_dir = tempdir.path();
        write_project_file(
            project_dir,
            "mesh.toml",
            "[package]\nname = \"native-package\"\nversion = \"0.1.0\"\n\n[native]\nabi = 1\nbindings = [\".bindings/native.mpl\"]\n",
        );
        write_project_file(
            project_dir,
            ".bindings/native.mpl",
            "@native(\"mesh_native_value\")\npub fn value() -> Int\n",
        );
        // The walk skips hidden directories; the declared binding goes in anyway.
        let members = archive_member_names(project_dir);
        assert!(
            members.contains(&".bindings/native.mpl".to_string()),
            "{members:?}"
        );
    }

    #[test]
    fn publish_archive_members_keep_root_main_when_override_and_root_entries_both_exist() {
        let tempdir = tempfile::tempdir().unwrap();
        let project_dir = tempdir.path();

        write_project_file(
            project_dir,
            "mesh.toml",
            &manifest("override-precedence-package", "lib/start.mpl"),
        );
        write_project_file(project_dir, "main.mpl", "fn main() do\n  0\nend\n");
        write_project_file(project_dir, "lib/start.mpl", "fn main() do\n  1\nend\n");
        write_project_file(
            project_dir,
            "modules/support.mpl",
            "pub fn label() -> String do\n  \"ok\"\nend\n",
        );

        let members = archive_member_names(project_dir);

        assert!(
            members.contains(&"main.mpl".to_string()),
            "expected root main.mpl to remain published when present, got: {members:?}"
        );
        assert!(
            members.contains(&"lib/start.mpl".to_string()),
            "expected override entrypoint to be published, got: {members:?}"
        );
        assert!(
            members.contains(&"modules/support.mpl".to_string()),
            "expected non-src nested support module to be published, got: {members:?}"
        );
    }

    #[test]
    fn discover_publish_source_members_reports_directory_path_when_walk_fails() {
        let tempdir = tempfile::tempdir().unwrap();
        let missing_dir = tempdir.path().join("missing");
        let mut members = Vec::new();

        let err = discover_publish_source_members(tempdir.path(), &missing_dir, &mut members)
            .expect_err("missing directories should surface a read error");

        assert!(
            err.contains(&missing_dir.display().to_string()),
            "expected walk failure to include the unreadable path, got: {err}"
        );
    }

    #[test]
    fn validate_archive_member_path_rejects_escaping_components() {
        let err =
            validate_archive_member_path(Path::new("../escape.mpl"), Path::new("../escape.mpl"))
                .expect_err("escaping member names should be rejected");

        assert!(
            err.contains("malformed member"),
            "unexpected validation error: {err}"
        );
        let err = validate_archive_member_path(Path::new(""), Path::new("/project"))
            .expect_err("an empty member name should be rejected");
        assert!(err.contains("empty member name"), "{err}");
    }

    #[test]
    fn ensure_unique_archive_members_rejects_duplicate_relative_paths() {
        let members = vec![
            PathBuf::from("mesh.toml"),
            PathBuf::from("lib/start.mpl"),
            PathBuf::from("lib/start.mpl"),
        ];

        let err = ensure_unique_archive_members(&members)
            .expect_err("duplicate archive members should be rejected");

        assert!(
            err.contains("lib/start.mpl"),
            "duplicate-path error should name the conflicting member, got: {err}"
        );
    }
}
