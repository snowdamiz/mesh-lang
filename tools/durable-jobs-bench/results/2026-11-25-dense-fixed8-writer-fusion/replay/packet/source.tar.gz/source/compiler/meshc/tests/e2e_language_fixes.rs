//! Regression tests for compiler and language fixes: each test is a program
//! that once miscompiled, crashed, or was wrongly rejected.

use std::path::PathBuf;
use std::process::Command;

#[path = "support/test_artifacts.rs"]
mod artifacts;

fn find_meshc() -> PathBuf {
    artifacts::meshc_bin()
}

struct Build {
    dir: tempfile::TempDir,
    ok: bool,
    stdout: String,
    stderr: String,
}

fn build(source: &str, json: bool) -> Build {
    build_with_args(source, if json { &["--json"] } else { &[] })
}

fn build_with_args(source: &str, args: &[&str]) -> Build {
    let dir = tempfile::tempdir().expect("temp dir");
    let project = dir.path().join("project");
    std::fs::create_dir_all(&project).expect("project dir");
    std::fs::write(project.join("main.mpl"), source).expect("main.mpl");
    let output = Command::new(find_meshc())
        .arg("build")
        .arg(&project)
        .arg("--no-color")
        .args(args)
        .output()
        .expect("meshc");
    Build {
        dir,
        ok: output.status.success(),
        stdout: String::from_utf8_lossy(&output.stdout).to_string(),
        stderr: String::from_utf8_lossy(&output.stderr).to_string(),
    }
}

/// Build and run; the program must build, run, and exit 0. Returns stdout.
fn run(source: &str) -> String {
    run_built(&build(source, false))
}

/// Run a program built by `build_with_args`; it must exit 0. Returns stdout.
fn run_built(built: &Build) -> String {
    assert!(built.ok, "build failed:\n{}", built.stderr);
    let output = Command::new(built.dir.path().join("project/project"))
        .output()
        .expect("run binary");
    assert!(
        output.status.success(),
        "binary failed with {:?}:\nstdout: {}\nstderr: {}",
        output.status.code(),
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
    String::from_utf8_lossy(&output.stdout).to_string()
}

/// Build and run, also returning the compiler's stderr (warnings).
fn run_with_build_stderr(source: &str) -> (String, String) {
    let built = build(source, false);
    assert!(built.ok, "build failed:\n{}", built.stderr);
    let output = Command::new(built.dir.path().join("project/project"))
        .output()
        .expect("run binary");
    assert!(output.status.success(), "binary failed: {:?}", output);
    (
        built.stderr,
        String::from_utf8_lossy(&output.stdout).to_string(),
    )
}

fn build_error(source: &str) -> String {
    let built = build(source, false);
    assert!(!built.ok, "expected the build to fail:\n{}", built.stderr);
    built.stderr
}

fn json_diagnostics(source: &str) -> Vec<serde_json::Value> {
    let built = build(source, true);
    parse_json_diagnostics(&built.stderr)
}

fn parse_json_diagnostics(stderr: &str) -> Vec<serde_json::Value> {
    stderr
        .lines()
        .filter(|line| !line.trim().is_empty())
        .map(|line| {
            serde_json::from_str(line)
                .unwrap_or_else(|e| panic!("diagnostic line is not one JSON object: {e}\n{line}"))
        })
        .collect()
}

// ── Diagnostics ────────────────────────────────────────────────────────

const PIPE_PLACEHOLDER: &str = r#"fn format_three(left :: String, middle :: String, right :: String) do
  "${left}:${middle}:${right}"
end

fn main() do
  let formatted = "middle" |> format_three("left", _, "right")
  println(formatted)
end
"#;

#[test]
fn diagnostic_repair_pipe_placeholder_preserves_argument_order() {
    let terminal = build_error(PIPE_PLACEHOLDER);
    let headline = "arity mismatch: expected 3 arguments, found 4";
    assert!(
        terminal.contains(&format!("[E0003] Error: {headline}")),
        "{terminal}"
    );
    assert!(
        terminal.contains("passes the piped value as the first argument"),
        "{terminal}"
    );
    assert!(terminal.contains("Use `|2>` and remove `_`"), "{terminal}");
    assert!(terminal.contains("meshc guide syntax"), "{terminal}");

    let json = build(PIPE_PLACEHOLDER, true);
    assert!(!json.ok, "{}", json.stderr);
    assert!(json.stdout.is_empty(), "{}", json.stdout);
    let diagnostics = parse_json_diagnostics(&json.stderr);
    assert_eq!(diagnostics.len(), 1, "{diagnostics:?}");
    let diagnostic = &diagnostics[0];
    assert_eq!(diagnostic["code"], "E0003");
    assert_eq!(diagnostic["severity"], "error");
    assert_eq!(diagnostic["message"], headline);
    let file = std::path::Path::new(diagnostic["file"].as_str().unwrap());
    assert_eq!(file.file_name().unwrap(), "main.mpl");
    assert_eq!(
        diagnostic["spans"],
        serde_json::json!([{
            "start": 149,
            "end": 181,
            "label": "expected 3 argument(s)",
            "file": diagnostic["file"],
            "line": 6,
            "col": 31,
            "end_line": 6,
            "end_col": 63
        }])
    );
    assert_eq!(
        &PIPE_PLACEHOLDER[149..181],
        r#"format_three("left", _, "right")"#
    );
    let hint = diagnostic["fix"].as_str().unwrap();
    assert!(hint.contains("Use `|2>` and remove `_`"), "{hint}");
    assert!(terminal.contains(hint), "{terminal}");

    let removing_only = PIPE_PLACEHOLDER.replace("_, ", "");
    assert_eq!(run(&removing_only), "middle:left:right\n");
    let repaired = removing_only.replace("|>", "|2>");
    assert_eq!(run(&repaired), "left:middle:right\n");
}

#[test]
fn diagnostic_repair_pipe_placeholder_stays_specific_to_one_extra_argument() {
    let call = r#""middle" |> format_three("left", _, "right")"#;
    for control in [
        r#"format_three("extra", "left", _, "right")"#,
        r#""middle" |> format_three("left", "_", "right")"#,
        r#""middle" |> format_three(_, _, "right")"#,
        r#""middle" |2> format_three("left", _, "right")"#,
    ] {
        let diagnostics = json_diagnostics(&PIPE_PLACEHOLDER.replace(call, control));
        let diagnostic = &diagnostics[0];
        assert_eq!(diagnostic["code"], "E0003", "{control}");
        assert_eq!(
            diagnostic["message"], "arity mismatch: expected 3 arguments, found 4",
            "{control}"
        );
        assert_eq!(diagnostic["fix"], "1 extra argument(s)", "{control}");
    }

    let matching_arity =
        "fn pair(a :: Int, b :: Int) do\n  a + b\nend\n\nfn main() do\n  1 |> pair(_)\nend\n";
    let diagnostics = json_diagnostics(matching_arity);
    assert_eq!(diagnostics[0]["code"], "E0004");
    assert_eq!(diagnostics[0]["message"], "undefined variable `_`");

    for (args, advice) in [
        (r#"_, "center", "right""#, "Keep `|>` and remove `_`"),
        (r#""left", "center", _"#, "Use `|3>` and remove `_`"),
    ] {
        let source = PIPE_PLACEHOLDER.replace(r#""left", _, "right""#, args);
        let diagnostics = json_diagnostics(&source);
        assert_eq!(diagnostics[0]["code"], "E0003");
        let hint = diagnostics[0]["fix"].as_str().unwrap();
        assert!(hint.contains(advice), "{hint}");
    }
}

#[test]
fn diagnostic_repair_exhaustive_match_requires_a_decision_for_new_variants() {
    let incomplete = r##"type Delivery do
  Delivered
  Rejected
  TimedOut
end

fn retry(state :: Delivery) -> Bool do
  case state do
    Delivered -> false
    Rejected -> false
  end
end

fn main() do
  println("#{retry(Delivered)}")
  println("#{retry(Rejected)}")
  println("#{retry(TimedOut)}")
end
"##;
    let terminal = build_error(incomplete);
    assert!(terminal.contains("[E0012]"), "{terminal}");
    assert!(terminal.contains("add an arm for `TimedOut`"), "{terminal}");
    assert!(
        terminal.contains("also covers future variants"),
        "{terminal}"
    );
    let json = build(incomplete, true);
    assert!(!json.ok, "{}", json.stderr);
    assert!(json.stdout.is_empty(), "{}", json.stdout);
    let diagnostics = parse_json_diagnostics(&json.stderr);
    let diagnostic = &diagnostics[0];
    assert_eq!(diagnostic["code"], "E0012");
    assert_eq!(diagnostic["spans"][0]["label"], "missing: TimedOut");
    let hint = diagnostic["fix"].as_str().unwrap();
    assert!(hint.contains("add an arm for `TimedOut`"), "{hint}");
    assert!(hint.contains("also covers future variants"), "{hint}");

    let explicit = incomplete.replace(
        "Rejected -> false\n",
        "Rejected -> false\n    TimedOut -> true\n",
    );
    let wildcard = explicit.replace("TimedOut -> true", "_ -> true");
    for repaired in [&explicit, &wildcard] {
        assert_eq!(run(repaired), "false\nfalse\ntrue\n");
    }
    let add_pending = |source: &str| source.replace("  TimedOut\n", "  TimedOut\n  Pending\n");
    let terminal = build_error(&add_pending(&explicit));
    assert!(terminal.contains("[E0012]"), "{terminal}");
    assert!(terminal.contains("add an arm for `Pending`"), "{terminal}");
    assert_eq!(run(&add_pending(&wildcard)), "false\nfalse\ntrue\n");
}

#[test]
fn diagnostic_spans_are_source_offsets_despite_whitespace() {
    let source = "fn main() do\n    let   a     =    1\n    println(zzz)\nend\n";
    let diags = json_diagnostics(source);
    let unbound = diags
        .iter()
        .find(|d| d["code"] == "E0004")
        .expect("unbound variable diagnostic");
    let span = &unbound["spans"][0];
    let start = source.find("zzz").unwrap();
    assert_eq!(span["start"], start);
    assert_eq!(span["end"], start + 3);
}

#[test]
fn json_diagnostics_are_one_object_per_line() {
    let source = "fn main() do\n  println(aaa)\n  println(bbb)\nend\n";
    let diags = json_diagnostics(source);
    let codes: Vec<&str> = diags.iter().filter_map(|d| d["code"].as_str()).collect();
    assert_eq!(codes, ["E0004", "E0004"]);
}

#[test]
fn not_on_an_int_reports_the_operator() {
    let source = "fn main() do\n  println(\"#{not 1 == 2}\")\nend\n";
    let diags = json_diagnostics(source);
    let mismatch = &diags[0];
    assert_eq!(mismatch["code"], "E0001");
    assert!(mismatch["message"]
        .as_str()
        .unwrap()
        .contains("expected `Bool`, found `Int`"));
    assert_eq!(mismatch["spans"][0]["start"], source.find("not").unwrap());
}

// ── Pattern matching ───────────────────────────────────────────────────

#[test]
fn tuple_of_bool_and_int_match_is_exhaustive() {
    let source = r##"
fn boolpat(b :: Bool, n :: Int) -> String do
  case (b, n) do
    (true, 0) -> "t0"
    (true, _) -> "tN"
    (false, 0) -> "f0"
    (false, _) -> "fN"
  end
end

fn tup(t :: (Int, (String, Bool))) -> String do
  case t do
    (0, (s, true)) -> "zero true #{s}"
    (0, (s, false)) -> "zero false #{s}"
    (n, (s, _)) when n < 0 -> "neg #{n} #{s}"
    (n, (_, b)) -> "pos #{n} #{b}"
  end
end

fn main() do
  println(boolpat(true, 0) <> boolpat(true, 1) <> boolpat(false, 0) <> boolpat(false, 2))
  println(tup((0, ("s", true))) <> "," <> tup((0, ("s", false))) <> "," <> tup((-3, ("n", true))) <> "," <> tup((7, ("p", false))))
end
"##;
    let (warnings, out) = run_with_build_stderr(source);
    assert_eq!(
        out,
        "t0tNf0fN\nzero true s,zero false s,neg -3 n,pos 7 false\n"
    );
    assert!(
        !warnings.contains("redundant"),
        "spurious warning:\n{warnings}"
    );
}

#[test]
fn guarded_arm_does_not_shadow_its_unguarded_twin() {
    let source = r##"
fn nested(v :: Option<Option<Int>>) -> String do
  case v do
    Some(Some(n)) when n > 10 -> "big #{n}"
    Some(Some(n)) -> "small #{n}"
    Some(None) -> "inner none"
    None -> "outer none"
  end
end

fn main() do
  println(nested(Some(Some(42))) <> "," <> nested(Some(Some(1))) <> "," <> nested(Some(None)) <> "," <> nested(None))
end
"##;
    let (warnings, out) = run_with_build_stderr(source);
    assert_eq!(out, "big 42,small 1,inner none,outer none\n");
    assert!(
        !warnings.contains("redundant"),
        "spurious warning:\n{warnings}"
    );
}

#[test]
fn cons_pattern_is_the_list_constructor_and_parens_group() {
    let source = r##"
fn listpat(xs :: List<Int>) -> String do
  case xs do
    h :: (h2 :: t) -> "two+ #{h} #{h2} rest=#{List.length(t)}"
    h :: t -> "one #{h} rest=#{List.length(t)}"
    _ -> "empty"
  end
end

fn main() do
  println(listpat([1, 2, 3]) <> "," <> listpat([1]) <> "," <> listpat([]))
end
"##;
    let (warnings, out) = run_with_build_stderr(source);
    assert_eq!(out, "two+ 1 2 rest=1,one 1 rest=0,empty\n");
    assert!(
        !warnings.contains("redundant"),
        "spurious warning:\n{warnings}"
    );
}

#[test]
fn cons_pattern_alone_is_not_exhaustive() {
    let err = build_error("fn f(xs :: List<Int>) -> Int do\n  case xs do\n    h :: _ -> h\n  end\nend\nfn main() do\n  println(\"#{f([1])}\")\nend\n");
    assert!(err.contains("non-exhaustive"), "{err}");
    assert!(
        err.contains("[]"),
        "witness should be the empty list:\n{err}"
    );
}

#[test]
fn a_pattern_alone_is_an_arm_that_rebuilds_its_value() {
    let source = r##"
type Step<T> do
  Done(T)
  Failed(String)
end

fn check(n :: Int) -> Result<Int, String> do
  if n > 0 do
    Ok(n)
  else
    Err("not positive")
  end
end

fn measured(n :: Int) -> Result<Int, Int> do
  case check(n) do
    Ok(value)
    Err(message) -> Err(String.length(message))
  end
end

fn widen<T>(r :: Result<T, String>) -> Result<T, Int> do
  case r do
    Ok(value)
    Err(message) -> Err(String.length(message))
  end
end

fn nested(o :: Option<Result<Int, String>>) -> Option<Result<Int, Int>> do
  case o do
    Some(Ok(value))
    Some(Err(message)) -> Some(Err(String.length(message)))
    None
  end
end

fn label(s :: Step<Int>) -> Step<String> do
  case s do
    Done(n) -> Done("step #{n}")
    Failed(reason)
  end
end

fn positive(r :: Result<Int, String>) -> Result<Int, String> do
  case r do
    Ok(v) when v > 0
    Ok(v) -> Err("#{v} is not positive")
    Err(e)
  end
end

fn show(r :: Result<Int, Int>) -> String do
  case r do
    Ok(v) -> "ok #{v}"
    Err(e) -> "err #{e}"
  end
end

fn main() do
  println(show(measured(5)) <> "," <> show(measured(-1)))
  let widened = case widen(Ok("text")) do
    Ok(s) -> s
    Err(e) -> "err #{e}"
  end
  println(widened <> "," <> show(widen(Err("four"))))
  let inner = case nested(Some(Err("four"))) do
    Some(Ok(v)) -> "ok #{v}"
    Some(Err(e)) -> "err #{e}"
    None -> "none"
  end
  let outer = case nested(Some(Ok(7))) do
    Some(Ok(v)) -> "ok #{v}"
    Some(Err(e)) -> "err #{e}"
    None -> "none"
  end
  let missing = case nested(None) do
    Some(_) -> "some"
    None -> "none"
  end
  println(inner <> "," <> outer <> "," <> missing)
  let steps = [label(Done(3)), label(Failed("boom"))]
  println(String.join(List.map(steps, fn s -> case s do
    Done(text) -> text
    Failed(reason) -> "failed #{reason}"
  end end), ","))
  let checked = case positive(Ok(0)) do
    Ok(v) -> "ok #{v}"
    Err(e) -> e
  end
  let kept = case positive(Ok(2)) do
    Ok(v) -> "ok #{v}"
    Err(e) -> e
  end
  println(checked <> "," <> kept)
end
"##;
    assert_eq!(
        run(source),
        "ok 5,err 12\ntext,err 4\nerr 4,ok 7,none\nstep 3,failed boom\n0 is not positive,ok 2\n"
    );

    for (arm, reason) in [
        ("_", "`_` names no value"),
        ("Ok", "`Ok` alone leaves its payload unnamed"),
    ] {
        let err = build_error(&format!(
            "fn f(r :: Result<Int, String>) -> Result<Int, String> do\n  case r do\n    Err(e) -> Err(e)\n    {arm}\n  end\nend\nfn main() do\n  println(\"x\")\nend\n"
        ));
        assert!(
            err.contains("E0056") && err.contains(reason),
            "{arm}:\n{err}"
        );
    }
}

#[test]
fn negative_and_string_literal_patterns_match_their_own_value() {
    let source = r##"
fn describe(x :: Int) -> String do
  case x do
    -1 -> "minus one"
    1 -> "one"
    _ -> "other"
  end
end

fn half(x :: Float) -> String do
  case x do
    -0.5 -> "minus half"
    _ -> "other"
  end
end

fn pair(-1, "x") = "minus one and x"
fn pair(n, "x") = "#{n} and x"
fn pair(_, _) = "neither"

fn checked(r :: Result<Bool, String>) -> Result<Bool, Int> do
  case r do
    Ok(true)
    Ok(false) -> Err(0)
    Err(e) -> Err(String.length(e))
  end
end

fn main() do
  println(describe(-1) <> "," <> describe(1) <> "," <> describe(5))
  println(half(-0.5) <> "," <> half(0.5))
  println(pair(-1, "x") <> "," <> pair(1, "x") <> "," <> pair(-1, "y"))
  let kept = case checked(Ok(true)) do
    Ok(b) -> "ok #{b}"
    Err(e) -> "err #{e}"
  end
  println(kept)
end
"##;
    let (warnings, out) = run_with_build_stderr(source);
    assert_eq!(
        out,
        "minus one,one,other\nminus half,other\nminus one and x,1 and x,neither\nok true\n"
    );
    assert!(
        !warnings.contains("redundant"),
        "`1` is not `-1`:\n{warnings}"
    );
}

#[test]
fn as_pattern_binds_the_matched_value() {
    let source = r##"
fn aspat(t :: (Int, Int)) -> String do
  case t do
    (x, y) as whole when x == y -> "diag #{x} #{Tuple.first(whole)}"
    (x, _) as whole -> "off #{x} #{Tuple.second(whole)}"
  end
end

fn main() do
  println(aspat((2, 2)) <> "," <> aspat((2, 3)))
  let r = case Some(4) do
    Some(n) as w -> case w do
      Some(m) -> "#{n} #{m}"
      None -> "none"
    end
    None -> "outer"
  end
  println(r)
end
"##;
    assert_eq!(run(source), "diag 2 2,off 2 3\n4 4\n");
}

// ── Grammar ────────────────────────────────────────────────────────────

#[test]
fn closure_can_be_a_statement_and_a_tail_expression() {
    let source = r##"
fn compose(f :: Fun(Int) -> Int, g :: Fun(Int) -> Int) -> Fun(Int) -> Int do
  fn x -> g(f(x)) end
end

fn main() do
  let inc = fn x -> x + 1 end
  println("#{compose(inc, inc)(1)}")
end
"##;
    assert_eq!(run(source), "3\n");
}

#[test]
fn match_arm_body_may_start_on_the_next_line() {
    let source = r##"
fn f(o :: Option<Int>) -> Int do
  case o do
    Some(x) ->
      let y = x * 2
      y + 1
    None -> -1
  end
end

fn g(o :: Option<Int>) -> Int do
  case o do
    Some(x) ->
      if x > 0 do
        x
      else
        0
      end
    None -> -1
  end
end

fn main() do
  println("#{f(Some(3))} #{f(None)} #{g(Some(3))} #{g(None)}")
end
"##;
    assert_eq!(run(source), "7 -1 3 -1\n");
}

#[test]
fn empty_match_arm_body_is_rejected() {
    let err = build_error("fn main() do\n  case 1 do\n    1 ->\n  end\nend\n");
    assert!(err.contains("expected expression after `->`"), "{err}");
}

#[test]
fn return_is_an_expression() {
    let source = r##"
fn f(o :: Option<Int>) -> Int do
  let v = case o do
    Some(x) -> x
    None -> return -1
  end
  v * 2
end

fn main() do
  println("#{f(Some(3))} #{f(None)}")
end
"##;
    assert_eq!(run(source), "6 -1\n");
}

#[test]
fn function_ending_in_let_has_unit_type() {
    let source =
        "fn f() do\n  let x = 5\nend\n\nfn main() do\n  f()\n  println(\"ok\")\n  let y = 6\nend\n";
    assert_eq!(run(source), "ok\n");
}

#[test]
fn heredoc_keeps_lines_around_interpolations() {
    // A heredoc ends at its last content line (no trailing newline).
    let source = "fn main() do\n  let a = \"\"\"\n    line one\n    #{1 + 2}\n    line three\n    \"\"\"\n  println(a)\n  let b = \"\"\"\n    x #{1 + 2} y\n    \"\"\"\n  println(b)\nend\n";
    assert_eq!(run(source), "line one\n3\nline three\nx 3 y\n");
}

// ── Closures and inference ─────────────────────────────────────────────

#[test]
fn closure_parameter_annotations_keep_generic_arguments() {
    let source = r##"
fn main() do
  let len = fn(xs :: List<Int>) -> List.length(xs) end
  let show = fn(o :: Option<Int>) -> case o do Some(n) -> "S#{n}" None -> "N" end end
  println("#{len([1, 2])} #{show(Some(1))}")
end
"##;
    assert_eq!(run(source), "2 S1\n");
}

#[test]
fn let_bound_closure_takes_the_type_of_its_use() {
    let source = r##"
fn main() do
  let show = fn o -> "#{o}" end
  let pick = fn o -> case o do
    Some(n) -> "S#{n}"
    None -> "N"
  end end
  let pair = fn p -> case p do (a, b) -> "#{a}#{b}" end end
  println(show(1) <> " " <> pick(Some(2)) <> " " <> pair((3, 4)))
end
"##;
    assert_eq!(run(source), "1 S2 34\n");
}

/// A let-bound closure is polymorphic like a named function: each use type
/// gets its own compiled copy, captures included.
#[test]
fn let_bound_closure_is_specialized_per_use_type() {
    let source = r##"
fn main() do
  let suffix = "!"
  let id = fn x -> x end
  let tag = fn x -> "#{x}#{suffix}" end
  let twice = fn f, x -> f(f(x)) end
  println("#{id(1)} #{id("s")} #{id(2.5)} #{tag(1)} #{tag("s")} #{twice(fn n -> n + 1 end, 1)}")
  println("#{List.map([1, 2], id)} #{List.map(["a"], id)} #{id([true])}")
end
"##;
    assert_eq!(run(source), "1 s 2.5 1! s! 3\n[1, 2] [a] [true]\n");
}

#[test]
fn trait_bound_holds_inside_closures_of_a_generic_function() {
    let source = r##"
interface Describe do
  fn describe(self) -> String
end
impl Describe for Int do
  fn describe(self) -> String do "int #{self}" end
end
impl Describe for String do
  fn describe(self) -> String do "string '#{self}'" end
end
impl Describe for Bool do
  fn describe(self) -> String do if self do "yes" else "no" end end
end
fn show_all<T>(items :: List<T>) -> List<String> where T: Describe do
  List.map(items, fn i -> i.describe() end)
end
fn each<T>(items :: List<T>) -> List<String> where T: Describe do
  for i in items do
    i.describe()
  end
end
fn twice<T>(item :: T) -> String where T: Describe do
  let f = fn -> item.describe() end
  f() <> f()
end
fn main() do
  println("#{show_all([1, 2])} #{show_all(["x"])} #{show_all([true, false])}")
  println("#{each([3])} #{twice(4)}")
end
"##;
    let (warnings, out) = run_with_build_stderr(source);
    assert_eq!(
        out,
        "[int 1, int 2] [string 'x'] [yes, no]\n[int 3] int 4int 4\n"
    );
    assert!(!warnings.contains("type checker bug"), "{warnings}");
}

#[test]
fn generic_function_specializes_per_source_type() {
    let source = r##"
fn each<T>(xs :: List<T>) -> List<String> where T: Display do
  List.map(xs, fn x -> x.to_string() end)
end
fn main() do
  println("#{each([1, 2])} #{each(["a"])} #{each([true])}")
end
"##;
    assert_eq!(run(source), "[1, 2] [a] [true]\n");
}

#[test]
fn pattern_bound_names_interpolate_inside_closures() {
    let source = "fn main() do\n  let r = List.map([Some(1), None], fn o -> case o do Some(n) -> \"#{n}\" None -> \"-\" end end)\n  println(\"#{r}\")\nend\n";
    assert_eq!(run(source), "[1, -]\n");
}

// ── Interfaces ─────────────────────────────────────────────────────────

#[test]
fn default_interface_methods_run_for_each_implementing_type() {
    let source = r##"
interface Shape do
  fn area(self) -> Float
  fn name(self) -> String
  fn describe(self) -> String do
    "#{self.name()} with area #{self.area()}"
  end
end

struct Circle do
  r :: Float
end

struct Sq do
  side :: Float
end

impl Shape for Circle do
  fn area(self) -> Float do 3.0 * self.r * self.r end
  fn name(self) -> String do "circle" end
end

impl Shape for Sq do
  fn area(self) -> Float do self.side * self.side end
  fn name(self) -> String do "square" end
  fn describe(self) -> String do "custom square #{self.side}" end
end

fn main() do
  let c = Circle { r: 1.0 }
  println(c.describe())
  println(Sq { side: 2.0 }.describe())
end
"##;
    assert_eq!(run(source), "circle with area 3.0\ncustom square 2.0\n");
}

#[test]
fn static_interface_methods_are_called_through_the_type() {
    let source = r##"
interface Counter do
  fn zero() -> Int
  fn bump(self, n :: Int) -> Int
end
struct Tally do
  count :: Int
end
impl Counter for Tally do
  fn zero() -> Int do 0 end
  fn bump(self, n :: Int) -> Int do self.count + n end
end
fn main() do
  println("#{Tally.zero()} #{Tally { count: 5 }.bump(3)}")
end
"##;
    assert_eq!(run(source), "0 8\n");
}

// ── Sum types ──────────────────────────────────────────────────────────

#[test]
fn recursive_sum_types_construct_match_and_derive() {
    let source = r##"
type IntList do
  Nil
  Cons(Int, IntList)
end deriving(Eq, Display, Debug)

type Tree<T> do
  Leaf
  Node(Tree<T>, T, Tree<T>)
end

fn sum(l :: IntList) -> Int do
  case l do
    Nil -> 0
    Cons(h, t) -> h + sum(t)
  end
end

fn build(n :: Int) -> IntList do
  if n == 0 do Nil else Cons(n, build(n - 1)) end
end

fn size<T>(t :: Tree<T>) -> Int do
  case t do
    Leaf -> 0
    Node(l, _, r) -> 1 + size(l) + size(r)
  end
end

fn main() do
  let l = Cons(1, Cons(2, Nil))
  println("#{sum(l)} #{sum(build(100))}")
  println("#{l == Cons(1, Cons(2, Nil))} #{l == Cons(1, Nil)}")
  println("#{l}")
  println(l.inspect())
  println("#{size(Node(Node(Leaf, 1, Leaf), 2, Leaf))} #{size(Node(Leaf, "s", Leaf))}")
end
"##;
    assert_eq!(
        run(source),
        "3 5050\ntrue false\nCons(1, Cons(2, Nil))\nCons(1, Cons(2, Nil))\n2 1\n"
    );
}

#[test]
fn debug_inspect_on_sum_types() {
    let source = "type Level do\n  Low\n  Mid\n  High\nend deriving(Eq, Ord, Display, Debug, Hash)\nfn main() do\n  println(\"#{Mid.inspect()} #{Low < High} #{Mid} #{High == High}\")\nend\n";
    assert_eq!(run(source), "Mid true Mid true\n");
}

#[test]
fn lists_of_structs_and_sum_types_display_and_sort() {
    let source = r##"
struct Money do
  cents :: Int
end deriving(Eq, Display)
type Level do
  Low
  Mid
  High
end deriving(Eq, Ord, Display)
fn main() do
  println("#{[Money { cents: 1 }, Money { cents: 2 }]}")
  println("#{[High, Low]}")
  println("#{List.sort([High, Low, Mid], fn x, y -> if x < y do -1 else 1 end end)}")
  println("#{List.reduce([High, Low, Mid], High, fn acc, x -> if x < acc do x else acc end end)}")
end
"##;
    assert_eq!(
        run(source),
        "[Money(1), Money(2)]\n[High, Low]\n[Low, Mid, High]\nLow\n"
    );
}

// ── Runtime values ─────────────────────────────────────────────────────

#[test]
fn runtime_option_passed_directly_to_functions_and_closures() {
    let source = r##"
fn show(o :: Option<Int>) -> String do
  case o do
    Some(n) -> "S#{n}"
    None -> "N"
  end
end
fn main() do
  let pick = fn o -> case o do Some(n) -> "s#{n}" None -> "n" end end
  println(show(String.to_int("42")) <> show(String.to_int("x")) <> pick(String.to_int("7")))
end
"##;
    assert_eq!(run(source), "S42Ns7\n");
}

#[test]
fn list_find_on_scalars_matches() {
    let source = r##"
fn main() do
  let xs = [3, 1, 2]
  let found = case List.find(xs, fn x -> x == 2 end) do
    Some(v) -> "found #{v}"
    None -> "none"
  end
  let missing = case List.find(xs, fn x -> x == 9 end) do
    Some(v) -> "found #{v}"
    None -> "none"
  end
  let s = case List.find(["a", "bb"], fn s -> String.length(s) == 2 end) do
    Some(v) -> v
    None -> "none"
  end
  println("#{found} #{missing} #{s}")
end
"##;
    assert_eq!(run(source), "found 2 none bb\n");
}

#[test]
fn for_over_a_list_of_tuples() {
    let source = "fn main() do\n  let mixed = [(1, \"a\"), (2, \"b\")]\n  for pr in mixed do\n    let n = Tuple.first(pr)\n    let ch = Tuple.second(pr)\n    print(\"#{n}#{ch} \")\n  end\n  println(\"\")\nend\n";
    assert_eq!(run(source), "1a 2b \n");
}

#[test]
fn for_body_ending_in_if_without_else() {
    let source = r##"
fn first_even(xs :: List<Int>) -> Int do
  for x in xs do
    if x % 2 == 0 do
      return x
    end
  end
  -1
end
fn main() do
  println("#{first_even([1, 4])} #{first_even([1])}")
  for x in [1, 2] do
    if x == 1 do
      println("one")
    end
  end
end
"##;
    assert_eq!(run(source), "4 -1\none\n");
}

#[test]
fn queue_pop_destructures_into_front_and_rest() {
    let source = "fn main() do\n  let q = Queue.push(Queue.push(Queue.new(), 1), 2)\n  let (front, rest) = Queue.pop(q)\n  println(\"#{front} #{Queue.size(rest)} #{Tuple.first(Queue.pop(rest))}\")\nend\n";
    assert_eq!(run(source), "1 1 2\n");
}

// ── Structural equality, ordering and display ──────────────────────────

#[test]
fn tuples_maps_sets_unit_and_ordering_compare_by_contents() {
    let source = r##"
struct Point do
  x :: Int
  y :: Int
end

type Shape do
  Circle(Int)
  Poly(List<Int>)
end

fn main() do
  println("#{(1, 2) == (1, 2)} #{(1, "a") == (1, "b")} #{(1, (2, 3)) == (1, (2, 3))}")
  println("#{%{"a" => 1, "b" => 2} == %{"b" => 2, "a" => 1}} #{%{"a" => 1} == %{"a" => 2}}")
  println("#{Set.from_list([1, 2]) == Set.from_list([2, 1])} #{Set.from_list([1]) == Set.from_list([2])}")
  let u = ()
  println("#{u == u} #{compare(1, 2) == Less} #{compare(2, 1)} #{Less < Greater}")
  println("#{Some(1) == Some(1)} #{Some(1) == None} #{Ok(1) == Err("x")} #{Some([1, 2]) == Some([1, 2])}")
  println("#{[Some(1), None] == [Some(1), None]} #{[(1, 2)] == [(1, 2)]} #{[1.0, 2.5] == [1.0, 2.5]} #{[1.0] == [2.0]}")
  println("#{Poly([1, 2]) == Poly([1, 2])} #{Circle(1) == Poly([1])} #{Point { x: 1, y: 2 } == Point { x: 1, y: 2 }}")
  println("#{(1, 2) < (1, 3)} #{(2, 0) > (1, 9)} #{[-1.0] < [1.0]} #{["a"] < ["b"]} #{Some(1) < Some(2)}")
end
"##;
    assert_eq!(
        run(source),
        "true false true\ntrue false\ntrue false\ntrue true Greater true\ntrue false false true\ntrue true true false\ntrue false true\ntrue true true true true\n"
    );
}

#[test]
fn tuples_options_results_and_floats_display_everywhere() {
    let source = r##"
struct Pt do
  x :: Int
end

impl Display for Pt do
  fn to_string(self) do
    "P#{self.x}"
  end
end

fn main() do
  println("#{(1, "a")} #{(1, (2.5, true))} #{[(1, "a"), (2, "b")]}")
  println("#{Some(1)} #{None} #{Some("s")} #{Ok(1)} #{Err("bad")} #{[Some(1), None]} #{[Some("x")]}")
  println("#{Some(1).inspect()} #{Some("x").inspect()} #{(1, "a").inspect()} #{[Some(1)].inspect()}")
  println("#{Some(1).to_string()} #{(1, 2).to_string()} #{()}")
  let p = Pt { x: 1 }
  println("#{p} #{p.to_string()} #{[p]} #{Some(p)} #{(p, 4)} #{%{"k" => (1, 2)}} #{%{1 => Some(2)}}")
  println("#{6.0} #{Float.from(42)} #{1.5 * 2.0} #{[1.0, 2.5]} #{-3.0} #{10.0 / 4.0} #{(1.0, 2.0)} #{Some(2.0)}")
end
"##;
    assert_eq!(
        run(source),
        "(1, a) (1, (2.5, true)) [(1, a), (2, b)]\n\
         Some(1) None Some(s) Ok(1) Err(bad) [Some(1), None] [Some(x)]\n\
         Some(1) Some(\"x\") (1, \"a\") [Some(1)]\n\
         Some(1) (1, 2) ()\n\
         P1 P1 [P1] Some(P1) (P1, 4) %{k => (1, 2)} %{1 => Some(2)}\n\
         6.0 42.0 3.0 [1.0, 2.5] -3.0 2.5 (1.0, 2.0) Some(2.0)\n"
    );
}

#[test]
fn single_letter_type_names_are_types_not_type_parameters() {
    let source = r##"
struct P do
  x :: Int
end deriving(Eq, Display)

type A do
  B
  C(Int)
end deriving(Eq, Display)

fn main() do
  println("#{P { x: 1 } == P { x: 1 }} #{P { x: 2 }} #{C(3) == C(3)} #{B}")
end
"##;
    assert_eq!(run(source), "true P(2) true B\n");
}

// ── Loops, calls and closures ──────────────────────────────────────────

#[test]
fn for_loops_destructure_tuple_patterns() {
    let source = r##"
fn main() do
  let pairs = [(1, "a"), (2, "b"), (3, "c")]
  for (n, s) in pairs when n != 2 do
    println("#{n}: #{s}")
  end
  let squares = for (n, _) in pairs do n * n end
  println("#{squares}")
  for (k, v) in %{"x" => 1} do
    println("#{k}=#{v}")
  end
  for (a, (b, c)) in [(1, (2, 3))] do
    println("#{a + b + c}")
  end
  for (i, x) in List.enumerate(["p", "q"]) do
    println("#{i} #{x}")
  end
end
"##;
    assert_eq!(run(source), "1: a\n3: c\n[1, 4, 9]\nx=1\n6\n0 p\n1 q\n");
}

#[test]
fn function_typed_struct_fields_are_callable_with_dot_syntax() {
    let source = r##"
struct Op do
  run :: Fun(Int) -> Int
end

fn main() do
  let op = Op { run: fn x -> x * 2 end }
  println("#{op.run(10)} #{(op.run)(21)}")
end
"##;
    assert_eq!(run(source), "20 42\n");
}

#[test]
fn ranges_are_values_outside_for_headers() {
    let source = "fn main() do\n  let r = 1..5\n  println(\"#{Range.to_list(r)} #{Range.to_list(3..4)}\")\nend\n";
    assert_eq!(run(source), "[1, 2, 3, 4] [3]\n");
}

#[test]
fn iter_find_returns_a_typed_option() {
    let source = r##"
fn main() do
  let found = Iter.find(Iter.from([1, 2, 3]), fn x -> x > 1 end)
  case found do
    Some(v) -> println("found #{v}")
    None -> println("none")
  end
  case Iter.find(Iter.from(["a"]), fn s -> s == "z" end) do
    Some(v) -> println("found #{v}")
    None -> println("none")
  end
end
"##;
    assert_eq!(run(source), "found 2\nnone\n");
}

#[test]
fn impl_methods_without_return_annotations_return_their_body_type() {
    let source = r##"
interface Named do
  fn label(self) -> String
end

struct User do
  name :: String
end

impl Named for User do
  fn label(self) do
    "user:#{self.name}"
  end
end

fn main() do
  let u = User { name: "ann" }
  println(u.label())
end
"##;
    assert_eq!(run(source), "user:ann\n");
}

// ── Lists ──────────────────────────────────────────────────────────────

#[test]
fn optimized_list_reads_respect_view_offsets_and_bounds() {
    let source = r##"
fn main() do
  let owned = [10, 20, 30, 40]
  let view = List.drop(List.tail(owned), 1)
  println("#{List.get(owned, 0)} #{List.length(view)} #{List.get(view, 0)} #{List.get(view, 1)}")
  println(List.get(List.tail(["a", "b", "c"]), 1))
end
"##;
    let flags = ["--opt-level", "2"];
    assert_eq!(
        run_built(&build_with_args(source, &flags)),
        "10 2 30 40\nc\n"
    );
    for index in [-1, 2] {
        let source = format!(
            "fn main() do\n  let value = List.get(List.tail([1, 2, 3]), {index})\n  println(\"#{{value}}\")\nend\n"
        );
        let (code, stdout, stderr) = run_status(&source, &flags);
        assert_eq!(code, Some(101), "{stderr}");
        assert!(stdout.is_empty());
        assert!(stderr.contains(&format!(
            "List.get: index {index} is out of bounds for a list of length 2"
        )));
    }
}

#[test]
fn optimized_integer_list_folds_preserve_views_and_bounds() {
    let source = r##"
fn fold(xs :: List<Int>, limit :: Int, index :: Int, acc :: Int) -> Int do
  if index == limit do
    acc
  else
    fold(xs, limit, index + 1, acc + (index + 1) * List.get(xs, index))
  end
end

actor observe_fold_yield() do
  receive do
    1 -> println("observer ran")
    _ -> panic("unexpected observer message")
  end
end

actor fold_actor(xs :: List<Int>, observer :: Pid<Int>) do
  let _ = send(observer, 1)
  println("#{fold(xs, List.length(xs), 0, 0)}")
end

fn main() do
  let xs = Range.to_list(1..10005)
  let view = List.drop(xs, 9)
  case Env.get("FOLD_TEST_MODE", "") do
    "bad_range" -> println("#{fold(view, 9996, 9994, 0)}")
    "actor" ->
      let observer = spawn(observe_fold_yield)
      let _ = spawn(fold_actor, view, observer)
    _ ->
      println("#{fold(xs, 5004, 0, 0)}")
      println("#{fold(view, 4993, 3, 17)}")
      println("#{fold([], 0, 0, 19)}")
  end
end
"##;
    let built = build_with_args(source, &["--opt-level", "2", "--emit-llvm"]);
    assert_eq!(run_built(&built), "41779267530\n41616585047\n19\n");
    let ir = std::fs::read_to_string(built.dir.path().join("project/project.ll")).unwrap();
    assert!(ir.contains("fold_chunk:"), "the compiler skipped the fold");
    let binary = built.dir.path().join("project/project");
    let actor = Command::new(&binary)
        .env("FOLD_TEST_MODE", "actor")
        .env("MESH_SCHEDULER_MIN_WORKERS", "1")
        .env("MESH_SCHEDULER_MAX_WORKERS", "1")
        .output()
        .expect("run fold across an actor timeslice");
    assert!(actor.status.success(), "{actor:?}");
    assert_eq!(
        String::from_utf8_lossy(&actor.stdout),
        "observer ran\n333333130060\n"
    );
    let output = Command::new(binary)
        .env("FOLD_TEST_MODE", "bad_range")
        .output()
        .expect("run out-of-bounds fold");
    assert_eq!(output.status.code(), Some(101));
    assert!(
        String::from_utf8_lossy(&output.stderr)
            .contains("List.get: index 9995 is out of bounds for a list of length 9995"),
        "{:?}",
        output
    );
}

#[test]
fn list_tail_is_a_view_so_cons_recursion_is_linear() {
    // 30k elements: with a copying tail this took seconds; a view makes each
    // step constant, and views behave as lists everywhere they flow.
    let source = r##"
fn sum(xs :: List<Int>, acc :: Int) -> Int do
  case xs do
    h :: t -> sum(t, acc + h)
    [] -> acc
  end
end

fn main() do
  let xs = Range.to_list(1..30001)
  println("#{sum(xs, 0)}")
  let t = List.tail([1, 2, 3])
  println("#{t} #{List.length(t)} #{List.drop(xs, 29998)} #{List.append(t, 9)} #{List.tail(t) ++ [7]}")
  println("#{List.tail([1, 2]) == [2]} #{String.join(List.tail(["a", "b", "c"]), "-")} #{Set.size(Set.from_list(List.tail([1, 1, 2])))}")
end
"##;
    let started = std::time::Instant::now();
    assert_eq!(
        run(source),
        "450015000\n[2, 3] 2 [29999, 30000] [2, 3, 9] [3, 7]\ntrue b-c 2\n"
    );
    // Under MESH_GC_STRESS every allocation collects, which is quadratic
    // here by design; the bound is about the copy that used to happen.
    if std::env::var_os("MESH_GC_STRESS").is_none() {
        assert!(started.elapsed() < std::time::Duration::from_secs(60));
    }
}

#[test]
fn list_tail_views_cross_actor_boundaries() {
    let source = r##"
actor printer() do
  receive do
    xs -> println("#{xs} #{List.length(xs)}")
  end
end

fn main() do
  let p = spawn(printer)
  send(p, List.tail([1, 2, 3]))
  Timer.sleep(200)
end
"##;
    assert_eq!(run(source), "[2, 3] 2\n");
}

#[test]
fn list_literal_patterns_match_fixed_lengths() {
    let source = r##"
fn describe(xs :: List<Int>) -> String do
  case xs do
    [] -> "empty"
    [x] -> "one #{x}"
    [x, y] -> "two #{x} #{y}"
    h :: t -> "many #{h} +#{List.length(t)}"
  end
end

fn sum(xs :: List<Int>) -> Int do
  case xs do
    [] -> 0
    h :: t -> h + sum(t)
  end
end

fn pairs(xs :: List<(Int, String)>) -> String do
  case xs do
    [(1, s), _] -> "first is one: #{s}"
    _ -> "other"
  end
end

fn main() do
  println("#{describe([])} #{describe([7])} #{describe([1, 2])} #{describe([1, 2, 3])}")
  println("#{sum([1, 2, 3, 4])} #{pairs([(1, "a"), (2, "b")])} #{pairs([(2, "a"), (1, "b")])}")
  println("#{for l in [[1], [], [2, 3]] do describe(l) end}")
end
"##;
    assert_eq!(
        run(source),
        "empty one 7 two 1 2 many 1 +2\n10 first is one: a other\n[one 1, empty, two 2 3]\n"
    );
    let err = build_error(
        "fn f(xs :: List<Int>) -> Int do\n  case xs do\n    [] -> 0\n    [x] -> x\n  end\nend\nfn main() do\n  println(\"#{f([1])}\")\nend\n",
    );
    assert!(
        err.contains("_ :: _ :: _"),
        "witness should name lists of two or more:\n{err}"
    );
}

// ── Recursive types ────────────────────────────────────────────────────

#[test]
fn mutually_recursive_and_tuple_payload_sum_types() {
    let source = r##"
type Expr do
  Num(Int)
  Block(Stmt)
end

type Stmt do
  Ret(Expr)
  Nop
end

type Chain do
  Leaf
  Node((Int, Chain))
end

fn eval(e :: Expr) -> Int do
  case e do
    Num(n) -> n
    Block(s) -> run(s)
  end
end

fn run(s :: Stmt) -> Int do
  case s do
    Ret(e) -> eval(e)
    Nop -> 0
  end
end

fn depth(c :: Chain) -> Int do
  case c do
    Leaf -> 0
    Node((n, rest)) -> n + depth(rest)
  end
end

fn main() do
  println("#{eval(Block(Ret(Num(7))))} #{run(Nop)} #{depth(Node((1, Node((2, Leaf)))))}")
end
"##;
    assert_eq!(run(source), "7 0 3\n");
}

// ── Branches that never return ─────────────────────────────────────────

#[test]
fn a_returning_first_branch_does_not_type_the_whole_expression() {
    let source = r##"
fn f(x :: Int) -> Int do
  let y = case x do
    0 -> return 5
    _ -> x * 3
  end
  let z = if x > 10 do
    return 7
  else
    y + 1
  end
  z
end

fn main() do
  println("#{f(0)} #{f(2)} #{f(20)}")
end
"##;
    assert_eq!(run(source), "5 7 7\n");
}

// ── Actors ─────────────────────────────────────────────────────────────

/// Lines of output, sorted: separate actors print in no fixed order.
fn sorted_lines(output: &str) -> Vec<&str> {
    let mut lines: Vec<&str> = output.lines().collect();
    lines.sort_unstable();
    lines
}

#[test]
fn receive_matches_arms_by_pattern_and_guard() {
    let source = r##"
struct Job do
  id :: Int
  name :: String
end

fn is_stop(j :: Job) -> Bool do
  j.id == 0
end

actor numbers() do
  receive do
    0 -> println("zero")
    1 -> println("one")
    n ->
      println("other #{n}")
      numbers()
  end
end

actor tuples(seen :: Int) do
  receive do
    (0, label) -> println("zero-tagged #{label} seen=#{seen}")
    (n, label) when n > 100 ->
      let big = n * 2
      println("big #{label} #{big}")
      tuples(seen + 1)
    (n, label) ->
      println("tuple #{n} #{label}")
      tuples(seen + 1)
  after 500 ->
    println("idle after #{seen}")
  end
end

actor jobs() do
  receive do
    j when is_stop(j) -> println("stop job #{j.name}")
    j ->
      println("job #{j.id}: #{j.name}")
      jobs()
  end
end

actor strings() do
  receive do
    "quit" -> println("quit")
    s ->
      println("string #{s}")
      strings()
  end
end

actor floats(total :: Float) do
  let next = receive do
    x when x < 0.0 -> -1.0
    x -> total + x
  end
  if next < 0.0 do
    println("float total #{total}")
  else
    floats(next)
  end
end

fn main() do
  let n = spawn(numbers)
  send(n, 7)
  send(n, 1)
  let t = spawn(tuples, 0)
  send(t, (5, "five"))
  send(t, (500, "huge"))
  send(t, (0, "end"))
  let j = spawn(jobs)
  send(j, Job { id: 3, name: "build" })
  send(j, Job { id: 0, name: "halt" })
  let s = spawn(strings)
  send(s, "héllo")
  send(s, "quit")
  let f = spawn(floats, 0.5)
  send(f, 1.25)
  send(f, 2.0)
  send(f, -3.0)
  let idle = spawn(tuples, 7)
  Timer.sleep(800)
end
"##;
    let expected = [
        "big huge 1000",
        "float total 3.75",
        "idle after 7",
        "job 3: build",
        "one",
        "other 7",
        "quit",
        "stop job halt",
        "string héllo",
        "tuple 5 five",
        "zero-tagged end seen=2",
    ];
    for opt in ["0", "2"] {
        let built = build_with_args(source, &["--opt-level", opt]);
        assert_eq!(
            sorted_lines(&run_built(&built)),
            expected,
            "--opt-level {opt}"
        );
    }
}

#[test]
fn an_actor_arm_may_stop_instead_of_calling_the_actor_again() {
    let source = r##"
type Msg do
  Add(n :: Int)
  Print
  Stop
end

actor acc(total :: Int) do
  receive do
    Add(n) -> acc(total + n)
    Print ->
      println("total=#{total}")
      acc(total)
    Stop -> println("stopping at #{total}")
  end
end

actor looper(n :: Int) do
  receive do
    m ->
      println("got #{m} at #{n}")
      if m > 0 do
        looper(n + 1)
      else
        println("done")
      end
  end
end

fn main() do
  let pid = spawn(acc, 0)
  send(pid, Add(5))
  send(pid, Add(7))
  send(pid, Print)
  send(pid, Stop)
  Timer.sleep(100)
  let l = spawn(looper, 0)
  send(l, 1)
  send(l, 2)
  send(l, 0)
  Timer.sleep(100)
end
"##;
    assert_eq!(
        run(source),
        "total=12\nstopping at 12\ngot 1 at 0\ngot 2 at 1\ngot 0 at 2\ndone\n"
    );
}

#[test]
fn an_actor_calling_itself_outside_tail_position_runs_its_body() {
    let source = r##"
actor nested(depth :: Int) do
  receive do
    m ->
      println("got #{m} at #{depth}")
      if m > 0 do
        nested(depth + 1)
        println("back at #{depth}")
      end
  end
end

fn main() do
  let p = spawn(nested, 0)
  send(p, 1)
  send(p, 0)
  Timer.sleep(100)
end
"##;
    assert_eq!(run(source), "got 1 at 0\ngot 0 at 1\nback at 0\n");
}

#[test]
fn an_actor_message_type_is_inferred_from_what_is_sent_to_it() {
    let source = r##"
actor echo() do
  receive do
    m -> println("echo got #{m}")
  end
end

actor ring(n :: Int) do
  if n > 0 do
    let child = spawn(ring, n - 1)
    send(child, n)
  end
  receive do
    m -> println("ring got #{m}")
  end
end

fn main() do
  let p = spawn(echo)
  send(p, 100)
  let r = spawn(ring, 2)
  send(r, 50)
  Timer.sleep(100)
end
"##;
    assert_eq!(
        sorted_lines(&run(source)),
        ["echo got 100", "ring got 1", "ring got 2", "ring got 50"]
    );
    let err = build_error(
        "actor echo() do\n  receive do\n    m -> println(\"#{m}\")\n  end\nend\nfn main() do\n  let p = spawn(echo)\n  send(p, 1)\n  send(p, \"two\")\nend\n",
    );
    assert!(
        err.contains("message type mismatch: expected `Int`, found `String`"),
        "mixed message types:\n{err}"
    );
}

#[test]
fn receive_arms_must_cover_the_message_type() {
    let err = build_error(
        "actor num() do\n  receive do\n    0 -> println(\"zero\")\n    1 -> println(\"one\")\n  end\nend\nfn main() do\n  let pid = spawn(num)\n  send(pid, 1)\nend\n",
    );
    assert!(err.contains("non-exhaustive match on `Int`"), "{err}");
    let (warnings, out) = run_with_build_stderr(
        "actor num() do\n  receive do\n    n -> println(\"any #{n}\")\n    0 -> println(\"zero\")\n  end\nend\nfn main() do\n  let pid = spawn(num)\n  send(pid, 1)\n  Timer.sleep(50)\nend\n",
    );
    assert!(warnings.contains("redundant match arm"), "{warnings}");
    assert_eq!(out, "any 1\n");
}

// ── Numbers ────────────────────────────────────────────────────────────

/// Build and run a program that may fail; returns (exit code, stdout, stderr).
/// What a program writes on stderr for runtime panics with `messages`,
/// raised where compiled code does not know the place (`List.get`): one
/// `R0001` report each, in order.
/// What a program's runtime writes for `diagnostics`, one process showing
/// each code's footer once.
fn runtime_report(diagnostics: impl IntoIterator<Item = mesh_diagnostics::Diagnostic>) -> String {
    let mut out = Vec::new();
    let mut reporter =
        mesh_diagnostics::Reporter::new(mesh_diagnostics::Format::Human { color: false }, &mut out);
    for diagnostic in diagnostics {
        reporter.emit(diagnostic);
    }
    drop(reporter);
    String::from_utf8(out).unwrap()
}

fn panic_report(messages: &[&str]) -> String {
    runtime_report(
        messages.iter().map(|message| {
            mesh_diagnostics::Diagnostic::new(mesh_diagnostics::Code::Panic, *message)
        }),
    )
}

fn run_status(source: &str, args: &[&str]) -> (Option<i32>, String, String) {
    let built = build_with_args(source, args);
    assert!(built.ok, "build failed:\n{}", built.stderr);
    let output = Command::new(built.dir.path().join("project/project"))
        .output()
        .expect("run binary");
    (
        output.status.code(),
        String::from_utf8_lossy(&output.stdout).to_string(),
        String::from_utf8_lossy(&output.stderr).to_string(),
    )
}

#[test]
fn integer_division_by_zero_panics_and_min_divided_by_minus_one_wraps() {
    let wraps = r##"
fn div(a :: Int, b :: Int) -> Int = a / b
fn rem(a :: Int, b :: Int) -> Int = a % b

fn main() do
  let min = 0 - 9223372036854775807 - 1
  println("#{div(min, -1)} #{rem(min, -1)} #{div(7, -1)} #{rem(7, -2)} #{div(-7, 2)}")
end
"##;
    let panics = r##"
fn main() do
  let zero = 0
  println("before")
  println("#{10 % zero}")
  println("after")
end
"##;
    for opt in ["0", "2"] {
        let (code, out, _) = run_status(wraps, &["--opt-level", opt]);
        assert_eq!(code, Some(0));
        assert_eq!(out, "-9223372036854775808 0 -7 1 -3\n", "--opt-level {opt}");
        // The panic ends the process cleanly instead of aborting.
        let (code, out, err) = run_status(panics, &["--opt-level", opt]);
        assert_eq!(code, Some(101), "--opt-level {opt}\n{err}");
        assert_eq!(out, "before\n");
        assert!(err.contains("[R0001] Error: division by zero"), "{err}");
        // At the `%`: line 5, where `10 % zero` starts.
        assert!(err.contains("main.mpl:5:14\n"), "{err}");
        assert!(!err.contains("failed to initiate panic"), "{err}");
    }
}

#[test]
fn nan_is_unequal_to_itself_and_float_to_int_saturates() {
    let source = r##"
fn main() do
  let nan = 0.0 / 0.0
  let big = 1.0e20
  println("#{nan != nan} #{not (nan == nan)} #{[nan] != [nan]} #{1.0 != 1.0}")
  println("#{Float.to_int(big)} #{Float.to_int(0.0 - big)} #{Float.to_int(nan)}")
  println("#{Math.floor(big)} #{Math.ceil(nan)} #{Math.round(0.0 - big)} #{Float.to_int(2.9)}")
end
"##;
    for opt in ["0", "2"] {
        let (code, out, err) = run_status(source, &["--opt-level", opt]);
        assert_eq!(code, Some(0), "{err}");
        assert_eq!(
            out,
            "true true true false\n9223372036854775807 -9223372036854775808 0\n9223372036854775807 0 -9223372036854775808 2\n",
            "--opt-level {opt}"
        );
    }
}

// ── Diagnostic locations ───────────────────────────────────────────────

#[test]
fn a_service_handler_type_error_points_at_the_handler() {
    let source = "service Registry do\n  fn init() -> Int do\n    0\n  end\n\n  call Get() :: String do |n|\n    (n, n)\n  end\nend\n\nfn main() do\n  let r = Registry.start()\n  println(Registry.get(r))\nend\n";
    let diags = json_diagnostics(source);
    let codes: Vec<&str> = diags.iter().filter_map(|d| d["code"].as_str()).collect();
    // Only the handler's error: the service is still defined for `main`.
    assert_eq!(codes, ["E0001"], "{diags:?}");
    assert_eq!(
        diags[0]["message"],
        "type mismatch: expected `String`, found `Int`"
    );
    let start = source.find("(n, n)").unwrap();
    assert_eq!(diags[0]["spans"][0]["start"], start);
}

#[test]
fn an_undefined_module_is_reported_once() {
    let diags = json_diagnostics("fn main() do\n  let r = Nope.start()\n  println(\"x\")\nend\n");
    let codes: Vec<&str> = diags.iter().filter_map(|d| d["code"].as_str()).collect();
    assert_eq!(codes, ["E0004"], "{diags:?}");
}

// ── Pattern matching: guards, nesting, scoping ─────────────────────────

#[test]
fn a_failed_guard_tests_the_next_arms_patterns() {
    let source = r##"
fn classify(x :: Int) -> String do
  case x do
    n when n > 7 -> "big"
    0 -> "zero"
    _ -> "other"
  end
end

fn clause(n) when n > 7 = "big"
fn clause(0) = "zero"
fn clause(_) = "other"

fn never(o :: Option<Int>) -> Bool = false

fn main() do
  let closure = fn n when n > 7 -> "big" | 0 -> "zero" | _ -> "other" end
  println("#{classify(5)} #{classify(0)} #{classify(9)} #{clause(5)} #{closure(5)}")
  let r = case Some(1) do
    o when never(o) -> "never"
    None -> "none"
    Some(_) -> "some"
  end
  println(r)
  case 5 do
    a when a > 7 -> println("big #{a}")
    b -> println("other #{b}")
  end
end
"##;
    assert_eq!(run(source), "other zero big other other\nsome\nother 5\n");
}

#[test]
fn nested_or_patterns_match_only_their_alternatives() {
    let source = r##"
type Letter do
  A
  B
  C
end

fn describe(o :: Option<Int>) -> String do
  case o do
    Some(1 | 2) -> "small"
    Some(n) -> "n #{n}"
    None -> "none"
  end
end

fn main() do
  println("#{describe(Some(2))} #{describe(Some(3))} #{describe(None)}")
  let t = case (3, 0) do
    (1 | 2, _) -> "small"
    (n, _) -> "n #{n}"
  end
  let l = case Some(C) do
    Some(A | B) -> "a or b"
    _ -> "other"
  end
  println("#{t} #{l}")
end
"##;
    assert_eq!(run(source), "small n 3 none\nn 3 other\n");
}

#[test]
fn case_arm_bindings_do_not_leak_into_the_enclosing_scope() {
    let source = r##"
fn main() do
  let x = 1
  case Some(2) do
    Some(x) -> println("arm #{x}")
    None -> println("none")
  end
  println("after #{x}")
  let b = "outer"
  let r = case Some(5) do
    Some(b) -> b
    None -> 0
  end
  println("#{r} #{b}")
  for i in [1, 2] do
    case Some(i * 10) do
      Some(i) -> println("inner #{i}")
      None -> println("none")
    end
    println("loop #{i}")
  end
end
"##;
    assert_eq!(
        run(source),
        "arm 2\nafter 1\n5 outer\ninner 10\nloop 1\ninner 20\nloop 2\n"
    );
}

#[test]
fn list_patterns_read_aggregate_elements() {
    let source = r##"
struct P do
  x :: Int
end

type Sh do
  C(r :: Int)
  S(w :: Int)
end

fn first_ok(xs :: List<Int!String>) -> Int do
  case xs do
    Ok(a) :: _ -> a
    _ -> 0
  end
end

fn main() do
  case [P { x: 42 }] do
    h :: _ -> println("#{h.x}")
    [] -> println("empty")
  end
  case [Some(7)] do
    [Some(a)] -> println("got #{a}")
    _ -> println("no match")
  end
  case [S(8)] do
    h :: _ -> case h do
      C(a) -> println("C #{a}")
      S(a) -> println("S #{a}")
    end
    [] -> println("empty")
  end
  case [fn n -> n * 3 end] do
    f :: _ -> println("#{f(10)}")
    [] -> println("none")
  end
  case [Some(9)] do
    Some(a) :: _ -> println("head #{a}")
    _ -> println("no")
  end
  println("#{first_ok([Ok(7)])}")
end
"##;
    for opt in ["0", "2"] {
        let (code, out, err) = run_status(source, &["--opt-level", opt]);
        assert_eq!(code, Some(0), "{err}");
        assert_eq!(out, "42\ngot 7\nS 8\n30\nhead 9\n7\n", "--opt-level {opt}");
    }
}

#[test]
fn a_tuple_literal_scrutinee_is_matched_by_columns() {
    let source = r##"
type Sh do
  C(r :: Int)
  S(w :: Int)
end

fn classify(a :: Int, b :: String, s :: Sh) -> String do
  case (a, b, s) do
    (0, "x", _) -> "zero-x"
    (n, _, C(r)) when n > r -> "big C #{n} #{r}"
    (1 | 2, t, S(w)) -> "small S #{t} #{w}"
    (n, t, _) -> "other #{n} #{t}"
  end
end

fn main() do
  println(classify(0, "x", C(1)))
  println(classify(5, "y", C(2)))
  println(classify(2, "z", S(9)))
  println(classify(1, "q", C(4)))
end
"##;
    assert_eq!(run(source), "zero-x\nbig C 5 2\nsmall S z 9\nother 1 q\n");
}

// ── Function clauses ───────────────────────────────────────────────────

#[test]
fn clause_parameters_match_constructors_tuples_and_or_patterns() {
    let source = r##"
type Sh do
  C(r :: Int)
  S(w :: Int)
end

type Color do
  Red
  Green
  Blue
end

fn f(C(_), n) = "C #{n}"
fn f(_, n) = "other #{n}"

fn g((0, _), n) = "zero-first #{n}"
fn g(_, n) = "other #{n}"

fn opt_add(Some(a), Some(b)) = Some(a + b)
fn opt_add(_, _) = None

fn pick((a, _), true) = a
fn pick((_, b), false) = b

fn small(1 | 2, label) = "small #{label}"
fn small(_, label) = "big #{label}"

fn name(Red) = "red"
fn name(Green) = "green"
fn name(Blue) = "blue"

fn len([]) = 0
fn len(_ :: t) = 1 + len(t)

fn max(a, b) when a > b = a
fn max(_, b) = b

fn fact(0) do
  1
end
fn fact(n) do
  n * fact(n - 1)
end

fn unwrap(Some(v)) = v
fn unwrap(None) = 0

fn first(x, _) = x

fn main() do
  println("#{f(S(1), 2)} #{f(C(1), 3)} #{g((5, 1), 2)} #{g((0, 1), 4)}")
  println("#{opt_add(Some(1), Some(2))} #{opt_add(None, Some(2))} #{pick((1, 2), true)} #{pick((1, 2), false)}")
  println("#{small(2, "a")} #{small(3, "b")} #{name(Green)} #{name(Blue)}")
  println("#{len([1, 2, 3])} #{max(3, 2)} #{max(2, 3)} #{fact(5)} #{unwrap(Some(3))} #{unwrap(None)}")
  println("#{first(1, "a")} #{first("s", 2)}")
end
"##;
    assert_eq!(
        run(source),
        "other 2 C 3 other 2 zero-first 4\nSome(3) None 1 2\nsmall a big b green blue\n3 3 3 120 3 0\n1 s\n"
    );
}

#[test]
fn closure_clauses_match_their_parameters() {
    let source = r##"
type Sh do
  C(r :: Int)
  S(w :: Int)
end

type Wrap do
  W(Int)
end

fn main() do
  let f = fn C(_), n -> "C #{n}" | _, n -> "other #{n}" end
  let some = fn Some(x) -> x * 2 | None -> 0 end
  let unwrap = fn W(v) -> v end
  let flag = fn true -> "T" | false -> "F" end
  println("#{f(S(1), 2)} #{f(C(1), 3)} #{some(Some(4))} #{some(None)} #{unwrap(W(3))} #{flag(false)}")
end
"##;
    assert_eq!(run(source), "other 2 C 3 8 0 3 F\n");
}

#[test]
fn clauses_that_do_not_cover_every_argument_warn_and_panic_when_missed() {
    for (source, missing) in [
        ("fn f(\"a\") = 1\nfn main() do\n  println(\"#{f(\"zzz\")}\")\nend\n", "missing: _"),
        ("fn pos(n) when n > 0 = n\nfn main() do\n  println(\"#{pos(-5)}\")\nend\n", "missing: _"),
        ("fn f(0, n) = n\nfn f(1, n) = n + 1\nfn main() do\n  println(\"#{f(5, 4)}\")\nend\n", "missing: (_, _)"),
        ("type Color do\n  Red\n  Green\nend\nfn f(Red) = \"red\"\nfn main() do\n  println(f(Green))\nend\n", "missing: Green"),
        ("fn main() do\n  let t = fn true -> \"T\" end\n  println(t(false))\nend\n", "missing: false"),
    ] {
        // A clause group that misses values is a warning, as documented; a
        // call no clause matches panics instead of returning garbage.
        let built = build(source, false);
        assert!(built.ok, "{source}\n{}", built.stderr);
        assert!(built.stderr.contains("clauses do not cover every"), "{source}\n{}", built.stderr);
        assert!(built.stderr.contains(missing), "{source}\n{}", built.stderr);
        assert!(built.stderr.contains("Warning"), "{source}\n{}", built.stderr);
        let output = Command::new(built.dir.path().join("project/project"))
            .output()
            .expect("run binary");
        assert_eq!(output.status.code(), Some(101), "{source}");
        assert!(
            String::from_utf8_lossy(&output.stderr).contains("non-exhaustive match"),
            "{source}"
        );
        assert!(output.stdout.is_empty(), "{source}");
    }
}

// ── Tuple values ───────────────────────────────────────────────────────

#[test]
fn tuple_values_keep_their_elements_wherever_they_come_from() {
    let source = r##"
struct P do
  n :: Int
  f :: (String, Int)
end deriving(Eq)

struct Box<T> do
  value :: T
end

fn pair() -> (Int, Int) = (1, 2)

fn fst(t :: (String, Int)) -> String do
  let (s, _) = t
  s
end

fn main() do
  let z = pair()
  println("#{z} #{z == (1, 2)} #{Tuple.first(z)}")
  let w = if true do (1, "a") else (2, "b") end
  let c = case 2 do
    1 -> (0, 0)
    _ -> (3, 4)
  end
  println("#{w} #{c}")
  let p = fn (a :: Int) -> (a, a * 10) end
  let t = p(7)
  println("#{p(1)} #{Tuple.second(t)} #{[p(2)]}")
  let a = P { n: 1, f: ("x", 2) }
  let b = P { n: 1, f: ("x", 2) }
  let d = P { n: 1, f: ("y", 9) }
  println("#{a.f} #{fst(a.f)} #{a == b} #{a == d} #{Box { value: (5, 6) }.value}")
  let m = %{"b" => (2, 3)}
  let v = Map.get(m, "b")
  println("#{v} #{Tuple.first(v)}")
  for {k, pv} in m do
    println("#{k} #{pv}")
  end
  for (k, (x, y)) in %{1 => (10, "s")} do
    println("#{k} #{x} #{y}")
  end
end
"##;
    for opt in ["0", "2"] {
        let (code, out, err) = run_status(source, &["--opt-level", opt]);
        assert_eq!(code, Some(0), "{err}");
        assert_eq!(
            out,
            "(1, 2) true 1\n(1, a) (3, 4)\n(1, 10) 70 [(2, 20)]\n(x, 2) x true false (5, 6)\n(2, 3) 2\nb (2, 3)\n1 10 s\n",
            "--opt-level {opt}"
        );
    }
}

// ── Runtime ────────────────────────────────────────────────────────────

#[test]
fn list_collect_and_flat_map_keep_their_results_alive_across_collections() {
    let source = r##"
fn check(ws :: List<String>, i :: Int, bad :: Int) -> Int do
  case ws do
    w :: rest -> check(rest, i + 1, if w == "w#{i}" do bad else bad + 1 end)
    _ -> bad
  end
end

fn main() do
  let xs = for i in 0..20000 do
    i
  end
  let lazy :: List<String> = Iter.from(xs) |> Iter.map(fn (x :: Int) -> "w#{x}" end) |> List.collect()
  let fm = List.flat_map(xs, fn x -> ["w#{x}"] end)
  println("#{check(lazy, 0, 0)} #{check(fm, 0, 0)} #{List.length(fm)}")
end
"##;
    assert_eq!(run(source), "0 0 20000\n");
}

#[cfg(unix)]
#[test]
fn a_closed_stdout_ends_the_program_quietly() {
    // The runtime ignores SIGPIPE so a server outlives a client that hung up
    // (e2e_http_crash_isolation covers a closed stderr); `println` to a
    // closed stdout still ends the program the way SIGPIPE would.
    let built = build(
        "fn main() do\n  for i in 0..100000 do\n    println(\"line #{i}\")\n  end\nend\n",
        false,
    );
    assert!(built.ok, "{}", built.stderr);
    let mut child = Command::new(built.dir.path().join("project/project"))
        .stdout(std::process::Stdio::piped())
        .spawn()
        .expect("run binary");
    let mut first = [0u8; 6];
    std::io::Read::read_exact(child.stdout.as_mut().unwrap(), &mut first).unwrap();
    drop(child.stdout.take());
    let status = child.wait().unwrap();
    // It ends quietly, as SIGPIPE ends a C program (`prog | head`).
    use std::os::unix::process::ExitStatusExt;
    assert_eq!(status.signal(), Some(13), "{status:?}");
}

// ── Collections compare by Eq ──────────────────────────────────────────

#[test]
fn list_contains_compares_elements_by_their_eq() {
    let source = r##"
struct P do
  x :: Int
end

type Color do
  Red
  Green
end

fn main() do
  println("#{List.contains([(2, "b")], (2, "b"))} #{List.contains([Some(3)], Some(3))} #{List.contains([[3]], [3])}")
  println("#{List.contains([P { x: 1 }], P { x: 1 })} #{List.contains([Red], Red)} #{List.contains([Red], Green)}")
  println("#{[(1, 2)] |> List.contains((1, 2))} #{List.contains([0.0], -0.0)} #{List.contains([None], None)}")
  let nan = 0.0 / 0.0
  println("#{List.contains([nan], nan)} #{List.contains([1, 2], 2)} #{List.contains(["a"], "a")}")
end
"##;
    assert_eq!(
        run(source),
        "true true true\ntrue true false\ntrue true true\nfalse true true\n"
    );
}

#[test]
fn maps_compare_compound_keys_by_their_eq() {
    // `struct K` also checks that the built-in `Map<K, V>` impls do not take
    // a user type named K for their type parameter.
    let source = r##"
struct K do
  id :: Int
  name :: String
end

fn main() do
  let m = Map.put(Map.new(), (1, 2), "a")
  let m = Map.put(m, (1, 2), "b")
  println("#{Map.size(m)} #{Map.has_key(m, (1, 2))} #{Map.get(m, (1, 2))} #{Map.has_key(m, (2, 1))}")
  let ks = Map.put(Map.new(), K { id: 1, name: "x" }, 10)
  let ks = Map.put(ks, K { id: 1, name: "x" }, 11)
  println("#{Map.size(ks)} #{Map.get(ks, K { id: 1, name: "x" })} #{Map.has_key(ks, K { id: 2, name: "x" })}")
  let ls = Map.delete(Map.put(Map.put(Map.new(), [1], "one"), [2], "two"), [1])
  println("#{Map.size(ls)} #{Map.keys(ls)}")
  let fl = Map.from_list([("Al", 1), ("Bo", 2)])
  println("#{fl} #{Map.has_key(fl, "Al")} #{Map.get(fl, "Bo")}")
  let pairs = [(1, "a"), (2, "b"), (3, "c")]
  println("#{Map.from_list(List.drop(pairs, 1))}")
  let tl = Map.from_list([((1, 1), "x"), ((1, 1), "y")])
  println("#{Map.size(tl)} #{Map.get(tl, (1, 1))}")
  let zm = Iter.from(["a", "b"]) |> Iter.zip(Iter.from([1, 2])) |> Map.collect()
  println("#{Map.has_key(zm, "a")} #{Map.get(zm, "b")}")
  let lit = %{(1, "a") => 1, (1, "a") => 2}
  println("#{Map.size(lit)} #{Map.get(lit, (1, "a"))} #{lit == %{(1, "a") => 2}} #{lit == %{(1, "a") => 3}}")
  let mg = Map.merge(%{(1, 1) => 1}, %{(1, 1) => 2, (2, 2) => 3})
  println("#{Map.size(mg)} #{Map.get(mg, (1, 1))}")
  let sk = %{Some(1) => "s", None => "n"}
  println("#{Map.get(sk, Some(1))} #{Map.get(sk, None)}")
end
"##;
    assert_eq!(
        run(source),
        "1 true b false\n1 11 false\n1 [[2]]\n%{Al => 1, Bo => 2} true 2\n%{2 => b, 3 => c}\n1 y\ntrue 2\n1 2 true false\n2 2\ns n\n"
    );
}

#[test]
fn iterators_carry_their_element_types() {
    let source = r##"
struct P do
  x :: Int
end

fn main() do
  let words = Iter.from(["a", "bb", "ccc"]) |> Iter.map(fn w -> String.length(w) end) |> List.collect()
  let floats = Iter.from([1.5, 2.5]) |> Iter.map(fn f -> f * 2.0 end) |> List.collect()
  let xs = Iter.from([P { x: 1 }, P { x: 2 }]) |> Iter.filter(fn p -> p.x > 1 end) |> List.collect()
  let pairs = Iter.from(["a", "b"]) |> Iter.enumerate() |> List.collect()
  let found = Iter.from(["x", "yy"]) |> Iter.find(fn s -> String.length(s) == 2 end)
  println("#{words} #{floats} #{List.length(xs)} #{pairs} #{found}")
end
"##;
    assert_eq!(
        run(source),
        "[1, 2, 3] [3.0, 5.0] 1 [(0, a), (1, b)] Some(yy)\n"
    );
    for (bad, code) in [
        ("fn main() do\n  let bad = Iter.from([\"a\"]) |> Iter.map(fn x -> x + 1 end) |> List.collect()\n  println(\"#{bad}\")\nend\n", "E0006"),
        ("fn main() do\n  println(\"#{Iter.from([\"x\"]) |> Iter.sum()}\")\nend\n", "E0001"),
        ("fn main() do\n  let r :: List<String> = Iter.from([1, 2]) |> List.collect()\n  println(\"#{r}\")\nend\n", "E0001"),
    ] {
        let err = build_error(bad);
        assert!(err.contains(code), "{bad}\n{err}");
        assert!(!err.contains("E0004"), "no cascade:\n{err}");
    }
}

/// A `for` over an `Iter<T>` binds its elements as `T`: they were typed as
/// the untyped iterator handle's element, a type parameter, so `v + 1.0`
/// failed (E0006) and interpolating one failed in code generation.
#[test]
fn a_for_over_an_iterator_binds_its_element_type() {
    let source = r##"
struct Halves do
  left :: Int
end

impl Iterator for Halves do
  type Item = Float
  fn next(self) -> Float? do
    None
  end
end

fn main() do
  let floats = for v in Iter.from([1.0, 2.0]) do
    v + 1.0
  end
  let lens = for n in Iter.from(["a", "bb"]) |> Iter.map(fn s -> String.length(s) end) do
    n * 10
  end
  let big = for x in Iter.from([1, 2, 3]) |> Iter.filter(fn x -> x > 1 end) do
    "#{x + 1}"
  end
  let pairs = for (i, s) in Iter.from(["x", "y"]) |> Iter.enumerate() do
    "#{i}#{s}"
  end
  let none = for h in Halves { left: 2 } do
    h + 0.5
  end
  for v in Iter.from([0.5]) do
    println("#{v}")
  end
  println("#{floats} #{lens} #{big} #{pairs} #{none}")
end
"##;
    assert_eq!(run(source), "0.5\n[2.0, 3.0] [10, 20] [3, 4] [0x, 1y] []\n");
}

/// An iterator handle's name in an annotation (`-> ListIterator`) is an
/// `Iter` whose element type is inferred: as a type of its own it had no
/// element type, so `Iter.next` printed `Some(())`, `List.collect` the
/// Floats' bits, and a `for` over it could not add to an element.
#[test]
fn an_iterator_handle_name_is_an_iter_of_inferred_elements() {
    let source = r##"
fn floats() -> ListIterator do
  Iter.from([1.0, 2.0])
end

fn pairs() -> MapIterator do
  Iter.from(%{"a" => 1})
end

fn flags() -> SetIterator do
  Iter.from(Set.from_list([true]))
end

fn steps() -> RangeIterator do
  Iter.from(1..3)
end

fn total(it :: ListIterator) -> Int do
  Iter.count(it)
end

struct Evens do
  items :: List<Int>
end

impl Iterable for Evens do
  type Item = Int
  type Iter = ListIterator
  fn iter(self) -> ListIterator do
    Iter.from(self.items)
  end
end

struct Odds do
  items :: List<Int>
end

impl Iterable for Odds do
  type Item = Int
  type Iter = ListIterator
  fn iter(self) -> Self.Iter do
    Iter.from(self.items)
  end
end

fn main() do
  println("#{Iter.next(floats())}")
  println("#{floats() |> List.collect()}")
  let shifted = for v in floats() do
    v + 0.5
  end
  println("#{shifted}")
  println("#{Iter.next(pairs())} #{Iter.next(flags())} #{List.collect(steps())}")
  let words :: ListIterator = Iter.from(["x", "y"])
  println("#{total(words)} #{total(Iter.from([1, 2, 3]))}")
  let evens = Evens { items: [2, 4] }
  let doubled = for x in evens do
    x * 2
  end
  println("#{doubled} #{Iter.next(evens.iter())} #{Iter.next(Odds { items: [3] }.iter())}")
end
"##;
    assert_eq!(
        run(source),
        "Some(1.0)\n[1.0, 2.0]\n[1.5, 2.5]\nSome((a, 1)) Some(true) [1, 2]\n2 3\n[4, 8] Some(2) Some(3)\n"
    );
}

#[test]
fn values_of_a_type_nothing_fixed_compare_equal() {
    let source = "fn main() do\n  println(\"#{None == None} #{Ok(1) == Ok(1)} #{Ok(1) == Ok(2)} #{[None] == [None]}\")\nend\n";
    assert_eq!(run(source), "true true false true\n");
}

// ── Type-checker soundness ─────────────────────────────────────────────

#[test]
fn a_failed_let_does_not_make_its_name_undefined() {
    let diags = json_diagnostics(
        "fn main() do\n  let v = \"a\" <> nope\n  let w :: Int = \"s\"\n  println(v)\n  println(\"#{w}\")\nend\n",
    );
    let codes: Vec<&str> = diags.iter().filter_map(|d| d["code"].as_str()).collect();
    assert_eq!(codes, ["E0004", "E0001"], "{diags:?}");
    // The annotation is what was expected.
    assert_eq!(
        diags[1]["message"],
        "type mismatch: expected `Int`, found `String`"
    );
}

#[test]
fn ill_typed_programs_that_used_to_build_are_rejected() {
    for (source, message) in [
        (
            "fn f(n :: Int) -> Int do\n  if n > 0 do\n    return \"x\"\n  end\n  0\nend\nfn main() do\n  println(\"#{f(1)}\")\nend\n",
            "expected `Int`, found `String`",
        ),
        (
            "fn f(n :: Int) -> Int do\n  if n > 0 do\n    return\n  end\n  0\nend\nfn main() do\n  println(\"#{f(1)}\")\nend\n",
            "expected Int, found ()",
        ),
        (
            "fn f(b :: Bool) -> Int do\n  if b do\n    1\n  end\nend\nfn main() do\n  println(\"#{f(false)}\")\nend\n",
            "expected Int, found ()",
        ),
        (
            "fn double(n :: Int) -> Int = n * 2\nfn main() do\n  case (5, \"hello\") do\n    (a, \"x\") | (5, a) -> println(\"#{double(a)}\")\n    _ -> println(\"y\")\n  end\nend\n",
            "expected `Int`, found `String`",
        ),
        (
            "fn main() do\n  case (1, 2) do\n    (a, a) -> println(\"#{a}\")\n  end\nend\n",
            "`a` is bound twice in one pattern",
        ),
        (
            "fn main() do\n  for x in \"hello\" do\n    println(x)\n  end\nend\n",
            "`String` does not implement `Iterable`",
        ),
        (
            "fn main() do\n  for x in 5 do\n    println(\"#{x}\")\n  end\nend\n",
            "`Int` does not implement `Iterable`",
        ),
    ] {
        let err = build_error(source);
        assert!(err.contains(message), "{source}\n{err}");
    }
}

#[test]
fn returns_are_checked_and_joined_without_a_declared_type() {
    let source = r##"
fn first_even(xs) do
  for x in xs do
    if x % 2 == 0 do
      return x
    end
  end
  -1
end

fn classify(v :: Int?) -> Int do
  case v do
    Some(v) -> v
    None -> 0
  end
end

fn main() do
  let f = fn n -> if n > 0 do
    return "pos"
  else
    "non-pos"
  end end
  println("#{first_even([1, 3, 4, 5])} #{first_even([1])} #{f(1)} #{f(0)} #{classify(Some(3))}")
end
"##;
    assert_eq!(run(source), "4 -1 pos non-pos 3\n");
}

// ── Generics and interfaces ────────────────────────────────────────────

#[test]
fn generic_functions_calling_generic_functions_are_specialized_for_each_use() {
    let source = r##"
fn ident(a) do
  a
end

fn wrap(a) do
  ident(a)
end

fn show(a) do
  "<${a}>"
end

fn relay(a) do
  show(a)
end

fn size(xs) do
  List.length(xs)
end

fn main() do
  println("#{wrap(5)} #{wrap("five")} #{show(7)} #{relay("hello")} #{relay(2.5)}")
  println("#{size([1])} #{size(["a"])} #{size([])}")
end
"##;
    assert_eq!(run(source), "5 five <7> <hello> <2.5>\n1 1 0\n");
}

#[test]
fn methods_of_bounded_type_parameters_have_their_interface_types() {
    let source = r##"
interface Sized do
  fn size(self) -> Int
end

interface Container do
  type Item
  fn first(self) -> Self.Item
end

struct Sq do
  s :: Int
end

struct IntBox do
  value :: Int
end

struct StrBox do
  s :: String
end

impl Sized for Sq do
  fn size(self) -> Int do
    self.s
  end
end

impl Container for IntBox do
  type Item = Int
  fn first(self) -> Int do
    self.value
  end
end

impl Container for StrBox do
  type Item = String
  fn first(self) -> String do
    self.s
  end
end

fn report<T>(x :: T) -> String where T: Sized do
  let n = x.size()
  "${n} ${x.size() + 1}"
end

fn show_first<T>(c :: T) -> String where T: Container do
  let x = c.first()
  "${x}"
end

fn get<T>(c :: T) where T: Container do
  c.first()
end

fn main() do
  let v = get(IntBox { value: 5 })
  println("#{report(Sq { s: 3 })} #{show_first(IntBox { value: 5 })} #{show_first(StrBox { s: "hi" })} #{v + 1}")
end
"##;
    assert_eq!(run(source), "3 4 5 hi 6\n");
    // `T.Item` fixed to Int by the body does not hold for StrBox.
    let err = build_error(&source.replace(
        "fn main() do",
        "fn plus<T>(c :: T) -> Int where T: Container do\n  c.first() + 1\nend\n\nfn main() do\n  println(\"#{plus(StrBox { s: \"x\" })}\")",
    ));
    assert!(err.contains("expected `Int`, found `String`"), "{err}");
}

#[test]
fn method_arguments_and_impl_signatures_are_checked_against_the_interface() {
    let interface = "interface Scale do\n  fn scale(self, k :: Int) -> String\nend\n\nstruct Cat do\n  n :: String\nend\n\n";
    let err = build_error(&format!(
        "{interface}impl Scale for Cat do\n  fn scale(self, k :: Int) -> String do\n    \"${{k}}\"\n  end\nend\n\nfn main() do\n  println(Cat {{ n: \"a\" }}.scale(\"oops\"))\nend\n"
    ));
    assert!(err.contains("expected `Int`, found `String`"), "{err}");
    for (method, found) in [
        (
            "fn scale(self, k :: String) -> String do\n    k\n  end",
            "(Self, String)",
        ),
        ("fn scale(self) -> String do\n    \"x\"\n  end", "(Self)"),
        ("fn scale(k :: Int) -> String do\n    \"x\"\n  end", "(Int)"),
    ] {
        let err = build_error(&format!(
            "{interface}impl Scale for Cat do\n  {method}\nend\n\nfn main() do\n  println(Cat {{ n: \"a\" }}.scale(1))\nend\n"
        ));
        assert!(
            err.contains("E0008") && err.contains(found),
            "{method}\n{err}"
        );
        // Located at the impl method, not the whole file.
        assert!(err.contains(":10:3"), "{method}\n{err}");
    }
    let err = build_error(
        "struct V do\n  x :: Int\nend\n\nimpl Mul for V do\n  type Output = Int\n  fn mul(self, other :: V) -> V do\n    V { x: self.x * other.x }\n  end\nend\n\nfn main() do\n  println(\"#{(V { x: 2 } * V { x: 3 }).x}\")\nend\n",
    );
    assert!(err.contains("expected `Int`, found `V`"), "{err}");
}

// ── Derived traits follow the source types ─────────────────────────────

#[test]
fn generic_struct_instantiations_derive_by_their_type_arguments() {
    // Box<List<Int>> and Box<List<String>> share a layout; their derived
    // helpers must not be shared.
    let source = r##"
struct Box<T> do
  value :: T
end deriving(Eq, Ord, Display, Debug, Hash)

fn main() do
  let a = Box { value: [1, 2] }
  let b = Box { value: ["x", "y"] }
  println("#{a} #{b} #{b.to_string()}")
  println("#{b == Box { value: ["x", "y"] }} #{a == Box { value: [1, 3] }}")
  println("#{a.inspect()} #{b.inspect()}")
  println("#{a < Box { value: [1, 3] }} #{b > Box { value: ["x"] }} #{compare(a, Box { value: [0] })}")
  println("#{b.hash() == Box { value: ["x", "y"] }.hash()} #{Box { value: 1 }.hash() == Box { value: 2 }.hash()}")
end
"##;
    assert_eq!(
        run(source),
        "Box([1, 2]) Box([x, y]) Box([x, y])\ntrue false\nBox { value: [1, 2] } Box { value: [\"x\", \"y\"] }\ntrue true Greater\ntrue false\n"
    );
}

#[test]
fn derived_traits_handle_collection_tuple_option_and_bool_fields() {
    let source = r##"
struct P do
  name :: String
  tags :: List<String>
  ok :: Bool
  pair :: (Int, String)
  opt :: Option<List<Int>>
end deriving(Eq, Ord, Display, Debug, Hash)

type Shape do
  Circle(Float)
  Poly(List<Int>)
  Named(String, Bool)
end deriving(Eq, Ord, Display, Debug, Hash)

type Chain do
  Link(Int, Chain)
  End
end deriving(Eq, Ord, Display, Debug)

fn main() do
  let p = P { name: "n", tags: ["a", "b"], ok: true, pair: (1, "z"), opt: Some([3]) }
  let q = P { name: "n", tags: ["a", "b"], ok: false, pair: (1, "z"), opt: None }
  println("#{p}")
  println(p.inspect())
  println("#{p == q} #{q < p} #{p < q} #{compare(p, p)}")
  println("#{Poly([1, 2])} #{Named("s", true).inspect()} #{Circle(1.5) < Poly([])} #{Poly([1]) < Poly([2])} #{Named("a", false) < Named("a", true)}")
  let c = Link(1, Link(2, End))
  println("#{c.inspect()} #{c < Link(1, Link(3, End))} #{End < c} #{compare(Circle(2.0), Circle(1.0))}")
  let tags = ["a"] ++ ["b"]
  println("#{p.hash() == P { name: "n", tags: tags, ok: true, pair: (1, "z"), opt: Some([3]) }.hash()} #{Poly([1, 2]).hash() == Poly([1] ++ [2]).hash()}")
end
"##;
    assert_eq!(
        run(source),
        "P(n, [a, b], true, (1, z), Some([3]))\n\
         P { name: \"n\", tags: [\"a\", \"b\"], ok: true, pair: (1, \"z\"), opt: Some([3]) }\n\
         false true false Equal\n\
         Poly([1, 2]) Named(\"s\", true) true true true\n\
         Link(1, Link(2, End)) true false Greater\n\
         true true\n"
    );
}

#[test]
fn compare_and_inspect_work_on_any_ordered_or_shown_type() {
    let source = r##"
fn main() do
  println("#{compare(1, 2)} #{compare("b", "a")} #{compare([1], [2])} #{compare((1, 2), (1, 2))}")
  let o = compare("b", "a")
  println("#{o == Greater} #{o.to_string()} #{[1].compare([0])}")
  println("#{["x", "y"].inspect()} #{[(1, "a")].inspect()}")
end
"##;
    assert_eq!(
        run(source),
        "Less Greater Less Equal\ntrue Greater Greater\n[\"x\", \"y\"] [(1, \"a\")]\n"
    );
}

#[test]
fn stdlib_functions_called_as_methods_lower_like_module_calls() {
    // `xs.contains(x)` compares by Eq like `List.contains(xs, x)`, and map
    // methods reach the map functions.
    let source = r##"
struct K do
  a :: Int
  b :: String
end deriving(Eq, Hash)

fn main() do
  let m = %{(1, "a") => 10}
  println("#{m.get((1, "a"))} #{m.has_key((1, "a"))} #{Map.has_key(m, (1, "a"))}")
  let m2 = m.put((1, "a"), 20)
  println("#{m2.size()} #{m2.get((1, "a"))}")
  let xs = [(1, "a")]
  println("#{xs.contains((1, "a"))} #{[K { a: 1, b: "q" }].contains(K { a: 1, b: "q" })}")
  let s = %{"k" => 1}
  println("#{s.get("k")} #{s.has_key("k" <> "")}")
end
"##;
    assert_eq!(run(source), "10 true true\n1 20\ntrue true\n1 true\n");
}

#[test]
fn bools_order_and_negative_zero_hashes_like_zero() {
    let source = r##"
struct S do
  s :: String
  b :: Bool
end deriving(Eq, Ord)

struct F do
  v :: Float
end deriving(Eq, Hash)

fn main() do
  println("#{false < true} #{true <= false} #{compare(true, false)} #{S { s: "a", b: false } < S { s: "a", b: true }}")
  println("#{F { v: 0.0 } == F { v: -0.0 }} #{F { v: 0.0 }.hash() == F { v: -0.0 }.hash()}")
end
"##;
    assert_eq!(run(source), "true false Greater true\ntrue true\n");
}

#[test]
fn inspect_quotes_and_escapes_strings_at_every_level() {
    let source = r##"
struct S do
  s :: String
end deriving(Debug)

fn main() do
  println("a\"b\\c\nd".inspect())
  println(("x", ["y"], Some("z")).inspect())
  println(S { s: "w\t" }.inspect())
  println(%{"k" => "v"}.inspect())
end
"##;
    assert_eq!(
        run(source),
        "\"a\\\"b\\\\c\\nd\"\n(\"x\", [\"y\"], Some(\"z\"))\nS { s: \"w\\t\" }\n%{\"k\" => \"v\"}\n"
    );
}

#[test]
fn qualified_variant_constructors_work_in_expressions() {
    let source = r##"
type Color do
  Red
  Rgb(n :: Int)
end

fn main() do
  let c = Color.Rgb(1)
  case c do
    Red -> println("r")
    Rgb(n) -> println("rgb #{n}")
  end
  println("#{Color.Red == Red} #{Result.Ok(1) == Ok(1)} #{Option.Some(2)}")
end
"##;
    assert_eq!(run(source), "rgb 1\ntrue true Some(2)\n");
}

#[test]
fn derived_json_handles_every_serializable_field_type() {
    let source = r##"
struct A do
  s :: Option<String>
  i :: Option<Int>
  f :: Option<Float>
end deriving(Json)

struct Outer do
  inner :: Inner
  kids :: List<Node>
end deriving(Json)

struct Inner do
  n :: List<List<Int>>
  o :: Option<List<Int>>
  m :: Map<String, List<Int>>
  p :: (Int, String)
end deriving(Json)

struct Node do
  kids :: List<Node>
end deriving(Json)

type T do
  V(xs :: List<Int>)
  W(m :: Map<String, Int>)
end deriving(Json)

struct Box<Item> do
  value :: Item
end deriving(Json)

fn show(r :: Result<A, String>) -> String do
  case r do
    Ok(a) -> Json.encode(a)
    Err(e) -> "err #{e}"
  end
end

fn main() do
  println(show(A.from_json("{\"s\":\"x\",\"i\":7,\"f\":1.5}")))
  println(show(A.from_json("{\"s\":null,\"i\":null,\"f\":null}")))
  println(show(A.from_json("{\"s\":null,\"i\":1.9,\"f\":null}")))
  let inner = Inner { n: [[1, 2], []], o: Some([3]), m: %{"a" => [1]}, p: (1, "z") }
  let enc = Json.encode(Outer { inner: inner, kids: [Node { kids: [] }] })
  println(enc)
  case Outer.from_json(enc) do
    Ok(o) -> println("#{Json.encode(o) == enc} #{Map.get(o.inner.m, "a")}")
    Err(e) -> println("err #{e}")
  end
  println("#{Json.encode(W(%{"a" => 1}))} #{Json.encode(V([10, 20]))}")
  case T.from_json("{\"tag\":\"V\",\"fields\":[[1,2]]}") do
    Ok(v) -> println(Json.encode(v))
    Err(e) -> println("err #{e}")
  end
  let r :: Result<Box<Int>, String> = Box.from_json("{\"value\":2}")
  case r do
    Ok(b) -> println("#{b.value + 1}")
    Err(e) -> println("err #{e}")
  end
  println("#{Json.encode(Box { value: ["x"] })} #{Json.encode(Box { value: %{"a" => 1} })}")
end
"##;
    assert_eq!(
        run(source),
        "{\"s\":\"x\",\"i\":7,\"f\":1.5}\n\
         {\"s\":null,\"i\":null,\"f\":null}\n\
         err $.i: expected Int\n\
         {\"inner\":{\"n\":[[1,2],[]],\"o\":[3],\"m\":{\"a\":[1]},\"p\":[1,\"z\"]},\"kids\":[{\"kids\":[]}]}\n\
         true [1]\n\
         {\"tag\":\"W\",\"fields\":[{\"a\":1}]} {\"tag\":\"V\",\"fields\":[[10,20]]}\n\
         {\"tag\":\"V\",\"fields\":[[1,2]]}\n\
         3\n\
         {\"value\":[\"x\"]} {\"value\":{\"a\":1}}\n"
    );
}

#[test]
fn derive_errors_point_at_the_field_or_the_deriving_clause() {
    let err = build_error(
        "struct X do\n  n :: Int\nend\n\nstruct W do\n  x :: X\nend deriving(Json)\n\nfn main() do\n  println(\"x\")\nend\n",
    );
    assert!(err.contains("E0038") && err.contains(":6:3"), "{err}");
    let err =
        build_error("type T do\n  A\nend deriving(Ord)\n\nfn main() do\n  println(\"x\")\nend\n");
    assert!(err.contains("E0029") && err.contains(":3:5"), "{err}");
}

#[test]
fn values_whose_type_parameter_is_never_fixed_compare_and_order() {
    // `Ok(1)`'s error type is never fixed; it holds no values to tell apart.
    let source = r##"
type Outcome<T> do
  Pending
  Done(T)
end deriving(Eq, Ord)

fn main() do
  let r = Ok(1)
  println("#{r == Ok(1)} #{None == None} #{Pending == Pending} #{Err("x") == Err("x")}")
  println("#{r < Ok(2)} #{compare(None, None)} #{Pending < Pending} #{Err("a") < Err("b")}")
end
"##;
    assert_eq!(run(source), "true true true true\ntrue Equal false true\n");
}

// ── Struct literals, updates, aliases and variants ─────────────────────

#[test]
fn aliases_expand_through_other_aliases() {
    let source = r##"
type Pair<A, B> = (A, B)
type Twin<T> = Pair<T, T>
type Id<T> = T
type Twice<T> = Id<Id<T>>
type Nested<T> = List<Pair<T, T>>

fn main() do
  let n :: Twin<Int> = (1, 2)
  let i :: Twice<Int> = 3
  let l :: Nested<String> = [("a", "b")]
  println("#{n} #{i} #{l}")
end
"##;
    assert_eq!(run(source), "(1, 2) 3 [(a, b)]\n");
}

#[test]
fn struct_literals_through_aliases() {
    let source = r##"
struct Point do
  x :: Int
end

struct Box<T> do
  value :: T
end

type P = Point
type IntBox = Box<Int>

fn main() do
  let q = P { x: 4 }
  let b = IntBox { value: 5 }
  println("#{q.x} #{b.value + 1}")
end
"##;
    assert_eq!(run(source), "4 6\n");
}

#[test]
fn a_struct_literal_must_name_a_struct() {
    // A name no type has is an unknown type; a type that is not a struct is
    // not a struct.
    let err = build_error("fn main() do\n  let q = Nope { x: 4 }\n  println(\"x\")\nend\n");
    assert!(err.contains("E0069") && err.contains(":2:11"), "{err}");
    let err = build_error(
        "type Sh do\n  A\nend\n\nfn main() do\n  let q = Sh { x: 4 }\n  println(\"x\")\nend\n",
    );
    assert!(err.contains("E0059") && err.contains(":6:11"), "{err}");
}

#[test]
fn a_struct_update_needs_a_struct_value() {
    let err = build_error(
        "fn main() do\n  let m = %{\"a\" => 1}\n  let t = %{m | a: 3}\n  println(\"#{t}\")\nend\n",
    );
    assert!(
        err.contains("E0059") && err.contains("`Map<String, Int>` is not a struct"),
        "{err}"
    );
    let err = build_error("fn main() do\n  let t = %{(1, 2) | a: 3}\n  println(\"#{t}\")\nend\n");
    assert!(
        err.contains("E0059") && !err.contains("<struct update>"),
        "{err}"
    );
}

#[test]
fn a_field_is_given_once() {
    let err = build_error(
        "struct S do\n  a :: Int\n  b :: Int\nend\n\nfn main() do\n  let s = S { a: 1, a: 2, b: 3 }\n  println(\"#{s.a}\")\nend\n",
    );
    assert!(err.contains("E0058") && err.contains(":7:21"), "{err}");
    let err = build_error(
        "struct S do\n  a :: Int\nend\n\nfn main() do\n  let s = S { a: 1 }\n  let t = %{s | a: 2, a: 3}\n  println(\"#{t.a}\")\nend\n",
    );
    assert!(err.contains("E0058"), "{err}");
}

#[test]
fn a_function_field_takes_no_value_derives() {
    // No deriving clause: the struct works, but has no Eq to call.
    let source = "struct Op do\n  run :: Fun(Int) -> Int\nend\n\nfn main() do\n  let o = Op { run: fn x -> x * 2 end }\n  println(\"#{o.run(10)}\")\nend\n";
    assert_eq!(run(source), "20\n");
    let err = build_error(&source.replace("#{o.run(10)}", "#{o == o}"));
    assert!(err.contains("does not implement `Eq`"), "{err}");
    // Deriving one explicitly is an error at the field.
    let err = build_error(&source.replace("end\n\nfn main", "end deriving(Eq)\n\nfn main"));
    assert!(err.contains("E0060") && err.contains(":2:3"), "{err}");
}

#[test]
fn a_variant_name_belongs_to_one_type_per_module() {
    let err = build_error(
        "type A do\n  Same(n :: Int)\nend\n\ntype B do\n  Same(s :: String)\nend\n\nfn main() do\n  println(\"x\")\nend\n",
    );
    assert!(err.contains("E0061") && err.contains(":6:3"), "{err}");
    // Only the one error: `Same` stays A's.
    assert_eq!(err.matches("Error:").count(), 1, "{err}");
}

#[test]
fn an_alias_that_refers_to_itself_is_reported() {
    let err = build_error(
        "type A = B\ntype B = A\ntype L<T> = List<L<T>>\n\nfn main() do\n  println(\"x\")\nend\n",
    );
    for alias in ["`A`", "`B`", "`L`"] {
        assert!(
            err.contains(&format!("type alias {alias} refers to itself")),
            "{err}"
        );
    }
}

#[test]
fn methods_are_callable_before_their_impl_and_from_sibling_methods() {
    let source = r##"
struct Dog do
  n :: Int
end

fn main() do
  let d = Dog { n: 1 }
  println("#{d.name()} #{d.label()} #{d.tag()}")
end

interface Named do
  fn name(self) -> Int
  fn label(self) -> Int
  fn tag(self) -> String do
    "t#{self.name()}"
  end
end

impl Named for Dog do
  fn name(self) -> Int do
    self.n
  end
  fn label(self) -> Int do
    self.name() + 1
  end
end
"##;
    assert_eq!(run(source), "1 2 t1\n");
}

#[test]
fn a_for_loop_over_a_map_takes_entries_or_keys() {
    let source = r##"
fn main() do
  let m = %{"a" => 1, "b" => 2}
  let keys = for k in m do
    k
  end
  let entries = for {k, v} in m do
    "#{k}=#{v}"
  end
  let pairs = for (k, v) in m do
    "#{k}:#{v}"
  end
  println("#{keys} #{entries} #{pairs}")
end
"##;
    assert_eq!(run(source), "[a, b] [a=1, b=2] [a:1, b:2]\n");
}

/// A method's receiver is borrowed from its caller in every call form:
/// `s.close()` nulled the caller's `s` (its fields then read 0, and nothing
/// destroyed it), and `close(s)` moved `s` into a method that never dropped
/// it, so using `s` after it was refused.
#[test]
fn a_resource_method_leaves_its_receiver_with_the_caller() {
    let source = r##"
resource struct Session do
  id :: Int
end

interface Closer do
  fn close(self) -> Int
end

impl Closer for Session do
  fn close(self) -> Int do
    self.id
  end
end

fn use_it(s :: Session) -> Int do
  let a = close(s)
  let b = s.close()
  let c = Closer.close(s)
  println("#{a} #{b} #{c} #{s.id}")
  a + b + c + s.id
end

fn main() do
  println("#{use_it(Session { id: 7 })}")
end
"##;
    assert_eq!(run(source), "7 7 7 7\n28\n");
}

#[test]
fn let_bound_closures_with_operators_work_at_each_type() {
    let source = r##"
fn main() do
  let dbl = fn x -> x * x end
  let add = fn a, b -> a + b end
  let eq = fn a, b -> a == b end
  let lt = fn a, b -> a < b end
  println("#{dbl(3)} #{dbl(1.5)} #{add(1, 2)} #{eq(1, 1)} #{lt(1, 2)} #{lt("b", "a")}")
  println("#{List.map([1, 2], dbl)}")
end
"##;
    assert_eq!(run(source), "9 2.25 3 true true false\n[1, 4]\n");
}

#[test]
fn an_operator_on_a_type_parameter_needs_its_bound() {
    let err = build_error(
        "fn less<T>(a :: T, b :: T) -> Bool do\n  a < b\nend\n\nfn main() do\n  println(\"#{less(1, 2)}\")\nend\n",
    );
    assert!(
        err.contains("E0063") && err.contains("where T: Ord") && err.contains(":2:3"),
        "{err}"
    );
    // With the bound (Ord includes Eq) it builds.
    let source = "fn less<T>(a :: T, b :: T) -> Bool where T: Ord do\n  a < b or a == b\nend\n\nfn main() do\n  println(\"#{less(1, 2)}\")\nend\n";
    assert_eq!(run(source), "true\n");
}

#[test]
fn default_needs_a_known_type_with_a_default() {
    let err = build_error("fn main() do\n  let x = default()\n  println(\"#{x}\")\nend\n");
    assert!(err.contains("E0064") && err.contains(":2:11"), "{err}");
    let err = build_error(
        "struct NoDef do\n  n :: Int\nend\n\nfn main() do\n  let x :: NoDef = default()\n  println(\"#{x.n}\")\nend\n",
    );
    assert!(
        err.contains("`NoDef` does not implement `Default`"),
        "{err}"
    );
    let source = r##"
struct Cfg do
  n :: Int
end

impl Default for Cfg do
  fn default() -> Cfg do
    Cfg { n: 7 }
  end
end

fn make<T>() -> T where T: Default do
  default()
end

fn main() do
  let a :: Int = default()
  let c :: Cfg = default()
  let d :: Cfg = make()
  println("#{a} #{c.n} #{d.n}")
end
"##;
    assert_eq!(run(source), "0 7 7\n");
}

#[test]
fn impls_of_generic_interfaces_are_called_by_their_result_type() {
    // The reference's example: one impl, with a default method.
    let source = r##"
pub interface Container<T> do
  type Item
  fn first(self) -> Self.Item
  fn label(self) -> String do
    "container"
  end
end

struct IntBox do
  value :: Int
end

impl Container<Int> for IntBox do
  type Item = Int
  fn first(self) -> Int do
    self.value
  end
end

fn main() do
  let b = IntBox { value: 3 }
  println("#{b.first()} #{b.label()}")
end
"##;
    assert_eq!(run(source), "3 container\n");
    // Two impls of one generic interface: the annotation picks.
    let source = r##"
interface Convert<T> do
  fn convert(self) -> T
end

struct Meters do
  v :: Int
end

impl Convert<String> for Meters do
  fn convert(self) -> String do
    "#{self.v}m"
  end
end

impl Convert<Int> for Meters do
  fn convert(self) -> Int do
    self.v * 100
  end
end

fn main() do
  let s :: String = Meters { v: 3 }.convert()
  let c :: Int = Meters { v: 3 }.convert()
  println("#{s} #{c}")
end
"##;
    assert_eq!(run(source), "3m 300\n");
}

/// `Type.from(value)` goes to the `From` impl for the value's type, however
/// many the type has: with `From<Int>` and `From<String>`, a `String`
/// argument was refused ("expected Int, found String"), and lowering took
/// whichever impl a hash map listed first.
#[test]
fn from_goes_to_the_impl_for_its_arguments_type() {
    let source = r##"
struct Wrapper do
  value :: Int
end

impl From<Int> for Wrapper do
  fn from(n :: Int) -> Wrapper do
    Wrapper { value: n * 2 }
  end
end

impl From<String> for Wrapper do
  fn from(s :: String) -> Wrapper do
    Wrapper { value: String.length(s) }
  end
end

fn main() do
  let a = Wrapper.from(21)
  let b = Wrapper.from("abc")
  let c = "hello" |> Wrapper.from()
  let d = 4 |> Wrapper.from
  println("#{a.value} #{b.value} #{c.value} #{d.value}")
end
"##;
    assert_eq!(run(source), "42 3 5 8\n");
    let err = build_error(&source.replace("Wrapper.from(21)", "Wrapper.from(true)"));
    assert!(
        err.contains("E0065") && err.contains("no impl's `from` for `Wrapper` takes `Bool`"),
        "{err}"
    );
}

/// A `From` impl is chosen and named by its whole argument type: only the
/// names in it were read, so `From<(Int, Int)>` was `From<Int, Int>`,
/// `From<List<Int>>` was `From<List>`, and `Bag.from((4, 5))` called the
/// `List` impl. The same goes for `.into()` and a `?` converting its error.
#[test]
fn from_is_chosen_by_its_whole_argument_type() {
    let source = r##"
struct Bag do
  n :: Int
end

impl From<(Int, Int)> for Bag do
  fn from(p :: (Int, Int)) -> Bag do
    let (a, b) = p
    Bag { n: a + b }
  end
end

impl From<List<Int>> for Bag do
  fn from(xs :: List<Int>) -> Bag do
    Bag { n: List.length(xs) }
  end
end

impl From<List<String>> for Bag do
  fn from(xs :: List<String>) -> Bag do
    Bag { n: 100 + List.length(xs) }
  end
end

impl From<Fun(Int) -> Int> for Bag do
  fn from(f :: Fun(Int) -> Int) -> Bag do
    Bag { n: f(20) }
  end
end

fn check(n :: Int) -> Result<Int, (Int, Int)> do
  if n > 0 do
    Ok(n)
  else
    Err((n, 7))
  end
end

fn doubled(n :: Int) -> Result<Int, Bag> do
  let v = check(n)?
  Ok(v * 2)
end

fn main() do
  let a = Bag.from((4, 5))
  let b = Bag.from([1, 2])
  let c = Bag.from(["x"])
  let d = Bag.from(fn x -> x + 1 end)
  let e :: Bag = (1, 2).into()
  let f :: Bag = [7, 8, 9].into()
  println("#{a.n} #{b.n} #{c.n} #{d.n} #{e.n} #{f.n}")
  case doubled(-3) do
    Ok(v) -> println("ok #{v}")
    Err(bag) -> println("err #{bag.n}")
  end
end
"##;
    assert_eq!(run(source), "9 2 101 21 3 3\nerr 4\n");
}

#[test]
fn into_and_try_into_go_to_the_from_impl_the_context_asks_for() {
    let source = r##"
struct Wrapper do
  value :: Int
end

impl From<Int> for Wrapper do
  fn from(n :: Int) -> Wrapper do
    Wrapper { value: n * 2 }
  end
end

impl From<String> for Wrapper do
  fn from(s :: String) -> Wrapper do
    Wrapper { value: String.length(s) }
  end
end

struct Meters do
  v :: Int
end

struct Feet do
  v :: Int
end

impl From<Meters> for Feet do
  fn from(m :: Meters) -> Feet do
    Feet { v: m.v * 3 }
  end
end

fn main() do
  let w :: Wrapper = 21.into()
  let f :: Float = 2.into()
  let s :: String = 7.into()
  let w4 :: Wrapper = "abc".into()
  let ft :: Feet = Meters { v: 2 }.into()
  println("#{w.value} #{f} #{s} #{w4.value} #{ft.v}")
end
"##;
    assert_eq!(run(source), "42 2.0 7 3 6\n");
    let source = r##"
struct Pos do
  v :: Int
end

struct Even do
  v :: Int
end

impl TryFrom<Int> for Pos do
  fn try_from(n :: Int) -> Result<Pos, String> do
    if n > 0 do
      Ok(Pos { v: n })
    else
      Err("not positive")
    end
  end
end

impl TryFrom<Int> for Even do
  fn try_from(n :: Int) -> Result<Even, String> do
    if n % 2 == 0 do
      Ok(Even { v: n })
    else
      Err("odd")
    end
  end
end

fn main() do
  let p :: Result<Pos, String> = 3.try_into()
  let e :: Result<Even, String> = 3.try_into()
  let q :: Result<Pos, String> = Pos.try_from(-1)
  case p do
    Ok(x) -> println("pos #{x.v}")
    Err(m) -> println(m)
  end
  case e do
    Ok(x) -> println("even #{x.v}")
    Err(m) -> println(m)
  end
  case q do
    Ok(x) -> println("pos #{x.v}")
    Err(m) -> println(m)
  end
end
"##;
    assert_eq!(run(source), "pos 3\nodd\nnot positive\n");
    let err = build_error("fn main() do\n  let x = 5.into()\n  println(\"#{x}\")\nend\n");
    assert!(err.contains("E0065") && err.contains(":2:11"), "{err}");
}

#[test]
fn interface_methods_are_called_by_argument_type_or_by_interface() {
    // `A.hello(x)` names the interface; a bare `hello(dog)` dispatches by
    // its argument like `dog.hello()`.
    let source = r##"
interface A do
  fn hello(self) -> String
end

interface B do
  fn hello(self) -> String
end

struct Cat do
  n :: Int
end

struct Dog do
  n :: Int
end

impl A for Cat do
  fn hello(self) -> String do
    "A"
  end
end

impl B for Cat do
  fn hello(self) -> String do
    "B"
  end
end

impl A for Dog do
  fn hello(self) -> String do
    "dog"
  end
end

fn main() do
  println(A.hello(Cat { n: 1 }))
  println(B.hello(Cat { n: 1 }))
  println(hello(Dog { n: 5 }))
  println(Dog { n: 5 }.hello())
end
"##;
    assert_eq!(run(source), "A\nB\ndog\ndog\n");
    // Two interfaces giving Cat a `hello`: a bare call is ambiguous.
    let err = build_error(&source.replace("A.hello(Cat", "hello(Cat"));
    assert!(
        err.contains("E0027") && err.contains("A.hello(value)"),
        "{err}"
    );
}

/// An instance method named on its type takes the value first, as one named
/// on its interface does, and a pipe can go into either: `Dog.hello(d)`
/// said "expected 1 argument(s), found 2", and `d |> A.hello()` failed in
/// code generation on the interface's name as a variable.
#[test]
fn methods_are_called_through_their_type_and_piped_into_qualified_names() {
    let source = r##"
interface A do
  fn hello(self, n :: Int) -> String
end

interface B do
  fn hello(self, n :: Int) -> String
end

struct Cat do
  n :: Int
end

struct Dog do
  n :: Int
end

impl A for Cat do
  fn hello(self, n :: Int) -> String do
    "A#{self.n + n}"
  end
end

impl B for Cat do
  fn hello(self, n :: Int) -> String do
    "B#{self.n + n}"
  end
end

impl A for Dog do
  fn hello(self, n :: Int) -> String do
    "dog#{self.n + n}"
  end
end

fn main() do
  let cat = Cat { n: 1 }
  let dog = Dog { n: 5 }
  println(Dog.hello(dog, 1))
  println(dog |> Dog.hello(2))
  println(3 |2> Dog.hello(dog))
  println(cat |> A.hello(1))
  println(cat |> B.hello(2))
end
"##;
    assert_eq!(run(source), "dog6\ndog7\ndog8\nA2\nB3\n");
    // Two interfaces give Cat a `hello`: naming the type picks neither.
    let err =
        build_error(&source.replace("println(Dog.hello(dog, 1))", "println(Cat.hello(cat, 1))"));
    assert!(err.contains("E0027"), "{err}");
    let err = build_error(&source.replace("println(Dog.hello(dog, 1))", "println(Dog)"));
    assert!(
        err.contains("E0083") && err.contains("`Dog` is a type, not a value"),
        "{err}"
    );
}

/// A self tail call passes its arguments to the function's parameters even
/// when a `let` shadows one: it stored them into the shadowing variable, so
/// the loop read the parameter unchanged and `count(5, 0)` was 0.
#[test]
fn a_tail_call_sets_parameters_a_let_shadows() {
    let source = r##"
fn count(n :: Int, acc :: Int) -> Int do
  if n == 0 do
    acc
  else
    let acc = acc + 1
    count(n - 1, acc)
  end
end

fn main() do
  println("#{count(5, 0)}")
end
"##;
    assert_eq!(run(source), "5\n");
}

#[test]
fn static_interface_methods_are_called_on_types_and_type_parameters() {
    let source = r##"
interface Versioned do
  fn version() -> Int
end

struct A do
  n :: Int
end

struct B do
  n :: Int
end

impl Versioned for A do
  fn version() -> Int do
    1
  end
end

impl Versioned for B do
  fn version() -> Int do
    2
  end
end

fn ver_of<T>(x :: T) -> Int where T: Versioned do
  T.version()
end

fn main() do
  println("#{A.version()} #{B.version()} #{ver_of(A { n: 0 })} #{ver_of(B { n: 0 })}")
end
"##;
    assert_eq!(run(source), "1 2 1 2\n");
    // A stdlib module name as the type: the impl's method, not a module function.
    let source = r##"
interface Named do
  fn tag() -> String
end

impl Named for Int do
  fn tag() -> String do
    "int"
  end
end

fn main() do
  println(Int.tag())
end
"##;
    assert_eq!(run(source), "int\n");
    // Bare: fine with one impl, ambiguous with several.
    let source = r##"
interface Versioned do
  fn version() -> Int
end

struct A do
  n :: Int
end

impl Versioned for A do
  fn version() -> Int do
    1
  end
end

fn main() do
  println("#{version()}")
end
"##;
    assert_eq!(run(source), "1\n");
    let err = build_error(&open_s02());
    assert!(
        err.contains("E0066") && err.contains("A.version()"),
        "{err}"
    );
}

fn open_s02() -> String {
    r##"
interface Versioned do
  fn version() -> Int
end

struct A do
  n :: Int
end

struct B do
  n :: Int
end

impl Versioned for A do
  fn version() -> Int do
    1
  end
end

impl Versioned for B do
  fn version() -> Int do
    2
  end
end

fn ver_of<T>(x :: T) -> Int where T: Versioned do
  T.version()
end

fn main() do
  println("#{version()}")
end
"##
    .to_string()
}

#[test]
fn non_ascii_text_does_not_move_later_diagnostics() {
    // Spans are byte offsets; ariadne counted them as characters, so every
    // multi-byte character before an error moved it further right.
    let source = "# コメント コメント コメント\nfn main() do\n  let n = 1 + \"x\"\n  println(\"#{n}\")\nend\n";
    let err = build_error(source);
    assert!(err.contains("main.mpl:3:11"), "{err}");
}

fn mismatches(source: &str) -> Vec<(String, usize)> {
    json_diagnostics(source)
        .iter()
        .filter(|d| d["code"] == "E0001")
        .map(|d| {
            (
                d["spans"][0]["label"].as_str().unwrap_or("").to_string(),
                d["spans"][0]["start"].as_u64().unwrap_or(0) as usize,
            )
        })
        .collect()
}

#[test]
fn mismatches_name_the_expected_type_first_at_the_offending_expression() {
    let source = r##"
fn g() -> Int do
  "str"
end

fn check(f :: Fun(Int) -> Bool) -> Bool do
  f(1)
end

fn main() do
  while 1 do
    println("loop")
  end
  println("#{check(fn (x :: Int) -> x + 1 end)}")
end
"##;
    let found = mismatches(source);
    assert_eq!(
        found,
        [
            (
                "expected Int, found String".to_string(),
                source.find("\"str\"").unwrap()
            ),
            (
                "expected Bool, found Int".to_string(),
                source.find("while 1").unwrap() + 6
            ),
            (
                "expected Bool, found Int".to_string(),
                source.find("x + 1").unwrap()
            ),
        ]
    );
    let err = build_error("fn main() do\n  let y :: String = 5\nend\n");
    assert!(err.contains("expected `String`, found `Int`"), "{err}");
}

#[test]
fn a_failed_tail_expression_is_reported_once() {
    // The body's type is unknown after its tail fails; it used to become
    // `()` and add "expected Int, found ()" over the whole file.
    let source = "fn g() -> Int do\n  1 + \"y\"\nend\n\nfn main() do\n  println(\"x\")\nend\n";
    let found = mismatches(source);
    assert_eq!(found.len(), 1, "{found:?}");
    assert_eq!(found[0].1, source.find("1 + ").unwrap());
}

#[test]
fn an_operator_on_a_type_without_it_names_the_left_operand() {
    // It said "expected Option<Int>, found Int", blaming the `1`.
    let err =
        build_error("fn main() do\n  let v :: Int? = Some(3)\n  println(\"#{v + 1}\")\nend\n");
    assert!(
        err.contains("`Option<Int>` does not implement `Add`"),
        "{err}"
    );
}

#[test]
fn question_mark_needs_a_function_that_can_return_its_error() {
    // `main` returns `()`: an `Err` cannot leave it (this failed the LLVM
    // verifier before).
    let helper = "fn helper(n :: Int) -> Int!String do\n  if n > 0 do\n    Ok(n)\n  else\n    Err(\"neg\")\n  end\nend\n\n";
    let err = build_error(&format!(
        "{helper}fn main() do\n  let v = helper(1)?\n  println(\"#{{v}}\")\nend\n"
    ));
    assert!(err.contains("E0036"), "{err}");
    // A function without a declared return type returns the `Err` early,
    // so its other results must be Results too.
    let source = format!(
        "{helper}fn go(n :: Int) do\n  let v = helper(n)?\n  v + 1\nend\n\nfn main() do\n  println(\"#{{go(1)}}\")\nend\n"
    );
    let diags = json_diagnostics(&source);
    let try_err = diags.iter().find(|d| d["code"] == "E0036").expect("E0036");
    assert!(try_err["fix"]
        .as_str()
        .unwrap()
        .contains("handle the operand with `case`"));
    assert_eq!(try_err["notes"], serde_json::json!([]));
    assert_eq!(
        try_err["spans"][0]["start"].as_u64().unwrap() as usize,
        source.find("helper(n)?").unwrap()
    );
}

#[test]
fn question_mark_in_unannotated_functions_and_closures_returns_early() {
    let source = r##"
fn helper(n :: Int) -> Int!String do
  if n > 0 do
    Ok(n)
  else
    Err("neg")
  end
end

fn double(n :: Int) do
  let v = helper(n)?
  Ok(v * 2)
end

fn main() do
  let triple = fn (n :: Int) do
    let v = helper(n)?
    Ok(v * 3)
  end
  case double(3) do
    Ok(v) -> println("ok #{v}")
    Err(e) -> println("err #{e}")
  end
  case triple(-1) do
    Ok(v) -> println("ok #{v}")
    Err(e) -> println("err #{e}")
  end
end
"##;
    assert_eq!(run(source), "ok 6\nerr neg\n");
}

#[test]
fn a_conflicting_early_return_is_reported_where_it_is() {
    let source = "fn pick(n :: Int) do\n  if n > 0 do\n    return \"pos\"\n  end\n  n\nend\n\nfn main() do\n  println(\"#{pick(1)}\")\nend\n";
    let diags = json_diagnostics(source);
    let mismatch = diags.iter().find(|d| d["code"] == "E0001").expect("E0001");
    assert_eq!(
        mismatch["spans"][0]["start"].as_u64().unwrap() as usize,
        source.find("return").unwrap()
    );
}

#[test]
fn bare_method_call_on_a_bounded_type_parameter_works_for_every_impl() {
    // `show_me(x)` fixed `T` to the first type with an impl (Int), so
    // `show(P { .. })` was rejected.
    let source = r##"
interface Printable do
  fn show_me(self) -> String
end

impl Printable for Int do
  fn show_me(self) -> String do
    "int"
  end
end

struct P do
  n :: Int
end

impl Printable for P do
  fn show_me(self) -> String do
    "p #{self.n}"
  end
end

fn show<T>(x :: T) -> String where T: Printable do
  show_me(x)
end

fn main() do
  println(show(1))
  println(show(P { n: 2 }))
end
"##;
    assert_eq!(run(source), "int\np 2\n");
}

#[test]
fn a_generic_function_must_keep_its_type_parameters_generic() {
    let err =
        build_error("fn bad<T>(x :: T) -> T do\n  5\nend\n\nfn main() do\n  println(\"x\")\nend\n");
    assert!(
        err.contains("E0067")
            && err.contains(
                "type parameter `T` stands for any type, but this function makes it `Int`"
            ),
        "{err}"
    );
    let err = build_error(
        "fn pair<A, B>(a :: A, b :: B) -> A do\n  b\nend\n\nfn main() do\n  println(\"x\")\nend\n",
    );
    assert!(
        err.contains("makes it `B`") || err.contains("makes it `A`"),
        "{err}"
    );
    // A parameter against a type built from it is a plain mismatch, named
    // by the parameter, not an "infinite type".
    let err = build_error(
        "fn first<T>(xs :: List<T>) -> Option<T> do\n  List.head(xs)\nend\n\nfn unwrap<T>(xs :: List<T>) -> T do\n  xs\nend\n\nfn main() do\n  println(\"x\")\nend\n",
    );
    assert!(err.contains("expected `Option<T>`, found `T`"), "{err}");
    assert!(err.contains("expected `T`, found `List<T>`"), "{err}");
    assert!(!err.contains("infinite type"), "{err}");
}

#[test]
fn duplicate_definitions_are_rejected() {
    let source = r##"
struct A do
  x :: Int
  x :: String
end

type C do
  R
  R
end

struct A do
  y :: Int
end

fn f(x :: Int, x :: String) -> String do
  x
end

fn main() do
  println(f(1, "dup"))
end
"##;
    let diags = json_diagnostics(source);
    let mut dups: Vec<(&str, usize)> = diags
        .iter()
        .filter(|d| d["code"] == "E0068")
        .map(|d| {
            (
                d["message"].as_str().unwrap(),
                d["spans"][0]["start"].as_u64().unwrap() as usize,
            )
        })
        .collect();
    dups.sort_by_key(|(_, start)| *start);
    assert_eq!(
        dups,
        [
            (
                "field `x` is defined twice",
                source.find("x :: String").unwrap()
            ),
            (
                "variant `R` is defined twice",
                source.rfind("  R\n").unwrap() + 2
            ),
            ("type `A` is defined twice", source.rfind("A do").unwrap()),
            (
                "parameter `x` is defined twice",
                source.find("x :: String)").unwrap()
            ),
        ]
    );
}

#[test]
fn annotations_that_start_with_a_type_parameter_keep_the_rest() {
    // `-> (A, B)` was read as `-> A` and `:: T?` as `:: T`.
    let source = r##"
fn pair<A, B>(a :: A, b :: B) -> (A, B) do
  (a, b)
end

fn maybe<T>(x :: T, keep :: Bool) -> T? do
  if keep do
    Some(x)
  else
    None
  end
end

fn unwrap_or<T>(x :: T?, d :: T) -> T do
  case x do
    Some(v) -> v
    None -> d
  end
end

fn swap<A, B>(p :: (A, B)) -> (B, A) do
  let (a, b) = p
  (b, a)
end

fn main() do
  let (a, b) = pair(1, "two")
  println("#{a} #{b}")
  println("#{unwrap_or(maybe(5, true), 0)} #{unwrap_or(maybe(5, false), 0)}")
  let (c, d) = swap((1, "x"))
  println("#{c} #{d}")
end
"##;
    assert_eq!(run(source), "1 two\n5 0\nx 1\n");
}

#[test]
fn tuple_types_take_option_and_result_sugar() {
    let source = r##"
fn h(x :: Int) -> (Int, String)? do
  if x > 0 do
    Some((x, "a"))
  else
    None
  end
end

fn k(x :: (Int, Int)!String) -> Int do
  case x do
    Ok((a, b)) -> a + b
    Err(_) -> 0
  end
end

fn main() do
  case h(1) do
    Some((a, b)) -> println("#{a} #{b}")
    None -> println("none")
  end
  println("#{k(Ok((1, 2)))} #{k(Err("e"))}")
end
"##;
    assert_eq!(run(source), "1 a\n3 0\n");
}

#[test]
fn unknown_type_names_are_rejected_where_they_are_written() {
    let source = r##"
fn f(x :: Strng) -> Int do
  1
end

struct S do
  field :: Nonexistent
end

type Shape do
  Circle(Flot)
  Box(w :: Int, h :: Integer)
end

fn g(xs :: List<Foo>, cb :: Fun(Intt) -> Bool) -> (Int, Strin)? do
  None
end

fn main() do
  let c = fn (q :: Quux) -> 1 end
  println("x")
end
"##;
    let diags = json_diagnostics(source);
    let unknown: Vec<(&str, usize)> = diags
        .iter()
        .filter(|d| d["code"] == "E0069")
        .map(|d| {
            (
                d["message"].as_str().unwrap(),
                d["spans"][0]["start"].as_u64().unwrap() as usize,
            )
        })
        .collect();
    let at = |name: &str| source.find(name).unwrap();
    assert_eq!(
        unknown,
        [
            ("unknown type `Strng`", at("Strng")),
            ("unknown type `Nonexistent`", at("Nonexistent")),
            ("unknown type `Flot`", at("Flot")),
            ("unknown type `Integer`", at("Integer")),
            ("unknown type `Foo`", at("Foo")),
            ("unknown type `Intt`", at("Intt")),
            ("unknown type `Strin`", at("Strin")),
            ("unknown type `Quux`", at("Quux")),
        ]
    );
}

#[test]
fn known_type_names_in_annotations_are_accepted() {
    let source = r##"
type Pair<A, B> = (A, B)
type Id = Int

struct Box<T> do
  value :: T
  items :: List<T>
end

type Tree<T> do
  Leaf
  Node(Tree<T>, T, Tree<T>)
end

interface Container<T> do
  type Item
  fn first(self) -> Self.Item
  fn wrap(self, x :: T) -> Self
end

fn swap<A, B>(p :: Pair<A, B>) -> Pair<B, A> do
  let (a, b) = p
  (b, a)
end

fn apply(f :: Fun(Int) -> Int, x :: Id) -> Int do
  f(x)
end

fn main() do
  let b :: Box<Int> = Box { value: 1, items: [2] }
  let t :: Tree<Int> = Leaf
  let m :: Map<String, Set<Int>> = Map.new()
  let o :: Option<Json>? = None
  let p :: Pid<Int>? = None
  let r :: Result<Bytes, CryptoError>? = None
  println("#{apply(fn (n :: Int) -> n + 1 end, 2)} #{b.value}")
  let (x, y) = swap((1, "a"))
  println("#{x} #{y}")
end
"##;
    assert_eq!(run(source), "3 1\na 1\n");
}

#[test]
fn a_value_from_a_function_defined_later_has_one_type() {
    // The function's type was still a placeholder when the `let` was
    // checked, and the `let` generalized it: `r` was accepted both as an
    // Int and as a String.
    for later in [
        "fn make(n) do\n  n * 2\nend\n",
        "fn make(0) = 1\nfn make(n) = n * make(n - 1)\n",
    ] {
        let source = format!(
            "fn main() do\n  let r = make(5)\n  let a :: Int = r\n  let b :: String = r\n  println(\"#{{a}} #{{b}}\")\nend\n\n{later}"
        );
        let err = build_error(&source);
        assert!(
            err.contains("expected `String`, found `Int`"),
            "{source}\n{err}"
        );
    }
    let source = "fn main() do\n  let r = make(5)\n  println(\"#{r + 1} #{fact(5)}\")\nend\n\nfn make(n) do\n  n * 2\nend\n\nfn fact(0) = 1\nfn fact(n) = n * fact(n - 1)\n";
    assert_eq!(run(source), "11 120\n");
}

#[test]
fn a_call_before_an_annotated_definition_has_its_declared_types() {
    // The call saw only a placeholder, which `?` took for a Result.
    let source = r##"
fn first() -> Int? do
  let v = maybe_later(3)?
  Some(v + 1)
end

fn maybe_later(n :: Int) -> Int? do
  Some(n)
end

fn main() do
  println("#{first()}")
end
"##;
    assert_eq!(run(source), "Some(4)\n");
}

#[test]
fn fields_of_values_typed_later_in_the_function() {
    // A closure's parameter is typed by the call after it, and a value by
    // a function defined later: codegen saw `Unit` ("Field access on
    // non-struct type").
    let source = r##"
struct A do
  x :: Int
  tags :: List<String>
end

fn from_later() -> Int!String do
  let a = later(4)?
  Ok(a.x + List.length(a.tags))
end

fn later(n) do
  Ok(A { x: n, tags: ["t"] })
end

fn main() do
  let f = fn p -> p.x end
  let a = A { x: 5, tags: ["t"] }
  let g = fn p -> List.length(p.tags) + p.x end
  println("#{f(a)} #{g(a)} #{List.map([a], fn p -> p.x * 2 end)}")
  case from_later() do
    Ok(n) -> println("#{n}")
    Err(e) -> println(e)
  end
end
"##;
    assert_eq!(run(source), "5 6 [10]\n5\n");
    // Nothing fixes the type of `p`: its layout is unknown.
    let err = build_error("fn get_x(p) do\n  p.x\nend\n\nfn main() do\n  println(\"x\")\nend\n");
    assert!(
        err.contains("E0070") && err.contains("cannot tell which type has the field `x`"),
        "{err}"
    );
}

#[test]
fn trailing_closures_are_the_last_argument() {
    // The docs' `with_value(10) do |value| ... end` was "expected 2
    // argument(s), found 1": the closure was parsed and then ignored.
    let source = r##"
fn with_value(value :: Int, block :: Fun(Int) -> Int) -> Int do
  block(value)
end

fn twice(block :: Fun() -> Int) -> Int do
  block() + block()
end

fn main() do
  let result = with_value(10) do |value|
    value * 2
  end
  let base = 5
  let total = twice() do
    base + 1
  end
  let lengths = List.map(["a", "bb"]) do |w|
    String.length(w)
  end
  let piped = 3 |> with_value() do |n|
    n * 10
  end
  println("#{result} #{total} #{lengths} #{piped}")
end
"##;
    assert_eq!(run(source), "20 12 [1, 2] 30\n");
    // A closure passed both ways is one argument too many; the trailing
    // one was dropped without a word.
    let err = build_error(
        "fn with_value(value :: Int, block :: Fun(Int) -> Int) -> Int do\n  block(value)\nend\n\nfn main() do\n  let r = with_value(10, fn x -> x + 1 end) do |v|\n    v\n  end\n  println(\"#{r}\")\nend\n",
    );
    assert!(err.contains("expected 2 arguments, found 3"), "{err}");
}

#[test]
fn items_can_be_used_before_their_declaration() {
    // A generic function called before its definition was pinned to its
    // first use ("expected Int, found String" at the second), and an actor
    // or service used above its declaration was an undefined variable.
    let source = r##"
fn main() do
  println("#{List.length(twice(1))} #{List.length(twice("a"))}")
  let p = spawn(echo)
  send(p, 1)
  let c = Counter.start(0)
  Counter.inc(c)
  println("#{Counter.get(c)} #{area(Sq(3))}")
  Timer.sleep(50)
end

fn twice(x) do
  [x, x]
end

fn area(s :: Shape) -> Int do
  case s do
    Sq(n) -> n * n
  end
end

type Shape do
  Sq(Int)
end

actor echo() do
  receive do
    m -> println("echo #{m}")
  end
end

service Counter do
  fn init(n :: Int) -> Int do
    n
  end

  call Get() :: Int do |s|
    (s, s)
  end

  cast Inc() do |s|
    s + 1
  end
end
"##;
    let output = run(source);
    assert!(output.starts_with("2 2\n"), "{output}");
    assert!(
        output.contains("echo 1\n") && output.contains("1 9\n"),
        "{output}"
    );
}

#[test]
fn a_let_naming_a_generic_function_is_generic() {
    // `let id = ident` used at two types compiled one copy of `ident` for
    // both, and the LLVM verifier rejected the call.
    let source = r##"
fn ident(x) do
  x
end

fn pair(a, b) do
  (a, b)
end

fn main() do
  let id = ident
  let again = id
  println("#{id(1)} #{id("two")} #{again(3.5)}")
  let p = pair
  let (a, b) = p(1, "x")
  let (c, d) = p("y", 2)
  println("#{a} #{b} #{c} #{d}")
end
"##;
    assert_eq!(run(source), "1 two 3.5\n1 x y 2\n");
}

#[test]
fn an_impl_must_name_an_existing_interface_and_type() {
    // Both impls were accepted; the first one's methods even worked.
    let source = r##"
struct C do
  n :: Int
end

impl Dispaly for C do
  fn to_string(self) -> String do
    "c"
  end
end

impl Display for Nope do
  fn to_string(self) -> String do
    "x"
  end
end

fn main() do
  println("x")
end
"##;
    let err = build_error(source);
    assert!(
        err.contains("[E0071] Error: unknown interface `Dispaly`"),
        "{err}"
    );
    assert!(err.contains("[E0069] Error: unknown type `Nope`"), "{err}");
}

#[test]
fn a_pipe_can_feed_send() {
    // `5 |2> send(p)` was "expected (), found (Int) -> ?14" over the whole
    // file: `send` is not a function value.
    let source = r##"
actor sink() do
  receive do
    m -> println("got #{m}")
  end
  sink()
end

fn main() do
  let p = spawn(sink)
  5 |2> send(p)
  p |> send(6)
  Timer.sleep(100)
end
"##;
    assert_eq!(run(source), "got 5\ngot 6\n");
}

#[test]
fn numeric_literals_are_checked() {
    // Each of these compiled to 0; the smallest Int could not be written.
    let source = r##"
fn main() do
  println("#{-9223372036854775808}")
  let r = case -9223372036854775808 do
    -9223372036854775808 -> "INT_MIN"
    _ -> "other"
  end
  println("#{r} #{0x7fffffffffffffff} #{1_000} #{0b101} #{0o17} #{1.5e3}")
end
"##;
    assert_eq!(
        run(source),
        "-9223372036854775808\nINT_MIN 9223372036854775807 1000 5 15 1500.0\n"
    );
    let bad = "fn main() do\n  let a = 1e\n  let b = 2e+\n  let c = 0x\n  let d = 9223372036854775808\n  let e = 0xffffffffffffffff\n  let f = 1e999\n  let g = case 0 do\n    99999999999999999999 -> 1\n    _ -> 0\n  end\n  println(\"#{a} #{b} #{c} #{d} #{e} #{f} #{g}\")\nend\n";
    let err = build_error(bad);
    assert_eq!(err.matches("[E0072] Error").count(), 7, "{err}");
    assert!(err.contains("expected digits after the exponent"), "{err}");
    assert!(err.contains("expected digits after `0x`"), "{err}");
    assert!(
        err.contains("integer literal `9223372036854775808` is out of range"),
        "{err}"
    );
    assert!(
        err.contains("float literal `1e999` is out of range"),
        "{err}"
    );
}

#[test]
fn concatenation_needs_strings_or_lists() {
    // `1 <> 2` aborted at runtime, `1.5 <> 2.5` failed the LLVM verifier,
    // `true ++ false` hung and `(1, 2) <> (3, 4)` printed garbage.
    let source = r##"
fn cat<T>(a :: T, b :: T) -> T do
  a <> b
end

fn main() do
  let v = 1 <> 2
  let w = 1.5 <> 2.5
  let x = true ++ false
  let y = (1, 2) <> (3, 4)
  println("done")
end
"##;
    let err = build_error(source);
    for ty in ["T", "Int", "Float", "Bool", "(Int, Int)"] {
        assert!(
            err.contains(&format!("joins strings or lists, not `{ty}`")),
            "{ty}\n{err}"
        );
    }
    let ok = "fn main() do\n  println(\"a\" <> \"b\")\n  println(\"#{[1] ++ [2]} #{[3] <> [4]}\")\n  println(\"c\" ++ \"d\")\nend\n";
    assert_eq!(run(ok), "ab\n[1, 2] [3, 4]\ncd\n");
}

#[test]
fn operators_in_unannotated_functions_are_checked_at_their_calls() {
    // `add("x", "y")` reached codegen ("Unsupported binop type: String",
    // no location), and `join(1, 2)` aborted at runtime.
    let source = r##"
fn add(a, b) do
  a + b
end

fn pass(x, y) do
  add(x, y)
end

fn join(a, b) do
  a <> b
end

fn main() do
  println("#{add(1, 2)} #{add(1.5, 2.0)} #{pass(3, 4)} #{join("a", "b")} #{join([1], [2])}")
  println(pass("x", "y"))
  println("#{join(1, 2)}")
end
"##;
    let err = build_error(source);
    assert!(err.contains("`String` does not implement `Add`"), "{err}");
    assert!(
        err.contains("`<>` joins strings or lists, not `Int`"),
        "{err}"
    );
    let ok = source
        .replace("  println(pass(\"x\", \"y\"))\n", "")
        .replace("  println(\"#{join(1, 2)}\")\n", "");
    assert_eq!(run(&ok), "3 3.5 7 ab [1, 2]\n");
}

#[test]
fn string_from_shows_any_value_with_display() {
    // Anything but Int, Float and Bool printed a pointer.
    let source = r##"
struct P do
  x :: Int
end deriving(Display)

fn main() do
  println(String.from(1))
  println(String.from(2.5))
  println(String.from("s"))
  println(String.from([1, 2]))
  println(String.from(Some(3)))
  println(String.from(P { x: 4 }))
  println(5 |> String.from())
end
"##;
    assert_eq!(run(source), "1\n2.5\ns\n[1, 2]\nSome(3)\nP(4)\n5\n");
    let err = build_error(
        "struct Q do\n  x :: Int\nend\n\nfn main() do\n  println(String.from(Q { x: 1 }))\nend\n",
    );
    // The type as written (it said `Main.Q`).
    assert!(
        err.contains("Error: `Q` does not implement `Display`"),
        "{err}"
    );
}

#[test]
fn builtins_expanded_inline_can_be_used_as_values() {
    // "Undefined variable 'mesh_math_sqrt'": these have no function of
    // their own to point at.
    let source = r##"
fn apply(f :: Fun(Float) -> Float, x :: Float) -> Float do
  f(x)
end

fn main() do
  let f = Math.sqrt
  println("#{f(4.0)} #{apply(Math.sqrt, 16.0)}")
  println("#{[1, 2] |> List.map(Int.to_float)} #{List.reduce([3, 9, 2], 0, Math.max)}")
  println("#{List.map([1.5, 2.5], Float.to_int)} #{List.map([1, 2], String.from)}")
end
"##;
    assert_eq!(run(source), "2.0 4.0\n[1.0, 2.0] 9\n[1, 2] [1, 2]\n");
}

#[test]
fn a_heredoc_pattern_matches_the_same_heredoc_value() {
    // The pattern kept its raw text: newline, indentation and all.
    let source = r##"
fn classify(s :: String) -> String do
  case s do
    """
    a
    """ -> "heredoc pattern"
    _ -> "other"
  end
end

fn main() do
  let h = """
    a
    """
  println("#{classify(h)} #{classify("\n    a\n    ")}")
end
"##;
    assert_eq!(run(source), "heredoc pattern other\n");
}

#[test]
fn heredocs_in_crlf_files_end_their_lines_with_newlines() {
    // The value was "a\r\nb\r": the `\r` before the closing indent stayed.
    let source = "fn main() do\r\n  let h = \"\"\"\r\n    a\r\n    b\r\n    \"\"\"\r\n  println(\"#{String.length(h)} #{h == \"a\\nb\"}\")\r\nend\r\n";
    assert_eq!(run(source), "3 true\n");
}

#[test]
fn long_expressions_do_not_overflow_the_compilers_stack() {
    // 200 interpolations or 500 chained `<>`/`+` crashed the compiler with
    // a stack overflow.
    let interpolations = "#{x},".repeat(1000);
    let joined = vec!["\"a\""; 800].join(" <> ");
    let sum = vec!["1"; 800].join(" + ");
    let source = format!(
        "fn main() do\n  let x = 7\n  let s = \"{interpolations}\"\n  println(\"#{{String.length(s)}} #{{String.length({joined})}} #{{{sum}}}\")\nend\n"
    );
    assert_eq!(run(&source), "2000 800 800\n");
}

#[test]
fn a_parse_error_at_the_end_of_the_file_is_reported() {
    // With byte offsets, the one-past-the-end span of an error at the end
    // of the file made ariadne panic.
    for source in [
        "fn main() do\n  let s = \"abc\n  println(s)\nend\n",
        "fn main() do\n  println(\"a\n",
        "fn main() do\n  println(\"é",
    ] {
        let err = build_error(source);
        assert!(
            err.contains("[P0102] Error:") && !err.contains("panicked"),
            "{err}"
        );
    }
}

#[test]
fn an_unterminated_string_is_one_error_at_its_opening_quote() {
    // It was "Parse error" with an empty message at the end of the file,
    // two or three times.
    let err = build_error("fn main() do\n  let s = \"abc\n  println(s)\nend\n");
    assert_eq!(err.matches("[P0102] Error:").count(), 1, "{err}");
    assert!(
        err.contains("unterminated string: no closing `\"`"),
        "{err}"
    );
    assert!(err.contains("main.mpl:2:11"), "{err}");
}

#[test]
fn parse_errors_name_tokens_as_written() {
    // "expected R_PAREN", "expected DO_KW", "expected IDENT".
    let err = build_error("fn main() do\n  println(1\nend\n");
    assert!(err.contains("expected `)`"), "{err}");
    assert!(!err.contains("R_PAREN"), "{err}");
}

#[test]
fn a_parse_error_is_not_repeated_at_the_same_place() {
    // An unclosed interpolation gave four errors on one column.
    let err = build_error("fn main() do\n  let x = 1\n  println(\"a#{x\")\nend\n");
    assert_eq!(err.matches("[P0003] Error:").count(), 1, "{err}");
    assert!(
        err.contains("expected `}` to close the interpolation"),
        "{err}"
    );
}

#[test]
fn a_pattern_of_the_wrong_type_is_reported_at_the_pattern() {
    // It spanned the whole function (and `main`), said "expected String,
    // found Int" the wrong way round, and suggested to_string().
    let source = "fn f(x :: Int) -> String do\n  case x do\n    \"a\" -> \"str\"\n    _ -> \"other\"\n  end\nend\n\nfn main() do\n  println(f(1))\nend\n";
    let diags = json_diagnostics(source);
    let mismatch = diags.iter().find(|d| d["code"] == "E0001").expect("E0001");
    assert_eq!(
        mismatch["spans"][0]["start"].as_u64().unwrap() as usize,
        source.find("\"a\"").unwrap()
    );
    assert_eq!(
        mismatch["fix"],
        mesh_diagnostics::Code::TypeMismatch.info().repair
    );
    let err = build_error(source);
    assert!(
        err.contains("this pattern matches String, but the value is Int"),
        "{err}"
    );
    assert_eq!(err.matches("[E0001] Error").count(), 1, "{err}");
}

#[test]
fn types_inference_has_not_determined_show_as_holes() {
    // "expected Int, found Option<?9>" leaked an inference variable.
    let err = build_error(
        "fn f(x :: Int) -> String do\n  case x do\n    Some(_) -> \"opt\"\n    _ -> \"other\"\n  end\nend\n\nfn main() do\n  println(f(1))\nend\n",
    );
    assert!(err.contains("expected `Int`, found `Option<_>`"), "{err}");
    assert!(!err.contains("?"), "{err}");
}

#[test]
fn a_function_a_module_lacks_is_reported_as_such() {
    // "undefined variable: Math", although `Math` exists.
    let err = build_error(
        "fn main() do\n  println(\"#{Math.log(2.0)}\")\n  println(String.upcase(\"s\"))\nend\n",
    );
    assert!(err.contains("module `Math` has no function `log`"), "{err}");
    assert!(err.contains("`Math` has abs, ceil, floor"), "{err}");
    assert!(
        err.contains("module `String` has no function `upcase`"),
        "{err}"
    );
    assert!(!err.contains("undefined variable"), "{err}");
}

#[test]
fn float_has_to_string_like_int() {
    // It was "expected 1 argument(s), found 2".
    assert_eq!(
        run("fn main() do\n  println(Float.to_string(1.5) <> \" \" <> Int.to_string(2))\nend\n"),
        "1.5 2\n"
    );
}

#[test]
fn an_error_is_reported_once() {
    // A failed callee was inferred again as a method call and reported twice.
    let err = build_error("fn main() do\n  println(Foo.bar(1))\nend\n");
    assert_eq!(err.matches("undefined variable `Foo`").count(), 1, "{err}");
}

#[test]
fn string_escapes_are_checked_and_unicode_escapes_work() {
    // An unknown escape `\q` became `q`, and `\u{e9}` printed `u{e9}`.
    let source = r##"
fn main() do
  let x = 1
  println("a\u{e9}b \u{1F389} [\t] [\"] [\\] [\${x}] [\#{x}]")
end
"##;
    assert_eq!(
        run(source),
        "a\u{e9}b \u{1F389} [\t] [\"] [\\] [${x}] [#{x}]\n"
    );
    let err = build_error("fn main() do\n  println(\"a\\qb\")\n  println(\"c\\u{zz}d\")\nend\n");
    assert!(err.contains("unknown escape `\\q`"), "{err}");
    assert!(err.contains("invalid unicode escape"), "{err}");
    assert!(
        err.contains("main.mpl:2:13") && err.contains("main.mpl:3:13"),
        "{err}"
    );
}

#[test]
fn a_heredoc_can_end_with_a_quote() {
    // `""""` closed the heredoc at the first three quotes and left a
    // stray `"`, a parse error.
    let source = "fn main() do\n  println(\"\"\"ends with quote\"\"\"\")\n  println(\"\"\"say \"hi\" twice\"\"\"\"\"\")\nend\n";
    assert_eq!(run(source), "ends with quote\"\nsay \"hi\" twice\"\"\"\n");
}

#[test]
fn a_bad_digit_in_a_radix_literal_is_named() {
    // `0b102` lexed as `0b10` then `2`: "expected a newline or `;`".
    let err = build_error("fn main() do\n  let b = 0b102\n  let c = 0o8\n  let d = 0xfg\n  println(\"#{b} #{c} #{d}\")\nend\n");
    assert!(
        err.contains("invalid digit `2` in binary literal `0b102`"),
        "{err}"
    );
    assert!(
        err.contains("invalid digit `8` in octal literal `0o8`"),
        "{err}"
    );
    assert!(
        err.contains("invalid digit `g` in hexadecimal literal `0xfg`"),
        "{err}"
    );
}

#[test]
fn return_of_a_tail_call_is_a_tail_call() {
    // "Terminator found in the middle of a basic block": the `ret` stayed
    // after the tail call's jump.
    let source = r##"
fn count(n :: Int, acc :: Int) -> Int do
  if n == 0 do
    return acc
  end
  return count(n - 1, acc + 1)
end

fn count2(n :: Int, acc :: Int) -> Int do
  if n == 0 do
    acc
  else
    return count2(n - 1, acc + 1)
  end
end

fn main() do
  println("#{count(10, 0)} #{count2(1000000, 0)}")
end
"##;
    assert_eq!(run(source), "10 1000000\n");
}

#[test]
fn a_stack_overflow_is_reported() {
    // Deep non-tail recursion died with a bare "Segmentation fault: 11".
    let recurse = "fn depth(n :: Int) -> Int do\n  if n == 0 do\n    0\n  else\n    1 + depth(n - 1)\n  end\nend\n\n";
    for main in [
        "fn main() do\n  println(\"#{depth(100000000)}\")\nend\n",
        "actor deep() do\n  receive do\n    n -> println(\"#{depth(n)}\")\n  end\nend\n\nfn main() do\n  let p = spawn(deep)\n  send(p, 100000000)\n  Timer.sleep(2000)\nend\n",
    ] {
        let (code, _stdout, stderr) = run_status(&format!("{recurse}{main}"), &[]);
        assert_ne!(code, Some(0), "{stderr}");
        assert!(stderr.contains("[R0002] Error: stack overflow"), "{stderr}");
    }
}

#[test]
fn a_name_can_be_defined_at_several_arities() {
    // Each arity is its own function. `= expr` bodies and private fns were
    // rejected ("expected 2 argument(s), found 1"), and clauses of one arity
    // beside another arity failed to link.
    let out = run(r##"fn area(r) = r * r * 3
fn area(w, h) = w * h

fn fact(0) = 1
fn fact(n) = fact(n, 1)
fn fact(0, acc) = acc
fn fact(n, acc) = fact(n - 1, acc * n)

fn scale(x :: Int) -> Int do
  x * 10
end

fn scale(x :: Int, by :: Int) -> Int do
  x * by
end

fn first(xs) = List.head(xs)
fn first(xs, fallback) = if List.length(xs) == 0 do fallback else List.head(xs) end

fn main() do
  println("#{area(2)} #{area(3, 4)}")
  println("#{fact(5)} #{fact(4, 1)}")
  println("#{3 |> scale} #{3 |> scale(4)} #{4 |2> scale(5)}")
  println("#{first([1, 2])} #{first(["a"])} #{first([], 7)} #{first([], "z")}")
  let scale = fn x -> x + 1 end
  println("#{scale(1)}")
end
"##);
    assert_eq!(out, "12 12\n120 24\n30 12 20\n1 a 7 z\n2\n");
}

#[test]
fn a_name_defined_at_several_arities_is_not_a_value() {
    let err = build_error(
        "fn area(r) = r * r * 3\nfn area(w, h) = w * h\n\nfn main() do\n  let f = area\n  println(\"#{area(1, 2, 3)}\")\nend\n",
    );
    assert_eq!(err.matches("[E0075]").count(), 2, "{err}");
    assert!(
        err.contains("`area` is defined at arities 1 and 2"),
        "{err}"
    );
    assert!(err.contains("fn a0 -> area(a0) end"), "{err}");
}

#[test]
fn a_runtime_error_is_a_mesh_panic_that_ends_only_its_actor() {
    // `List.get` past the end, in an actor, aborted the whole process ("panic
    // in a function that cannot unwind", then Rust's backtrace): runtime
    // functions could not unwind. It now ends the actor alone, reported as
    // its R0001 diagnostic.
    let (code, out, err) = run_status(
        r##"actor worker(n :: Int) do
  receive do
    i -> println("got #{List.get([1], i)}")
  end
end

fn main() do
  let pid = spawn(worker, 0)
  send(pid, 5)
  Timer.sleep(200)
  println("main still running")
end
"##,
        &[],
    );
    assert_eq!(code, Some(0), "{err}");
    assert_eq!(out, "main still running\n");
    assert_eq!(
        err,
        panic_report(&["List.get: index 5 is out of bounds for a list of length 1"])
    );
    // On the main thread it ends the program with status 101.
    for (value, message) in [
        ("List.head(List.tail([1]))", "List.head: the list is empty"),
        (
            "DateTime.to_unix_ms(DateTime.add(dt, 1, :year))",
            "DateTime.add: unknown unit \"year\"",
        ),
        (
            "DateTime.to_unix_ms(DateTime.add(dt, 9223372036854775807, :day))",
            "DateTime.add: adding 9223372036854775807 day to 0 ms is out of the supported range",
        ),
    ] {
        let source = format!(
            "fn main() do\n  case DateTime.from_unix_ms(0) do\n    Ok(dt) -> println(\"#{{{value}}}\")\n    Err(e) -> println(e)\n  end\nend\n"
        );
        let (code, out, err) = run_status(&source, &[]);
        assert_eq!(code, Some(101), "{value}\n{err}");
        assert_eq!(out, "", "{value}");
        assert!(
            err.starts_with(&format!("[R0001] Error: {message}")),
            "{value}\n{err}"
        );
        assert_eq!(err.matches("[R0001]").count(), 1, "{value}\n{err}");
    }
}

#[test]
fn an_unknown_query_atom_is_a_mesh_panic() {
    // An operator or join kind the Query builders do not know read as `=`
    // or INNER: a typo ran a different query.
    for (call, message) in [
        (
            "Query.from(\"t\") |> Query.where_op(:age, :greater, \"1\")",
            "[R0001] Error: Query.where_op: unknown operator :greater;",
        ),
        (
            "Query.from(\"t\") |> Query.join_as(:outer, \"u\", \"x\", \"x.id = t.id\")",
            "[R0001] Error: Query.join_as: unknown join kind :outer;",
        ),
    ] {
        let source = format!("fn main() do\n  let q = {call}\n  println(\"built\")\nend\n");
        let (code, out, err) = run_status(&source, &[]);
        assert_eq!(code, Some(101), "{call}\n{err}");
        assert_eq!(out, "", "{call}");
        assert!(err.starts_with(message), "{call}\n{err}");
    }
}

#[test]
fn a_failed_match_names_its_function() {
    // It said "Mesh panic in <unknown>".
    let (code, out, err) = run_status(
        "fn f(0) = \"zero\"\n\nfn main() do\n  println(f(0))\n  println(f(5))\nend\n",
        &[],
    );
    assert_eq!(code, Some(101), "{err}");
    assert_eq!(out, "zero\n");
    assert!(
        err.starts_with("[R0001] Error: non-exhaustive match\n"),
        "{err}"
    );
    assert!(err.contains("  Note: raised in `Main__f`\n"), "{err}");
    assert_eq!(err.matches("[R0001]").count(), 1, "{err}");
}

#[test]
fn break_outside_a_loop_names_both_loops() {
    // It said `break` belongs inside a `while` loop; `for` loops take it too.
    let err = build_error("fn main() do\n  break\nend\n");
    assert!(err.contains("inside a `while` or `for` loop"), "{err}");
}

#[test]
fn tuples_of_different_lengths_are_a_type_mismatch() {
    // `let (a, b) = (1, 2, 3)` said "expected 2 argument(s), found 3".
    let err = build_error("fn main() do\n  let (a, b) = (1, 2, 3)\n  println(\"#{a}\")\nend\n");
    assert!(
        err.contains("expected (_, _), found (Int, Int, Int)"),
        "{err}"
    );
    assert!(!err.contains("argument"), "{err}");
}

#[test]
fn a_guard_may_call_a_module_qualified_function() {
    // Guards allow named function calls, but `String.length(s)` was
    // rejected as not one.
    let out = run(
        "fn main() do\n  let r = case \"hello\" do\n    s when String.length(s) > 3 -> \"long\"\n    _ -> \"short\"\n  end\n  println(r)\nend\n",
    );
    assert_eq!(out, "long\n");
}

#[test]
fn a_misspelled_name_suggests_the_one_in_scope() {
    // The "did you mean" help existed, but the compiler never gave it the
    // names in scope.
    let err = build_error(
        "fn main() do\n  let count = 3\n  println(\"#{cuont}\")\n  printn(\"x\")\nend\n",
    );
    assert!(err.contains("did you mean `count`?"), "{err}");
    assert!(err.contains("did you mean `println`?"), "{err}");
    let err = build_error(
        "fn main() do\n  let r = case Some(1) do\n    Sme(n) -> n\n    None -> 0\n  end\n  println(\"#{r}\")\nend\n",
    );
    assert!(err.contains("unknown variant `Sme`"), "{err}");
    assert!(err.contains("did you mean `Some`?"), "{err}");
}

#[test]
fn an_unknown_capitalized_pattern_is_an_error() {
    // A misspelled constructor was a new variable that matched every value:
    // `Grean` caught `Green`, and `Five` matched any Int.
    let err = build_error(
        r##"type Color do
  Red
  Green
end

fn name(c :: Color) -> String do
  case c do
    Red -> "red"
    Grean -> "green"
  end
end

fn main() do
  println(name(Green))
  let r = case 5 do
    Five -> "five?"
  end
  println(r)
end
"##,
    );
    assert!(err.contains("unknown variant `Grean`"), "{err}");
    assert!(err.contains("did you mean `Green`?"), "{err}");
    assert!(err.contains("unknown variant `Five`"), "{err}");
}

#[test]
fn an_arm_of_another_type_is_reported_at_the_arms() {
    // A `case` arm, `receive` arm or clause whose type differs from the
    // first was reported over the whole enclosing function.
    for (source, first, other) in [
        (
            "fn main() do\n  let x = case 1 do\n    1 -> 5\n    _ -> \"s\"\n  end\n  println(\"#{x}\")\nend\n",
            "5",
            "\"s\"",
        ),
        (
            "fn f(0) = 1\nfn f(n) = \"many\"\n\nfn main() do\n  println(\"#{f(2)}\")\nend\n",
            "1",
            "\"many\"",
        ),
    ] {
        let diags = json_diagnostics(source);
        let mismatch = diags
            .iter()
            .find(|d| d["code"] == "E0001")
            .unwrap_or_else(|| panic!("{source}\n{diags:?}"));
        let spans = mismatch["spans"].as_array().unwrap();
        let at = |text: &str| {
            let start = source.rfind(text).unwrap();
            spans
                .iter()
                .any(|s| s["start"] == start && s["end"] == start + text.len())
        };
        assert!(at(first) && at(other), "{source}\n{spans:?}");
    }
}

#[test]
fn a_panic_in_a_collection_callback_ends_only_its_actor() {
    // The runtime called the closures of `List.map`, `filter`, `reduce` and
    // the generated Eq/Display functions through `extern "C"` pointers:
    // unwinding out of them was undefined behaviour that happened to work.
    let (code, out, err) = run_status(
        r##"actor worker(n :: Int) do
  receive do
    d ->
      let total = List.reduce([1, 2], 0, fn acc, x -> acc + x / d end)
      println("total #{total}")
  end
end

fn main() do
  let pid = spawn(worker, 0)
  send(pid, 0)
  Timer.sleep(200)
  println("main still running")
end
"##,
        &[],
    );
    assert_eq!(code, Some(0), "{err}");
    assert_eq!(out, "main still running\n");
    assert!(err.contains("division by zero"), "{err}");
}

#[test]
fn a_for_loop_runs_over_a_range_value() {
    // `for i in r` with `r` a Range variable (not a `2..5` literal) panicked
    // the compiler: "Runtime function 'Iterable__iter__Unknown' not declared".
    let out = run(r##"fn span() -> Range = Range.new(1, 3)

fn main() do
  let r = 2..5
  let xs = for i in r do
    i
  end
  println("#{xs}")
  println("#{for i in Range.new(2, 5) when i != 3 do i * 2 end}")
  println("#{for i in span() do i end}")
end
"##);
    assert_eq!(out, "[2, 3, 4]\n[4, 8]\n[1, 2]\n");
}

#[test]
fn a_function_can_be_the_accumulator_of_a_reduce() {
    // A closure as the initial value was split into (fn, env) like the
    // callback, or neither was: "Incorrect number of arguments passed to
    // called function!" from LLVM.
    let out = run(r##"fn main() do
  let id = fn (x :: Int) -> x end
  let f = List.reduce([1, 2, 3], id, fn acc, i -> fn x -> acc(x) + i end end)
  println("#{f(0)} #{f(10)}")
end
"##);
    assert_eq!(out, "6 16\n");
}

#[test]
fn a_computed_function_value_has_one_type() {
    // `let f = ident_fn()` was generalized like a closure literal: its use at
    // String ran a closure built for no type (an empty line), as did
    // `List.head([fn x -> x end])`, and `tag_with(1)` failed LLVM
    // verification. A computed value gets the one type its uses fix.
    let out = run(r##"fn ident_fn<B>() -> Fun(B) -> B do
  fn b -> b end
end

fn tag_with<A, B>(a :: A) -> Fun(B) -> B do
  fn b -> b end
end

fn main() do
  let f = ident_fn()
  println(f("x"))
  let fs = [fn x -> x end]
  let g = List.head(fs)
  println(g("y"))
  let h = Tuple.first((fn x -> x end, 1))
  println(h("abc"))
  let t = tag_with(1)
  println(t("z"))
end
"##);
    assert_eq!(out, "x\ny\nabc\nz\n");
    // Used at two types, it is a type error, not an LLVM one.
    let err = build_error(
        "fn main() do\n  let flag = true\n  let f = if flag do fn x -> x end else fn y -> y end end\n  println(f(\"s\"))\n  println(\"#{f(3)}\")\nend\n",
    );
    assert!(err.contains("[E0001]"), "{err}");
    assert!(!err.contains("LLVM"), "{err}");
}

#[test]
fn a_for_loop_runs_over_a_user_iterator() {
    // A struct implementing `Iterator` on the right of `in` panicked the
    // compiler: "Found StructValue ... but expected PointerValue". Its
    // `next` returns the `Option` by value, not a runtime option pointer.
    let out = run(r##"service Feed do
  fn init(items :: List<Int>) -> List<Int> do
    items
  end

  call Pop() :: Int? do |items|
    case items do
      [] -> (items, None)
      _ -> (List.tail(items), Some(List.head(items)))
    end
  end
end

struct Stream do
  pid :: Pid
end

impl Iterator for Stream do
  type Item = Int
  fn next(self) -> Int? do
    Feed.pop(self.pid)
  end
end

struct Empty do
  n :: Int
end

impl Iterator for Empty do
  type Item = String
  fn next(self) -> String? do
    None
  end
end

fn main() do
  let stream = Stream { pid: Feed.start([2, 4, 6]) }
  println("#{for x in stream do x * 10 end}")
  println("#{for s in Empty { n: 0 } do s end}")
end
"##);
    assert_eq!(out, "[20, 40, 60]\n[]\n");
}

#[test]
fn panic_ends_the_actor_or_the_program() {
    // The Mesh skill docs used `panic("...")`, which did not exist.
    let built = build_with_args(
        r##"fn parse_port(text :: String) -> Int do
  case String.to_int(text) do
    Some(port) -> port
    None -> panic("not a port: #{text}")
  end
end

actor worker(n :: Int) do
  receive do
    _ -> panic("deliberate crash")
  end
end

fn main() do
  println("#{parse_port("8080")}")
  let pid = spawn(worker, 0)
  send(pid, 1)
  Timer.sleep(200)
  println("#{parse_port("x")}")
  println("unreachable")
end
"##,
        &[],
    );
    assert!(built.ok, "build failed:\n{}", built.stderr);
    let output = Command::new(built.dir.path().join("project/project"))
        .output()
        .expect("run binary");
    let err = String::from_utf8_lossy(&output.stderr);
    assert_eq!(output.status.code(), Some(101), "{err}");
    assert_eq!(String::from_utf8_lossy(&output.stdout), "8080\n");
    // Each panic is at its call.
    let main = mesh_diagnostics::SourceFile::unread(built.dir.path().join("project/main.mpl"));
    let at = |line, col, message| {
        mesh_diagnostics::Diagnostic::at_line(
            mesh_diagnostics::Code::Panic,
            main.clone(),
            line,
            message,
        )
        .at_column(col)
    };
    assert_eq!(
        err,
        runtime_report([at(10, 10, "deliberate crash"), at(4, 13, "not a port: x")])
    );
}

#[test]
fn an_impl_for_a_generic_type_is_reported_at_its_header() {
    // `impl Describe for Box` (with `struct Box<T>`) was accepted, and then
    // no `Box<Int>` had the method; `impl ... for List<Int>` was a parse
    // error at `<` ("expected `do`") and one about the unclosed body.
    let interface = "interface Describe do\n  fn describe(self) -> String\nend\n\n";
    let err = build_error(&format!(
        "{interface}struct Box<T> do\n  value :: T\nend\n\nimpl Describe for Box do\n  fn describe(self) -> String do\n    \"a box\"\n  end\nend\n\nfn main() do\n  println(Box {{ value: 1 }}.describe())\nend\n"
    ));
    assert!(err.contains("[E0076]"), "{err}");
    assert!(err.contains("`Box` takes type parameters"), "{err}");
    let err = build_error(&format!(
        "{interface}impl Describe for Option do\n  fn describe(self) -> String do\n    \"an option\"\n  end\nend\n\nfn main() do\n  println(\"x\")\nend\n"
    ));
    assert!(err.contains("[E0076]"), "{err}");
    let err = build_error(&format!(
        "{interface}impl Describe for List<Int> do\n  fn describe(self) -> String do\n    \"a list\"\n  end\nend\n\nfn main() do\n  println(\"x\")\nend\n"
    ));
    assert!(
        err.contains("an `impl` for a type with type arguments is not supported"),
        "{err}"
    );
    assert_eq!(err.matches("Error").count(), 1, "{err}");
}

#[test]
fn assert_receive_outside_a_test_is_undefined() {
    // `meshc test` expands it; elsewhere it is parsed (for `meshc fmt` and
    // `meshc lint`) and reported (E0077), not skipped.
    let err = build_error("fn main() do\n  assert_receive 42, 500\nend\n");
    assert!(err.contains("[E0077]"), "{err}");
}

#[test]
fn a_guard_compares_with_a_string_literal() {
    // "invalid guard: expression not allowed in guard"; an Int literal worked.
    let out = run(
        "fn main() do\n  let r = case \"b\" do\n    t when t == \"zzzz\" -> \"long\"\n    t when t == \"b\" -> \"b\"\n    _ -> \"other\"\n  end\n  println(r)\nend\n",
    );
    assert_eq!(out, "b\n");
}

#[test]
fn map_get_of_a_missing_key_panics() {
    // It returned 0, 0.0 or a null string (a crash later, far from the
    // cause); `Map.get` requires the key, as `List.get` requires the index.
    for (source, value) in [
        (
            "let m = %{1 => 10}\n  println(\"#{Map.get(m, 2)}\")",
            "Map.get",
        ),
        (
            "let m = %{\"a\" => \"x\"}\n  println(Map.get(m, \"b\"))",
            "Map.get",
        ),
        (
            "let m = %{(1, 2) => 3}\n  println(\"#{Map.get(m, (2, 1))}\")",
            "Map.get",
        ),
    ] {
        let (code, out, err) = run_status(&format!("fn main() do\n  {source}\nend\n"), &[]);
        assert_eq!(code, Some(101), "{source}\n{err}");
        assert_eq!(out, "", "{source}");
        assert!(
            err.starts_with(&format!(
                "[R0001] Error: {value}: the key is not in the map"
            )),
            "{source}\n{err}"
        );
    }
    // A key found by its type's Eq (a tuple here) is found by `Map.get` too.
    assert_eq!(
        run("fn main() do\n  let m = %{\"a\" => 1}\n  let t = %{(1, 2) => 3}\n  println(\"#{Map.get(m, \"a\")} #{Map.get(t, (1, 2))}\")\nend\n"),
        "1 3\n"
    );
}

#[test]
fn a_bad_struct_field_leaves_the_value_typed() {
    // After `S { a: "s", b: 1 }`, `s` had no type: an update of it and a
    // field read of that reported E0059 and E0070 too, and an unknown field
    // hid a missing one.
    let err = build_error(
        "struct S do\n  a :: Int\n  b :: Int\nend\n\nfn main() do\n  let s = S { a: \"s\", b: 1 }\n  let t = %{s | b: \"x\"}\n  let u = S { c: 1, a: 2 }\n  println(\"#{t.a} #{u.a}\")\nend\n",
    );
    assert_eq!(err.matches("[E0001]").count(), 2, "{err}");
    assert!(err.contains("unknown field `c`"), "{err}");
    assert!(err.contains("missing field `b`"), "{err}");
    assert!(!err.contains("E0059") && !err.contains("E0070"), "{err}");
}

#[test]
fn interpolating_a_value_without_display_is_a_type_error() {
    // A struct or sum value without Display printed its Debug form, and a
    // closure or a Queue failed in codegen, with no location.
    for (value, name) in [
        ("Sq { s: 1 }", "Sq"),
        ("A", "Sh"),
        ("Queue.new()", "Queue<_>"),
        ("fn x -> x + 1 end", "(Int) -> Int"),
    ] {
        let err = build_error(&format!(
            "struct Sq do\n  s :: Int\nend\n\ntype Sh do\n  A\n  B(Int)\nend\n\nfn main() do\n  let v = {value}\n  println(\"<#{{v}}>\")\nend\n"
        ));
        assert!(
            err.contains(&format!("`{name}` does not implement `Display`")),
            "{value}: {err}"
        );
        assert!(err.contains("main.mpl:12:15"), "{value}: {err}");
    }
    // In a generic function the type parameter needs the bound.
    let err = build_error(
        "fn show<T>(x :: T) -> String do\n  \"<#{x}>\"\nend\n\nfn main() do\n  println(show(1))\nend\n",
    );
    assert!(
        err.contains("`T` is not known to implement Display"),
        "{err}"
    );
    assert_eq!(
        run("fn show<T>(x :: T) -> String where T: Display do\n  \"<#{x}>\"\nend\n\nfn main() do\n  println(show(1))\nend\n"),
        "<1>\n"
    );
}

#[test]
fn an_argument_error_points_at_the_argument() {
    // It underlined the whole call, every line of a call written over
    // several, and a multi-line argument started on the line before it.
    let err = build_error(
        "fn f(a :: Int, b :: String) -> Int do\n  a\nend\n\nfn main() do\n  let x = f(\n    1,\n    2\n  )\n  println(\"#{x + f(1, 3)}\")\nend\n",
    );
    assert!(err.contains("main.mpl:8:5"), "{err}");
    assert!(err.contains("main.mpl:10:23"), "{err}");
}

#[test]
fn a_mismatch_of_two_collection_types_names_both_whole() {
    // "expected Map, found List": the arguments were left out.
    let err = build_error(
        "fn main() do\n  let m :: Map<String, Int> = [1]\n  println(\"#{Map.size(m)}\")\nend\n",
    );
    assert!(
        err.contains("expected `Map<String, Int>`, found `List<Int>`"),
        "{err}"
    );
}

#[test]
fn map_destructuring_over_a_list_is_a_type_error() {
    // `{k, v}` bound nothing over a list: "undefined variable: k", with
    // "did you mean `_`?".
    let err = build_error(
        "fn main() do\n  for {k, v} in [1, 2, 3] do\n    println(\"#{k} #{v}\")\n  end\nend\n",
    );
    assert!(
        err.contains("expected `Map<_, _>`, found `List<Int>`"),
        "{err}"
    );
    assert!(!err.contains("undefined variable"), "{err}");
}

#[test]
fn bulk_collection_builders_take_linear_time() {
    // Each built its result one element at a time through a copying
    // `append`, `put` or `add`: 100 000 elements took minutes.
    let source = r##"
fn main() do
  let n = 100000
  let xs = Range.to_list(0..n)
  let doubled = Range.map(0..n, fn i -> i * 2 end)
  let evens = Range.filter(0..n, fn i -> i % 2 == 0 end)
  let s = Set.from_list(List.append(xs, 5))
  let m = Map.from_list(List.zip(xs, doubled))
  println("#{List.length(xs)} #{List.last(doubled)} #{List.length(evens)} #{Set.size(s)} #{Map.size(m)} #{Map.get(m, 99999)}")
  let ms = Iter.from(xs) |> Iter.map(fn i -> (i % 1000, i) end) |> Map.collect()
  let ss = Iter.from(xs) |> Iter.map(fn i -> i % 7 end) |> Set.collect()
  let sm = Map.from_list([("a", 1), ("b", 2), ("a", 3)])
  let tk = Map.from_list([((1, 2), "x"), ((1, 2), "y"), ((2, 1), "z")])
  println("#{Map.size(ms)} #{Map.get(ms, 5)} #{Set.to_list(ss)} #{sm} #{Map.size(tk)} #{Map.get(tk, (1, 2))}")
  let q = List.reduce(xs, Queue.new(), fn q, x -> Queue.push(q, x) end)
  let (first, rest) = Queue.pop(q)
  println("#{Queue.size(q)} #{first} #{Queue.peek(rest)} #{Queue.size(Queue.push(rest, 7))}")
end
"##;
    let started = std::time::Instant::now();
    assert_eq!(
        run(source),
        "100000 199998 50000 100000 100000 199998\n1000 99005 [0, 1, 2, 3, 4, 5, 6] %{a => 3, b => 2} 2 y\n100000 0 1 100000\n"
    );
    // Compiling included; the quadratic builders took minutes. A collection
    // at every allocation (MESH_GC_STRESS) is slower than that.
    if std::env::var_os("MESH_GC_STRESS").is_none() {
        assert!(started.elapsed() < std::time::Duration::from_secs(60));
    }
}

#[test]
fn json_encode_takes_any_value_json_holds() {
    // Only a Json value or a derived type was encoded: a map printed as a
    // number, an Int or a Bool crashed, a String printed `true`, a Float
    // failed LLVM verification, and a closure was accepted.
    let source = r##"
struct P do
  b :: Int
  a :: String
end deriving(Json)

fn main() do
  println(Json.encode(1))
  println(Json.encode(true))
  println(Json.encode(1.5))
  println(Json.encode("s"))
  println(Json.encode([1.5, 2.0]))
  println(Json.encode(Some(1)))
  println(Json.encode((1, "a")))
  println(Json.encode(%{"z" => 1, "y" => 2}))
  println(Json.encode([P { b: 1, a: "x" }]))
  case Json.parse("[1, 2]") do
    Ok(tree) -> println(Json.encode(tree))
    Err(e) -> println(e)
  end
end
"##;
    assert_eq!(
        run(source),
        "1\ntrue\n1.5\n\"s\"\n[1.5,2.0]\n1\n[1,\"a\"]\n{\"z\":1,\"y\":2}\n[{\"b\":1,\"a\":\"x\"}]\n[1,2]\n"
    );
    let err = build_error("fn main() do\n  println(Json.encode(%{1 => 2}))\nend\n");
    assert!(
        err.contains("`Map<Int, Int>` does not implement `Json`"),
        "{err}"
    );
}

#[test]
fn a_struct_literal_of_an_unknown_type_is_reported_once() {
    // "`Nope` is not a struct", then "type Nope has no field x" for each use.
    let err = build_error("fn main() do\n  let p = Nope { x: 1 }\n  println(\"#{p.x}\")\nend\n");
    assert!(err.contains("unknown type `Nope`"), "{err}");
    assert_eq!(err.matches("Error:").count(), 1, "{err}");
}

#[test]
fn a_module_blocks_struct_stays_in_the_block() {
    // A struct of a `module ... do ... end` block was a type of the file's
    // module too, usable outside the block without an import, private or not.
    let err = build_error(
        "module Geometry do\n  struct Secret do\n    s :: Int\n  end\nend\n\nfn main() do\n  let s = Secret { s: 2 }\n  println(\"#{s.s}\")\nend\n",
    );
    assert!(err.contains("unknown type `Secret`"), "{err}");
}

#[test]
fn collections_grow_in_place_one_element_at_a_time() {
    // `List.append`, `Map.put` and `Set.add` copied the collection they were
    // given, and a map or set found a key by a scan: building 100 000
    // elements one at a time took minutes. The newest version of a
    // collection now grows in place (a map or set through a hash index), and
    // a change to an older one copies it, so every value keeps its elements.
    let source = r##"
fn build(i :: Int, n :: Int, xs :: List<Int>, m :: Map<Int, Int>, s :: Set) -> (List<Int>, Map<Int, Int>, Set) do
  if i == n do
    (xs, m, s)
  else
    build(i + 1, n, List.append(xs, i), Map.put(m, i % 5000, i), Set.add(s, i % 7000))
  end
end

fn count_words(words :: List<String>) -> Map<String, Int> do
  List.reduce(words, %{}, fn acc, w ->
    if Map.has_key(acc, w) do
      Map.put(acc, w, Map.get(acc, w) + 1)
    else
      Map.put(acc, w, 1)
    end
  end)
end

fn main() do
  let (xs, m, s) = build(0, 100000, [], %{}, Set.new())
  println("#{List.length(xs)} #{List.last(xs)} #{Map.size(m)} #{Map.get(m, 4999)} #{Set.size(s)} #{Set.contains(s, 6999)}")
  let short = List.take(xs, 3)
  let a = List.append(short, 7)
  let b = List.append(short, 8)
  let c = short ++ [9, 10]
  let d = a ++ a
  println("#{short} #{a} #{b} #{c} #{d}")
  let big = List.reduce(Range.to_list(0..20), %{}, fn acc, i -> Map.put(acc, i, i) end)
  let left = Map.put(big, 5, 50)
  let right = Map.delete(big, 5)
  let again = Map.put(big, 100, 1)
  println("#{Map.get(big, 5)} #{Map.get(left, 5)} #{Map.has_key(right, 5)} #{Map.size(big)} #{Map.size(right)} #{Map.size(again)} #{Map.has_key(big, 100)}")
  let moved = Map.put(Map.delete(big, 0), 0, 7)
  println("#{List.head(Map.keys(moved))} #{List.last(Map.keys(moved))} #{Map.get(moved, 0)} #{left == Map.put(big, 5, 50)} #{left == big}")
  let total = for {k, v} in left do
    k + v
  end
  println("#{List.reduce(total, 0, fn x, y -> x + y end)}")
  let grid = List.reduce(Range.to_list(0..3000), %{}, fn acc, i -> Map.put(acc, (i % 50, i / 50), i) end)
  println("#{Map.size(grid)} #{Map.get(grid, (7, 11))} #{Map.has_key(grid, (50, 0))}")
  let words = List.map(Range.to_list(0..30000), fn i -> "w#{i % 300}" end)
  let counts = count_words(words)
  println("#{Map.size(counts)} #{Map.get(counts, "w17")} #{Json.encode(Map.delete(counts, "w1")) |> String.length()}")
  let sset = Set.remove(Set.add(s, 70000), 3)
  println("#{Set.size(sset)} #{Set.contains(sset, 3)} #{Set.contains(s, 3)} #{Set.size(Set.intersection(s, sset))}")
end
"##;
    let started = std::time::Instant::now();
    assert_eq!(
        run(source),
        "100000 99999 5000 99999 7000 true\n[0, 1, 2] [0, 1, 2, 7] [0, 1, 2, 8] [0, 1, 2, 9, 10] [0, 1, 2, 7, 0, 1, 2, 7]\n5 50 false 20 19 21 false\n1 0 7 true false\n425\n3000 557 false\n300 100 3182\n7000 false true 6999\n"
    );
    // Compiling included. A collection at every allocation (MESH_GC_STRESS)
    // is slower than that.
    if std::env::var_os("MESH_GC_STRESS").is_none() {
        assert!(started.elapsed() < std::time::Duration::from_secs(60));
    }
    // A grown map, set or list sent to another actor arrives as its live
    // elements.
    let source = r##"
actor keeper() do
  receive do
    (m, s, xs) -> do
      let m2 = Map.put(m, "extra", 1)
      println("#{Map.size(m)} #{Map.get(m, "k3")} #{Map.has_key(m, "k0")} #{Map.size(m2)} #{Set.size(s)} #{Set.contains(s, 12)} #{List.length(xs)} #{List.last(xs)}")
    end
  end
end

fn main() do
  let m = List.reduce(Range.to_list(0..30), %{}, fn acc, i -> Map.put(acc, "k#{i % 12}", i) end)
  let m = Map.delete(m, "k0")
  let s = List.reduce(Range.to_list(0..40), Set.new(), fn acc, i -> Set.add(acc, i % 13) end)
  let xs = List.reduce(Range.to_list(0..50), [], fn acc, i -> List.append(acc, i) end)
  let pid = spawn(keeper)
  send(pid, (m, s, xs))
  Timer.sleep(200)
end
"##;
    assert_eq!(run(source), "11 27 false 12 13 true 50 49\n");
}

#[test]
fn an_iterator_steps_with_next() {
    // Built-in iterators had no `next`: `Iter.next(it)` was "module `Iter`
    // has no function `next`" and `it.next()` found an untyped method of the
    // handle behind the pipeline.
    let source = r##"
fn main() do
  let it = Iter.from([1, 2, 3]) |> Iter.map(fn x -> x * 10 end)
  case Iter.next(it) do
    Some(x) -> println("#{x}")
    None -> println("none")
  end
  case it.next() do
    Some(x) -> println("#{x + 1}")
    None -> println("none")
  end
  let words = Iter.from(["a", "b"])
  let first = words.next()
  let second = Iter.next(words)
  let third = words.next()
  println("#{first} #{second} #{third} #{Iter.count(it)}")
  println("#{Iter.from([1.5]) |> Iter.next()}")
end
"##;
    assert_eq!(run(source), "10\n21\nSome(a) Some(b) None 1\nSome(1.5)\n");
}

// ── Struct patterns ────────────────────────────────────────────────────

/// `Point { x: 0, y }` matches a struct by its fields: `field: pattern`
/// tests the field, a field alone binds it, and fields left out match
/// anything. Struct patterns nest in constructors, tuples and each other,
/// and work in `case`, function and closure clauses, `let` and `for`.
#[test]
fn struct_patterns_match_and_bind_fields() {
    let output = run(r##"
struct Point do
  x :: Int
  y :: Int
end

struct Box<T> do
  value :: T
  label :: String
end

struct Line do
  from :: Point
  to :: Point
end

struct Pair do
  t :: (Int, String)
  f :: Float
end

type Shape do
  Dot(Point)
  Segment(Line)
end

fn describe(p :: Point) -> String do
  case p do
    Point { x: 0, y: 0 } -> "origin"
    Point { x: 0, y } -> "on y axis at #{y}"
    Point { y: 0, x } -> "on x axis at #{x}"
    Point { x, y } when x == y -> "diagonal #{x}"
    Point { x: 1 } | Point { y: 1 } -> "next to an axis"
    _ -> "elsewhere"
  end
end

fn norm1(Point { x, y }) = x + y

fn length(s :: Shape) -> Int do
  case s do
    Dot(_) -> 0
    Segment(Line { from: Point { x: x1, y: y1 }, to: Point { x: x2, y: y2 } }) ->
      x2 - x1 + (y2 - y1)
  end
end

fn first_x(o :: Point?) -> Int do
  case o do
    Some(Point { x }) -> x
    None -> -1
  end
end

fn main() do
  for p in [Point { x: 0, y: 0 }, Point { x: 0, y: 5 }, Point { x: 7, y: 0 }, Point { x: 3, y: 3 }, Point { x: 1, y: 9 }, Point { x: 4, y: 2 }] do
    println(describe(p))
  end
  println("#{norm1(Point { x: 4, y: 5 })}")
  let Point { x, y: why } = Point { x: 10, y: 20 }
  println("#{x} #{why}")
  case Box { value: "hi", label: "greeting" } do
    Box { value: "hi", label } -> println("hi box #{label}")
    Box { value } -> println(value)
  end
  case Box { value: Some(2.5), label: "maybe" } do
    Box { value: Some(v) } -> println("some #{v}")
    Box { value: None } -> println("none")
  end
  for Box { value, label } in [Box { value: 1, label: "a" }, Box { value: 2, label: "b" }] do
    println("#{label}=#{value}")
  end
  let segment = Segment(Line { from: Point { x: 1, y: 1 }, to: Point { x: 4, y: 5 } })
  println("#{length(segment)} #{length(Dot(Point { x: 0, y: 0 }))}")
  println("#{first_x(Some(Point { x: 3, y: 4 }))} #{first_x(None)}")
  case Pair { t: (5, "five"), f: 2.5 } do
    Pair { t: (n, s), f } -> println("#{n} #{s} #{f}")
  end
  let get_x = fn Point { x } -> x end
  println("#{get_x(Point { x: 42, y: 0 })}")
  println("#{List.map([Point { x: 1, y: 2 }, Point { x: 3, y: 4 }], fn Point { x, y } -> x * y end)}")
end
"##);
    assert_eq!(
        output,
        "origin\non y axis at 5\non x axis at 7\ndiagonal 3\nnext to an axis\nelsewhere\n\
         9\n10 20\nhi box greeting\nsome 2.5\na=1\nb=2\n7 0\n3 -1\n5 five 2.5\n42\n[2, 12]\n"
    );
}

/// A struct pattern's fields must exist, be named once, and hold values of
/// the field's type; the name must be a struct. A match on a struct must
/// cover every value, and the missing ones print as struct patterns.
#[test]
fn struct_pattern_errors_and_coverage() {
    let program = |arms: &str| {
        format!(
            "struct Point do\n  x :: Int\n  y :: Int\nend\ntype Color do\n  Red\nend\n\
             fn f(p :: Point) -> Int do\n  case p do\n{arms}\n  end\nend\n\
             fn main() do\n  println(\"#{{f(Point {{ x: 1, y: 2 }})}}\")\nend\n"
        )
    };
    let unknown = build_error(&program("    Point { z } -> 1\n    _ -> 0"));
    assert!(
        unknown.contains("E0009") && unknown.contains("has no field `z`"),
        "{unknown}"
    );
    assert!(!unknown.contains("redundant"), "{unknown}");
    let duplicate = build_error(&program("    Point { x, x: 2 } -> 1\n    _ -> 0"));
    assert!(duplicate.contains("E0058"), "{duplicate}");
    let not_struct = build_error(&program("    Color { x } -> 1\n    _ -> 0"));
    assert!(
        not_struct.contains("`Color` is not a struct"),
        "{not_struct}"
    );
    let unknown_type = build_error(&program("    Nope { x } -> 1\n    _ -> 0"));
    assert!(
        unknown_type.contains("unknown type `Nope`"),
        "{unknown_type}"
    );
    let mismatch = build_error(&program("    Point { x: \"s\" } -> 1\n    _ -> 0"));
    assert!(
        mismatch.contains("expected `Int`, found `String`"),
        "{mismatch}"
    );
    let missing = build_error(&program("    Point { x: 0 } -> 1"));
    assert!(
        missing.contains("missing: Point { x: _, y: _ }"),
        "{missing}"
    );
    let (warnings, output) = run_with_build_stderr(&program(
        "    Point { x, y } -> x + y\n    Point { x: 0 } -> 2",
    ));
    assert!(warnings.contains("redundant match arm"), "{warnings}");
    assert_eq!(output, "3\n");
    let refutable = build_error(
        "struct Point do\n  x :: Int\n  y :: Int\nend\nfn main() do\n  let Point { x: 0, y } = Point { x: 0, y: 1 }\n  println(\"#{y}\")\nend\n",
    );
    assert!(refutable.contains("must match every value"), "{refutable}");
}

// ── Generic sets and queues ────────────────────────────────────────────

/// Sets hold any element type: strings compare by content, compound
/// elements by their type's Eq and Hash, and every operation, conversion,
/// iteration and comparison agrees on it, also past the size where a set
/// is indexed.
#[test]
fn sets_hold_any_element_type() {
    let output = run(r##"
struct Point do
  x :: Int
  y :: Int
end

fn main() do
  let words = Set.new() |> Set.add("b") |> Set.add("a") |> Set.add("b")
  let copy = Set.add(Set.new(), String.trim(" a "))
  println("#{Set.size(words)} #{Set.contains(words, "a")} #{Set.contains(copy, "a")} #{Set.contains(words, "c")}")
  println("#{words}")
  println("#{Set.to_list(Set.remove(words, "b"))}")
  let pairs = Set.from_list([(1, "one"), (2, "two"), (1, "one")])
  println("#{Set.size(pairs)} #{Set.contains(pairs, (2, "two"))} #{Set.contains(pairs, (2, "zwei"))}")
  let points = Set.new() |> Set.add(Point { x: 1, y: 2 }) |> Set.add(Point { x: 1, y: 2 })
  println("#{Set.size(points)}")
  let many = List.reduce(Range.to_list(0..40), Set.new(), fn acc, i -> Set.add(acc, "k#{i % 25}") end)
  println("#{Set.size(many)} #{Set.contains(many, "k24")} #{Set.contains(many, "k25")}")
  let evens = Set.from_list(["k0", "k2", "k4"])
  println("#{Set.size(Set.intersection(many, evens))} #{Set.size(Set.difference(many, evens))} #{Set.size(Set.union(evens, Set.from_list(["z"])))}")
  println("#{Set.from_list(["x", "y"]) == Set.from_list(["y", String.trim(" x ")])}")
  let floats = Iter.from([1.5, 2.5, 1.5]) |> Set.collect()
  println("#{Set.size(floats)}")
  let collected = Iter.from(["q", "q", "r"]) |> Set.collect()
  for w in collected do
    println(w)
  end
  println("#{words.contains("a")} #{words.size()}")
end
"##);
    assert_eq!(
        output,
        "2 true true false\n#{b, a}\n[a]\n2 true false\n1\n25 true false\n3 22 4\ntrue\n2\nq\nr\ntrue 2\n"
    );
}

/// A module's function bound by a `let` is generic like any function value:
/// each use gets a copy for its own types, with the helpers those types need
/// (`Queue.pop` building its tuple, a struct compared by its Eq, a string
/// sent into a channel copied). The one copy made for no type in particular
/// crashed.
#[test]
fn let_bound_module_functions_specialize_per_use() {
    let output = run(r##"
struct P do
  x :: Int
  y :: Int
end

fn main() do
  let pop = Queue.pop
  let (front, _) = pop(Queue.push(Queue.new(), "first"))
  let (number, _) = pop(Queue.push(Queue.new(), 7))
  println("#{front} #{number}")
  let has = List.contains
  println("#{has([P { x: 1, y: 2 }], P { x: 1, y: 2 })} #{has(["a"], "b")}")
  let put = Channel.try_send
  case Channel.bounded(2, :drop_oldest) do
    Ok(texts) -> do
      let _ = put(texts, "sent #{number}")
      case Channel.recv(texts, 0) do
        Ok(text) -> println(text)
        Err(error) -> println(error)
      end
    end
    Err(error) -> println(error)
  end
end
"##);
    assert_eq!(output, "first 7\ntrue false\nsent 7\n");
}

/// A queue holds any element type, and `Queue.pop` gives it back as the
/// first element of its tuple, small structs included.
#[test]
fn queues_hold_any_element_type() {
    let output = run(r##"
struct Id do
  n :: Int
end

fn main() do
  let q = Queue.new() |> Queue.push("first") |> Queue.push("second")
  let (front, rest) = Queue.pop(q)
  println("#{front} #{Queue.peek(rest)} #{Queue.size(q)} #{Queue.size(rest)}")
  let ids = Queue.push(Queue.new(), Id { n: 7 })
  let (id, empty) = Queue.pop(ids)
  println("#{id.n} #{Queue.is_empty(empty)}")
  let pairs = Queue.push(Queue.new(), (1.5, "x"))
  let ((f, s), _) = Queue.pop(pairs)
  println("#{f} #{s} #{q.size()}")
end
"##);
    assert_eq!(output, "first second 2 1\n7 true\n1.5 x 2\n");
}

/// A generic type named without arguments in an annotation takes inferred
/// ones: `xs :: List` is `List<_>`.
#[test]
fn bare_generic_annotations_infer_their_arguments() {
    let output = run(r##"
fn count(xs :: List) -> Int do
  List.length(xs)
end

fn members(s :: Set) -> Int do
  Set.size(s)
end

fn main() do
  let m :: Map = %{"a" => 1}
  println("#{count([1, 2]) + count(["a"])} #{members(Set.from_list(["x"]))} #{Map.get(m, "a")}")
end
"##);
    assert_eq!(output, "3 1 1\n");
}

/// `Iter.from` iterates over any built-in collection: a list's elements, a
/// map's `(key, value)` pairs, a set's elements, a range's integers.
#[test]
fn iter_from_takes_any_collection() {
    let output = run(r##"
fn main() do
  println("#{Iter.from(0..5) |> Iter.map(fn x -> x * 2 end) |> List.collect()}")
  let m = %{"a" => 1, "b" => 2}
  println("#{Iter.from(m) |> Iter.map(fn ((k, v)) -> "#{k}=#{v}" end) |> List.collect()}")
  println("#{Map.get(Iter.from(m) |> Map.collect(), "b")}")
  let s = Set.from_list(["x", "y"])
  println("#{Iter.from(s) |> Iter.map(fn w -> w <> "!" end) |> List.collect()}")
  println("#{1..4 |> Iter.from() |> Iter.sum()}")
  println("#{Iter.from([3, 4]) |> Iter.count()}")
end
"##);
    assert_eq!(output, "[0, 2, 4, 6, 8]\n[a=1, b=2]\n2\n[x!, y!]\n6\n2\n");
}

#[test]
fn range_map_makes_a_list_of_whatever_its_function_returns() {
    // `Range.map` took only `Int -> Int`; a string or a struct per index
    // needed `Range.to_list` and `List.map`.
    let source = r##"
struct P do
  x :: Int
end

fn main() do
  let names = Range.map(1..4, fn(i) -> "n#{i}" end)
  let halves = Range.map(1..3, fn(i) -> Int.to_float(i) / 2.0 end)
  let pairs = (0..2).map(fn(i) -> (i, i * i) end)
  let ps = Range.map(5..7, fn(i) -> P { x: i } end)
  println("#{String.join(names, ",")} #{halves} #{pairs} #{List.map(ps, fn(p) -> p.x end)}")
  println("#{range_map(1..3, fn(i) -> i > 1 end)} #{range_to_list(1..3)} #{range_filter(1..5, fn(i) -> i > 3 end)}")
end
"##;
    assert_eq!(
        run(source),
        "n1,n2,n3 [0.5, 1.0] [(0, 0), (1, 1)] [5, 6]\n[false, true] [1, 2] [4]\n"
    );
}

/// A self tail call that ends a resource's scope runs as a loop, with the
/// resource dropped before the jump: the scope's own drop after it failed
/// LLVM verification ("Terminator found in the middle of a basic block").
#[test]
fn a_tail_call_ending_a_resource_scope_runs_as_a_loop() {
    let source = r##"
fn walk(n :: Int, total :: Int) -> Int ! CryptoError do
  if n == 0 do
    Ok(total)
  else
    let s = Secret.random(1) ?
    Secret.destroy(s)
    walk(n - 1, total + 1)
  end
end

fn main() do
  case walk(100000, 0) do
    Ok(v) -> println("walked #{v}")
    Err(_) -> println("err")
  end
end
"##;
    assert_eq!(run(source), "walked 100000\n");
}

/// A method called on what an interface call returns: `Add.add(v, v)` is a
/// `V` as soon as its arguments say so.
#[test]
fn an_interface_call_result_takes_methods() {
    let source = r##"
struct V do
  x :: Int
end

impl Add for V do
  type Output = V
  fn add(self, other :: V) -> V do
    V { x: self.x + other.x }
  end
end

fn main() do
  let v = V { x: 2 }
  let w = Add.add(v, v).add(v)
  println("#{w.x}")
end
"##;
    assert_eq!(run(source), "6\n");
}

// alias, cond, monitor, trait, trap and with name nothing in the grammar,
// so they are ordinary names.
#[test]
fn words_other_languages_reserve_are_names() {
    let source = r##"
struct Rule do
  trait :: String
  with :: Int
end

fn alias(cond :: Int) -> Int do
  cond + 1
end

fn main() do
  let trap = alias(2)
  let monitor = Rule { trait: "t", with: trap }
  println("#{monitor.trait} #{monitor.with}")
end
"##;
    assert_eq!(run(source), "t 3\n");
}

/// A tuple passed to or returned from a function value is the pointer to
/// its heap block, as the function takes it: a call through the value
/// passed it as a struct loaded from that pointer, and the callee read a
/// garbage pointer.
#[test]
fn a_function_value_takes_and_returns_tuples() {
    let source = r##"
fn show(p :: (Int, String)) -> String do
  case p do
    (n, s) -> "#{n}:#{s}"
  end
end

fn pair(n :: Int) -> (Int, String) do
  (n, "p#{n}")
end

fn call_it(f :: Fun((Int, String)) -> String, p :: (Int, String)) -> String do
  f(p)
end

fn use_pair(g :: Fun(Int) -> (Int, String)) -> String do
  show(g(7))
end

fn main() do
  let f = show
  println(f((1, "one")))
  println(call_it(show, (2, "two")))
  println(call_it(fn q -> show(q) end, (3, "three")))
  let g = pair
  println(show(g(4)))
  println(use_pair(pair))
  println(use_pair(fn n -> (n * 2, "c") end))
end
"##;
    assert_eq!(run(source), "1:one\n2:two\n3:three\n4:p4\n7:p7\n14:c\n");
}

/// A runtime function that takes a function, used as a value, is a Mesh
/// function value: bound, passed and called like any other. Called through
/// the value it took its function argument as two pointers, where the value
/// passes one, and failed code generation ("Incorrect number of
/// arguments").
#[test]
fn a_runtime_function_taking_a_function_is_a_value() {
    let source = r##"
fn double(x :: Int) -> Int do
  x * 2
end

fn main() do
  let m = List.map
  println("#{List.length(m([1, 2], double))}")
  let fm = List.map
  let halves = fm([1.0, 3.0], fn f -> f / 2.0 end)
  println("#{List.get(halves, 1)}")
  let keep = List.filter
  println("#{List.length(keep([1, 2, 3, 4], fn x -> x > 2 end))}")
  let apply_all = fn f, xs -> f(xs, double) end
  println("#{List.get(apply_all(List.map, [5, 6, 7]), 2)}")
end
"##;
    assert_eq!(run(source), "2\n1.5\n2\n14\n");
}

/// `x |> f(a)?` is `(x |> f(a))?`: the value goes into the call and `?`
/// takes the call's result, bare (`x |> f?`), in a chain, through a slot,
/// for an `Option`, and converting the error by `From`. `?` bound to the
/// call before the value went in, which then lacked an argument.
#[test]
fn a_pipe_into_a_call_then_try() {
    let source = r##"
struct AppError do
  message :: String
end

impl From<String> for AppError do
  fn from(message :: String) -> AppError do
    AppError { message: "app: " <> message }
  end
end

fn parse(text :: String) -> Result<Int, String> do
  case String.to_int(text) do
    Some(n) -> Ok(n)
    None -> Err("not a number: #{text}")
  end
end

fn add(n :: Int, m :: Int) -> Result<Int, String> do
  Ok(n + m)
end

fn total(text :: String) -> Result<Int, String> do
  let n = text |> parse? |> add(1)? |> add(10)?
  Ok(n)
end

fn labelled(text :: String) -> Result<Int, String> do
  let n = parse(text) |> Result.map_err(fn e -> "input: " <> e end)?
  Ok(n)
end

fn subtract(from :: Int, n :: Int) -> Result<Int, String> do
  Ok(from - n)
end

fn slot(n :: Int) -> Result<Int, String> do
  let d = n |2> subtract(100)?
  Ok(d)
end

fn first_big(xs :: List<Int>) -> Option<Int> do
  let x = xs |> List.find(fn x -> x > 10 end)?
  Some(x * 2)
end

fn converted(text :: String) -> Result<Int, AppError> do
  let n = text |> parse?
  Ok(n)
end

fn show(r :: Result<Int, String>) -> String do
  case r do
    Ok(n) -> "#{n}"
    Err(e) -> e
  end
end

fn main() do
  println(show(total("4")) <> " " <> show(total("x")))
  println(show(labelled("x")))
  println(show(slot(30)))
  println("#{Option.unwrap_or(first_big([1, 20]), 0)} #{Option.unwrap_or(first_big([1, 2]), 0)}")
  case converted("y") do
    Ok(n) -> println("#{n}")
    Err(e) -> println(e.message)
  end
end
"##;
    assert_eq!(
        run(source),
        "15 not a number: x\ninput: not a number: x\n70\n40 0\napp: not a number: y\n"
    );
}

/// `to_string(value)` and `inspect(value)` show a value as the method
/// calls and interpolation do, whatever its shape: called bare with a
/// tuple, `inspect` failed code generation ("Undefined variable
/// 'inspect'") and `to_string` found no `Display` for its pointer.
#[test]
fn bare_to_string_and_inspect_show_every_shape() {
    let source = r##"
fn main() do
  println(inspect((1, "x")) <> " " <> to_string((1, 2)) <> " " <> inspect(()))
  println(inspect([(1, "a")]) <> " " <> to_string(["a"]) <> " " <> inspect(Some("s")))
  println(to_string(42) <> " " <> inspect("q") <> " " <> inspect(%{"k" => [1]}))
end
"##;
    assert_eq!(
        run(source),
        "(1, \"x\") (1, 2) ()\n[(1, \"a\")] [a] Some(\"s\")\n42 \"q\" %{\"k\" => [1]}\n"
    );
}

/// A value `from_json` cannot decode names where it failed, as a path from
/// the top of the document: a struct's field, a list's or tuple's index, a
/// map's key, a variant's fields. The error was only "expected Int",
/// wherever in a nested payload the value was.
#[test]
fn a_json_decoding_error_names_its_path() {
    let source = r##"
struct Address do
  city :: String
  zip :: Option<String>
end deriving(Json)

type Shape do
  Circle(Float)
  Rect(Float, Float)
end deriving(Json)

struct Person do
  name :: String
  age :: Int
  tags :: List<String>
  home :: Address
  scores :: Map<String, Int>
  pair :: (Int, String)
  shape :: Shape
end deriving(Json)

fn show(text :: String) -> String do
  case Person.from_json(text) do
    Ok(p) -> "ok #{p.name}"
    Err(e) -> e
  end
end

fn main() do
  let good = "{\"name\":\"A\",\"age\":1,\"tags\":[\"t\"],\"home\":{\"city\":\"c\",\"zip\":null},\"scores\":{\"x\":1},\"pair\":[1,\"a\"],\"shape\":{\"tag\":\"Circle\",\"fields\":[1.0]}}"
  println(show(good))
  println(show("{\"name\":\"A\",\"age\":\"x\"}"))
  println(show("{\"name\":\"A\",\"age\":1,\"tags\":[\"t\",2],\"home\":{\"city\":\"c\",\"zip\":null},\"scores\":{},\"pair\":[1,\"a\"],\"shape\":{\"tag\":\"Circle\",\"fields\":[1.0]}}"))
  println(show("{\"name\":\"A\",\"age\":1,\"tags\":[],\"home\":{\"city\":\"c\",\"zip\":5},\"scores\":{},\"pair\":[1,\"a\"],\"shape\":{\"tag\":\"Circle\",\"fields\":[1.0]}}"))
  println(show("{\"name\":\"A\",\"age\":1,\"tags\":[],\"home\":{\"city\":\"c\",\"zip\":null},\"scores\":{\"k\":true},\"pair\":[1,\"a\"],\"shape\":{\"tag\":\"Circle\",\"fields\":[1.0]}}"))
  println(show("{\"name\":\"A\",\"age\":1,\"tags\":[],\"home\":{\"city\":\"c\",\"zip\":null},\"scores\":{},\"pair\":[1,2],\"shape\":{\"tag\":\"Circle\",\"fields\":[1.0]}}"))
  println(show("{\"name\":\"A\",\"age\":1,\"tags\":[],\"home\":{\"city\":\"c\",\"zip\":null},\"scores\":{},\"pair\":[1,\"a\"],\"shape\":{\"tag\":\"Rect\",\"fields\":[1.0,\"w\"]}}"))
  println(show("{\"name\":\"A\"}"))
end
"##;
    assert_eq!(
        run(source),
        "ok A\n$.age: expected Int\n$.tags[1]: expected String\n$.home.zip: expected String\n\
         $.scores.k: expected Int\n$.pair[1]: expected String\n$.shape.fields[1]: expected Float\n\
         missing field: age\n"
    );
}

/// Code outside every function is an error (E0087): it compiled and never
/// ran, `println` at the top of a file included, and `fn hello do ... end`,
/// a function without parentheses, was such a closure expression (so
/// `hello()` was undefined). A function with no parameters may now leave
/// out its parentheses, as with `def`.
#[test]
fn top_level_code_is_an_error_and_fn_name_do_defines_a_function() {
    let source = r##"
fn version do
  3
end

fn main() do
  println("#{version()}")
end
"##;
    assert_eq!(run(source), "3\n");
    for top in [
        "println(\"top\")",
        "1 + 2",
        "fn x -> x end",
        "module M do\n  println(\"m\")\nend",
    ] {
        let built = build(
            &format!("{top}\n\nfn main() do\n  println(\"m\")\nend\n"),
            false,
        );
        assert!(
            !built.ok && built.stderr.contains("E0087"),
            "{top}: {}",
            built.stderr
        );
    }
}

/// A struct literal names its fields, in any order: each value goes to the
/// field its name gives, and is evaluated where it is written. Code
/// generation stored them by their place in the literal, so a literal in
/// another order than the declaration put a String where an Int belongs.
#[test]
fn struct_literal_fields_go_where_their_names_say() {
    let source = r##"
struct P do
  a :: Int
  b :: String
  c :: Float
end

struct Box<T> do
  first :: T
  label :: String
end

fn noisy(n :: Int) -> Int do
  println("evaluated #{n}")
  n
end

fn main() do
  let p = P { c: 2.5, b: "x", a: noisy(1) }
  println("#{p.a} #{p.b} #{p.c}")
  let q = P { b: "y", a: noisy(2), c: 0.5 }
  println("#{q.a} #{q.b} #{q.c}")
  let boxed = Box { label: "l", first: 7 }
  println("#{boxed.first} #{boxed.label}")
end
"##;
    assert_eq!(
        run(source),
        "evaluated 1\n1 x 2.5\nevaluated 2\n2 y 0.5\n7 l\n"
    );
}

/// The alternatives of an or-pattern match the type the whole pattern
/// does. They were lowered with no type, so a variable an alternative binds
/// inside a generic constructor (`Ok(n) | Err(n)`) had the unsubstituted
/// parameter's type, and the build failed ("Unsupported binop type").
#[test]
fn or_pattern_alternatives_bind_at_the_scrutinee_type() {
    let source = r##"
fn f(r :: Result<Int, Int>) -> Int do
  case r do
    Ok(n) | Err(n) -> n + 1
  end
end

fn g(p :: Option<(Int, String)>) -> String do
  case p do
    Some((1, s)) | Some((2, s)) -> s
    _ -> "other"
  end
end

fn h(p :: Option<Float>) -> Float do
  case p do
    Some(x) | Some(x) -> x * 2.0
    None -> 0.0
  end
end

fn main() do
  let two = Some((2, "two"))
  println("#{f(Ok(1))} #{f(Err(5))} #{g(two)} #{g(None)} #{h(Some(1.5))}")
end
"##;
    assert_eq!(run(source), "2 6 two other 3.0\n");
}

/// A method call runs the method of the receiver's type even when a
/// top-level function has the method's name. The call went to the
/// top-level function, which is private to the module under another name,
/// so the build panicked; with the names matching it would have run the
/// wrong function.
#[test]
fn a_method_call_runs_the_method_whatever_the_top_level_functions() {
    let source = r##"
interface Describe do
  fn describe(self) -> String
end

struct Crate do
  n :: Int
end

impl Describe for Crate do
  fn describe(self) -> String do
    "method #{self.n}"
  end
end

fn describe(c :: Crate) -> String do
  "function #{c.n}"
end

fn main() do
  let c = Crate { n: 4 }
  println(c.describe())
  println(describe(c))
  println(Describe.describe(c))
end
"##;
    assert_eq!(run(source), "method 4\nfunction 4\nmethod 4\n");
}

/// An Option or Result a runtime function returns, written into a tuple
/// that a `case` matches (its values matched as columns), matches its
/// constructor patterns. The column held the pointer the function returned
/// where the value goes, so its tag was the pointer's low byte and
/// `(String.to_int(s), n)` never matched `(Some(a), m)`.
#[test]
fn runtime_options_and_results_match_as_tuple_columns() {
    let source = r##"
fn main() do
  case (U64.parse("5"), Ok(2)) do
    (Ok(a), Ok(b)) -> println("ok #{U64.to_string(a)} #{b}")
    _ -> println("other")
  end
  case (String.to_int("5"), 1) do
    (Some(a), n) -> println("ok #{a} #{n}")
    _ -> println("other")
  end
  case (List.find([1, 2], fn x -> x > 1 end), File.read("/nonexistent/mesh")) do
    (Some(a), Err(_)) -> println("ok #{a}")
    _ -> println("other")
  end
end
"##;
    assert_eq!(run(source), "ok 5 2\nok 5 1\nok 2\n");
}

/// A program may give a built-in type a trait it lacks (`impl Display for
/// Regex`): interpolated, inspected in a list, or called as a method, the
/// value is shown by that impl, and compared by an Eq impl. It type
/// checked, and lowering then said the type had no `Display`.
#[test]
fn a_programs_impls_for_built_in_types_are_used() {
    let source = r##"
impl Display for Regex do
  fn to_string(self) -> String do
    "a regex"
  end
end

impl Eq for Regex do
  fn eq(self, other :: Regex) -> Bool do
    true
  end
end

fn main() do
  let r = ~r/a+/
  println(r.to_string())
  println("#{r} #{[r]}")
  println("#{r == ~r/b/}")
end
"##;
    assert_eq!(run(source), "a regex\na regex [a regex]\ntrue\n");
}

/// A generic function shows a struct by the struct's Display (lowering
/// sees its type only once the function is specialized), and an interface
/// default method whose result nothing fixes builds for a type that never
/// calls it.
#[test]
fn generic_shows_and_unused_open_defaults_build() {
    let source = r##"
struct Point do
  x :: Int
end deriving(Display)

interface Empty do
  fn empty(self) do
    []
  end
end

struct S do
  n :: Int
end

impl Empty for S do
end

fn show(x) do
  "#{x}"
end

fn main() do
  println(show(Point { x: 1 }))
  println(show(S { n: 2 }.n))
end
"##;
    assert_eq!(run(source), "Point(1)\n2\n");
}
