//! Parser integration tests using insta snapshots.
//!
//! Each test parses a Mesh expression/declaration/program, builds the CST,
//! and snapshots the debug tree output to verify correct structure.

use insta::assert_snapshot;
use mesh_parser::ast::expr::{
    BinaryExpr, ClosureClause, ClosureExpr, Expr, ForInExpr, IfExpr, Literal, MatchArm,
};
use mesh_parser::ast::item::{
    FnDef, LetBinding, Param, ParamOwnership, SourceFile, StructDef, SumTypeDef,
};
use mesh_parser::ast::pat::{AsPat, ConstructorPat, OrPat, Pattern};
use mesh_parser::SyntaxKind;
use mesh_parser::{debug_tree, parse, parse_block, parse_expr, AstNode};

fn parse_and_debug(source: &str) -> String {
    let parse = parse_expr(source);
    format_parse(&parse)
}

fn block_and_debug(source: &str) -> String {
    let parse = parse_block(source);
    format_parse(&parse)
}

fn source_and_debug(source: &str) -> String {
    let parse = parse(source);
    format_parse(&parse)
}

fn format_parse(parse: &mesh_parser::Parse) -> String {
    let tree = debug_tree(&parse.syntax());
    if !parse.errors().is_empty() {
        format!(
            "{}\nerrors:\n{}",
            tree,
            parse
                .errors()
                .iter()
                .map(|e| format!("  - {} @{}..{}", e.message, e.span.start, e.span.end))
                .collect::<Vec<_>>()
                .join("\n")
        )
    } else {
        tree
    }
}

// ── Literals ───────────────────────────────────────────────────────────

#[test]
fn literal_int() {
    assert_snapshot!(parse_and_debug("42"));
}

#[test]
fn literal_float() {
    assert_snapshot!(parse_and_debug("3.14"));
}

#[test]
fn literal_true() {
    assert_snapshot!(parse_and_debug("true"));
}

#[test]
fn literal_false() {
    assert_snapshot!(parse_and_debug("false"));
}

#[test]
fn literal_nil() {
    assert_snapshot!(parse_and_debug("nil"));
}

#[test]
fn literal_string() {
    assert_snapshot!(parse_and_debug("\"hello\""));
}

// ── Simple Binary Expressions ──────────────────────────────────────────

#[test]
fn binary_add() {
    assert_snapshot!(parse_and_debug("1 + 2"));
}

#[test]
fn binary_mul_add_precedence() {
    // * binds tighter than +, so: a * b + c => (a * b) + c
    assert_snapshot!(parse_and_debug("a * b + c"));
}

// ── Precedence Chain ───────────────────────────────────────────────────

#[test]
fn precedence_chain() {
    // 1 + 2 * 3 - 4 / 2 => (1 + (2 * 3)) - (4 / 2)
    assert_snapshot!(parse_and_debug("1 + 2 * 3 - 4 / 2"));
}

// ── Unary Prefix ───────────────────────────────────────────────────────

#[test]
fn unary_negate() {
    assert_snapshot!(parse_and_debug("-x"));
}

#[test]
fn unary_bang() {
    assert_snapshot!(parse_and_debug("!flag"));
}

#[test]
fn unary_not_keyword() {
    assert_snapshot!(parse_and_debug("not done"));
}

// ── Unary with Binary ──────────────────────────────────────────────────

#[test]
fn unary_with_binary() {
    // -x + y => (-x) + y (unary binds tighter)
    assert_snapshot!(parse_and_debug("-x + y"));
}

// ── Comparison ─────────────────────────────────────────────────────────

#[test]
fn comparison_eq() {
    assert_snapshot!(parse_and_debug("a == b"));
}

#[test]
fn comparison_lt_with_arithmetic() {
    // x < y + 1 => x < (y + 1) (+ binds tighter than <)
    assert_snapshot!(parse_and_debug("x < y + 1"));
}

// ── Logical ────────────────────────────────────────────────────────────

#[test]
fn logical_and_or() {
    // a and b or c => (a and b) or c (and binds tighter than or)
    assert_snapshot!(parse_and_debug("a and b or c"));
}

// ── Pipe ───────────────────────────────────────────────────────────────

#[test]
fn pipe_simple() {
    assert_snapshot!(parse_and_debug("x |> foo()"));
}

#[test]
fn pipe_chain() {
    // x |> foo() |> bar() => ((x |> foo()) |> bar()) -- left-associative
    assert_snapshot!(parse_and_debug("x |> foo() |> bar()"));
}

// ── Function Calls ─────────────────────────────────────────────────────

#[test]
fn call_no_args() {
    assert_snapshot!(parse_and_debug("foo()"));
}

#[test]
fn call_with_args() {
    assert_snapshot!(parse_and_debug("foo(1, 2, 3)"));
}

#[test]
fn call_with_expr_arg() {
    assert_snapshot!(parse_and_debug("foo(a, b + c)"));
}

// ── Nested Calls ───────────────────────────────────────────────────────

#[test]
fn nested_calls() {
    assert_snapshot!(parse_and_debug("foo(bar(x))"));
}

// ── Field Access ───────────────────────────────────────────────────────

#[test]
fn field_access_single() {
    assert_snapshot!(parse_and_debug("a.b"));
}

#[test]
fn field_access_chain() {
    // a.b.c => (a.b).c -- left-to-right
    assert_snapshot!(parse_and_debug("a.b.c"));
}

#[test]
fn field_access_names_a_keyword_member() {
    // Stdlib functions named like keywords: Expr.alias, Expr.call, Expr.case.
    for member in ["alias", "call", "case", "self", "send", "cast", "json"] {
        let parse = parse_expr(&format!("Expr.{member}(x)"));
        assert!(
            parse.errors().is_empty(),
            "Expr.{member}(x): {:?}",
            parse.errors()
        );
        let field = parse
            .syntax()
            .descendants()
            .find_map(mesh_parser::ast::expr::FieldAccess::cast)
            .and_then(|access| access.field())
            .map(|token| token.text().to_string());
        assert_eq!(field.as_deref(), Some(member));
    }
}

// ── Index Access ───────────────────────────────────────────────────────

#[test]
fn index_access() {
    assert_snapshot!(parse_and_debug("a[0]"));
}

#[test]
fn index_with_expr() {
    assert_snapshot!(parse_and_debug("a[i + 1]"));
}

// ── Mixed Postfix ──────────────────────────────────────────────────────

#[test]
fn mixed_postfix() {
    // a.b(c)[d] => ((a.b)(c))[d]
    assert_snapshot!(parse_and_debug("a.b(c)[d]"));
}

// ── Grouped Expression ─────────────────────────────────────────────────

#[test]
fn grouped_expression() {
    // (a + b) * c => (group(a + b)) * c
    assert_snapshot!(parse_and_debug("(a + b) * c"));
}

// ── String Interpolation ───────────────────────────────────────────────

#[test]
fn string_interpolation() {
    assert_snapshot!(parse_and_debug("\"hello ${name} world\""));
}

// ── Pipe with Calls ────────────────────────────────────────────────────

#[test]
fn pipe_with_calls() {
    assert_snapshot!(parse_and_debug("data |> map(f) |> filter(g)"));
}

// ── Error Cases ────────────────────────────────────────────────────────

#[test]
fn error_missing_lhs() {
    // + by itself should produce an error
    assert_snapshot!(parse_and_debug("+"));
}

// ── Range ──────────────────────────────────────────────────────────────

#[test]
fn range_operator() {
    assert_snapshot!(parse_and_debug("1..10"));
}

// ── Concatenation ──────────────────────────────────────────────────────

#[test]
fn concat_diamond() {
    assert_snapshot!(parse_and_debug("a <> b"));
}

#[test]
fn concat_plus_plus() {
    assert_snapshot!(parse_and_debug("a ++ b"));
}

// ── Tuple ──────────────────────────────────────────────────────────────

#[test]
fn tuple_expression() {
    assert_snapshot!(parse_and_debug("(1, 2, 3)"));
}

#[test]
fn empty_tuple() {
    assert_snapshot!(parse_and_debug("()"));
}

// ── Modulo ─────────────────────────────────────────────────────────────

#[test]
fn modulo_operator() {
    assert_snapshot!(parse_and_debug("a % b"));
}

// ── Let Bindings ──────────────────────────────────────────────────────

#[test]
fn let_simple() {
    assert_snapshot!(block_and_debug("let x = 5"));
}

#[test]
fn let_with_type_annotation() {
    assert_snapshot!(block_and_debug("let name :: String = \"hello\""));
}

#[test]
fn let_multiple_statements() {
    assert_snapshot!(block_and_debug("let x = 1\nlet y = 2"));
}

// ── Return ────────────────────────────────────────────────────────────

#[test]
fn return_with_value() {
    assert_snapshot!(block_and_debug("return x"));
}

#[test]
fn return_with_expr() {
    assert_snapshot!(block_and_debug("return x + 1"));
}

// ── If/Else ───────────────────────────────────────────────────────────

#[test]
fn if_simple() {
    assert_snapshot!(parse_and_debug("if true do\n  1\nend"));
}

#[test]
fn if_else() {
    assert_snapshot!(parse_and_debug("if x > 0 do\n  x\nelse\n  -x\nend"));
}

#[test]
fn if_else_if_else() {
    assert_snapshot!(parse_and_debug(
        "if a do\n  1\nelse if b do\n  2\nelse\n  3\nend"
    ));
}

#[test]
fn if_single_line() {
    assert_snapshot!(parse_and_debug("if true do 1 end"));
}

// ── Case/Match ────────────────────────────────────────────────────────

#[test]
fn case_simple() {
    assert_snapshot!(parse_and_debug(
        "case x do\n  1 -> \"one\"\n  2 -> \"two\"\nend"
    ));
}

#[test]
fn match_boolean() {
    assert_snapshot!(parse_and_debug(
        "match value do\n  true -> 1\n  false -> 0\nend"
    ));
}

// ── Closures ──────────────────────────────────────────────────────────

#[test]
fn closure_single_param() {
    assert_snapshot!(parse_and_debug("fn (x) -> x + 1 end"));
}

#[test]
fn closure_two_params() {
    assert_snapshot!(parse_and_debug("fn (x, y) -> x + y end"));
}

#[test]
fn closure_no_params() {
    assert_snapshot!(parse_and_debug("fn () -> 42 end"));
}

// ── Closures (Phase 12: bare params, do/end, multi-clause, guards) ──

#[test]
fn closure_bare_single_param() {
    assert_snapshot!(parse_and_debug("fn x -> x + 1 end"));
}

#[test]
fn closure_bare_two_params() {
    assert_snapshot!(parse_and_debug("fn x, y -> x + y end"));
}

#[test]
fn closure_bare_param_pattern_matching() {
    assert_snapshot!(parse_and_debug("fn 0 -> 42 end"));
}

#[test]
fn closure_do_end_body() {
    // Use a let binding so the closure is parsed in expression context
    // (at statement level, `fn x do...end` is parsed as a named fn def)
    assert_snapshot!(source_and_debug(
        "let f = fn x do\n  let y = x * 2\n  y + 1\nend"
    ));
}

#[test]
fn closure_do_end_no_params() {
    assert_snapshot!(parse_and_debug("fn do 42 end"));
}

#[test]
fn closure_multi_clause() {
    assert_snapshot!(parse_and_debug("fn 0 -> 42 | n -> n + 1 end"));
}

#[test]
fn closure_multi_clause_three() {
    assert_snapshot!(parse_and_debug("fn 0 -> 42 | 1 -> 99 | n -> n + 1 end"));
}

#[test]
fn closure_guard_clause() {
    assert_snapshot!(parse_and_debug("fn x when x > 0 -> x end"));
}

#[test]
fn closure_multi_clause_with_guards() {
    assert_snapshot!(parse_and_debug("fn x when x > 0 -> x | x -> 0 - x end"));
}

#[test]
fn closure_in_pipe_chain() {
    assert_snapshot!(source_and_debug(
        "fn main() do\n  let list = (1, 2, 3)\n  list |> map(fn x -> x * 2 end)\nend"
    ));
}

#[test]
fn closure_chained_pipes() {
    assert_snapshot!(parse_and_debug(
        "list |> map(fn x -> x + 1 end) |> filter(fn x -> x > 3 end)"
    ));
}

#[test]
fn closure_nested_do_end_in_body() {
    assert_snapshot!(parse_and_debug("fn x -> if x > 0 do x else 0 - x end end"));
}

#[test]
fn closure_paren_params_still_work() {
    // Confirms existing parenthesized syntax is unchanged
    assert_snapshot!(parse_and_debug("fn (x) -> x + 1 end"));
}

#[test]
fn closure_constructor_pattern() {
    assert_snapshot!(parse_and_debug("fn Some(x) -> x | None -> 0 end"));
}

#[test]
fn closure_wildcard_param() {
    assert_snapshot!(parse_and_debug("fn _ -> 42 end"));
}

#[test]
fn closure_tuple_pattern_param() {
    assert_snapshot!(parse_and_debug("fn (a, b) -> a + b end"));
}

#[test]
fn closure_pipe_inside_closure_body() {
    assert_snapshot!(parse_and_debug("fn x -> x |> to_string() end"));
}

#[test]
fn closure_missing_end_error() {
    assert_snapshot!(parse_and_debug("fn x -> x + 1"));
}

// ── Blocks ────────────────────────────────────────────────────────────

#[test]
fn block_multi_statement() {
    assert_snapshot!(block_and_debug("let x = 1\nx + 1"));
}

// ── Trailing Closures ────────────────────────────────────────────────

#[test]
fn trailing_closure_basic() {
    assert_snapshot!(parse_and_debug("run() do\n  42\nend"));
}

// ── Error Cases (compound) ───────────────────────────────────────────

#[test]
fn error_if_missing_end() {
    assert_snapshot!(parse_and_debug("if x do\n  1\n"));
}

#[test]
fn error_let_missing_ident() {
    assert_snapshot!(block_and_debug("let = 5"));
}

// ── Newline Significance ─────────────────────────────────────────────

#[test]
fn newlines_inside_parens_ignored() {
    assert_snapshot!(parse_and_debug("foo(\n  1,\n  2\n)"));
}

// ── Return bare (no value) ───────────────────────────────────────────

#[test]
fn return_bare() {
    assert_snapshot!(block_and_debug("return"));
}

// ── Case with when guard ─────────────────────────────────────────────

#[test]
fn case_with_when_guard() {
    assert_snapshot!(parse_and_debug(
        "case x do\n  n when n > 0 -> n\n  _ -> 0\nend"
    ));
}

// ═══════════════════════════════════════════════════════════════════════
// Plan 02-04: Declarations, Patterns, and Types
// ═══════════════════════════════════════════════════════════════════════

// ── Function Definitions ─────────────────────────────────────────────

#[test]
fn fn_def_simple() {
    assert_snapshot!(source_and_debug("fn greet(name) do\n  \"hello\"\nend"));
}

#[test]
fn fn_def_pub() {
    assert_snapshot!(source_and_debug("pub fn add(x, y) do\n  x + y\nend"));
}

#[test]
fn fn_def_typed_params_and_return() {
    assert_snapshot!(source_and_debug(
        "fn typed(x :: Int, y :: Int) -> Int do\n  x + y\nend"
    ));
}

#[test]
fn fn_def_borrow_parameter() {
    assert_snapshot!(source_and_debug(
        "fn derive(root :: borrow SecretBytes) do\n  root\nend"
    ), @r#"
    SOURCE_FILE@0..51
      FN_DEF@0..51
        FN_KW@0..2 "fn"
        WHITESPACE@2..3 " "
        NAME@3..9
          IDENT@3..9 "derive"
        PARAM_LIST@9..37
          L_PAREN@9..10 "("
          PARAM@10..36
            IDENT@10..14 "root"
            WHITESPACE@14..15 " "
            TYPE_ANNOTATION@15..36
              COLON_COLON@15..17 "::"
              WHITESPACE@17..18 " "
              OWNERSHIP_MODIFIER@18..24
                IDENT@18..24 "borrow"
              WHITESPACE@24..25 " "
              IDENT@25..36 "SecretBytes"
          R_PAREN@36..37 ")"
        WHITESPACE@37..38 " "
        DO_KW@38..40 "do"
        BLOCK@40..48
          NEWLINE@40..41 "\n"
          WHITESPACE@41..43 "  "
          NAME_REF@43..47
            IDENT@43..47 "root"
          NEWLINE@47..48 "\n"
        END_KW@48..51 "end"
      EOF@51..51 ""
    "#);
}

#[test]
fn fn_def_consume_parameter() {
    assert_snapshot!(source_and_debug(
        "fn destroy(secret :: consume SecretBytes) do\nend"
    ), @r#"
    SOURCE_FILE@0..48
      FN_DEF@0..48
        FN_KW@0..2 "fn"
        WHITESPACE@2..3 " "
        NAME@3..10
          IDENT@3..10 "destroy"
        PARAM_LIST@10..41
          L_PAREN@10..11 "("
          PARAM@11..40
            IDENT@11..17 "secret"
            WHITESPACE@17..18 " "
            TYPE_ANNOTATION@18..40
              COLON_COLON@18..20 "::"
              WHITESPACE@20..21 " "
              OWNERSHIP_MODIFIER@21..28
                IDENT@21..28 "consume"
              WHITESPACE@28..29 " "
              IDENT@29..40 "SecretBytes"
          R_PAREN@40..41 ")"
        WHITESPACE@41..42 " "
        DO_KW@42..44 "do"
        BLOCK@44..45
          NEWLINE@44..45 "\n"
        END_KW@45..48 "end"
      EOF@48..48 ""
    "#);
}

#[test]
fn def_keyword() {
    assert_snapshot!(source_and_debug("def greet(name) do\n  \"hello\"\nend"));
}

#[test]
fn fn_def_no_params() {
    assert_snapshot!(source_and_debug("fn hello() do\n  \"world\"\nend"));
}

// ── Module Definitions ──────────────────────────────────────────────

#[test]
fn module_simple() {
    assert_snapshot!(source_and_debug(
        "module Math do\n  pub fn add(x, y) do\n    x + y\n  end\nend"
    ));
}

#[test]
fn module_nested() {
    assert_snapshot!(source_and_debug(
        "module Outer do\n  module Inner do\n  end\nend"
    ));
}

// ── Import Declarations ─────────────────────────────────────────────

#[test]
fn import_simple() {
    assert_snapshot!(source_and_debug("import Math"));
}

#[test]
fn import_dotted_path() {
    assert_snapshot!(source_and_debug("import Foo.Bar.Baz"));
}

#[test]
fn from_import() {
    assert_snapshot!(source_and_debug("from Math import sqrt, pow"));
}

#[test]
fn from_import_paren() {
    assert_snapshot!(source_and_debug("from Math import (sqrt, pow)"));
}

#[test]
fn from_import_paren_trailing_comma() {
    assert_snapshot!(source_and_debug("from Math import (sqrt, pow,)"));
}

#[test]
fn from_import_paren_multiline() {
    assert_snapshot!(source_and_debug("from Math import (\n  sqrt,\n  pow\n)"));
}

// ── Struct Definitions ──────────────────────────────────────────────

#[test]
fn struct_simple() {
    assert_snapshot!(source_and_debug(
        "struct Point do\n  x :: Float\n  y :: Float\nend"
    ));
}

#[test]
fn struct_pub_with_generics() {
    assert_snapshot!(source_and_debug(
        "pub struct Pair<A, B> do\n  first :: A\n  second :: B\nend"
    ));
}

#[test]
fn opaque_resource_declaration() {
    assert_snapshot!(source_and_debug("resource X25519PrivateKey"), @r#"
    SOURCE_FILE@0..25
      STRUCT_DEF@0..25
        RESOURCE_MODIFIER@0..8
          IDENT@0..8 "resource"
        WHITESPACE@8..9 " "
        NAME@9..25
          IDENT@9..25 "X25519PrivateKey"
      EOF@25..25 ""
    "#);
}

#[test]
fn public_opaque_resource_declaration() {
    assert_snapshot!(source_and_debug("pub resource StorageKey"), @r#"
    SOURCE_FILE@0..23
      STRUCT_DEF@0..23
        VISIBILITY@0..3
          PUB_KW@0..3 "pub"
        WHITESPACE@3..4 " "
        RESOURCE_MODIFIER@4..12
          IDENT@4..12 "resource"
        WHITESPACE@12..13 " "
        NAME@13..23
          IDENT@13..23 "StorageKey"
      EOF@23..23 ""
    "#);
}

#[test]
fn resource_remains_contextual_outside_declaration_syntax() {
    assert_snapshot!(source_and_debug("resource()"), @r#"
    SOURCE_FILE@0..10
      CALL_EXPR@0..10
        NAME_REF@0..8
          IDENT@0..8 "resource"
        ARG_LIST@8..10
          L_PAREN@8..9 "("
          R_PAREN@9..10 ")"
      EOF@10..10 ""
    "#);
}

#[test]
fn resource_struct_declaration() {
    assert_snapshot!(source_and_debug(
        "resource struct RatchetSecrets do\n  root_key :: SecretBytes\nend"
    ), @r#"
    SOURCE_FILE@0..63
      STRUCT_DEF@0..63
        RESOURCE_MODIFIER@0..8
          IDENT@0..8 "resource"
        WHITESPACE@8..9 " "
        STRUCT_KW@9..15 "struct"
        WHITESPACE@15..16 " "
        NAME@16..30
          IDENT@16..30 "RatchetSecrets"
        WHITESPACE@30..31 " "
        DO_KW@31..33 "do"
        NEWLINE@33..34 "\n"
        WHITESPACE@34..36 "  "
        STRUCT_FIELD@36..59
          NAME@36..44
            IDENT@36..44 "root_key"
          WHITESPACE@44..45 " "
          TYPE_ANNOTATION@45..59
            COLON_COLON@45..47 "::"
            WHITESPACE@47..48 " "
            IDENT@48..59 "SecretBytes"
        NEWLINE@59..60 "\n"
        END_KW@60..63 "end"
      EOF@63..63 ""
    "#);
}

// ── Pattern Matching ────────────────────────────────────────────────

#[test]
fn case_with_literal_patterns() {
    assert_snapshot!(parse_and_debug(
        "case x do\n  0 -> \"zero\"\n  _ -> \"other\"\nend"
    ));
}

#[test]
fn let_tuple_destructure() {
    assert_snapshot!(source_and_debug("let (a, b) = pair"));
}

#[test]
fn case_with_tuple_patterns() {
    assert_snapshot!(parse_and_debug(
        "case point do\n  (0, 0) -> \"origin\"\n  (x, y) -> \"other\"\nend"
    ));
}

#[test]
fn case_with_negative_literal() {
    assert_snapshot!(parse_and_debug(
        "case x do\n  -1 -> \"neg\"\n  0 -> \"zero\"\n  1 -> \"pos\"\nend"
    ));
}

#[test]
fn case_with_string_pattern() {
    assert_snapshot!(parse_and_debug(
        "case s do\n  \"hello\" -> 1\n  _ -> 0\nend"
    ));
}

// ── Full Programs (integration) ─────────────────────────────────────

#[test]
fn full_program_module_with_fns() {
    let source = "\
module Math do
  pub fn add(x, y) do
    x + y
  end

  pub fn sub(x, y) do
    x - y
  end
end";
    assert_snapshot!(source_and_debug(source));
}

#[test]
fn full_program_imports_and_pipes() {
    let source = "\
import IO
from Math import sqrt

fn main() do
  42 |> sqrt() |> IO.puts()
end";
    assert_snapshot!(source_and_debug(source));
}

#[test]
fn full_program_struct_and_fn() {
    let source = "\
struct Point do
  x :: Float
  y :: Float
end

fn distance(p :: Point) -> Float do
  p.x + p.y
end";
    assert_snapshot!(source_and_debug(source));
}

// ── Error Cases (declarations) ──────────────────────────────────────

#[test]
fn error_fn_missing_name() {
    assert_snapshot!(source_and_debug("fn do end"));
}

#[test]
fn error_glob_import() {
    assert_snapshot!(source_and_debug("from Math import *"));
}

// ── Public parse() API end-to-end ───────────────────────────────────

#[test]
fn parse_api_simple_expression() {
    // parse() should work with simple expressions
    assert_snapshot!(source_and_debug("1 + 2"));
}

#[test]
fn parse_api_let_binding() {
    assert_snapshot!(source_and_debug("let x = 42"));
}

// ═══════════════════════════════════════════════════════════════════════
// Plan 02-05: Typed AST Wrappers and Comprehensive Tests
// ═══════════════════════════════════════════════════════════════════════

// ── Full Program Snapshot Tests ──────────────────────────────────────

#[test]
fn full_complete_module() {
    let source = "\
module StringUtils do
  pub fn upcase(s :: String) -> String do
    s
  end

  pub fn downcase(s :: String) -> String do
    s
  end

  fn helper(x) do
    x
  end
end";
    assert_snapshot!(source_and_debug(source));
}

#[test]
fn full_program_with_imports_pipes_closures() {
    let source = "\
import IO
from List import map, filter

fn main() do
  let nums = (1, 2, 3, 4, 5)
  nums |> filter(fn (x) -> x > 2 end) |> map(fn (x) -> x * 2 end)
end";
    assert_snapshot!(source_and_debug(source));
}

#[test]
fn full_nested_if_else_with_case() {
    let source = "\
fn classify(x) do
  if x > 0 do
    case x do
      1 -> \"one\"
      2 -> \"two\"
      _ -> \"many\"
    end
  else if x == 0 do
    \"zero\"
  else
    \"negative\"
  end
end";
    assert_snapshot!(source_and_debug(source));
}

#[test]
fn full_struct_definition_and_usage() {
    let source = "\
pub struct Point<T> do
  x :: T
  y :: T
end

fn origin() -> Point do
  let p = Point
  p
end

fn translate(p :: Point, dx :: Float, dy :: Float) -> Point do
  p
end";
    assert_snapshot!(source_and_debug(source));
}

#[test]
fn full_multiple_imports_and_nested_modules() {
    let source = "\
import IO
import Math
from String import split, join, trim

module App do
  module Config do
    fn default() do
      42
    end
  end

  pub fn run() do
    let cfg = Config.default()
    cfg |> IO.inspect()
  end
end";
    assert_snapshot!(source_and_debug(source));
}

#[test]
fn full_pattern_matching_program() {
    let source = "\
fn fibonacci(n) do
  case n do
    0 -> 0
    1 -> 1
    _ -> fibonacci(n - 1) + fibonacci(n - 2)
  end
end

fn classify_pair(pair) do
  case pair do
    (0, 0) -> \"origin\"
    (x, 0) -> \"x-axis\"
    (0, y) -> \"y-axis\"
    (x, y) -> \"general\"
  end
end";
    assert_snapshot!(source_and_debug(source));
}

#[test]
fn full_closure_and_higher_order() {
    let source = "\
fn apply(f, x) do
  f(x)
end

fn compose(f, g) do
  fn (x) -> f(g(x)) end
end

fn main() do
  let double = fn (x) -> x * 2 end
  let inc = fn (x) -> x + 1 end
  let double_then_inc = compose(inc, double)
  apply(double_then_inc, 5)
end";
    assert_snapshot!(source_and_debug(source));
}

#[test]
fn full_chained_pipes_and_field_access() {
    let source = "\
fn process(data) do
  data.items
    |> filter(fn (x) -> x.active end)
    |> map(fn (x) -> x.value end)
end";
    assert_snapshot!(source_and_debug(source));
}

// ── AST Accessor Tests ──────────────────────────────────────────────

#[test]
fn ast_fn_def_accessors() {
    let p = parse("pub fn add(x, y) do\n  x + y\nend");
    assert!(p.ok(), "parse errors: {:?}", p.errors());
    let tree = p.tree();
    let fn_def: FnDef = tree.fn_defs().next().expect("should have fn def");

    // Visibility
    assert!(fn_def.visibility().is_some(), "should have pub visibility");

    // Name
    let name = fn_def.name().expect("should have name");
    assert_eq!(name.text().unwrap(), "add");

    // Param list
    let param_list = fn_def.param_list().expect("should have param list");
    let params: Vec<_> = param_list.params().collect();
    assert_eq!(params.len(), 2);
    assert_eq!(params[0].name().unwrap().text(), "x");
    assert_eq!(params[1].name().unwrap().text(), "y");

    // Body
    assert!(fn_def.body().is_some(), "should have body block");
}

#[test]
fn ast_fn_def_with_return_type() {
    let p = parse("fn typed(x :: Int) -> Int do\n  x\nend");
    assert!(p.ok(), "parse errors: {:?}", p.errors());
    let tree = p.tree();
    let fn_def: FnDef = tree.fn_defs().next().expect("should have fn def");

    // No visibility
    assert!(fn_def.visibility().is_none());

    // Return type
    let ret_type = fn_def.return_type().expect("should have return type");
    assert_eq!(ret_type.type_name().unwrap().text(), "Int");

    // Param with type annotation
    let param_list = fn_def.param_list().unwrap();
    let param = param_list.params().next().unwrap();
    assert_eq!(param.name().unwrap().text(), "x");
    let ann = param
        .type_annotation()
        .expect("should have type annotation");
    assert_eq!(ann.type_name().unwrap().text(), "Int");
}

#[test]
fn ast_parameter_ownership_preserves_the_annotated_type() {
    let p = parse(
        "fn transfer(data :: Bytes, view :: borrow SecretBytes, owned :: consume SecretBytes) do\nend",
    );
    assert!(p.ok(), "parse errors: {:?}", p.errors());

    let fn_def = p.tree().fn_defs().next().expect("should have fn def");
    let params: Vec<_> = fn_def
        .param_list()
        .expect("should have params")
        .params()
        .collect();
    assert_eq!(params.len(), 3);

    assert_eq!(params[0].ownership(), ParamOwnership::Move);
    assert_eq!(params[1].ownership(), ParamOwnership::Borrow);
    assert_eq!(params[2].ownership(), ParamOwnership::Consume);
    assert_eq!(
        params[1]
            .type_annotation()
            .and_then(|annotation| annotation.type_name())
            .map(|token| token.text().to_string()),
        Some("SecretBytes".to_string())
    );
}

#[test]
fn lone_borrow_identifier_remains_a_type_name() {
    let p = parse("fn view(value :: borrow) do\nend");
    assert!(p.ok(), "parse errors: {:?}", p.errors());

    let parameter = p
        .tree()
        .fn_defs()
        .next()
        .and_then(|function| function.param_list())
        .and_then(|parameters| parameters.params().next())
        .expect("should have parameter");
    assert_eq!(parameter.ownership(), ParamOwnership::Move);
    assert_eq!(
        parameter
            .type_annotation()
            .and_then(|annotation| annotation.type_name())
            .map(|token| token.text().to_string()),
        Some("borrow".to_string())
    );
}

#[test]
fn closure_parameter_supports_borrow_ownership() {
    let p = parse_expr("fn (root :: borrow SecretBytes) -> root end");
    assert!(p.ok(), "parse errors: {:?}", p.errors());

    let closure = p
        .syntax()
        .children()
        .find_map(ClosureExpr::cast)
        .expect("should have closure");
    let parameter = closure
        .param_list()
        .expect("should have parameter list")
        .params()
        .next()
        .expect("should have parameter");
    assert_eq!(parameter.ownership(), ParamOwnership::Borrow);
}

#[test]
fn trailing_closure_parameter_supports_consume_ownership() {
    let p = parse_expr("run() do |secret :: consume SecretBytes|\n  secret\nend");
    assert!(p.ok(), "parse errors: {:?}", p.errors());

    let parameter = p
        .syntax()
        .descendants()
        .find_map(Param::cast)
        .expect("should have trailing closure parameter");
    assert_eq!(parameter.ownership(), ParamOwnership::Consume);
}

#[test]
fn ast_let_binding_accessors() {
    let p = parse("let x :: Int = 5");
    assert!(p.ok(), "parse errors: {:?}", p.errors());
    let tree = p.tree();

    let let_binding: LetBinding = tree
        .syntax()
        .children()
        .find_map(LetBinding::cast)
        .expect("should have let binding");

    // Name
    let name = let_binding.name().expect("should have name");
    assert_eq!(name.text().unwrap(), "x");

    // Type annotation
    let ann = let_binding
        .type_annotation()
        .expect("should have type annotation");
    assert_eq!(ann.type_name().unwrap().text(), "Int");

    // Initializer
    let init = let_binding.initializer().expect("should have initializer");
    match init {
        mesh_parser::ast::expr::Expr::Literal(_) => {} // expected
        other => panic!("expected Literal, got {:?}", other),
    }
}

#[test]
fn ast_if_expr_accessors() {
    let p = parse_expr("if true do 1 else 2 end");
    assert!(p.ok(), "parse errors: {:?}", p.errors());
    let root = p.syntax();

    let if_expr: IfExpr = root
        .children()
        .find_map(IfExpr::cast)
        .expect("should have if expr");

    // Condition
    let cond = if_expr.condition().expect("should have condition");
    match cond {
        mesh_parser::ast::expr::Expr::Literal(_) => {} // true
        other => panic!("expected Literal condition, got {:?}", other),
    }

    // Then branch
    assert!(if_expr.then_branch().is_some(), "should have then branch");

    // Else branch
    let else_br = if_expr.else_branch().expect("should have else branch");
    assert!(else_br.block().is_some(), "else should have a block");
}

#[test]
fn ast_struct_def_accessors() {
    let p = parse("pub struct Point do\n  x :: Float\n  y :: Float\nend");
    assert!(p.ok(), "parse errors: {:?}", p.errors());
    let tree = p.tree();

    let struct_def: StructDef = tree
        .syntax()
        .children()
        .find_map(StructDef::cast)
        .expect("should have struct def");

    // Visibility
    assert!(struct_def.visibility().is_some());

    // Name
    assert_eq!(struct_def.name().unwrap().text().unwrap(), "Point");

    // Fields
    let fields: Vec<_> = struct_def.fields().collect();
    assert_eq!(fields.len(), 2);
    assert_eq!(fields[0].name().unwrap().text().unwrap(), "x");
    assert_eq!(
        fields[0]
            .type_annotation()
            .unwrap()
            .type_name()
            .unwrap()
            .text(),
        "Float"
    );
    assert_eq!(fields[1].name().unwrap().text().unwrap(), "y");
}

#[test]
fn ast_resource_def_accessors_distinguish_opaque_and_aggregate_resources() {
    let p = parse(
        "resource SecretBytes\nresource struct RatchetSecrets do\n  root_key :: SecretBytes\nend\nstruct PublicData do\n  value :: Bytes\nend",
    );
    assert!(p.ok(), "parse errors: {:?}", p.errors());

    let definitions: Vec<_> = p
        .tree()
        .syntax()
        .children()
        .filter_map(StructDef::cast)
        .collect();
    assert_eq!(definitions.len(), 3);

    assert!(definitions[0].is_declared_resource());
    assert!(definitions[0].is_opaque_resource());
    assert!(definitions[0].fields().next().is_none());

    assert!(definitions[1].is_declared_resource());
    assert!(!definitions[1].is_opaque_resource());
    assert_eq!(definitions[1].fields().count(), 1);

    assert!(!definitions[2].is_declared_resource());
    assert!(!definitions[2].is_opaque_resource());
}

#[test]
fn ast_source_file_items() {
    let source = "\
fn foo() do 1 end
fn bar() do 2 end";
    let p = parse(source);
    assert!(p.ok(), "parse errors: {:?}", p.errors());
    let tree = p.tree();

    let fns: Vec<_> = tree.fn_defs().collect();
    assert_eq!(fns.len(), 2);
    assert_eq!(fns[0].name().unwrap().text().unwrap(), "foo");
    assert_eq!(fns[1].name().unwrap().text().unwrap(), "bar");
}

#[test]
fn ast_binary_expr_accessors() {
    let p = parse_expr("1 + 2");
    assert!(p.ok(), "parse errors: {:?}", p.errors());
    let root = p.syntax();

    let binary: BinaryExpr = root
        .children()
        .find_map(BinaryExpr::cast)
        .expect("should have binary expr");

    // LHS
    let lhs = binary.lhs().expect("should have lhs");
    match lhs {
        mesh_parser::ast::expr::Expr::Literal(_) => {}
        other => panic!("expected Literal lhs, got {:?}", other),
    }

    // RHS
    let rhs = binary.rhs().expect("should have rhs");
    match rhs {
        mesh_parser::ast::expr::Expr::Literal(_) => {}
        other => panic!("expected Literal rhs, got {:?}", other),
    }

    // Operator
    let op = binary.op().expect("should have op token");
    assert_eq!(op.text(), "+");
}

#[test]
fn ast_literal_token() {
    let p = parse_expr("42");
    assert!(p.ok());
    let root = p.syntax();

    let lit: Literal = root
        .children()
        .find_map(Literal::cast)
        .expect("should have literal");

    let token = lit.token().expect("should have token");
    assert_eq!(token.text(), "42");
}

#[test]
fn ast_import_accessors() {
    let p = parse("from Foo.Bar import baz, qux");
    assert!(p.ok(), "parse errors: {:?}", p.errors());
    let tree = p.tree();

    let from_import: mesh_parser::ast::item::FromImportDecl = tree
        .syntax()
        .children()
        .find_map(mesh_parser::ast::item::FromImportDecl::cast)
        .expect("should have from import");

    let path = from_import.module_path().expect("should have module path");
    assert_eq!(path.segments(), vec!["Foo", "Bar"]);

    let import_list = from_import.import_list().expect("should have import list");
    let names: Vec<_> = import_list.names().map(|n| n.text().unwrap()).collect();
    assert_eq!(names, vec!["baz", "qux"]);
}

#[test]
fn ast_module_accessors() {
    let source = "\
pub module Math do
  pub fn add(x, y) do
    x + y
  end
end";
    let p = parse(source);
    assert!(p.ok(), "parse errors: {:?}", p.errors());
    let tree = p.tree();

    let module: mesh_parser::ast::item::ModuleDef =
        tree.modules().next().expect("should have module");

    assert!(module.visibility().is_some());
    assert_eq!(module.name().unwrap().text().unwrap(), "Math");

    let items: Vec<_> = module.items().collect();
    assert_eq!(items.len(), 1);
    match &items[0] {
        mesh_parser::ast::item::Item::FnDef(_) => {}
        other => panic!("expected FnDef, got {:?}", other),
    }
}

#[test]
fn ast_parse_tree_convenience() {
    let p = parse("fn hello() do 42 end");
    assert!(p.ok());
    let tree: SourceFile = p.tree();
    let fn_def = tree.fn_defs().next().unwrap();
    assert_eq!(fn_def.name().unwrap().text().unwrap(), "hello");
}

// ── Error Message Quality Tests ─────────────────────────────────────

#[test]
fn recovery_reports_independent_syntax_and_lex_errors_at_their_tokens() {
    let source = concat!(
        "fn a() do\n  let = 1\nend\n",
        "fn b() do\n  for x [1] do\n    x\n  end\nend\n",
        "fn c() = 1 ^ 2\n",
        "pub fn d() = 3 $ 4\n",
        "fn e() = \"unfinished",
    );
    assert_parse_errors(
        source,
        &[
            ("P0001", "let =", 4, 1),
            ("P0002", "[1]", 0, 1),
            ("P0101", "^", 0, 1),
            ("P0101", "$", 0, 1),
            ("P0102", "\"unfinished", 0, 1),
        ],
    );
}

#[test]
fn recovery_skips_the_broken_item_tail() {
    for tail in [
        "end",
        "  if true do\n    let = 2\n  end\nend",
        "  f(\nfn -> end\n  )\nend",
        "  fn nested() do\n    let = 2\n  end\nend",
        "fn nested() do\n    let = 2\nend\nend",
        "  let closure = fn -> 1 end\n  fn nested() do\n    let = 2\n  end\nend",
    ] {
        let source = format!("fn main() do\n  let = 1\n{tail}");
        assert_parse_errors(&source, &[("P0001", "let =", 4, 1)]);
    }
}

#[test]
fn recovery_caps_diagnostics_and_keeps_the_source_lossless() {
    let source: String = (0..40)
        .map(|id| format!("fn bad{id}() do\n  let = {id}\nend\n"))
        .collect();
    let expected: Vec<_> = source
        .match_indices('=')
        .take(20)
        .map(|(at, _)| at)
        .collect();
    let parsed = parse(&source);
    assert_eq!(parsed.errors().len(), 20);
    for (error, at) in parsed.errors().iter().zip(expected) {
        assert_eq!(error.code.id(), "P0001");
        assert_eq!(
            error.span,
            mesh_common::span::Span::new(at as u32, at as u32 + 1)
        );
    }
    assert_eq!(parsed.syntax().text().to_string(), source);
}

#[test]
fn recovery_resumes_after_unclosed_delimiters_and_blocks() {
    for (body, code) in [
        ("  f(1\n", "P0003"),
        ("  f(\n", "P0003"),
        ("  1\n", "P0004"),
    ] {
        let source = format!("fn a() do\n{body}fn broken() do\n  let = 1\nend\nfn good() = 2\n");
        assert_parse_errors(
            &source,
            &[(code, "fn broken", 0, 2), ("P0001", "let =", 4, 1)],
        );
        let parsed = parse(&source);
        let names: Vec<_> = parsed
            .tree()
            .fn_defs()
            .map(|f| f.name().unwrap().text().unwrap())
            .collect();
        assert_eq!(names, ["a", "broken", "good"]);
    }
}

#[test]
fn recovery_respects_declaration_boundaries_without_changing_valid_nesting() {
    let source = "module Outer do\nfn nested() = 1\nend\nfn outer() = 2";
    let parsed = parse(source);
    assert!(parsed.ok(), "{:?}", parsed.errors());
    let names: Vec<_> = parsed
        .tree()
        .fn_defs()
        .map(|f| f.name().unwrap().text().unwrap())
        .collect();
    assert_eq!(names, ["outer"]);

    let source = "struct MissingEnd do\n  field :: Int\nfn next() = 1 ^ 2";
    assert_parse_errors(source, &[("P0004", "fn next", 0, 2), ("P0101", "^", 0, 1)]);

    let source = "let = 1; let = 2\n  fn next() = 1 ^ 2";
    assert_parse_errors(
        source,
        &[
            ("P0001", "= 1", 0, 1),
            ("P0001", "= 2", 0, 1),
            ("P0101", "^", 0, 1),
        ],
    );
}

#[test]
fn recovery_bounds_adversarial_nesting() {
    let statements = [
        format!("fn bad() = {}1", "(".repeat(4096)),
        format!("fn bad() = a{}", " + a".repeat(30_000)),
        format!("fn bad(x :: {}Int", "(".repeat(4096)),
        format!("fn bad({}x", "(".repeat(4096)),
        "module Nested do ".repeat(4096),
        format!(
            "fn bad() = if true do 1 {}",
            "else if true do 1 ".repeat(4096)
        ),
    ];
    for statement in statements {
        let source = format!("{statement}\n");
        let parsed = parse(&source);
        assert_eq!(parsed.errors().len(), 1);
        assert!(parsed.errors()[0].message.contains("nested too deeply"));
        assert_eq!(
            parsed.errors()[0].repair.as_deref(),
            Some("Break this deeply nested expression or block into helper functions or `let` bindings.")
        );
        assert_eq!(parsed.syntax().text().to_string(), source);
    }
}

#[test]
fn deep_but_reasonable_nesting_parses() {
    let parens = format!("fn f() = {}1{}\n", "(".repeat(250), ")".repeat(250));
    let blocks = format!(
        "fn f() do\n{}1\n{}end\n",
        "if true do\n".repeat(125),
        "end\n".repeat(125)
    );
    let chain = format!("fn f() = a{}\n", " + a".repeat(4000));
    for source in [parens, blocks, chain] {
        let parsed = parse(&source);
        assert!(parsed.errors().is_empty(), "{:?}", parsed.errors());
    }
}

fn assert_parse_errors(source: &str, expected: &[(&str, &str, usize, usize)]) {
    use mesh_common::span::Span;

    let parsed = parse(source);
    assert_eq!(
        parsed.errors().len(),
        expected.len(),
        "{source}\n{:?}",
        parsed.errors()
    );
    for (error, &(code, needle, offset, width)) in parsed.errors().iter().zip(expected) {
        let start = source.find(needle).unwrap() + offset;
        assert_eq!(error.code.id(), code, "{source}\n{error:?}");
        assert_eq!(
            error.span,
            Span::new(start as u32, (start + width) as u32),
            "{source}\n{error:?}"
        );
    }
    assert_eq!(parsed.syntax().text().to_string(), source);
}

#[test]
fn error_fn_missing_end_references_do_span() {
    // fn foo() do 1 (missing end) -> error should reference the do span
    let p = parse("fn foo() do\n  1\n");
    assert!(!p.ok());
    let err = &p.errors()[0];
    assert!(
        err.message.contains("end"),
        "error should mention `end`: {}",
        err.message
    );
    assert!(
        err.related.is_some(),
        "error should have related span referencing `do`"
    );
    let (related_msg, related_span) = err.related.as_ref().unwrap();
    assert_eq!(err.code.id(), "P0004");
    assert_eq!(related_msg, "block opened here");
    assert_eq!(
        &"fn foo() do\n  1\n"[related_span.start as usize..related_span.end as usize],
        "do"
    );
}

#[test]
fn error_two_statements_on_one_line() {
    // Once parsed as two statements: a bare `assert_raises` and a closure.
    for source in [
        "test(\"t\") do\n  assert_raises fn() do\n    assert(false)\n  end\nend\n",
        "fn main() do\n  let a = 1 let b = 2\nend\n",
        "let a = 1 let b = 2\n",
        "fn f(r) do\n  case r do\n    Ok(v) ->\n      log(v) v\n    Err(_) -> 0\n  end\nend\n",
        "actor a() do\n  let n = 1 println(\"#{n}\")\nend\n",
    ] {
        let p = parse(source);
        assert_eq!(
            p.errors().first().map(|e| e.message.as_str()),
            Some("expected a newline or `;` after the statement"),
            "{source}"
        );
    }
}

#[test]
fn statements_end_at_newlines_inside_delimiters_and_at_semicolons() {
    for source in [
        "fn main() do\n  map(xs, fn x do\n    let y = x * 2\n    y\n  end)\nend\n",
        "fn main() do\n  let a = 1; let b = 2\n  if a do a else b end\nend\n",
        "let a = 1; let b = 2\n",
    ] {
        let p = parse(source);
        assert!(p.ok(), "{source}: {:?}", p.errors());
    }
}

#[test]
fn error_glob_import_message() {
    // from Math import * -> error about glob imports
    let p = parse("from Math import *");
    assert!(!p.ok());
    let err = &p.errors()[0];
    assert!(
        err.message.contains("glob"),
        "error should mention glob: {}",
        err.message
    );
}

#[test]
fn error_let_missing_identifier_message() {
    // let = 5 -> error about missing identifier
    let p = parse("let = 5");
    assert!(!p.ok());
    let err = &p.errors()[0];
    assert!(
        err.message.contains("identifier") || err.message.contains("pattern"),
        "error should mention identifier or pattern: {}",
        err.message
    );
}

#[test]
fn error_if_missing_do() {
    // if true 1 end -> error about missing do
    let p = parse_expr("if true 1 end");
    assert!(!p.ok());
    let err = &p.errors()[0];
    assert!(
        err.message.contains("DO_KW")
            || err.message.contains("do")
            || err.message.contains("expected"),
        "error should mention do: {}",
        err.message
    );
}

#[test]
fn error_struct_missing_name() {
    let p = parse("struct do end");
    assert!(!p.ok());
    let err = &p.errors()[0];
    assert!(
        err.message.contains("name") || err.message.contains("struct"),
        "error should mention struct name: {}",
        err.message
    );
}

#[test]
fn error_module_missing_end() {
    let p = parse("module Foo do\n  fn bar() do 1 end\n");
    assert!(!p.ok());
    let err = &p.errors()[0];
    assert!(
        err.message.contains("end"),
        "error should mention `end`: {}",
        err.message
    );
}

// ── Lossless Round-Trip Tests ───────────────────────────────────────
//
// The lexer strips whitespace (by design -- whitespace tokens are not emitted).
// Newlines ARE preserved as tokens. The CST round-trip preserves all token text:
// stripping spaces from the source should match the CST text exactly.

fn assert_lossless_roundtrip(source: &str) {
    let p = parse(source);
    let tree_text = p.syntax().text().to_string();
    assert_eq!(
        tree_text, source,
        "round-trip failed: CST text does not match source"
    );
}

#[test]
fn lossless_simple_let() {
    assert_lossless_roundtrip("let x = 5");
}

#[test]
fn lossless_fn_def() {
    assert_lossless_roundtrip("fn add(x, y) do\n  x + y\nend");
}

/// A source that starts with a space or tab: the gap before the first token
/// has to land inside the root, or rowan panics on a second top-level element.
/// The release fuzzer found it with a single space.
#[test]
fn lossless_leading_whitespace() {
    for source in [" ", "\t", " x", "  fn main() do\nend\n", "\tlet x = 1"] {
        assert_lossless_roundtrip(source);
        let _ = mesh_parser::parse_expr(source).syntax();
        let _ = mesh_parser::parse_block(source).syntax();
    }
}

/// A program cut off anywhere still parses, losslessly: every line prefix
/// of the e2e fixtures, and every token prefix of the formatter's torture
/// file, which uses every construct. Cut-off input reaches the recovery and
/// look-past-the-end paths a whole program never does.
#[test]
fn every_prefix_of_a_program_parses_losslessly() {
    let root = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../..");
    let mut fixtures: Vec<_> = std::fs::read_dir(root.join("tests/e2e"))
        .expect("tests/e2e is readable")
        .map(|entry| entry.expect("a directory entry").path())
        .filter(|path| path.extension().is_some_and(|ext| ext == "mpl"))
        .collect();
    fixtures.sort();
    assert!(fixtures.len() > 100, "found {} fixtures", fixtures.len());
    for path in fixtures {
        let source = std::fs::read_to_string(&path).expect("a fixture is UTF-8");
        let ends = source.match_indices('\n').map(|(i, _)| i + 1);
        for end in ends.chain([source.len()]) {
            assert_lossless_roundtrip(&source[..end]);
        }
    }
    let torture = std::fs::read_to_string(root.join("compiler/mesh-fmt/tests/comments.mpl"))
        .expect("the torture file is readable");
    for token in mesh_lexer::Lexer::tokenize(&torture) {
        let start = token.span.start as usize;
        assert_lossless_roundtrip(&torture[..start]);
        let _ = mesh_parser::inline_modules(&torture[..start], &parse(&torture[..start]));
    }
}

/// Forms that are valid but rare: trailing commas, fields separated by new
/// lines, `;` between statements, and closures with pattern parameters.
#[test]
fn less_common_forms_parse_without_errors() {
    let sources = [
        "fn f() do\n  (1, 2,)\nend",
        "fn f(p) do\n  %{p | x: 1\n    y: 2}\nend",
        "fn f() do\n  json {}\nend",
        "fn f(p) do\n  %{p | x: 1, y: 2}\nend",
        "fn f() do\n  P { x: 0\n    y: 0 }\nend",
        "fn f() do\n  [1, 2,]\nend",
        "fn f() do\n  g(1, 2,)\nend",
        "fn f(p) do\n  case p do\n    Point { x: 0, y } ->\n      y\n    _ -> 0\n  end\nend",
        "fn f(x) do\n  case x do\n    1 ->\n      g(\n        2\n      )\n    _ -> 0\n  end\nend",
        "fn f(v) do\n  g(case v do\n    1 ->\n      let y = 2\n      h(y)\n    other ->\n      other\n  end)\nend",
        "fn f(v) do\n  [case v do\n    Point { x: 0 } ->\n      1\n    Point { x: 1, y } -> y\n  end]\nend",
        "fn f() do\n  fn 0 -> 1 | n when n > 0 -> n | _ -> 0 end\nend",
        "fn f() do\n  fn 0 -> 1 | -1 -> 2 | n -> n end\nend",
        "fn f([]) = 0",
        "struct S do\n  has_many :posts, Post\n  belongs_to :user, User\nend",
        "struct S do\n  table \"people\"\n  primary_key :uuid\nend",
        "fn f<T, U>(x :: T, y :: U) -> String where T: Show, U: Eq do\n  x\nend",
        "impl Convert<Int, String> for Meters do\nend",
        "pub interface I do\n  fn f(self) -> Int\nend",
        "pub supervisor S do\n  strategy: one_for_one\nend",
        "fn f(p) do\n  let Geo.Point { x } = p\n  x\nend",
        "fn f(x) do\n  case x do\n    (a, b,) -> a\n    [c, d,] -> c\n  end\nend",
        "fn f(\"a\") = 1",
        "fn f(h :: []) = h",
        "actor A(x :: Int,) do\n  x\nend",
        "fn f() do\n  g() do |x,|\n    x\n  end\nend",
        "fn f() do\n  json { a: 1\n    b: 2 }\nend",
        "fn f() do\n  g(a: 1, b: 2,)\nend",
        "fn f() do\n  1;; 2\n  3; 4\nend",
        "fn f(x) do\n  case x do\n    1 ->\n      2; 3\n    _ -> 4\n  end\nend",
        "fn f(x) do\n  case x do 1 -> 2; _ -> 4 end\nend",
        "fn f(x) do\n  case x do\n    1 ->\n      g(\n        2\n      )\n    _ -> 0\n  end\nend",
        "fn f(x) do\n  case x do\n    1 -> 2;\n    _ -> 4;\n  end\nend",
        "actor A() do\n  receive do\n    n -> n; after 10 -> 0;\n  end\nend",
        "fn f() do\n  fn 0 -> 1 | n do\n    n\n  end end\nend",
        "fn f() do\n  fn -1 -> 1 | n -> n end\nend",
        "fn f(a, b,) do\n  a\nend",
        "fn f() do\n  fn (a, b,) -> a end\nend",
        "fn f() do\n  fn (-1) -> 1 | (n) -> n end\nend",
        "fn f() do\n  g() do |x, y|\n    x\n  end\nend",
        "fn f(m) do\n  for {k, v,} in m do\n    k\n  end\nend",
        "struct S<T,> do\n  x :: T\nend",
        "fn f(g :: Fun(Int,) -> Int, t :: (Int, String,)) do\n  1\nend",
        "fn f(x :: List<Int,>) do\n  1\nend",
        "type T do\n  A(Int, String,)\nend",
        "struct S do\n  timestamps false\nend",
        "impl Show for Int do\n  pub fn show(self) -> String do\n    \"i\"\n  end;\nend",
        "actor A() do\n  receive do\n    _ -> 1\n  end;\nend",
        "service S do\n  fn init() -> Int do\n    0\n  end;\n  call Get() :: Int do |s|\n    (s, s)\n  end\nend",
        "supervisor S do\n  strategy: one_for_one;\n  child c do\n    start: fn -> 1 end;\n    restart: permanent\n    shutdown: brutal_kill\n  end\nend",
        "interface I do\n  fn f(self) -> Int do\n    1\n  end;\nend",
    ];
    for source in sources {
        let parse = parse(source);
        assert!(parse.ok(), "{source:?}: {:?}", parse.errors());
        assert_eq!(parse.syntax().text().to_string(), source);
    }
}

/// Inputs at the edge of the grammar parse, whatever they report.
#[test]
fn edge_inputs_parse_losslessly() {
    for source in [
        "fn f(x :: List<>) do\n  1\nend",
        "impl Convert<Int,> for Meters do\nend",
        "type T do\n  A()\nend",
        "fn f<T>(x :: T) -> String where T: Fmt.Show do\n  x\nend",
        "fn f(xs) do\n  case xs do\n    h :: [] -> h\n  end\nend",
        "fn f() do\n  \"abc\\",
        "fn f() do\n  g() do | |\n    1\n  end\nend",
        "fn f() do\n  fn x, -> x end\nend",
        "struct S<> do\nend",
        "impl Convert<> for Meters do\nend",
        "struct S do\n  has_many :posts Post\nend",
        "struct S do\n  table \"people\nend",
        "fn f(p) do\n  case p do\n    Point { x: } -> 1\n  end\nend",
        "impl Show for Int where T: Show do\nend",
    ] {
        assert_lossless_roundtrip(source);
    }
}

#[test]
fn lossless_if_else() {
    assert_lossless_roundtrip("if true do\n  1\nelse\n  2\nend");
}

#[test]
fn lossless_case_expr() {
    assert_lossless_roundtrip("case x do\n  1 -> \"one\"\n  _ -> \"other\"\nend");
}

#[test]
fn lossless_struct_def() {
    assert_lossless_roundtrip("struct Point do\n  x :: Float\n  y :: Float\nend");
}

#[test]
fn lossless_import() {
    assert_lossless_roundtrip("import Foo.Bar");
}

#[test]
fn lossless_from_import() {
    assert_lossless_roundtrip("from Math import sqrt, pow");
}

#[test]
fn lossless_pipe_chain() {
    assert_lossless_roundtrip("fn main() do\n  x |> foo() |> bar()\nend");
}

#[test]
fn lossless_closure() {
    assert_lossless_roundtrip("fn (x) -> x + 1 end");
}

// ═══════════════════════════════════════════════════════════════════════
// Plan 03-01: Phase 3 Syntax (interface, impl, type alias, generics)
// ═══════════════════════════════════════════════════════════════════════

// ── Angle Bracket Generics ──────────────────────────────────────────

#[test]
fn struct_angle_bracket_generics() {
    assert_snapshot!(source_and_debug("struct Foo<T> do\n  x :: T\nend"));
}

// ── Interface Definition ────────────────────────────────────────────

#[test]
fn interface_simple() {
    assert_snapshot!(source_and_debug(
        "interface Printable do\n  fn to_string(self) -> String\nend"
    ));
}

#[test]
fn interface_with_generic() {
    assert_snapshot!(source_and_debug(
        "interface Container<T> do\n  fn get(self) -> T\n  fn set(self, value :: T)\nend"
    ));
}

// ── Interface Method with Default Body ──────────────────────────────

#[test]
fn interface_method_with_default_body() {
    let source =
        "interface Describable do\n  fn describe(self) -> String do\n    \"unknown\"\n  end\nend";
    let parse = parse(source);
    assert!(
        parse.errors().is_empty(),
        "Expected no parse errors, got: {:?}",
        parse.errors()
    );
    let root = SourceFile::cast(parse.syntax()).unwrap();
    let items: Vec<_> = root.items().collect();
    assert_eq!(items.len(), 1);
    if let mesh_parser::ast::item::Item::InterfaceDef(iface) = &items[0] {
        let methods: Vec<_> = iface.methods().collect();
        assert_eq!(methods.len(), 1);
        let method = &methods[0];
        assert_eq!(
            method.name().and_then(|n| n.text()),
            Some("describe".to_string())
        );
        assert!(method.body().is_some(), "Expected default body to be Some");
    } else {
        panic!("Expected InterfaceDef");
    }
}

#[test]
fn interface_method_without_body() {
    let source = "interface Describable do\n  fn describe(self) -> String\nend";
    let parse = parse(source);
    assert!(
        parse.errors().is_empty(),
        "Expected no parse errors, got: {:?}",
        parse.errors()
    );
    let root = SourceFile::cast(parse.syntax()).unwrap();
    let items: Vec<_> = root.items().collect();
    assert_eq!(items.len(), 1);
    if let mesh_parser::ast::item::Item::InterfaceDef(iface) = &items[0] {
        let methods: Vec<_> = iface.methods().collect();
        assert_eq!(methods.len(), 1);
        let method = &methods[0];
        assert_eq!(
            method.name().and_then(|n| n.text()),
            Some("describe".to_string())
        );
        assert!(
            method.body().is_none(),
            "Expected body to be None for signature-only method"
        );
    } else {
        panic!("Expected InterfaceDef");
    }
}

// ── Impl Block ──────────────────────────────────────────────────────

#[test]
fn impl_simple() {
    assert_snapshot!(source_and_debug(
        "impl Printable for Int do\n  fn to_string(self) -> String do\n    \"int\"\n  end\nend"
    ));
}

// ── Type Alias ──────────────────────────────────────────────────────

#[test]
fn type_alias_simple() {
    assert_snapshot!(source_and_debug("type Alias = Int"));
}

#[test]
fn type_alias_generic() {
    assert_snapshot!(source_and_debug("type StringResult<T> = Result<T, String>"));
}

#[test]
fn type_alias_pub() {
    assert_snapshot!(source_and_debug("pub type Url = String"));
}

// ── Option Sugar ────────────────────────────────────────────────────

#[test]
fn option_sugar_in_type() {
    // Int? should produce a QUESTION token after IDENT "Int"
    assert_snapshot!(source_and_debug("fn foo(x :: Int?) do\n  x\nend"));
}

// ── Result Sugar ────────────────────────────────────────────────────

#[test]
fn result_sugar_in_type() {
    // T!E should produce BANG token between T and E types
    assert_snapshot!(source_and_debug("fn bar(x :: String!Error) do\n  x\nend"));
}

// ── Function with Where Clause ──────────────────────────────────────

#[test]
fn fn_with_where_clause() {
    assert_snapshot!(source_and_debug(
        "fn print<T>(x :: T) where T: Printable do\n  x\nend"
    ));
}

// ── Function with Generic Params ────────────────────────────────────

#[test]
fn fn_with_generic_params() {
    assert_snapshot!(source_and_debug("fn identity<T>(x :: T) -> T do\n  x\nend"));
}

#[test]
fn lossless_full_program() {
    let source = "\
module Math do
  pub fn add(x, y) do
    x + y
  end
end";
    assert_lossless_roundtrip(source);
}

// ═══════════════════════════════════════════════════════════════════════
// Plan 04-01: Sum Types, Constructor Patterns, Or/As Patterns
// ═══════════════════════════════════════════════════════════════════════

// ── Sum Type Definitions ────────────────────────────────────────────

#[test]
fn sum_type_simple() {
    assert_snapshot!(source_and_debug(
        "type Shape do\n  Circle(Float)\n  Rectangle(width :: Float, height :: Float)\n  Point\nend"
    ));
}

#[test]
fn sum_type_stops_at_a_malformed_variant() {
    // The unclosed variant is the error; the variants after it are not read
    // as more of the same mistake.
    let parse = parse("type Shape do\n  Circle(Float\n  Square\nend\n");
    let messages: Vec<&str> = parse.errors().iter().map(|e| e.message.as_str()).collect();
    assert_eq!(messages, ["expected `)` to close `(`, found `Square`"]);
    assert_eq!(parse.errors()[0].code.id(), "P0003");
}

#[test]
fn sum_type_generic() {
    assert_snapshot!(source_and_debug(
        "type Option<T> do\n  Some(T)\n  None\nend"
    ));
}

#[test]
fn sum_type_multiple_positional() {
    assert_snapshot!(source_and_debug("type Pair do\n  Pair(Int, Int)\nend"));
}

// ── Constructor Patterns ────────────────────────────────────────────

#[test]
fn pattern_constructor_qualified() {
    assert_snapshot!(parse_and_debug(
        "case x do\n  Shape.Circle(r) -> r\n  _ -> 0\nend"
    ));
}

#[test]
fn pattern_constructor_unqualified() {
    assert_snapshot!(parse_and_debug("case x do\n  Some(v) -> v\n  _ -> 0\nend"));
}

#[test]
fn pattern_constructor_nested() {
    assert_snapshot!(parse_and_debug(
        "case x do\n  Some(Circle(r)) -> r\n  _ -> 0\nend"
    ));
}

#[test]
fn pattern_constructor_qualified_no_args() {
    assert_snapshot!(parse_and_debug(
        "case x do\n  Shape.Point -> 1\n  _ -> 0\nend"
    ));
}

// ── Or Patterns ─────────────────────────────────────────────────────

#[test]
fn pattern_or_simple() {
    assert_snapshot!(parse_and_debug(
        "case x do\n  Circle(_) | Point -> 1\n  _ -> 0\nend"
    ));
}

#[test]
fn pattern_or_triple() {
    assert_snapshot!(parse_and_debug(
        "case x do\n  1 | 2 | 3 -> true\n  _ -> false\nend"
    ));
}

// ── As Patterns ─────────────────────────────────────────────────────

#[test]
fn pattern_as_simple() {
    assert_snapshot!(parse_and_debug(
        "case x do\n  Circle(r) as c -> c\n  _ -> x\nend"
    ));
}

// ── Combined Patterns ───────────────────────────────────────────────

#[test]
fn pattern_or_with_constructors() {
    assert_snapshot!(parse_and_debug(
        "case x do\n  Some(1) | Some(2) -> true\n  _ -> false\nend"
    ));
}

// ── Lossless Round-Trip for Sum Types ───────────────────────────────

#[test]
fn lossless_sum_type() {
    assert_lossless_roundtrip("type Shape do\n  Circle(Float)\n  Point\nend");
}

// ── AST Accessor Tests (Phase 04-01) ─────────────────────────────────

#[test]
fn ast_sum_type_def_accessors() {
    let p = parse("type Shape do\n  Circle(Float)\n  Rectangle(width :: Float, height :: Float)\n  Point\nend");
    assert!(p.ok(), "parse errors: {:?}", p.errors());
    let tree = p.tree();

    let sum_type: SumTypeDef = tree
        .syntax()
        .children()
        .find_map(SumTypeDef::cast)
        .expect("should have sum type def");

    // Name
    assert_eq!(sum_type.name().unwrap().text().unwrap(), "Shape");

    // No visibility
    assert!(sum_type.visibility().is_none());

    // Variants
    let variants: Vec<_> = sum_type.variants().collect();
    assert_eq!(variants.len(), 3);

    // First variant: Circle(Float) - positional
    assert_eq!(variants[0].name().unwrap().text(), "Circle");
    let pos_types: Vec<_> = variants[0].positional_types().collect();
    assert_eq!(pos_types.len(), 1);
    assert_eq!(pos_types[0].type_name().unwrap().text(), "Float");

    // Second variant: Rectangle(width :: Float, height :: Float) - named fields
    assert_eq!(variants[1].name().unwrap().text(), "Rectangle");
    let fields: Vec<_> = variants[1].fields().collect();
    assert_eq!(fields.len(), 2);
    assert_eq!(fields[0].name().unwrap().text().unwrap(), "width");
    assert_eq!(
        fields[0]
            .type_annotation()
            .unwrap()
            .type_name()
            .unwrap()
            .text(),
        "Float"
    );
    assert_eq!(fields[1].name().unwrap().text().unwrap(), "height");

    // Third variant: Point - nullary
    assert_eq!(variants[2].name().unwrap().text(), "Point");
    assert_eq!(variants[2].fields().count(), 0);
    assert_eq!(variants[2].positional_types().count(), 0);
}

#[test]
fn ast_constructor_pat_qualified() {
    let p = parse_expr("case x do\n  Shape.Circle(r) -> r\n  _ -> 0\nend");
    assert!(p.ok(), "parse errors: {:?}", p.errors());
    let root = p.syntax();

    // Find the CONSTRUCTOR_PAT via tree traversal
    fn find_constructor_pat(node: &mesh_parser::SyntaxNode) -> Option<ConstructorPat> {
        if let Some(pat) = ConstructorPat::cast(node.clone()) {
            return Some(pat);
        }
        for child in node.children() {
            if let Some(pat) = find_constructor_pat(&child) {
                return Some(pat);
            }
        }
        None
    }

    let ctor = find_constructor_pat(&root).expect("should have constructor pattern");

    assert!(ctor.is_qualified());
    assert_eq!(ctor.type_name().unwrap().text(), "Shape");
    assert_eq!(ctor.variant_name().unwrap().text(), "Circle");

    let fields: Vec<_> = ctor.fields().collect();
    assert_eq!(fields.len(), 1);
    match &fields[0] {
        Pattern::Ident(ident) => assert_eq!(ident.name().unwrap().text(), "r"),
        other => panic!("expected ident pattern, got {:?}", other),
    }
}

#[test]
fn ast_constructor_pat_unqualified() {
    let p = parse_expr("case x do\n  Some(v) -> v\n  _ -> 0\nend");
    assert!(p.ok(), "parse errors: {:?}", p.errors());
    let root = p.syntax();

    fn find_constructor_pat(node: &mesh_parser::SyntaxNode) -> Option<ConstructorPat> {
        if let Some(pat) = ConstructorPat::cast(node.clone()) {
            return Some(pat);
        }
        for child in node.children() {
            if let Some(pat) = find_constructor_pat(&child) {
                return Some(pat);
            }
        }
        None
    }

    let ctor = find_constructor_pat(&root).expect("should have constructor pattern");

    assert!(!ctor.is_qualified());
    assert!(ctor.type_name().is_none());
    assert_eq!(ctor.variant_name().unwrap().text(), "Some");

    let fields: Vec<_> = ctor.fields().collect();
    assert_eq!(fields.len(), 1);
}

#[test]
fn ast_or_pat_accessors() {
    let p = parse_expr("case x do\n  1 | 2 | 3 -> true\n  _ -> false\nend");
    assert!(p.ok(), "parse errors: {:?}", p.errors());
    let root = p.syntax();

    fn find_or_pat(node: &mesh_parser::SyntaxNode) -> Option<OrPat> {
        if let Some(pat) = OrPat::cast(node.clone()) {
            return Some(pat);
        }
        for child in node.children() {
            if let Some(pat) = find_or_pat(&child) {
                return Some(pat);
            }
        }
        None
    }

    let or_pat = find_or_pat(&root).expect("should have or-pattern");
    let alts: Vec<_> = or_pat.alternatives().collect();
    assert_eq!(alts.len(), 3, "should have 3 alternatives");
}

#[test]
fn ast_as_pat_accessors() {
    let p = parse_expr("case x do\n  Circle(r) as c -> c\n  _ -> x\nend");
    assert!(p.ok(), "parse errors: {:?}", p.errors());
    let root = p.syntax();

    fn find_as_pat(node: &mesh_parser::SyntaxNode) -> Option<AsPat> {
        if let Some(pat) = AsPat::cast(node.clone()) {
            return Some(pat);
        }
        for child in node.children() {
            if let Some(pat) = find_as_pat(&child) {
                return Some(pat);
            }
        }
        None
    }

    let as_pat = find_as_pat(&root).expect("should have as-pattern");

    // Inner pattern
    let inner = as_pat.pattern().expect("should have inner pattern");
    match inner {
        Pattern::Constructor(_) => {} // expected
        other => panic!("expected constructor pattern, got {:?}", other),
    }

    // Binding name
    assert_eq!(as_pat.binding_name().unwrap().text(), "c");
}

#[test]
fn ast_sum_type_in_items() {
    let source = "type Shape do\n  Circle(Float)\n  Point\nend\n\nfn foo() do\n  1\nend";
    let p = parse(source);
    assert!(p.ok(), "parse errors: {:?}", p.errors());
    let tree = p.tree();

    let items: Vec<_> = tree.items().collect();
    assert_eq!(items.len(), 2);
    match &items[0] {
        mesh_parser::ast::item::Item::SumTypeDef(_) => {} // expected
        other => panic!("expected SumTypeDef, got {:?}", other),
    }
    match &items[1] {
        mesh_parser::ast::item::Item::FnDef(_) => {} // expected
        other => panic!("expected FnDef, got {:?}", other),
    }
}

// =======================================================================
// Plan 06-02: Actor Syntax (actor blocks, spawn/send/receive/self/link, terminate)
// =======================================================================

// -- Actor Block Definition --

#[test]
fn actor_def_simple() {
    assert_snapshot!(source_and_debug("actor Counter do\n  0\nend"));
}

#[test]
fn actor_def_with_params() {
    assert_snapshot!(source_and_debug(
        "actor Counter(state) do\n  state + 1\nend"
    ));
}

#[test]
fn actor_def_with_terminate_clause() {
    let source = "\
actor Worker(state) do
  state
  terminate do
    state
  end
end";
    assert_snapshot!(source_and_debug(source));
}

// -- Spawn Expression --

#[test]
fn spawn_expr_simple() {
    assert_snapshot!(parse_and_debug("spawn(counter, 0)"));
}

#[test]
fn spawn_expr_no_args() {
    assert_snapshot!(parse_and_debug("spawn(worker)"));
}

// -- Send Expression --

#[test]
fn send_expr_simple() {
    assert_snapshot!(parse_and_debug("send(pid, 42)"));
}

// -- Receive Expression --

#[test]
fn receive_expr_single_arm() {
    assert_snapshot!(parse_and_debug("receive do\n  x -> x\nend"));
}

#[test]
fn receive_expr_multiple_arms() {
    assert_snapshot!(parse_and_debug("receive do\n  1 -> 10\n  2 -> 20\nend"));
}

#[test]
fn receive_expr_with_after() {
    assert_snapshot!(parse_and_debug(
        "receive do\n  x -> x\nafter 5000 -> 0\nend"
    ));
}

// -- Self Expression --

#[test]
fn self_expr() {
    assert_snapshot!(parse_and_debug("self()"));
}

// -- Link Expression --

#[test]
fn link_expr_simple() {
    assert_snapshot!(parse_and_debug("link(other_pid)"));
}

// -- Actor in Context --

#[test]
fn actor_with_receive_and_send() {
    let source = "\
actor EchoServer do
  receive do
    msg -> send(msg, msg)
  end
end";
    assert_snapshot!(source_and_debug(source));
}

// -- AST Accessor Tests --

#[test]
fn ast_actor_def_accessors() {
    use mesh_parser::ast::item::ActorDef;
    let p = parse("actor Counter(state) do\n  state\nend");
    assert!(p.ok(), "parse errors: {:?}", p.errors());
    let tree = p.tree();

    let actor: ActorDef = tree
        .syntax()
        .children()
        .find_map(ActorDef::cast)
        .expect("should have actor def");

    assert_eq!(actor.name().unwrap().text().unwrap(), "Counter");
    assert!(actor.param_list().is_some(), "should have param list");
    assert!(actor.body().is_some(), "should have body block");
    assert!(actor.terminate_clause().is_none(), "no terminate clause");
}

#[test]
fn ast_actor_def_with_terminate() {
    use mesh_parser::ast::item::ActorDef;
    let source = "actor Worker do\n  0\n  terminate do\n    1\n  end\nend";
    let p = parse(source);
    assert!(p.ok(), "parse errors: {:?}", p.errors());
    let tree = p.tree();

    let actor: ActorDef = tree
        .syntax()
        .children()
        .find_map(ActorDef::cast)
        .expect("should have actor def");

    assert_eq!(actor.name().unwrap().text().unwrap(), "Worker");
    let tc = actor
        .terminate_clause()
        .expect("should have terminate clause");
    assert!(tc.body().is_some(), "terminate clause should have body");
}

#[test]
fn ast_actor_in_items() {
    let source = "actor Foo do 1 end\n\nfn bar() do 2 end";
    let p = parse(source);
    assert!(p.ok(), "parse errors: {:?}", p.errors());
    let tree = p.tree();

    let items: Vec<_> = tree.items().collect();
    assert_eq!(items.len(), 2);
    match &items[0] {
        mesh_parser::ast::item::Item::ActorDef(_) => {}
        other => panic!("expected ActorDef, got {:?}", other),
    }
    match &items[1] {
        mesh_parser::ast::item::Item::FnDef(_) => {}
        other => panic!("expected FnDef, got {:?}", other),
    }
}

// ── Service Definition ──────────────────────────────────────────────

#[test]
fn service_def_simple() {
    assert_snapshot!(source_and_debug(
        "service Counter do\n  fn init(start_val :: Int) -> Int do\n    start_val\n  end\nend"
    ));
}

#[test]
fn service_def_with_call_handler() {
    assert_snapshot!(source_and_debug(
        "service Counter do\n  call GetCount() :: Int do |state|\n    (state, state)\n  end\nend"
    ));
}

#[test]
fn service_def_with_cast_handler() {
    assert_snapshot!(source_and_debug(
        "service Counter do\n  cast Reset() do |state|\n    0\n  end\nend"
    ));
}

#[test]
fn service_def_full() {
    let source = "\
service Counter do
  fn init(start_val :: Int) -> Int do
    start_val
  end

  call GetCount() :: Int do |state|
    (state, state)
  end

  call Increment(amount :: Int) :: Int do |state|
    (state + amount, state + amount)
  end

  cast Reset() do |state|
    0
  end
end";
    assert_snapshot!(source_and_debug(source));
}

#[test]
fn ast_service_def_accessors() {
    let source = "\
service Counter do
  fn init(start_val :: Int) -> Int do
    start_val
  end

  call GetCount() :: Int do |state|
    (state, state)
  end

  call Increment(amount :: Int) :: Int do |state|
    (state + amount, state + amount)
  end

  cast Reset() do |state|
    0
  end
end";
    let p = parse(source);
    assert!(p.ok(), "parse errors: {:?}", p.errors());
    let tree = p.tree();

    let items: Vec<_> = tree.items().collect();
    assert_eq!(items.len(), 1);

    match &items[0] {
        mesh_parser::ast::item::Item::ServiceDef(svc) => {
            // Name
            assert_eq!(svc.name().unwrap().text().unwrap(), "Counter");

            // Init fn
            let init = svc.init_fn().expect("should have init fn");
            assert_eq!(init.name().unwrap().text().unwrap(), "init");

            // Call handlers
            let calls = svc.call_handlers();
            assert_eq!(calls.len(), 2);
            assert_eq!(calls[0].name().unwrap().text().unwrap(), "GetCount");
            assert_eq!(calls[0].state_param_name().unwrap(), "state");
            assert!(calls[0].return_type().is_some());
            assert_eq!(calls[1].name().unwrap().text().unwrap(), "Increment");
            assert_eq!(calls[1].state_param_name().unwrap(), "state");
            assert!(calls[1].params().is_some());

            // Cast handlers
            let casts = svc.cast_handlers();
            assert_eq!(casts.len(), 1);
            assert_eq!(casts[0].name().unwrap().text().unwrap(), "Reset");
            assert_eq!(casts[0].state_param_name().unwrap(), "state");
        }
        other => panic!("expected ServiceDef, got {:?}", other),
    }
}

#[test]
fn ast_service_in_items() {
    let source = "service Foo do\n  cast Bar() do |s|\n    s\n  end\nend\n\nfn baz() do 1 end";
    let p = parse(source);
    assert!(p.ok(), "parse errors: {:?}", p.errors());
    let tree = p.tree();

    let items: Vec<_> = tree.items().collect();
    assert_eq!(items.len(), 2);
    match &items[0] {
        mesh_parser::ast::item::Item::ServiceDef(_) => {}
        other => panic!("expected ServiceDef, got {:?}", other),
    }
    match &items[1] {
        mesh_parser::ast::item::Item::FnDef(_) => {}
        other => panic!("expected FnDef, got {:?}", other),
    }
}

// ── Multi-Clause Function Definitions ────────────────────────────────

#[test]
fn fn_expr_body_literal_param() {
    // fn fib(0) = 0
    let source = "fn fib(0) = 0";
    assert_snapshot!(source_and_debug(source));
}

#[test]
fn fn_expr_body_ident_param() {
    // fn fib(n) = fib(n - 1) + fib(n - 2)
    let source = "fn fib(n) = fib(n - 1) + fib(n - 2)";
    assert_snapshot!(source_and_debug(source));
}

#[test]
fn fn_expr_body_with_guard() {
    // fn abs(n) when n < 0 = -n
    let source = "fn abs(n) when n < 0 = -n";
    assert_snapshot!(source_and_debug(source));
}

#[test]
fn fn_expr_body_constructor_pattern() {
    // fn foo(Some(x)) = x
    let source = "fn foo(Some(x)) = x";
    assert_snapshot!(source_and_debug(source));
}

#[test]
fn fn_expr_body_wildcard() {
    // fn foo(_) = 0
    let source = "fn foo(_) = 0";
    assert_snapshot!(source_and_debug(source));
}

#[test]
fn fn_expr_body_multiple_params() {
    // fn add(0, y) = y
    let source = "fn add(0, y) = y";
    assert_snapshot!(source_and_debug(source));
}

#[test]
fn fn_expr_body_negative_literal() {
    // fn neg(-1) = 1
    let source = "fn neg(-1) = 1";
    assert_snapshot!(source_and_debug(source));
}

#[test]
fn fn_expr_body_bool_pattern() {
    // fn to_int(true) = 1
    let source = "fn to_int(true) = 1";
    assert_snapshot!(source_and_debug(source));
}

#[test]
fn clustered_work_is_rejected_and_recovery_keeps_function_visible() {
    let source = "clustered(work) pub fn enqueue(job) do\n  job\nend";
    let p = parse(source);
    assert!(!p.ok(), "removed clustered(work) syntax should fail closed");
    assert!(
        p.errors()[0]
            .message
            .contains("`clustered(work)` declarations are not supported"),
        "unexpected error: {}",
        p.errors()[0].message
    );

    let tree = p.tree();
    let fn_def: FnDef = tree.fn_defs().next().expect("function should still parse");
    assert!(
        fn_def.visibility().is_some(),
        "pub visibility should remain visible"
    );
    assert!(
        fn_def.body().is_some(),
        "function body should remain visible"
    );
    assert!(fn_def.clustered_decl().is_none());
}

#[test]
fn clustered_work_non_function_prefix_is_rejected_without_cascade() {
    let p = parse("clustered(work) let job = 1");
    assert!(
        !p.ok(),
        "removed prefix without function should fail closed"
    );
    assert_eq!(
        p.errors().len(),
        1,
        "removed syntax should prefer one explicit error"
    );
    assert!(
        p.errors()[0]
            .message
            .contains("`clustered(work)` declarations are not supported"),
        "unexpected error: {}",
        p.errors()[0].message
    );
}

#[test]
fn clustered_work_malformed_targets_are_rejected_with_same_guidance() {
    for source in [
        "clustered work fn enqueue(job) do\n  job\nend",
        "clustered() fn enqueue(job) do\n  job\nend",
        "clustered(service_call) fn enqueue(job) do\n  job\nend",
    ] {
        let p = parse(source);
        assert!(!p.ok(), "{source:?} should fail closed");
        assert!(
            p.errors()[0]
                .message
                .contains("`clustered(work)` declarations are not supported"),
            "unexpected error for {source:?}: {}",
            p.errors()[0].message
        );
    }
}

#[test]
fn clustered_work_recovery_keeps_following_plain_functions() {
    let source = "clustered(work) fn remote(job) do\n  job\nend\nfn local(job) do\n  job\nend";
    let p = parse(source);
    assert_eq!(p.errors().len(), 1, "removed prefix should fail closed");

    let tree = p.tree();
    let fn_defs: Vec<_> = tree.fn_defs().collect();
    assert_eq!(
        fn_defs.len(),
        2,
        "expected recovery to keep the following plain function visible"
    );
    assert_eq!(fn_defs[0].name().unwrap().text().unwrap(), "remote");
    assert_eq!(fn_defs[1].name().unwrap().text().unwrap(), "local");
    assert!(fn_defs[0].clustered_decl().is_none());
}

#[test]
fn cluster_decorator_ast_accessor_stays_source_only() {
    let source = "@cluster(3) def enqueue(job) do\n  job\nend";
    let p = parse(source);
    assert!(p.ok(), "parse errors: {:?}", p.errors());

    let tree = p.tree();
    let fn_def: FnDef = tree.fn_defs().next().expect("should have fn def");
    let decl = fn_def
        .clustered_decl()
        .expect("@cluster marker should be present");

    assert_eq!(decl.explicit_replica_count(), Some(3));
}

#[test]
fn parser_cluster_decorator_fn_def() {
    let source = "@cluster pub fn enqueue(job) do\n  job\nend";
    assert_snapshot!(source_and_debug(source));
}

#[test]
fn parser_cluster_decorator_with_count_fn_def() {
    let source = "@cluster(3) def enqueue(job) do\n  job\nend";
    assert_snapshot!(source_and_debug(source));
}

#[test]
fn parser_cluster_decorator_invalid_count_shape() {
    let source = "@cluster(1, 2) fn enqueue(job) do\n  job\nend";
    assert_snapshot!(source_and_debug(source));
}

#[test]
fn clustered_work_debug_output_mentions_unsupported_syntax() {
    let source = "clustered(work) pub fn enqueue(job) do\n  job\nend";
    let rendered = source_and_debug(source);
    assert!(
        rendered.contains("`clustered(work)` declarations are not supported"),
        "unexpected debug output: {rendered}"
    );
}

#[test]
fn parser_cluster_decorator_ast_accessor_present_for_pub_fn() {
    let source = "@cluster pub fn enqueue(job) do\n  job\nend";
    let p = parse(source);
    assert!(p.ok(), "parse errors: {:?}", p.errors());

    let tree = p.tree();
    let fn_def: FnDef = tree.fn_defs().next().expect("should have fn def");
    let decl = fn_def
        .clustered_decl()
        .expect("@cluster marker should be present");
    let span = decl.declaration_span();

    assert_eq!(decl.explicit_replica_count(), None);
    assert!(decl.explicit_replica_count_token().is_none());
    assert_eq!((span.start, span.end), (0, 8));
    assert!(
        fn_def.visibility().is_some(),
        "pub visibility should remain visible"
    );
}

#[test]
fn parser_cluster_decorator_ast_accessor_present_for_counted_def() {
    let source = "@cluster(3) def enqueue(job) do\n  job\nend";
    let p = parse(source);
    assert!(p.ok(), "parse errors: {:?}", p.errors());

    let tree = p.tree();
    let fn_def: FnDef = tree.fn_defs().next().expect("should have fn def");
    let decl = fn_def
        .clustered_decl()
        .expect("@cluster marker should be present");
    let span = decl.declaration_span();

    assert_eq!(
        decl.explicit_replica_count_token()
            .map(|t| t.text().to_string()),
        Some("3".to_string())
    );
    assert_eq!(decl.explicit_replica_count(), Some(3));
    assert_eq!((span.start, span.end), (0, 11));
}

/// A replica count is an integer literal in any radix, with `_`s.
#[test]
fn replica_counts_read_in_every_radix() {
    for (count, expected) in [("0x1F", 31), ("0b101", 5), ("0o17", 15), ("1_000", 1000)] {
        let parse = parse(&format!("@cluster({count}) fn work() do\n  1\nend"));
        let decl = parse
            .tree()
            .fn_defs()
            .next()
            .unwrap()
            .clustered_decl()
            .unwrap();
        assert_eq!(decl.explicit_replica_count(), Some(expected), "{count}");
    }
}

/// Every item and decorator gives back its own node.
#[test]
fn items_and_decorators_are_their_nodes() {
    let source = "import Foo\nfrom Bar import baz\ninterface I do\n  fn f(self) -> Int\nend\nimpl I for Int do\n  fn f(self) -> Int do\n    1\n  end\nend\n@native(\"c_sym\") pub fn native_f() -> Int\n@export(\"exported\") pub fn export_f() -> Int do\n  1\nend\n@cluster fn work() do\n  1\nend\nmodule M do\n  fn g() = 1\nend\ntype Alias = Int\nsupervisor Sup do\n  strategy: one_for_one\nend\n";
    let parse = parse(source);
    let kinds: Vec<SyntaxKind> = parse
        .tree()
        .items()
        .map(|item| item.syntax().kind())
        .collect();
    assert_eq!(
        kinds,
        [
            SyntaxKind::IMPORT_DECL,
            SyntaxKind::FROM_IMPORT_DECL,
            SyntaxKind::INTERFACE_DEF,
            SyntaxKind::IMPL_DEF,
            SyntaxKind::FN_DEF,
            SyntaxKind::FN_DEF,
            SyntaxKind::FN_DEF,
            SyntaxKind::MODULE_DEF,
            SyntaxKind::TYPE_ALIAS_DEF,
            SyntaxKind::SUPERVISOR_DEF,
        ]
    );
    let fns: Vec<FnDef> = parse.tree().fn_defs().collect();
    assert_eq!(
        fns[0].native_decl().unwrap().syntax().kind(),
        SyntaxKind::NATIVE_DECORATOR_DECL
    );
    assert_eq!(
        fns[1].export_decl().unwrap().syntax().kind(),
        SyntaxKind::EXPORT_DECORATOR_DECL
    );
    assert_eq!(
        fns[2].clustered_decl().unwrap().syntax().kind(),
        SyntaxKind::CLUSTER_DECORATOR_DECL
    );
}

/// A schema option's value reads as what it says.
#[test]
fn schema_options_read_their_values() {
    let parse =
        parse("struct S do\n  table \"people\"\n  primary_key :uuid\n  timestamps false\nend\n");
    let def: StructDef = parse
        .tree()
        .items()
        .find_map(|item| match item {
            mesh_parser::ast::item::Item::StructDef(def) => Some(def),
            _ => None,
        })
        .unwrap();
    let options = def.schema_options();
    let values: Vec<_> = options
        .iter()
        .map(|option| {
            (
                option.option_name(),
                option.atom_value(),
                option.bool_value(),
            )
        })
        .collect();
    assert_eq!(
        values,
        [
            (Some("table".to_string()), None, None),
            (
                Some("primary_key".to_string()),
                Some("uuid".to_string()),
                None
            ),
            (Some("timestamps".to_string()), None, Some(false)),
        ]
    );
}

/// A field may have a schema option's or a relationship's name: it was
/// taken as the option, `table :: Int` as a table without its name.
#[test]
fn a_field_may_have_a_schema_options_name() {
    let parse = parse(
        "struct S do\n  table \"people\"\n  table :: Int\n  timestamps :: Bool\n  has_many :: Int\nend\n",
    );
    assert!(parse.errors().is_empty(), "{:?}", parse.errors());
    let def: StructDef = parse
        .tree()
        .items()
        .find_map(|item| match item {
            mesh_parser::ast::item::Item::StructDef(def) => Some(def),
            _ => None,
        })
        .unwrap();
    let fields: Vec<_> = def
        .fields()
        .filter_map(|field| field.name()?.text())
        .collect();
    assert_eq!(fields, ["table", "timestamps", "has_many"]);
    assert_eq!(def.schema_options().len(), 1);
}

/// A body cut off before it begins is missing, not an empty block, which
/// is one of type `()`: an arm's, a closure clause's, and a block an
/// earlier error stopped before its first statement (`if b` with no `do`).
#[test]
fn a_body_cut_off_before_it_begins_is_missing() {
    let arm = parse("fn f(x) do\n  case x do\n    1 -> 1\n    _ ->\n  end\nend\n");
    assert!(!arm.errors().is_empty());
    let bodies: Vec<_> = arm
        .syntax()
        .descendants()
        .filter_map(MatchArm::cast)
        .map(|arm| arm.body().is_some())
        .collect();
    assert_eq!(bodies, [true, false]);

    let clause = parse("fn g() do\n  let h = fn 0 -> 1\n    | n ->\n  end\nend\n");
    assert!(!clause.errors().is_empty());
    let bodies: Vec<_> = clause
        .syntax()
        .descendants()
        .filter_map(ClosureClause::cast)
        .map(|clause| clause.body().is_some())
        .collect();
    // The clauses after the first, each after a `|`.
    assert_eq!(bodies, [false]);

    let cut = parse("fn f(b) do\n  if b\nend\n");
    assert!(!cut.errors().is_empty());
    let if_expr = cut.syntax().descendants().find_map(IfExpr::cast).unwrap();
    assert!(if_expr.then_branch().is_none());
}

/// An as-pattern's sub-pattern is what it names, not the name.
#[test]
fn an_as_pattern_contains_its_inner_pattern() {
    let parse = parse("fn f(v) do\n  case v do\n    Some(x) as whole -> x\n  end\nend");
    let pattern = parse
        .syntax()
        .descendants()
        .find_map(Pattern::cast)
        .expect("a pattern");
    let Pattern::As(as_pat) = &pattern else {
        panic!("{pattern:?}")
    };
    assert_eq!(as_pat.binding_name().unwrap().text(), "whole");
    let subs = pattern.sub_patterns();
    assert_eq!(subs.len(), 1);
    assert!(matches!(subs[0], Pattern::Constructor(_)), "{subs:?}");
    let names: Vec<String> = pattern
        .binders()
        .iter()
        .map(|t| t.text().to_string())
        .collect();
    assert_eq!(names, ["x", "whole"]);
}

#[test]
fn clustered_work_does_not_expose_generic_accessor() {
    let source = "clustered(work) pub fn enqueue(job) do\n  job\nend";
    let p = parse(source);
    assert!(!p.ok(), "parse should fail closed for removed syntax");

    let tree = p.tree();
    let fn_def: FnDef = tree
        .fn_defs()
        .next()
        .expect("should still recover function");
    assert!(fn_def.clustered_decl().is_none());
}

#[test]
fn parser_cluster_decorator_rejects_missing_count_and_close() {
    // Both are missing at the end of the file; the first error there is
    // the one reported.
    let p = parse("@cluster(");
    assert!(!p.ok(), "unterminated decorator should fail closed");
    assert!(
        p.errors().iter().any(|err| err
            .message
            .contains("expected integer replication count inside `@cluster(...)`")),
        "unexpected errors: {:?}",
        p.errors()
    );
}

#[test]
fn parser_cluster_decorator_rejects_non_integer_count() {
    let p = parse("@cluster(foo) fn enqueue(job) do\n  job\nend");
    assert!(!p.ok(), "non-integer count should fail closed");
    assert!(
        p.errors()[0]
            .message
            .contains("expected integer replication count inside `@cluster(...)`"),
        "unexpected error: {}",
        p.errors()[0].message
    );
}

#[test]
fn parser_cluster_decorator_rejects_extra_count_arguments() {
    let p = parse("@cluster(1, 2) fn enqueue(job) do\n  job\nend");
    assert!(!p.ok(), "extra count arguments should fail closed");
    assert!(
        p.errors()[0]
            .message
            .contains("expected exactly one replication count in `@cluster(N)`"),
        "unexpected error: {}",
        p.errors()[0].message
    );
}

#[test]
fn parser_cluster_decorator_rejects_prefix_without_fn_or_def() {
    let p = parse("@cluster let job = 1");
    assert!(!p.ok(), "decorator without function should fail closed");
    assert!(
        p.errors()[0]
            .message
            .contains("expected `fn` or `def` after `@cluster`"),
        "unexpected error: {}",
        p.errors()[0].message
    );
}

#[test]
fn parser_cluster_decorator_rejects_non_function_item() {
    let p = parse("@cluster module Jobs do\nend");
    assert!(!p.ok(), "decorator on non-function item should fail closed");
    assert!(
        p.errors()[0]
            .message
            .contains("expected `fn` or `def` after `@cluster`"),
        "unexpected error: {}",
        p.errors()[0].message
    );
}

#[test]
fn parser_cluster_decorator_rejects_missing_r_paren() {
    let p = parse("@cluster(3 pub fn enqueue(job) do\n  job\nend");
    assert!(!p.ok(), "missing `)` should fail closed");
    assert!(
        p.errors().iter().any(|err| err
            .message
            .contains("expected `)` to close `@cluster(...)`")),
        "unexpected errors: {:?}",
        p.errors()
    );
}

#[test]
fn parser_cluster_decorator_rejects_stray_at() {
    let p = parse("@ fn enqueue(job) do\n  job\nend");
    assert!(!p.ok(), "stray `@` should fail closed");
    assert!(
        p.errors()[0]
            .message
            .contains("expected `cluster` after `@`"),
        "unexpected error: {}",
        p.errors()[0].message
    );
}

#[test]
fn parser_native_declaration_exposes_external_symbol_without_body() {
    let parsed =
        parse("@native(\"mesh_math_add\")\npub fn add(left :: Int, right :: Int) -> Int\n");
    assert!(parsed.errors().is_empty(), "{:?}", parsed.errors());

    let function = parsed
        .tree()
        .fn_defs()
        .next()
        .expect("native function declaration");
    let native = function.native_decl().expect("@native declaration");
    assert_eq!(native.symbol().as_deref(), Some("mesh_math_add"));
    assert!(function.body().is_none());
    assert!(function.expr_body().is_none());
}

#[test]
fn parser_native_declaration_requires_one_literal_symbol() {
    for source in [
        "@native()\npub fn value() -> Int\n",
        "@native(symbol)\npub fn value() -> Int\n",
        "@native(\"a\", \"b\")\npub fn value() -> Int\n",
    ] {
        let parsed = parse(source);
        assert!(
            parsed
                .errors()
                .iter()
                .any(|error| error.message.contains("native symbol")),
            "expected native symbol diagnostic for {source:?}, got {:?}",
            parsed.errors()
        );
    }
}

#[test]
fn parser_export_declaration_exposes_external_symbol_with_body() {
    let parsed = parse(
        "@export(\"mesh_mobile_echo\")\npub fn echo(request :: Bytes) -> Bytes!String do\n  Ok(request)\nend\n",
    );
    assert!(parsed.errors().is_empty(), "{:?}", parsed.errors());

    let function = parsed.tree().fn_defs().next().expect("exported function");
    let export = function.export_decl().expect("@export declaration");
    assert_eq!(export.symbol().as_deref(), Some("mesh_mobile_echo"));
    assert!(function.body().is_some());
}

/// `@display` marks an export that may carry plaintext, on either side of
/// its `@export`.
#[test]
fn parser_display_marks_an_export_before_or_after_it() {
    for source in [
        "@display\n@export(\"mesh_show\")\npub fn show(request :: Bytes) -> Bytes!String do\n  Ok(request)\nend\n",
        "@export(\"mesh_show\")\n@display\npub fn show(request :: Bytes) -> Bytes!String do\n  Ok(request)\nend\n",
    ] {
        let parsed = parse(source);
        assert!(parsed.errors().is_empty(), "{:?}", parsed.errors());
        let function = parsed.tree().fn_defs().next().expect("exported function");
        assert!(function.display_decl().is_some(), "{source:?}");
        let export = function.export_decl().expect("@export declaration");
        assert_eq!(export.symbol().as_deref(), Some("mesh_show"));
    }
    let dangling = parse("@display\n");
    assert!(
        dangling
            .errors()
            .iter()
            .any(|error| error.message.contains("after `@display`")),
        "{:?}",
        dangling.errors()
    );
}

#[test]
fn parser_export_declaration_requires_one_literal_symbol() {
    for source in [
        "@export()\npub fn echo(request :: Bytes) -> Bytes!String do\n  Ok(request)\nend\n",
        "@export(symbol)\npub fn echo(request :: Bytes) -> Bytes!String do\n  Ok(request)\nend\n",
        "@export(\"a\", \"b\")\npub fn echo(request :: Bytes) -> Bytes!String do\n  Ok(request)\nend\n",
    ] {
        let parsed = parse(source);
        assert!(
            parsed
                .errors()
                .iter()
                .any(|error| error.message.contains("export symbol")),
            "expected export symbol diagnostic for {source:?}, got {:?}",
            parsed.errors()
        );
    }
}

#[test]
fn fn_existing_do_end_still_works() {
    // Existing syntax must continue to work
    let source = "fn foo(x) do\n  x + 1\nend";
    let p = parse(source);
    assert!(p.ok(), "parse errors: {:?}", p.errors());
}

#[test]
fn fn_existing_typed_params_still_works() {
    // fn bar(x :: Int) do x end
    let source = "fn bar(x :: Int) do\n  x\nend";
    let p = parse(source);
    assert!(p.ok(), "parse errors: {:?}", p.errors());
}

#[test]
fn fn_multi_clause_consecutive() {
    // Multiple clauses for the same function
    let source = "fn fib(0) = 0\nfn fib(1) = 1\nfn fib(n) = fib(n - 1) + fib(n - 2)";
    let p = parse(source);
    assert!(p.ok(), "parse errors: {:?}", p.errors());

    let tree = p.tree();
    let fn_defs: Vec<_> = tree.fn_defs().collect();
    assert_eq!(fn_defs.len(), 3);

    // All three should have the same name
    for f in &fn_defs {
        assert_eq!(f.name().unwrap().text().unwrap(), "fib");
    }
}

#[test]
fn fn_guard_clause_produces_guard_node() {
    // fn abs(n) when n < 0 = -n
    let source = "fn abs(n) when n < 0 = -n";
    let p = parse(source);
    assert!(p.ok(), "parse errors: {:?}", p.errors());

    let tree = p.tree();
    let fn_def: FnDef = tree.fn_defs().next().unwrap();

    // Check that GUARD_CLAUSE child exists
    let has_guard = fn_def
        .syntax()
        .children()
        .any(|n| n.kind() == SyntaxKind::GUARD_CLAUSE);
    assert!(has_guard, "expected GUARD_CLAUSE child in FnDef");
}

#[test]
fn fn_expr_body_produces_fn_expr_body_node() {
    // fn fib(0) = 0
    let source = "fn fib(0) = 0";
    let p = parse(source);
    assert!(p.ok(), "parse errors: {:?}", p.errors());

    let tree = p.tree();
    let fn_def: FnDef = tree.fn_defs().next().unwrap();

    // Check that FN_EXPR_BODY child exists
    let has_expr_body = fn_def
        .syntax()
        .children()
        .any(|n| n.kind() == SyntaxKind::FN_EXPR_BODY);
    assert!(has_expr_body, "expected FN_EXPR_BODY child in FnDef");
}

#[test]
fn fn_do_end_has_no_fn_expr_body() {
    // fn foo(x) do x + 1 end
    let source = "fn foo(x) do\n  x + 1\nend";
    let p = parse(source);
    assert!(p.ok(), "parse errors: {:?}", p.errors());

    let tree = p.tree();
    let fn_def: FnDef = tree.fn_defs().next().unwrap();

    // No FN_EXPR_BODY node for do/end functions
    let has_expr_body = fn_def
        .syntax()
        .children()
        .any(|n| n.kind() == SyntaxKind::FN_EXPR_BODY);
    assert!(
        !has_expr_body,
        "do/end function should not have FN_EXPR_BODY"
    );
}

#[test]
fn fn_param_literal_has_pattern_child() {
    // fn fib(0) = 0 -- the param should contain a LITERAL_PAT
    let source = "fn fib(0) = 0";
    let p = parse(source);
    assert!(p.ok(), "parse errors: {:?}", p.errors());

    let tree = p.tree();
    let fn_def: FnDef = tree.fn_defs().next().unwrap();
    let param_list = fn_def.param_list().unwrap();
    let param = param_list.params().next().unwrap();

    // The param should have a LITERAL_PAT child
    let has_literal_pat = param
        .syntax()
        .children()
        .any(|n| n.kind() == SyntaxKind::LITERAL_PAT);
    assert!(
        has_literal_pat,
        "expected LITERAL_PAT child in param for fn fib(0)"
    );
}

#[test]
fn fn_param_wildcard_has_pattern_child() {
    // fn foo(_) = 0
    let source = "fn foo(_) = 0";
    let p = parse(source);
    assert!(p.ok(), "parse errors: {:?}", p.errors());

    let tree = p.tree();
    let fn_def: FnDef = tree.fn_defs().next().unwrap();
    let param_list = fn_def.param_list().unwrap();
    let param = param_list.params().next().unwrap();

    let has_wildcard_pat = param
        .syntax()
        .children()
        .any(|n| n.kind() == SyntaxKind::WILDCARD_PAT);
    assert!(
        has_wildcard_pat,
        "expected WILDCARD_PAT child in param for fn foo(_)"
    );
}

#[test]
fn fn_param_constructor_has_pattern_child() {
    // fn foo(Some(x)) = x
    let source = "fn foo(Some(x)) = x";
    let p = parse(source);
    assert!(p.ok(), "parse errors: {:?}", p.errors());

    let tree = p.tree();
    let fn_def: FnDef = tree.fn_defs().next().unwrap();
    let param_list = fn_def.param_list().unwrap();
    let param = param_list.params().next().unwrap();

    let has_constructor_pat = param
        .syntax()
        .children()
        .any(|n| n.kind() == SyntaxKind::CONSTRUCTOR_PAT);
    assert!(
        has_constructor_pat,
        "expected CONSTRUCTOR_PAT child in param for fn foo(Some(x))"
    );
}

#[test]
fn fn_guard_with_function_call() {
    // Guards can include function calls (arbitrary Bool expr)
    let source = "fn process(x) when is_valid(x) = x";
    let p = parse(source);
    assert!(p.ok(), "parse errors: {:?}", p.errors());
}

#[test]
fn fn_guard_with_complex_expr() {
    // Guards can be complex boolean expressions
    let source = "fn check(n) when n > 0 and n < 100 = n";
    let p = parse(source);
    assert!(p.ok(), "parse errors: {:?}", p.errors());
}

#[test]
fn fn_tuple_pattern_param() {
    // fn swap((a, b)) = (b, a)
    let source = "fn swap((a, b)) = (b, a)";
    let p = parse(source);
    assert!(p.ok(), "parse errors: {:?}", p.errors());

    let tree = p.tree();
    let fn_def: FnDef = tree.fn_defs().next().unwrap();
    let param_list = fn_def.param_list().unwrap();
    let param = param_list.params().next().unwrap();

    let has_tuple_pat = param
        .syntax()
        .children()
        .any(|n| n.kind() == SyntaxKind::TUPLE_PAT);
    assert!(
        has_tuple_pat,
        "expected TUPLE_PAT child in param for fn swap((a, b))"
    );
}

/// A pattern parameter takes a `:: Type` like a named one; `::` before a
/// list pattern still makes a cons pattern.
#[test]
fn fn_pattern_params_take_a_type_annotation() {
    for (source, pattern_kind, annotated) in [
        ("fn f(0 :: Int) = 1", SyntaxKind::LITERAL_PAT, true),
        (
            "fn f(Some(x) :: Option<Int>) = x",
            SyntaxKind::CONSTRUCTOR_PAT,
            true,
        ),
        (
            "fn f((s, n) :: borrow (SecretBytes, Int)) = n",
            SyntaxKind::TUPLE_PAT,
            true,
        ),
        ("fn f(h :: t :: List<Int>) = h", SyntaxKind::CONS_PAT, true),
        ("fn f((a, b) :: rest) = a", SyntaxKind::CONS_PAT, false),
        ("fn f(h :: [x]) = x", SyntaxKind::CONS_PAT, false),
    ] {
        let p = parse(source);
        assert!(p.ok(), "{source}: {:?}", p.errors());
        let fn_def: FnDef = p.tree().fn_defs().next().unwrap();
        let param = fn_def.param_list().unwrap().params().next().unwrap();
        assert_eq!(
            param.pattern().map(|pattern| pattern.syntax().kind()),
            Some(pattern_kind),
            "{source}"
        );
        assert_eq!(param.type_annotation().is_some(), annotated, "{source}");
    }
}

// ── AST Accessor Tests for Multi-Clause Functions ────────────────────

#[test]
fn ast_fn_def_guard_accessor() {
    let source = "fn abs(n) when n < 0 = -n";
    let p = parse(source);
    assert!(p.ok(), "parse errors: {:?}", p.errors());

    let tree = p.tree();
    let fn_def: FnDef = tree.fn_defs().next().unwrap();

    // guard() should return Some
    let guard = fn_def.guard();
    assert!(
        guard.is_some(),
        "FnDef::guard() should return Some for guarded function"
    );

    // guard().expr() should return the guard expression
    let guard_expr = guard.unwrap().expr();
    assert!(
        guard_expr.is_some(),
        "GuardClause::expr() should return the guard expression"
    );
}

#[test]
fn ast_fn_def_no_guard() {
    let source = "fn fib(0) = 0";
    let p = parse(source);
    assert!(p.ok(), "parse errors: {:?}", p.errors());

    let tree = p.tree();
    let fn_def: FnDef = tree.fn_defs().next().unwrap();

    // guard() should return None for non-guarded functions
    assert!(
        fn_def.guard().is_none(),
        "FnDef::guard() should return None"
    );
}

#[test]
fn ast_fn_def_expr_body_accessor() {
    let source = "fn fib(0) = 0";
    let p = parse(source);
    assert!(p.ok(), "parse errors: {:?}", p.errors());

    let tree = p.tree();
    let fn_def: FnDef = tree.fn_defs().next().unwrap();

    // expr_body() should return the body expression
    let expr_body = fn_def.expr_body();
    assert!(
        expr_body.is_some(),
        "FnDef::expr_body() should return Some for = expr form"
    );

    // has_eq_body() should be true
    assert!(
        fn_def.has_eq_body(),
        "FnDef::has_eq_body() should be true for = expr form"
    );

    // body() should return None (no do/end block)
    assert!(
        fn_def.body().is_none(),
        "FnDef::body() should return None for = expr form"
    );
}

#[test]
fn ast_fn_def_do_end_accessors() {
    let source = "fn foo(x) do\n  x + 1\nend";
    let p = parse(source);
    assert!(p.ok(), "parse errors: {:?}", p.errors());

    let tree = p.tree();
    let fn_def: FnDef = tree.fn_defs().next().unwrap();

    // body() should return Some for do/end form
    assert!(
        fn_def.body().is_some(),
        "FnDef::body() should return Some for do/end form"
    );

    // has_eq_body() should be false
    assert!(
        !fn_def.has_eq_body(),
        "FnDef::has_eq_body() should be false for do/end form"
    );

    // expr_body() should return None
    assert!(
        fn_def.expr_body().is_none(),
        "FnDef::expr_body() should return None for do/end form"
    );
}

#[test]
fn ast_param_pattern_accessor() {
    // Test literal pattern param
    let source = "fn fib(0) = 0";
    let p = parse(source);
    assert!(p.ok(), "parse errors: {:?}", p.errors());

    let tree = p.tree();
    let fn_def: FnDef = tree.fn_defs().next().unwrap();
    let param = fn_def.param_list().unwrap().params().next().unwrap();

    // pattern() should return Some for literal pattern
    assert!(
        param.pattern().is_some(),
        "Param::pattern() should return Some for literal pattern"
    );

    // name() may return None for pattern params (no direct IDENT child in some cases)
}

#[test]
fn ast_param_ident_no_pattern() {
    // Regular ident param should have no pattern
    let source = "fn foo(x) do\n  x\nend";
    let p = parse(source);
    assert!(p.ok(), "parse errors: {:?}", p.errors());

    let tree = p.tree();
    let fn_def: FnDef = tree.fn_defs().next().unwrap();
    let param = fn_def.param_list().unwrap().params().next().unwrap();

    // pattern() should return None for plain ident params
    assert!(
        param.pattern().is_none(),
        "Param::pattern() should return None for ident param"
    );

    // name() should return the IDENT
    assert!(
        param.name().is_some(),
        "Param::name() should return Some for ident param"
    );
    assert_eq!(param.name().unwrap().text(), "x");
}

// ═══════════════════════════════════════════════════════════════════════
// Phase 22-01: Deriving clause parsing and AST accessors
// ═══════════════════════════════════════════════════════════════════════

#[test]
fn struct_deriving_clause_snapshot() {
    let source = "struct Point do\n  x :: Int\nend deriving(Eq, Display)";
    assert_snapshot!(source_and_debug(source));
}

#[test]
fn struct_no_deriving_clause_snapshot() {
    // Existing behavior: no deriving clause
    let source = "struct Point do\n  x :: Int\nend";
    assert_snapshot!(source_and_debug(source));
}

#[test]
fn sum_type_deriving_clause_snapshot() {
    let source = "type Shape do\n  Circle\nend deriving(Eq)";
    assert_snapshot!(source_and_debug(source));
}

#[test]
fn struct_deriving_empty_clause() {
    // deriving() with empty parens derives nothing
    let source = "struct Empty do\n  x :: Int\nend deriving()";
    assert_snapshot!(source_and_debug(source));
}

#[test]
fn ast_struct_deriving_traits_accessor() {
    let source = "struct Point do\n  x :: Int\nend deriving(Eq, Display)";
    let p = parse(source);
    assert!(p.ok(), "parse errors: {:?}", p.errors());
    let tree = p.tree();
    let struct_def: StructDef = tree
        .syntax()
        .children()
        .find_map(StructDef::cast)
        .expect("should have struct def");

    assert!(struct_def.has_deriving_clause());
    let traits = struct_def.deriving_traits();
    assert_eq!(traits, vec!["Eq".to_string(), "Display".to_string()]);
}

#[test]
fn ast_struct_no_deriving_clause() {
    let source = "struct Point do\n  x :: Int\nend";
    let p = parse(source);
    assert!(p.ok(), "parse errors: {:?}", p.errors());
    let tree = p.tree();
    let struct_def: StructDef = tree
        .syntax()
        .children()
        .find_map(StructDef::cast)
        .expect("should have struct def");

    assert!(!struct_def.has_deriving_clause());
    assert!(struct_def.deriving_traits().is_empty());
}

#[test]
fn ast_sum_type_deriving_traits_accessor() {
    let source = "type Shape do\n  Circle\n  Square\nend deriving(Eq)";
    let p = parse(source);
    assert!(p.ok(), "parse errors: {:?}", p.errors());
    let tree = p.tree();
    let sum_def: SumTypeDef = tree
        .syntax()
        .children()
        .find_map(SumTypeDef::cast)
        .expect("should have sum type def");

    assert!(sum_def.has_deriving_clause());
    let traits = sum_def.deriving_traits();
    assert_eq!(traits, vec!["Eq".to_string()]);
}

#[test]
fn ast_struct_deriving_empty() {
    let source = "struct Point do\n  x :: Int\nend deriving()";
    let p = parse(source);
    assert!(p.ok(), "parse errors: {:?}", p.errors());
    let tree = p.tree();
    let struct_def: StructDef = tree
        .syntax()
        .children()
        .find_map(StructDef::cast)
        .expect("should have struct def");

    assert!(struct_def.has_deriving_clause());
    assert!(struct_def.deriving_traits().is_empty());
}

// ═══════════════════════════════════════════════════════════════════════
// Phase 36-02: For-in with when filter clause
// ═══════════════════════════════════════════════════════════════════════

#[test]
fn for_in_when_filter_snapshot() {
    assert_snapshot!(parse_and_debug("for x in list when x > 0 do\n  x\nend"));
}

#[test]
fn for_in_when_filter_ast_accessors() {
    let p = parse_expr("for x in list when x > 0 do\n  x\nend");
    assert!(p.ok(), "parse errors: {:?}", p.errors());
    let root = p.syntax();

    let for_in: ForInExpr = root
        .children()
        .find_map(ForInExpr::cast)
        .expect("should have ForInExpr");

    // WHEN_KW token is present as a direct child
    let has_when = for_in
        .syntax()
        .children_with_tokens()
        .any(|it| it.kind() == SyntaxKind::WHEN_KW);
    assert!(has_when, "ForInExpr should have WHEN_KW token");

    // filter() returns Some(expr)
    let filter = for_in.filter();
    assert!(filter.is_some(), "ForInExpr::filter() should return Some");

    // iterable() still returns the correct expression
    let iterable = for_in.iterable();
    assert!(
        iterable.is_some(),
        "ForInExpr::iterable() should return Some"
    );

    // body() returns the block
    let body = for_in.body();
    assert!(body.is_some(), "ForInExpr::body() should return Some");
}

/// A filter that calls a function is not a call with a trailing closure:
/// the `do` after it opens the loop's body, as after a condition.
#[test]
fn for_in_when_filter_may_end_in_a_call() {
    let p = parse_expr("for x in list when valid(x) do\n  x\nend");
    assert!(p.ok(), "parse errors: {:?}", p.errors());
    let for_in: ForInExpr = p
        .syntax()
        .children()
        .find_map(ForInExpr::cast)
        .expect("should have ForInExpr");
    assert!(matches!(for_in.filter(), Some(Expr::CallExpr(_))));
    assert!(for_in.body().is_some());
}

#[test]
fn for_in_without_when_filter_returns_none() {
    let p = parse_expr("for x in list do\n  x\nend");
    assert!(p.ok(), "parse errors: {:?}", p.errors());
    let root = p.syntax();

    let for_in: ForInExpr = root
        .children()
        .find_map(ForInExpr::cast)
        .expect("should have ForInExpr");

    // No WHEN_KW token
    let has_when = for_in
        .syntax()
        .children_with_tokens()
        .any(|it| it.kind() == SyntaxKind::WHEN_KW);
    assert!(
        !has_when,
        "ForInExpr without when should not have WHEN_KW token"
    );

    // filter() returns None
    assert!(
        for_in.filter().is_none(),
        "ForInExpr::filter() should return None without when clause"
    );

    // iterable() and body() still work
    assert!(for_in.iterable().is_some(), "iterable() should still work");
    assert!(for_in.body().is_some(), "body() should still work");
}

// ═══════════════════════════════════════════════════════════════════════
// Phase 74-01: Associated Type Parser and AST Support
// ═══════════════════════════════════════════════════════════════════════

#[test]
fn interface_with_assoc_type_decl() {
    let source = "interface Iterator do\n  type Item\n  fn next(self) -> Int\nend";
    let p = parse(source);
    assert!(p.ok(), "parse errors: {:?}", p.errors());
    assert_snapshot!(source_and_debug(source));
}

#[test]
fn impl_with_assoc_type_binding() {
    let source = "impl Iterator for MyList do\n  type Item = Int\n  fn next(self) -> Int do\n    42\n  end\nend";
    let p = parse(source);
    assert!(p.ok(), "parse errors: {:?}", p.errors());
    assert_snapshot!(source_and_debug(source));
}

#[test]
fn interface_assoc_type_cst_has_assoc_type_def() {
    let source = "interface Foo do\n  type Item\n  fn next(self) -> Int\nend";
    let p = parse(source);
    assert!(p.ok(), "parse errors: {:?}", p.errors());
    let root = p.syntax();

    // Find ASSOC_TYPE_DEF in the CST
    fn find_kind(node: &mesh_parser::SyntaxNode, target: SyntaxKind) -> bool {
        if node.kind() == target {
            return true;
        }
        node.children().any(|c| find_kind(&c, target))
    }

    assert!(
        find_kind(&root, SyntaxKind::ASSOC_TYPE_DEF),
        "CST should contain ASSOC_TYPE_DEF node"
    );
}

#[test]
fn impl_assoc_type_cst_has_assoc_type_binding() {
    let source = "impl Iterator for MyList do\n  type Item = Int\n  fn next(self) -> Int do\n    42\n  end\nend";
    let p = parse(source);
    assert!(p.ok(), "parse errors: {:?}", p.errors());
    let root = p.syntax();

    fn find_kind(node: &mesh_parser::SyntaxNode, target: SyntaxKind) -> bool {
        if node.kind() == target {
            return true;
        }
        node.children().any(|c| find_kind(&c, target))
    }

    assert!(
        find_kind(&root, SyntaxKind::ASSOC_TYPE_BINDING),
        "CST should contain ASSOC_TYPE_BINDING node"
    );
}

#[test]
fn ast_interface_def_assoc_types_accessor() {
    use mesh_parser::ast::item::{AssocTypeDef, InterfaceDef};
    let source = "interface Iterator do\n  type Item\n  fn next(self) -> Int\nend";
    let p = parse(source);
    assert!(p.ok(), "parse errors: {:?}", p.errors());
    let tree = p.tree();

    let iface: InterfaceDef = tree
        .syntax()
        .children()
        .find_map(InterfaceDef::cast)
        .expect("should have interface def");

    let assoc_types: Vec<AssocTypeDef> = iface.assoc_types().collect();
    assert_eq!(assoc_types.len(), 1);
    assert_eq!(assoc_types[0].name().unwrap().text().unwrap(), "Item");

    // Methods should still work
    let methods: Vec<_> = iface.methods().collect();
    assert_eq!(methods.len(), 1);
    assert_eq!(methods[0].name().unwrap().text().unwrap(), "next");
}

#[test]
fn ast_impl_def_assoc_type_bindings_accessor() {
    use mesh_parser::ast::item::{AssocTypeBinding, ImplDef};
    let source = "impl Iterator for MyList do\n  type Item = Int\n  fn next(self) -> Int do\n    42\n  end\nend";
    let p = parse(source);
    assert!(p.ok(), "parse errors: {:?}", p.errors());
    let tree = p.tree();

    let impl_def: ImplDef = tree
        .syntax()
        .children()
        .find_map(ImplDef::cast)
        .expect("should have impl def");

    let bindings: Vec<AssocTypeBinding> = impl_def.assoc_type_bindings().collect();
    assert_eq!(bindings.len(), 1);
    assert_eq!(bindings[0].name().unwrap().text().unwrap(), "Item");

    // Methods should still work
    let methods: Vec<_> = impl_def.methods().collect();
    assert_eq!(methods.len(), 1);
    assert_eq!(methods[0].name().unwrap().text().unwrap(), "next");
}

#[test]
fn interface_multiple_assoc_types() {
    let source =
        "interface Numeric do\n  type Output\n  type Input\n  fn compute(self) -> Int\nend";
    let p = parse(source);
    assert!(p.ok(), "parse errors: {:?}", p.errors());

    use mesh_parser::ast::item::InterfaceDef;
    let tree = p.tree();
    let iface: InterfaceDef = tree
        .syntax()
        .children()
        .find_map(InterfaceDef::cast)
        .expect("should have interface def");

    let assoc_types: Vec<_> = iface.assoc_types().collect();
    assert_eq!(assoc_types.len(), 2);
    assert_eq!(assoc_types[0].name().unwrap().text().unwrap(), "Output");
    assert_eq!(assoc_types[1].name().unwrap().text().unwrap(), "Input");
}

#[test]
fn impl_assoc_type_generic_binding() {
    // Test binding to a generic type: type Item = List<Int>
    let source =
        "impl Foo for Bar do\n  type Item = List<Int>\n  fn baz(self) do\n    42\n  end\nend";
    let p = parse(source);
    assert!(p.ok(), "parse errors: {:?}", p.errors());
}

// ── Multi-line pipe (PIPE-01) ──────────────────────────────────────────

#[test]
fn pipe_multiline_leading() {
    // |> at start of continuation line (already worked, regression test)
    assert_snapshot!(parse_and_debug("x\n  |> foo()"));
}

#[test]
fn pipe_multiline_trailing() {
    // |> at end of line (new in Phase 126)
    assert_snapshot!(parse_and_debug("x |>\n  foo()"));
}

#[test]
fn pipe_multiline_chain_leading() {
    assert_snapshot!(parse_and_debug("x\n  |> foo()\n  |> bar()"));
}

#[test]
fn pipe_multiline_chain_trailing() {
    assert_snapshot!(parse_and_debug("x |>\n  foo() |>\n  bar()"));
}

#[test]
fn slot_pipe_multiline_leading() {
    // |2> at start of continuation line
    assert_snapshot!(parse_and_debug("x\n  |2> foo(1)"));
}

#[test]
fn slot_pipe_multiline_trailing() {
    // |2> at end of line (new in Phase 126)
    assert_snapshot!(parse_and_debug("x |2>\n  foo(1)"));
}

// ── Statement-position closures, block arm bodies, return expressions ──

#[test]
fn closure_as_statement_is_not_a_fn_def() {
    assert_snapshot!(source_and_debug("fn x -> x + 1 end"));
}

#[test]
fn match_arm_body_on_following_lines() {
    assert_snapshot!(source_and_debug(
        "case o do
  Some(x) ->
    let y = x
    y
  None -> 0
end"
    ));
}

#[test]
fn a_pattern_alone_is_a_pass_through_arm() {
    for (source, expected) in [
        (
            "case r do\n  Ok(value)\n  Err(e) -> Err(wrap(e))\nend",
            vec![true, false],
        ),
        // Newlines inside parentheses still end the arm.
        (
            "f(case r do\n  Ok(value) # kept\n  Err(e) -> Err(e)\nend)",
            vec![true, false],
        ),
        (
            "case o do\n  Some(v) when v > 0\n  _ -> None end",
            vec![true, false],
        ),
        ("case o do None end", vec![true]),
    ] {
        let parse = parse(source);
        assert!(parse.ok(), "{source}: {:?}", parse.errors());
        let arms: Vec<bool> = parse
            .syntax()
            .descendants()
            .filter_map(MatchArm::cast)
            .map(|arm| arm.is_pass_through())
            .collect();
        assert_eq!(arms, expected, "{source}");
    }

    // A missing `->` mid-line is still an error, not a pass-through.
    assert!(!parse("case r do\n  Ok(value) value\nend").ok());
}

#[test]
fn return_in_arm_body() {
    assert_snapshot!(source_and_debug(
        "case o do
  Some(x) -> x
  None -> return 0
end"
    ));
}

#[test]
fn for_loop_binding_can_be_a_tuple_pattern() {
    assert_snapshot!(source_and_debug(
        "for (n, s) in pairs when n > 1 do
  n
end"
    ));
}

#[test]
fn list_patterns_match_fixed_lengths() {
    assert_snapshot!(source_and_debug(
        "case xs do
  [] -> 0
  [x, (a, b)] -> x
  h :: t -> h
end"
    ));
}

/// `Point { x, y: 0 }` is a struct pattern: a field alone binds its name,
/// `field: pattern` matches the field, and the struct may be qualified.
#[test]
fn struct_patterns_name_fields_and_bind_shorthands() {
    let parse = parse(
        "fn f(p) do
  case p do
    Point { x: 0, y } -> y
    Geo.Point { x, y: (a, _) } as whole -> x
  end
  let Point { x, y: why } = p
end",
    );
    assert!(parse.errors().is_empty(), "{:?}", parse.errors());
    let structs: Vec<_> = parse
        .syntax()
        .descendants()
        .filter_map(Pattern::cast)
        .filter_map(|pattern| match pattern {
            Pattern::Struct(s) => Some(s),
            _ => None,
        })
        .collect();
    assert_eq!(structs.len(), 3);
    let describe = |s: &mesh_parser::ast::pat::StructPat| {
        let fields: Vec<String> = s
            .fields()
            .map(|f| f.name().map(|n| n.text().to_string()).unwrap_or_default())
            .collect();
        (
            s.qualifier().map(|q| q.text().to_string()),
            s.type_name().map(|n| n.text().to_string()),
            fields,
        )
    };
    assert_eq!(
        describe(&structs[0]),
        (None, Some("Point".into()), vec!["x".into(), "y".into()])
    );
    assert_eq!(
        describe(&structs[1]),
        (
            Some("Geo".into()),
            Some("Point".into()),
            vec!["x".into(), "y".into()]
        )
    );
    let binders = |node: &mesh_parser::SyntaxNode| -> Vec<String> {
        Pattern::cast(node.clone())
            .unwrap()
            .binders()
            .iter()
            .map(|t| t.text().to_string())
            .collect()
    };
    assert_eq!(binders(structs[0].syntax()), vec!["y"]);
    let as_pat = structs[1].syntax().parent().unwrap();
    assert_eq!(binders(&as_pat), vec!["x", "a", "whole"]);
    assert_eq!(binders(structs[2].syntax()), vec!["x", "why"]);
}

#[test]
fn struct_pattern_errors_name_what_is_missing() {
    let messages = |source: &str| -> Vec<String> {
        parse(source)
            .errors()
            .iter()
            .map(|e| e.message.clone())
            .collect()
    };
    assert!(
        messages("fn f(p) do\n  case p do\n    Point { 1 } -> 0\n  end\nend")
            .iter()
            .any(|m| m.contains("expected a field name in the struct pattern"))
    );
    assert!(
        messages("fn f(p) do\n  case p do\n    Point { x, .. } -> 0\n  end\nend")
            .iter()
            .any(|m| m.contains("`..` is not needed"))
    );
    // Fields may also be separated by new lines, as in a struct literal.
    assert!(messages(
        "fn f(p) do\n  case p do\n    Point {\n      x\n      y: 0\n    } -> x\n  end\nend"
    )
    .is_empty());
}

/// Every malformed construct is reported with a message that names what was
/// expected, and parsing goes on.
#[test]
fn malformed_constructs_report_what_was_expected() {
    let cases: &[(&str, &str)] = &[
        ("fn f() do\n  link x\nend", "expected `(` after `link`"),
        ("fn f() do\n  send x\nend", "expected `(` after `send`"),
        ("fn f() do\n  spawn x\nend", "expected `(` after `spawn`"),
        (
            "fn f() do\n  let g = fn x, y end\nend",
            "expected `->` or `do` after closure parameters",
        ),
        (
            "fn f() do\n  let g = fn 1 -> 2 | x end\nend",
            "expected `->` or `do` after closure clause parameters",
        ),
        (
            "fn f() do\n  let g = fn end\nend",
            "expected closure parameters, `->`, or `do`",
        ),
        (
            "fn f() do\n  let g = fn x -> do\n    x\n  end end\nend",
            "a closure of several statements is `fn params do ... end`, without `->`",
        ),
        (
            "fn f() do\n  let g = fn(x :: Int) -> Int do\n    x\n  end\nend",
            "a closure's return type is inferred: write `fn(params) do ... end`, without `-> Type`",
        ),
        ("fn f() 1", "expected `=` or `do` for function body"),
        (
            "interface I do\n  fn f(self) do\n    1\n",
            "expected `end` to close default method body",
        ),
        (
            "fn f() do\n  fn 0 -> 1 | n do\n    n\n",
            "expected `end` to close closure clause",
        ),
        (
            "impl Show for Int do\n  pub let x = 1\nend",
            "expected `fn` or `type` in impl body",
        ),
        (
            "clustered(work) fn f() do\nend",
            "`clustered(work)` declarations are not supported",
        ),
        (
            "struct S do\n  has_many :posts, 1\nend",
            "expected target type name after comma in relationship declaration",
        ),
        (
            "impl Show for List<Int, String> do\nend",
            "an `impl` for a type with type arguments is not supported",
        ),
        (
            "fn f<T>(x :: T) where T: 1 do\n  x\nend",
            "expected trait name",
        ),
        ("@x fn f() do\n  1\nend", "expected `cluster` after `@`"),
        (
            "fn f(x) do\n  case x do\n    1 -> do\n      2",
            "expected `end` to close arm `do` block",
        ),
        ("@cluster struct S do\nend", "expected `fn` or `def`"),
        ("impl Show for Int do\n  let x = 1\nend", "in impl body"),
        (
            "service S do\n  let x = 1\nend",
            "expected `fn`, `call`, `cast`, or `end` in service body",
        ),
        ("pub let x = 1", "after `pub`"),
        (
            "supervisor S do\n  child c do\n    bogus: 1\n  end\nend",
            "in child spec body",
        ),
        ("supervisor S do\n  bogus: 1\nend", "in supervisor body"),
        (
            "struct S do\n  timestamps 3\nend",
            "expected `true` or `false` after `timestamps`",
        ),
        (
            "fn f() do\n  g() do |x\n    x\n  end\nend",
            "expected `|` to close trailing closure parameters",
        ),
        (
            "fn f(p) do\n  case p do\n    Point { 1 } -> 0\n  end\nend",
            "expected a field name in the struct pattern",
        ),
        (
            "fn f() do\n  let a = 1 let b = 2\nend",
            "expected a newline or `;` after the statement",
        ),
        ("actor do\nend", "expected actor name"),
        (
            "interface I do\n  type\nend",
            "expected associated type name",
        ),
        (
            "struct S do\n  belongs_to user\nend",
            "expected atom literal (e.g., :user) after relationship kind",
        ),
        (
            "struct S do\n  primary_key uuid\nend",
            "expected atom literal after `primary_key`",
        ),
        (
            "service S do\n  call do |s|\n    s\n  end\nend",
            "expected call handler name",
        ),
        (
            "service S do\n  cast do |s|\n    s\n  end\nend",
            "expected cast handler name",
        ),
        (
            "supervisor S do\n  child do\n  end\nend",
            "expected child spec name",
        ),
        (
            "@cluster(1, 2) fn f() do\n  1\nend",
            "expected exactly one replication count in `@cluster(N)`",
        ),
        (
            "@cluster(x) fn f() do\n  1\nend",
            "expected integer replication count inside `@cluster(...)`",
        ),
        (
            "@native(\"a\", \"b\") fn f() -> Int",
            "expected exactly one literal native symbol",
        ),
        (
            "@native(\"\") fn f() -> Int",
            "expected one non-empty literal native symbol",
        ),
        (
            "@native(x) fn f() -> Int",
            "expected one literal native symbol",
        ),
        (
            "@native \"x\" fn f() -> Int",
            "expected `(` and one literal native symbol after `@native`",
        ),
        (
            "@native(\"a#{b}\") fn f() -> Int",
            "expected one literal native symbol without interpolation",
        ),
        ("@native(\"a\"", "expected `)` to close `@native(...)`"),
        (
            "fn f(x) do\n  case x do\n    1 ->\n  end\nend",
            "expected expression after `->`",
        ),
        ("fn f() do\n  let x = \nend", "expected expression"),
        (
            "fn f() do\n  S { 1 }\nend",
            "expected field name in struct literal",
        ),
        (
            "fn f(s) do\n  %{s | 1: 2}\nend",
            "expected field name in struct update",
        ),
        ("struct S do\n  1 :: Int\nend", "expected field name"),
        ("def () do\n  1\nend", "expected function name"),
        ("pub fn () do\n  1\nend", "expected function name"),
        (
            "fn f(x) do\n  case x do\n    y as -> 1\n  end\nend",
            "expected identifier after `as`",
        ),
        (
            "fn f() do\n  json { 1: 2 }\nend",
            "expected identifier key in json literal",
        ),
        (
            "fn f() do\n  let 1 = 2\nend",
            "expected identifier or pattern after `let`",
        ),
        ("from Foo import", "expected import name"),
        (
            "supervisor S do\n  max_restarts: x\nend",
            "expected integer for max_restarts",
        ),
        (
            "supervisor S do\n  max_seconds: x\nend",
            "expected integer for max_seconds",
        ),
        ("interface do\nend", "expected interface name"),
        (
            "fn f() do\n  for 1 in xs do\n    1\n  end\nend",
            "expected loop variable name, pattern, or {key, value} destructuring after `for`",
        ),
        (
            "interface I do\n  fn () -> Int\nend",
            "expected method name",
        ),
        (
            "interface I do\n  let x = 1\nend",
            "expected method signature (fn)",
        ),
        ("module do\nend", "expected module name"),
        ("fn f(+) do\n  1\nend", "expected parameter name or pattern"),
        (
            "service S do\n  call Get(1) :: Int do |s|\n    s\n  end\nend",
            "expected parameter name",
        ),
        (
            "fn f(x) do\n  case x do\n    ) -> 1\n  end\nend",
            "expected pattern",
        ),
        ("pub resource 1", "expected resource name"),
        (
            "supervisor S do\n  child c do\n    restart: 5\n  end\nend",
            "expected restart strategy (permanent, transient, temporary)",
        ),
        ("service do\nend", "expected service name"),
        (
            "supervisor S do\n  child c do\n    shutdown: \"soon\"\n  end\nend",
            "expected shutdown timeout (integer or brutal_kill)",
        ),
        (
            "service S do\n  cast Reset() do |(s)|\n    0\n  end\nend",
            "expected state parameter name",
        ),
        (
            "service S do\n  call Get() :: Int do |(s)|\n    (s, s)\n  end\nend",
            "expected state parameter name",
        ),
        (
            "struct S do\n  table users\nend",
            "expected string literal after `table`",
        ),
        ("struct do\nend", "expected struct name"),
        ("type do\n  A\nend", "expected sum type name"),
        ("supervisor do\nend", "expected supervisor name"),
        (
            "struct S do\n  has_many :posts,\nend",
            "expected target type name after comma in relationship declaration",
        ),
        (
            "struct S do\n  x :: Int\nend deriving(1)",
            "expected trait name in deriving clause",
        ),
        ("impl for Int do\nend", "expected trait name"),
        ("type = Int", "expected type alias name"),
        ("fn f(x :: ) do\n  1\nend", "expected type name"),
        ("type T do\n  1\nend", "expected variant name"),
        // A bad type parameter stops the declaration before its variants.
        ("type T<1> do\n  A\nend", "expected a name"),
        (
            "@export(\"x\") fn f(b :: Bytes) -> Bytes!String",
            "exported functions require a Mesh body",
        ),
        (
            "@native(\"x\") fn f() -> Int do\n  1\nend",
            "native function declarations must not have a Mesh body",
        ),
        (
            "from Foo import *",
            "glob imports are not allowed; import names explicitly",
        ),
        (
            "actor a() do\n  terminate do\n    1\n  end\n  terminate do\n    2\n  end\nend",
            "only one `terminate` clause is allowed per actor block",
        ),
        (
            "fn f(x) do\n  case x do\n    \"a#{b}\" -> 1\n  end\nend",
            "string interpolation not allowed in patterns",
        ),
        (
            "fn f(x) do\n  case x do\n    \"abc",
            "unterminated string: no closing `\"`",
        ),
        (
            "supervisor S do\n  child c do\n    start: fn -> 1 end\n    1\n  end\nend",
            "in child spec body",
        ),
        ("supervisor S do\n  1\nend", "in supervisor body"),
        (
            "struct S do\n  table \"users",
            "unterminated string: no closing `\"`",
        ),
        (
            "fn f(p) do\n  case p do\n    Point { x, .. } -> 0\n  end\nend",
            "`..` is not needed",
        ),
    ];
    let mut misses = Vec::new();
    for (source, expected) in cases {
        let messages: Vec<String> = parse(source)
            .errors()
            .iter()
            .map(|e| e.message.clone())
            .collect();
        if !messages.iter().any(|m| m.contains(expected)) {
            misses.push(format!(
                "{source:?}\n  wanted: {expected}\n  got: {messages:?}"
            ));
        }
    }
    assert!(
        misses.is_empty(),
        "{} misses:\n{}",
        misses.len(),
        misses.join("\n")
    );
}

/// A line that ends in an infix operator or `=`, or a line that starts with
/// an infix operator other than `-` and `%`, continues the statement.
#[test]
fn operators_and_equals_continue_a_statement_across_lines() {
    for source in [
        "fn f(a, b) do\n  let x =\n    a\n  let y = a +\n    b\n  let z = a\n    + b\n  let w = a and\n    b\n  let v = a\n    and b\n  let u = a ==\n    b\n  x\nend",
        "fn f(a) =\n  a * 2",
        "fn f(a) do\n  a\n    |> g()\n    |> h()\nend",
        "fn f() do\n  let g = fn x ->\n    x * 2\n  end\n  let h = fn 0 ->\n    \"zero\"\n  | n -> \"other\"\n  end\n  g\nend",
    ] {
        let parsed = parse(source);
        assert!(parsed.errors().is_empty(), "{source}\n{:?}", parsed.errors());
    }
    // `-` and `%` start statements of their own.
    let parsed = parse("fn f(a) do\n  a\n  -1\nend");
    assert!(parsed.errors().is_empty(), "{:?}", parsed.errors());
    let body_statements = |source: &str| {
        let parsed = parse(source);
        let block = parsed
            .syntax()
            .descendants()
            .find(|n| n.kind() == SyntaxKind::BLOCK)
            .unwrap();
        block.children().count()
    };
    assert_eq!(body_statements("fn f(a) do\n  a\n  -1\nend"), 2);
    assert_eq!(body_statements("fn f(s) do\n  s\n  %{s | x: 1}\nend"), 2);
    assert_eq!(body_statements("fn f(a, b) do\n  a\n    + b\nend"), 1);
}

/// A map entry binding names the key and then the value: nothing else.
#[test]
fn for_in_map_entry_binding_takes_two_names() {
    for binding in ["{k, v}", "{_, v}", "{k, v,}"] {
        let source = format!("fn f(m) do\n  for {binding} in m do\n    1\n  end\nend");
        assert!(
            parse(&source).ok(),
            "{source}: {:?}",
            parse(&source).errors()
        );
    }
    for binding in ["{}", "{, v}", "{k}", "{k,,v}", "{a, b, c}"] {
        let source = format!("fn f(m) do\n  for {binding} in m do\n    1\n  end\nend");
        let parsed = parse(&source);
        assert!(
            parsed
                .errors()
                .first()
                .is_some_and(|error| error.message.contains("expected `{key, value}`")),
            "{source}: {:?}",
            parsed.errors()
        );
    }
}

/// Inputs at the edges of the grammar: each parses, or reports an error
/// without the parser losing its footing.
#[test]
fn edge_inputs_parse_or_report_errors() {
    for (source, ok) in [
        // A generic list names something (`<>` is concatenation).
        ("struct S< > do\nend\n", false),
        ("fn f(x :: Map< >) do\n  x\nend\n", false),
        ("impl Show< > for Int do\nend\n", false),
        ("struct Pair<A, B,> do\nend\n", true),
        // `clustered` that starts no clustered declaration.
        ("clustered.run()\n", true),
        // A negative literal parameter, in a clause and a closure.
        ("fn f(-1) do\n  0\nend\n", true),
        ("fn g() do\n  fn -1 -> 0 | n -> n end\nend\n", true),
        // A negated name is no pattern.
        ("fn f(-x) do\n  x\nend\n", false),
        ("fn g() do\n  fn -x -> x end\nend\n", false),
        // A case inside a call whose `)` comes before its `end`.
        (
            "fn f(x) do\n  g(case x do\n    1 ->\n      a\n  )\nend\n",
            false,
        ),
        // A sum type without `do`, and a bound without `:`.
        ("type Color Red | Green end\n", false),
        ("fn f(x) where T Display do\n  x\nend\n", false),
    ] {
        let parse = mesh_parser::parse(source);
        assert_eq!(
            parse.errors().is_empty(),
            ok,
            "{source:?}: {:?}",
            parse.errors()
        );
    }
}

/// `if x = 5 do` and `while x = 5 do`, a comparison written as a binding,
/// say `==` compares; any other missing `do` says only that it is missing.
#[test]
fn a_binding_where_a_condition_compares_names_the_comparison() {
    for (source, compare) in [
        ("fn f(x) do\n  if x = 5 do\n    1\n  end\nend\n", true),
        ("fn f(x) do\n  while x = 5 do\n    1\n  end\nend\n", true),
        ("fn f(x) do\n  if x > 5 then\n    1\n  end\nend\n", false),
    ] {
        let parse = mesh_parser::parse(source);
        let first = parse
            .errors()
            .first()
            .expect("a parse error")
            .message
            .clone();
        assert!(first.starts_with("expected `do`"), "{source:?}: {first}");
        assert_eq!(first.contains("`==`"), compare, "{source:?}: {first}");
    }
}

/// `x = 5` as a statement, an assignment to a bound name, says names are
/// bound once.
#[test]
fn an_assignment_statement_says_names_are_bound_once() {
    let parse = mesh_parser::parse("fn f() do\n  let x = 1\n  x = 2\n  x\nend\n");
    let first = parse
        .errors()
        .first()
        .expect("a parse error")
        .message
        .clone();
    assert!(first.contains("cannot be assigned again"), "{first}");
}

/// `test "adds" do`, a call written without parentheses, says to put the
/// arguments in them; a value after a value does not.
#[test]
fn a_call_without_parentheses_says_to_add_them() {
    for (source, hint) in [
        ("test \"adds\" do\n  1\nend\n", Some("test(...)")),
        ("fn f(x) do\n  g 5\nend\n", Some("g(...)")),
        ("fn f() do\n  \"a\" \"b\"\nend\n", None),
    ] {
        let parse = mesh_parser::parse(source);
        let first = parse
            .errors()
            .first()
            .expect("a parse error")
            .message
            .clone();
        match hint {
            Some(call) => assert!(first.contains(call), "{source:?}: {first}"),
            None => assert!(!first.contains("parentheses"), "{source:?}: {first}"),
        }
    }
}
