//! JSON field extraction runtime functions for Mesh.
//!
//! Provides intrinsics that inspect and extract fields from JSON strings using
//! serde_json. These replace PostgreSQL JSONB parsing roundtrips
//! (`$1::jsonb->>'key'`) with in-process extraction.
//!
//! The extraction functions follow the existing COALESCE behavior:
//! - If the field exists and is a string, return the string value
//! - If the field exists and is a number/bool/null, convert to string
//! - If the field is missing or JSON is invalid, return empty string ""

use crate::string::{mesh_str, text_of};
use serde_json::Value;

// ── Pure Rust helpers (testable without GC) ─────────────────────────

/// `json_str` parsed, or `None` for text that is not JSON.
fn parse(json_str: &str) -> Option<Value> {
    serde_json::from_str(json_str).ok()
}

/// Extract a top-level field from a JSON string by key.
/// Returns the field value as a string, or empty string if missing/invalid.
fn json_get_field(json_str: &str, key: &str) -> String {
    value_to_string(parse(json_str).as_ref().and_then(|value| value.get(key)))
}

/// Extract a nested field from a JSON string by two path segments.
/// Traverses `value[path1][path2]` and returns the leaf as a string.
/// Returns empty string if any segment is missing or JSON is invalid.
fn json_get_nested_field(json_str: &str, path1: &str, path2: &str) -> String {
    let value = parse(json_str);
    value_to_string(value.as_ref().and_then(|v| v.get(path1)?.get(path2)))
}

/// Return whether a top-level field exists and is a JSON string.
fn json_field_is_string(json_str: &str, key: &str) -> bool {
    parse(json_str).is_some_and(|value| value.get(key).is_some_and(Value::is_string))
}

/// Convert an optional serde_json::Value to a string representation.
/// Matches PostgreSQL `->>` operator behavior:
/// - String values are returned directly (no quotes)
/// - Numbers, bools, arrays and objects as their JSON text
/// - Null and missing values return empty string
fn value_to_string(val: Option<&Value>) -> String {
    match val {
        None | Some(Value::Null) => String::new(),
        Some(Value::String(s)) => s.clone(),
        Some(other) => other.to_string(),
    }
}

// ── Extern C wrappers ───────────────────────────────────────────────

/// Extract a top-level string field from a JSON string.
///
/// `Json.get(body, "user_id")` replaces
/// `Pool.query(pool, "SELECT COALESCE($1::jsonb->>'user_id', '') AS user_id", [body])`
///
/// Returns empty string on invalid JSON or missing key (matches COALESCE behavior).
#[no_mangle]
pub extern "C" fn mesh_json_get(json_ptr: *mut u8, key_ptr: *mut u8) -> *mut u8 {
    unsafe { mesh_str(&json_get_field(text_of(json_ptr), text_of(key_ptr))) as *mut u8 }
}

/// Extract a nested string field from a JSON string (two levels deep).
///
/// `Json.get_nested(message, "filters", "level")` replaces
/// `Pool.query(pool, "SELECT COALESCE($1::jsonb->'filters'->>'level', '') AS level", [message])`
///
/// Returns empty string on invalid JSON or missing path (matches COALESCE behavior).
#[no_mangle]
pub extern "C" fn mesh_json_get_nested(
    json_ptr: *mut u8,
    path1_ptr: *mut u8,
    path2_ptr: *mut u8,
) -> *mut u8 {
    unsafe {
        let nested =
            json_get_nested_field(text_of(json_ptr), text_of(path1_ptr), text_of(path2_ptr));
        mesh_str(&nested) as *mut u8
    }
}

/// Return true only when the top-level field exists and is a JSON string.
#[no_mangle]
pub extern "C" fn mesh_json_is_string(json_ptr: *mut u8, key_ptr: *mut u8) -> i8 {
    unsafe { json_field_is_string(text_of(json_ptr), text_of(key_ptr)) as i8 }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_json_get_string_field() {
        let result = json_get_field(r#"{"user_id":"abc123","name":"Test"}"#, "user_id");
        assert_eq!(result, "abc123");
    }

    #[test]
    fn test_json_get_number_field() {
        let result = json_get_field(r#"{"count":42}"#, "count");
        assert_eq!(result, "42");
    }

    #[test]
    fn test_json_get_bool_field() {
        let result = json_get_field(r#"{"enabled":true}"#, "enabled");
        assert_eq!(result, "true");
    }

    #[test]
    fn test_json_get_null_field() {
        let result = json_get_field(r#"{"field":null}"#, "field");
        assert_eq!(result, "");
    }

    #[test]
    fn test_json_get_missing_field() {
        let result = json_get_field(r#"{"other":"value"}"#, "missing");
        assert_eq!(result, "");
    }

    #[test]
    fn test_json_get_invalid_json() {
        let result = json_get_field("not valid json", "key");
        assert_eq!(result, "");
    }

    #[test]
    fn test_json_get_empty_string() {
        let result = json_get_field("", "key");
        assert_eq!(result, "");
    }

    #[test]
    fn test_json_get_nested_string() {
        let result = json_get_nested_field(
            r#"{"filters":{"level":"error","environment":"production"}}"#,
            "filters",
            "level",
        );
        assert_eq!(result, "error");
    }

    #[test]
    fn test_json_get_nested_environment() {
        let result = json_get_nested_field(
            r#"{"filters":{"level":"error","environment":"production"}}"#,
            "filters",
            "environment",
        );
        assert_eq!(result, "production");
    }

    #[test]
    fn test_json_get_nested_missing_outer() {
        let result = json_get_nested_field(r#"{"other":"value"}"#, "filters", "level");
        assert_eq!(result, "");
    }

    #[test]
    fn test_json_get_nested_missing_inner() {
        let result =
            json_get_nested_field(r#"{"filters":{"level":"error"}}"#, "filters", "missing");
        assert_eq!(result, "");
    }

    #[test]
    fn test_json_get_nested_invalid_json() {
        let result = json_get_nested_field("not json", "a", "b");
        assert_eq!(result, "");
    }

    #[test]
    fn test_json_get_nested_outer_not_object() {
        let result =
            json_get_nested_field(r#"{"filters":"string_not_object"}"#, "filters", "level");
        assert_eq!(result, "");
    }

    #[test]
    fn test_json_get_dynamic_key() {
        // Simulates the pipeline.mpl pattern: extract_condition_field(pool, condition_json, field)
        let json = r#"{"threshold":"100","window_minutes":"5"}"#;
        assert_eq!(json_get_field(json, "threshold"), "100");
        assert_eq!(json_get_field(json, "window_minutes"), "5");
        assert_eq!(json_get_field(json, "nonexistent"), "");
    }

    #[test]
    fn test_json_get_enabled_with_default() {
        // Simulates the alerts.mpl pattern: COALESCE($1::jsonb->>'enabled', 'true')
        let with_field = json_get_field(r#"{"enabled":"false"}"#, "enabled");
        assert_eq!(with_field, "false");

        let without_field = json_get_field(r#"{}"#, "enabled");
        assert_eq!(without_field, ""); // caller defaults to "true" when empty
    }

    /// The Mesh functions answer the helpers' results as Mesh values: a
    /// false, an array as its JSON, a string test as 1.
    #[test]
    fn the_mesh_functions_read_and_answer_mesh_strings() {
        crate::gc::mesh_rt_init();
        let s = |text: &str| mesh_str(text) as *mut u8;
        let json = s(r#"{"a":{"b":false},"c":[1],"d":"x"}"#);
        let nested = mesh_json_get_nested(json, s("a"), s("b"));
        assert_eq!(unsafe { text_of(nested) }, "false");
        assert_eq!(unsafe { text_of(mesh_json_get(json, s("c"))) }, "[1]");
        assert_eq!(mesh_json_is_string(json, s("d")), 1);
    }

    #[test]
    fn test_json_field_is_string_distinguishes_json_types() {
        let json = r#"{"string":"42","number":42,"nested":{"value":"ok"}}"#;
        assert!(json_field_is_string(json, "string"));
        assert!(!json_field_is_string(json, "number"));
        assert!(json_field_is_string(
            &json_get_field(json, "nested"),
            "value"
        ));
    }
}
