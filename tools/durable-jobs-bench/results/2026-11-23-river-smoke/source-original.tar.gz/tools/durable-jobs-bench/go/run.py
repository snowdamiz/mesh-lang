#!/usr/bin/env python3
"""Provision one capped PostgreSQL cluster and run a single River matrix arm."""

import argparse
import datetime
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile

from prepare_input import PROFILES, harness

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from verify import PROFILES as MATRIX_PROFILES, reconcile, require

VERSION = "river v0.51.2 / pgx v5.13.0 / go1.26.4"
EPOCH = datetime.datetime(1970, 1, 1, tzinfo=datetime.timezone.utc)


class Cluster(harness["Cluster"]):
    def configure_tls(self):
        super().configure_tls()
        with (self.data / "postgresql.conf").open("a") as stream:
            stream.write(f"max_connections = {self.connection_cap}\n"
                         "superuser_reserved_connections = 0\nreserved_connections = 0\n"
                         "fsync = on\nfull_page_writes = on\n")


def epoch_us(timestamp):
    delta = datetime.datetime.fromisoformat(timestamp) - EPOCH
    return (delta.days * 86400 + delta.seconds) * 1_000_000 + delta.microseconds


def translate(raw, profile, binary):
    def read(path):
        return json.loads((raw / path).read_text())

    build = read("config.json")
    modules = {item["Path"]: item["Version"] for item in build["build"]["Deps"]}
    require(build["build"]["GoVersion"] == "go1.26.4" and all(modules.get(name) == version for name, version in {
        "github.com/riverqueue/river": "v0.51.2",
        "github.com/riverqueue/river/riverdriver/riverpgxv5": "v0.51.2",
        "github.com/jackc/pgx/v5": "v5.13.0",
    }.items()), "River build pins differ from the matrix inventory")
    binary_hash = harness["digest"](binary)
    require(build["binary_sha256"] == binary_hash, "executed River artifact differs from binary digest")
    metrics = read("measured/metrics.json")
    database = read("database.json")
    database["version"] = "17.11"
    ledger = read("measured/ledger.json")
    attempts = {row["job_key"]: row for row in ledger["attempts"]}
    effects = {row["job_key"]: row for row in ledger["effects"]}
    transactions = []
    for line in (raw / "measured/enqueue.jsonl").read_text().splitlines():
        row = json.loads(line)
        transactions.append(dict(request_id=row["request_id"], submitted_us=row["submitted_us"],
                                 committed_us=epoch_us(row["commit"]), returned_us=row["returned_us"],
                                 xid=row["xid"], enqueued_ids=row["ids"]))
    jobs = []
    for row in ledger["jobs"]:
        key = row["key"]
        a, e = attempts[key], effects[key]
        jobs.append(dict(id=row["id"], job_key=key, payload_sha256=row["payload_sha256"],
                         hold_ms=row["hold_ms"], fail_first=row["fail_first"], state=row["state"],
                         attempt=row["attempt"], attempts=1, effects=1, entered_us=epoch_us(a["entered_at"]),
                         attempt_xid=a["xid"], effect_xid=e["xid"], settled_xid=row["settled_xid"],
                         attempt_committed_us=epoch_us(a["committed"]), effect_committed_us=epoch_us(e["committed"]),
                         settled_us=epoch_us(row["settled"]), claimed_us=epoch_us(row["claimed"])))
    runners, slots, _, _, _ = MATRIX_PROFILES[profile]
    peak = metrics["peak_samples"]
    return dict(engine="go", version=VERSION, profile=profile, artifact_sha256=binary_hash,
                input_sha256=metrics["input_sha256"], runners=runners, slots=slots,
                database=database, runner_cpu_seconds=metrics["runner_cpu_seconds_including_startup_and_idle"],
                peak_executing=metrics["concurrent_handler_upper_bound"], peak_connections=peak["connections"],
                peak_runner_rss_bytes=peak["rss_bytes"], jobs=jobs, transactions=transactions)


def arm(args):
    out = args.output.resolve(strict=True)
    require(args.output.is_absolute() and not args.output.is_symlink() and out.is_dir()
            and not any(out.iterdir()), "the matrix must supply an empty absolute output directory")
    binary = args.binary.resolve(strict=True)
    scratch = args.scratch.resolve(strict=True)
    os.environ["PG_BIN_DIR"] = str(args.pg_bin.resolve(strict=True))
    os.umask(0o077)
    raw = out / "river"
    slots, frozen = PROFILES[args.profile]
    settings = json.loads(harness["CONFIG"].read_text())
    batches = harness["inputs"](settings["workloads"][args.profile], slots, settings["seed"])
    phase = os.environ.get("DURABLE_JOBS_PHASE", "diagnostic")
    harness["write_json"](out / "runtime.json", {"phase": phase, "version": VERSION, "artifact_sha256": harness["digest"](binary)})
    with tempfile.TemporaryDirectory(prefix="arm-", dir=scratch) as location:
        work = Path(location)
        inputs = work / "input"
        inputs.mkdir()
        paths = harness["batch_files"](inputs, batches)
        harness["write_json"](out / "input.json", {"input_sha256": frozen, "batch_digests": {
            path.name: harness["digest"](path) for path in paths}})
        cluster = Cluster(work, work, MATRIX_PROFILES[args.profile][2], "17.11")
        try:
            cluster.start()
            cluster.sql("postgres", f"CREATE DATABASE river OWNER parity_subject CONNECTION LIMIT {cluster.connection_cap}")
            cluster.sql("postgres", "SELECT pg_stat_statements_reset()")
            env = dict(cluster.env, RIVER_BENCH_DATABASE_URL=cluster.url("river"))
            command = [str(binary), "-single", "-profile", args.profile, "-input", str(inputs), "-out", str(raw)]
            if args.smoke:
                command.append("-smoke")
            result = subprocess.run(command, env=env, check=False)
            if result.returncode:
                raise RuntimeError(f"River binary exited {result.returncode}")
            counters = json.loads(cluster.sql("postgres", """
                SELECT json_build_object('calls', coalesce(sum(calls), 0), 'distinct_statements', count(*),
                    'dealloc', (SELECT dealloc FROM pg_stat_statements_info))
                FROM pg_stat_statements WHERE dbid = (SELECT oid FROM pg_database WHERE datname = 'river')
            """))
            harness["write_json"](out / "counters.json", counters)
            if args.smoke:
                return
            ledger = translate(raw, args.profile, binary)
            metrics = reconcile(ledger, "go", args.profile,
                                {"version": VERSION, "artifact_sha256": harness["digest"](binary)})
            harness["write_json"](out / "ledger.json", ledger)
            harness["write_json"](out / "metrics.json", metrics)
        finally:
            cluster.stop()


def interrupt(signum, _frame):
    raise SystemExit(128 + signum)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--scratch", type=Path, required=True)
    parser.add_argument("--pg-bin", type=Path, required=True)
    parser.add_argument("--smoke", action="store_true", help="functional run with rollback and retry witnesses")
    parser.add_argument("profile", choices=PROFILES)
    parser.add_argument("output", type=Path)
    signal.signal(signal.SIGTERM, interrupt)
    try:
        arm(parser.parse_args())
    except (OSError, ValueError, RuntimeError) as error:
        raise SystemExit(str(error)) from None


if __name__ == "__main__":
    main()
