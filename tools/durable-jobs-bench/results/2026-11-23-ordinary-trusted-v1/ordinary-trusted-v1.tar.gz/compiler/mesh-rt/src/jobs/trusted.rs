use std::sync::Arc;
use std::time::Instant;

use crossbeam_channel::{Receiver, Sender, TryRecvError};
use parking_lot::Mutex;

use crate::actor::{
    global_scheduler,
    process::{ExitReason, ProcessId},
};

use super::runner::JobProcess;
use super::worker::{boot_millis, host_deadline, invoke_in_current_context, Handler, WorkerPoll};

struct Authority {
    deadline: u64,
    lease: u64,
    stopped: bool,
}

impl Authority {
    fn expired(&self, now: u64) -> Option<WorkerPoll> {
        if now < self.deadline.min(self.lease) {
            None
        } else if self.deadline <= self.lease {
            Some(WorkerPoll::TimedOut)
        } else {
            Some(WorkerPoll::LeaseExpired)
        }
    }
}

pub(super) struct TrustedAttempt {
    pid: ProcessId,
    authority: Arc<Mutex<Authority>>,
    result: Receiver<WorkerPoll>,
}

impl TrustedAttempt {
    pub(super) fn start(
        handler: Handler,
        context: String,
        deadline: Instant,
        lease: u64,
        wake: Sender<()>,
    ) -> Result<Self, String> {
        let authority = Arc::new(Mutex::new(Authority {
            deadline: host_deadline(deadline)?,
            lease,
            stopped: false,
        }));
        let (send, result) = crossbeam_channel::bounded(1);
        let guard = Arc::clone(&authority);
        // Capture the guard before spawning so rejecting a queued actor also drops it.
        let completion = Completion { send, wake };
        let pid = global_scheduler().spawn_owned(move || {
            let completion = completion;
            let reply = match check(&guard) {
                Ok(()) => {
                    let reply =
                        invoke_in_current_context(context, |input| unsafe { handler(input) });
                    check(&guard).err().unwrap_or(WorkerPoll::Exited(reply))
                }
                Err(reply) => reply,
            };
            let _ = completion.send.try_send(reply);
        });
        Ok(Self {
            pid,
            authority,
            result,
        })
    }
}

fn check(authority: &Mutex<Authority>) -> Result<(), WorkerPoll> {
    let state = authority.lock();
    if state.stopped {
        return Err(WorkerPoll::Exited(Err("trusted job was stopped".into())));
    }
    let now = boot_millis().map_err(|err| WorkerPoll::Exited(Err(err.to_string())))?;
    state.expired(now).map_or(Ok(()), Err)
}

struct Completion {
    send: Sender<WorkerPoll>,
    wake: Sender<()>,
}

impl Drop for Completion {
    fn drop(&mut self) {
        let _ = self.wake.try_send(());
    }
}

impl JobProcess for TrustedAttempt {
    fn reply_pending(&self) -> bool {
        !self.result.is_empty()
    }

    fn poll(&mut self, _: Instant) -> Result<WorkerPoll, String> {
        match self.result.try_recv() {
            Ok(reply) => Ok(reply),
            Err(TryRecvError::Empty) => Ok(WorkerPoll::Running),
            Err(TryRecvError::Disconnected) => Ok(WorkerPoll::Exited(Err(
                "trusted job actor exited without a result (panic or cooperative stop)".into(),
            ))),
        }
    }

    fn renew(&mut self, lease: u64) -> Result<(), String> {
        let mut state = self.authority.lock();
        let now = boot_millis().map_err(|err| err.to_string())?;
        if state.stopped || state.expired(now).is_some() {
            return Err("trusted job could not accept renewal after its deadline".into());
        }
        state.lease = state.lease.max(lease);
        Ok(())
    }

    fn kill(&mut self) -> Result<(), String> {
        let mut state = self.authority.lock();
        if !state.stopped {
            state.stopped = true;
            if let Some(process) = crate::actor::process(self.pid) {
                global_scheduler().force_exit(self.pid, process.lock(), ExitReason::Shutdown);
            }
        }
        Ok(())
    }
}

impl Drop for TrustedAttempt {
    fn drop(&mut self) {
        let _ = self.kill();
    }
}
