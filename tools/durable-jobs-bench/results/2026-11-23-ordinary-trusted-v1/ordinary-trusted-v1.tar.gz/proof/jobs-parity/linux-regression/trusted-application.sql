BEGIN;
ALTER TABLE public.mesh_jobs_parity_attempts
    ADD COLUMN job_id uuid NOT NULL,
    ADD COLUMN job_generation text NOT NULL,
    ADD UNIQUE (namespace, job_id, job_generation, attempt);
ALTER TABLE public.mesh_jobs_parity_attempts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mesh_jobs_parity_effects ENABLE ROW LEVEL SECURITY;
CREATE POLICY trusted_attempt_insert ON public.mesh_jobs_parity_attempts
    FOR INSERT TO compiled_caller
    WITH CHECK (engine = 'mesh' AND namespace = '@NAMESPACE@' AND effect_key = job_key);
CREATE POLICY trusted_effect_insert ON public.mesh_jobs_parity_effects
    FOR INSERT TO compiled_caller
    WITH CHECK (engine = 'mesh' AND namespace = '@NAMESPACE@' AND effect_key = job_key);
-- ON CONFLICT reads the indexed columns. The role may see only its namespace.
CREATE POLICY trusted_attempt_read ON public.mesh_jobs_parity_attempts
    FOR SELECT TO compiled_caller USING (engine = 'mesh' AND namespace = '@NAMESPACE@');
CREATE POLICY trusted_effect_read ON public.mesh_jobs_parity_effects
    FOR SELECT TO compiled_caller USING (engine = 'mesh' AND namespace = '@NAMESPACE@');
GRANT USAGE ON SCHEMA public TO compiled_caller;
GRANT INSERT ON public.mesh_jobs_parity_attempts, public.mesh_jobs_parity_effects TO compiled_caller;
GRANT SELECT (namespace, job_id, job_generation, attempt)
    ON public.mesh_jobs_parity_attempts TO compiled_caller;
GRANT SELECT (engine, namespace, effect_key)
    ON public.mesh_jobs_parity_effects TO compiled_caller;
COMMIT;
