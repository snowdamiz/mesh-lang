#include <errno.h>
#include <spawn.h>
#include <stdio.h>
#include <sys/resource.h>
#include <sys/wait.h>

extern char **environ;

int main(int argc, char **argv) {
    if (argc < 2) return 2;
    pid_t pid;
    if (posix_spawn(&pid, argv[1], NULL, NULL, &argv[1], environ) != 0) return 3;
    int status;
    struct rusage usage;
    pid_t result;
    do { result = wait4(pid, &status, 0, &usage); } while (result < 0 && errno == EINTR);
    if (result != pid) return 4;
    fprintf(stderr, "%ld maximum resident set size\n", usage.ru_maxrss);
    fprintf(stderr, "subject cpu_us %lld %lld\n", 1000000LL*usage.ru_utime.tv_sec+usage.ru_utime.tv_usec,
            1000000LL*usage.ru_stime.tv_sec+usage.ru_stime.tv_usec);
    return WIFEXITED(status) ? WEXITSTATUS(status) : 1;
}
