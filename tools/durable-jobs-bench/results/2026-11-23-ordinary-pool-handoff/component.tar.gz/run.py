from support import LANE, ROOT, DB, SCHEMA, parity, launch
from pathlib import Path
from hashlib import sha256
import sys, json, tempfile, os, fcntl, time

def run(out):
    out.mkdir()
    binary=LANE/'actor'
    orders=[('service','direct','duplicate'),('duplicate','direct','service'),
            ('direct','service','duplicate'),('service','duplicate','direct'),
            ('duplicate','service','direct'),('direct','duplicate','service')]
    with (ROOT/'target/queue-performance.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        with tempfile.TemporaryDirectory(prefix='ap-',dir=ROOT/'target') as tmp:
            cluster=parity.Cluster(Path(tmp),out,17,'17.11')
            try:
                cluster.start()
                cluster.prepare_database(DB)
                cluster.sql(DB,SCHEMA)
                metadata=dict(sha256=sha256(binary.read_bytes()).hexdigest(), orders=orders,
                              description="2 fixed scheduler workers, 8 actors and 8 verified TLS connections, 64 write pairs each",
                              settings=cluster.sql(DB,"SELECT current_setting('server_version'),current_setting('synchronous_commit'),current_setting('fsync'),current_setting('track_commit_timestamp')"))
                (out/'manifest.json').write_text(json.dumps(metadata,indent=2)+'\n')
                with (out/'results.jsonl').open('x',buffering=1) as log:
                    for group,order in enumerate(orders,1):
                        for arm in order:
                            os.environ['POOL_HANDOFF_MODE']='direct' if arm=='direct' else 'service'
                            ns=f'g{group}_a{("service","direct","duplicate").index(arm)}'
                            v=launch(cluster,binary,2,8,64,ns,8)
                            v.update(group=group,mode=arm,load=os.getloadavg(),finished=time.time())
                            print(json.dumps(v,sort_keys=True),file=log)
                            print(group,arm,round(v['elapsed_ms'],2),v['user_us']+v['sys_us'],flush=True)
            finally:
                cluster.stop()

if __name__=='__main__':
    run(LANE/'evidence'/sys.argv[1])
