#!/usr/bin/env python3
"""Run optimized compiled actors against an owned, verified TLS cluster."""
import argparse
import ctypes
import importlib.util
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import tempfile
import time

LANE = Path(__file__).resolve().parent
ROOT = LANE.parents[1]
spec = importlib.util.spec_from_file_location("parity", ROOT / "scripts/jobs-parity.py")
parity = importlib.util.module_from_spec(spec)
spec.loader.exec_module(parity)

DB = "actor_pg"
SCHEMA = """
ALTER TABLE mesh_jobs_parity_attempts ADD COLUMN job_id uuid NOT NULL;
ALTER TABLE mesh_jobs_parity_attempts ADD COLUMN job_generation text NOT NULL;
CREATE UNIQUE INDEX ON mesh_jobs_parity_attempts (namespace, job_id, job_generation, attempt);
"""
LIBPROC = ctypes.CDLL("/usr/lib/libproc.dylib") if os.uname().sysname == "Darwin" else None

class TaskInfo(ctypes.Structure):
    _fields_ = [(name, ctypes.c_uint64) for name in (
        "virtual", "resident", "user", "system", "threads_user", "threads_system",
    )] + [(name, ctypes.c_int32) for name in (
        "policy", "faults", "pageins", "cow", "sent", "received", "mach", "unix",
        "switches", "threads", "running", "priority",
    )]

def thread_count(parent):
    if LIBPROC:
        child = ctypes.c_int()
        if LIBPROC.proc_listchildpids(parent, ctypes.byref(child), ctypes.sizeof(child)) <= 0:
            return 0
        info = TaskInfo()
        if LIBPROC.proc_pidinfo(child, 4, ctypes.c_uint64(0), ctypes.byref(info),
                                ctypes.sizeof(info)) == ctypes.sizeof(info):
            return info.threads
        return 0
    children = Path(f"/proc/{parent}/task/{parent}/children")
    try:
        pid, *_ = children.read_text().split()
        return sum(1 for _ in Path(f"/proc/{pid}/task").iterdir())
    except (OSError, ValueError):
        return 0

SAMPLE = """
SELECT count(*) || '|' || count(*) FILTER (WHERE ssl) || '|' ||
       count(*) FILTER (WHERE state='active' AND query LIKE 'SELECT $1::text AS actor_id, pg_sleep%') || '|' ||
       count(*) FILTER (WHERE state='active' AND query LIKE 'INSERT INTO public.mesh_jobs_parity_%') || '|' ||
       count(*) FILTER (WHERE state LIKE 'idle in transaction%')
FROM pg_stat_activity JOIN pg_stat_ssl USING (pid)
WHERE usename='parity_subject' AND datname=current_database();
"""

def check(condition, message):
    if not condition:
        raise RuntimeError(message)

def launch(cluster, binary, workers, actors, repetitions, ns, cap, expected_rejected=0):
    with tempfile.TemporaryDirectory(dir=cluster.scratch) as folder:
        folder = Path(folder)
        env = dict(os.environ, ACTOR_PG_URL=cluster.url(DB), ACTOR_PG_NS=ns,
                   ACTOR_PG_ACTORS=str(actors), ACTOR_PG_WRITES=str(repetitions),
                   ACTOR_PG_POOL=str(cap), ACTOR_PG_DONE=str(folder / "finished"),
                   ACTOR_PG_SLEEP="0.8" if expected_rejected else "0.05", MESH_SCHEDULER_MIN_WORKERS=str(workers),
                   MESH_SCHEDULER_MAX_WORKERS=str(workers))
        args, observer_env = cluster.psql(DB)
        with (folder / "samples").open("w+") as samples, (folder / "stdout").open("w+") as stdout, (folder / "stderr").open("w+") as stderr:
            observer = subprocess.Popen(args, env=observer_env, stdin=subprocess.PIPE,
                                        stdout=samples, stderr=stderr, text=True)
            proc = subprocess.Popen([str(LANE / "measure"), str(binary)], env=env,
                                    stdout=stdout, stderr=stderr, start_new_session=True)
            try:
                observer.stdin.write(SAMPLE + "\\watch 0.005\n")
                observer.stdin.flush()
                peak_threads = 0
                deadline = time.monotonic() + 25
                while proc.poll() is None:
                    check(time.monotonic() < deadline, f"{binary.name} {ns} timed out")
                    peak_threads = max(peak_threads, thread_count(proc.pid))
                    time.sleep(0.004)
                check(proc.returncode == 0, f"{binary.name} {ns} failed")
            finally:
                if proc.poll() is None:
                    os.killpg(proc.pid, signal.SIGKILL)
                    proc.wait()
                observer.terminate()
                observer.wait(timeout=5)
            stdout.seek(0)
            lines = stdout.read().splitlines()
            stderr.seek(0)
            resources = stderr.read()
            samples.seek(0)
            activity = [list(map(int, line.strip().split("|"))) for line in samples
                        if re.fullmatch(r"\d+\|\d+\|\d+\|\d+\|\d+", line.strip())]
        if any("error" in line for line in lines):
            raise RuntimeError(f"{ns} reported an error: " + str(lines).replace(cluster.password, "[redacted]"))
        events = [line.split() for line in lines]
        start, = [int(e[1]) for e in events if e[0] == "start"]
        tick, = [(int(e[1]), int(e[2])) for e in events if e[0] == "tick"]
        dones = {int(e[1]): int(e[2]) for e in events if e[0] == "done"}
        rejected = {int(e[1]) for e in events if e[0] == "rejected"}
        check(len(rejected) == expected_rejected and not rejected.intersection(dones)
              and set(dones).union(rejected) == set(range(1, actors + 1))
              and len(events) == actors + 3, f"incomplete events {ns}: {lines}")
        peak_conn, peak_tls, peak_sleep, peak_writes, idle_tx = map(max, zip(*activity))
        check(peak_conn == peak_tls == cap and idle_tx == 0, f"invalid TLS/cap/transaction samples: {ns}")
        usage = re.search(r"(\d+)\s+maximum resident set size", resources)
        check(usage and peak_threads, f"missing resources: {ns}")
        ledger = list(map(int, cluster.sql(DB, f"""
SELECT count(*) FILTER (WHERE kind=1), count(*) FILTER (WHERE kind=2),
       count(DISTINCT xid::text), count(*) FILTER (WHERE pg_xact_commit_timestamp(xid) IS NOT NULL)
FROM (
  SELECT 1 AS kind, xmin AS xid FROM mesh_jobs_parity_attempts WHERE namespace='{ns}'
  UNION ALL
  SELECT 2, xmin FROM mesh_jobs_parity_effects WHERE namespace='{ns}'
) AS writes
""").split("|")))
        expected = actors * repetitions
        check(ledger == [expected, expected, 2 * expected, 2 * expected], f"bad commits {ns}: {ledger}")
        pairs = int(cluster.sql(DB, f"""
SELECT count(*) FROM mesh_jobs_parity_attempts a JOIN mesh_jobs_parity_effects e
ON a.namespace=e.namespace AND a.job_key=e.job_key AND a.effect_key=e.effect_key
WHERE a.namespace='{ns}' AND a.xmin<>e.xmin AND pg_xact_commit_timestamp(a.xmin)<=pg_xact_commit_timestamp(e.xmin)
"""))
        check(pairs == expected, f"bad attempt/effect pairing {ns}: {pairs}")
        user_us, sys_us = map(int, re.search(r"subject cpu_us (\d+) (\d+)", resources).groups())
        return {"user_us": user_us, "sys_us": sys_us, "arm": binary.name, "sched_workers": workers, "actors": actors,
                "rounds_per_actor": repetitions, "run": ns, "rejected": len(rejected), "elapsed_ms": (max(dones.values())-start)/1e6,
                "tick_lateness_ms": (tick[0]-tick[1])/1e6, "rss_bytes": int(usage[1]),
                "peak_threads": peak_threads, "peak_pool_connections": peak_conn, "peak_tls_connections": peak_tls,
                "peak_active_sleep": peak_sleep, "peak_active_write": peak_writes,
                "activity_samples": len(activity), "committed_attempts": ledger[0],
                "committed_effects": ledger[1], "unique_committed_xids": ledger[2], "matched_pairs": pairs}

