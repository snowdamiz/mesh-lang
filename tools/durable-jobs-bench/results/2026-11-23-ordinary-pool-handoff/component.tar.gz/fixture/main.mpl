from Writes import record_attempt, record_effect

fn sleep_query(pool :: PoolHandle, id :: Int) -> Int!String do
  let delay = Env.get("ACTOR_PG_SLEEP", "0.05")
  let rows = Pool.query(pool, "SELECT $1::text AS actor_id, pg_sleep($2::double precision)", [String.from(id), delay])?
  let first = List.head(rows)
  if Map.get(first, "actor_id") == String.from(id) && List.length(rows) == 1 do
    Ok(1)
  else
    Err("bad query value")
  end
end

service ApplicationPool do
  fn init(pool :: PoolHandle) -> PoolHandle do
    pool
  end

  call Current() :: PoolHandle do |pool|
    (pool, pool)
  end
end

fn writes(pool :: PoolHandle, ns :: String, id :: Int, n :: Int, via_owner :: Bool) -> Int!String do
  if n == 0 do
    Ok(0)
  else
    let key = "${id}-${n}"
    let identity = "00000000-0000-0000-0000-${100000000000 + id * 10000 + n}"
    let selected = if via_owner do
      ApplicationPool.current(Process.whereis("parity-app-pool"))
    else
      pool
    end
    let attempt = record_attempt(selected, ns, key, identity, "1", 1, 1800000000000000, id)?
    let effect = record_effect(selected, ns, key)?
    if attempt == 1 && effect == 1 do
      writes(pool, ns, id, n - 1, via_owner)
    else
      Err("unexpected write count")
    end
  end
end

actor client(pool :: PoolHandle, id :: Int, n :: Int, ns :: String, parent :: Pid<Int>) do
  receive do
    go ->
      let result = if n == 0 do
        sleep_query(pool, id)
      else
        writes(pool, ns, id, n, Env.get("POOL_HANDOFF_MODE", "service") == "service")
      end
      case result do
        Ok(_) -> println("done ${id} ${Monotonic.now_nanos()}")
        Err(error) ->
          if error == "actor PostgreSQL executor is full" do
            println("rejected ${id}")
          else
            println("error ${id} ${error}")
          end
      end
      send(parent, id)
  end
end

fn clients(pool :: PoolHandle, n :: Int, ns :: String, left :: Int, parent :: Pid<Int>) -> List<Pid<Int>> do
  if left <= 0 do
    []
  else
    List.append(clients(pool, n, ns, left - 1, parent), spawn(client, pool, left, n, ns, parent))
  end
end

actor heartbeat(parent :: Pid<Int>) do
  receive do
    target ->
      let actual = Monotonic.now_nanos()
      println("tick ${actual} ${target}")
      send(parent, 0)
  end
end

fn env_int(key :: String, fallback :: Int) -> Int do
  case String.to_int(Env.get(key, "")) do
    Some(n) -> n
    None -> fallback
  end
end

actor coordinate(count :: Int, milestone :: String) do
  for i in 0..(count + 1) do
    let ended = receive do
      id -> id + 0
    after 10000 -> -1
    end
    if ended == -1 do
      println("error completion timeout")
    end
  end
  let _ = File.write(milestone, "done")
  ()
end

fn main() do
  let dsn = Env.get("ACTOR_PG_URL", "")
  let repetitions = env_int("ACTOR_PG_WRITES", 0)
  let min = env_int("ACTOR_PG_POOL", 16)
  let count = env_int("ACTOR_PG_ACTORS", 16)
  let milestone = Env.get("ACTOR_PG_DONE", "")
  case Pool.open(dsn, min, min, 5000) do
    Err(e) -> println("open error ${e}")
    Ok(pool) ->
      let owner = ApplicationPool.start(pool)
      let registered = Process.register("parity-app-pool", owner)
      let coordinator :: Pid<Int> = spawn(coordinate, count, milestone)
      let pids = clients(pool, repetitions, Env.get("ACTOR_PG_NS", ""), count, coordinator)
      let ticker :: Pid<Int> = spawn(heartbeat, coordinator)
      println("ready ${Monotonic.now_nanos()}")
      Timer.sleep(50)
      let started = Monotonic.now_nanos()
      Timer.send_after(ticker, 20, started + 20000000)
      println("start ${started}")
      for pid in pids do
        send(pid, 1)
      end
      while !File.exists(milestone) do
        Timer.sleep(10)
      end
      Pool.close(pool)
  end
end
