"""Untimed PostgreSQL transaction and public-handler checks on a small fixture."""

from contextlib import contextmanager
import json
import os
from pathlib import Path
import shutil
import sys
import time

from backend import Subject, arm
from wire import Relay

NS = "parity_0123456789abcdef"


def wait(label, probe):
    return arm.h.wait_for(probe, time.monotonic() + 12, label, .025)


@contextmanager
def cluster(out, executable, mode):
    out.mkdir(mode=0o700)
    scratch = out / "scratch"
    scratch.mkdir(mode=0o700)
    db = arm.Cluster(scratch, out, 20)
    db.trusted_application = True
    db.runners, db.slots, db.lanes = 1, 4, 1
    try:
        db.start()
        db.prepare_database("mesh")
        subject = Subject("mesh", [str(executable)], executable.parent, db, db.env)
        env = subject.environment(NS, db.slots, db.slots, mode, 50)
        env.update(JOBS_PARITY_MESH_BATCH="1", JOBS_PARITY_MESH_LISTEN="1",
                   JOBS_PARITY_MESH_EVENTS="logged", MESH_JOBS_SET_BASED_ENQUEUE="1",
                   MESH_EFFECT_LANES=str(db.lanes), MESH_SCHEDULER_MIN_WORKERS="2",
                   MESH_SCHEDULER_MAX_WORKERS="2", MESH_EFFECT_APP_URL=db.url("mesh", "compiled_caller"))
        subject.call("migrate", env, out / "migrate.log")
        yield db, subject, env
    finally:
        db.stop()
        shutil.rmtree(scratch)
        arm.redact(out, db.password)


def submit(out, subject, env, name, jobs):
    path = out / f"{name}.json"
    items = [dict(key=key, hold_ms=0, fail_first=False, payload="semantic") | extra
             for key, extra in jobs]
    path.write_text(json.dumps(dict(request_id=name, jobs=items, rollback=False)))
    receipt, _ = subject.enqueue_receipt(env, path, out / f"{name}.log")
    assert receipt["count"] == len(jobs)
    return receipt


def rows(db):
    return json.loads(db.sql("mesh", f"""
        SELECT coalesce(jsonb_object_agg(key, to_jsonb(r)), '{{}}') FROM (
            SELECT j.args->>'key' AS key, j.state, j.attempt, j.xmin::text AS xid,
                j.lease_token::text AS token, j.lease_expires_at_ms AS expiry,
                ARRAY(SELECT a.xmin::text FROM public.mesh_jobs_parity_attempts a
                    WHERE a.namespace=j.namespace AND a.job_key=j.args->>'key' ORDER BY a.attempt) AS attempts,
                (SELECT e.xmin::text FROM public.mesh_jobs_parity_effects e
                    WHERE e.namespace=j.namespace AND e.job_key=j.args->>'key') AS effect
            FROM mesh_jobs.jobs j WHERE j.namespace='{NS}'
        ) r
    """))


def sql_cut(out, executable):
    with cluster(out, executable, "dense") as (db, subject, env):
        job_names = ("one", "two", "expired", "cancelled", "stale")
        keys = [(key, {}) for key in job_names]
        # The scoped legacy single-claim and checked batch paths coexist.
        enqueue = submit(out, subject, env, "sql-cut", keys)
        ids = enqueue["ids"]
        workers = """[{"worker":"parity","version":1}]"""
        prefix = "SET ROLE parity_subject; "
        db.sql("mesh", prefix +
               f"SELECT * FROM mesh_jobs.claim('{NS}', 'default', '{workers}', 30000);")
        db.sql("mesh", prefix + f"SELECT * FROM mesh_jobs.claim_batch_bounded_v1("
               f"'{NS}', 'default', '{workers}', 30000, 16, NULL);")
        current = rows(db)
        assert list(row["state"] for row in current.values()).count("executing") == 4
        released = next(key for key, row in current.items() if row["state"] == "executing")
        db.sql("mesh", prefix + f"""SELECT mesh_jobs.settle_state(
            '{NS}', '{ids[released]}', '{current[released]['token']}', '{{"action":"snooze","delay_ms":0}}', false);
        """)
        db.sql("mesh", f"UPDATE mesh_jobs.queues SET concurrency=5 WHERE namespace='{NS}' AND name='default';")
        db.sql("mesh", prefix + f"SELECT * FROM mesh_jobs.claim_batch_bounded_v1("
               f"'{NS}', 'default', '{workers}', 30000, 16, NULL);")
        db.sql("mesh", f"""UPDATE mesh_jobs.jobs SET lease_expires_at_ms=0 WHERE id='{ids["expired"]}';
            UPDATE mesh_jobs.jobs SET cancel_requested_at_ms=mesh_jobs.now_ms() WHERE id='{ids["cancelled"]}';
        """)
        before = rows(db)
        assert all(row["state"] == "executing" for row in before.values())
        args_ids = ",".join(ids[key] for key in job_names)
        args_tokens = ",".join(before[key]["token"] if key != "stale" else "00000000-0000-0000-0000-000000000001"
                               for key in job_names)
        cohort = (f"SELECT ordinal FROM mesh_jobs.complete_batch_v1("
                  f"'{NS}', '{{{args_ids}}}'::uuid[], '{{{args_tokens}}}'::uuid[]) ORDER BY ordinal;")
        db.sql("mesh", "BEGIN; " + prefix + cohort + " ROLLBACK;")
        assert rows(db) == before
        assert db.sql("mesh", prefix + cohort).splitlines() == ["1", "2"]
        after = rows(db)
        assert after["one"]["xid"] == after["two"]["xid"]
        assert all(after[key]["state"] == "completed" and after[key]["token"] is None for key in ("one", "two"))
        assert all(after[key] == before[key] for key in ("expired", "cancelled", "stale"))
        assert not db.sql("mesh", prefix + cohort)
        db.sql("mesh", prefix + f"""SELECT mesh_jobs.settle_state('{NS}',
            '{ids["cancelled"]}', '{before["cancelled"]["token"]}', '{{"action":"complete"}}', false);
        """)
        assert rows(db)["cancelled"]["state"] == "cancelled"
        arm.h.write_json(out / "result.json", dict(rolled_back=True, before=before, after=after,
                         legacy_mix=True, wrong_token_untouched=True, expired_untouched=True))


def handler_cut(out, executable, fault=None):
    os.environ["PRODUCT_COMPOSITION"] = "product-d2"
    with cluster(out, executable, "final_attempt" if fault else "dense") as (db, subject, env), Relay(db) as relay:
        app_url = db.url("mesh", "compiled_caller", port=relay.port)
        gate = relay.arm(b"INSERT INTO public.mesh_jobs_parity_attempts", drop=True) if fault else None
        run_env = dict(env, MESH_EFFECT_APP_URL=app_url)
        process = subject.run(run_env, 0, out / "runner.log")
        try:
            wait("public runner ready", lambda: arm.h.runner_ready([process], [out / "runner.log"], track=False))
            receipt = submit(out, subject, env, "handler-cut", [("first", {})])
            if gate:
                assert gate.hit.wait(6)
                held = rows(db)["first"]
                assert held["state"] == "executing" and len(held["attempts"]) == 1 and held["effect"] is None
                gate.release.set()
                wait("failed ambiguous attempt", lambda: rows(db)["first"]["state"] == "discarded")
                assert rows(db)["first"]["attempts"] == held["attempts"]
                assert rows(db)["first"]["effect"] is None
                receipt = submit(out, subject, env, "after-loss", [("next", {})])
            key = "next" if gate else "first"
            wait("handler and settlement", lambda: rows(db)[key]["state"] == "completed")
            final = rows(db)[key]
            assert len(final["attempts"]) == 1
            assert len({receipt["xid"], final["attempts"][0], final["effect"], final["xid"]}) == 4
            arm.h.stop_runners([process], require_clean=True)
            inserts = [sql for _, sql in relay.requests if sql.startswith("INSERT INTO")]
            assert len(inserts) == (3 if gate else 2), inserts
            if gate:
                assert gate.witness == dict(command="INSERT 0 1", rows=0, idle=True, receipt_dropped=True)
                assert len({port for port, sql in relay.requests if sql.startswith("INSERT INTO")}) == 2
            arm.h.write_json(out / "result.json", dict(final=final, wire=gate.witness if gate else None,
                                                      app_insert_calls=len(inserts)))
        finally:
            if process.poll() is None:
                if gate:
                    gate.release.set()
                arm.h.stop_runners([process], require_clean=False)


def claim_loss(out, executable):
    with cluster(out, executable, "fault") as (db, subject, env), Relay(db) as relay:
        gate = relay.arm(b"COMMIT", drop=True)
        run_env = dict(env, JOBS_PARITY_POOL_URL=db.url("mesh", port=relay.port))
        log = out / "runner.log"
        process = subject.run(run_env, 0, log)
        try:
            wait("runner ready", lambda: arm.h.runner_ready([process], [log], track=False))
            submit(out, subject, env, "claim-loss", [("claim", {})])
            assert gate.hit.wait(6), "no claimed transaction COMMIT"
            held = rows(db)["claim"]
            assert held["state"] == "executing" and held["attempt"] == 1
            assert held["attempts"] == [] and held["effect"] is None
            gate.release.set()
            wait("lease recovery", lambda: rows(db)["claim"]["state"] == "completed")
            done = rows(db)["claim"]
            commit_ms = int(db.sql("mesh", f"""SELECT (extract(epoch FROM
                pg_xact_commit_timestamp(xmin)) * 1000)::bigint
                FROM public.mesh_jobs_parity_attempts WHERE namespace='{NS}' AND job_key='claim'"""))
            assert done["attempt"] == 2 and len(done["attempts"]) == 1
            assert commit_ms >= held["expiry"]
            arm.h.stop_runners([process], require_clean=True)
            arm.h.write_json(out / "result.json", dict(held=held, done=done, wire=gate.witness))
        finally:
            gate.release.set()
            if process.poll() is None:
                arm.h.stop_runners([process], require_clean=False)


def group_loss(out, executable):
    with cluster(out, executable, "dense") as (db, subject, env), Relay(db) as relay:
        sentinel = relay.arm(b"SELECT coalesce(mesh_jobs.settle_state($1,")
        group = relay.arm(b"SELECT ordinal::text FROM mesh_jobs.complete_batch_v1(", drop=True)
        run_env = dict(env, JOBS_PARITY_POOL_URL=db.url("mesh", port=relay.port))
        log = out / "runner.log"
        process = subject.run(run_env, 0, log)
        try:
            wait("runner ready", lambda: arm.h.runner_ready([process], [log], track=False))
            # The dispatcher visits the two sleeping attempts first and then
            # blocks receiving the last attempt's scalar settlement receipt.
            receipt = submit(out, subject, env, "group-loss",
                             [("a", {"hold_ms": 900}), ("b", {"hold_ms": 900}), ("sentinel", {})])
            assert sentinel.hit.wait(6), "scalar settlement did not reach the receipt cut"
            wait("both independent effects", lambda: all(rows(db)[key]["effect"] for key in ("a", "b")))
            time.sleep(.20)  # Let both actor exit callbacks finish while the dispatcher is held.
            assert all(rows(db)[key]["state"] == "executing" for key in ("a", "b"))
            sentinel.release.set()
            assert group.hit.wait(6), "no grouped terminal acknowledgement"
            held = rows(db)
            assert held["a"]["state"] == held["b"]["state"] == "completed"
            assert held["a"]["xid"] == held["b"]["xid"] != held["sentinel"]["xid"]
            assert len({receipt["xid"], held["a"]["xid"], held["sentinel"]["xid"],
                        *(held[key]["attempts"][0] for key in held),
                        *(held[key]["effect"] for key in held)}) == 9
            assert group.witness["rows"] == 2
            group.release.set()
            wait("both uncertain events", lambda: log.read_text().count('"event":"ack_uncertain"') == 2)
            arm.h.stop_runners([process], require_clean=True)
            assert rows(db) == held
            assert sum(sql.startswith("SELECT ordinal::text FROM mesh_jobs.complete_batch_v1(") for _, sql in relay.requests) == 1
            assert sum(sql.startswith("SELECT coalesce(mesh_jobs.settle_state($1,") for _, sql in relay.requests) == 1
            arm.h.write_json(out / "result.json", dict(committed=held, wire=group.witness,
                             grouped_submission_count=1, scalar_submission_count=1))
        finally:
            sentinel.release.set()
            group.release.set()
            if process.poll() is None:
                arm.h.stop_runners([process], require_clean=False)


def teardown(out, executable, witness, forced):
    os.environ["PRODUCT_COMPOSITION"] = "product-d2"
    with cluster(out, executable, "dense") as (db, subject, env):
        gate = out / "gate"
        gate.mkdir()
        runner = Subject("mesh", [str(witness)], witness.parent, db, db.env)
        log = out / "runner.log"
        child = runner.run(dict(env, COMBINED_TEARDOWN_DIR=str(gate)), 0, log)
        try:
            wait("runner ready", lambda: arm.h.runner_ready([child], [log], track=False))
            receipt = submit(out, subject, env, "teardown", [("owned", {})])
            wait("termination callback entered", (gate / "entered").exists)
            held = rows(db)["owned"]
            assert held["state"] == "executing" and len(held["attempts"]) == 1 and held["effect"]
            assert len({receipt["xid"], held["attempts"][0], held["effect"], held["xid"]}) == 4
            for _ in range(5):
                assert not (gate / "finished").exists()
                assert rows(db)["owned"] == held
            if forced:
                child.kill()
                assert child.wait(timeout=5) == -9
                assert rows(db)["owned"] == held
                done = held
            else:
                (gate / "release").touch()
                wait("termination callback released", (gate / "finished").exists)
                wait("post-exit settlement", lambda: rows(db)["owned"]["state"] == "completed")
                done = rows(db)["owned"]
                assert held["attempts"] == done["attempts"] and held["effect"] == done["effect"]
                assert done["xid"] not in (held["xid"], held["attempts"][0], held["effect"], receipt["xid"])
                arm.h.stop_runners([child], require_clean=True)
            arm.h.write_json(out / "result.json", dict(held=held, done=done, forced=forced,
                             runner_sha256=arm.h.digest(witness)))
        finally:
            if child.poll() is None:
                (gate / "release").touch()
                arm.h.stop_runners([child], require_clean=False)


def outcomes(out, executable):
    os.environ["PRODUCT_COMPOSITION"] = "product-d2"
    with cluster(out, executable, "fault") as (db, subject, env):
        log = out / "runner.log"
        child = subject.run(env, 0, log)
        try:
            wait("runner ready", lambda: arm.h.runner_ready([child], [log], track=False))
            receipt = submit(out, subject, env, "outcomes", [("cancel", {"hold_ms": 8000}),
                             ("retry", {"fail_first": True})])
            wait("first cancellation write", lambda: rows(db)["cancel"]["attempts"])
            assert rows(db)["cancel"]["state"] == "executing"
            db.sql("mesh", f"""SET ROLE parity_operator; SELECT mesh_jobs.job_control(
                '{NS}', '{receipt["ids"]["cancel"]}', 'cancel', NULL, NULL);""")
            wait("cancelled after actor exit", lambda: rows(db)["cancel"]["state"] == "cancelled")
            wait("requested retry succeeded", lambda: rows(db)["retry"]["state"] == "completed")
            result = rows(db)
            assert len(result["cancel"]["attempts"]) == 1 and result["cancel"]["effect"] is None
            assert result["retry"]["attempt"] == len(result["retry"]["attempts"]) == 2
            assert result["retry"]["effect"]
            assert len({receipt["xid"], result["cancel"]["xid"], result["retry"]["xid"],
                        *result["cancel"]["attempts"], *result["retry"]["attempts"],
                        result["retry"]["effect"]}) == 7
            arm.h.stop_runners([child], require_clean=True)
            arm.h.write_json(out / "result.json", result)
        finally:
            if child.poll() is None:
                arm.h.stop_runners([child], require_clean=False)


if __name__ == "__main__":
    out, executable = map(lambda name: Path(name).resolve(), sys.argv[1:3])
    out.mkdir()
    sql_cut(out / "sql-cut", executable)
    handler_cut(out / "public-handler", executable)
    handler_cut(out / "ambiguous-application-write", executable, fault=True)
    claim_loss(out / "ambiguous-claim-commit", executable)
    group_loss(out / "ambiguous-group-commit", executable)
    outcomes(out / "cancel-and-retry", executable)
    if len(sys.argv) == 4:
        witness = Path(sys.argv[3]).resolve(strict=True)
        teardown(out / "teardown-release", executable, witness, forced=False)
        teardown(out / "teardown-kill", executable, witness, forced=True)
