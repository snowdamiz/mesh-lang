"""Build-free local campaign against retained arm adapters and Mach-O artifacts."""
import argparse
from collections import Counter
import ctypes
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
TARGET = ROOT / "target"
WORK = TARGET / "dense-two-runner-checkout"
COMBINED = TARGET / "ordinary-completion-writer/combined"
V1 = TARGET / "ordinary-trusted-mesh-queue"
SOURCES = {"v1": V1 / "source", "v2": COMBINED / "bulk-base/ordinary-v2"}
SPLIT = HERE.parent / "2026-11-24-exit-confirmed-bulk-d2/replay"
ARTIFACTS = {
    "d2": TARGET / "short-exit-bulk-d2/artifacts",
    "r2": COMBINED / "runner-artifacts",
    "broker": COMBINED / "broker-artifacts",
    "v1": V1 / "local-artifacts-v1",
}
MANIFESTS = {
    "d2": "2ebb97ac2b9f6d5c4b513a62057728fd2e404107565ff61ef9bb491f47a74023",
    "r2": "2e1c6a1b56a2b8a67e0659c7f8960420311a47ea80225affb35bfb8be498d3cb",
    "broker": "ac239c8296a50d6439b1c5f86e626a138c70a36b4442a8c27d72fc979564d18a",
    "v1": "a14f09df14fc666e905c53916174997112eaa6720b6fadc9257321299b1678f8",
}
PG = Path("/opt/homebrew/opt/postgresql@17/bin")
FROZEN = "9afb598e8e80b56fc96689cfbe7a7061d82f8e5e3c33a2c534d680ce3db2528a"
EXPECTED = {"compiled_caller": 32, "parity_producer": 1, "parity_subject": 8}
RUNNER_ENV = ("MESH_PG_HOT_CHECKOUT", "TRUSTED_COMPLETION_WRITER_MS", "TRUSTED_ADMISSION_POLICY",
              "MESH_EFFECT_LANES", "JOBS_PARITY_SLOTS", "MESH_SCHEDULER_MIN_WORKERS",
              "MESH_SCHEDULER_MAX_WORKERS", "MESH_JOBS_SET_BASED_ENQUEUE",
              "JOBS_PARITY_MESH_LISTEN", "JOBS_PARITY_MESH_BATCH")
ROSTER = """
SELECT coalesce(json_agg(json_build_object('role', a.usename, 'backend', a.pid,
    'client_port', a.client_port, 'tls', coalesce(s.ssl, false)) ORDER BY a.pid), '[]')
FROM pg_stat_activity a LEFT JOIN pg_stat_ssl s USING (pid)
WHERE a.datname = current_database()
  AND a.usename IN ('parity_subject', 'parity_producer', 'compiled_caller')
"""
PRODUCER = """
SELECT coalesce(json_object_agg(p.query, p.calls), '{}') FROM pg_stat_statements p
WHERE p.dbid = (SELECT oid FROM pg_database WHERE datname=current_database())
  AND p.userid = 'parity_producer'::regrole
  AND (p.query LIKE 'SELECT ordinal, receipt FROM mesh_jobs.enqueue_batch_v1(%'
       OR p.query LIKE 'SELECT mesh_jobs.enqueue(%')
"""


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def write(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def seal():
    builds = {}
    for who, directory in ARTIFACTS.items():
        path = directory / "mesh.json"
        require(digest(path) == MANIFESTS[who], f"unexpected {who} manifest")
        builds[who] = json.loads(path.read_text())
        for file, expected in builds[who]["files"].items():
            require(digest(directory / file) == expected, f"{who}: changed {file}")
    for name in ("main.mpl", "writes.mpl", "worker_identity.mpl", "worker_identity.c", "mesh.toml"):
        require(builds["r2"]["files"][name] == builds["d2"]["files"][name], f"r2 fixture changed: {name}")


def child_path(process):
    proc_pidpath = ctypes.CDLL("/usr/lib/libproc.dylib", use_errno=True).proc_pidpath
    buf = ctypes.create_string_buffer(4096)
    require(process.poll() is None and proc_pidpath(process.pid, buf, len(buf)) > 0,
            f"no live executable for child {process.pid}")
    return Path(os.fsdecode(buf.value)).resolve(strict=True)


def socket_ports(pids, postgres_port):
    result = subprocess.check_output([
        "/usr/sbin/lsof", "-a", "-nP", "-p", ",".join(map(str, pids)),
        "-iTCP", "-sTCP:ESTABLISHED", "-Fpn",
    ], text=True, timeout=10)
    ports = {pid: [] for pid in pids}
    for line in result.splitlines():
        if line.startswith("p"):
            pid = int(line[1:])
        elif match := re.fullmatch(r"n127\.0\.0\.1:(\d+)->127\.0\.0\.1:(\d+)", line):
            if int(match[2]) == postgres_port:
                ports[pid].append(int(match[1]))
    return {pid: sorted(items) for pid, items in ports.items()}


def child(label, out):
    v1 = label == "v1"
    runner = label if label in {"v1", "r2"} else "d2"
    checkout = {"on": "d2", "r2": "off"}.get(label, "d2-disabled")
    source = SOURCES["v1" if v1 else "v2"]
    broker = "v1" if v1 else "broker"
    os.environ.update(COMBINED_BULK_SOURCE=str(source),
                      COMBINED_RUNNER_ARTIFACTS=str(ARTIFACTS[runner]),
                      EXIT_BULK_CHECKOUT=checkout, NATIVE_JOBS_ARTIFACTS=str(ARTIFACTS[broker]),
                      MESH_JOBS_SET_BASED_ENQUEUE="0" if v1 else "1",
                      TRUSTED_ADMISSION_POLICY="stock" if v1 else "success_cohort")
    if v1:
        sys.path.insert(0, str(source / "tools/durable-jobs-bench/native"))
        import arm
        base = launch = arm.Subject
        # V1's stock arm predates the V2 producer statement receipt.
        original_arm = arm.run_arm

        def collect_scalar(args, evidence, state, artifacts):
            original_settings = arm.database_settings

            def settings(cluster, engine):
                statements = json.loads(cluster.sql(engine, PRODUCER))
                write(out / "producer-writer.json", dict(enabled=False,
                      bulk=sum(v for k, v in statements.items() if k.startswith("SELECT ordinal, receipt")),
                      scalar=sum(v for k, v in statements.items() if k.startswith("SELECT mesh_jobs.enqueue(")),
                      statements=statements))
                return original_settings(cluster, engine)

            arm.database_settings = settings
            return original_arm(args, evidence, state, artifacts)

        arm.run_arm = collect_scalar
    else:
        sys.path.insert(0, str(SPLIT))
        from split_arm import arm, BaseSubject as base, SplitSubject as launch

    # Observe what the frozen launcher actually hands to the runner subprocess.
    class ObservedRunner(arm.h.RunnerProcess):
        def __init__(self, argv, **options):
            super().__init__(argv, **options)
            self.bench_env = {key: options["env"].get(key) for key in RUNNER_ENV}

    arm.h.RunnerProcess = ObservedRunner
    require(arm.PROFILES["noop"] == (8, 64, 4, 96, 2, FROZEN), "frozen dense profile changed")
    arm.PROFILES["noop"] = (2, 64, 16, 96, 2, FROZEN)

    class CheckedSubject(launch):
        def capture_runners(self, processes, logs):
            def warm():
                rows = json.loads(self.cluster.sql(self.engine, ROSTER))
                return rows if Counter(r["role"] for r in rows if r["tls"]) == EXPECTED else None

            rows = arm.h.wait_for(warm, time.monotonic() + 12, "41 verified TLS sessions", 0.05)
            pids = [p.pid for p in processes]
            ports = socket_ports(pids, self.cluster.port)
            runner_path = (ARTIFACTS[runner] / "mesh").resolve(strict=True)
            app = {row["client_port"] for row in rows if row["role"] == "compiled_caller"}
            queue = {row["client_port"] for row in rows if row["role"] == "parity_subject"}
            require(len(processes) == 2 and len(rows) == 41 and len({r["backend"] for r in rows}) == 41
                    and all(r["tls"] for r in rows), "physical TLS roster changed")
            launch_receipts = []
            for p in processes:
                actual = child_path(p)
                require(actual == runner_path and Path(p.fixture_executable) == actual, "runner executable changed")
                ve = p.bench_env
                require(ve["TRUSTED_COMPLETION_WRITER_MS"] is None
                        and ve["MESH_PG_HOT_CHECKOUT"] == ("1" if label == "on" else None)
                        and ve["MESH_EFFECT_LANES"] == "16" and ve["JOBS_PARITY_SLOTS"] == "32"
                        and ve["MESH_SCHEDULER_MIN_WORKERS"] == ve["MESH_SCHEDULER_MAX_WORKERS"] == "2",
                        "runner child environment differs")
                owned = set(ports[p.pid])
                require(len(owned & app) == 16 and len(owned & queue) == 4 and len(owned) == 20,
                        f"runner {p.pid} TLS ownership differs: {len(owned & app)} app, {len(owned & queue)} queue")
                launch_receipts.append(dict(pid=p.pid, observed_executable=str(actual), env=ve,
                                            client_ports=ports[p.pid]))
            require(set(ports[pids[0]]).isdisjoint(ports[pids[1]])
                    and set(ports[pids[0]] + ports[pids[1]]) == app | queue, "unmatched TLS sockets")
            base.capture_runners(self, processes, logs)
            standard = json.loads((out / "postgres-tls-sessions.json").read_text())
            require({(r["role"], r["backend"], r["tls"]) for r in standard} ==
                    {(r["role"], r["backend"], r["tls"]) for r in rows}, "TLS roster changed before capture")
            write(out / "pre-submit.json", dict(observed_us=time.time_ns() // 1000,
                  label=label, checkout_mode=("unset" if label != "on" else "1"),
                  writer_mode="off", broker=broker, runner=runner,
                  broker_manifest_sha256=digest(ARTIFACTS[broker] / "mesh.json"),
                  broker_sha256=digest(ARTIFACTS[broker] / "mesh"),
                  runner_manifest_sha256=digest(ARTIFACTS[runner] / "mesh.json"),
                  runner_sha256=digest(runner_path), launches=launch_receipts, tls=rows))

    arm.Subject = CheckedSubject
    sys.argv = [sys.argv[0], "--local-smoke", "mesh", "noop", str(out)]
    arm.main()


def campaign(name, smoke):
    require(sys.platform == "darwin", "the local seals are Darwin only")
    require(re.fullmatch(r"[a-z0-9-]+", name), "use a fresh plain series name")
    (WORK / "state/scratch").mkdir(parents=True, exist_ok=True)
    (WORK / "tmp").mkdir(exist_ok=True)
    out = WORK / name
    out.mkdir()
    plan = json.loads((HERE / "plan.json").read_text())
    orders = [plan["smoke"]] if smoke else plan["orders"]
    write(out / "freeze.json", dict(orders=orders, plan_sha256=digest(HERE / "plan.json"),
          source_sha256=digest(Path(__file__)), postgres_version=subprocess.check_output(
              [PG / "postgres", "--version"], text=True).strip(), manifests=MANIFESTS,
          logical_cpus=os.cpu_count(), prelock_load=os.getloadavg()))
    seal()
    for kind, path in ARTIFACTS.items():
        (out / f"{kind}-manifest.json").write_bytes((path / "mesh.json").read_bytes())
    require("17.11" in (out / "freeze.json").read_text(), "PostgreSQL version changed")
    env = {"PATH": "/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin", "LC_ALL": "C",
           "TMPDIR": str(WORK / "tmp"), "NATIVE_JOBS_STATE": str(WORK / "state"),
           "PG_BIN_DIR": str(PG), "DURABLE_JOBS_PHASE": "diagnostic"}
    waiting = time.monotonic()
    print("Waiting for the shared queue timing lock", flush=True)
    with (TARGET / "queue-performance.lock").open("rb") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        write(out / "lock.json", dict(wait_seconds=time.monotonic() - waiting,
                                     acquired_us=time.time_ns() // 1000, load=os.getloadavg()))
        for index, order in enumerate(orders, 1):
            for label in order:
                directory = out / f"{index:02}-{label}"
                load = os.getloadavg()
                start = time.time_ns() // 1000
                with directory.with_suffix(".log").open("x") as log:
                    result = subprocess.run([sys.executable, "-B", __file__, "arm", label, str(directory)],
                                            env=env, stdout=log, stderr=subprocess.STDOUT)
                write(directory.with_suffix(".status.json"), dict(exit=result.returncode, start_us=start,
                      finish_us=time.time_ns() // 1000, load_before=load, load_after=os.getloadavg()))
                print(directory.name, result.returncode, flush=True)
                result.check_returncode()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_subparsers(dest="mode", required=True)
    for mode in ("smoke", "campaign"):
        modes.add_parser(mode).add_argument("name")
    arm_cli = modes.add_parser("arm")
    arm_cli.add_argument("label", choices=("off-a", "off-b", "on", "r2", "v1"))
    arm_cli.add_argument("out", type=Path)
    args = parser.parse_args()
    if args.mode == "arm":
        child(args.label, args.out)
    else:
        campaign(args.name, args.mode == "smoke")
