CREATE FUNCTION mesh_jobs.batch_enqueue_probe(ns text, batch jsonb)
RETURNS TABLE(ordinal bigint, receipt text)
LANGUAGE plpgsql VOLATILE SET search_path=pg_catalog,pg_temp AS $$
BEGIN
    -- A stock enqueue can observe and change earlier jobs through its unique/replace policy.
    IF EXISTS (SELECT FROM jsonb_array_elements(batch) x
               WHERE x->'spec'->'unique' IS DISTINCT FROM 'null'::jsonb
                  OR x->'spec'->'replace' IS DISTINCT FROM '{}'::jsonb)
       OR EXISTS (SELECT FROM jsonb_array_elements(batch) x
                  WHERE x->>'request_key' <> '' GROUP BY x->>'request_key' HAVING count(*) > 1)
       OR EXISTS (SELECT FROM jsonb_array_elements(batch) x JOIN mesh_jobs.receipts r
                  ON r.namespace=ns AND r.request_key=x->>'request_key') THEN
        RETURN QUERY SELECT x.i, mesh_jobs.enqueue(ns,x.value->'spec',x.value->>'request_key',x.value->>'fingerprint')::text
                     FROM jsonb_array_elements(batch) WITH ORDINALITY AS x(value,i) ORDER BY x.i;
        RETURN;
    END IF;

    INSERT INTO mesh_jobs.queues(namespace,name)
    SELECT ns, x->'spec'->>'queue' FROM jsonb_array_elements(batch) x GROUP BY x->'spec'->>'queue'
    ORDER BY x->'spec'->>'queue' ON CONFLICT DO NOTHING;

    RETURN QUERY WITH inputs AS MATERIALIZED (
        SELECT x.i, x.value->'spec' AS s, x.value->>'request_key' AS rk, x.value->>'fingerprint' AS fp,
               mesh_jobs.now_ms() AS ts, pg_catalog.gen_random_uuid() AS new_id
        FROM jsonb_array_elements(batch) WITH ORDINALITY AS x(value,i) ORDER BY x.i
    ), specs AS (
        SELECT *, coalesce((s->>'scheduled_at_ms')::bigint, ts + coalesce((s->>'delay_ms')::bigint,0)) AS due
        FROM inputs
    ), inserted AS (
        INSERT INTO mesh_jobs.jobs AS j (namespace,id,worker,version,queue,args,metadata,tags,state,priority,
                max_attempts,timeout_ms,backoff_base_ms,backoff_max_ms,inserted_at_ms,scheduled_at_ms,unique_key)
        SELECT ns,new_id,s->>'worker',(s->>'version')::bigint,s->>'queue',s->'args',s->'metadata',s->'tags',
               CASE WHEN (s->>'suspended')::boolean THEN 'suspended' WHEN due>ts THEN 'scheduled' ELSE 'available' END,
               (s->>'priority')::int,(s->>'max_attempts')::int,(s->>'timeout_ms')::bigint,
               (s->>'backoff_base_ms')::bigint,(s->>'backoff_max_ms')::bigint,ts,due,NULL
        FROM specs ORDER BY i
        RETURNING j.id,jsonb_build_object('id',j.id,'effect_key',mesh_jobs.effect_key(j),
                    'state',j.state,'conflict',false,'inserted',true) AS result
    ), saved AS (
        INSERT INTO mesh_jobs.receipts(namespace,request_key,fingerprint,receipt)
        SELECT ns,i.rk,i.fp,j.result FROM inputs i JOIN inserted j ON j.id=i.new_id
        WHERE i.rk <> ''
    )
    SELECT i.i,j.result::text FROM inputs i JOIN inserted j ON j.id=i.new_id ORDER BY i.i;
END $$;
