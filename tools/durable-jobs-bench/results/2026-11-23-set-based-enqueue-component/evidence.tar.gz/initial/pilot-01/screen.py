import hashlib
import importlib.util
import json
import os
from pathlib import Path
import runpy
import fcntl
import sys
import time
import tempfile
import statistics

here=Path(__file__).resolve().parent
root=here.parent.parent
source=here.parent/'native-large-payload-storage'/'screen.py'
spec=importlib.util.spec_from_file_location("storage_case",source)
storage=importlib.util.module_from_spec(spec);spec.loader.exec_module(storage)
pg=storage.pg
ordered="""SELECT x.i::text,mesh_jobs.enqueue($1,x.value->'spec',x.value->>'request_key',x.value->>'fingerprint')::text
           FROM jsonb_array_elements($2::jsonb) WITH ORDINALITY AS x(value,i) ORDER BY x.i"""
bulk="SELECT ordinal::text,receipt FROM mesh_jobs.batch_enqueue_probe($1,$2::jsonb) ORDER BY ordinal"
orders=[
 ["stock_a","ordered","bulk","stock_b"],
 ["stock_b","bulk","ordered","stock_a"],
 ["ordered","stock_b","stock_a","bulk"],
 ["bulk","stock_a","stock_b","ordered"]
]
def pack(vals):
    return '['+','.join('{"spec":'+s+',"request_key":'+json.dumps(k)+',"fingerprint":'+json.dumps(f)+'}'
                        for _,s,k,f in vals)+']'
def execute(actor,arm,values):
    ids=[]
    for begin in range(0,len(values),128):
        group=values[begin:begin+128]
        actor.params("SAVEPOINT mesh_jobs_enqueue")
        actor.params(storage.sql_admit,storage.namespace)
        if arm in ("stock_a","stock_b"):
            replies=[pg.scalar(actor,storage.sql_enqueue,*vs) for vs in group]
        else:
            data=pack(group)
            reply=actor.params(ordered if arm=="ordered" else bulk,storage.namespace,data)[1]
            if tuple(int(r[0]) for r in reply)!=tuple(range(1,len(group)+1)):
                raise ValueError("incorrect ordinal")
            replies=[r[1] for r in reply]
        ids.extend(json.loads(r)['id'] for r in replies)
        actor.params("RELEASE SAVEPOINT mesh_jobs_enqueue")
    return ids

def block(actor,arm,values):
    def transaction():
        actor.params("BEGIN")
        xid=pg.scalar(actor,"SELECT pg_current_xact_id()::text")
        ids=execute(actor,arm,values)
        actor.params("COMMIT")
        return xid,ids
    before=time.process_time_ns()
    (xid,ids),measurement=storage.measure(actor,transaction)
    measurement['driver_cpu_ms']=(time.process_time_ns()-before)/1e6
    rows=actor.params("""SELECT id::text,r.request_key,j.xmin::text,r.xmin::text,r.fingerprint,
                       encode(sha256(convert_to(j.args->>'payload','UTF8')),'hex'),
                       r.receipt->>'id',r.receipt->>'effect_key',j.run::text
                       FROM mesh_jobs.jobs j JOIN mesh_jobs.receipts r
                         ON r.namespace=j.namespace AND r.receipt->>'id'=j.id::text
                       ORDER BY j.position""")[1]
    assert len(rows)==len(values)==len(ids)==len(set(ids))
    for r,id_,v in zip(rows,ids,values,strict=True):
        _,s,k,f=v
        expected=hashlib.sha256(json.loads(s)['args']['payload'].encode()).hexdigest()
        assert tuple(r)==(id_,k,str(int(xid)%(2**32)),str(int(xid)%(2**32)),f,expected,id_,id_+'/1','1'),r[:6]
    return {**measurement,'rows':len(rows),'xid':xid,'load':os.getloadavg()}
def main():
    out=here/sys.argv[1];out.mkdir()
    harness=runpy.run_path(str(root/'scripts/jobs-parity.py'))
    settings=json.loads((root/'scripts/jobs-parity-profiles.json').read_text())
    spec=lambda profile,n:[storage.actual_spec(j) for b in harness['inputs'](settings['workloads'][profile],n,settings['seed']) for j in b['jobs']]
    workloads={name:spec(name,n) for name,n in [('short',16),('noop',64)]}
    assert len(workloads['noop'])==1024 and len(workloads['short'])==128
    pg.json_write(out/'manifest.json',dict(orders=orders,mach=pg.calibrate_cpu(),policies=["stock_a","stock_b","ordered","bulk"],sql_sha256=hashlib.sha256((here/'bulk.sql').read_bytes()).hexdigest(),source_sha256=hashlib.sha256(storage.schema.read_bytes()).hexdigest()))
    with (here.parent/'queue-performance.lock').open("r") as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        with tempfile.TemporaryDirectory(dir=here.parent,prefix="bpg-") as d:
            cl=pg.Cluster(Path(d),out)
            try:
                cl.start()
                for i,order in enumerate(orders):
                    for name,vals in workloads.items():
                        for arm in order:
                            database=f"b_{i}_{name}_{arm}"
                            with cl.connect("postgres") as admin:
                                admin.params(f"CREATE DATABASE {database}")
                            try:
                                with cl.connect(database) as actor:
                                    actor.simple(storage.schema.read_text())
                                    actor.simple((here/'bulk.sql').read_text())
                                    r=block(actor,arm,vals)
                                pg.json_write(out/f'{i}-{name}-{arm}.json',r)
                            finally:
                                cl.drop(database)
            finally:
                cl.stop()
if __name__=='__main__':main()
