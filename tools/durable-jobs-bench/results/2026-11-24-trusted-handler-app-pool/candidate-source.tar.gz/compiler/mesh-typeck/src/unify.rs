//! Unification engine for Hindley-Milner type inference.
//!
//! Implements the core unification algorithm using `ena`'s union-find table.
//! Supports occurs check (infinite type detection), level-based generalization,
//! and scheme instantiation.

use ena::unify::InPlaceUnificationTable;
use rowan::TextRange;
use rustc_hash::{FxHashMap, FxHashSet};

use crate::env::TypeEnv;
use crate::error::{ConstraintOrigin, TypeError};
use crate::ty::{NatIndex, Scheme, Ty, TyCon, TyVar};
use crate::{ClusteredRouteReplicationCount, ClusteredRouteWrapperMetadata};

/// A method call that several impls could answer (`Meters.convert()` with
/// `Convert<Int>` and `Convert<String>`): its open result type, and the
/// return types of the impls.
#[derive(Clone, Debug)]
pub struct ImplChoice {
    pub result: Ty,
    pub method: String,
    pub receiver: Ty,
    pub candidates: Vec<Ty>,
    pub span: TextRange,
    /// Whether the impls differ in the argument they take
    /// (`Meters.from(x)` with `From<Int>` and `From<String>`), not in what
    /// they return: `result` is then the argument's type.
    pub by_argument: bool,
}

/// A field read from a value whose type was not known yet (`p.x` with an
/// unannotated `p`): resolved when the enclosing function is done.
#[derive(Clone, Debug)]
pub struct PendingField {
    pub base: Ty,
    pub field: String,
    pub result: Ty,
    pub span: TextRange,
}

/// A parameter of an impl method or an interface's default method, with the
/// type its inference gave it: one still unknown at the module's end is an
/// error. `name` is none for `self` and for a pattern.
#[derive(Clone, Debug)]
pub struct MethodParam {
    pub method: Option<String>,
    pub name: Option<mesh_parser::SyntaxToken>,
    pub span: TextRange,
    pub ty: Ty,
}

/// A value a function returns before its end: `return value`, or the
/// early exit of `?`.
#[derive(Clone, Debug)]
pub struct EarlyReturn {
    pub ty: Ty,
    pub span: TextRange,
    /// For `?`: the type of its operand.
    pub try_operand: Option<Ty>,
}

/// A deferred check a generalized binding's value leaves on the variables
/// its scheme generalizes: `let show = fn x -> "#{x}" end` needs Display of
/// `x`'s type. Each instance of the scheme requires it of its own variables
/// (see `InferCtx::instantiate`), as a function's inferred bounds are
/// required of each call's arguments.
#[derive(Clone, Debug)]
pub enum SchemeRequirement {
    /// An operand's trait (see `InferCtx::operand_traits`).
    Trait(Ty, String, ConstraintOrigin),
    /// An operand of `<>` or `++` (see `InferCtx::concat_operands`).
    Concat(Ty, &'static str, TextRange),
}

/// The first of `vars` that occurs in `ty`, a resolved type.
fn first_of(ty: &Ty, vars: &[TyVar]) -> Option<TyVar> {
    ty.variable()
        .filter(|var| vars.contains(var))
        .or_else(|| ty.parts().find_map(|part| first_of(part, vars)))
}

/// Where the checker is nested (see `InferCtx::nesting`).
#[derive(Clone, Copy)]
pub struct Nesting {
    level: u32,
    loop_depth: u32,
    returns: usize,
    scopes: usize,
    index_equations: usize,
}

/// A derived trait's need of one field: `type_name` derives `trait_name`
/// by comparing or showing its field `field`, of type `field_ty`, which must
/// have the trait too. `explicit` when the deriving list names the trait;
/// a type deriving everything by default quietly goes without it instead.
#[derive(Clone, Debug)]
pub struct DeriveNeed {
    pub type_name: String,
    pub trait_name: String,
    pub explicit: bool,
    pub field: String,
    pub field_ty: Ty,
    pub span: TextRange,
}

/// The inference context -- owns the unification table, level state, and errors.
///
/// All type inference happens through this context. It creates fresh type
/// variables, unifies types, tracks levels for generalization, and collects
/// errors.
#[derive(Default)]
pub struct InferCtx {
    /// The union-find unification table (ena).
    table: InPlaceUnificationTable<TyVar>,
    /// Current let-nesting level for generalization.
    current_level: u32,
    /// Level at which each type variable was created.
    /// Indexed by `TyVar.0`.
    var_levels: Vec<u32>,
    /// Declared function indices are rigid in the body. Instances of a
    /// function or constructor scheme always allocate fresh flexible ids.
    rigid_indices: FxHashMap<TyVar, String>,
    /// Rigid constructor indices introduced by matching under a local
    /// equation. Their level is the arm in which they were introduced.
    arm_indices: FxHashSet<TyVar>,
    /// Equalities learned from enclosing constructor patterns. They do not
    /// assign any of the rigid indices in the unification table.
    index_equations: Vec<(TyVar, NatIndex)>,
    /// Type errors accumulated during inference.
    pub errors: Vec<TypeError>,
    /// Warnings accumulated during inference (e.g. redundant match arms).
    pub warnings: Vec<TypeError>,
    /// The message type of each typed `Pid<M>` unified with an untyped
    /// `Pid`, with where: a pid for plaintext messages converts neither way
    /// (see `plaintext.rs`).
    pub untyped_pid_conversions: Vec<(Ty, ConstraintOrigin)>,
    /// Current loop nesting depth (0 = not inside any loop).
    /// Incremented when entering a while body, reset to 0 when entering a closure body.
    pub loop_depth: u32,
    /// The interface whose default method body is being checked, if any:
    /// `self` then has the type `Self`, whose methods are the interface's own.
    pub current_interface: Option<String>,
    /// User-defined module namespaces for qualified access (e.g., Vector.add()).
    /// Populated during ImportDecl processing, read during field access resolution.
    /// Key is the module namespace name, value maps function/type name to its scheme.
    pub qualified_modules: FxHashMap<String, FxHashMap<String, Scheme>>,
    /// Function names imported via `from Module import name1, name2`.
    /// Tracked so the MIR lowerer can skip trait dispatch for these.
    pub imported_functions: Vec<String>,
    /// Defining module for imported bare function references.
    /// Keyed by the imported in-scope name (e.g. `handle_submit` -> `Work`).
    pub imported_function_origins: FxHashMap<String, String>,
    /// Full module name for qualified module namespaces (e.g. `Todos` -> `Api.Todos`).
    pub qualified_module_origins: FxHashMap<String, String>,
    /// The full names of the project's modules (see `ImportContext`).
    pub project_modules: Vec<String>,
    /// The variants of the sum types an imported module exports, by module
    /// namespace and variant name: the type each belongs to (`Geo.Dot`).
    pub module_variants: FxHashMap<String, FxHashMap<String, String>>,
    /// Private names exported by a qualified module namespace.
    /// Used to turn `HTTP.clustered(Module.hidden)` into a focused privacy diagnostic.
    pub qualified_module_private_names: FxHashMap<String, FxHashSet<String>>,
    /// Top-level function visibility in the current module.
    /// Keyed by the unqualified function name; value is true when the fn is public.
    pub top_level_function_visibility: FxHashMap<String, bool>,
    /// Metadata for each `HTTP.clustered(...)` wrapper call.
    pub clustered_route_wrappers: FxHashMap<TextRange, ClusteredRouteWrapperMetadata>,
    /// Wrapper call ranges that were consumed in the route-handler slot.
    pub consumed_clustered_route_wrappers: FxHashSet<TextRange>,
    /// References to Jobs.start and Jobs.drain, marked when checked as direct calls.
    pub jobs_runner_references: FxHashMap<TextRange, bool>,
    /// Handlers defined in this module, checked once their types are final.
    pub jobs_local_handlers: Vec<(String, TextRange, Ty)>,
    /// Function arguments passed where a callback returning `()` is expected
    /// whose own result is discarded; lowering wraps each one in an adapter.
    pub discarded_callback_results: FxHashSet<TextRange>,
    /// `Json` arguments passed where a `String` is expected; lowering passes
    /// each one's encoded text.
    pub json_text_arguments: FxHashSet<TextRange>,
    /// Every type the builtins name (`builtin_type_names`): no value.
    pub builtin_types: FxHashSet<String>,
    /// What each derived Eq, Ord, Display or Debug needs of a field's type (see
    /// `DeriveNeed`), checked once every type and impl is registered.
    pub derive_needs: Vec<DeriveNeed>,
    /// The types generic `from_json` calls decode, with where each is
    /// called, checked when the enclosing function is done: a type it
    /// leaves open that no caller can fix is not known.
    pub open_decodes: Vec<(Ty, TextRange)>,
    /// Replication counts already declared for a clustered route runtime name.
    pub clustered_route_replication_counts: FxHashMap<String, ClusteredRouteReplicationCount>,
    /// Service method mappings imported from other modules.
    /// Maps service_name -> Vec<(method_name, generated_fn_name)>.
    /// Populated during import resolution, propagated to TypeckResult for MIR lowering.
    pub imported_service_methods: FxHashMap<String, Vec<(String, String)>>,
    /// Locally-defined service export info for collect_exports.
    /// Populated by infer_service_def with resolved helper function types.
    pub local_service_exports: FxHashMap<String, crate::ServiceExportInfo>,
    /// The name of the current module being type-checked (e.g., "Geometry").
    /// None for single-file mode. Used to name clustered route handlers.
    pub current_module: Option<String>,
    /// Whether compiler-provided test-only builtins are available.
    pub test_builtins: bool,
    /// Stack of enclosing function/closure return types.
    /// Pushed when entering a function/closure body, popped when leaving.
    /// `None` means the return type is not yet known (will be inferred).
    pub fn_return_type_stack: Vec<Option<Ty>>,
    fn_return_levels: Vec<u32>,
    /// Per entry of `fn_return_type_stack`: the early returns (`return`,
    /// `?`) in a function whose return type is not declared.
    pub fn_returned_types: Vec<Vec<EarlyReturn>>,
    /// The `where` bounds of the function whose body is being checked: each
    /// type parameter's variable with a trait it must implement.
    pub where_bounds: Vec<(Ty, String)>,
    /// The declared type parameters of the function whose body is being
    /// checked: the variable standing for each, and its name.
    pub rigid_params: Vec<(Ty, String)>,
    /// Associated types used through a type parameter (`c.first()` with
    /// `first(self) -> Self.Item` under `where T: Container`): the variable
    /// standing for it, the trait, the associated type's name and the
    /// receiver. Lowering binds the variable in each specialization.
    pub assoc_projections: Vec<(Ty, String, String, Ty)>,
    /// What generalized bindings' values require of the variables their
    /// schemes generalize, by one such variable (see `SchemeRequirement`).
    pub scheme_requirements: FxHashMap<TyVar, Vec<SchemeRequirement>>,
    /// A generic function's body can fix an associated type (`c.first() + 1`
    /// makes `T.Item` an Int). Each instance of the function then requires it
    /// of its receiver: (required type, trait, associated type name, the
    /// instance's receiver, where the function was used).
    pub projection_requirements: Vec<(Ty, String, String, Ty, Option<TextRange>)>,
    /// Names `from Module import name` brought in from a standard module,
    /// each with its module (`sqrt` -> `Math`): the function the name
    /// means, which lowering and `monitor`'s typing go by.
    pub stdlib_imports: FxHashMap<String, String>,
    /// The module's types that derive Json, known before any is checked, so
    /// `deriving(Json)` accepts fields of types declared later or recursively.
    pub json_types: rustc_hash::FxHashSet<String>,
    /// The variants of this module's sum types, by name, with the type that
    /// declares each: one name may belong to only one of them.
    pub local_variants: FxHashMap<String, String>,
    /// Names reported as unknown types: a value said to be one is not
    /// reported again, field by field.
    pub unknown_types: FxHashSet<String>,
    /// Operators applied to values of a type not yet known, with the trait
    /// each needs: a generic function's own type parameter must be bounded
    /// by it (`where T: Ord`), checked when the function's body is done.
    pub operand_traits: Vec<(Ty, String, ConstraintOrigin)>,
    /// Field reads from values of a type not known yet, resolved when the
    /// enclosing function (or the module, outside functions) is done.
    pub pending_fields: Vec<PendingField>,
    /// The field access whose base was typed last, and the base's type: a
    /// call of a name that type has no field of is retried as a method of
    /// it, without inferring the base again.
    pub field_base: Option<(TextRange, Ty)>,
    /// The parameters of the module's impl methods and interface default
    /// methods, checked for a type when the module is done.
    pub method_params: Vec<MethodParam>,
    /// Operands of `<>` or `++` whose type was not known yet, with the
    /// operator and where it is: checked when the function is done.
    pub concat_operands: Vec<(Ty, &'static str, TextRange)>,
    /// The builtin `default()` calls of the function being inferred, with
    /// the type each builds (checked when the function is done).
    pub default_calls: Vec<(Ty, TextRange)>,
    /// Each actor whose `receive` binds its message, with the message type
    /// and the actor's name: sends anywhere in the module may fix the type,
    /// so it is checked when the module is done.
    pub actor_message_types: Vec<(String, Ty, TextRange)>,
    /// Method calls that several impls could answer, to be decided by the
    /// type their context gives the result (checked when the function is done).
    pub impl_choices: Vec<ImplChoice>,
    /// Names bound in the environment to an impl's method (so `hello(x)`
    /// resolves), which a bare call dispatches by its first argument.
    pub trait_method_fns: FxHashSet<String>,
    /// Top-level fn names defined at more than one arity. Each arity is its
    /// own function, known in the env (and exported) as `name__N`.
    pub overloaded_fn_names: FxHashSet<String>,
    /// Maps call-site TextRange -> mangled callee name (e.g. "slugify__2").
    /// Populated during inference for arity-overloaded calls.
    /// Consumed by the MIR lowerer to emit the correct function reference.
    pub overloaded_call_targets: FxHashMap<TextRange, String>,
    /// The expressions being inferred, innermost last: where a constraint
    /// with no more specific origin is reported.
    pub expr_spans: Vec<TextRange>,
}

impl InferCtx {
    /// Create a new, empty inference context.
    pub fn new() -> Self {
        Self::default()
    }

    /// Enter a loop body -- increments loop_depth.
    pub fn enter_loop(&mut self) {
        self.loop_depth += 1;
    }

    /// Exit a loop body -- decrements loop_depth.
    pub fn exit_loop(&mut self) {
        self.loop_depth = self.loop_depth.saturating_sub(1);
    }

    /// Enter a closure body -- saves and resets loop_depth to 0.
    /// Returns the saved loop_depth to restore later.
    pub fn enter_closure(&mut self) -> u32 {
        let saved = self.loop_depth;
        self.loop_depth = 0;
        saved
    }

    /// Exit a closure body -- restores loop_depth from saved value.
    pub fn exit_closure(&mut self, saved_depth: u32) {
        self.loop_depth = saved_depth;
    }

    /// Whether we are currently inside a loop.
    pub fn in_loop(&self) -> bool {
        self.loop_depth > 0
    }

    /// Push a function return type onto the stack (call when entering a function body).
    pub fn push_fn_return_type(&mut self, ty: Option<Ty>) {
        self.fn_return_type_stack.push(ty);
        self.fn_return_levels.push(self.current_level);
        self.fn_returned_types.push(Vec::new());
    }

    /// Pop a function return type from the stack (call when leaving a function
    /// body). Returns the early returns seen while the return type was not
    /// declared, for the caller to join with the body's type.
    pub fn pop_fn_return_type(&mut self) -> Vec<EarlyReturn> {
        self.fn_return_type_stack.pop();
        self.fn_return_levels.pop();
        self.fn_returned_types.pop().unwrap_or_default()
    }

    /// Record an early return in a function without a declared return type.
    pub fn record_return(&mut self, mut early: EarlyReturn) {
        if !self.index_equations.is_empty() {
            if let Some(&level) = self.fn_return_levels.last() {
                early.ty = self.resolve(early.ty);
                if self
                    .check_index_escape(&early.ty, level, early.span)
                    .is_err()
                {
                    return;
                }
                self.lower_levels(&early.ty, level);
            }
        }
        if let Some(returns) = self.fn_returned_types.last_mut() {
            returns.push(early);
        }
    }

    /// Get the current enclosing function's return type (top of stack).
    pub fn current_fn_return_type(&self) -> Option<&Ty> {
        self.fn_return_type_stack.last().and_then(|t| t.as_ref())
    }

    // ── Type Variable Creation ──────────────────────────────────────────

    /// Create a fresh type variable at the current level.
    pub fn fresh_var(&mut self) -> Ty {
        Ty::Var(self.fresh_key())
    }

    pub(crate) fn fresh_index(&mut self, rigid_name: Option<&str>) -> Ty {
        let var = self.fresh_key();
        if let Some(name) = rigid_name {
            self.rigid_indices.insert(var, name.to_owned());
        }
        Ty::Nat(NatIndex::Variable(var))
    }

    pub(crate) fn fresh_arm_index(&mut self, name: &str) -> NatIndex {
        let var = self.fresh_key();
        self.rigid_indices.insert(var, name.to_owned());
        self.arm_indices.insert(var);
        NatIndex::Variable(var)
    }

    pub(crate) fn is_rigid_index(&self, var: TyVar) -> bool {
        self.rigid_indices.contains_key(&var)
    }

    pub(crate) fn add_index_equation(&mut self, var: TyVar, value: NatIndex) {
        debug_assert!(self.is_rigid_index(var));
        self.index_equations.push((var, value));
    }

    /// Check the normalized type from an indexed arm before it is joined
    /// with sibling results. Later unification must treat any remaining
    /// flexible variables as belonging to the enclosing scope.
    pub(crate) fn close_arm_type(&mut self, ty: &Ty, span: TextRange) -> Result<(), TypeError> {
        self.check_index_escape(ty, self.current_level, span)?;
        self.lower_levels(ty, self.current_level);
        Ok(())
    }

    fn check_index_escape(
        &mut self,
        ty: &Ty,
        level: u32,
        span: TextRange,
    ) -> Result<(), TypeError> {
        if self.arm_indices.is_empty() || !self.has_inner_arm_index(ty, level) {
            return Ok(());
        }
        let err = TypeError::InvalidIndex {
            reason: "a constructor-local Nat index cannot escape its case arm".into(),
            span,
        };
        self.errors.push(err.clone());
        Err(err)
    }

    fn has_inner_arm_index(&self, ty: &Ty, level: u32) -> bool {
        match ty {
            Ty::Nat(index) => matches!(
                index.leaf(),
                NatIndex::Variable(var)
                    if self.arm_indices.contains(var) && self.level_of(*var) > level
            ),
            _ => ty.parts().any(|part| self.has_inner_arm_index(part, level)),
        }
    }

    fn fresh_key(&mut self) -> TyVar {
        // The table numbers its keys in order, as `var_levels` holds them.
        let var = self.table.new_key(None);
        self.var_levels.push(self.current_level);
        var
    }

    /// The `let` level `v` was created at, or lowered to.
    fn level_of(&self, v: TyVar) -> u32 {
        self.var_levels[v.0 as usize]
    }

    fn set_level(&mut self, v: TyVar, level: u32) {
        self.var_levels[v.0 as usize] = level;
    }

    /// Lower every unbound variable in `ty` to at most `level`: bound into a
    /// variable of that level, they are reachable from outside a deeper
    /// `let`, which must not generalize them (a call of a function defined
    /// later in the file fixes them only then).
    fn lower_levels(&mut self, ty: &Ty, level: u32) {
        let ty = self.resolve(ty.clone());
        if let Some(var) = ty.variable() {
            if self.level_of(var) > level && !self.rigid_indices.contains_key(&var) {
                self.set_level(var, level);
            }
        }
        ty.parts().for_each(|part| self.lower_levels(part, level));
    }

    /// A fresh variable at the level of `anchor`'s variable (the current level
    /// when it has none): a `let` inside `anchor`'s scope does not generalize
    /// it away from `anchor`.
    pub fn fresh_var_beside(&mut self, anchor: &Ty) -> Ty {
        let fresh = self.fresh_var();
        if let (Ty::Var(anchor), Ty::Var(var)) = (self.resolve(anchor.clone()), &fresh) {
            self.set_level(*var, self.level_of(anchor));
        }
        fresh
    }

    // ── Resolution ──────────────────────────────────────────────────────

    /// Resolve a type by following union-find indirection.
    ///
    /// If the type is a variable with a known value, recursively resolve
    /// that value. Otherwise return the type as-is.
    pub fn resolve(&mut self, ty: Ty) -> Ty {
        match ty {
            Ty::Nat(index) => Ty::Nat(self.resolve_index(&index)),
            Ty::Var(v) => {
                let probe = self.table.probe_value(v);
                match probe {
                    Some(inner) => self.resolve(inner),
                    None => {
                        // Normalize to the root key so that variables
                        // in the same equivalence class resolve to the
                        // same representative. This is critical for
                        // generalization: two unified-but-unbound vars
                        // must appear as the same variable.
                        let root = self.table.find(v);
                        Ty::Var(root)
                    }
                }
            }
            // For compound types, resolve recursively.
            Ty::Fun(params, ret) => {
                let params = params.into_iter().map(|p| self.resolve(p)).collect();
                let ret = Box::new(self.resolve(*ret));
                Ty::Fun(params, ret)
            }
            Ty::App(con, args) => {
                let con = Box::new(self.resolve(*con));
                let args = args.into_iter().map(|a| self.resolve(a)).collect();
                // A tuple row whose tail has become known is that tuple.
                Ty::App(con, args).normalize_tuple_row()
            }
            Ty::Tuple(elems) => {
                let elems = elems.into_iter().map(|e| self.resolve(e)).collect();
                Ty::Tuple(elems)
            }
            other => other,
        }
    }

    fn resolve_index(&mut self, index: &NatIndex) -> NatIndex {
        index.map_leaf(|leaf| match leaf {
            NatIndex::Variable(var) => {
                if let Some(value) = self
                    .index_equations
                    .iter()
                    .rev()
                    .find_map(|(key, value)| (key == var).then(|| value.clone()))
                {
                    return self.resolve_index(&value);
                }
                match self.table.probe_value(*var) {
                    Some(Ty::Nat(value)) => self.resolve_index(&value),
                    None => NatIndex::Variable(self.table.find(*var)),
                    Some(_) => unreachable!("Nat variable bound to a type"),
                }
            }
            _ => leaf.clone(),
        })
    }

    /// Check if two TyCon names are compatible because they both represent
    /// opaque iterator handle pointers. All iterator handle types
    /// (ListIterator, MapIterator, etc.) and adapter types resolve to
    /// MirType::Ptr at the MIR/codegen level, so they must be unifiable
    /// with each other and with the generic `Ptr` type in the type checker.
    fn iterator_ptr_compatible(c1: &TyCon, c2: &TyCon) -> bool {
        if c1.indexed_origin.is_some() || c2.indexed_origin.is_some() {
            return false;
        }
        fn is_iter_ptr(name: &str) -> bool {
            name == "Ptr"
                || name == "ListIterator"
                || name == "MapIterator"
                || name == "SetIterator"
                || name == "RangeIterator"
                || name == "MapAdapterIterator"
                || name == "FilterAdapterIterator"
                || name == "TakeAdapterIterator"
                || name == "SkipAdapterIterator"
                || name == "EnumerateAdapterIterator"
                || name == "ZipAdapterIterator"
        }
        is_iter_ptr(&c1.name) && is_iter_ptr(&c2.name)
    }

    /// Unify a tuple row (`Ty::tuple_row`) with a tuple, another row, or the
    /// untyped `Tuple`. `None` when neither side is a row, or the other side is
    /// a variable, which `unify` binds to the row like to any other type.
    fn unify_tuple_row(
        &mut self,
        a: &Ty,
        b: &Ty,
        origin: &ConstraintOrigin,
    ) -> Option<Result<(), TypeError>> {
        // (the row's leading elements, its tail, what they must equal, what the tail must equal)
        let (elems, tail, known, rest) = match (a.as_tuple_row(), b.as_tuple_row()) {
            (None, None) => return None,
            // Two rows agree on the elements both name; the shorter one's tail
            // is the longer one's remainder.
            (Some(row_a), Some(row_b)) => {
                let (short, long) = if row_a.0.len() <= row_b.0.len() {
                    (row_a, row_b)
                } else {
                    (row_b, row_a)
                };
                let (named, remainder) = long.0.split_at(short.0.len());
                let rest = if remainder.is_empty() {
                    long.1.clone()
                } else {
                    Ty::tuple_row(remainder.to_vec(), long.1.clone())
                };
                (short.0.to_vec(), short.1.clone(), named.to_vec(), rest)
            }
            (Some(row), None) | (None, Some(row)) => {
                let other = if a.as_tuple_row().is_some() { b } else { a };
                let (known, rest) = match other {
                    Ty::Var(_) => return None,
                    // The row's elements are the tuple's first ones, its tail the rest.
                    Ty::Tuple(all) if all.len() >= row.0.len() => {
                        let (named, remainder) = all.split_at(row.0.len());
                        (named.to_vec(), Ty::Tuple(remainder.to_vec()))
                    }
                    // The untyped `Tuple` promises `Int` elements, as its accessors do.
                    Ty::Con(c) if c.name == "Tuple" => {
                        (vec![Ty::int(); row.0.len()], row.1.clone())
                    }
                    _ => {
                        let err = TypeError::Mismatch {
                            expected: a.clone(),
                            found: b.clone(),
                            origin: origin.clone(),
                        };
                        self.errors.push(err.clone());
                        return Some(Err(err));
                    }
                };
                (row.0.to_vec(), row.1.clone(), known, rest)
            }
        };
        for (elem, known) in elems.into_iter().zip(known) {
            if let Err(err) = self.unify(elem, known, origin.clone()) {
                return Some(Err(err));
            }
        }
        Some(self.unify(tail, rest, origin.clone()))
    }

    /// Bind `v` to `ty`, both resolved, unless `v` occurs in it (`a ~ (a) ->
    /// Int` is an infinite type). `var_expected` says whether `v` was the
    /// expected side of the unification.
    fn bind_var(
        &mut self,
        v: TyVar,
        ty: Ty,
        origin: ConstraintOrigin,
        var_expected: bool,
    ) -> Result<(), TypeError> {
        if first_of(&ty, &[v]).is_none() {
            let level = self.level_of(v);
            self.check_index_escape(&ty, level, origin.span().unwrap_or_default())?;
            self.lower_levels(&ty, level);
            self.table
                .unify_var_value(v, Some(ty))
                .expect("binding a var to a concrete type after occurs check should not fail");
            return Ok(());
        }
        // A declared type parameter is a type of its own: `T` where
        // `Option<T>` is expected is a plain mismatch, not an infinite type.
        let err = if self.rigid_param_name(v).is_some() {
            let (var, ty) = (self.with_param_names(Ty::Var(v)), self.with_param_names(ty));
            let (expected, found) = if var_expected { (var, ty) } else { (ty, var) };
            TypeError::Mismatch {
                expected,
                found,
                origin,
            }
        } else {
            TypeError::InfiniteType { var: v, ty, origin }
        };
        self.errors.push(err.clone());
        Err(err)
    }

    /// The declared type parameter in scope that `v` stands for.
    pub(crate) fn rigid_param_name(&mut self, v: TyVar) -> Option<String> {
        let params = self.rigid_params.clone();
        params
            .into_iter()
            .find(|(param, _)| self.resolve(param.clone()) == Ty::Var(v))
            .map(|(_, name)| name)
    }

    /// `ty` with the variables of the declared type parameters in scope
    /// shown by their names.
    fn with_param_names(&mut self, ty: Ty) -> Ty {
        match self.resolve(ty) {
            Ty::Nat(index) => Ty::Nat(index.map_leaf(|leaf| {
                match leaf {
                    NatIndex::Variable(var) => self
                        .rigid_indices
                        .get(var)
                        .map(|name| NatIndex::Parameter(name.clone()))
                        .unwrap_or_else(|| leaf.clone()),
                    _ => leaf.clone(),
                }
            })),
            Ty::Var(v) => self
                .rigid_param_name(v)
                .map(|name| Ty::Con(TyCon::new(name)))
                .unwrap_or(Ty::Var(v)),
            other => other.map_parts(|part| self.with_param_names(part.clone())),
        }
    }

    fn unify_indices(
        &mut self,
        expected: NatIndex,
        found: NatIndex,
        origin: ConstraintOrigin,
    ) -> Result<(), TypeError> {
        let mut left = expected.clone();
        let mut right = found.clone();
        loop {
            if left == right {
                return Ok(());
            }
            match (&left, &right) {
                (NatIndex::Literal(_), NatIndex::Literal(_)) => break,
                (NatIndex::Variable(var), _) if !self.rigid_indices.contains_key(var) => {
                    if right.leaf() != &left {
                        return self.bind_var(*var, Ty::Nat(right), origin, true);
                    }
                    break;
                }
                (_, NatIndex::Variable(var)) if !self.rigid_indices.contains_key(var) => {
                    if left.leaf() != &right {
                        return self.bind_var(*var, Ty::Nat(left), origin, false);
                    }
                    break;
                }
                _ => match (left.predecessor(), right.predecessor()) {
                    (Some(a), Some(b)) => (left, right) = (a, b),
                    _ => break,
                },
            }
        }
        let err = TypeError::Mismatch {
            expected: self.with_param_names(Ty::Nat(expected)),
            found: self.with_param_names(Ty::Nat(found)),
            origin,
        };
        self.errors.push(err.clone());
        Err(err)
    }

    // ── Unification ─────────────────────────────────────────────────────

    /// Unify two types, making them equal.
    ///
    /// This is the core of HM inference. Both types are first resolved
    /// through the union-find table, then structurally compared. If they
    /// differ, a type error is recorded.
    pub fn unify(&mut self, a: Ty, b: Ty, origin: ConstraintOrigin) -> Result<(), TypeError> {
        let origin = match (origin, self.expr_spans.last()) {
            (ConstraintOrigin::Builtin, Some(&span)) => ConstraintOrigin::Expr { span },
            (origin, _) => origin,
        };
        let a = self.resolve(a);
        let b = self.resolve(b);

        if let Some(result) = self.unify_tuple_row(&a, &b, &origin) {
            return result;
        }

        match (a, b) {
            (Ty::Nat(a), Ty::Nat(b)) => self.unify_indices(a, b, origin),
            // Even a flexible variable of kind Type can never stand for Nat.
            (a @ Ty::Nat(_), b) | (a, b @ Ty::Nat(_)) => {
                let err = TypeError::Mismatch {
                    expected: a,
                    found: b,
                    origin,
                };
                self.errors.push(err.clone());
                Err(err)
            }
            // Two identical variables -- already unified.
            (Ty::Var(v1), Ty::Var(v2)) if v1 == v2 => Ok(()),

            // Variable meets variable -- union them, at the outer level of the two.
            (Ty::Var(v1), Ty::Var(v2)) => {
                let level = self.level_of(v1).min(self.level_of(v2));
                self.table
                    .unify_var_var(v1, v2)
                    .expect("unifying two unbound vars should not fail");
                let root = self.table.find(v1);
                self.set_level(root, level);
                Ok(())
            }

            // Variable meets concrete type -- bind the variable (with occurs check).
            (Ty::Var(v), ty) => self.bind_var(v, ty, origin, true),
            (ty, Ty::Var(v)) => self.bind_var(v, ty, origin, false),

            // Concrete constructor meets concrete constructor -- names must match.
            (Ty::Con(c1), Ty::Con(c2)) => {
                if c1 == c2 || Self::iterator_ptr_compatible(&c1, &c2) {
                    Ok(())
                } else {
                    let err = TypeError::Mismatch {
                        expected: Ty::Con(c1),
                        found: Ty::Con(c2),
                        origin,
                    };
                    self.errors.push(err.clone());
                    Err(err)
                }
            }

            // Function types -- unify params pairwise, then return types.
            (Ty::Fun(p1, r1), Ty::Fun(p2, r2)) => {
                if p1.len() != p2.len() {
                    // One side takes a tuple, the other its elements.
                    let tuple_len = |params: &[Ty], ctx: &mut Self| match params {
                        [only] => match ctx.resolve(only.clone()) {
                            Ty::Tuple(elements) => Some(elements.len()),
                            _ => None,
                        },
                        _ => None,
                    };
                    let split = tuple_len(&p1, self)
                        .filter(|n| *n == p2.len())
                        .or_else(|| tuple_len(&p2, self).filter(|n| *n == p1.len()));
                    let err = match split {
                        Some(elements) => TypeError::TupleParameterSplit { elements, origin },
                        None => TypeError::ArityMismatch {
                            expected: p1.len(),
                            found: p2.len(),
                            origin,
                        },
                    };
                    self.errors.push(err.clone());
                    Err(err)
                } else {
                    for (a, b) in p1.into_iter().zip(p2.into_iter()) {
                        self.unify(a, b, origin.clone())?;
                    }
                    self.unify(*r1, *r2, origin)
                }
            }

            // Pid escape hatch: untyped Pid (Con) unifies with typed Pid<M> (App).
            // This allows: let untyped :: Pid = typed_pid  (typed -> untyped).
            (Ty::Con(ref c), Ty::App(ref con, ref args))
            | (Ty::App(ref con, ref args), Ty::Con(ref c))
                if c.name == "Pid" && matches!(con.as_ref(), Ty::Con(tc) if tc.name == "Pid") =>
            {
                if let [message] = args.as_slice() {
                    self.untyped_pid_conversions
                        .push((message.clone(), origin.clone()));
                }
                Ok(())
            }

            // Iterator handles (`ListIterator`, the untyped `Ptr`, ...) carry no
            // element type; they are compatible with any `Iter<T>`.
            (Ty::Con(ref c), Ty::App(ref con, _)) | (Ty::App(ref con, _), Ty::Con(ref c))
                if matches!(con.as_ref(), Ty::Con(tc) if tc.name == "Iter")
                    && Self::iterator_ptr_compatible(c, &TyCon::new("Ptr")) =>
            {
                Ok(())
            }

            // Non-generic type identity: Con("Point") == App(Con("Point"), [])
            // This arises because infer_struct_literal returns App(Con(name), []) for
            // non-generic structs, while name_to_type returns Con(name). Both represent
            // the same type.
            (Ty::Con(ref c), Ty::App(ref con, ref args))
            | (Ty::App(ref con, ref args), Ty::Con(ref c))
                if args.is_empty() && matches!(con.as_ref(), Ty::Con(ref ac) if ac == c) =>
            {
                Ok(())
            }

            // Type applications -- unify constructor and args.
            (Ty::App(c1, a1), Ty::App(c2, a2)) => {
                // Different constructors, or one applied to another number of
                // arguments (which counting them where a type is named rules
                // out): the whole types differ ("expected Map<String, Int>,
                // found List<Int>", not "Map, found List").
                if let (Ty::Con(h1), Ty::Con(h2)) =
                    (self.resolve(*c1.clone()), self.resolve(*c2.clone()))
                {
                    let heads_differ = h1 != h2 && !Self::iterator_ptr_compatible(&h1, &h2);
                    if heads_differ || a1.len() != a2.len() {
                        let err = TypeError::Mismatch {
                            expected: self.resolve(Ty::App(c1, a1)),
                            found: self.resolve(Ty::App(c2, a2)),
                            origin,
                        };
                        self.errors.push(err.clone());
                        return Err(err);
                    }
                }
                self.unify(*c1, *c2, origin.clone())?;
                for (a, b) in a1.into_iter().zip(a2) {
                    self.unify(a, b, origin.clone())?;
                }
                Ok(())
            }

            // Tuple escape hatch: untyped Tuple (Con) unifies with any typed tuple (Ty::Tuple).
            // This allows Tuple.first/Tuple.second to accept concrete tuple types like (Int, String).
            (Ty::Con(ref c), Ty::Tuple(_)) | (Ty::Tuple(_), Ty::Con(ref c))
                if c.name == "Tuple" =>
            {
                Ok(())
            }

            // Tuple types -- unify element-wise.
            (Ty::Tuple(e1), Ty::Tuple(e2)) => {
                if e1.len() != e2.len() {
                    // Tuples of different lengths are different types: not
                    // "expected 2 argument(s)".
                    let err = TypeError::Mismatch {
                        expected: self.resolve(Ty::Tuple(e1)),
                        found: self.resolve(Ty::Tuple(e2)),
                        origin,
                    };
                    self.errors.push(err.clone());
                    Err(err)
                } else {
                    for (a, b) in e1.into_iter().zip(e2.into_iter()) {
                        self.unify(a, b, origin.clone())?;
                    }
                    Ok(())
                }
            }

            // Never unifies with anything (bottom type).
            (Ty::Never, _) | (_, Ty::Never) => Ok(()),

            // Everything else is a mismatch.
            (a, b) => {
                let err = TypeError::Mismatch {
                    expected: a,
                    found: b,
                    origin,
                };
                self.errors.push(err.clone());
                Err(err)
            }
        }
    }

    // ── Level Management ────────────────────────────────────────────────

    /// How deep the checker is nested (let levels, loops, function bodies)
    /// and how many scopes `env` has. An error abandons an expression or a
    /// definition midway, past the ends of what it entered; `restore` goes
    /// back to where it was before.
    pub fn nesting(&self, env: &TypeEnv) -> Nesting {
        Nesting {
            level: self.current_level,
            loop_depth: self.loop_depth,
            returns: self.fn_return_type_stack.len(),
            scopes: env.depth(),
            index_equations: self.index_equations.len(),
        }
    }

    /// Go back to a `nesting` taken before an error.
    pub fn restore(&mut self, env: &mut TypeEnv, nesting: Nesting) {
        self.current_level = nesting.level;
        self.loop_depth = nesting.loop_depth;
        self.fn_return_type_stack.truncate(nesting.returns);
        self.fn_return_levels.truncate(nesting.returns);
        self.fn_returned_types.truncate(nesting.returns);
        self.index_equations.truncate(nesting.index_equations);
        env.truncate(nesting.scopes);
    }

    /// Enter a new let-binding level (increases nesting depth).
    pub fn enter_level(&mut self) {
        self.current_level += 1;
    }

    /// Leave the current let-binding level (decreases nesting depth).
    pub fn leave_level(&mut self) {
        debug_assert!(self.current_level > 0, "cannot leave level 0");
        self.current_level -= 1;
    }

    // ── Generalization ──────────────────────────────────────────────────

    /// Generalize a type into a polymorphic scheme.
    ///
    /// Collects all type variables in `ty` whose level is strictly greater
    /// than `current_level` -- these are the variables that were introduced
    /// at a deeper level and can be universally quantified.
    pub fn generalize(&mut self, ty: Ty) -> Scheme {
        let resolved = self.resolve(ty);
        let mut free_vars = Vec::new();
        self.collect_generalizable_vars(&resolved, &mut free_vars);
        // Deduplicate while preserving order.
        let mut seen = std::collections::HashSet::new();
        free_vars.retain(|v| seen.insert(*v));
        Scheme {
            vars: free_vars,
            ty: resolved,
        }
    }

    /// The scheme of a binding that is not generalized: its variables are
    /// lowered to the current level, so a later `let` beside it does not
    /// generalize them away from it either.
    pub fn monomorphic(&mut self, ty: Ty) -> Scheme {
        let level = self.current_level;
        self.lower_levels(&ty, level);
        Scheme::mono(self.resolve(ty))
    }

    /// Collect type variables that can be generalized (level > current_level).
    /// `ty` is resolved: its variables are unbound.
    fn collect_generalizable_vars(&self, ty: &Ty, out: &mut Vec<TyVar>) {
        if let Some(var) = ty.variable() {
            if self.level_of(var) > self.current_level && !self.arm_indices.contains(&var) {
                out.push(var);
            }
        }
        ty.parts()
            .for_each(|part| self.collect_generalizable_vars(part, out));
    }

    // ── Instantiation ───────────────────────────────────────────────────

    /// Instantiate a polymorphic scheme with fresh type variables.
    ///
    /// Creates a fresh type variable for each quantified variable in the
    /// scheme, then substitutes them throughout the type.
    pub fn instantiate(&mut self, scheme: &Scheme) -> Ty {
        if scheme.vars.is_empty() {
            return scheme.ty.clone();
        }

        let substitution: FxHashMap<TyVar, Ty> =
            scheme.vars.iter().map(|v| (*v, self.fresh_var())).collect();

        // An associated type the scheme holds as a variable is the same
        // associated type of the instance's receiver.
        let mut instances = Vec::new();
        for (var, trait_name, assoc, receiver) in self.assoc_projections.clone() {
            let receiver = self.resolve(receiver);
            let Ty::Var(receiver_root) = receiver else {
                continue;
            };
            if !substitution.contains_key(&receiver_root) {
                continue;
            }
            let instance_receiver = substitution[&receiver_root].clone();
            // The instance's is the receiver's associated type, whatever
            // its use takes it for (`let s :: String = first(box)`).
            let required = match self.resolve(var) {
                Ty::Var(root) if substitution.contains_key(&root) => {
                    let instance = substitution[&root].clone();
                    instances.push((
                        instance.clone(),
                        trait_name.clone(),
                        assoc.clone(),
                        instance_receiver.clone(),
                    ));
                    instance
                }
                Ty::Var(_) => continue,
                fixed => fixed,
            };
            self.projection_requirements.push((
                required,
                trait_name,
                assoc,
                instance_receiver,
                self.expr_spans.last().copied(),
            ));
        }
        self.assoc_projections.extend(instances);

        // What the binding's value requires of its variables, required of
        // this instance's.
        for var in &scheme.vars {
            for requirement in self
                .scheme_requirements
                .get(var)
                .cloned()
                .unwrap_or_default()
            {
                match requirement {
                    SchemeRequirement::Trait(ty, trait_name, origin) => {
                        let ty = self.apply_substitution(&ty, &substitution);
                        self.operand_traits.push((ty, trait_name, origin));
                    }
                    SchemeRequirement::Concat(ty, op, span) => {
                        let ty = self.apply_substitution(&ty, &substitution);
                        self.concat_operands.push((ty, op, span));
                    }
                }
            }
        }

        self.apply_substitution(&scheme.ty, &substitution)
    }

    /// Hands what was required, since the marks `traits_from` and
    /// `concat_from`, of the variables `vars` a binding's scheme generalizes
    /// to the scheme's instances (see `SchemeRequirement`). Checked on the
    /// generalized variables themselves, which no use ever fixes, it could
    /// never fail.
    pub fn generalize_requirements(
        &mut self,
        vars: &[TyVar],
        traits_from: usize,
        concat_from: usize,
    ) {
        if vars.is_empty() {
            return;
        }
        let traits = self.operand_traits.split_off(traits_from);
        for (ty, trait_name, origin) in traits {
            let ty = self.resolve(ty);
            match first_of(&ty, vars) {
                Some(var) => self
                    .scheme_requirements
                    .entry(var)
                    .or_default()
                    .push(SchemeRequirement::Trait(ty, trait_name, origin)),
                None => self.operand_traits.push((ty, trait_name, origin)),
            }
        }
        let concat = self.concat_operands.split_off(concat_from);
        for (ty, op, span) in concat {
            let ty = self.resolve(ty);
            match first_of(&ty, vars) {
                Some(var) => self
                    .scheme_requirements
                    .entry(var)
                    .or_default()
                    .push(SchemeRequirement::Concat(ty, op, span)),
                None => self.concat_operands.push((ty, op, span)),
            }
        }
    }

    /// Apply a substitution map to a type.
    fn apply_substitution(&mut self, ty: &Ty, subst: &FxHashMap<TyVar, Ty>) -> Ty {
        match ty {
            Ty::Nat(index) => self.resolve(Ty::Nat(index.map_leaf(|leaf| match leaf {
                NatIndex::Variable(var) => match subst.get(var) {
                    Some(Ty::Var(replacement)) => NatIndex::Variable(*replacement),
                    None => leaf.clone(),
                    Some(_) => unreachable!("a scheme allocates fresh variable ids"),
                },
                _ => leaf.clone(),
            }))),
            Ty::Var(v) => {
                if let Some(replacement) = subst.get(v) {
                    replacement.clone()
                } else {
                    // Check if this var is bound in the table.
                    let probe = self.table.probe_value(*v);
                    match probe {
                        Some(inner) => self.apply_substitution(&inner, subst),
                        None => ty.clone(),
                    }
                }
            }
            _ => ty.map_parts(|part| self.apply_substitution(part, subst)),
        }
    }
}

// ── Tests ──────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;
    use crate::error::ConstraintOrigin;
    use crate::ty::TyCon;

    fn builtin_origin() -> ConstraintOrigin {
        ConstraintOrigin::Builtin
    }

    #[test]
    fn a_tuple_row_takes_its_elements_from_the_tuple_it_meets() {
        let mut ctx = InferCtx::new();
        // What `Tuple.first(p)` says about a `p` of unknown type.
        let (p, first, tail) = (ctx.fresh_var(), ctx.fresh_var(), ctx.fresh_var());
        let row = Ty::tuple_row(vec![first.clone()], tail);
        assert!(ctx.unify(p.clone(), row, builtin_origin()).is_ok());
        assert!(ctx.resolve(p.clone()).as_tuple_row().is_some());

        let pair = Ty::Tuple(vec![Ty::string(), Ty::int()]);
        assert!(ctx.unify(p.clone(), pair.clone(), builtin_origin()).is_ok());
        assert_eq!(ctx.resolve(first), Ty::string());
        assert_eq!(ctx.resolve(p), pair, "a row with a known tail is the tuple");
    }

    #[test]
    fn two_tuple_rows_agree_on_the_elements_both_name() {
        let mut ctx = InferCtx::new();
        // `Tuple.first(p)` and then `Tuple.second(p)` on the same unknown `p`.
        let p = ctx.fresh_var();
        let (a, t1) = (ctx.fresh_var(), ctx.fresh_var());
        let (b, c, t2) = (ctx.fresh_var(), ctx.fresh_var(), ctx.fresh_var());
        let first = Ty::tuple_row(vec![a.clone()], t1);
        let second = Ty::tuple_row(vec![b, c.clone()], t2);
        assert!(ctx.unify(p.clone(), first, builtin_origin()).is_ok());
        assert!(ctx.unify(p.clone(), second, builtin_origin()).is_ok());

        let triple = Ty::Tuple(vec![Ty::int(), Ty::bool(), Ty::string()]);
        assert!(ctx
            .unify(p.clone(), triple.clone(), builtin_origin())
            .is_ok());
        assert_eq!(ctx.resolve(a), Ty::int());
        assert_eq!(ctx.resolve(c), Ty::bool());
        assert_eq!(ctx.resolve(p), triple);
    }

    #[test]
    fn a_tuple_row_rejects_what_cannot_be_that_tuple() {
        let mut ctx = InferCtx::new();
        let row = |ctx: &mut InferCtx| {
            let (a, b, tail) = (ctx.fresh_var(), ctx.fresh_var(), ctx.fresh_var());
            Ty::tuple_row(vec![a, b], tail)
        };
        let too_short = Ty::Tuple(vec![Ty::int()]);
        let r = row(&mut ctx);
        assert!(ctx.unify(r, too_short, builtin_origin()).is_err());
        let r = row(&mut ctx);
        assert!(ctx.unify(r, Ty::int(), builtin_origin()).is_err());

        // The untyped `Tuple` promises Int elements, as its accessors always have.
        let (a, tail) = (ctx.fresh_var(), ctx.fresh_var());
        let r = Ty::tuple_row(vec![a.clone()], tail);
        let untyped = Ty::Con(TyCon::new("Tuple"));
        assert!(ctx.unify(r, untyped, builtin_origin()).is_ok());
        assert_eq!(ctx.resolve(a), Ty::int());
    }

    #[test]
    fn unify_two_fresh_vars() {
        let mut ctx = InferCtx::new();
        let a = ctx.fresh_var();
        let b = ctx.fresh_var();

        // Unify a ~ b
        assert!(ctx.unify(a.clone(), b.clone(), builtin_origin()).is_ok());

        // After unification, binding one to Int should make both resolve to Int.
        assert!(ctx.unify(a.clone(), Ty::int(), builtin_origin()).is_ok());
        let ra = ctx.resolve(a);
        let rb = ctx.resolve(b);
        assert_eq!(ra, Ty::int());
        assert_eq!(rb, Ty::int());
    }

    #[test]
    fn unify_var_with_concrete() {
        let mut ctx = InferCtx::new();
        let a = ctx.fresh_var();
        let int = Ty::int();

        // Unify a ~ Int
        assert!(ctx.unify(a.clone(), int.clone(), builtin_origin()).is_ok());

        // a should resolve to Int.
        let resolved = ctx.resolve(a);
        assert_eq!(resolved, int);
    }

    #[test]
    fn unify_mismatch() {
        let mut ctx = InferCtx::new();
        let int = Ty::int();
        let string = Ty::string();

        // Unify Int ~ String => should fail.
        let result = ctx.unify(int, string, builtin_origin());
        assert!(result.is_err());
        match result.unwrap_err() {
            TypeError::Mismatch {
                expected, found, ..
            } => {
                assert_eq!(expected, Ty::int());
                assert_eq!(found, Ty::string());
            }
            other => panic!("expected Mismatch, got {:?}", other),
        }
    }

    #[test]
    fn unify_function_return_mismatch() {
        let mut ctx = InferCtx::new();
        let f1 = Ty::fun(vec![Ty::int()], Ty::string());
        let f2 = Ty::fun(vec![Ty::int()], Ty::bool());

        // (Int) -> String ~ (Int) -> Bool => mismatch on return type.
        let result = ctx.unify(f1, f2, builtin_origin());
        assert!(result.is_err());
        match result.unwrap_err() {
            TypeError::Mismatch {
                expected, found, ..
            } => {
                assert_eq!(expected, Ty::string());
                assert_eq!(found, Ty::bool());
            }
            other => panic!("expected Mismatch, got {:?}", other),
        }
    }

    #[test]
    fn occurs_check_infinite_type() {
        let mut ctx = InferCtx::new();
        let a = ctx.fresh_var();

        // Unify a ~ (a) -> Int => should detect infinite type.
        let fun = Ty::fun(vec![a.clone()], Ty::int());
        let result = ctx.unify(a, fun, builtin_origin());
        assert!(result.is_err());
        match result.unwrap_err() {
            TypeError::InfiniteType { .. } => {} // expected
            other => panic!("expected InfiniteType, got {:?}", other),
        }
    }

    #[test]
    fn generalize_and_instantiate() {
        let mut ctx = InferCtx::new();

        // Create a type a -> a at level 1.
        ctx.enter_level();
        let a = ctx.fresh_var();
        let identity_ty = Ty::fun(vec![a.clone()], a);
        ctx.leave_level();

        // Generalize: should quantify over the type variable.
        let scheme = ctx.generalize(identity_ty);
        assert_eq!(scheme.vars.len(), 1, "should have one quantified var");

        // Instantiate twice: should produce different fresh variables.
        let inst1 = ctx.instantiate(&scheme);
        let inst2 = ctx.instantiate(&scheme);

        // The two instantiations should have different type variables.
        match (&inst1, &inst2) {
            (Ty::Fun(p1, _), Ty::Fun(p2, _)) => {
                // The fresh vars in inst1 and inst2 should be different.
                assert_ne!(p1[0], p2[0], "instantiations should produce different vars");
            }
            _ => panic!("expected function types"),
        }
    }

    /// One constructor applied to different numbers of arguments makes two
    /// different types.
    #[test]
    fn unify_applications_of_different_lengths_mismatch() {
        let mut ctx = InferCtx::new();
        let boxed = |args: Vec<Ty>| Ty::App(Box::new(Ty::Con(TyCon::new("Box"))), args);
        let result = ctx.unify(
            boxed(vec![Ty::int()]),
            boxed(vec![Ty::int(), Ty::int()]),
            builtin_origin(),
        );
        assert!(
            matches!(result, Err(TypeError::Mismatch { .. })),
            "{result:?}"
        );
    }

    #[test]
    fn unify_function_arity_mismatch() {
        let mut ctx = InferCtx::new();
        let f1 = Ty::fun(vec![Ty::int()], Ty::string());
        let f2 = Ty::fun(vec![Ty::int(), Ty::int()], Ty::string());

        let result = ctx.unify(f1, f2, builtin_origin());
        assert!(result.is_err());
        match result.unwrap_err() {
            TypeError::ArityMismatch {
                expected: 1,
                found: 2,
                ..
            } => {}
            other => panic!("expected ArityMismatch(1, 2), got {:?}", other),
        }
    }

    #[test]
    fn unify_never_with_anything() {
        let mut ctx = InferCtx::new();

        // Never unifies with any type.
        assert!(ctx.unify(Ty::Never, Ty::int(), builtin_origin()).is_ok());
        assert!(ctx.unify(Ty::string(), Ty::Never, builtin_origin()).is_ok());
    }

    #[test]
    fn unify_tuple_types() {
        let mut ctx = InferCtx::new();
        let t1 = Ty::Tuple(vec![Ty::int(), Ty::string()]);
        let t2 = Ty::Tuple(vec![Ty::int(), Ty::string()]);

        assert!(ctx.unify(t1, t2, builtin_origin()).is_ok());
    }

    #[test]
    fn unify_app_types() {
        let mut ctx = InferCtx::new();
        let opt_int = Ty::option(Ty::int());
        let opt_int2 = Ty::option(Ty::int());

        assert!(ctx.unify(opt_int, opt_int2, builtin_origin()).is_ok());
    }

    #[test]
    fn unify_app_type_mismatch() {
        let mut ctx = InferCtx::new();
        let opt_int = Ty::option(Ty::int());
        let opt_str = Ty::option(Ty::string());

        let result = ctx.unify(opt_int, opt_str, builtin_origin());
        assert!(result.is_err());
    }

    #[test]
    fn con_unifies_with_app_con_empty_args() {
        let mut ctx = InferCtx::new();
        let con = Ty::Con(TyCon::new("Point"));
        let app = Ty::App(Box::new(Ty::Con(TyCon::new("Point"))), vec![]);
        // Con("Point") should unify with App(Con("Point"), [])
        assert!(ctx
            .unify(con.clone(), app.clone(), builtin_origin())
            .is_ok());
        // Symmetric: App should also unify with Con
        assert!(ctx.unify(app, con, builtin_origin()).is_ok());
    }

    #[test]
    fn con_does_not_unify_with_app_con_nonempty_args() {
        let mut ctx = InferCtx::new();
        let con = Ty::Con(TyCon::new("List"));
        let app = Ty::App(Box::new(Ty::Con(TyCon::new("List"))), vec![Ty::int()]);
        // Con("List") should NOT unify with App(Con("List"), [Int]) -- different arities
        assert!(ctx.unify(con, app, builtin_origin()).is_err());
    }

    #[test]
    fn ty_display() {
        assert_eq!(format!("{}", Ty::int()), "Int");
        assert_eq!(
            format!("{}", Ty::fun(vec![Ty::int(), Ty::string()], Ty::bool())),
            "(Int, String) -> Bool"
        );
        assert_eq!(format!("{}", Ty::option(Ty::int())), "Option<Int>");
        assert_eq!(
            format!("{}", Ty::result(Ty::string(), Ty::int())),
            "Result<String, Int>"
        );
        assert_eq!(
            format!("{}", Ty::Tuple(vec![Ty::int(), Ty::string()])),
            "(Int, String)"
        );
        assert_eq!(format!("{}", Ty::Never), "Never");
    }
}
