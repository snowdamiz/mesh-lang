fn job_spec(args :: Json) -> String!String do
  let key = Json.as_string(Json.object_get(args, "key")?)?
  let _ = Json.as_string(Json.object_get(args, "payload")?)?
  let hold = Json.as_int(Json.object_get(args, "hold_ms")?)?
  let _ = Json.as_bool(Json.object_get(args, "fail_first")?)?
  if hold < 0 do
    return Err("hold_ms must be nonnegative")
  end
  let max_attempts = if Env.get("JOBS_PARITY_MODE", "") == "final_attempt" do 1 else 3 end
  Ok(Json.encode(json {
    worker: "parity", args: args, request_key: key, max_attempts: max_attempts,
    backoff_base_ms: 1000, backoff_max_ms: 1000
  }))
end

fn collect_specs(jobs :: Json, index :: Int, stop :: Int, specs :: List<String>, batch_bytes :: Int) -> List<String>!String do
  if index == stop do
    return Ok(specs)
  end
  let spec = job_spec(Json.array_get(jobs, index)?)?
  let spec_bytes = Bytes.length(Bytes.from_utf8(spec))
  IO.eprintln("ENCODE " <> String.from(index) <> " " <> String.from(spec_bytes))
  let empty = List.length(specs) == 0
  let comma_bytes = if empty do 0 else 1 end
  let next_bytes = batch_bytes + spec_bytes + comma_bytes
  if next_bytes > 1_048_576 do
    if empty do
      return Err("encoded job exceeds the Jobs.enqueue_in input limit")
    end
    return Ok(specs)
  end
  collect_specs(jobs, index + 1, stop, List.append(specs, spec), next_bytes)
end

fn enqueue_batches(jobs :: Json, index :: Int, count :: Int, chunks :: Int) -> Int!String do
  if index < count do
    let stop = if count - index > 128 do index + 128 else count end
    let specs = collect_specs(jobs, index, stop, [], 2)?
    let size = List.length(specs)
    let batch_text = "[" <> String.join(specs, ",") <> "]"
    if batch_text == "" do return Err("missing serialized batch") end
    let _ = File.write(Env.get("TRACE_DIR", "") <> "/" <> String.from(chunks), batch_text)?
    enqueue_batches(jobs, index + size, count, chunks + 1)
  else
    Ok(chunks)
  end
end

fn run() -> Unit!String do
  let input = Json.parse(File.read(Env.get("INPUT", ""))?)?
  let jobs = Json.object_get(input, "jobs")?
  let count = Json.array_length(jobs)?
  let started = Monotonic.now_nanos()
  let chunks = enqueue_batches(jobs, 0, count, 0)?
  let elapsed = Monotonic.now_nanos() - started
  println(Json.encode(json { chunks: chunks, count: count, elapsed_ns: elapsed }))
  Ok(())
end

fn main() do
  case run() do
    Ok(_) -> ()
    Err(error) ->
      IO.eprintln(error)
      Process.exit(1)
  end
end
