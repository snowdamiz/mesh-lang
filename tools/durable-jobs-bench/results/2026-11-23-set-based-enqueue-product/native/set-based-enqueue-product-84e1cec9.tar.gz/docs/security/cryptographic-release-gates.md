# Cryptographic Release Gates

Status: mandatory gates for any Mesh release that adds or changes a
cryptographic primitive, provider, secret type, or supported cryptographic
profile.

These gates distinguish implementation progress from release approval. Passing
unit tests alone is not sufficient, and development-profile evidence must not
be presented as production security review.

## Gate 1: Profile and compatibility

- The consuming protocol names a versioned cryptographic profile.
- Algorithms, parameters, domain-separation labels, wire identifiers, and
  downgrade behavior are explicit.
- The selected suite is authenticated and included in associated data where
  applicable.
- Unsupported higher suites fail explicitly; there is no silent algorithm
  fallback.
- Compatibility and migration behavior have tests.

## Gate 2: Public Mesh contract

- A binary-first public Mesh API exists.
- Secret keys and retained key material use secret/resource types, never
  ordinary `Bytes` or `String`.
- Inputs and allocations are bounded and errors are typed.
- Type checking, code generation, and runtime ABI agree.
- The same public API is used by tests, examples, and production code.
- The messenger consumes the public API; no private application-level Rust
  protocol or cryptographic implementation exists.

## Gate 3: Provider and dependencies

- The default provider and dependency versions are pinned.
- Any deterministic test provider is compile-time test-only.
- Unsupported targets fail clearly.
- Dependency provenance, security findings, versions, and licenses are
  reviewed under the [dependency policy](dependency-policy.md).
- No dependency changes the selected algorithm or compatibility behavior
  implicitly.

## Gate 4: Verification evidence

Evidence must be generated from the release commit and include:

- Published known-answer vectors and an automated vector runner.
- Negative tests for malformed inputs, wrong lengths, wrong keys, tampering,
  authentication failure, and allocation limits.
- Fuzz harnesses for every public parser and cryptographic boundary.
- Regression coverage for known defects, including secure-comparison length
  boundaries.
- Secret-leak sentinel tests across errors, panic paths, logs, telemetry, and
  crash reports.
- Cross-platform builds for every advertised target.
- Machine-readable test reports and coverage results.
- A dependency audit, software bill of materials, and reproducible-build
  check.

Plaintext must never be returned after an authentication failure. Tests must
exercise the actual public API and provider used in production.

## Gate 5: Constant-time assurance

Runtime-backed primitives must use the approved provider and constant-time
dependency as defined by the [constant-time policy](constant-time-policy.md).

A cryptographic algorithm implemented directly in Mesh also requires
differential tests, generated-machine-code inspection, timing-distribution
tests, and all supported optimization levels and architectures. External
specialist review is valuable additional scrutiny, not a release prerequisite.

## Gate 6: Integration proof

- The messenger pins the exact Mesh commit or release in CI.
- Interoperability tests cross the Mesh API and application boundary.
- Protocol codecs, snapshots, and stored secret blobs have explicit versions.
- Mobile builds execute the same vectors on every supported platform before
  that platform is advertised.
- Production-target profiles require internally verified evidence for the exact
  candidate and applicable platforms. Independent review is reported accurately
  and is not an activation requirement.

## Stop-ship conditions

A release is blocked if any applicable gate lacks current evidence, or if it
contains:

- A known correctness defect in authentication, comparison, key derivation,
  nonce handling, or secret destruction.
- Secret material in ordinary strings, logs, diagnostics, telemetry, crash
  reports, or serialized actor messages.
- An undocumented algorithm, fallback, domain label, or profile change.
- An unresolved dependency finding without an explicit security disposition.
- A target that silently substitutes or omits the selected primitive.
- Stale evidence produced from a different source revision.

## Current baseline

The development runtime implements the classical Crypto V2 API, an ML-KEM-768
KEM primitive (libcrux-ml-kem 0.0.10, portable implementation on every target),
an Argon2id v1.3 password KDF, and blind RSA profile BR1
(RFC 9474 RSABSSA-SHA384-PSS-Deterministic, 2,048 bits, the RFC 9578 token type
`0x0002` scheme), plus affine secret resources,
a static production provider, a test-only deterministic provider, known-answer
and negative tests, a published NIST ACVP ML-KEM-768 key-generation vector
executed through the public Mesh API, every ACVP ML-KEM-768 key-generation,
encapsulation and decapsulation case plus an OpenSSL differential run through
the runtime's ML-KEM helpers, secret-table memory locked in RAM and left out
of core dumps where the OS allows it (see the
[secret memory model](secret-memory-model.md)), core dumps turned off in
release executables, and an iOS compilation proof. The hybrid
messenger suite is callable; there is no software-enforced external-review
disable. Release readiness requires protocol negotiation, downgrade and target
performance evidence at the exact candidate. No independent audit is claimed:

- Native fuzz targets now exercise byte operations, including bounded
  Argon2id calls through the production provider,
  runtime protocol/routing/WebSocket decoders, and the lexer/parser. Coverage-
  guided targets for generated Mesh messenger boundaries and the complete
  secret-leak sentinel suite remain open.
- The full advertised mobile/host target matrix remains a Milestone 10 gate.
- The release workflow now blocks tagged releases on a clean RustSec audit, a
  CycloneDX SBOM, and two reproducible isolated `meshc` builds for the workflow
  host. It also records a release-mode timing-distribution check for
  `Bytes.secure_equals`, runs the published ML-KEM vector through compiled Mesh,
  and packages both the vector and its test log. Published external vectors for
  the remaining Crypto V2 primitives and reproducibility of every advertised
  target archive remain open.
- ML-KEM provider evidence (libcrux-ml-kem 0.0.10): `crypto::mlkem_tests`
  checks all 25 ACVP key generations (public and expanded private key), 25
  encapsulations and 10 decapsulations (implicit rejection included) at
  ACVP-Server `65370b86`, and eight OpenSSL 3.6.3 cases (public key from seed,
  encapsulation, decapsulation of the ciphertext and a tampered copy);
  `crypto::tests::nist_acvp_mlkem768_keygen_tc26_matches_public_key` keeps the
  release vector at the runtime level. `scripts/verify-crypto-mobile.sh`
  proves libcrux, not the `ml-kem` crate, is in the iOS and Android graphs.
  libcrux's portable backend is formally verified; parts of its generic code
  and its SHA-3 are not yet (see the dependency change review). The outside
  review (plan C10) is still to come.
- Blind RSA BR1 evidence: all five RFC 9578 Appendix A.2 tokens run through
  the public Mesh API in compiled Mesh (key import, SPKI, signing, token
  verification) and through the helpers with the deterministic test provider
  (blinding reproduces each token request); RFC 9474 Appendix A.3 runs through
  the size-generic helpers and AWS-LC at 4,096 bits. An OpenSSL CLI
  differential checks Mesh SPKIs and finalized signatures with
  `openssl dgst -sha384` (RSASSA-PSS, 48-byte salt) and raw signing against
  OpenSSL's raw private-key operation. Negative and bounds tests cover wrong
  lengths, a blinded value not below n, every byte of the SPKI template,
  another exponent or size, tampered and misplaced signatures, stale,
  destroyed, wrong-kind and wrong-owner handles, a second finalize with one
  state (a compile error) and `UnsupportedTarget` off the servers, which also
  runs in the iOS simulator. The crypto fuzz target covers SPKI parsing,
  blinding, finalizing, verifying and signing rejection, with corpus seeds.
  The release timing check covers `Crypto.blind_rsa_sign`, and the release
  evidence publishes the RFC 9578 vectors, runs the vector proof and the
  differential, and records the BR1 profile. Android and Windows are
  build-verified only (no AWS-LC linked); an outside review of the primitive is
  still to come.

Current primitives are implementation baseline, not approval evidence. A
release record must name the profile, Mesh revision, provider and dependency
versions, tested targets and optimization levels, vector set, test reports,
audit/SBOM/reproducibility results, known limitations, and required review.

Run `bash scripts/generate-crypto-release-evidence.sh OUTPUT_DIRECTORY` from a
clean release revision to produce the audit JSON, CycloneDX 1.5 SBOM,
secure-equality timing record, reproducibility comparison, release record,
published ML-KEM vector, public-Mesh vector test log, logs, and checksums. The
output record explicitly lists the remaining vector, fuzzing, target-matrix,
secret-leak evidence that this command does not provide. Independent review
is recorded separately and is not an approval credential.
