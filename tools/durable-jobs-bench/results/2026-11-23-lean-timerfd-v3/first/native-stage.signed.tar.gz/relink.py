"""Reuse the exact compiled handler. Re-emit only the digest-bearing parent IR."""
import json
from pathlib import Path
import re
import sys
from types import SimpleNamespace

from specialize import classify, digest, emit_obj, link, native_check, runner_ir

stage = Path(sys.argv[1]).resolve()
runtime = Path(sys.argv[2]).resolve()
inputs = stage / "inputs"
out = stage / "out"
native = inputs / "libworker_identity.a"
args = SimpleNamespace(native=native, runtime=runtime)
native_check(native, "adcb475dbad943e5807543e992d64decba5e15f78923b2811df12f44a1726270", out)
ir_path = inputs / "full.opt.ll"
ir = ir_path.read_text()
target = re.search(r'^target triple = "([^"]+)"', ir, re.M)[1]
closure = classify(ir)
assert closure[3] == "e03da7787d8c4083:Main__handle"
worker_object = inputs / "worker.o"
for worker, parent, extra in (
    ("mesh-lean-worker", "mesh", ()),
    ("mesh-lean-witness", "mesh-witness-runner",
     ("-pthread", "-Wl,--wrap=mesh_parity_worker_pid", inputs / "witness_a.o", out / "witness-clock.o")),
):
    link(worker_object, out / worker, args, out / (worker + ".map"), extra)
    specialized_ir = out / (parent + ".ll")
    specialized_ir.write_text(runner_ir(ir, closure, digest(out / worker)))
    obj = out / (parent + ".o")
    emit_obj(specialized_ir, target, obj)
    link(obj, out / parent, args, out / (parent + ".map"))
manifest = {
    "fingerprint": closure[3], "native_imports": sorted(closure[6]), "mesh_functions": sorted(closure[4]),
    "native_sha256": digest(native), "handler_object_sha256": digest(worker_object),
    "runtime_sha256": digest(runtime), "worker_sha256": digest(out / "mesh-lean-worker"),
    "runner_sha256": digest(out / "mesh"), "witness_sha256": digest(out / "mesh-lean-witness"),
    "witness_runner_sha256": digest(out / "mesh-witness-runner"),
}
(out / "closure.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps(manifest, indent=2))
