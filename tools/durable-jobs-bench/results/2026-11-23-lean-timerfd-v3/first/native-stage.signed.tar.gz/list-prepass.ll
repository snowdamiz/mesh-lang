
define private i64 @mesh_list_length.inline(ptr %0) alwaysinline {
entry:
  %length = load i64, ptr %0, align 8
  ret i64 %length
}

define private i64 @mesh_list_get.inline(ptr %0, i64 %1) alwaysinline {
entry:
  %length = load i64, ptr %0, align 8
  %in_bounds = icmp ult i64 %1, %length
  br i1 %in_bounds, label %select_data, label %bounds_error
bounds_error:
  %bounds_panic = call i64 @mesh_list_get(ptr %0, i64 %1)
  unreachable
select_data:
  %capacity_slot = getelementptr i64, ptr %0, i64 1
  %capacity = load i64, ptr %capacity_slot, align 8
  %owned_data = getelementptr i64, ptr %0, i64 2
  %is_view = icmp eq i64 %capacity, -1
  br i1 %is_view, label %list_view, label %list_data
list_view:
  %parent_word = load i64, ptr %owned_data, align 8
  %parent = inttoptr i64 %parent_word to ptr
  %offset_slot = getelementptr i64, ptr %0, i64 3
  %offset = load i64, ptr %offset_slot, align 8
  %parent_data = getelementptr i64, ptr %parent, i64 2
  %view_data = getelementptr i64, ptr %parent_data, i64 %offset
  br label %list_data
list_data:
  %data = phi ptr [ %owned_data, %select_data ], [ %view_data, %list_view ]
  %element = getelementptr i64, ptr %data, i64 %1
  %value = load i64, ptr %element, align 8
  ret i64 %value
}
