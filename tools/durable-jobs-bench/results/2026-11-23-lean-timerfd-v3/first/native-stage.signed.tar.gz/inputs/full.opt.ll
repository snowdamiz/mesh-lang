; ModuleID = '/var/lib/durable-jobs-bench/native/lean-worker-v3.PcX1SX/out/full.preopt.ll'
source_filename = "mesh_module"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

@.str = unnamed_addr constant { i64, [18 x i8] } { i64 18, [18 x i8] c"JOBS_PARITY_DB_URL" }, align 8
@.str.1 = unnamed_addr constant { i64, [0 x i8] } zeroinitializer, align 8
@.str.2 = unnamed_addr constant { i64, [21 x i8] } { i64 21, [21 x i8] c"JOBS_PARITY_NAMESPACE" }, align 8
@.str.3 = unnamed_addr constant { i64, [0 x i8] } zeroinitializer, align 8
@.str.4 = unnamed_addr constant { i64, [23 x i8] } { i64 23, [23 x i8] c"JOBS_PARITY_TOTAL_SLOTS" }, align 8
@.str.5 = unnamed_addr constant { i64, [50 x i8] } { i64 50, [50 x i8] c"JOBS_PARITY_TOTAL_SLOTS must be between 1 and 1024" }, align 8
@.panic_msg = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.6 = unnamed_addr constant { i64, [6 x i8] } { i64 6, [6 x i8] c"action" }, align 8
@.str.7 = unnamed_addr constant { i64, [9 x i8] } { i64 9, [9 x i8] c"configure" }, align 8
@.str.8 = unnamed_addr constant { i64, [5 x i8] } { i64 5, [5 x i8] c"queue" }, align 8
@.str.9 = unnamed_addr constant { i64, [7 x i8] } { i64 7, [7 x i8] c"default" }, align 8
@.str.10 = unnamed_addr constant { i64, [11 x i8] } { i64 11, [11 x i8] c"concurrency" }, align 8
@.str.11 = unnamed_addr constant { i64, [3 x i8] } { i64 3, [3 x i8] c"key" }, align 8
@.panic_msg.12 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.13 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.panic_msg.14 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.15 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.16 = unnamed_addr constant { i64, [7 x i8] } { i64 7, [7 x i8] c"payload" }, align 8
@.panic_msg.17 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.18 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.panic_msg.19 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.20 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.21 = unnamed_addr constant { i64, [7 x i8] } { i64 7, [7 x i8] c"hold_ms" }, align 8
@.panic_msg.22 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.23 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.panic_msg.24 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.25 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.26 = unnamed_addr constant { i64, [10 x i8] } { i64 10, [10 x i8] c"fail_first" }, align 8
@.panic_msg.27 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.28 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.panic_msg.29 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.30 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.31 = unnamed_addr constant { i64, [27 x i8] } { i64 27, [27 x i8] c"hold_ms must be nonnegative" }, align 8
@.str.32 = unnamed_addr constant { i64, [16 x i8] } { i64 16, [16 x i8] c"JOBS_PARITY_MODE" }, align 8
@.str.33 = unnamed_addr constant { i64, [0 x i8] } zeroinitializer, align 8
@.str.34 = unnamed_addr constant { i64, [13 x i8] } { i64 13, [13 x i8] c"final_attempt" }, align 8
@.str.35 = unnamed_addr constant { i64, [6 x i8] } { i64 6, [6 x i8] c"worker" }, align 8
@.str.36 = unnamed_addr constant { i64, [6 x i8] } { i64 6, [6 x i8] c"parity" }, align 8
@.str.37 = unnamed_addr constant { i64, [4 x i8] } { i64 4, [4 x i8] c"args" }, align 8
@.str.38 = unnamed_addr constant { i64, [11 x i8] } { i64 11, [11 x i8] c"request_key" }, align 8
@.str.39 = unnamed_addr constant { i64, [12 x i8] } { i64 12, [12 x i8] c"max_attempts" }, align 8
@.str.40 = unnamed_addr constant { i64, [15 x i8] } { i64 15, [15 x i8] c"backoff_base_ms" }, align 8
@.str.41 = unnamed_addr constant { i64, [14 x i8] } { i64 14, [14 x i8] c"backoff_max_ms" }, align 8
@.panic_msg.42 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.43 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.panic_msg.44 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.45 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.46 = unnamed_addr constant { i64, [51 x i8] } { i64 51, [51 x i8] c"encoded job exceeds the Jobs.enqueue_in input limit" }, align 8
@.panic_msg.47 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.48 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.49 = unnamed_addr constant { i64, [3 x i8] } { i64 3, [3 x i8] c"key" }, align 8
@.panic_msg.50 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.51 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.panic_msg.52 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.53 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.panic_msg.54 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.55 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.56 = unnamed_addr constant { i64, [2 x i8] } { i64 2, [2 x i8] c"id" }, align 8
@.panic_msg.57 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.58 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.panic_msg.59 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.60 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.61 = unnamed_addr constant { i64, [1 x i8] } { i64 1, [1 x i8] c"[" }, align 8
@.str.62 = unnamed_addr constant { i64, [1 x i8] } { i64 1, [1 x i8] c"," }, align 8
@.str.63 = unnamed_addr constant { i64, [1 x i8] } { i64 1, [1 x i8] c"]" }, align 8
@.panic_msg.64 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.65 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.panic_msg.66 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.67 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.panic_msg.68 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.69 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.70 = unnamed_addr constant { i64, [44 x i8] } { i64 44, [44 x i8] c"enqueue did not return one receipt per input" }, align 8
@.panic_msg.71 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.72 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.panic_msg.73 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.74 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.panic_msg.75 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.76 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.77 = unnamed_addr constant { i64, [40 x i8] } { i64 40, [40 x i8] c"SELECT pg_current_xact_id()::text AS xid" }, align 8
@.panic_msg.78 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.79 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.80 = unnamed_addr constant { i64, [3 x i8] } { i64 3, [3 x i8] c"xid" }, align 8
@.str.81 = unnamed_addr constant { i64, [14 x i8] } { i64 14, [14 x i8] c"notify_prepare" }, align 8
@.str.82 = unnamed_addr constant { i64, [13 x i8] } { i64 13, [13 x i8] c"notify_commit" }, align 8
@.str.83 = unnamed_addr constant { i64, [23 x i8] } { i64 23, [23 x i8] c"JOBS_PARITY_MESH_LISTEN" }, align 8
@.str.84 = unnamed_addr constant { i64, [1 x i8] } { i64 1, [1 x i8] c"0" }, align 8
@.str.85 = unnamed_addr constant { i64, [1 x i8] } { i64 1, [1 x i8] c"1" }, align 8
@.str.86 = unnamed_addr constant { i64, [40 x i8] } { i64 40, [40 x i8] c"SET LOCAL mesh_jobs.publish_wakeups = on" }, align 8
@.panic_msg.87 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.88 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.89 = unnamed_addr constant { i64, [41 x i8] } { i64 41, [41 x i8] c"SET LOCAL mesh_jobs.publish_wakeups = off" }, align 8
@.panic_msg.90 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.91 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.92 = unnamed_addr constant { i64, [122 x i8] } { i64 122, [122 x i8] c"INSERT INTO public.mesh_jobs_parity_product (engine, namespace, request_id) VALUES ('mesh', $1, $2) ON CONFLICT DO NOTHING" }, align 8
@.panic_msg.93 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.94 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.95 = unnamed_addr constant { i64, [15 x i8] } { i64 15, [15 x i8] c"producer_commit" }, align 8
@.str.96 = unnamed_addr constant { i64, [57 x i8] } { i64 57, [57 x i8] c"producer commit probe requires one nonempty enqueue batch" }, align 8
@.panic_msg.97 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.98 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.99 = unnamed_addr constant { i64, [59 x i8] } { i64 59, [59 x i8] c"producer commit probe input exceeds the enqueue batch limit" }, align 8
@.panic_msg.100 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.101 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.panic_msg.102 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.103 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.panic_msg.104 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.105 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.106 = unnamed_addr constant { i64, [5 x i8] } { i64 5, [5 x i8] c"count" }, align 8
@.str.107 = unnamed_addr constant { i64, [3 x i8] } { i64 3, [3 x i8] c"xid" }, align 8
@.str.108 = unnamed_addr constant { i64, [3 x i8] } { i64 3, [3 x i8] c"ids" }, align 8
@.str.109 = unnamed_addr constant { i64, [8 x i8] } { i64 8, [8 x i8] c"receipts" }, align 8
@.panic_msg.110 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.111 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.panic_msg.112 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.113 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.114 = unnamed_addr constant { i64, [5 x i8] } { i64 5, [5 x i8] c"count" }, align 8
@.str.115 = unnamed_addr constant { i64, [3 x i8] } { i64 3, [3 x i8] c"xid" }, align 8
@.str.116 = unnamed_addr constant { i64, [3 x i8] } { i64 3, [3 x i8] c"ids" }, align 8
@.str.117 = unnamed_addr constant { i64, [14 x i8] } { i64 14, [14 x i8] c"notify_prepare" }, align 8
@.str.118 = unnamed_addr constant { i64, [40 x i8] } { i64 40, [40 x i8] c"PREPARE TRANSACTION 'jobs_parity_notify'" }, align 8
@.str.119 = unnamed_addr constant { i64, [21 x i8] } { i64 21, [21 x i8] c"PREPARE TRANSACTION: " }, align 8
@.panic_msg.120 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.121 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.122 = unnamed_addr constant { i64, [13 x i8] } { i64 13, [13 x i8] c"notify_commit" }, align 8
@.str.123 = unnamed_addr constant { i64, [8 x i8] } { i64 8, [8 x i8] c"COMMIT: " }, align 8
@.panic_msg.124 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.125 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.126 = unnamed_addr constant { i64, [4 x i8] } { i64 4, [4 x i8] c"jobs" }, align 8
@.panic_msg.127 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.128 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.panic_msg.129 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.130 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.131 = unnamed_addr constant { i64, [10 x i8] } { i64 10, [10 x i8] c"request_id" }, align 8
@.panic_msg.132 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.133 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.panic_msg.134 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.135 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.136 = unnamed_addr constant { i64, [8 x i8] } { i64 8, [8 x i8] c"rollback" }, align 8
@.panic_msg.137 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.138 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.panic_msg.139 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.140 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.141 = unnamed_addr constant { i64, [16 x i8] } { i64 16, [16 x i8] c"JOBS_PARITY_MODE" }, align 8
@.str.142 = unnamed_addr constant { i64, [0 x i8] } zeroinitializer, align 8
@.panic_msg.143 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.144 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.panic_msg.145 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.146 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.panic_msg.147 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.148 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.panic_msg.149 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.150 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.151 = unnamed_addr constant { i64, [1 x i8] } { i64 1, [1 x i8] c"/" }, align 8
@.str.152 = unnamed_addr constant { i64, [42 x i8] } { i64 42, [42 x i8] c"JOBS_PARITY_INPUT must be an absolute path" }, align 8
@.panic_msg.153 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.154 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.panic_msg.155 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.156 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.panic_msg.157 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.158 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.panic_msg.159 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.160 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.161 = unnamed_addr constant { i64, [4 x i8] } { i64 4, [4 x i8] c"stop" }, align 8
@.str.162 = unnamed_addr constant { i64, [2 x i8] } { i64 2, [2 x i8] c"{}" }, align 8
@.panic_msg.163 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.164 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.165 = unnamed_addr constant { i64, [14 x i8] } { i64 14, [14 x i8] c"PRODUCER_READY" }, align 8
@.str.166 = unnamed_addr constant { i64, [18 x i8] } { i64 18, [18 x i8] c"proof hold elapsed" }, align 8
@.str.167 = unnamed_addr constant { i64, [7 x i8] } { i64 7, [7 x i8] c"applied" }, align 8
@.str.168 = unnamed_addr constant { i64, [5 x i8] } { i64 5, [5 x i8] c"prior" }, align 8
@.panic_msg.169 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.170 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.171 = unnamed_addr constant { i64, [21 x i8] } { i64 21, [21 x i8] c"{\22action\22:\22complete\22}" }, align 8
@.panic_msg.172 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.173 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.174 = unnamed_addr constant { i64, [4 x i8] } { i64 4, [4 x i8] c"args" }, align 8
@.panic_msg.175 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.176 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.177 = unnamed_addr constant { i64, [3 x i8] } { i64 3, [3 x i8] c"key" }, align 8
@.panic_msg.178 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.179 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.panic_msg.180 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.181 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.182 = unnamed_addr constant { i64, [7 x i8] } { i64 7, [7 x i8] c"attempt" }, align 8
@.panic_msg.183 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.184 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.panic_msg.185 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.186 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.187 = unnamed_addr constant { i64, [7 x i8] } { i64 7, [7 x i8] c"hold_ms" }, align 8
@.panic_msg.188 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.189 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.panic_msg.190 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.191 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.192 = unnamed_addr constant { i64, [10 x i8] } { i64 10, [10 x i8] c"fail_first" }, align 8
@.panic_msg.193 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.194 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.panic_msg.195 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.196 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.197 = unnamed_addr constant { i64, [10 x i8] } { i64 10, [10 x i8] c"LD_PRELOAD" }, align 8
@.str.198 = unnamed_addr constant { i64, [0 x i8] } zeroinitializer, align 8
@.str.199 = unnamed_addr constant { i64, [0 x i8] } zeroinitializer, align 8
@.str.200 = unnamed_addr constant { i64, [18 x i8] } { i64 18, [18 x i8] c"JOBS_PARITY_DB_URL" }, align 8
@.str.201 = unnamed_addr constant { i64, [0 x i8] } zeroinitializer, align 8
@.str.202 = unnamed_addr constant { i64, [0 x i8] } zeroinitializer, align 8
@.str.203 = unnamed_addr constant { i64, [19 x i8] } { i64 19, [19 x i8] c"MESH_EFFECT_APP_URL" }, align 8
@.str.204 = unnamed_addr constant { i64, [0 x i8] } zeroinitializer, align 8
@.str.205 = unnamed_addr constant { i64, [0 x i8] } zeroinitializer, align 8
@.str.206 = unnamed_addr constant { i64, [56 x i8] } { i64 56, [56 x i8] c"unexpected handler input or inherited runner environment" }, align 8
@.str.207 = unnamed_addr constant { i64, [10 x i8] } { i64 10, [10 x i8] c"proof_path" }, align 8
@.panic_msg.208 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.209 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.210 = unnamed_addr constant { i64, [0 x i8] } zeroinitializer, align 8
@.panic_msg.211 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.212 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.213 = unnamed_addr constant { i64, [0 x i8] } zeroinitializer, align 8
@.str.214 = unnamed_addr constant { i64, [0 x i8] } zeroinitializer, align 8
@.str.215 = unnamed_addr constant { i64, [1 x i8] } { i64 1, [1 x i8] c"/" }, align 8
@.str.216 = unnamed_addr constant { i64, [0 x i8] } zeroinitializer, align 8
@.str.217 = unnamed_addr constant { i64, [7 x i8] } { i64 7, [7 x i8] c"/worker" }, align 8
@.panic_msg.218 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.219 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.220 = unnamed_addr constant { i64, [5 x i8] } { i64 5, [5 x i8] c"/call" }, align 8
@.panic_msg.221 = local_unnamed_addr constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.222 = local_unnamed_addr constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.223 = unnamed_addr constant { i64, [4 x i8] } { i64 4, [4 x i8] c"true" }, align 8
@.str.224 = unnamed_addr constant { i64, [5 x i8] } { i64 5, [5 x i8] c"false" }, align 8
@.str.225 = unnamed_addr constant { i64, [1 x i8] } { i64 1, [1 x i8] c"[" }, align 8
@.str.226 = unnamed_addr constant { i64, [1 x i8] } { i64 1, [1 x i8] c"," }, align 8
@.str.227 = unnamed_addr constant { i64, [1 x i8] } { i64 1, [1 x i8] c"," }, align 8
@.str.228 = unnamed_addr constant { i64, [1 x i8] } { i64 1, [1 x i8] c"," }, align 8
@.str.229 = unnamed_addr constant { i64, [1 x i8] } { i64 1, [1 x i8] c"]" }, align 8
@.panic_msg.230 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.231 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.232 = unnamed_addr constant { i64, [8 x i8] } { i64 8, [8 x i8] c"/calling" }, align 8
@.panic_msg.233 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.234 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.235 = unnamed_addr constant { i64, [5 x i8] } { i64 5, [5 x i8] c"first" }, align 8
@.str.236 = unnamed_addr constant { i64, [6 x i8] } { i64 6, [6 x i8] c"/first" }, align 8
@.str.237 = unnamed_addr constant { i64, [7 x i8] } { i64 7, [7 x i8] c"outcome" }, align 8
@.str.238 = unnamed_addr constant { i64, [12 x i8] } { i64 12, [12 x i8] c"monotonic_ns" }, align 8
@.panic_msg.239 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.240 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.241 = unnamed_addr constant { i64, [34 x i8] } { i64 34, [34 x i8] c"Jobs effect outcome is unconfirmed" }, align 8
@.str.242 = unnamed_addr constant { i64, [7 x i8] } { i64 7, [7 x i8] c"/finish" }, align 8
@.panic_msg.243 = local_unnamed_addr constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.244 = local_unnamed_addr constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.245 = unnamed_addr constant { i64, [18 x i8] } { i64 18, [18 x i8] c"/returned-complete" }, align 8
@.panic_msg.246 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.247 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.248 = unnamed_addr constant { i64, [12 x i8] } { i64 12, [12 x i8] c"/second-call" }, align 8
@.panic_msg.249 = local_unnamed_addr constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.250 = local_unnamed_addr constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.251 = unnamed_addr constant { i64, [7 x i8] } { i64 7, [7 x i8] c"applied" }, align 8
@.str.252 = unnamed_addr constant { i64, [5 x i8] } { i64 5, [5 x i8] c"prior" }, align 8
@.str.253 = unnamed_addr constant { i64, [1 x i8] } { i64 1, [1 x i8] c"[" }, align 8
@.str.254 = unnamed_addr constant { i64, [1 x i8] } { i64 1, [1 x i8] c"," }, align 8
@.str.255 = unnamed_addr constant { i64, [1 x i8] } { i64 1, [1 x i8] c"]" }, align 8
@.panic_msg.256 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.257 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.258 = unnamed_addr constant { i64, [6 x i8] } { i64 6, [6 x i8] c"second" }, align 8
@.str.259 = unnamed_addr constant { i64, [7 x i8] } { i64 7, [7 x i8] c"applied" }, align 8
@.str.260 = unnamed_addr constant { i64, [5 x i8] } { i64 5, [5 x i8] c"prior" }, align 8
@.str.261 = unnamed_addr constant { i64, [7 x i8] } { i64 7, [7 x i8] c"/second" }, align 8
@.panic_msg.262 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.263 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.264 = unnamed_addr constant { i64, [7 x i8] } { i64 7, [7 x i8] c"/finish" }, align 8
@.panic_msg.265 = local_unnamed_addr constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.266 = local_unnamed_addr constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.267 = unnamed_addr constant { i64, [22 x i8] } { i64 22, [22 x i8] c"named effect handler: " }, align 8
@.str.268 = unnamed_addr constant { i64, [6 x i8] } { i64 6, [6 x i8] c"action" }, align 8
@.str.269 = unnamed_addr constant { i64, [4 x i8] } { i64 4, [4 x i8] c"fail" }, align 8
@.str.270 = unnamed_addr constant { i64, [6 x i8] } { i64 6, [6 x i8] c"reason" }, align 8
@.str.271 = unnamed_addr constant { i64, [27 x i8] } { i64 27, [27 x i8] c"named effect handler failed" }, align 8
@.panic_msg.272 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.273 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.panic_msg.274 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.275 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.276 = unnamed_addr constant { i64, [4 x i8] } { i64 4, [4 x i8] c"stop" }, align 8
@.str.277 = unnamed_addr constant { i64, [2 x i8] } { i64 2, [2 x i8] c"{}" }, align 8
@.panic_msg.278 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.279 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.280 = unnamed_addr constant { i64, [4 x i8] } { i64 4, [4 x i8] c"verb" }, align 8
@.panic_msg.281 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.282 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.panic_msg.283 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.284 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.285 = unnamed_addr constant { i64, [7 x i8] } { i64 7, [7 x i8] c"enqueue" }, align 8
@.str.286 = unnamed_addr constant { i64, [5 x i8] } { i64 5, [5 x i8] c"batch" }, align 8
@.panic_msg.287 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.288 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.panic_msg.289 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.290 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.291 = unnamed_addr constant { i64, [5 x i8] } { i64 5, [5 x i8] c"query" }, align 8
@.str.292 = unnamed_addr constant { i64, [3 x i8] } { i64 3, [3 x i8] c"sql" }, align 8
@.panic_msg.293 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.294 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.panic_msg.295 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.296 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.panic_msg.297 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.298 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.299 = unnamed_addr constant { i64, [32 x i8] } { i64 32, [32 x i8] c"observer SQL must return one row" }, align 8
@.str.300 = unnamed_addr constant { i64, [5 x i8] } { i64 5, [5 x i8] c"value" }, align 8
@.str.301 = unnamed_addr constant { i64, [24 x i8] } { i64 24, [24 x i8] c"unknown producer command" }, align 8
@.panic_msg.302 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.303 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.304 = unnamed_addr constant { i64, [13 x i8] } { i64 13, [13 x i8] c"SESSION_READY" }, align 8
@.str.305 = unnamed_addr constant { i64, [17 x i8] } { i64 17, [17 x i8] c"JOBS_PARITY_SLOTS" }, align 8
@.str.306 = unnamed_addr constant { i64, [19 x i8] } { i64 19, [19 x i8] c"JOBS_PARITY_POLL_MS" }, align 8
@.str.307 = unnamed_addr constant { i64, [18 x i8] } { i64 18, [18 x i8] c"JOBS_PARITY_RUNNER" }, align 8
@.str.308 = unnamed_addr constant { i64, [0 x i8] } zeroinitializer, align 8
@.str.309 = unnamed_addr constant { i64, [0 x i8] } zeroinitializer, align 8
@.str.310 = unnamed_addr constant { i64, [30 x i8] } { i64 30, [30 x i8] c"JOBS_PARITY_RUNNER is required" }, align 8
@.str.311 = unnamed_addr constant { i64, [16 x i8] } { i64 16, [16 x i8] c"JOBS_PARITY_MODE" }, align 8
@.str.312 = unnamed_addr constant { i64, [0 x i8] } zeroinitializer, align 8
@.str.313 = unnamed_addr constant { i64, [5 x i8] } { i64 5, [5 x i8] c"dense" }, align 8
@.str.314 = unnamed_addr constant { i64, [6 x i8] } { i64 6, [6 x i8] c"sparse" }, align 8
@.str.315 = unnamed_addr constant { i64, [5 x i8] } { i64 5, [5 x i8] c"fault" }, align 8
@.str.316 = unnamed_addr constant { i64, [13 x i8] } { i64 13, [13 x i8] c"final_attempt" }, align 8
@.str.317 = unnamed_addr constant { i64, [63 x i8] } { i64 63, [63 x i8] c"JOBS_PARITY_MODE must be dense, sparse, fault, or final_attempt" }, align 8
@.str.318 = unnamed_addr constant { i64, [33 x i8] } { i64 33, [33 x i8] c"[{\22worker\22:\22parity\22,\22version\22:1}]" }, align 8
@.panic_msg.319 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.320 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.321 = unnamed_addr constant { i64, [9 x i8] } { i64 9, [9 x i8] c"namespace" }, align 8
@.str.322 = unnamed_addr constant { i64, [6 x i8] } { i64 6, [6 x i8] c"queues" }, align 8
@.str.323 = unnamed_addr constant { i64, [7 x i8] } { i64 7, [7 x i8] c"default" }, align 8
@.str.324 = unnamed_addr constant { i64, [7 x i8] } { i64 7, [7 x i8] c"workers" }, align 8
@.str.325 = unnamed_addr constant { i64, [8 x i8] } { i64 8, [8 x i8] c"lease_ms" }, align 8
@.str.326 = unnamed_addr constant { i64, [7 x i8] } { i64 7, [7 x i8] c"poll_ms" }, align 8
@.str.327 = unnamed_addr constant { i64, [17 x i8] } { i64 17, [17 x i8] c"shutdown_grace_ms" }, align 8
@.str.328 = unnamed_addr constant { i64, [22 x i8] } { i64 22, [22 x i8] c"JOBS_PARITY_MESH_BATCH" }, align 8
@.str.329 = unnamed_addr constant { i64, [1 x i8] } { i64 1, [1 x i8] c"0" }, align 8
@.str.330 = unnamed_addr constant { i64, [1 x i8] } { i64 1, [1 x i8] c"1" }, align 8
@.str.331 = unnamed_addr constant { i64, [19 x i8] } { i64 19, [19 x i8] c",\22claim_batch\22:true" }, align 8
@.str.332 = unnamed_addr constant { i64, [0 x i8] } zeroinitializer, align 8
@.str.333 = unnamed_addr constant { i64, [23 x i8] } { i64 23, [23 x i8] c"JOBS_PARITY_MESH_LISTEN" }, align 8
@.str.334 = unnamed_addr constant { i64, [1 x i8] } { i64 1, [1 x i8] c"0" }, align 8
@.str.335 = unnamed_addr constant { i64, [1 x i8] } { i64 1, [1 x i8] c"1" }, align 8
@.str.336 = unnamed_addr constant { i64, [14 x i8] } { i64 14, [14 x i8] c",\22listen\22:true" }, align 8
@.str.337 = unnamed_addr constant { i64, [0 x i8] } zeroinitializer, align 8
@.str.338 = unnamed_addr constant { i64, [23 x i8] } { i64 23, [23 x i8] c"JOBS_PARITY_MESH_EVENTS" }, align 8
@.str.339 = unnamed_addr constant { i64, [0 x i8] } zeroinitializer, align 8
@.str.340 = unnamed_addr constant { i64, [6 x i8] } { i64 6, [6 x i8] c"logged" }, align 8
@.str.341 = unnamed_addr constant { i64, [17 x i8] } { i64 17, [17 x i8] c",\22event_log\22:true" }, align 8
@.str.342 = unnamed_addr constant { i64, [13 x i8] } { i64 13, [13 x i8] c"backpressured" }, align 8
@.str.343 = unnamed_addr constant { i64, [19 x i8] } { i64 19, [19 x i8] c",\22event_buffer\22:128" }, align 8
@.str.344 = unnamed_addr constant { i64, [0 x i8] } zeroinitializer, align 8
@.str.345 = unnamed_addr constant { i64, [1 x i8] } { i64 1, [1 x i8] c"}" }, align 8
@.str.346 = unnamed_addr constant { i64, [17 x i8] } { i64 17, [17 x i8] c"MESH_EFFECT_LANES" }, align 8
@.str.347 = unnamed_addr constant { i64, [22 x i8] } { i64 22, [22 x i8] c"JOBS_PARITY_MESH_BATCH" }, align 8
@.str.348 = unnamed_addr constant { i64, [0 x i8] } zeroinitializer, align 8
@.str.349 = unnamed_addr constant { i64, [1 x i8] } { i64 1, [1 x i8] c"1" }, align 8
@.str.350 = unnamed_addr constant { i64, [54 x i8] } { i64 54, [54 x i8] c"named effects require prewarmed lanes and batch claims" }, align 8
@.str.351 = unnamed_addr constant { i64, [19 x i8] } { i64 19, [19 x i8] c",\22effect_sessions\22:" }, align 8
@.str.352 = unnamed_addr constant { i64, [1 x i8] } { i64 1, [1 x i8] c"}" }, align 8
@.str.353 = unnamed_addr constant { i64, [159 x i8] } { i64 159, [159 x i8] c"[{\22name\22:\22first\22,\22routine\22:\22compiled_demo.first\22,\22args\22:[\22text\22,\22int\22,\22int\22,\22bool\22]},{\22name\22:\22second\22,\22routine\22:\22compiled_demo.second\22,\22args\22:[\22text\22,\22bool\22]}]" }, align 8
@.panic_msg.354 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.355 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.356 = unnamed_addr constant { i64, [19 x i8] } { i64 19, [19 x i8] c"MESH_EFFECT_APP_URL" }, align 8
@.str.357 = unnamed_addr constant { i64, [0 x i8] } zeroinitializer, align 8
@.panic_msg.358 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.359 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.360 = unnamed_addr constant { i64, [23 x i8] } { i64 23, [23 x i8] c"JOBS_PARITY_STATUS_PATH" }, align 8
@.str.361 = unnamed_addr constant { i64, [0 x i8] } zeroinitializer, align 8
@.str.362 = unnamed_addr constant { i64, [5 x i8] } { i64 5, [5 x i8] c"READY" }, align 8
@.str.363 = unnamed_addr constant { i64, [0 x i8] } zeroinitializer, align 8
@.str.364 = unnamed_addr constant { i64, [8 x i8] } { i64 8, [8 x i8] c".request" }, align 8
@.panic_msg.365 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.366 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.367 = unnamed_addr constant { i64, [8 x i8] } { i64 8, [8 x i8] c".request" }, align 8
@.str.368 = unnamed_addr constant { i64, [8 x i8] } { i64 8, [8 x i8] c".pending" }, align 8
@.panic_msg.369 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.370 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.371 = unnamed_addr constant { i64, [8 x i8] } { i64 8, [8 x i8] c".pending" }, align 8
@.panic_msg.372 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.373 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.374 = unnamed_addr constant { i64, [8 x i8] } { i64 8, [8 x i8] c".pending" }, align 8
@.panic_msg.375 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.376 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.panic_msg.377 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.378 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.379 = unnamed_addr constant { i64, [43 x i8] } { i64 43, [43 x i8] c"usage: jobs-parity-mesh migrate|enqueue|run" }, align 8
@.str.380 = unnamed_addr constant { i64, [7 x i8] } { i64 7, [7 x i8] c"migrate" }, align 8
@.str.381 = unnamed_addr constant { i64, [7 x i8] } { i64 7, [7 x i8] c"enqueue" }, align 8
@.str.382 = unnamed_addr constant { i64, [3 x i8] } { i64 3, [3 x i8] c"run" }, align 8
@.str.383 = unnamed_addr constant { i64, [7 x i8] } { i64 7, [7 x i8] c"session" }, align 8
@.str.384 = unnamed_addr constant { i64, [43 x i8] } { i64 43, [43 x i8] c"usage: jobs-parity-mesh migrate|enqueue|run" }, align 8
@.str.385 = unnamed_addr constant { i64, [22 x i8] } { i64 22, [22 x i8] c"^[a-z][a-z0-9_]{0,62}$" }, align 8
@.str.386 = unnamed_addr constant { i64, [53 x i8] } { i64 53, [53 x i8] c"JOBS_PARITY_NAMESPACE must match [a-z][a-z0-9_]{0,62}" }, align 8
@.str.387 = unnamed_addr constant { i64, [0 x i8] } zeroinitializer, align 8
@.str.388 = unnamed_addr constant { i64, [30 x i8] } { i64 30, [30 x i8] c"JOBS_PARITY_DB_URL is required" }, align 8
@.str.389 = unnamed_addr constant { i64, [7 x i8] } { i64 7, [7 x i8] c"session" }, align 8
@.str.390 = unnamed_addr constant { i64, [7 x i8] } { i64 7, [7 x i8] c"enqueue" }, align 8
@.str.391 = unnamed_addr constant { i64, [17 x i8] } { i64 17, [17 x i8] c"JOBS_PARITY_INPUT" }, align 8
@.str.392 = unnamed_addr constant { i64, [0 x i8] } zeroinitializer, align 8
@.str.393 = unnamed_addr constant { i64, [1 x i8] } { i64 1, [1 x i8] c"-" }, align 8
@.str.394 = unnamed_addr constant { i64, [20 x i8] } { i64 20, [20 x i8] c"JOBS_PARITY_POOL_URL" }, align 8
@.str.395 = unnamed_addr constant { i64, [0 x i8] } zeroinitializer, align 8
@.str.396 = unnamed_addr constant { i64, [3 x i8] } { i64 3, [3 x i8] c"run" }, align 8
@.str.397 = unnamed_addr constant { i64, [0 x i8] } zeroinitializer, align 8
@.panic_msg.398 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.399 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@.str.400 = unnamed_addr constant { i64, [7 x i8] } { i64 7, [7 x i8] c"migrate" }, align 8
@.str.401 = unnamed_addr constant { i64, [14 x i8] } { i64 14, [14 x i8] c"parity error: " }, align 8
@.panic_msg.402 = constant [30 x i8] c"non-exhaustive match in switch"
@.panic_file.403 = constant [82 x i8] c"/var/lib/durable-jobs-bench/native/builds/mesh-stock-3828f20d/mesh-source/main.mpl"
@fn_reg_Main__database_url = private unnamed_addr constant [19 x i8] c"Main__database_url\00", align 1
@fn_reg_Main__namespace = private unnamed_addr constant [16 x i8] c"Main__namespace\00", align 1
@fn_reg_Main__migrate = private unnamed_addr constant [14 x i8] c"Main__migrate\00", align 1
@fn_reg_Main__job_spec = private unnamed_addr constant [15 x i8] c"Main__job_spec\00", align 1
@fn_reg_Main__collect_specs = private unnamed_addr constant [20 x i8] c"Main__collect_specs\00", align 1
@fn_reg_Main__collect_ids = private unnamed_addr constant [18 x i8] c"Main__collect_ids\00", align 1
@fn_sig_Main__collect_ids = private unnamed_addr constant [6 x i8] zeroinitializer
@fn_reg_Main__enqueue_specs = private unnamed_addr constant [20 x i8] c"Main__enqueue_specs\00", align 1
@fn_reg_Main__enqueue_batches = private unnamed_addr constant [22 x i8] c"Main__enqueue_batches\00", align 1
@fn_reg_Main__transaction_id = private unnamed_addr constant [21 x i8] c"Main__transaction_id\00", align 1
@fn_reg_Main__write_batch = private unnamed_addr constant [18 x i8] c"Main__write_batch\00", align 1
@fn_sig_Main__write_batch = private unnamed_addr constant [5 x i8] zeroinitializer
@fn_reg_Main__finish_batch = private unnamed_addr constant [19 x i8] c"Main__finish_batch\00", align 1
@fn_sig_Main__finish_batch = private unnamed_addr constant [3 x i8] zeroinitializer
@fn_reg_Main__transact_batch = private unnamed_addr constant [21 x i8] c"Main__transact_batch\00", align 1
@fn_reg_Main__read_batch = private unnamed_addr constant [17 x i8] c"Main__read_batch\00", align 1
@fn_reg_Main__enqueue = private unnamed_addr constant [14 x i8] c"Main__enqueue\00", align 1
@fn_reg_Main__enqueue_paths = private unnamed_addr constant [20 x i8] c"Main__enqueue_paths\00", align 1
@fn_reg_Main__enqueue_stream = private unnamed_addr constant [21 x i8] c"Main__enqueue_stream\00", align 1
@fn_reg_Main__wait_mark = private unnamed_addr constant [16 x i8] c"Main__wait_mark\00", align 1
@fn_reg_Main__effect_result = private unnamed_addr constant [20 x i8] c"Main__effect_result\00", align 1
@fn_reg_Main__complete = private unnamed_addr constant [15 x i8] c"Main__complete\00", align 1
@fn_reg_Main__perform = private unnamed_addr constant [14 x i8] c"Main__perform\00", align 1
@fn_sig_Main__perform = private unnamed_addr constant [2 x i8] zeroinitializer
@fn_reg_Main__handle = private unnamed_addr constant [13 x i8] c"Main__handle\00", align 1
@fn_reg_Main__session_loop = private unnamed_addr constant [19 x i8] c"Main__session_loop\00", align 1
@fn_reg_Main__session = private unnamed_addr constant [14 x i8] c"Main__session\00", align 1
@fn_reg_Main__serve = private unnamed_addr constant [12 x i8] c"Main__serve\00", align 1
@fn_sig_Main__serve = private unnamed_addr constant [1 x i8] zeroinitializer
@fn_reg_Main__run = private unnamed_addr constant [10 x i8] c"Main__run\00", align 1
@fn_reg_mesh_main = private unnamed_addr constant [10 x i8] c"mesh_main\00", align 1
@jobs_handler_Main__handle = private unnamed_addr constant [30 x i8] c"e03da7787d8c4083:Main__handle\00", align 1

declare void @mesh_rt_init() local_unnamed_addr

declare void @mesh_rt_disable_core_dumps() local_unnamed_addr

declare void @mesh_run_main(ptr) local_unnamed_addr

declare ptr @mesh_gc_alloc_actor(i64, i64) local_unnamed_addr

declare ptr @mesh_string_concat(ptr, ptr) local_unnamed_addr

declare ptr @mesh_int_to_string(i64) local_unnamed_addr

declare void @mesh_println(ptr) local_unnamed_addr

declare void @mesh_rt_init_actor(i32) local_unnamed_addr

declare void @mesh_reduction_check() local_unnamed_addr

declare ptr @mesh_reduction_state_v1() local_unnamed_addr

declare void @mesh_rt_run_scheduler() local_unnamed_addr

declare i64 @mesh_string_length(ptr) local_unnamed_addr

declare ptr @mesh_string_slice(ptr, i64, i64) local_unnamed_addr

declare i8 @mesh_string_starts_with(ptr, ptr) local_unnamed_addr

declare i8 @mesh_string_eq(ptr, ptr) local_unnamed_addr

declare ptr @mesh_string_join(ptr, ptr) local_unnamed_addr

declare ptr @mesh_file_read(ptr) local_unnamed_addr

declare ptr @mesh_file_write(ptr, ptr) local_unnamed_addr

declare i8 @mesh_file_exists(ptr) local_unnamed_addr

declare ptr @mesh_file_rename(ptr, ptr) local_unnamed_addr

declare ptr @mesh_io_read_line() local_unnamed_addr

declare void @mesh_io_eprintln(ptr) local_unnamed_addr

declare ptr @mesh_env_args() local_unnamed_addr

declare ptr @mesh_env_get_with_default(ptr, ptr) local_unnamed_addr

declare i64 @mesh_env_get_int(ptr, i64) local_unnamed_addr

declare ptr @mesh_regex_from_literal(ptr, i64) local_unnamed_addr

declare i8 @mesh_regex_match(ptr, ptr) local_unnamed_addr

declare ptr @mesh_json_array_length(ptr) local_unnamed_addr

declare i64 @mesh_monotonic_now_nanos() local_unnamed_addr

declare ptr @mesh_list_new() local_unnamed_addr

declare ptr @mesh_list_append(ptr, i64) local_unnamed_addr

declare i64 @mesh_list_head(ptr) local_unnamed_addr

declare ptr @mesh_list_from_array(ptr, i64) local_unnamed_addr

declare ptr @mesh_map_new() local_unnamed_addr

declare ptr @mesh_map_tag_string(ptr) local_unnamed_addr

declare ptr @mesh_map_put(ptr, i64, i64) local_unnamed_addr

declare i64 @mesh_map_fetch(ptr, i64) local_unnamed_addr

declare ptr @mesh_json_parse(ptr) local_unnamed_addr

declare ptr @mesh_json_encode(ptr) local_unnamed_addr

declare ptr @mesh_json_from_int(i64) local_unnamed_addr

declare ptr @mesh_json_from_string(ptr)

declare ptr @mesh_json_object_new() local_unnamed_addr

declare ptr @mesh_json_object_put(ptr, ptr, ptr) local_unnamed_addr

declare ptr @mesh_json_object_get(ptr, ptr) local_unnamed_addr

declare ptr @mesh_json_array_get(ptr, i64) local_unnamed_addr

declare ptr @mesh_json_as_string(ptr) local_unnamed_addr

declare ptr @mesh_json_value_as_int(ptr) local_unnamed_addr

declare ptr @mesh_json_value_as_bool(ptr) local_unnamed_addr

declare ptr @mesh_json_from_map(ptr, ptr) local_unnamed_addr

declare ptr @mesh_pg_connect(ptr) local_unnamed_addr

declare void @mesh_pg_close(i64) local_unnamed_addr

declare ptr @mesh_pg_execute(i64, ptr, ptr) local_unnamed_addr

declare ptr @mesh_pg_query(i64, ptr, ptr) local_unnamed_addr

declare ptr @mesh_pg_begin(i64) local_unnamed_addr

declare ptr @mesh_pg_commit(i64) local_unnamed_addr

declare ptr @mesh_pg_rollback(i64) local_unnamed_addr

declare ptr @mesh_pool_open(ptr, i64, i64, i64) local_unnamed_addr

declare void @mesh_pool_close(i64) local_unnamed_addr

declare ptr @mesh_jobs_migrate(i64) local_unnamed_addr

declare ptr @mesh_jobs_enqueue_in(i64, ptr, ptr) local_unnamed_addr

declare ptr @mesh_jobs_control(i64, ptr, ptr) local_unnamed_addr

declare ptr @mesh_jobs_start_effects_v1(i64, ptr, ptr, ptr, ptr, ptr) local_unnamed_addr

declare ptr @mesh_jobs_effect_v1(ptr, ptr) local_unnamed_addr

declare ptr @mesh_jobs_stop(i64, i64) local_unnamed_addr

declare ptr @mesh_jobs_join(i64) local_unnamed_addr

declare ptr @mesh_jobs_status(i64) local_unnamed_addr

declare void @mesh_jobs_register_handler(ptr, i64, ptr) local_unnamed_addr

declare void @mesh_jobs_enter_worker(i32, ptr) local_unnamed_addr

declare void @mesh_timer_sleep(i64) local_unnamed_addr

; Function Attrs: noreturn
declare void @mesh_panic_at(ptr, i64, ptr, i64, i32, i32) local_unnamed_addr #0

declare void @mesh_register_function(ptr, i64, ptr, ptr, i64) local_unnamed_addr

declare void @mesh_process_install_shutdown_signals() local_unnamed_addr

declare i8 @mesh_process_shutdown_requested() local_unnamed_addr

; Function Attrs: noreturn
declare void @mesh_process_exit(i64) local_unnamed_addr #0

declare i64 @mesh_parity_realtime_us() local_unnamed_addr

declare i64 @mesh_parity_worker_pid() local_unnamed_addr

define ptr @Main__database_url() {
entry:
  %call = tail call ptr @mesh_env_get_with_default(ptr nonnull @.str, ptr nonnull @.str.1)
  ret ptr %call
}

define ptr @Main__namespace() {
entry:
  %call = tail call ptr @mesh_env_get_with_default(ptr nonnull @.str.2, ptr nonnull @.str.3)
  ret ptr %call
}

define { i8, ptr } @Main__migrate(i64 %0) {
entry:
  %call = tail call i64 @mesh_env_get_int(ptr nonnull @.str.4, i64 0)
  %1 = add i64 %call, -1025
  %or_result = icmp ult i64 %1, -1024
  br i1 %or_result, label %common.ret, label %else

common.ret:                                       ; preds = %entry, %case_Err, %case_Ok
  %common.ret.op = phi { i8, ptr } [ %ret_coerce_load, %case_Ok ], [ %variant_val13.fca.1.insert, %case_Err ], [ { i8 1, ptr @.str.5 }, %entry ]
  ret { i8, ptr } %common.ret.op

else:                                             ; preds = %entry
  %call5 = tail call ptr @mesh_jobs_migrate(i64 %0)
  %tag = load i8, ptr %call5, align 1
  switch i8 %tag, label %switch_default [
    i8 0, label %case_Ok
    i8 1, label %case_Err
  ]

switch_default:                                   ; preds = %else
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg, i64 30, ptr nonnull @.panic_file, i64 82, i32 16, i32 11)
  unreachable

case_Ok:                                          ; preds = %else
  %call.i = tail call ptr @mesh_env_get_with_default(ptr nonnull @.str.2, ptr nonnull @.str.3)
  tail call void @mesh_reduction_check()
  %call16 = tail call ptr @mesh_json_object_new()
  %call17 = tail call ptr @mesh_json_from_string(ptr nonnull @.str.7)
  %call18 = tail call ptr @mesh_json_object_put(ptr %call16, ptr nonnull @.str.6, ptr %call17)
  %call19 = tail call ptr @mesh_json_from_string(ptr nonnull @.str.9)
  %call20 = tail call ptr @mesh_json_object_put(ptr %call18, ptr nonnull @.str.8, ptr %call19)
  %call22 = tail call ptr @mesh_json_from_int(i64 %call)
  %call23 = tail call ptr @mesh_json_object_put(ptr %call20, ptr nonnull @.str.10, ptr %call22)
  %call24 = tail call ptr @mesh_json_encode(ptr %call23)
  %call25 = tail call ptr @mesh_jobs_control(i64 %0, ptr %call.i, ptr %call24)
  %ret_coerce_load = load { i8, ptr }, ptr %call25, align 8
  br label %common.ret

case_Err:                                         ; preds = %else
  %variant_field7 = getelementptr inbounds nuw i8, ptr %call5, i64 8
  %path_val8 = load ptr, ptr %variant_field7, align 8
  %variant_val13.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val8, 1
  br label %common.ret
}

define { i8, ptr } @Main__job_spec(ptr %0) {
entry:
  %call = tail call ptr @mesh_json_object_get(ptr %0, ptr nonnull @.str.11)
  %tag = load i8, ptr %call, align 1
  switch i8 %tag, label %switch_default [
    i8 0, label %case_Ok
    i8 1, label %case_Err
  ]

switch_default:                                   ; preds = %entry
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.12, i64 30, ptr nonnull @.panic_file.13, i64 82, i32 23, i32 28)
  unreachable

case_Ok:                                          ; preds = %entry
  %variant_field = getelementptr inbounds nuw i8, ptr %call, i64 8
  %path_val = load ptr, ptr %variant_field, align 8
  %call6 = tail call ptr @mesh_json_as_string(ptr %path_val)
  %tag9 = load i8, ptr %call6, align 1
  switch i8 %tag9, label %switch_default10 [
    i8 0, label %case_Ok11
    i8 1, label %case_Err12
  ]

common.ret:                                       ; preds = %case_Ok122, %else, %case_Err123, %case_Err105, %case_Err86, %case_Err68, %case_Err49, %case_Err31, %case_Err12, %case_Err
  %common.ret.op = phi { i8, ptr } [ %variant_val.fca.1.insert, %case_Err ], [ %variant_val22.fca.1.insert, %case_Err12 ], [ %variant_val41.fca.1.insert, %case_Err31 ], [ %variant_val59.fca.1.insert, %case_Err49 ], [ %variant_val78.fca.1.insert, %case_Err68 ], [ %variant_val96.fca.1.insert, %case_Err86 ], [ %variant_val115.fca.1.insert, %case_Err105 ], [ %variant_val134.fca.1.insert, %case_Err123 ], [ %variant_val167.fca.1.insert, %else ], [ { i8 1, ptr @.str.31 }, %case_Ok122 ]
  ret { i8, ptr } %common.ret.op

case_Err:                                         ; preds = %entry
  %variant_field3 = getelementptr inbounds nuw i8, ptr %call, i64 8
  %path_val4 = load ptr, ptr %variant_field3, align 8
  %variant_val.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val4, 1
  br label %common.ret

switch_default10:                                 ; preds = %case_Ok
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.14, i64 30, ptr nonnull @.panic_file.15, i64 82, i32 23, i32 13)
  unreachable

case_Ok11:                                        ; preds = %case_Ok
  %variant_field13 = getelementptr inbounds nuw i8, ptr %call6, i64 8
  %path_val14 = load ptr, ptr %variant_field13, align 8
  %call25 = tail call ptr @mesh_json_object_get(ptr %0, ptr nonnull @.str.16)
  %tag28 = load i8, ptr %call25, align 1
  switch i8 %tag28, label %switch_default29 [
    i8 0, label %case_Ok30
    i8 1, label %case_Err31
  ]

case_Err12:                                       ; preds = %case_Ok
  %variant_field16 = getelementptr inbounds nuw i8, ptr %call6, i64 8
  %path_val17 = load ptr, ptr %variant_field16, align 8
  %variant_val22.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val17, 1
  br label %common.ret

switch_default29:                                 ; preds = %case_Ok11
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.17, i64 30, ptr nonnull @.panic_file.18, i64 82, i32 24, i32 26)
  unreachable

case_Ok30:                                        ; preds = %case_Ok11
  %variant_field32 = getelementptr inbounds nuw i8, ptr %call25, i64 8
  %path_val33 = load ptr, ptr %variant_field32, align 8
  %call43 = tail call ptr @mesh_json_as_string(ptr %path_val33)
  %tag46 = load i8, ptr %call43, align 1
  switch i8 %tag46, label %switch_default47 [
    i8 0, label %case_Ok48
    i8 1, label %case_Err49
  ]

case_Err31:                                       ; preds = %case_Ok11
  %variant_field35 = getelementptr inbounds nuw i8, ptr %call25, i64 8
  %path_val36 = load ptr, ptr %variant_field35, align 8
  %variant_val41.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val36, 1
  br label %common.ret

switch_default47:                                 ; preds = %case_Ok30
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.19, i64 30, ptr nonnull @.panic_file.20, i64 82, i32 24, i32 11)
  unreachable

case_Ok48:                                        ; preds = %case_Ok30
  %call62 = tail call ptr @mesh_json_object_get(ptr %0, ptr nonnull @.str.21)
  %tag65 = load i8, ptr %call62, align 1
  switch i8 %tag65, label %switch_default66 [
    i8 0, label %case_Ok67
    i8 1, label %case_Err68
  ]

case_Err49:                                       ; preds = %case_Ok30
  %variant_field53 = getelementptr inbounds nuw i8, ptr %call43, i64 8
  %path_val54 = load ptr, ptr %variant_field53, align 8
  %variant_val59.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val54, 1
  br label %common.ret

switch_default66:                                 ; preds = %case_Ok48
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.22, i64 30, ptr nonnull @.panic_file.23, i64 82, i32 25, i32 26)
  unreachable

case_Ok67:                                        ; preds = %case_Ok48
  %variant_field69 = getelementptr inbounds nuw i8, ptr %call62, i64 8
  %path_val70 = load ptr, ptr %variant_field69, align 8
  %call80 = tail call ptr @mesh_json_value_as_int(ptr %path_val70)
  %tag83 = load i8, ptr %call80, align 1
  switch i8 %tag83, label %switch_default84 [
    i8 0, label %case_Ok85
    i8 1, label %case_Err86
  ]

case_Err68:                                       ; preds = %case_Ok48
  %variant_field72 = getelementptr inbounds nuw i8, ptr %call62, i64 8
  %path_val73 = load ptr, ptr %variant_field72, align 8
  %variant_val78.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val73, 1
  br label %common.ret

switch_default84:                                 ; preds = %case_Ok67
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.24, i64 30, ptr nonnull @.panic_file.25, i64 82, i32 25, i32 14)
  unreachable

case_Ok85:                                        ; preds = %case_Ok67
  %variant_field87 = getelementptr inbounds nuw i8, ptr %call80, i64 8
  %boxed_variant_payload = load ptr, ptr %variant_field87, align 8
  %path_val88 = load i64, ptr %boxed_variant_payload, align 8
  %call99 = tail call ptr @mesh_json_object_get(ptr %0, ptr nonnull @.str.26)
  %tag102 = load i8, ptr %call99, align 1
  switch i8 %tag102, label %switch_default103 [
    i8 0, label %case_Ok104
    i8 1, label %case_Err105
  ]

case_Err86:                                       ; preds = %case_Ok67
  %variant_field90 = getelementptr inbounds nuw i8, ptr %call80, i64 8
  %path_val91 = load ptr, ptr %variant_field90, align 8
  %variant_val96.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val91, 1
  br label %common.ret

switch_default103:                                ; preds = %case_Ok85
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.27, i64 30, ptr nonnull @.panic_file.28, i64 82, i32 26, i32 24)
  unreachable

case_Ok104:                                       ; preds = %case_Ok85
  %variant_field106 = getelementptr inbounds nuw i8, ptr %call99, i64 8
  %path_val107 = load ptr, ptr %variant_field106, align 8
  %call117 = tail call ptr @mesh_json_value_as_bool(ptr %path_val107)
  %tag120 = load i8, ptr %call117, align 1
  switch i8 %tag120, label %switch_default121 [
    i8 0, label %case_Ok122
    i8 1, label %case_Err123
  ]

case_Err105:                                      ; preds = %case_Ok85
  %variant_field109 = getelementptr inbounds nuw i8, ptr %call99, i64 8
  %path_val110 = load ptr, ptr %variant_field109, align 8
  %variant_val115.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val110, 1
  br label %common.ret

switch_default121:                                ; preds = %case_Ok104
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.29, i64 30, ptr nonnull @.panic_file.30, i64 82, i32 26, i32 11)
  unreachable

case_Ok122:                                       ; preds = %case_Ok104
  %cmp = icmp slt i64 %path_val88, 0
  br i1 %cmp, label %common.ret, label %else

case_Err123:                                      ; preds = %case_Ok104
  %variant_field128 = getelementptr inbounds nuw i8, ptr %call117, i64 8
  %path_val129 = load ptr, ptr %variant_field128, align 8
  %variant_val134.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val129, 1
  br label %common.ret

else:                                             ; preds = %case_Ok122
  %call142 = tail call ptr @mesh_env_get_with_default(ptr nonnull @.str.32, ptr nonnull @.str.33)
  %str_eq = tail call i8 @mesh_string_eq(ptr %call142, ptr nonnull @.str.34)
  %str_eq_bool.not = icmp eq i8 %str_eq, 0
  %. = select i1 %str_eq_bool.not, i64 3, i64 1
  %call150 = tail call ptr @mesh_json_object_new()
  %call151 = tail call ptr @mesh_json_from_string(ptr nonnull @.str.36)
  %call152 = tail call ptr @mesh_json_object_put(ptr %call150, ptr nonnull @.str.35, ptr %call151)
  %call154 = tail call ptr @mesh_json_object_put(ptr %call152, ptr nonnull @.str.37, ptr %0)
  %call156 = tail call ptr @mesh_json_from_string(ptr %path_val14)
  %call157 = tail call ptr @mesh_json_object_put(ptr %call154, ptr nonnull @.str.38, ptr %call156)
  %call159 = tail call ptr @mesh_json_from_int(i64 %.)
  %call160 = tail call ptr @mesh_json_object_put(ptr %call157, ptr nonnull @.str.39, ptr %call159)
  %call161 = tail call ptr @mesh_json_from_int(i64 1000)
  %call162 = tail call ptr @mesh_json_object_put(ptr %call160, ptr nonnull @.str.40, ptr %call161)
  %call163 = tail call ptr @mesh_json_from_int(i64 1000)
  %call164 = tail call ptr @mesh_json_object_put(ptr %call162, ptr nonnull @.str.41, ptr %call163)
  %call165 = tail call ptr @mesh_json_encode(ptr %call164)
  %variant_val167.fca.1.insert = insertvalue { i8, ptr } { i8 0, ptr poison }, ptr %call165, 1
  br label %common.ret
}

define { i8, ptr } @Main__collect_specs(ptr %0, i64 %1, i64 %2, ptr %3, i64 %4) {
entry:
  %reduction_state = tail call ptr @mesh_reduction_state_v1()
  %cmp29 = icmp eq i64 %1, %2
  br i1 %cmp29, label %then, label %else

common.ret:                                       ; preds = %then49, %case_Err20, %case_Err, %then
  %common.ret.op = phi { i8, ptr } [ %variant_val.fca.1.insert, %then ], [ %variant_val13.fca.1.insert, %case_Err ], [ %variant_val30.fca.1.insert, %case_Err20 ], [ %spec.select, %then49 ]
  ret { i8, ptr } %common.ret.op

then:                                             ; preds = %tce_loop.backedge, %entry
  %specs.0.lcssa = phi ptr [ %3, %entry ], [ %call74, %tce_loop.backedge ]
  %variant_val.fca.1.insert = insertvalue { i8, ptr } { i8 0, ptr poison }, ptr %specs.0.lcssa, 1
  br label %common.ret

else:                                             ; preds = %entry, %tce_loop.backedge
  %batch_bytes.032 = phi i64 [ %add45, %tce_loop.backedge ], [ %4, %entry ]
  %specs.031 = phi ptr [ %call74, %tce_loop.backedge ], [ %3, %entry ]
  %index.030 = phi i64 [ %add70, %tce_loop.backedge ], [ %1, %entry ]
  %call = tail call ptr @mesh_json_array_get(ptr %0, i64 %index.030)
  %tag = load i8, ptr %call, align 1
  switch i8 %tag, label %switch_default [
    i8 0, label %case_Ok
    i8 1, label %case_Err
  ]

switch_default:                                   ; preds = %else
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.42, i64 30, ptr nonnull @.panic_file.43, i64 82, i32 41, i32 23)
  unreachable

case_Ok:                                          ; preds = %else
  %variant_field = getelementptr inbounds nuw i8, ptr %call, i64 8
  %path_val = load ptr, ptr %variant_field, align 8
  %call14 = tail call { i8, ptr } @Main__job_spec(ptr %path_val)
  tail call void @mesh_reduction_check()
  %call14.fca.0.extract = extractvalue { i8, ptr } %call14, 0
  %call14.fca.1.extract = extractvalue { i8, ptr } %call14, 1
  switch i8 %call14.fca.0.extract, label %switch_default18 [
    i8 0, label %case_Ok19
    i8 1, label %case_Err20
  ]

case_Err:                                         ; preds = %else
  %variant_field7 = getelementptr inbounds nuw i8, ptr %call, i64 8
  %path_val8 = load ptr, ptr %variant_field7, align 8
  %variant_val13.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val8, 1
  br label %common.ret

switch_default18:                                 ; preds = %case_Ok
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.44, i64 30, ptr nonnull @.panic_file.45, i64 82, i32 41, i32 14)
  unreachable

case_Ok19:                                        ; preds = %case_Ok
  %str_len = load i64, ptr %call14.fca.1.extract, align 8
  %length.i = load i64, ptr %specs.031, align 8
  %cmp35 = icmp ne i64 %length.i, 0
  %. = zext i1 %cmp35 to i64
  %add = add i64 %str_len, %batch_bytes.032
  %add45 = add i64 %add, %.
  %cmp47 = icmp sgt i64 %add45, 1048576
  br i1 %cmp47, label %then49, label %else50

case_Err20:                                       ; preds = %case_Ok
  %variant_val30.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %call14.fca.1.extract, 1
  br label %common.ret

then49:                                           ; preds = %case_Ok19
  %variant_val66.fca.1.insert = insertvalue { i8, ptr } { i8 0, ptr poison }, ptr %specs.031, 1
  %spec.select = select i1 %cmp35, { i8, ptr } %variant_val66.fca.1.insert, { i8, ptr } { i8 1, ptr @.str.46 }
  br label %common.ret

else50:                                           ; preds = %case_Ok19
  %add70 = add i64 %index.030, 1
  %ret_coerce_ptrtoint = ptrtoint ptr %call14.fca.1.extract to i64
  %call74 = tail call ptr @mesh_list_append(ptr nonnull %specs.031, i64 %ret_coerce_ptrtoint)
  %reduction_remaining = load i32, ptr %reduction_state, align 4
  switch i32 %reduction_remaining, label %reduction_debit [
    i32 0, label %reduction_slow
    i32 -1, label %tce_loop.backedge
  ]

tce_loop.backedge:                                ; preds = %else50, %reduction_slow, %reduction_debit
  %cmp = icmp eq i64 %add70, %2
  br i1 %cmp, label %then, label %else

reduction_slow:                                   ; preds = %else50
  tail call void @mesh_reduction_check()
  br label %tce_loop.backedge

reduction_debit:                                  ; preds = %else50
  %reduction_next = add i32 %reduction_remaining, -1
  store i32 %reduction_next, ptr %reduction_state, align 4
  br label %tce_loop.backedge
}

define { i8, ptr } @Main__collect_ids(ptr %0, ptr %1, i64 %2, i64 %3, i64 %4, ptr %5) {
entry:
  %reduction_state = tail call ptr @mesh_reduction_state_v1()
  %cmp66 = icmp eq i64 %3, %4
  br i1 %cmp66, label %common.ret, label %else

common.ret.sink.split:                            ; preds = %case_Ok78, %case_Ok59, %case_Ok39, %case_Ok21, %case_Ok, %else
  %call91.lcssa151.sink = phi ptr [ %call, %else ], [ %call16, %case_Ok ], [ %call34, %case_Ok21 ], [ %call54, %case_Ok39 ], [ %call73, %case_Ok59 ], [ %call91, %case_Ok78 ]
  %variant_field101 = getelementptr inbounds nuw i8, ptr %call91.lcssa151.sink, i64 8
  %path_val102 = load ptr, ptr %variant_field101, align 8
  br label %common.ret

common.ret:                                       ; preds = %tce_loop.backedge, %common.ret.sink.split, %entry
  %.pn = phi { i8, ptr } [ { i8 0, ptr poison }, %entry ], [ { i8 1, ptr poison }, %common.ret.sink.split ], [ { i8 0, ptr poison }, %tce_loop.backedge ]
  %ids.0.pn = phi ptr [ %5, %entry ], [ %path_val102, %common.ret.sink.split ], [ %call120, %tce_loop.backedge ]
  %common.ret.op = insertvalue { i8, ptr } %.pn, ptr %ids.0.pn, 1
  ret { i8, ptr } %common.ret.op

else:                                             ; preds = %entry, %tce_loop.backedge
  %ids.068 = phi ptr [ %call120, %tce_loop.backedge ], [ %5, %entry ]
  %index.067 = phi i64 [ %add113, %tce_loop.backedge ], [ %3, %entry ]
  %add = add i64 %index.067, %2
  %call = tail call ptr @mesh_json_array_get(ptr %1, i64 %add)
  %tag = load i8, ptr %call, align 1
  switch i8 %tag, label %switch_default [
    i8 0, label %case_Ok
    i8 1, label %common.ret.sink.split
  ]

switch_default:                                   ; preds = %else
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.47, i64 30, ptr nonnull @.panic_file.48, i64 82, i32 59, i32 13)
  unreachable

case_Ok:                                          ; preds = %else
  %variant_field = getelementptr inbounds nuw i8, ptr %call, i64 8
  %path_val = load ptr, ptr %variant_field, align 8
  %call16 = tail call ptr @mesh_json_object_get(ptr %path_val, ptr nonnull @.str.49)
  %tag19 = load i8, ptr %call16, align 1
  switch i8 %tag19, label %switch_default20 [
    i8 0, label %case_Ok21
    i8 1, label %common.ret.sink.split
  ]

switch_default20:                                 ; preds = %case_Ok
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.50, i64 30, ptr nonnull @.panic_file.51, i64 82, i32 60, i32 28)
  unreachable

case_Ok21:                                        ; preds = %case_Ok
  %variant_field23 = getelementptr inbounds nuw i8, ptr %call16, i64 8
  %path_val24 = load ptr, ptr %variant_field23, align 8
  %call34 = tail call ptr @mesh_json_as_string(ptr %path_val24)
  %tag37 = load i8, ptr %call34, align 1
  switch i8 %tag37, label %switch_default38 [
    i8 0, label %case_Ok39
    i8 1, label %common.ret.sink.split
  ]

switch_default38:                                 ; preds = %case_Ok21
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.52, i64 30, ptr nonnull @.panic_file.53, i64 82, i32 60, i32 13)
  unreachable

case_Ok39:                                        ; preds = %case_Ok21
  %variant_field41 = getelementptr inbounds nuw i8, ptr %call34, i64 8
  %path_val42 = load ptr, ptr %variant_field41, align 8
  %call54 = tail call ptr @mesh_json_array_get(ptr %0, i64 %index.067)
  %tag57 = load i8, ptr %call54, align 1
  switch i8 %tag57, label %switch_default58 [
    i8 0, label %case_Ok59
    i8 1, label %common.ret.sink.split
  ]

switch_default58:                                 ; preds = %case_Ok39
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.54, i64 30, ptr nonnull @.panic_file.55, i64 82, i32 61, i32 17)
  unreachable

case_Ok59:                                        ; preds = %case_Ok39
  %variant_field61 = getelementptr inbounds nuw i8, ptr %call54, i64 8
  %path_val62 = load ptr, ptr %variant_field61, align 8
  %call73 = tail call ptr @mesh_json_object_get(ptr %path_val62, ptr nonnull @.str.56)
  %tag76 = load i8, ptr %call73, align 1
  switch i8 %tag76, label %switch_default77 [
    i8 0, label %case_Ok78
    i8 1, label %common.ret.sink.split
  ]

switch_default77:                                 ; preds = %case_Ok59
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.57, i64 30, ptr nonnull @.panic_file.58, i64 82, i32 62, i32 27)
  unreachable

case_Ok78:                                        ; preds = %case_Ok59
  %variant_field80 = getelementptr inbounds nuw i8, ptr %call73, i64 8
  %path_val81 = load ptr, ptr %variant_field80, align 8
  %call91 = tail call ptr @mesh_json_as_string(ptr %path_val81)
  %tag94 = load i8, ptr %call91, align 1
  switch i8 %tag94, label %switch_default95 [
    i8 0, label %case_Ok96
    i8 1, label %common.ret.sink.split
  ]

switch_default95:                                 ; preds = %case_Ok78
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.59, i64 30, ptr nonnull @.panic_file.60, i64 82, i32 62, i32 12)
  unreachable

case_Ok96:                                        ; preds = %case_Ok78
  %variant_field98 = getelementptr inbounds nuw i8, ptr %call91, i64 8
  %path_val99 = load ptr, ptr %variant_field98, align 8
  %add113 = add i64 %index.067, 1
  %call116 = tail call ptr @mesh_map_tag_string(ptr %ids.068)
  %ret_coerce_ptrtoint = ptrtoint ptr %path_val42 to i64
  %ret_coerce_ptrtoint119 = ptrtoint ptr %path_val99 to i64
  %call120 = tail call ptr @mesh_map_put(ptr %call116, i64 %ret_coerce_ptrtoint, i64 %ret_coerce_ptrtoint119)
  %reduction_remaining = load i32, ptr %reduction_state, align 4
  switch i32 %reduction_remaining, label %reduction_debit [
    i32 0, label %reduction_slow
    i32 -1, label %tce_loop.backedge
  ]

tce_loop.backedge:                                ; preds = %case_Ok96, %reduction_slow, %reduction_debit
  %cmp = icmp eq i64 %add113, %4
  br i1 %cmp, label %common.ret, label %else

reduction_slow:                                   ; preds = %case_Ok96
  tail call void @mesh_reduction_check()
  br label %tce_loop.backedge

reduction_debit:                                  ; preds = %case_Ok96
  %reduction_next = add i32 %reduction_remaining, -1
  store i32 %reduction_next, ptr %reduction_state, align 4
  br label %tce_loop.backedge
}

define { i8, ptr } @Main__enqueue_specs(i64 %0, ptr %1, i64 %2) {
entry:
  %call = tail call ptr @mesh_string_join(ptr %1, ptr nonnull @.str.62)
  %concat = tail call ptr @mesh_string_concat(ptr nonnull @.str.61, ptr %call)
  %concat2 = tail call ptr @mesh_string_concat(ptr %concat, ptr nonnull @.str.63)
  %call.i = tail call ptr @mesh_env_get_with_default(ptr nonnull @.str.2, ptr nonnull @.str.3)
  tail call void @mesh_reduction_check()
  %call6 = tail call ptr @mesh_jobs_enqueue_in(i64 %0, ptr %call.i, ptr %concat2)
  %tag = load i8, ptr %call6, align 1
  switch i8 %tag, label %switch_default [
    i8 0, label %case_Ok
    i8 1, label %case_Err
  ]

switch_default:                                   ; preds = %entry
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.64, i64 30, ptr nonnull @.panic_file.65, i64 82, i32 68, i32 29)
  unreachable

case_Ok:                                          ; preds = %entry
  %variant_field = getelementptr inbounds nuw i8, ptr %call6, i64 8
  %path_val = load ptr, ptr %variant_field, align 8
  %call11 = tail call ptr @mesh_json_parse(ptr %path_val)
  %tag14 = load i8, ptr %call11, align 1
  switch i8 %tag14, label %switch_default15 [
    i8 0, label %case_Ok16
    i8 1, label %case_Err17
  ]

common.ret:                                       ; preds = %case_Ok35, %case_Err36, %case_Err17, %case_Err
  %common.ret.op = phi { i8, ptr } [ %variant_val.fca.1.insert, %case_Err ], [ %variant_val27.fca.1.insert, %case_Err17 ], [ %variant_val46.fca.1.insert, %case_Err36 ], [ %spec.select, %case_Ok35 ]
  ret { i8, ptr } %common.ret.op

case_Err:                                         ; preds = %entry
  %variant_field8 = getelementptr inbounds nuw i8, ptr %call6, i64 8
  %path_val9 = load ptr, ptr %variant_field8, align 8
  %variant_val.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val9, 1
  br label %common.ret

switch_default15:                                 ; preds = %case_Ok
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.66, i64 30, ptr nonnull @.panic_file.67, i64 82, i32 68, i32 18)
  unreachable

case_Ok16:                                        ; preds = %case_Ok
  %variant_field18 = getelementptr inbounds nuw i8, ptr %call11, i64 8
  %path_val19 = load ptr, ptr %variant_field18, align 8
  %call30 = tail call ptr @mesh_json_array_length(ptr %path_val19)
  %tag33 = load i8, ptr %call30, align 1
  switch i8 %tag33, label %switch_default34 [
    i8 0, label %case_Ok35
    i8 1, label %case_Err36
  ]

case_Err17:                                       ; preds = %case_Ok
  %variant_field21 = getelementptr inbounds nuw i8, ptr %call11, i64 8
  %path_val22 = load ptr, ptr %variant_field21, align 8
  %variant_val27.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val22, 1
  br label %common.ret

switch_default34:                                 ; preds = %case_Ok16
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.68, i64 30, ptr nonnull @.panic_file.69, i64 82, i32 69, i32 6)
  unreachable

case_Ok35:                                        ; preds = %case_Ok16
  %variant_field37 = getelementptr inbounds nuw i8, ptr %call30, i64 8
  %boxed_variant_payload = load ptr, ptr %variant_field37, align 8
  %path_val38 = load i64, ptr %boxed_variant_payload, align 8
  %cmp.not = icmp eq i64 %path_val38, %2
  %variant_val57.fca.1.insert = insertvalue { i8, ptr } { i8 0, ptr poison }, ptr %path_val19, 1
  %spec.select = select i1 %cmp.not, { i8, ptr } %variant_val57.fca.1.insert, { i8, ptr } { i8 1, ptr @.str.70 }
  br label %common.ret

case_Err36:                                       ; preds = %case_Ok16
  %variant_field40 = getelementptr inbounds nuw i8, ptr %call30, i64 8
  %path_val41 = load ptr, ptr %variant_field40, align 8
  %variant_val46.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val41, 1
  br label %common.ret
}

define { i8, ptr } @Main__enqueue_batches(i64 %0, ptr %1, i64 %2, i64 %3, ptr %4) {
entry:
  %reduction_state = tail call ptr @mesh_reduction_state_v1()
  %cmp29 = icmp slt i64 %2, %3
  br i1 %cmp29, label %then, label %common.ret

then:                                             ; preds = %entry, %tce_loop.backedge
  %ids.031 = phi ptr [ %call49.fca.1.extract, %tce_loop.backedge ], [ %4, %entry ]
  %index.030 = phi i64 [ %add73, %tce_loop.backedge ], [ %2, %entry ]
  %sub = sub i64 %3, %index.030
  %cmp5 = icmp sgt i64 %sub, 128
  %add = add i64 %index.030, 128
  %.0 = select i1 %cmp5, i64 %add, i64 %3
  %call = tail call ptr @mesh_list_new()
  %call15 = tail call { i8, ptr } @Main__collect_specs(ptr %1, i64 %index.030, i64 %.0, ptr %call, i64 2)
  tail call void @mesh_reduction_check()
  %call15.fca.0.extract = extractvalue { i8, ptr } %call15, 0
  %call15.fca.1.extract = extractvalue { i8, ptr } %call15, 1
  switch i8 %call15.fca.0.extract, label %switch_default [
    i8 0, label %case_Ok
    i8 1, label %common.ret
  ]

common.ret:                                       ; preds = %tce_loop.backedge, %then, %case_Ok, %case_Ok31, %entry
  %.pn = phi { i8, ptr } [ { i8 0, ptr poison }, %entry ], [ { i8 1, ptr poison }, %case_Ok31 ], [ { i8 1, ptr poison }, %case_Ok ], [ { i8 1, ptr poison }, %then ], [ { i8 0, ptr poison }, %tce_loop.backedge ]
  %ids.0.pn = phi ptr [ %4, %entry ], [ %call49.fca.1.extract, %case_Ok31 ], [ %call25.fca.1.extract, %case_Ok ], [ %call15.fca.1.extract, %then ], [ %call49.fca.1.extract, %tce_loop.backedge ]
  %common.ret.op = insertvalue { i8, ptr } %.pn, ptr %ids.0.pn, 1
  ret { i8, ptr } %common.ret.op

switch_default:                                   ; preds = %then
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.71, i64 30, ptr nonnull @.panic_file.72, i64 82, i32 78, i32 17)
  unreachable

case_Ok:                                          ; preds = %then
  %length.i = load i64, ptr %call15.fca.1.extract, align 8
  %call25 = tail call { i8, ptr } @Main__enqueue_specs(i64 %0, ptr nonnull %call15.fca.1.extract, i64 %length.i)
  tail call void @mesh_reduction_check()
  %call25.fca.0.extract = extractvalue { i8, ptr } %call25, 0
  %call25.fca.1.extract = extractvalue { i8, ptr } %call25, 1
  switch i8 %call25.fca.0.extract, label %switch_default30 [
    i8 0, label %case_Ok31
    i8 1, label %common.ret
  ]

switch_default30:                                 ; preds = %case_Ok
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.73, i64 30, ptr nonnull @.panic_file.74, i64 82, i32 80, i32 20)
  unreachable

case_Ok31:                                        ; preds = %case_Ok
  %call49 = tail call { i8, ptr } @Main__collect_ids(ptr %call25.fca.1.extract, ptr %1, i64 %index.030, i64 0, i64 %length.i, ptr %ids.031)
  tail call void @mesh_reduction_check()
  %call49.fca.0.extract = extractvalue { i8, ptr } %call49, 0
  %call49.fca.1.extract = extractvalue { i8, ptr } %call49, 1
  switch i8 %call49.fca.0.extract, label %switch_default54 [
    i8 0, label %case_Ok55
    i8 1, label %common.ret
  ]

switch_default54:                                 ; preds = %case_Ok31
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.75, i64 30, ptr nonnull @.panic_file.76, i64 82, i32 81, i32 15)
  unreachable

case_Ok55:                                        ; preds = %case_Ok31
  %add73 = add i64 %length.i, %index.030
  %reduction_remaining = load i32, ptr %reduction_state, align 4
  switch i32 %reduction_remaining, label %reduction_debit [
    i32 0, label %reduction_slow
    i32 -1, label %tce_loop.backedge
  ]

tce_loop.backedge:                                ; preds = %case_Ok55, %reduction_slow, %reduction_debit
  %cmp = icmp slt i64 %add73, %3
  br i1 %cmp, label %then, label %common.ret

reduction_slow:                                   ; preds = %case_Ok55
  tail call void @mesh_reduction_check()
  br label %tce_loop.backedge

reduction_debit:                                  ; preds = %case_Ok55
  %reduction_next = add i32 %reduction_remaining, -1
  store i32 %reduction_next, ptr %reduction_state, align 4
  br label %tce_loop.backedge
}

define { i8, ptr } @Main__transaction_id(i64 %0) {
entry:
  %call = tail call ptr @mesh_list_new()
  %call2 = tail call ptr @mesh_pg_query(i64 %0, ptr nonnull @.str.77, ptr %call)
  %tag = load i8, ptr %call2, align 1
  switch i8 %tag, label %switch_default [
    i8 0, label %case_Ok
    i8 1, label %case_Err
  ]

common.ret:                                       ; preds = %case_Err, %case_Ok
  %.pn = phi { i8, ptr } [ { i8 0, ptr poison }, %case_Ok ], [ { i8 1, ptr poison }, %case_Err ]
  %i64_to_ptr13.pn = phi ptr [ %i64_to_ptr13, %case_Ok ], [ %path_val5, %case_Err ]
  %common.ret.op = insertvalue { i8, ptr } %.pn, ptr %i64_to_ptr13.pn, 1
  ret { i8, ptr } %common.ret.op

switch_default:                                   ; preds = %entry
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.78, i64 30, ptr nonnull @.panic_file.79, i64 82, i32 89, i32 14)
  unreachable

case_Ok:                                          ; preds = %entry
  %variant_field = getelementptr inbounds nuw i8, ptr %call2, i64 8
  %path_val = load ptr, ptr %variant_field, align 8
  %call10 = tail call i64 @mesh_list_head(ptr %path_val)
  %i64_to_ptr = inttoptr i64 %call10 to ptr
  %call11 = tail call ptr @mesh_map_tag_string(ptr %i64_to_ptr)
  %call12 = tail call i64 @mesh_map_fetch(ptr %call11, i64 ptrtoint (ptr @.str.80 to i64))
  %i64_to_ptr13 = inttoptr i64 %call12 to ptr
  br label %common.ret

case_Err:                                         ; preds = %entry
  %variant_field4 = getelementptr inbounds nuw i8, ptr %call2, i64 8
  %path_val5 = load ptr, ptr %variant_field4, align 8
  br label %common.ret
}

define { i8, ptr } @Main__write_batch(i64 %0, ptr %1, i64 %2, ptr %3, ptr %4) {
entry:
  %5 = alloca [2 x i64], align 8
  %str_eq = tail call i8 @mesh_string_eq(ptr %4, ptr nonnull @.str.81)
  %str_eq_bool.not = icmp eq i8 %str_eq, 0
  br i1 %str_eq_bool.not, label %or_rhs, label %or_merge

or_rhs:                                           ; preds = %entry
  %str_eq3 = tail call i8 @mesh_string_eq(ptr %4, ptr nonnull @.str.82)
  %str_eq_bool4 = icmp ne i8 %str_eq3, 0
  br label %or_merge

or_merge:                                         ; preds = %or_rhs, %entry
  %or_result = phi i1 [ true, %entry ], [ %str_eq_bool4, %or_rhs ]
  %call = tail call ptr @mesh_env_get_with_default(ptr nonnull @.str.83, ptr nonnull @.str.84)
  %str_eq5 = tail call i8 @mesh_string_eq(ptr %call, ptr nonnull @.str.85)
  %str_eq_bool6.not = icmp eq i8 %str_eq5, 0
  br i1 %str_eq_bool6.not, label %else, label %then

then:                                             ; preds = %or_merge
  %call8 = tail call ptr @mesh_list_new()
  %call9 = tail call ptr @mesh_pg_execute(i64 %0, ptr nonnull @.str.86, ptr %call8)
  %tag = load i8, ptr %call9, align 1
  switch i8 %tag, label %switch_default [
    i8 0, label %if_merge
    i8 1, label %case_Err
  ]

else:                                             ; preds = %or_merge
  br i1 %or_result, label %then16, label %if_merge

if_merge:                                         ; preds = %then16, %else, %then
  %call.i = tail call ptr @mesh_env_get_with_default(ptr nonnull @.str.2, ptr nonnull @.str.3)
  tail call void @mesh_reduction_check()
  %ptr_to_i64 = ptrtoint ptr %call.i to i64
  store i64 %ptr_to_i64, ptr %5, align 8
  %ptr_to_i6445 = ptrtoint ptr %3 to i64
  %elem_ptr46 = getelementptr inbounds nuw i8, ptr %5, i64 8
  store i64 %ptr_to_i6445, ptr %elem_ptr46, align 8
  %list = call ptr @mesh_list_from_array(ptr nonnull %5, i64 2)
  %call47 = call ptr @mesh_pg_execute(i64 %0, ptr nonnull @.str.92, ptr %list)
  %tag50 = load i8, ptr %call47, align 1
  switch i8 %tag50, label %switch_default51 [
    i8 0, label %case_Ok52
    i8 1, label %case_Err53
  ]

switch_default:                                   ; preds = %then
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.87, i64 30, ptr nonnull @.panic_file.88, i64 82, i32 96, i32 13)
  unreachable

common.ret:                                       ; preds = %case_Ok101, %then75, %case_Err242, %case_Ok241, %case_Err221, %case_Err180, %case_Ok179, %case_Err160, %case_Err137, %case_Err102, %case_Err53, %case_Err27, %case_Err
  %common.ret.op = phi { i8, ptr } [ %variant_val.fca.1.insert, %case_Err ], [ %variant_val38.fca.1.insert, %case_Err27 ], [ %variant_val64.fca.1.insert, %case_Err53 ], [ %variant_val112.fca.1.insert, %case_Err102 ], [ %variant_val147.fca.1.insert, %case_Err137 ], [ %variant_val170.fca.1.insert, %case_Err160 ], [ %variant_val208.fca.1.insert, %case_Ok179 ], [ %variant_val190.fca.1.insert, %case_Err180 ], [ %variant_val231.fca.1.insert, %case_Err221 ], [ %variant_val269.fca.1.insert, %case_Ok241 ], [ %variant_val252.fca.1.insert, %case_Err242 ], [ { i8 1, ptr @.str.96 }, %then75 ], [ { i8 1, ptr @.str.99 }, %case_Ok101 ]
  ret { i8, ptr } %common.ret.op

case_Err:                                         ; preds = %then
  %variant_field11 = getelementptr inbounds nuw i8, ptr %call9, i64 8
  %path_val12 = load ptr, ptr %variant_field11, align 8
  %variant_val.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val12, 1
  br label %common.ret

then16:                                           ; preds = %else
  %call20 = tail call ptr @mesh_list_new()
  %call21 = tail call ptr @mesh_pg_execute(i64 %0, ptr nonnull @.str.89, ptr %call20)
  %tag24 = load i8, ptr %call21, align 1
  switch i8 %tag24, label %switch_default25 [
    i8 0, label %if_merge
    i8 1, label %case_Err27
  ]

switch_default25:                                 ; preds = %then16
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.90, i64 30, ptr nonnull @.panic_file.91, i64 82, i32 99, i32 13)
  unreachable

case_Err27:                                       ; preds = %then16
  %variant_field32 = getelementptr inbounds nuw i8, ptr %call21, i64 8
  %path_val33 = load ptr, ptr %variant_field32, align 8
  %variant_val38.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val33, 1
  br label %common.ret

switch_default51:                                 ; preds = %if_merge
  call void @mesh_panic_at(ptr nonnull @.panic_msg.93, i64 30, ptr nonnull @.panic_file.94, i64 82, i32 102, i32 11)
  unreachable

case_Ok52:                                        ; preds = %if_merge
  %str_eq68 = call i8 @mesh_string_eq(ptr %4, ptr nonnull @.str.95)
  %str_eq_bool69 = icmp ne i8 %str_eq68, 0
  %spec.select = select i1 %str_eq_bool69, i1 true, i1 %or_result
  br i1 %spec.select, label %then75, label %else76

case_Err53:                                       ; preds = %if_merge
  %variant_field58 = getelementptr inbounds nuw i8, ptr %call47, i64 8
  %path_val59 = load ptr, ptr %variant_field58, align 8
  %variant_val64.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val59, 1
  br label %common.ret

then75:                                           ; preds = %case_Ok52
  %6 = add i64 %2, -129
  %or_result83 = icmp ult i64 %6, -128
  br i1 %or_result83, label %common.ret, label %else86

else76:                                           ; preds = %case_Ok52
  %call213 = call ptr @mesh_map_new()
  %call214 = call { i8, ptr } @Main__enqueue_batches(i64 %0, ptr %1, i64 0, i64 %2, ptr %call213)
  call void @mesh_reduction_check()
  %call214.fca.0.extract = extractvalue { i8, ptr } %call214, 0
  %call214.fca.1.extract = extractvalue { i8, ptr } %call214, 1
  switch i8 %call214.fca.0.extract, label %switch_default219 [
    i8 0, label %case_Ok220
    i8 1, label %case_Err221
  ]

else86:                                           ; preds = %then75
  %call95 = call ptr @mesh_list_new()
  %call96 = call { i8, ptr } @Main__collect_specs(ptr %1, i64 0, i64 %2, ptr %call95, i64 2)
  call void @mesh_reduction_check()
  %call96.fca.0.extract = extractvalue { i8, ptr } %call96, 0
  %call96.fca.1.extract = extractvalue { i8, ptr } %call96, 1
  switch i8 %call96.fca.0.extract, label %switch_default100 [
    i8 0, label %case_Ok101
    i8 1, label %case_Err102
  ]

switch_default100:                                ; preds = %else86
  call void @mesh_panic_at(ptr nonnull @.panic_msg.97, i64 30, ptr nonnull @.panic_file.98, i64 82, i32 109, i32 17)
  unreachable

case_Ok101:                                       ; preds = %else86
  %length.i = load i64, ptr %call96.fca.1.extract, align 8
  %cmp117.not = icmp eq i64 %length.i, %2
  br i1 %cmp117.not, label %else120, label %common.ret

case_Err102:                                      ; preds = %else86
  %variant_val112.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %call96.fca.1.extract, 1
  br label %common.ret

else120:                                          ; preds = %case_Ok101
  %call130 = call { i8, ptr } @Main__enqueue_specs(i64 %0, ptr nonnull %call96.fca.1.extract, i64 %2)
  call void @mesh_reduction_check()
  %call130.fca.0.extract = extractvalue { i8, ptr } %call130, 0
  %call130.fca.1.extract = extractvalue { i8, ptr } %call130, 1
  switch i8 %call130.fca.0.extract, label %switch_default135 [
    i8 0, label %case_Ok136
    i8 1, label %case_Err137
  ]

switch_default135:                                ; preds = %else120
  call void @mesh_panic_at(ptr nonnull @.panic_msg.100, i64 30, ptr nonnull @.panic_file.101, i64 82, i32 113, i32 20)
  unreachable

case_Ok136:                                       ; preds = %else120
  %call152 = call ptr @mesh_map_new()
  %call153 = call { i8, ptr } @Main__collect_ids(ptr %call130.fca.1.extract, ptr %1, i64 0, i64 0, i64 %2, ptr %call152)
  call void @mesh_reduction_check()
  %call153.fca.0.extract = extractvalue { i8, ptr } %call153, 0
  %call153.fca.1.extract = extractvalue { i8, ptr } %call153, 1
  switch i8 %call153.fca.0.extract, label %switch_default158 [
    i8 0, label %case_Ok159
    i8 1, label %case_Err160
  ]

case_Err137:                                      ; preds = %else120
  %variant_val147.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %call130.fca.1.extract, 1
  br label %common.ret

switch_default158:                                ; preds = %case_Ok136
  call void @mesh_panic_at(ptr nonnull @.panic_msg.102, i64 30, ptr nonnull @.panic_file.103, i64 82, i32 114, i32 15)
  unreachable

case_Ok159:                                       ; preds = %case_Ok136
  %call173 = call { i8, ptr } @Main__transaction_id(i64 %0)
  call void @mesh_reduction_check()
  %call173.fca.0.extract = extractvalue { i8, ptr } %call173, 0
  %call173.fca.1.extract = extractvalue { i8, ptr } %call173, 1
  switch i8 %call173.fca.0.extract, label %switch_default178 [
    i8 0, label %case_Ok179
    i8 1, label %case_Err180
  ]

case_Err160:                                      ; preds = %case_Ok136
  %variant_val170.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %call153.fca.1.extract, 1
  br label %common.ret

switch_default178:                                ; preds = %case_Ok159
  call void @mesh_panic_at(ptr nonnull @.panic_msg.104, i64 30, ptr nonnull @.panic_file.105, i64 82, i32 115, i32 15)
  unreachable

case_Ok179:                                       ; preds = %case_Ok159
  %call194 = call ptr @mesh_json_object_new()
  %call196 = call ptr @mesh_json_from_int(i64 %2)
  %call197 = call ptr @mesh_json_object_put(ptr %call194, ptr nonnull @.str.106, ptr %call196)
  %call199 = call ptr @mesh_json_from_string(ptr %call173.fca.1.extract)
  %call200 = call ptr @mesh_json_object_put(ptr %call197, ptr nonnull @.str.107, ptr %call199)
  %call202 = call ptr @mesh_json_from_map(ptr %call153.fca.1.extract, ptr nonnull @mesh_json_from_string)
  %call203 = call ptr @mesh_json_object_put(ptr %call200, ptr nonnull @.str.108, ptr %call202)
  %call205 = call ptr @mesh_json_object_put(ptr %call203, ptr nonnull @.str.109, ptr %call130.fca.1.extract)
  %call206 = call ptr @mesh_json_encode(ptr %call205)
  %variant_val208.fca.1.insert = insertvalue { i8, ptr } { i8 0, ptr poison }, ptr %call206, 1
  br label %common.ret

case_Err180:                                      ; preds = %case_Ok159
  %variant_val190.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %call173.fca.1.extract, 1
  br label %common.ret

switch_default219:                                ; preds = %else76
  call void @mesh_panic_at(ptr nonnull @.panic_msg.110, i64 30, ptr nonnull @.panic_file.111, i64 82, i32 118, i32 13)
  unreachable

case_Ok220:                                       ; preds = %else76
  %call235 = call { i8, ptr } @Main__transaction_id(i64 %0)
  call void @mesh_reduction_check()
  %call235.fca.0.extract = extractvalue { i8, ptr } %call235, 0
  %call235.fca.1.extract = extractvalue { i8, ptr } %call235, 1
  switch i8 %call235.fca.0.extract, label %switch_default240 [
    i8 0, label %case_Ok241
    i8 1, label %case_Err242
  ]

case_Err221:                                      ; preds = %else76
  %variant_val231.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %call214.fca.1.extract, 1
  br label %common.ret

switch_default240:                                ; preds = %case_Ok220
  call void @mesh_panic_at(ptr nonnull @.panic_msg.112, i64 30, ptr nonnull @.panic_file.113, i64 82, i32 119, i32 13)
  unreachable

case_Ok241:                                       ; preds = %case_Ok220
  %call257 = call ptr @mesh_json_object_new()
  %call259 = call ptr @mesh_json_from_int(i64 %2)
  %call260 = call ptr @mesh_json_object_put(ptr %call257, ptr nonnull @.str.114, ptr %call259)
  %call262 = call ptr @mesh_json_from_string(ptr %call235.fca.1.extract)
  %call263 = call ptr @mesh_json_object_put(ptr %call260, ptr nonnull @.str.115, ptr %call262)
  %call265 = call ptr @mesh_json_from_map(ptr %call214.fca.1.extract, ptr nonnull @mesh_json_from_string)
  %call266 = call ptr @mesh_json_object_put(ptr %call263, ptr nonnull @.str.116, ptr %call265)
  %call267 = call ptr @mesh_json_encode(ptr %call266)
  %variant_val269.fca.1.insert = insertvalue { i8, ptr } { i8 0, ptr poison }, ptr %call267, 1
  br label %common.ret

case_Err242:                                      ; preds = %case_Ok220
  %variant_val252.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %call235.fca.1.extract, 1
  br label %common.ret
}

define { i8, ptr } @Main__finish_batch(i64 %0, i1 %1, ptr %2) {
entry:
  br i1 %1, label %then, label %else

common.ret:                                       ; preds = %case_Err, %case_Ok, %else21, %case_Err30, %case_Ok29, %then
  %common.ret.op = phi { i8, ptr } [ %ret_coerce_load, %then ], [ %4, %case_Err ], [ %3, %case_Ok ], [ %ret_coerce_load48, %else21 ], [ %6, %case_Err30 ], [ %5, %case_Ok29 ]
  ret { i8, ptr } %common.ret.op

then:                                             ; preds = %entry
  %call = tail call ptr @mesh_pg_rollback(i64 %0)
  %ret_coerce_load = load { i8, ptr }, ptr %call, align 8
  br label %common.ret

else:                                             ; preds = %entry
  %str_eq = tail call i8 @mesh_string_eq(ptr %2, ptr nonnull @.str.117)
  %str_eq_bool.not = icmp eq i8 %str_eq, 0
  br i1 %str_eq_bool.not, label %else6, label %then5

then5:                                            ; preds = %else
  %call9 = tail call ptr @mesh_list_new()
  %call10 = tail call ptr @mesh_pg_execute(i64 %0, ptr nonnull @.str.118, ptr %call9)
  %tag = load i8, ptr %call10, align 1
  switch i8 %tag, label %switch_default [
    i8 0, label %case_Ok
    i8 1, label %case_Err
  ]

else6:                                            ; preds = %else
  %str_eq17 = tail call i8 @mesh_string_eq(ptr %2, ptr nonnull @.str.122)
  %str_eq_bool18.not = icmp eq i8 %str_eq17, 0
  %call47 = tail call ptr @mesh_pg_commit(i64 %0)
  br i1 %str_eq_bool18.not, label %else21, label %then20

switch_default:                                   ; preds = %then5
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.120, i64 30, ptr nonnull @.panic_file.121, i64 82, i32 128, i32 5)
  unreachable

case_Ok:                                          ; preds = %then5
  %variant_box = tail call ptr @mesh_gc_alloc_actor(i64 0, i64 8)
  %3 = insertvalue { i8, ptr } { i8 0, ptr poison }, ptr %variant_box, 1
  br label %common.ret

case_Err:                                         ; preds = %then5
  %variant_field = getelementptr inbounds nuw i8, ptr %call10, i64 8
  %path_val = load ptr, ptr %variant_field, align 8
  %concat = tail call ptr @mesh_string_concat(ptr nonnull @.str.119, ptr %path_val)
  %4 = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %concat, 1
  br label %common.ret

then20:                                           ; preds = %else6
  %tag27 = load i8, ptr %call47, align 1
  switch i8 %tag27, label %switch_default28 [
    i8 0, label %case_Ok29
    i8 1, label %case_Err30
  ]

else21:                                           ; preds = %else6
  %ret_coerce_load48 = load { i8, ptr }, ptr %call47, align 8
  br label %common.ret

switch_default28:                                 ; preds = %then20
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.124, i64 30, ptr nonnull @.panic_file.125, i64 82, i32 133, i32 5)
  unreachable

case_Ok29:                                        ; preds = %then20
  %variant_box33 = tail call ptr @mesh_gc_alloc_actor(i64 0, i64 8)
  %5 = insertvalue { i8, ptr } { i8 0, ptr poison }, ptr %variant_box33, 1
  br label %common.ret

case_Err30:                                       ; preds = %then20
  %variant_field36 = getelementptr inbounds nuw i8, ptr %call47, i64 8
  %path_val37 = load ptr, ptr %variant_field36, align 8
  %concat42 = tail call ptr @mesh_string_concat(ptr nonnull @.str.123, ptr %path_val37)
  %6 = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %concat42, 1
  br label %common.ret
}

define { i8, ptr } @Main__transact_batch(i64 %0, ptr %1) {
entry:
  %call = tail call ptr @mesh_json_object_get(ptr %1, ptr nonnull @.str.126)
  %tag = load i8, ptr %call, align 1
  switch i8 %tag, label %switch_default [
    i8 0, label %case_Ok
    i8 1, label %case_Err
  ]

switch_default:                                   ; preds = %entry
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.127, i64 30, ptr nonnull @.panic_file.128, i64 82, i32 143, i32 14)
  unreachable

case_Ok:                                          ; preds = %entry
  %variant_field = getelementptr inbounds nuw i8, ptr %call, i64 8
  %path_val = load ptr, ptr %variant_field, align 8
  %call7 = tail call ptr @mesh_json_array_length(ptr %path_val)
  %tag10 = load i8, ptr %call7, align 1
  switch i8 %tag10, label %switch_default11 [
    i8 0, label %case_Ok12
    i8 1, label %case_Err13
  ]

common.ret:                                       ; preds = %case_Err132, %case_Ok131, %case_Err173, %case_Err145, %case_Err108, %case_Err87, %case_Err69, %case_Err50, %case_Err32, %case_Err13, %case_Err
  %common.ret.op = phi { i8, ptr } [ %variant_val.fca.1.insert, %case_Err ], [ %variant_val23.fca.1.insert, %case_Err13 ], [ %variant_val42.fca.1.insert, %case_Err32 ], [ %variant_val60.fca.1.insert, %case_Err50 ], [ %variant_val79.fca.1.insert, %case_Err69 ], [ %variant_val98.fca.1.insert, %case_Err87 ], [ %variant_val119.fca.1.insert, %case_Err108 ], [ %variant_val156.fca.1.insert, %case_Err145 ], [ %variant_val184.fca.1.insert, %case_Err173 ], [ %call126, %case_Ok131 ], [ %call126, %case_Err132 ]
  ret { i8, ptr } %common.ret.op

case_Err:                                         ; preds = %entry
  %variant_field3 = getelementptr inbounds nuw i8, ptr %call, i64 8
  %path_val4 = load ptr, ptr %variant_field3, align 8
  %variant_val.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val4, 1
  br label %common.ret

switch_default11:                                 ; preds = %case_Ok
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.129, i64 30, ptr nonnull @.panic_file.130, i64 82, i32 144, i32 15)
  unreachable

case_Ok12:                                        ; preds = %case_Ok
  %variant_field14 = getelementptr inbounds nuw i8, ptr %call7, i64 8
  %boxed_variant_payload = load ptr, ptr %variant_field14, align 8
  %path_val15 = load i64, ptr %boxed_variant_payload, align 8
  %call26 = tail call ptr @mesh_json_object_get(ptr %1, ptr nonnull @.str.131)
  %tag29 = load i8, ptr %call26, align 1
  switch i8 %tag29, label %switch_default30 [
    i8 0, label %case_Ok31
    i8 1, label %case_Err32
  ]

case_Err13:                                       ; preds = %case_Ok
  %variant_field17 = getelementptr inbounds nuw i8, ptr %call7, i64 8
  %path_val18 = load ptr, ptr %variant_field17, align 8
  %variant_val23.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val18, 1
  br label %common.ret

switch_default30:                                 ; preds = %case_Ok12
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.132, i64 30, ptr nonnull @.panic_file.133, i64 82, i32 145, i32 35)
  unreachable

case_Ok31:                                        ; preds = %case_Ok12
  %variant_field33 = getelementptr inbounds nuw i8, ptr %call26, i64 8
  %path_val34 = load ptr, ptr %variant_field33, align 8
  %call44 = tail call ptr @mesh_json_as_string(ptr %path_val34)
  %tag47 = load i8, ptr %call44, align 1
  switch i8 %tag47, label %switch_default48 [
    i8 0, label %case_Ok49
    i8 1, label %case_Err50
  ]

case_Err32:                                       ; preds = %case_Ok12
  %variant_field36 = getelementptr inbounds nuw i8, ptr %call26, i64 8
  %path_val37 = load ptr, ptr %variant_field36, align 8
  %variant_val42.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val37, 1
  br label %common.ret

switch_default48:                                 ; preds = %case_Ok31
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.134, i64 30, ptr nonnull @.panic_file.135, i64 82, i32 145, i32 20)
  unreachable

case_Ok49:                                        ; preds = %case_Ok31
  %variant_field51 = getelementptr inbounds nuw i8, ptr %call44, i64 8
  %path_val52 = load ptr, ptr %variant_field51, align 8
  %call63 = tail call ptr @mesh_json_object_get(ptr %1, ptr nonnull @.str.136)
  %tag66 = load i8, ptr %call63, align 1
  switch i8 %tag66, label %switch_default67 [
    i8 0, label %case_Ok68
    i8 1, label %case_Err69
  ]

case_Err50:                                       ; preds = %case_Ok31
  %variant_field54 = getelementptr inbounds nuw i8, ptr %call44, i64 8
  %path_val55 = load ptr, ptr %variant_field54, align 8
  %variant_val60.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val55, 1
  br label %common.ret

switch_default67:                                 ; preds = %case_Ok49
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.137, i64 30, ptr nonnull @.panic_file.138, i64 82, i32 146, i32 31)
  unreachable

case_Ok68:                                        ; preds = %case_Ok49
  %variant_field70 = getelementptr inbounds nuw i8, ptr %call63, i64 8
  %path_val71 = load ptr, ptr %variant_field70, align 8
  %call81 = tail call ptr @mesh_json_value_as_bool(ptr %path_val71)
  %tag84 = load i8, ptr %call81, align 1
  switch i8 %tag84, label %switch_default85 [
    i8 0, label %case_Ok86
    i8 1, label %case_Err87
  ]

case_Err69:                                       ; preds = %case_Ok49
  %variant_field73 = getelementptr inbounds nuw i8, ptr %call63, i64 8
  %path_val74 = load ptr, ptr %variant_field73, align 8
  %variant_val79.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val74, 1
  br label %common.ret

switch_default85:                                 ; preds = %case_Ok68
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.139, i64 30, ptr nonnull @.panic_file.140, i64 82, i32 146, i32 18)
  unreachable

case_Ok86:                                        ; preds = %case_Ok68
  %variant_field88 = getelementptr inbounds nuw i8, ptr %call81, i64 8
  %boxed_variant_payload89 = load ptr, ptr %variant_field88, align 8
  %path_val90 = load i1, ptr %boxed_variant_payload89, align 1
  %call100 = tail call ptr @mesh_env_get_with_default(ptr nonnull @.str.141, ptr nonnull @.str.142)
  %call102 = tail call ptr @mesh_pg_begin(i64 %0)
  %tag105 = load i8, ptr %call102, align 1
  switch i8 %tag105, label %switch_default106 [
    i8 0, label %case_Ok107
    i8 1, label %case_Err108
  ]

case_Err87:                                       ; preds = %case_Ok68
  %variant_field92 = getelementptr inbounds nuw i8, ptr %call81, i64 8
  %path_val93 = load ptr, ptr %variant_field92, align 8
  %variant_val98.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val93, 1
  br label %common.ret

switch_default106:                                ; preds = %case_Ok86
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.143, i64 30, ptr nonnull @.panic_file.144, i64 82, i32 148, i32 11)
  unreachable

case_Ok107:                                       ; preds = %case_Ok86
  %call126 = tail call { i8, ptr } @Main__write_batch(i64 %0, ptr %path_val, i64 %path_val15, ptr %path_val52, ptr %call100)
  tail call void @mesh_reduction_check()
  %call126.fca.0.extract = extractvalue { i8, ptr } %call126, 0
  switch i8 %call126.fca.0.extract, label %switch_default130 [
    i8 0, label %case_Ok131
    i8 1, label %case_Err132
  ]

case_Err108:                                      ; preds = %case_Ok86
  %variant_field113 = getelementptr inbounds nuw i8, ptr %call102, i64 8
  %path_val114 = load ptr, ptr %variant_field113, align 8
  %variant_val119.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val114, 1
  br label %common.ret

switch_default130:                                ; preds = %case_Ok107
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.149, i64 30, ptr nonnull @.panic_file.150, i64 82, i32 149, i32 3)
  unreachable

case_Ok131:                                       ; preds = %case_Ok107
  %call138 = tail call { i8, ptr } @Main__finish_batch(i64 %0, i1 %path_val90, ptr %call100)
  tail call void @mesh_reduction_check()
  %call138.fca.0.extract = extractvalue { i8, ptr } %call138, 0
  switch i8 %call138.fca.0.extract, label %switch_default143 [
    i8 0, label %common.ret
    i8 1, label %case_Err145
  ]

case_Err132:                                      ; preds = %case_Ok107
  %call167 = tail call ptr @mesh_pg_rollback(i64 %0)
  %tag170 = load i8, ptr %call167, align 1
  switch i8 %tag170, label %switch_default171 [
    i8 0, label %common.ret
    i8 1, label %case_Err173
  ]

switch_default143:                                ; preds = %case_Ok131
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.145, i64 30, ptr nonnull @.panic_file.146, i64 82, i32 151, i32 15)
  unreachable

case_Err145:                                      ; preds = %case_Ok131
  %call138.fca.1.extract = extractvalue { i8, ptr } %call138, 1
  %variant_val156.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %call138.fca.1.extract, 1
  br label %common.ret

switch_default171:                                ; preds = %case_Err132
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.147, i64 30, ptr nonnull @.panic_file.148, i64 82, i32 154, i32 15)
  unreachable

case_Err173:                                      ; preds = %case_Err132
  %variant_field178 = getelementptr inbounds nuw i8, ptr %call167, i64 8
  %path_val179 = load ptr, ptr %variant_field178, align 8
  %variant_val184.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val179, 1
  br label %common.ret
}

define { i8, ptr } @Main__read_batch(ptr %0) {
entry:
  %call = tail call i8 @mesh_string_starts_with(ptr %0, ptr nonnull @.str.151)
  %to_bool = trunc i8 %call to i1
  br i1 %to_bool, label %else, label %common.ret

common.ret:                                       ; preds = %entry, %case_Err, %case_Ok
  %common.ret.op = phi { i8, ptr } [ %ret_coerce_load, %case_Ok ], [ %variant_val11.fca.1.insert, %case_Err ], [ { i8 1, ptr @.str.152 }, %entry ]
  ret { i8, ptr } %common.ret.op

else:                                             ; preds = %entry
  %call3 = tail call ptr @mesh_file_read(ptr %0)
  %tag = load i8, ptr %call3, align 1
  switch i8 %tag, label %switch_default [
    i8 0, label %case_Ok
    i8 1, label %case_Err
  ]

switch_default:                                   ; preds = %else
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.153, i64 30, ptr nonnull @.panic_file.154, i64 82, i32 163, i32 14)
  unreachable

case_Ok:                                          ; preds = %else
  %variant_field = getelementptr inbounds nuw i8, ptr %call3, i64 8
  %path_val = load ptr, ptr %variant_field, align 8
  %call12 = tail call ptr @mesh_json_parse(ptr %path_val)
  %ret_coerce_load = load { i8, ptr }, ptr %call12, align 8
  br label %common.ret

case_Err:                                         ; preds = %else
  %variant_field5 = getelementptr inbounds nuw i8, ptr %call3, i64 8
  %path_val6 = load ptr, ptr %variant_field5, align 8
  %variant_val11.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val6, 1
  br label %common.ret
}

define { i8, ptr } @Main__enqueue(ptr %0) {
entry:
  %call.i = tail call i8 @mesh_string_starts_with(ptr %0, ptr nonnull @.str.151)
  %to_bool.i = trunc i8 %call.i to i1
  br i1 %to_bool.i, label %else.i, label %Main__read_batch.exit

else.i:                                           ; preds = %entry
  %call3.i = tail call ptr @mesh_file_read(ptr %0)
  %tag.i = load i8, ptr %call3.i, align 1
  switch i8 %tag.i, label %switch_default.i [
    i8 0, label %case_Ok.i
    i8 1, label %case_Err.i
  ]

switch_default.i:                                 ; preds = %else.i
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.153, i64 30, ptr nonnull @.panic_file.154, i64 82, i32 163, i32 14)
  unreachable

case_Ok.i:                                        ; preds = %else.i
  %variant_field.i = getelementptr inbounds nuw i8, ptr %call3.i, i64 8
  %path_val.i = load ptr, ptr %variant_field.i, align 8
  %call12.i = tail call ptr @mesh_json_parse(ptr %path_val.i)
  %ret_coerce_load.i = load { i8, ptr }, ptr %call12.i, align 8
  br label %Main__read_batch.exit

case_Err.i:                                       ; preds = %else.i
  %variant_field5.i = getelementptr inbounds nuw i8, ptr %call3.i, i64 8
  %path_val6.i = load ptr, ptr %variant_field5.i, align 8
  %variant_val11.fca.1.insert.i = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val6.i, 1
  br label %Main__read_batch.exit

Main__read_batch.exit:                            ; preds = %entry, %case_Ok.i, %case_Err.i
  %common.ret.op.i = phi { i8, ptr } [ %ret_coerce_load.i, %case_Ok.i ], [ %variant_val11.fca.1.insert.i, %case_Err.i ], [ { i8 1, ptr @.str.152 }, %entry ]
  tail call void @mesh_reduction_check()
  %call.fca.0.extract = extractvalue { i8, ptr } %common.ret.op.i, 0
  %call.fca.1.extract = extractvalue { i8, ptr } %common.ret.op.i, 1
  switch i8 %call.fca.0.extract, label %switch_default [
    i8 0, label %case_Ok
    i8 1, label %case_Err
  ]

switch_default:                                   ; preds = %Main__read_batch.exit
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.155, i64 30, ptr nonnull @.panic_file.156, i64 82, i32 167, i32 15)
  unreachable

case_Ok:                                          ; preds = %Main__read_batch.exit
  %call.i11 = tail call ptr @mesh_env_get_with_default(ptr nonnull @.str, ptr nonnull @.str.1)
  tail call void @mesh_reduction_check()
  %call7 = tail call ptr @mesh_pg_connect(ptr %call.i11)
  %tag10 = load i8, ptr %call7, align 1
  switch i8 %tag10, label %switch_default11 [
    i8 0, label %case_Ok12
    i8 1, label %case_Err13
  ]

common.ret:                                       ; preds = %case_Ok12, %case_Err13, %case_Err
  %common.ret.op = phi { i8, ptr } [ %variant_val.fca.1.insert, %case_Err ], [ %variant_val23.fca.1.insert, %case_Err13 ], [ %call27, %case_Ok12 ]
  ret { i8, ptr } %common.ret.op

case_Err:                                         ; preds = %Main__read_batch.exit
  %variant_val.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %call.fca.1.extract, 1
  br label %common.ret

switch_default11:                                 ; preds = %case_Ok
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.157, i64 30, ptr nonnull @.panic_file.158, i64 82, i32 168, i32 14)
  unreachable

case_Ok12:                                        ; preds = %case_Ok
  %variant_field14 = getelementptr inbounds nuw i8, ptr %call7, i64 8
  %boxed_variant_payload = load ptr, ptr %variant_field14, align 8
  %path_val15 = load i64, ptr %boxed_variant_payload, align 8
  %call27 = tail call { i8, ptr } @Main__transact_batch(i64 %path_val15, ptr %call.fca.1.extract)
  tail call void @mesh_reduction_check()
  tail call void @mesh_pg_close(i64 %path_val15)
  br label %common.ret

case_Err13:                                       ; preds = %case_Ok
  %variant_field17 = getelementptr inbounds nuw i8, ptr %call7, i64 8
  %path_val18 = load ptr, ptr %variant_field17, align 8
  %variant_val23.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val18, 1
  br label %common.ret
}

define { i8, ptr } @Main__enqueue_paths() {
entry:
  %reduction_state = tail call ptr @mesh_reduction_state_v1()
  br label %tce_loop

tce_loop:                                         ; preds = %tce_loop.backedge, %entry
  %call = tail call ptr @mesh_io_read_line()
  %tag = load i8, ptr %call, align 1
  switch i8 %tag, label %switch_default [
    i8 0, label %case_Ok
    i8 1, label %case_Err
  ]

switch_default:                                   ; preds = %tce_loop
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.159, i64 30, ptr nonnull @.panic_file.160, i64 82, i32 175, i32 14)
  unreachable

case_Ok:                                          ; preds = %tce_loop
  %variant_field = getelementptr inbounds nuw i8, ptr %call, i64 8
  %path_val = load ptr, ptr %variant_field, align 8
  %str_eq = tail call i8 @mesh_string_eq(ptr %path_val, ptr nonnull @.str.161)
  %str_eq_bool.not = icmp eq i8 %str_eq, 0
  br i1 %str_eq_bool.not, label %else, label %common.ret

common.ret:                                       ; preds = %case_Ok, %case_Err17, %case_Err
  %common.ret.op = phi { i8, ptr } [ %variant_val.fca.1.insert, %case_Err ], [ %variant_val27.fca.1.insert, %case_Err17 ], [ { i8 0, ptr @.str.162 }, %case_Ok ]
  ret { i8, ptr } %common.ret.op

case_Err:                                         ; preds = %tce_loop
  %variant_field2 = getelementptr inbounds nuw i8, ptr %call, i64 8
  %path_val3 = load ptr, ptr %variant_field2, align 8
  %variant_val.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val3, 1
  br label %common.ret

else:                                             ; preds = %case_Ok
  %call11 = tail call { i8, ptr } @Main__enqueue(ptr %path_val)
  tail call void @mesh_reduction_check()
  %call11.fca.0.extract = extractvalue { i8, ptr } %call11, 0
  %call11.fca.1.extract = extractvalue { i8, ptr } %call11, 1
  switch i8 %call11.fca.0.extract, label %switch_default15 [
    i8 0, label %case_Ok16
    i8 1, label %case_Err17
  ]

switch_default15:                                 ; preds = %else
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.163, i64 30, ptr nonnull @.panic_file.164, i64 82, i32 179, i32 17)
  unreachable

case_Ok16:                                        ; preds = %else
  tail call void @mesh_println(ptr %call11.fca.1.extract)
  %reduction_remaining = load i32, ptr %reduction_state, align 4
  switch i32 %reduction_remaining, label %reduction_debit [
    i32 0, label %reduction_slow
    i32 -1, label %tce_loop.backedge
  ]

tce_loop.backedge:                                ; preds = %case_Ok16, %reduction_slow, %reduction_debit
  br label %tce_loop

case_Err17:                                       ; preds = %else
  %variant_val27.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %call11.fca.1.extract, 1
  br label %common.ret

reduction_slow:                                   ; preds = %case_Ok16
  tail call void @mesh_reduction_check()
  br label %tce_loop.backedge

reduction_debit:                                  ; preds = %case_Ok16
  %reduction_next = add i32 %reduction_remaining, -1
  store i32 %reduction_next, ptr %reduction_state, align 4
  br label %tce_loop.backedge
}

define { i8, ptr } @Main__enqueue_stream() {
entry:
  tail call void @mesh_println(ptr nonnull @.str.165)
  %call = tail call { i8, ptr } @Main__enqueue_paths()
  tail call void @mesh_reduction_check()
  ret { i8, ptr } %call
}

define { i8, ptr } @Main__wait_mark(ptr %0) {
entry:
  %call = tail call i64 @mesh_monotonic_now_nanos()
  %add = add i64 %call, 15000000000
  %call24 = tail call i8 @mesh_file_exists(ptr %0)
  %to_bool5 = trunc i8 %call24 to i1
  br i1 %to_bool5, label %while_merge, label %and_rhs

while_body:                                       ; preds = %and_rhs
  tail call void @mesh_timer_sleep(i64 5)
  tail call void @mesh_reduction_check()
  %call2 = tail call i8 @mesh_file_exists(ptr %0)
  %to_bool = trunc i8 %call2 to i1
  br i1 %to_bool, label %while_merge, label %and_rhs

while_merge:                                      ; preds = %and_rhs, %while_body, %entry
  %call6 = tail call i8 @mesh_file_exists(ptr %0)
  %to_bool7 = trunc i8 %call6 to i1
  br i1 %to_bool7, label %then, label %if_merge

and_rhs:                                          ; preds = %entry, %while_body
  %call3 = tail call i64 @mesh_monotonic_now_nanos()
  %cmp = icmp slt i64 %call3, %add
  br i1 %cmp, label %while_body, label %while_merge

then:                                             ; preds = %while_merge
  %variant_box = tail call ptr @mesh_gc_alloc_actor(i64 0, i64 8)
  br label %if_merge

if_merge:                                         ; preds = %while_merge, %then
  %.sroa.03.0 = phi i8 [ 0, %then ], [ 1, %while_merge ]
  %.sroa.3.0 = phi ptr [ %variant_box, %then ], [ @.str.166, %while_merge ]
  %if_val.fca.0.insert = insertvalue { i8, ptr } poison, i8 %.sroa.03.0, 0
  %if_val.fca.1.insert = insertvalue { i8, ptr } %if_val.fca.0.insert, ptr %.sroa.3.0, 1
  ret { i8, ptr } %if_val.fca.1.insert
}

define ptr @Main__effect_result(ptr %0, ptr %1) {
entry:
  %call = tail call ptr @mesh_jobs_effect_v1(ptr %0, ptr %1)
  %tag = load i8, ptr %call, align 1
  switch i8 %tag, label %switch_default [
    i8 0, label %case_Ok
    i8 1, label %case_Err
  ]

match_merge:                                      ; preds = %case_Ok, %case_Err
  %match_result.0 = phi ptr [ %.str.167..str.168, %case_Ok ], [ %path_val5, %case_Err ]
  ret ptr %match_result.0

switch_default:                                   ; preds = %entry
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.169, i64 30, ptr nonnull @.panic_file.170, i64 82, i32 198, i32 3)
  unreachable

case_Ok:                                          ; preds = %entry
  %variant_field = getelementptr inbounds nuw i8, ptr %call, i64 8
  %boxed_variant_payload = load ptr, ptr %variant_field, align 8
  %path_val = load i1, ptr %boxed_variant_payload, align 1
  %.str.167..str.168 = select i1 %path_val, ptr @.str.167, ptr @.str.168
  br label %match_merge

case_Err:                                         ; preds = %entry
  %variant_field4 = getelementptr inbounds nuw i8, ptr %call, i64 8
  %path_val5 = load ptr, ptr %variant_field4, align 8
  br label %match_merge
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define noundef nonnull ptr @Main__complete() #1 {
entry:
  ret ptr @.str.171
}

define { i8, ptr } @Main__perform(ptr %0, i64 %1) {
entry:
  %call = tail call ptr @mesh_json_parse(ptr %0)
  %tag = load i8, ptr %call, align 1
  switch i8 %tag, label %switch_default [
    i8 0, label %case_Ok
    i8 1, label %case_Err
  ]

switch_default:                                   ; preds = %entry
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.172, i64 30, ptr nonnull @.panic_file.173, i64 82, i32 209, i32 13)
  unreachable

case_Ok:                                          ; preds = %entry
  %variant_field = getelementptr inbounds nuw i8, ptr %call, i64 8
  %path_val = load ptr, ptr %variant_field, align 8
  %call7 = tail call ptr @mesh_json_object_get(ptr %path_val, ptr nonnull @.str.174)
  %tag10 = load i8, ptr %call7, align 1
  switch i8 %tag10, label %switch_default11 [
    i8 0, label %case_Ok12
    i8 1, label %case_Err13
  ]

common.ret:                                       ; preds = %or_rhs187, %or_rhs177, %case_Ok161, %or_rhs181, %case_Err588, %case_Err565, %if_merge555, %then542, %case_Err518, %then489, %case_Err468, %case_Err439, %case_Ok438, %case_Err417, %case_Err387, %case_Err349, %case_Err322, %case_Err279, %case_Err258, %case_Err214, %case_Err162, %case_Err144, %case_Err124, %case_Err106, %case_Err87, %case_Err69, %case_Err50, %case_Err32, %case_Err13, %case_Err
  %common.ret.op = phi { i8, ptr } [ %variant_val.fca.1.insert, %case_Err ], [ %variant_val23.fca.1.insert, %case_Err13 ], [ %variant_val42.fca.1.insert, %case_Err32 ], [ %variant_val60.fca.1.insert, %case_Err50 ], [ %variant_val79.fca.1.insert, %case_Err69 ], [ %variant_val97.fca.1.insert, %case_Err87 ], [ %variant_val116.fca.1.insert, %case_Err106 ], [ %variant_val135.fca.1.insert, %case_Err124 ], [ %variant_val154.fca.1.insert, %case_Err144 ], [ %variant_val173.fca.1.insert, %case_Err162 ], [ %variant_val224.fca.1.insert, %case_Err214 ], [ %variant_val269.fca.1.insert, %case_Err258 ], [ %variant_val290.fca.1.insert, %case_Err279 ], [ %variant_val332.fca.1.insert, %case_Err322 ], [ %variant_val360.fca.1.insert, %case_Err349 ], [ %variant_val398.fca.1.insert, %case_Err387 ], [ %variant_val428.fca.1.insert, %case_Err417 ], [ { i8 0, ptr @.str.171 }, %case_Ok438 ], [ %variant_val450.fca.1.insert, %case_Err439 ], [ %variant_val479.fca.1.insert, %case_Err468 ], [ %variant_val496.fca.1.insert, %then489 ], [ %variant_val528.fca.1.insert, %case_Err518 ], [ %variant_val549.fca.1.insert, %then542 ], [ { i8 0, ptr @.str.171 }, %if_merge555 ], [ %variant_val576.fca.1.insert, %case_Err565 ], [ %variant_val599.fca.1.insert, %case_Err588 ], [ { i8 1, ptr @.str.206 }, %or_rhs181 ], [ { i8 1, ptr @.str.206 }, %case_Ok161 ], [ { i8 1, ptr @.str.206 }, %or_rhs177 ], [ { i8 1, ptr @.str.206 }, %or_rhs187 ]
  ret { i8, ptr } %common.ret.op

case_Err:                                         ; preds = %entry
  %variant_field3 = getelementptr inbounds nuw i8, ptr %call, i64 8
  %path_val4 = load ptr, ptr %variant_field3, align 8
  %variant_val.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val4, 1
  br label %common.ret

switch_default11:                                 ; preds = %case_Ok
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.175, i64 30, ptr nonnull @.panic_file.176, i64 82, i32 210, i32 14)
  unreachable

case_Ok12:                                        ; preds = %case_Ok
  %variant_field14 = getelementptr inbounds nuw i8, ptr %call7, i64 8
  %path_val15 = load ptr, ptr %variant_field14, align 8
  %call26 = tail call ptr @mesh_json_object_get(ptr %path_val15, ptr nonnull @.str.177)
  %tag29 = load i8, ptr %call26, align 1
  switch i8 %tag29, label %switch_default30 [
    i8 0, label %case_Ok31
    i8 1, label %case_Err32
  ]

case_Err13:                                       ; preds = %case_Ok
  %variant_field17 = getelementptr inbounds nuw i8, ptr %call7, i64 8
  %path_val18 = load ptr, ptr %variant_field17, align 8
  %variant_val23.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val18, 1
  br label %common.ret

switch_default30:                                 ; preds = %case_Ok12
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.178, i64 30, ptr nonnull @.panic_file.179, i64 82, i32 211, i32 28)
  unreachable

case_Ok31:                                        ; preds = %case_Ok12
  %variant_field33 = getelementptr inbounds nuw i8, ptr %call26, i64 8
  %path_val34 = load ptr, ptr %variant_field33, align 8
  %call44 = tail call ptr @mesh_json_as_string(ptr %path_val34)
  %tag47 = load i8, ptr %call44, align 1
  switch i8 %tag47, label %switch_default48 [
    i8 0, label %case_Ok49
    i8 1, label %case_Err50
  ]

case_Err32:                                       ; preds = %case_Ok12
  %variant_field36 = getelementptr inbounds nuw i8, ptr %call26, i64 8
  %path_val37 = load ptr, ptr %variant_field36, align 8
  %variant_val42.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val37, 1
  br label %common.ret

switch_default48:                                 ; preds = %case_Ok31
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.180, i64 30, ptr nonnull @.panic_file.181, i64 82, i32 211, i32 13)
  unreachable

case_Ok49:                                        ; preds = %case_Ok31
  %variant_field51 = getelementptr inbounds nuw i8, ptr %call44, i64 8
  %path_val52 = load ptr, ptr %variant_field51, align 8
  %call63 = tail call ptr @mesh_json_object_get(ptr %path_val, ptr nonnull @.str.182)
  %tag66 = load i8, ptr %call63, align 1
  switch i8 %tag66, label %switch_default67 [
    i8 0, label %case_Ok68
    i8 1, label %case_Err69
  ]

case_Err50:                                       ; preds = %case_Ok31
  %variant_field54 = getelementptr inbounds nuw i8, ptr %call44, i64 8
  %path_val55 = load ptr, ptr %variant_field54, align 8
  %variant_val60.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val55, 1
  br label %common.ret

switch_default67:                                 ; preds = %case_Ok49
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.183, i64 30, ptr nonnull @.panic_file.184, i64 82, i32 212, i32 29)
  unreachable

case_Ok68:                                        ; preds = %case_Ok49
  %variant_field70 = getelementptr inbounds nuw i8, ptr %call63, i64 8
  %path_val71 = load ptr, ptr %variant_field70, align 8
  %call81 = tail call ptr @mesh_json_value_as_int(ptr %path_val71)
  %tag84 = load i8, ptr %call81, align 1
  switch i8 %tag84, label %switch_default85 [
    i8 0, label %case_Ok86
    i8 1, label %case_Err87
  ]

case_Err69:                                       ; preds = %case_Ok49
  %variant_field73 = getelementptr inbounds nuw i8, ptr %call63, i64 8
  %path_val74 = load ptr, ptr %variant_field73, align 8
  %variant_val79.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val74, 1
  br label %common.ret

switch_default85:                                 ; preds = %case_Ok68
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.185, i64 30, ptr nonnull @.panic_file.186, i64 82, i32 212, i32 17)
  unreachable

case_Ok86:                                        ; preds = %case_Ok68
  %variant_field88 = getelementptr inbounds nuw i8, ptr %call81, i64 8
  %boxed_variant_payload = load ptr, ptr %variant_field88, align 8
  %path_val89 = load i64, ptr %boxed_variant_payload, align 8
  %call100 = tail call ptr @mesh_json_object_get(ptr %path_val15, ptr nonnull @.str.187)
  %tag103 = load i8, ptr %call100, align 1
  switch i8 %tag103, label %switch_default104 [
    i8 0, label %case_Ok105
    i8 1, label %case_Err106
  ]

case_Err87:                                       ; preds = %case_Ok68
  %variant_field91 = getelementptr inbounds nuw i8, ptr %call81, i64 8
  %path_val92 = load ptr, ptr %variant_field91, align 8
  %variant_val97.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val92, 1
  br label %common.ret

switch_default104:                                ; preds = %case_Ok86
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.188, i64 30, ptr nonnull @.panic_file.189, i64 82, i32 213, i32 26)
  unreachable

case_Ok105:                                       ; preds = %case_Ok86
  %variant_field107 = getelementptr inbounds nuw i8, ptr %call100, i64 8
  %path_val108 = load ptr, ptr %variant_field107, align 8
  %call118 = tail call ptr @mesh_json_value_as_int(ptr %path_val108)
  %tag121 = load i8, ptr %call118, align 1
  switch i8 %tag121, label %switch_default122 [
    i8 0, label %case_Ok123
    i8 1, label %case_Err124
  ]

case_Err106:                                      ; preds = %case_Ok86
  %variant_field110 = getelementptr inbounds nuw i8, ptr %call100, i64 8
  %path_val111 = load ptr, ptr %variant_field110, align 8
  %variant_val116.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val111, 1
  br label %common.ret

switch_default122:                                ; preds = %case_Ok105
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.190, i64 30, ptr nonnull @.panic_file.191, i64 82, i32 213, i32 14)
  unreachable

case_Ok123:                                       ; preds = %case_Ok105
  %variant_field125 = getelementptr inbounds nuw i8, ptr %call118, i64 8
  %boxed_variant_payload126 = load ptr, ptr %variant_field125, align 8
  %path_val127 = load i64, ptr %boxed_variant_payload126, align 8
  %call138 = tail call ptr @mesh_json_object_get(ptr %path_val15, ptr nonnull @.str.192)
  %tag141 = load i8, ptr %call138, align 1
  switch i8 %tag141, label %switch_default142 [
    i8 0, label %case_Ok143
    i8 1, label %case_Err144
  ]

case_Err124:                                      ; preds = %case_Ok105
  %variant_field129 = getelementptr inbounds nuw i8, ptr %call118, i64 8
  %path_val130 = load ptr, ptr %variant_field129, align 8
  %variant_val135.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val130, 1
  br label %common.ret

switch_default142:                                ; preds = %case_Ok123
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.193, i64 30, ptr nonnull @.panic_file.194, i64 82, i32 214, i32 33)
  unreachable

case_Ok143:                                       ; preds = %case_Ok123
  %variant_field145 = getelementptr inbounds nuw i8, ptr %call138, i64 8
  %path_val146 = load ptr, ptr %variant_field145, align 8
  %call156 = tail call ptr @mesh_json_value_as_bool(ptr %path_val146)
  %tag159 = load i8, ptr %call156, align 1
  switch i8 %tag159, label %switch_default160 [
    i8 0, label %case_Ok161
    i8 1, label %case_Err162
  ]

case_Err144:                                      ; preds = %case_Ok123
  %variant_field148 = getelementptr inbounds nuw i8, ptr %call138, i64 8
  %path_val149 = load ptr, ptr %variant_field148, align 8
  %variant_val154.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val149, 1
  br label %common.ret

switch_default160:                                ; preds = %case_Ok143
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.195, i64 30, ptr nonnull @.panic_file.196, i64 82, i32 214, i32 20)
  unreachable

case_Ok161:                                       ; preds = %case_Ok143
  %variant_field163 = getelementptr inbounds nuw i8, ptr %call156, i64 8
  %boxed_variant_payload164 = load ptr, ptr %variant_field163, align 8
  %path_val165 = load i1, ptr %boxed_variant_payload164, align 1
  %cmp = icmp slt i64 %1, 0
  %spec.select = select i1 %cmp, i1 true, i1 %path_val165
  br i1 %spec.select, label %common.ret, label %or_rhs177

case_Err162:                                      ; preds = %case_Ok143
  %variant_field167 = getelementptr inbounds nuw i8, ptr %call156, i64 8
  %path_val168 = load ptr, ptr %variant_field167, align 8
  %variant_val173.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val168, 1
  br label %common.ret

or_rhs177:                                        ; preds = %case_Ok161
  %call179 = tail call ptr @mesh_env_get_with_default(ptr nonnull @.str.197, ptr nonnull @.str.198)
  %str_eq = tail call i8 @mesh_string_eq(ptr %call179, ptr nonnull @.str.199)
  %str_eq_bool = icmp eq i8 %str_eq, 0
  br i1 %str_eq_bool, label %common.ret, label %or_rhs181

or_rhs181:                                        ; preds = %or_rhs177
  %call183 = tail call ptr @mesh_env_get_with_default(ptr nonnull @.str.200, ptr nonnull @.str.201)
  %str_eq184 = tail call i8 @mesh_string_eq(ptr %call183, ptr nonnull @.str.202)
  %str_eq_bool185 = icmp eq i8 %str_eq184, 0
  br i1 %str_eq_bool185, label %common.ret, label %or_rhs187

or_rhs187:                                        ; preds = %or_rhs181
  %call189 = tail call ptr @mesh_env_get_with_default(ptr nonnull @.str.203, ptr nonnull @.str.204)
  %str_eq190 = tail call i8 @mesh_string_eq(ptr %call189, ptr nonnull @.str.205)
  %str_eq_bool191 = icmp eq i8 %str_eq190, 0
  br i1 %str_eq_bool191, label %common.ret, label %else

else:                                             ; preds = %or_rhs187
  %call198 = tail call ptr @mesh_json_object_get(ptr %path_val15, ptr nonnull @.str.207)
  %tag201 = load i8, ptr %call198, align 1
  switch i8 %tag201, label %switch_default202 [
    i8 0, label %case_Ok203
    i8 1, label %match_merge200
  ]

match_merge200:                                   ; preds = %else, %case_Ok213
  %.0 = phi ptr [ %path_val216, %case_Ok213 ], [ @.str.210, %else ]
  %str_eq228 = tail call i8 @mesh_string_eq(ptr %.0, ptr nonnull @.str.213)
  %str_eq_bool229.not = icmp eq i8 %str_eq228, 0
  br i1 %str_eq_bool229.not, label %else232, label %if_merge233

switch_default202:                                ; preds = %else
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.211, i64 30, ptr nonnull @.panic_file.212, i64 82, i32 218, i32 15)
  unreachable

case_Ok203:                                       ; preds = %else
  %variant_field205 = getelementptr inbounds nuw i8, ptr %call198, i64 8
  %path_val206 = load ptr, ptr %variant_field205, align 8
  %call208 = tail call ptr @mesh_json_as_string(ptr %path_val206)
  %tag211 = load i8, ptr %call208, align 1
  switch i8 %tag211, label %switch_default212 [
    i8 0, label %case_Ok213
    i8 1, label %case_Err214
  ]

switch_default212:                                ; preds = %case_Ok203
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.208, i64 30, ptr nonnull @.panic_file.209, i64 82, i32 219, i32 17)
  unreachable

case_Ok213:                                       ; preds = %case_Ok203
  %variant_field215 = getelementptr inbounds nuw i8, ptr %call208, i64 8
  %path_val216 = load ptr, ptr %variant_field215, align 8
  br label %match_merge200

case_Err214:                                      ; preds = %case_Ok203
  %variant_field218 = getelementptr inbounds nuw i8, ptr %call208, i64 8
  %path_val219 = load ptr, ptr %variant_field218, align 8
  %variant_val224.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val219, 1
  br label %common.ret

else232:                                          ; preds = %match_merge200
  %concat = tail call ptr @mesh_string_concat(ptr %.0, ptr nonnull @.str.215)
  %call236 = tail call ptr @mesh_int_to_string(i64 %path_val89)
  %concat237 = tail call ptr @mesh_string_concat(ptr %concat, ptr %call236)
  br label %if_merge233

if_merge233:                                      ; preds = %match_merge200, %else232
  %.070 = phi ptr [ %concat237, %else232 ], [ @.str.214, %match_merge200 ]
  %str_eq240 = tail call i8 @mesh_string_eq(ptr %.070, ptr nonnull @.str.216)
  %str_eq_bool241 = icmp eq i8 %str_eq240, 0
  %call242 = tail call i64 @mesh_parity_worker_pid()
  tail call void @mesh_reduction_check()
  br i1 %str_eq_bool241, label %then245, label %if_merge247

then245:                                          ; preds = %if_merge233
  %concat249 = tail call ptr @mesh_string_concat(ptr %.070, ptr nonnull @.str.217)
  %call251 = tail call ptr @mesh_int_to_string(i64 %call242)
  %call252 = tail call ptr @mesh_file_write(ptr %concat249, ptr %call251)
  %tag255 = load i8, ptr %call252, align 1
  switch i8 %tag255, label %switch_default256 [
    i8 0, label %case_Ok257
    i8 1, label %case_Err258
  ]

if_merge247:                                      ; preds = %case_Ok257, %if_merge233
  %.str.223..str.224 = phi ptr [ @.str.223, %case_Ok257 ], [ @.str.224, %if_merge233 ]
  %call294 = tail call ptr @mesh_json_from_string(ptr %path_val52)
  %call295 = tail call ptr @mesh_json_encode(ptr %call294)
  %call303 = tail call ptr @mesh_string_concat(ptr nonnull @.str.225, ptr %call295)
  %call304 = tail call ptr @mesh_string_concat(ptr %call303, ptr nonnull @.str.226)
  %call306 = tail call ptr @mesh_int_to_string(i64 %1)
  %call307 = tail call ptr @mesh_string_concat(ptr %call304, ptr %call306)
  %call308 = tail call ptr @mesh_string_concat(ptr %call307, ptr nonnull @.str.227)
  %call310 = tail call ptr @mesh_int_to_string(i64 %call242)
  %call311 = tail call ptr @mesh_string_concat(ptr %call308, ptr %call310)
  %call312 = tail call ptr @mesh_string_concat(ptr %call311, ptr nonnull @.str.228)
  %call314 = tail call ptr @mesh_string_concat(ptr %call312, ptr nonnull %.str.223..str.224)
  %call315 = tail call ptr @mesh_string_concat(ptr %call314, ptr nonnull @.str.229)
  %call316 = tail call ptr @mesh_json_parse(ptr %call315)
  %tag319 = load i8, ptr %call316, align 1
  switch i8 %tag319, label %switch_default320 [
    i8 0, label %case_Ok321
    i8 1, label %case_Err322
  ]

switch_default256:                                ; preds = %then245
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.218, i64 30, ptr nonnull @.panic_file.219, i64 82, i32 226, i32 13)
  unreachable

case_Ok257:                                       ; preds = %then245
  %concat272 = tail call ptr @mesh_string_concat(ptr %.070, ptr nonnull @.str.220)
  %call273 = tail call { i8, ptr } @Main__wait_mark(ptr %concat272)
  tail call void @mesh_reduction_check()
  %call273.fca.0.extract = extractvalue { i8, ptr } %call273, 0
  %switch = icmp eq i8 %call273.fca.0.extract, 0
  br i1 %switch, label %if_merge247, label %case_Err279

case_Err258:                                      ; preds = %then245
  %variant_field263 = getelementptr inbounds nuw i8, ptr %call252, i64 8
  %path_val264 = load ptr, ptr %variant_field263, align 8
  %variant_val269.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val264, 1
  br label %common.ret

case_Err279:                                      ; preds = %case_Ok257
  %call273.fca.1.extract = extractvalue { i8, ptr } %call273, 1
  %variant_val290.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %call273.fca.1.extract, 1
  br label %common.ret

switch_default320:                                ; preds = %if_merge247
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.230, i64 30, ptr nonnull @.panic_file.231, i64 82, i32 231, i32 16)
  unreachable

case_Ok321:                                       ; preds = %if_merge247
  %variant_field323 = getelementptr inbounds nuw i8, ptr %call316, i64 8
  %path_val324 = load ptr, ptr %variant_field323, align 8
  br i1 %str_eq_bool241, label %then336, label %if_merge338

case_Err322:                                      ; preds = %if_merge247
  %variant_field326 = getelementptr inbounds nuw i8, ptr %call316, i64 8
  %path_val327 = load ptr, ptr %variant_field326, align 8
  %variant_val332.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val327, 1
  br label %common.ret

then336:                                          ; preds = %case_Ok321
  %concat340 = tail call ptr @mesh_string_concat(ptr %.070, ptr nonnull @.str.232)
  %call341 = tail call i64 @mesh_monotonic_now_nanos()
  %call342 = tail call ptr @mesh_int_to_string(i64 %call341)
  %call343 = tail call ptr @mesh_file_write(ptr %concat340, ptr %call342)
  %tag346 = load i8, ptr %call343, align 1
  switch i8 %tag346, label %switch_default347 [
    i8 0, label %if_merge338
    i8 1, label %case_Err349
  ]

if_merge338:                                      ; preds = %then336, %case_Ok321
  %call365 = tail call ptr @Main__effect_result(ptr nonnull @.str.235, ptr %path_val324)
  tail call void @mesh_reduction_check()
  br i1 %str_eq_bool241, label %then368, label %if_merge370

switch_default347:                                ; preds = %then336
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.233, i64 30, ptr nonnull @.panic_file.234, i64 82, i32 233, i32 13)
  unreachable

case_Err349:                                      ; preds = %then336
  %variant_field354 = getelementptr inbounds nuw i8, ptr %call343, i64 8
  %path_val355 = load ptr, ptr %variant_field354, align 8
  %variant_val360.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val355, 1
  br label %common.ret

then368:                                          ; preds = %if_merge338
  %concat372 = tail call ptr @mesh_string_concat(ptr %.070, ptr nonnull @.str.236)
  %call373 = tail call ptr @mesh_json_object_new()
  %call375 = tail call ptr @mesh_json_from_string(ptr %call365)
  %call376 = tail call ptr @mesh_json_object_put(ptr %call373, ptr nonnull @.str.237, ptr %call375)
  %call377 = tail call i64 @mesh_monotonic_now_nanos()
  %call378 = tail call ptr @mesh_json_from_int(i64 %call377)
  %call379 = tail call ptr @mesh_json_object_put(ptr %call376, ptr nonnull @.str.238, ptr %call378)
  %call380 = tail call ptr @mesh_json_encode(ptr %call379)
  %call381 = tail call ptr @mesh_file_write(ptr %concat372, ptr %call380)
  %tag384 = load i8, ptr %call381, align 1
  switch i8 %tag384, label %switch_default385 [
    i8 0, label %case_Ok386
    i8 1, label %case_Err387
  ]

if_merge370:                                      ; preds = %else406, %if_merge338
  %str_eq483 = tail call i8 @mesh_string_eq(ptr %call365, ptr nonnull @.str.251)
  %str_eq_bool484 = icmp eq i8 %str_eq483, 0
  br i1 %str_eq_bool484, label %and_rhs, label %else490

switch_default385:                                ; preds = %then368
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.239, i64 30, ptr nonnull @.panic_file.240, i64 82, i32 238, i32 13)
  unreachable

case_Ok386:                                       ; preds = %then368
  %str_eq402 = tail call i8 @mesh_string_eq(ptr %call365, ptr nonnull @.str.241)
  %str_eq_bool403.not = icmp eq i8 %str_eq402, 0
  br i1 %str_eq_bool403.not, label %else406, label %then405

case_Err387:                                      ; preds = %then368
  %variant_field392 = getelementptr inbounds nuw i8, ptr %call381, i64 8
  %path_val393 = load ptr, ptr %variant_field392, align 8
  %variant_val398.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val393, 1
  br label %common.ret

then405:                                          ; preds = %case_Ok386
  %concat409 = tail call ptr @mesh_string_concat(ptr %.070, ptr nonnull @.str.242)
  %call410 = tail call { i8, ptr } @Main__wait_mark(ptr %concat409)
  tail call void @mesh_reduction_check()
  %call410.fca.0.extract = extractvalue { i8, ptr } %call410, 0
  %switch73 = icmp eq i8 %call410.fca.0.extract, 0
  br i1 %switch73, label %case_Ok416, label %case_Err417

else406:                                          ; preds = %case_Ok386
  %concat460 = tail call ptr @mesh_string_concat(ptr %.070, ptr nonnull @.str.248)
  %call461 = tail call { i8, ptr } @Main__wait_mark(ptr %concat460)
  tail call void @mesh_reduction_check()
  %call461.fca.0.extract = extractvalue { i8, ptr } %call461, 0
  %switch74 = icmp eq i8 %call461.fca.0.extract, 0
  br i1 %switch74, label %if_merge370, label %case_Err468

case_Ok416:                                       ; preds = %then405
  %concat431 = tail call ptr @mesh_string_concat(ptr %.070, ptr nonnull @.str.245)
  %call433 = tail call ptr @mesh_file_write(ptr %concat431, ptr %call365)
  %tag436 = load i8, ptr %call433, align 1
  switch i8 %tag436, label %switch_default437 [
    i8 0, label %case_Ok438
    i8 1, label %case_Err439
  ]

case_Err417:                                      ; preds = %then405
  %call410.fca.1.extract = extractvalue { i8, ptr } %call410, 1
  %variant_val428.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %call410.fca.1.extract, 1
  br label %common.ret

switch_default437:                                ; preds = %case_Ok416
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.246, i64 30, ptr nonnull @.panic_file.247, i64 82, i32 243, i32 15)
  unreachable

case_Ok438:                                       ; preds = %case_Ok416
  tail call void @mesh_reduction_check()
  br label %common.ret

case_Err439:                                      ; preds = %case_Ok416
  %variant_field444 = getelementptr inbounds nuw i8, ptr %call433, i64 8
  %path_val445 = load ptr, ptr %variant_field444, align 8
  %variant_val450.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val445, 1
  br label %common.ret

case_Err468:                                      ; preds = %else406
  %call461.fca.1.extract = extractvalue { i8, ptr } %call461, 1
  %variant_val479.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %call461.fca.1.extract, 1
  br label %common.ret

and_rhs:                                          ; preds = %if_merge370
  %str_eq486 = tail call i8 @mesh_string_eq(ptr %call365, ptr nonnull @.str.252)
  %str_eq_bool487 = icmp eq i8 %str_eq486, 0
  br i1 %str_eq_bool487, label %then489, label %else490

then489:                                          ; preds = %and_rhs
  %variant_val496.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %call365, 1
  br label %common.ret

else490:                                          ; preds = %if_merge370, %and_rhs
  %cmp499 = icmp sgt i64 %path_val127, 0
  br i1 %cmp499, label %then501, label %if_merge503

then501:                                          ; preds = %else490
  tail call void @mesh_timer_sleep(i64 %path_val127)
  br label %if_merge503

if_merge503:                                      ; preds = %else490, %then501
  %call507 = tail call ptr @mesh_string_concat(ptr nonnull @.str.253, ptr %call295)
  %call508 = tail call ptr @mesh_string_concat(ptr %call507, ptr nonnull @.str.254)
  %call510 = tail call ptr @mesh_string_concat(ptr %call508, ptr nonnull %.str.223..str.224)
  %call511 = tail call ptr @mesh_string_concat(ptr %call510, ptr nonnull @.str.255)
  %call512 = tail call ptr @mesh_json_parse(ptr %call511)
  %tag515 = load i8, ptr %call512, align 1
  switch i8 %tag515, label %switch_default516 [
    i8 0, label %case_Ok517
    i8 1, label %case_Err518
  ]

switch_default516:                                ; preds = %if_merge503
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.256, i64 30, ptr nonnull @.panic_file.257, i64 82, i32 250, i32 23)
  unreachable

case_Ok517:                                       ; preds = %if_merge503
  %variant_field519 = getelementptr inbounds nuw i8, ptr %call512, i64 8
  %path_val520 = load ptr, ptr %variant_field519, align 8
  %call531 = tail call ptr @Main__effect_result(ptr nonnull @.str.258, ptr %path_val520)
  tail call void @mesh_reduction_check()
  %str_eq533 = tail call i8 @mesh_string_eq(ptr %call531, ptr nonnull @.str.259)
  %str_eq_bool534 = icmp eq i8 %str_eq533, 0
  br i1 %str_eq_bool534, label %and_rhs535, label %else543

case_Err518:                                      ; preds = %if_merge503
  %variant_field522 = getelementptr inbounds nuw i8, ptr %call512, i64 8
  %path_val523 = load ptr, ptr %variant_field522, align 8
  %variant_val528.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val523, 1
  br label %common.ret

and_rhs535:                                       ; preds = %case_Ok517
  %str_eq538 = tail call i8 @mesh_string_eq(ptr %call531, ptr nonnull @.str.260)
  %str_eq_bool539 = icmp eq i8 %str_eq538, 0
  br i1 %str_eq_bool539, label %then542, label %else543

then542:                                          ; preds = %and_rhs535
  %variant_val549.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %call531, 1
  br label %common.ret

else543:                                          ; preds = %case_Ok517, %and_rhs535
  br i1 %str_eq_bool241, label %then553, label %if_merge555

then553:                                          ; preds = %else543
  %concat557 = tail call ptr @mesh_string_concat(ptr %.070, ptr nonnull @.str.261)
  %call559 = tail call ptr @mesh_file_write(ptr %concat557, ptr %call531)
  %tag562 = load i8, ptr %call559, align 1
  switch i8 %tag562, label %switch_default563 [
    i8 0, label %case_Ok564
    i8 1, label %case_Err565
  ]

if_merge555:                                      ; preds = %case_Ok564, %else543
  tail call void @mesh_reduction_check()
  br label %common.ret

switch_default563:                                ; preds = %then553
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.262, i64 30, ptr nonnull @.panic_file.263, i64 82, i32 254, i32 13)
  unreachable

case_Ok564:                                       ; preds = %then553
  %concat580 = tail call ptr @mesh_string_concat(ptr %.070, ptr nonnull @.str.264)
  %call581 = tail call { i8, ptr } @Main__wait_mark(ptr %concat580)
  tail call void @mesh_reduction_check()
  %call581.fca.0.extract = extractvalue { i8, ptr } %call581, 0
  %switch75 = icmp eq i8 %call581.fca.0.extract, 0
  br i1 %switch75, label %if_merge555, label %case_Err588

case_Err565:                                      ; preds = %then553
  %variant_field570 = getelementptr inbounds nuw i8, ptr %call559, i64 8
  %path_val571 = load ptr, ptr %variant_field570, align 8
  %variant_val576.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val571, 1
  br label %common.ret

case_Err588:                                      ; preds = %case_Ok564
  %call581.fca.1.extract = extractvalue { i8, ptr } %call581, 1
  %variant_val599.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %call581.fca.1.extract, 1
  br label %common.ret
}

define ptr @Main__handle(ptr %0) {
entry:
  %call = tail call i64 @mesh_parity_realtime_us()
  tail call void @mesh_reduction_check()
  %call3 = tail call { i8, ptr } @Main__perform(ptr %0, i64 %call)
  tail call void @mesh_reduction_check()
  %call3.fca.0.extract = extractvalue { i8, ptr } %call3, 0
  %call3.fca.1.extract = extractvalue { i8, ptr } %call3, 1
  switch i8 %call3.fca.0.extract, label %switch_default [
    i8 0, label %match_merge
    i8 1, label %case_Err
  ]

match_merge:                                      ; preds = %entry, %case_Err
  %match_result.0 = phi ptr [ %call13, %case_Err ], [ %call3.fca.1.extract, %entry ]
  ret ptr %match_result.0

switch_default:                                   ; preds = %entry
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.272, i64 30, ptr nonnull @.panic_file.273, i64 82, i32 262, i32 3)
  unreachable

case_Err:                                         ; preds = %entry
  %concat = tail call ptr @mesh_string_concat(ptr nonnull @.str.267, ptr %call3.fca.1.extract)
  tail call void @mesh_io_eprintln(ptr %concat)
  %call8 = tail call ptr @mesh_json_object_new()
  %call9 = tail call ptr @mesh_json_from_string(ptr nonnull @.str.269)
  %call10 = tail call ptr @mesh_json_object_put(ptr %call8, ptr nonnull @.str.268, ptr %call9)
  %call11 = tail call ptr @mesh_json_from_string(ptr nonnull @.str.271)
  %call12 = tail call ptr @mesh_json_object_put(ptr %call10, ptr nonnull @.str.270, ptr %call11)
  %call13 = tail call ptr @mesh_json_encode(ptr %call12)
  br label %match_merge
}

define { i8, ptr } @Main__session_loop(i64 %0) {
entry:
  %reduction_state = tail call ptr @mesh_reduction_state_v1()
  br label %tce_loop

tce_loop:                                         ; preds = %tce_loop.backedge, %entry
  %call = tail call ptr @mesh_io_read_line()
  %tag = load i8, ptr %call, align 1
  switch i8 %tag, label %switch_default [
    i8 0, label %case_Ok
    i8 1, label %case_Err
  ]

switch_default:                                   ; preds = %tce_loop
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.274, i64 30, ptr nonnull @.panic_file.275, i64 82, i32 271, i32 14)
  unreachable

case_Ok:                                          ; preds = %tce_loop
  %variant_field = getelementptr inbounds nuw i8, ptr %call, i64 8
  %path_val = load ptr, ptr %variant_field, align 8
  %str_eq = tail call i8 @mesh_string_eq(ptr %path_val, ptr nonnull @.str.276)
  %str_eq_bool.not = icmp eq i8 %str_eq, 0
  br i1 %str_eq_bool.not, label %else, label %common.ret

common.ret:                                       ; preds = %case_Ok164, %else71, %case_Ok, %case_Err165, %case_Err144, %case_Err126, %case_Err99, %case_Err81, %case_Err54, %case_Err36, %case_Err17, %case_Err
  %common.ret.op = phi { i8, ptr } [ %variant_val.fca.1.insert, %case_Err ], [ %variant_val27.fca.1.insert, %case_Err17 ], [ %variant_val46.fca.1.insert, %case_Err36 ], [ %variant_val64.fca.1.insert, %case_Err54 ], [ %variant_val91.fca.1.insert, %case_Err81 ], [ %variant_val109.fca.1.insert, %case_Err99 ], [ %variant_val136.fca.1.insert, %case_Err126 ], [ %variant_val154.fca.1.insert, %case_Err144 ], [ %variant_val175.fca.1.insert, %case_Err165 ], [ { i8 1, ptr @.str.299 }, %case_Ok164 ], [ { i8 1, ptr @.str.301 }, %else71 ], [ { i8 0, ptr @.str.277 }, %case_Ok ]
  ret { i8, ptr } %common.ret.op

case_Err:                                         ; preds = %tce_loop
  %variant_field2 = getelementptr inbounds nuw i8, ptr %call, i64 8
  %path_val3 = load ptr, ptr %variant_field2, align 8
  %variant_val.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val3, 1
  br label %common.ret

else:                                             ; preds = %case_Ok
  %call11 = tail call ptr @mesh_json_parse(ptr %path_val)
  %tag14 = load i8, ptr %call11, align 1
  switch i8 %tag14, label %switch_default15 [
    i8 0, label %case_Ok16
    i8 1, label %case_Err17
  ]

switch_default15:                                 ; preds = %else
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.278, i64 30, ptr nonnull @.panic_file.279, i64 82, i32 273, i32 17)
  unreachable

case_Ok16:                                        ; preds = %else
  %variant_field18 = getelementptr inbounds nuw i8, ptr %call11, i64 8
  %path_val19 = load ptr, ptr %variant_field18, align 8
  %call30 = tail call ptr @mesh_json_object_get(ptr %path_val19, ptr nonnull @.str.280)
  %tag33 = load i8, ptr %call30, align 1
  switch i8 %tag33, label %switch_default34 [
    i8 0, label %case_Ok35
    i8 1, label %case_Err36
  ]

case_Err17:                                       ; preds = %else
  %variant_field21 = getelementptr inbounds nuw i8, ptr %call11, i64 8
  %path_val22 = load ptr, ptr %variant_field21, align 8
  %variant_val27.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val22, 1
  br label %common.ret

switch_default34:                                 ; preds = %case_Ok16
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.281, i64 30, ptr nonnull @.panic_file.282, i64 82, i32 274, i32 29)
  unreachable

case_Ok35:                                        ; preds = %case_Ok16
  %variant_field37 = getelementptr inbounds nuw i8, ptr %call30, i64 8
  %path_val38 = load ptr, ptr %variant_field37, align 8
  %call48 = tail call ptr @mesh_json_as_string(ptr %path_val38)
  %tag51 = load i8, ptr %call48, align 1
  switch i8 %tag51, label %switch_default52 [
    i8 0, label %case_Ok53
    i8 1, label %case_Err54
  ]

case_Err36:                                       ; preds = %case_Ok16
  %variant_field40 = getelementptr inbounds nuw i8, ptr %call30, i64 8
  %path_val41 = load ptr, ptr %variant_field40, align 8
  %variant_val46.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val41, 1
  br label %common.ret

switch_default52:                                 ; preds = %case_Ok35
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.283, i64 30, ptr nonnull @.panic_file.284, i64 82, i32 274, i32 14)
  unreachable

case_Ok53:                                        ; preds = %case_Ok35
  %variant_field55 = getelementptr inbounds nuw i8, ptr %call48, i64 8
  %path_val56 = load ptr, ptr %variant_field55, align 8
  %str_eq67 = tail call i8 @mesh_string_eq(ptr %path_val56, ptr nonnull @.str.285)
  %str_eq_bool68.not = icmp eq i8 %str_eq67, 0
  br i1 %str_eq_bool68.not, label %else71, label %then70

case_Err54:                                       ; preds = %case_Ok35
  %variant_field58 = getelementptr inbounds nuw i8, ptr %call48, i64 8
  %path_val59 = load ptr, ptr %variant_field58, align 8
  %variant_val64.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val59, 1
  br label %common.ret

then70:                                           ; preds = %case_Ok53
  %call75 = tail call ptr @mesh_json_object_get(ptr %path_val19, ptr nonnull @.str.286)
  %tag78 = load i8, ptr %call75, align 1
  switch i8 %tag78, label %switch_default79 [
    i8 0, label %case_Ok80
    i8 1, label %case_Err81
  ]

else71:                                           ; preds = %case_Ok53
  %str_eq113 = tail call i8 @mesh_string_eq(ptr %path_val56, ptr nonnull @.str.291)
  %str_eq_bool114.not = icmp eq i8 %str_eq113, 0
  br i1 %str_eq_bool114.not, label %common.ret, label %then116

if_merge72:                                       ; preds = %case_Ok80, %else181
  %i64_to_ptr192.sink = phi ptr [ %i64_to_ptr192, %else181 ], [ %call93.fca.1.extract, %case_Ok80 ]
  tail call void @mesh_println(ptr %i64_to_ptr192.sink)
  %reduction_remaining = load i32, ptr %reduction_state, align 4
  switch i32 %reduction_remaining, label %reduction_debit [
    i32 0, label %reduction_slow
    i32 -1, label %tce_loop.backedge
  ]

tce_loop.backedge:                                ; preds = %if_merge72, %reduction_slow, %reduction_debit
  br label %tce_loop

switch_default79:                                 ; preds = %then70
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.287, i64 30, ptr nonnull @.panic_file.288, i64 82, i32 276, i32 40)
  unreachable

case_Ok80:                                        ; preds = %then70
  %variant_field82 = getelementptr inbounds nuw i8, ptr %call75, i64 8
  %path_val83 = load ptr, ptr %variant_field82, align 8
  %call93 = tail call { i8, ptr } @Main__transact_batch(i64 %0, ptr %path_val83)
  tail call void @mesh_reduction_check()
  %call93.fca.0.extract = extractvalue { i8, ptr } %call93, 0
  %call93.fca.1.extract = extractvalue { i8, ptr } %call93, 1
  switch i8 %call93.fca.0.extract, label %switch_default97 [
    i8 0, label %if_merge72
    i8 1, label %case_Err99
  ]

case_Err81:                                       ; preds = %then70
  %variant_field85 = getelementptr inbounds nuw i8, ptr %call75, i64 8
  %path_val86 = load ptr, ptr %variant_field85, align 8
  %variant_val91.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val86, 1
  br label %common.ret

switch_default97:                                 ; preds = %case_Ok80
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.289, i64 30, ptr nonnull @.panic_file.290, i64 82, i32 276, i32 19)
  unreachable

case_Err99:                                       ; preds = %case_Ok80
  %variant_val109.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %call93.fca.1.extract, 1
  br label %common.ret

then116:                                          ; preds = %else71
  %call120 = tail call ptr @mesh_json_object_get(ptr %path_val19, ptr nonnull @.str.292)
  %tag123 = load i8, ptr %call120, align 1
  switch i8 %tag123, label %switch_default124 [
    i8 0, label %case_Ok125
    i8 1, label %case_Err126
  ]

switch_default124:                                ; preds = %then116
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.293, i64 30, ptr nonnull @.panic_file.294, i64 82, i32 279, i32 30)
  unreachable

case_Ok125:                                       ; preds = %then116
  %variant_field127 = getelementptr inbounds nuw i8, ptr %call120, i64 8
  %path_val128 = load ptr, ptr %variant_field127, align 8
  %call138 = tail call ptr @mesh_json_as_string(ptr %path_val128)
  %tag141 = load i8, ptr %call138, align 1
  switch i8 %tag141, label %switch_default142 [
    i8 0, label %case_Ok143
    i8 1, label %case_Err144
  ]

case_Err126:                                      ; preds = %then116
  %variant_field130 = getelementptr inbounds nuw i8, ptr %call120, i64 8
  %path_val131 = load ptr, ptr %variant_field130, align 8
  %variant_val136.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val131, 1
  br label %common.ret

switch_default142:                                ; preds = %case_Ok125
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.295, i64 30, ptr nonnull @.panic_file.296, i64 82, i32 279, i32 15)
  unreachable

case_Ok143:                                       ; preds = %case_Ok125
  %variant_field145 = getelementptr inbounds nuw i8, ptr %call138, i64 8
  %path_val146 = load ptr, ptr %variant_field145, align 8
  %call158 = tail call ptr @mesh_list_new()
  %call159 = tail call ptr @mesh_pg_query(i64 %0, ptr %path_val146, ptr %call158)
  %tag162 = load i8, ptr %call159, align 1
  switch i8 %tag162, label %switch_default163 [
    i8 0, label %case_Ok164
    i8 1, label %case_Err165
  ]

case_Err144:                                      ; preds = %case_Ok125
  %variant_field148 = getelementptr inbounds nuw i8, ptr %call138, i64 8
  %path_val149 = load ptr, ptr %variant_field148, align 8
  %variant_val154.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val149, 1
  br label %common.ret

switch_default163:                                ; preds = %case_Ok143
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.297, i64 30, ptr nonnull @.panic_file.298, i64 82, i32 280, i32 16)
  unreachable

case_Ok164:                                       ; preds = %case_Ok143
  %variant_field166 = getelementptr inbounds nuw i8, ptr %call159, i64 8
  %path_val167 = load ptr, ptr %variant_field166, align 8
  %length.i = load i64, ptr %path_val167, align 8
  %cmp.not = icmp eq i64 %length.i, 1
  br i1 %cmp.not, label %else181, label %common.ret

case_Err165:                                      ; preds = %case_Ok143
  %variant_field169 = getelementptr inbounds nuw i8, ptr %call159, i64 8
  %path_val170 = load ptr, ptr %variant_field169, align 8
  %variant_val175.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val170, 1
  br label %common.ret

else181:                                          ; preds = %case_Ok164
  %call189 = tail call i64 @mesh_list_head(ptr nonnull %path_val167)
  %i64_to_ptr = inttoptr i64 %call189 to ptr
  %call190 = tail call ptr @mesh_map_tag_string(ptr %i64_to_ptr)
  %call191 = tail call i64 @mesh_map_fetch(ptr %call190, i64 ptrtoint (ptr @.str.300 to i64))
  %i64_to_ptr192 = inttoptr i64 %call191 to ptr
  br label %if_merge72

reduction_slow:                                   ; preds = %if_merge72
  tail call void @mesh_reduction_check()
  br label %tce_loop.backedge

reduction_debit:                                  ; preds = %if_merge72
  %reduction_next = add i32 %reduction_remaining, -1
  store i32 %reduction_next, ptr %reduction_state, align 4
  br label %tce_loop.backedge
}

define { i8, ptr } @Main__session() {
entry:
  %call.i = tail call ptr @mesh_env_get_with_default(ptr nonnull @.str, ptr nonnull @.str.1)
  tail call void @mesh_reduction_check()
  %call1 = tail call ptr @mesh_pg_connect(ptr %call.i)
  %tag = load i8, ptr %call1, align 1
  switch i8 %tag, label %switch_default [
    i8 0, label %case_Ok
    i8 1, label %case_Err
  ]

switch_default:                                   ; preds = %entry
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.302, i64 30, ptr nonnull @.panic_file.303, i64 82, i32 290, i32 14)
  unreachable

case_Ok:                                          ; preds = %entry
  %variant_field = getelementptr inbounds nuw i8, ptr %call1, i64 8
  %boxed_variant_payload = load ptr, ptr %variant_field, align 8
  %path_val = load i64, ptr %boxed_variant_payload, align 8
  tail call void @mesh_println(ptr nonnull @.str.304)
  %call7 = tail call { i8, ptr } @Main__session_loop(i64 %path_val)
  tail call void @mesh_reduction_check()
  tail call void @mesh_pg_close(i64 %path_val)
  br label %common.ret

common.ret:                                       ; preds = %case_Ok, %case_Err
  %common.ret.op = phi { i8, ptr } [ %variant_val.fca.1.insert, %case_Err ], [ %call7, %case_Ok ]
  ret { i8, ptr } %common.ret.op

case_Err:                                         ; preds = %entry
  %variant_field3 = getelementptr inbounds nuw i8, ptr %call1, i64 8
  %path_val4 = load ptr, ptr %variant_field3, align 8
  %variant_val.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val4, 1
  br label %common.ret
}

define { i8, ptr } @Main__serve(i64 %0) {
entry:
  %call = tail call i64 @mesh_env_get_int(ptr nonnull @.str.305, i64 0)
  %call1 = tail call i64 @mesh_env_get_int(ptr nonnull @.str.306, i64 0)
  %call2 = tail call ptr @mesh_env_get_with_default(ptr nonnull @.str.307, ptr nonnull @.str.308)
  %str_eq = tail call i8 @mesh_string_eq(ptr %call2, ptr nonnull @.str.309)
  %str_eq_bool.not = icmp eq i8 %str_eq, 0
  br i1 %str_eq_bool.not, label %else, label %common.ret

common.ret:                                       ; preds = %or_rhs112, %match_merge84, %match_merge, %entry, %case_Err287, %case_Ok286, %case_Err264, %case_Err241, %case_Err219, %case_Err197, %case_Err165, %case_Err143, %case_Err
  %common.ret.op = phi { i8, ptr } [ %variant_val42.fca.1.insert, %case_Err ], [ %variant_val153.fca.1.insert, %case_Err143 ], [ %variant_val175.fca.1.insert, %case_Err165 ], [ %variant_val207.fca.1.insert, %case_Err197 ], [ %variant_val230.fca.1.insert, %case_Err219 ], [ %variant_val252.fca.1.insert, %case_Err241 ], [ %variant_val275.fca.1.insert, %case_Err264 ], [ %ret_coerce_load, %case_Ok286 ], [ %variant_val297.fca.1.insert, %case_Err287 ], [ { i8 1, ptr @.str.310 }, %entry ], [ { i8 1, ptr @.str.317 }, %match_merge ], [ { i8 1, ptr @.str.350 }, %match_merge84 ], [ { i8 1, ptr @.str.350 }, %or_rhs112 ]
  ret { i8, ptr } %common.ret.op

else:                                             ; preds = %entry
  %call3 = tail call ptr @mesh_env_get_with_default(ptr nonnull @.str.311, ptr nonnull @.str.312)
  %str_eq4 = tail call i8 @mesh_string_eq(ptr %call3, ptr nonnull @.str.313)
  %str_eq_bool5.not = icmp eq i8 %str_eq4, 0
  br i1 %str_eq_bool5.not, label %test_failure, label %else24

match_merge:                                      ; preds = %test_failure10
  %str_eq17 = tail call i8 @mesh_string_eq(ptr %call3, ptr nonnull @.str.316)
  %str_eq_bool18.not = icmp eq i8 %str_eq17, 0
  br i1 %str_eq_bool18.not, label %common.ret, label %else24

test_failure:                                     ; preds = %else
  %str_eq7 = tail call i8 @mesh_string_eq(ptr %call3, ptr nonnull @.str.314)
  %str_eq_bool8.not = icmp eq i8 %str_eq7, 0
  br i1 %str_eq_bool8.not, label %test_failure10, label %else24

test_failure10:                                   ; preds = %test_failure
  %str_eq12 = tail call i8 @mesh_string_eq(ptr %call3, ptr nonnull @.str.315)
  %str_eq_bool13.not = icmp eq i8 %str_eq12, 0
  br i1 %str_eq_bool13.not, label %match_merge, label %else24

else24:                                           ; preds = %test_failure10, %test_failure, %else, %match_merge
  %.040 = phi i64 [ 10000, %match_merge ], [ 1500, %test_failure10 ], [ 30000, %test_failure ], [ 30000, %else ]
  %call31 = tail call ptr @mesh_json_parse(ptr nonnull @.str.318)
  %tag = load i8, ptr %call31, align 1
  switch i8 %tag, label %switch_default [
    i8 0, label %case_Ok
    i8 1, label %case_Err
  ]

switch_default:                                   ; preds = %else24
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.319, i64 30, ptr nonnull @.panic_file.320, i64 82, i32 314, i32 17)
  unreachable

case_Ok:                                          ; preds = %else24
  %variant_field = getelementptr inbounds nuw i8, ptr %call31, i64 8
  %path_val34 = load ptr, ptr %variant_field, align 8
  tail call void @mesh_process_install_shutdown_signals()
  %call44 = tail call ptr @mesh_json_object_new()
  %call.i = tail call ptr @mesh_env_get_with_default(ptr nonnull @.str.2, ptr nonnull @.str.3)
  tail call void @mesh_reduction_check()
  %call46 = tail call ptr @mesh_json_from_string(ptr %call.i)
  %call47 = tail call ptr @mesh_json_object_put(ptr %call44, ptr nonnull @.str.321, ptr %call46)
  %call48 = tail call ptr @mesh_json_object_new()
  %call50 = tail call ptr @mesh_json_from_int(i64 %call)
  %call51 = tail call ptr @mesh_json_object_put(ptr %call48, ptr nonnull @.str.323, ptr %call50)
  %call52 = tail call ptr @mesh_json_object_put(ptr %call47, ptr nonnull @.str.322, ptr %call51)
  %call54 = tail call ptr @mesh_json_object_put(ptr %call52, ptr nonnull @.str.324, ptr %path_val34)
  %call56 = tail call ptr @mesh_json_from_int(i64 %.040)
  %call57 = tail call ptr @mesh_json_object_put(ptr %call54, ptr nonnull @.str.325, ptr %call56)
  %call59 = tail call ptr @mesh_json_from_int(i64 %call1)
  %call60 = tail call ptr @mesh_json_object_put(ptr %call57, ptr nonnull @.str.326, ptr %call59)
  %call62 = tail call ptr @mesh_json_from_int(i64 15000)
  %call63 = tail call ptr @mesh_json_object_put(ptr %call60, ptr nonnull @.str.327, ptr %call62)
  %call64 = tail call ptr @mesh_json_encode(ptr %call63)
  %call65 = tail call ptr @mesh_env_get_with_default(ptr nonnull @.str.328, ptr nonnull @.str.329)
  %str_eq66 = tail call i8 @mesh_string_eq(ptr %call65, ptr nonnull @.str.330)
  %str_eq_bool67.not = icmp eq i8 %str_eq66, 0
  %.str.332..str.331 = select i1 %str_eq_bool67.not, ptr @.str.332, ptr @.str.331
  %call73 = tail call ptr @mesh_env_get_with_default(ptr nonnull @.str.333, ptr nonnull @.str.334)
  %str_eq74 = tail call i8 @mesh_string_eq(ptr %call73, ptr nonnull @.str.335)
  %str_eq_bool75.not = icmp eq i8 %str_eq74, 0
  %.035 = select i1 %str_eq_bool75.not, ptr @.str.337, ptr @.str.336
  %call81 = tail call ptr @mesh_env_get_with_default(ptr nonnull @.str.338, ptr nonnull @.str.339)
  %str_eq86 = tail call i8 @mesh_string_eq(ptr %call81, ptr nonnull @.str.340)
  %str_eq_bool87.not = icmp eq i8 %str_eq86, 0
  br i1 %str_eq_bool87.not, label %test_failure89, label %match_merge84

case_Err:                                         ; preds = %else24
  %variant_field36 = getelementptr inbounds nuw i8, ptr %call31, i64 8
  %path_val37 = load ptr, ptr %variant_field36, align 8
  %variant_val42.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val37, 1
  br label %common.ret

match_merge84:                                    ; preds = %test_failure89, %case_Ok
  %.036 = phi ptr [ @.str.341, %case_Ok ], [ %.str.344..str.343, %test_failure89 ]
  %call98 = tail call i64 @mesh_string_length(ptr %call64)
  %sub = add i64 %call98, -1
  %call99 = tail call ptr @mesh_string_slice(ptr %call64, i64 0, i64 %sub)
  %concat = tail call ptr @mesh_string_concat(ptr %call99, ptr nonnull %.str.332..str.331)
  %concat102 = tail call ptr @mesh_string_concat(ptr %concat, ptr nonnull %.035)
  %concat104 = tail call ptr @mesh_string_concat(ptr %concat102, ptr nonnull %.036)
  %concat105 = tail call ptr @mesh_string_concat(ptr %concat104, ptr nonnull @.str.345)
  %call106 = tail call i64 @mesh_env_get_int(ptr nonnull @.str.346, i64 0)
  %cmp108 = icmp slt i64 %call106, 1
  %cmp111 = icmp sgt i64 %call106, %call
  %or_result = select i1 %cmp108, i1 true, i1 %cmp111
  br i1 %or_result, label %common.ret, label %or_rhs112

test_failure89:                                   ; preds = %case_Ok
  %str_eq91 = tail call i8 @mesh_string_eq(ptr %call81, ptr nonnull @.str.342)
  %str_eq_bool92.not = icmp eq i8 %str_eq91, 0
  %.str.344..str.343 = select i1 %str_eq_bool92.not, ptr @.str.344, ptr @.str.343
  br label %match_merge84

or_rhs112:                                        ; preds = %match_merge84
  %call114 = tail call ptr @mesh_env_get_with_default(ptr nonnull @.str.347, ptr nonnull @.str.348)
  %str_eq115 = tail call i8 @mesh_string_eq(ptr %call114, ptr nonnull @.str.349)
  %str_eq_bool116 = icmp eq i8 %str_eq115, 0
  br i1 %str_eq_bool116, label %common.ret, label %else120

else120:                                          ; preds = %or_rhs112
  %call129 = tail call i64 @mesh_string_length(ptr %concat105)
  %sub130 = add i64 %call129, -1
  %call131 = tail call ptr @mesh_string_slice(ptr %concat105, i64 0, i64 %sub130)
  %concat132 = tail call ptr @mesh_string_concat(ptr %call131, ptr nonnull @.str.351)
  %call134 = tail call ptr @mesh_int_to_string(i64 %call106)
  %concat135 = tail call ptr @mesh_string_concat(ptr %concat132, ptr %call134)
  %concat136 = tail call ptr @mesh_string_concat(ptr %concat135, ptr nonnull @.str.352)
  %call137 = tail call ptr @mesh_json_parse(ptr nonnull @.str.353)
  %tag140 = load i8, ptr %call137, align 1
  switch i8 %tag140, label %switch_default141 [
    i8 0, label %case_Ok142
    i8 1, label %case_Err143
  ]

switch_default141:                                ; preds = %else120
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.354, i64 30, ptr nonnull @.panic_file.355, i64 82, i32 334, i32 18)
  unreachable

case_Ok142:                                       ; preds = %else120
  %variant_field144 = getelementptr inbounds nuw i8, ptr %call137, i64 8
  %path_val145 = load ptr, ptr %variant_field144, align 8
  %call157 = tail call ptr @mesh_env_get_with_default(ptr nonnull @.str.356, ptr nonnull @.str.357)
  %call159 = tail call ptr @mesh_jobs_start_effects_v1(i64 %0, ptr %concat136, ptr nonnull @Main__handle, ptr null, ptr %call157, ptr %path_val145)
  %tag162 = load i8, ptr %call159, align 1
  switch i8 %tag162, label %switch_default163 [
    i8 0, label %case_Ok164
    i8 1, label %case_Err165
  ]

case_Err143:                                      ; preds = %else120
  %variant_field147 = getelementptr inbounds nuw i8, ptr %call137, i64 8
  %path_val148 = load ptr, ptr %variant_field147, align 8
  %variant_val153.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val148, 1
  br label %common.ret

switch_default163:                                ; preds = %case_Ok142
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.358, i64 30, ptr nonnull @.panic_file.359, i64 82, i32 335, i32 16)
  unreachable

case_Ok164:                                       ; preds = %case_Ok142
  %variant_field166 = getelementptr inbounds nuw i8, ptr %call159, i64 8
  %boxed_variant_payload = load ptr, ptr %variant_field166, align 8
  %path_val167 = load i64, ptr %boxed_variant_payload, align 8
  %call177 = tail call ptr @mesh_env_get_with_default(ptr nonnull @.str.360, ptr nonnull @.str.361)
  tail call void @mesh_println(ptr nonnull @.str.362)
  %call17857 = tail call i8 @mesh_process_shutdown_requested()
  %to_bool58 = trunc i8 %call17857 to i1
  br i1 %to_bool58, label %while_merge, label %while_body

case_Err165:                                      ; preds = %case_Ok142
  %variant_field169 = getelementptr inbounds nuw i8, ptr %call159, i64 8
  %path_val170 = load ptr, ptr %variant_field169, align 8
  %variant_val175.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val170, 1
  br label %common.ret

while_body:                                       ; preds = %case_Ok164, %if_merge189
  %str_eq180 = tail call i8 @mesh_string_eq(ptr %call177, ptr nonnull @.str.363)
  %str_eq_bool181 = icmp eq i8 %str_eq180, 0
  br i1 %str_eq_bool181, label %and_rhs, label %if_merge189

while_merge:                                      ; preds = %if_merge189, %case_Ok164
  %call281 = tail call ptr @mesh_jobs_stop(i64 %path_val167, i64 15000)
  %tag284 = load i8, ptr %call281, align 1
  switch i8 %tag284, label %switch_default285 [
    i8 0, label %case_Ok286
    i8 1, label %case_Err287
  ]

and_rhs:                                          ; preds = %while_body
  %concat183 = tail call ptr @mesh_string_concat(ptr %call177, ptr nonnull @.str.364)
  %call184 = tail call i8 @mesh_file_exists(ptr %concat183)
  %to_bool185 = trunc i8 %call184 to i1
  br i1 %to_bool185, label %then187, label %if_merge189

then187:                                          ; preds = %and_rhs
  %call191 = tail call ptr @mesh_jobs_status(i64 %path_val167)
  %tag194 = load i8, ptr %call191, align 1
  switch i8 %tag194, label %switch_default195 [
    i8 0, label %case_Ok196
    i8 1, label %case_Err197
  ]

if_merge189:                                      ; preds = %case_Ok240, %and_rhs, %while_body
  tail call void @mesh_timer_sleep(i64 25)
  tail call void @mesh_reduction_check()
  %call178 = tail call i8 @mesh_process_shutdown_requested()
  %to_bool = trunc i8 %call178 to i1
  br i1 %to_bool, label %while_merge, label %while_body

switch_default195:                                ; preds = %then187
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.365, i64 30, ptr nonnull @.panic_file.366, i64 82, i32 340, i32 20)
  unreachable

case_Ok196:                                       ; preds = %then187
  %variant_field198 = getelementptr inbounds nuw i8, ptr %call191, i64 8
  %path_val199 = load ptr, ptr %variant_field198, align 8
  %concat210 = tail call ptr @mesh_string_concat(ptr %call177, ptr nonnull @.str.367)
  %concat212 = tail call ptr @mesh_string_concat(ptr %call177, ptr nonnull @.str.368)
  %call213 = tail call ptr @mesh_file_rename(ptr %concat210, ptr %concat212)
  %tag216 = load i8, ptr %call213, align 1
  switch i8 %tag216, label %switch_default217 [
    i8 0, label %case_Ok218
    i8 1, label %case_Err219
  ]

case_Err197:                                      ; preds = %then187
  %variant_field201 = getelementptr inbounds nuw i8, ptr %call191, i64 8
  %path_val202 = load ptr, ptr %variant_field201, align 8
  %variant_val207.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val202, 1
  br label %common.ret

switch_default217:                                ; preds = %case_Ok196
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.369, i64 30, ptr nonnull @.panic_file.370, i64 82, i32 341, i32 15)
  unreachable

case_Ok218:                                       ; preds = %case_Ok196
  %concat233 = tail call ptr @mesh_string_concat(ptr %call177, ptr nonnull @.str.371)
  %call235 = tail call ptr @mesh_file_write(ptr %concat233, ptr %path_val199)
  %tag238 = load i8, ptr %call235, align 1
  switch i8 %tag238, label %switch_default239 [
    i8 0, label %case_Ok240
    i8 1, label %case_Err241
  ]

case_Err219:                                      ; preds = %case_Ok196
  %variant_field224 = getelementptr inbounds nuw i8, ptr %call213, i64 8
  %path_val225 = load ptr, ptr %variant_field224, align 8
  %variant_val230.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val225, 1
  br label %common.ret

switch_default239:                                ; preds = %case_Ok218
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.372, i64 30, ptr nonnull @.panic_file.373, i64 82, i32 342, i32 15)
  unreachable

case_Ok240:                                       ; preds = %case_Ok218
  %concat256 = tail call ptr @mesh_string_concat(ptr %call177, ptr nonnull @.str.374)
  %call258 = tail call ptr @mesh_file_rename(ptr %concat256, ptr %call177)
  %tag261 = load i8, ptr %call258, align 1
  switch i8 %tag261, label %switch_default262 [
    i8 0, label %if_merge189
    i8 1, label %case_Err264
  ]

case_Err241:                                      ; preds = %case_Ok218
  %variant_field246 = getelementptr inbounds nuw i8, ptr %call235, i64 8
  %path_val247 = load ptr, ptr %variant_field246, align 8
  %variant_val252.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val247, 1
  br label %common.ret

switch_default262:                                ; preds = %case_Ok240
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.375, i64 30, ptr nonnull @.panic_file.376, i64 82, i32 343, i32 15)
  unreachable

case_Err264:                                      ; preds = %case_Ok240
  %variant_field269 = getelementptr inbounds nuw i8, ptr %call258, i64 8
  %path_val270 = load ptr, ptr %variant_field269, align 8
  %variant_val275.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val270, 1
  br label %common.ret

switch_default285:                                ; preds = %while_merge
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.377, i64 30, ptr nonnull @.panic_file.378, i64 82, i32 348, i32 11)
  unreachable

case_Ok286:                                       ; preds = %while_merge
  %call301 = tail call ptr @mesh_jobs_join(i64 %path_val167)
  %ret_coerce_load = load { i8, ptr }, ptr %call301, align 8
  br label %common.ret

case_Err287:                                      ; preds = %while_merge
  %variant_field291 = getelementptr inbounds nuw i8, ptr %call281, i64 8
  %path_val292 = load ptr, ptr %variant_field291, align 8
  %variant_val297.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val292, 1
  br label %common.ret
}

define { i8, ptr } @Main__run() {
entry:
  %call = tail call ptr @mesh_env_args()
  %length.i = load i64, ptr %call, align 8
  %cmp.not = icmp eq i64 %length.i, 2
  br i1 %cmp.not, label %select_data.i, label %common.ret

common.ret:                                       ; preds = %else35, %else23, %and_rhs15, %entry, %if_merge116, %case_Err, %else76, %then75, %then58
  %common.ret.op = phi { i8, ptr } [ %call61, %then58 ], [ %call78, %then75 ], [ %call81, %else76 ], [ %variant_val109.fca.1.insert, %case_Err ], [ %call118.pn, %if_merge116 ], [ { i8 1, ptr @.str.379 }, %entry ], [ { i8 1, ptr @.str.384 }, %and_rhs15 ], [ { i8 1, ptr @.str.386 }, %else23 ], [ { i8 1, ptr @.str.388 }, %else35 ]
  ret { i8, ptr } %common.ret.op

select_data.i:                                    ; preds = %entry
  %capacity_slot.i = getelementptr i8, ptr %call, i64 8
  %capacity.i = load i64, ptr %capacity_slot.i, align 8
  %owned_data.i = getelementptr i8, ptr %call, i64 16
  %is_view.i = icmp eq i64 %capacity.i, -1
  br i1 %is_view.i, label %list_view.i, label %mesh_list_get.inline.exit

list_view.i:                                      ; preds = %select_data.i
  %parent_word.i = load i64, ptr %owned_data.i, align 8
  %parent.i = inttoptr i64 %parent_word.i to ptr
  %offset_slot.i = getelementptr i8, ptr %call, i64 24
  %offset.i = load i64, ptr %offset_slot.i, align 8
  %parent_data.i = getelementptr i8, ptr %parent.i, i64 16
  %view_data.i = getelementptr i64, ptr %parent_data.i, i64 %offset.i
  br label %mesh_list_get.inline.exit

mesh_list_get.inline.exit:                        ; preds = %select_data.i, %list_view.i
  %data.i = phi ptr [ %owned_data.i, %select_data.i ], [ %view_data.i, %list_view.i ]
  %element.i = getelementptr i8, ptr %data.i, i64 8
  %value.i = load i64, ptr %element.i, align 8
  %i64_to_ptr = inttoptr i64 %value.i to ptr
  %str_eq = tail call i8 @mesh_string_eq(ptr %i64_to_ptr, ptr nonnull @.str.380)
  %str_eq_bool = icmp eq i8 %str_eq, 0
  br i1 %str_eq_bool, label %and_rhs, label %else23

and_rhs:                                          ; preds = %mesh_list_get.inline.exit
  %str_eq7 = tail call i8 @mesh_string_eq(ptr %i64_to_ptr, ptr nonnull @.str.381)
  %str_eq_bool8 = icmp eq i8 %str_eq7, 0
  br i1 %str_eq_bool8, label %and_rhs9, label %else23

and_rhs9:                                         ; preds = %and_rhs
  %str_eq12 = tail call i8 @mesh_string_eq(ptr %i64_to_ptr, ptr nonnull @.str.382)
  %str_eq_bool13 = icmp eq i8 %str_eq12, 0
  br i1 %str_eq_bool13, label %and_rhs15, label %else23

and_rhs15:                                        ; preds = %and_rhs9
  %str_eq18 = tail call i8 @mesh_string_eq(ptr %i64_to_ptr, ptr nonnull @.str.383)
  %str_eq_bool19 = icmp eq i8 %str_eq18, 0
  br i1 %str_eq_bool19, label %common.ret, label %else23

else23:                                           ; preds = %and_rhs9, %mesh_list_get.inline.exit, %and_rhs, %and_rhs15
  %call30 = tail call ptr @mesh_regex_from_literal(ptr nonnull @.str.385, i64 0)
  %call.i = tail call ptr @mesh_env_get_with_default(ptr nonnull @.str.2, ptr nonnull @.str.3)
  tail call void @mesh_reduction_check()
  %call32 = tail call i8 @mesh_regex_match(ptr %call30, ptr %call.i)
  %to_bool = trunc i8 %call32 to i1
  br i1 %to_bool, label %else35, label %common.ret

else35:                                           ; preds = %else23
  %call.i18 = tail call ptr @mesh_env_get_with_default(ptr nonnull @.str, ptr nonnull @.str.1)
  tail call void @mesh_reduction_check()
  %str_eq43 = tail call i8 @mesh_string_eq(ptr %call.i18, ptr nonnull @.str.387)
  %str_eq_bool44.not = icmp eq i8 %str_eq43, 0
  br i1 %str_eq_bool44.not, label %else47, label %common.ret

else47:                                           ; preds = %else35
  %str_eq55 = tail call i8 @mesh_string_eq(ptr %i64_to_ptr, ptr nonnull @.str.389)
  %str_eq_bool56.not = icmp eq i8 %str_eq55, 0
  br i1 %str_eq_bool56.not, label %else59, label %then58

then58:                                           ; preds = %else47
  %call61 = tail call { i8, ptr } @Main__session()
  tail call void @mesh_reduction_check()
  br label %common.ret

else59:                                           ; preds = %else47
  %str_eq64 = tail call i8 @mesh_string_eq(ptr %i64_to_ptr, ptr nonnull @.str.390)
  %str_eq_bool65.not = icmp eq i8 %str_eq64, 0
  br i1 %str_eq_bool65.not, label %else68, label %then67

then67:                                           ; preds = %else59
  %call70 = tail call ptr @mesh_env_get_with_default(ptr nonnull @.str.391, ptr nonnull @.str.392)
  %str_eq72 = tail call i8 @mesh_string_eq(ptr %call70, ptr nonnull @.str.393)
  %str_eq_bool73.not = icmp eq i8 %str_eq72, 0
  br i1 %str_eq_bool73.not, label %else76, label %then75

else68:                                           ; preds = %else59
  %call83 = tail call ptr @mesh_env_get_with_default(ptr nonnull @.str.394, ptr nonnull @.str.395)
  %str_eq85 = tail call i8 @mesh_string_eq(ptr %i64_to_ptr, ptr nonnull @.str.396)
  %str_eq_bool86.not = icmp eq i8 %str_eq85, 0
  br i1 %str_eq_bool86.not, label %else95, label %and_rhs87

then75:                                           ; preds = %then67
  %call78 = tail call { i8, ptr } @Main__enqueue_stream()
  tail call void @mesh_reduction_check()
  br label %common.ret

else76:                                           ; preds = %then67
  %call81 = tail call { i8, ptr } @Main__enqueue(ptr %call70)
  tail call void @mesh_reduction_check()
  br label %common.ret

and_rhs87:                                        ; preds = %else68
  %str_eq90 = tail call i8 @mesh_string_eq(ptr %call83, ptr nonnull @.str.397)
  %str_eq_bool91 = icmp eq i8 %str_eq90, 0
  br i1 %str_eq_bool91, label %if_merge96, label %else95

else95:                                           ; preds = %else68, %and_rhs87
  %call.i19 = tail call ptr @mesh_env_get_with_default(ptr nonnull @.str, ptr nonnull @.str.1)
  tail call void @mesh_reduction_check()
  br label %if_merge96

if_merge96:                                       ; preds = %and_rhs87, %else95
  %.0 = phi ptr [ %call.i19, %else95 ], [ %call83, %and_rhs87 ]
  %call101 = tail call ptr @mesh_pool_open(ptr %.0, i64 1, i64 1, i64 5000)
  %tag = load i8, ptr %call101, align 1
  switch i8 %tag, label %switch_default [
    i8 0, label %case_Ok
    i8 1, label %case_Err
  ]

switch_default:                                   ; preds = %if_merge96
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.398, i64 30, ptr nonnull @.panic_file.399, i64 82, i32 377, i32 14)
  unreachable

case_Ok:                                          ; preds = %if_merge96
  %variant_field = getelementptr inbounds nuw i8, ptr %call101, i64 8
  %boxed_variant_payload = load ptr, ptr %variant_field, align 8
  %path_val = load i64, ptr %boxed_variant_payload, align 8
  %str_eq111 = tail call i8 @mesh_string_eq(ptr %i64_to_ptr, ptr nonnull @.str.400)
  %str_eq_bool112.not = icmp eq i8 %str_eq111, 0
  br i1 %str_eq_bool112.not, label %else115, label %then114

case_Err:                                         ; preds = %if_merge96
  %variant_field103 = getelementptr inbounds nuw i8, ptr %call101, i64 8
  %path_val104 = load ptr, ptr %variant_field103, align 8
  %variant_val109.fca.1.insert = insertvalue { i8, ptr } { i8 1, ptr poison }, ptr %path_val104, 1
  br label %common.ret

then114:                                          ; preds = %case_Ok
  %call118 = tail call { i8, ptr } @Main__migrate(i64 %path_val)
  br label %if_merge116

else115:                                          ; preds = %case_Ok
  %call120 = tail call { i8, ptr } @Main__serve(i64 %path_val)
  br label %if_merge116

if_merge116:                                      ; preds = %else115, %then114
  %call118.pn = phi { i8, ptr } [ %call118, %then114 ], [ %call120, %else115 ]
  tail call void @mesh_reduction_check()
  tail call void @mesh_pool_close(i64 %path_val)
  br label %common.ret
}

define {} @mesh_main() {
entry:
  %call = tail call { i8, ptr } @Main__run()
  tail call void @mesh_reduction_check()
  %call.fca.0.extract = extractvalue { i8, ptr } %call, 0
  %call.fca.1.extract = extractvalue { i8, ptr } %call, 1
  switch i8 %call.fca.0.extract, label %switch_default [
    i8 0, label %case_Ok
    i8 1, label %case_Err
  ]

switch_default:                                   ; preds = %entry
  tail call void @mesh_panic_at(ptr nonnull @.panic_msg.402, i64 30, ptr nonnull @.panic_file.403, i64 82, i32 384, i32 3)
  unreachable

case_Ok:                                          ; preds = %entry
  tail call void @mesh_println(ptr %call.fca.1.extract)
  ret {} zeroinitializer

case_Err:                                         ; preds = %entry
  %concat = tail call ptr @mesh_string_concat(ptr nonnull @.str.401, ptr %call.fca.1.extract)
  tail call void @mesh_io_eprintln(ptr %concat)
  tail call void @mesh_process_exit(i64 1)
  unreachable
}

define noundef i32 @main(i32 %0, ptr %1) local_unnamed_addr {
entry:
  tail call void @mesh_rt_disable_core_dumps()
  tail call void @mesh_rt_init()
  tail call void @mesh_rt_init_actor(i32 0)
  tail call void @mesh_register_function(ptr nonnull @fn_reg_Main__database_url, i64 18, ptr nonnull @Main__database_url, ptr null, i64 0)
  tail call void @mesh_register_function(ptr nonnull @fn_reg_Main__namespace, i64 15, ptr nonnull @Main__namespace, ptr null, i64 0)
  tail call void @mesh_register_function(ptr nonnull @fn_reg_Main__migrate, i64 13, ptr nonnull @Main__migrate, ptr nonnull @fn_sig_Main__serve, i64 1)
  tail call void @mesh_register_function(ptr nonnull @fn_reg_Main__job_spec, i64 14, ptr nonnull @Main__job_spec, ptr nonnull @fn_sig_Main__serve, i64 1)
  tail call void @mesh_register_function(ptr nonnull @fn_reg_Main__collect_specs, i64 19, ptr nonnull @Main__collect_specs, ptr nonnull @fn_sig_Main__write_batch, i64 5)
  tail call void @mesh_register_function(ptr nonnull @fn_reg_Main__collect_ids, i64 17, ptr nonnull @Main__collect_ids, ptr nonnull @fn_sig_Main__collect_ids, i64 6)
  tail call void @mesh_register_function(ptr nonnull @fn_reg_Main__enqueue_specs, i64 19, ptr nonnull @Main__enqueue_specs, ptr nonnull @fn_sig_Main__finish_batch, i64 3)
  tail call void @mesh_register_function(ptr nonnull @fn_reg_Main__enqueue_batches, i64 21, ptr nonnull @Main__enqueue_batches, ptr nonnull @fn_sig_Main__write_batch, i64 5)
  tail call void @mesh_register_function(ptr nonnull @fn_reg_Main__transaction_id, i64 20, ptr nonnull @Main__transaction_id, ptr nonnull @fn_sig_Main__serve, i64 1)
  tail call void @mesh_register_function(ptr nonnull @fn_reg_Main__write_batch, i64 17, ptr nonnull @Main__write_batch, ptr nonnull @fn_sig_Main__write_batch, i64 5)
  tail call void @mesh_register_function(ptr nonnull @fn_reg_Main__finish_batch, i64 18, ptr nonnull @Main__finish_batch, ptr nonnull @fn_sig_Main__finish_batch, i64 3)
  tail call void @mesh_register_function(ptr nonnull @fn_reg_Main__transact_batch, i64 20, ptr nonnull @Main__transact_batch, ptr nonnull @fn_sig_Main__perform, i64 2)
  tail call void @mesh_register_function(ptr nonnull @fn_reg_Main__read_batch, i64 16, ptr nonnull @Main__read_batch, ptr nonnull @fn_sig_Main__serve, i64 1)
  tail call void @mesh_register_function(ptr nonnull @fn_reg_Main__enqueue, i64 13, ptr nonnull @Main__enqueue, ptr nonnull @fn_sig_Main__serve, i64 1)
  tail call void @mesh_register_function(ptr nonnull @fn_reg_Main__enqueue_paths, i64 19, ptr nonnull @Main__enqueue_paths, ptr null, i64 0)
  tail call void @mesh_register_function(ptr nonnull @fn_reg_Main__enqueue_stream, i64 20, ptr nonnull @Main__enqueue_stream, ptr null, i64 0)
  tail call void @mesh_register_function(ptr nonnull @fn_reg_Main__wait_mark, i64 15, ptr nonnull @Main__wait_mark, ptr nonnull @fn_sig_Main__serve, i64 1)
  tail call void @mesh_register_function(ptr nonnull @fn_reg_Main__effect_result, i64 19, ptr nonnull @Main__effect_result, ptr nonnull @fn_sig_Main__perform, i64 2)
  tail call void @mesh_register_function(ptr nonnull @fn_reg_Main__complete, i64 14, ptr nonnull @Main__complete, ptr null, i64 0)
  tail call void @mesh_register_function(ptr nonnull @fn_reg_Main__perform, i64 13, ptr nonnull @Main__perform, ptr nonnull @fn_sig_Main__perform, i64 2)
  tail call void @mesh_register_function(ptr nonnull @fn_reg_Main__handle, i64 12, ptr nonnull @Main__handle, ptr nonnull @fn_sig_Main__serve, i64 1)
  tail call void @mesh_register_function(ptr nonnull @fn_reg_Main__session_loop, i64 18, ptr nonnull @Main__session_loop, ptr nonnull @fn_sig_Main__serve, i64 1)
  tail call void @mesh_register_function(ptr nonnull @fn_reg_Main__session, i64 13, ptr nonnull @Main__session, ptr null, i64 0)
  tail call void @mesh_register_function(ptr nonnull @fn_reg_Main__serve, i64 11, ptr nonnull @Main__serve, ptr nonnull @fn_sig_Main__serve, i64 1)
  tail call void @mesh_register_function(ptr nonnull @fn_reg_Main__run, i64 9, ptr nonnull @Main__run, ptr null, i64 0)
  tail call void @mesh_register_function(ptr nonnull @fn_reg_mesh_main, i64 9, ptr nonnull @mesh_main, ptr null, i64 0)
  tail call void @mesh_jobs_register_handler(ptr nonnull @jobs_handler_Main__handle, i64 29, ptr nonnull @Main__handle)
  tail call void @mesh_jobs_enter_worker(i32 %0, ptr %1)
  tail call void @mesh_run_main(ptr nonnull @mesh_main)
  tail call void @mesh_rt_run_scheduler()
  ret i32 0
}

attributes #0 = { noreturn }
attributes #1 = { mustprogress nofree norecurse nosync nounwind willreturn memory(none) }
