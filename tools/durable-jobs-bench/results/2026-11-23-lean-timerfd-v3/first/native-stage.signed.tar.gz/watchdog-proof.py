"""Fault replay using the real compiled handler, with a private wire relay."""
from array import array
from contextlib import contextmanager
import ctypes
import json
import os
from pathlib import Path
import resource
import select
import signal
import socket
import struct
import subprocess
import sys
import time

from component import ENV, SELECTOR, attempt, boot_ms, frame, receive, usage, witness


def wait_until(cutoff):
    while (left := cutoff - boot_ms()) > 0:
        time.sleep(left / 1000)


def clock_snapshot():
    return {"boot_ms": boot_ms(), "monotonic_ns": time.monotonic_ns()}


def readable(pidfd, timeout_ms):
    poller = select.poll()
    poller.register(pidfd, select.POLLIN)
    return bool(poller.poll(timeout_ms))


@contextmanager
def launch(image, fingerprint, case, hard_ms, lease_ms, hold_ms):
    control, control_child = socket.socketpair()
    effect, effect_child = socket.socketpair()
    with control, control_child, effect, effect_child:
        control.settimeout(3)
        effect.settimeout(3)
        proc = subprocess.Popen([str(image), SELECTOR], stdin=control_child, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, process_group=0, env=ENV)
        control_child.close()
        try:
            control.sendmsg([b"\1"], [(socket.SOL_SOCKET, socket.SCM_RIGHTS,
                                       array("i", [effect_child.fileno()]))])
            effect_child.close()
            now = boot_ms()
            clocks = clock_snapshot()
            hard, lease = now + hard_ms, now + lease_ms
            request = dict(handler=fingerprint, deadline=hard, lease_deadline=lease)
            context = dict(attempt=1, args=dict(key=case, payload="protected", hold_ms=hold_ms,
                                               fail_first=False))
            control.sendall(frame(request) + frame(context))
            with effect.makefile("rb") as stream:
                yield proc, control, effect, stream, hard, lease, clocks
        finally:
            if proc.returncode is None:
                try:
                    os.killpg(proc.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                proc.wait(timeout=3)
            proc.stdout.close()
            proc.stderr.close()


def effect_request(proc, stream, case, after, *, name="first"):
    req = receive(stream)
    assert req["name"] == name and req["values"][0] == case, (case, req)
    if name == "first":
        assert req["values"][2:] == [proc.pid, False], req
    else:
        assert req["values"] == [case, False], req
    # PG wire deadlines use CLOCK_MONOTONIC nanoseconds. The watchdog
    # separately takes integer CLOCK_BOOTTIME milliseconds in control frames.
    assert after <= req["deadline"] <= time.monotonic_ns() + 30_000_000_000, req
    return req


def reap(proc, expected):
    with os.fdopen(os.pidfd_open(proc.pid), "rb", closefd=True) as pidfd:
        assert readable(pidfd, 3000), ("worker did not exit", proc.pid)
    pid, status, stats = os.wait4(proc.pid, 0)
    proc.returncode = os.waitstatus_to_exitcode(status)
    assert pid == proc.pid and proc.returncode == expected, (pid, proc.returncode, proc.stderr.read())
    reply = proc.stdout.read()
    if expected:
        assert reply == b"", reply
    else:
        from io import BytesIO
        result = receive(BytesIO(reply))
        assert json.loads(result["Ok"]) == {"action": "complete"}, result
    return {"pid": pid, "exit": proc.returncode, "clock_at_reap": clock_snapshot(), **usage(stats)}


SCENARIOS = {
    # The parameters are hard deadline, initial lease and the real handler sleep.
    "expired-before-entry": (1800, -10, 1500),
    "fragment-renews": (1600, 450, 620),
    "late-renew-queued": (1700, 350, 1400),
    "old-renew-ignored": (1800, 400, 1400),
    "partial-renew-expires": (1800, 400, 1400),
    "cancel-by-eof": (1800, 1400, 1200),
    "hard-deadline-blocked": (440, 1400, 1200),
}


def fault(image, fingerprint, case):
    with launch(image, fingerprint, case, *SCENARIOS[case]) as fields:
        proc, control, effect, stream, hard, lease, start = fields
        records = {"case": case, "start": start, "hard_ms": hard, "lease_ms": lease, "effects": []}
        if case == "expired-before-entry":
            assert receive(stream) is None
            return {**records, **reap(proc, 172)}
        records["effects"].append(effect_request(proc, stream, case, start["monotonic_ns"]))
        effect.sendall(b"\1")
        if case == "fragment-renews":
            renewal = struct.pack("<Q", lease + 650)
            control.sendall(renewal[:3])
            time.sleep(0.025)
            control.sendall(renewal[3:])
            records["effects"].append(effect_request(proc, stream, case, start["monotonic_ns"], name="second"))
            effect.sendall(b"\1")
            records["second_boottime_ms"] = boot_ms()
            assert records["second_boottime_ms"] > lease
            code = 0
        elif case == "late-renew-queued":
            # Stop the entire worker process after the first effect. Put a full
            # renewal on the private stream so data and expiry are both ready.
            os.kill(proc.pid, signal.SIGSTOP)
            pid, stopped = os.waitpid(proc.pid, os.WUNTRACED)
            assert pid == proc.pid and os.WIFSTOPPED(stopped)
            control.sendall(struct.pack("<Q", hard + 1000))
            wait_until(lease + 40)
            records["resumed_boottime_ms"] = boot_ms()
            os.kill(proc.pid, signal.SIGCONT)
            code = 172
        elif case == "old-renew-ignored":
            control.sendall(struct.pack("<QQQ", 0, lease - 100, lease))
            code = 172
        elif case == "partial-renew-expires":
            control.sendall(struct.pack("<Q", hard + 1000)[:7])
            code = 172
        elif case == "cancel-by-eof":
            control.sendall(b"\x01\x02\x03")
            control.shutdown(socket.SHUT_WR)
            code = 173
        else:
            control.sendall(struct.pack("<Q", hard + 4000))
            # Interrupt poll without requesting worker termination. The same
            # process signal handler is installed for regular Jobs workers.
            tasks = Path(f"/proc/{proc.pid}/task")
            tids = [int(task.name) for task in tasks.iterdir() if int(task.name) != proc.pid]
            assert len(tids) == 1, tids
            assert ctypes.CDLL(None).tgkill(proc.pid, tids[0], signal.SIGTERM) == 0
            code = 171
        assert receive(stream) is None
        row = reap(proc, code)
        at = row["clock_at_reap"]["boot_ms"]
        if case != "expired-before-entry" and code in (171, 172):
            cutoff = min(hard, lease)
            assert cutoff <= at <= cutoff + 900, (case, cutoff, row)
        return {**records, **row}


def suspended_owner(image, fingerprint, output):
    # The broker process owns the control socket and performs the actual
    # consuming wait. The outer observer holds only a pidfd, never the socket.
    read_fd, write_fd = os.pipe()
    owner = os.fork()
    if owner == 0:
        os.close(read_fd)
        result = 1
        try:
            with launch(image, fingerprint, "suspended-owner", 520, 1800, 1500) as fields:
                proc, _, effect, stream, hard, _, start = fields
                effect_request(proc, stream, "suspended-owner", start["monotonic_ns"])
                effect.sendall(b"\1")
                os.write(write_fd, f"{proc.pid} {hard}\n".encode())
                os.close(write_fd)
                assert receive(stream) is None
                output.write_text(json.dumps(reap(proc, 171)) + "\n")
                result = 0
        finally:
            os._exit(result)
    os.close(write_fd)
    observed = None
    try:
        with os.fdopen(read_fd, "rb") as stream:
            wait = select.poll()
            wait.register(stream, select.POLLIN)
            assert wait.poll(3000), "owner failed to start worker"
            pid, deadline = map(int, stream.readline().split())
        pidfd = os.pidfd_open(pid)
        try:
            os.kill(owner, signal.SIGSTOP)
            got, status = os.waitpid(owner, os.WUNTRACED)
            assert got == owner and os.WIFSTOPPED(status)
            stopped_at = boot_ms()
            assert stopped_at < deadline and not readable(pidfd, 0)
            assert readable(pidfd, 1500), "worker survived while the owner was stopped"
            observed = {"owner": owner, "pid": pid, "deadline": deadline, "stopped_at": stopped_at,
                        "observed_child_exit_at": boot_ms()}
            assert observed["observed_child_exit_at"] >= deadline
        finally:
            os.close(pidfd)
            os.kill(owner, signal.SIGCONT)
        got, status = os.waitpid(owner, 0)
        assert got == owner and os.waitstatus_to_exitcode(status) == 0
        return {**observed, "reap": json.loads(output.read_text())}
    finally:
        try:
            waited, _ = os.waitpid(owner, os.WNOHANG)
            if not waited:
                os.kill(owner, signal.SIGKILL)
                os.waitpid(owner, 0)
        except ChildProcessError:
            pass


def main(build, output):
    assert os.getuid() != 0
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    fingerprint = json.loads((build / "closure.json").read_text())["fingerprint"]
    image = build / "mesh-lean-worker"
    with output.open("x") as log:
        def retain(row):
            print(json.dumps(row, ensure_ascii=False), file=log, flush=True)

        os.environ["MESH_EFFECT_APP_URL"] = "fixture-private-parent-only"
        with open("/dev/null", "rb") as unused:
            assert not os.get_inheritable(unused.fileno())
            retain({"case": "constructors-tls-aslr", "rows": witness(build / "mesh-lean-witness", fingerprint)})
        for case in SCENARIOS:
            retain(fault(image, fingerprint, case))
        retain({"case": "suspended-owner", **suspended_owner(image, fingerprint, output.with_suffix(".owner.json"))})
        for case in ("handler-error", "unknown-commit"):
            retain({"case": case, **attempt(image, fingerprint, case, None, fault=case)})


if __name__ == "__main__":
    main(*(Path(arg) for arg in sys.argv[1:]))
