#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <inttypes.h>
#include <time.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/resource.h>
#include <sys/syscall.h>
#include <sys/wait.h>
#include <unistd.h>

static void record(pid_t child, int code, int status, const struct rusage *usage) {
    int result_errno = errno;
    const char *directory = getenv("MESH_LEAN_REAP_LOG");
    if (directory != NULL) {
        char path[PATH_MAX];
        int length = snprintf(path, sizeof(path), "%s", directory);
        if (length > 0 && length < (int)sizeof(path)) {
            int output = open(path, O_APPEND | O_CREAT | O_WRONLY | O_CLOEXEC, 0600);
            if (output >= 0) {
                long user = usage->ru_utime.tv_sec * 1000000L + usage->ru_utime.tv_usec;
                long system = usage->ru_stime.tv_sec * 1000000L + usage->ru_stime.tv_usec;
                char line[256];
                struct timespec wall;
                clock_gettime(CLOCK_REALTIME, &wall);
                uint64_t epoch_us = (uint64_t)wall.tv_sec * 1000000 + wall.tv_nsec / 1000;
                length = snprintf(line, sizeof(line), "%d %d %d %d %ld %ld %ld %ld %ld %" PRIu64 "\n",
                                  getpid(), child, code, status, user, system, usage->ru_minflt,
                                  usage->ru_majflt, usage->ru_maxrss, epoch_us);
                if (length > 0 && length < (int)sizeof(line)) {
                    if (write(output, line, length) != length) {
                        dprintf(2, "exact wait receipt write failed for %ld\n", (long)child);
                    }
                }
                close(output);
            }
        }
    }
    errno = result_errno;
}

pid_t waitpid(pid_t pid, int *status, int flags) {
    int result_status;
    struct rusage usage = {0};
    pid_t result = wait4(pid, &result_status, flags, &usage);
    if (result > 0) {
        if (status != NULL) *status = result_status;
        if (WIFEXITED(result_status) || WIFSIGNALED(result_status)) record(result, WIFEXITED(result_status) ? CLD_EXITED : CLD_KILLED,
                   WIFEXITED(result_status) ? WEXITSTATUS(result_status) : WTERMSIG(result_status), &usage);
    }
    return result;
}

int waitid(idtype_t type, id_t id, siginfo_t *info, int flags) {
    struct rusage usage = {0};
    int result = (int)syscall(SYS_waitid, type, id, info, flags, &usage);
    if (result == 0 && info != NULL && info->si_pid > 0 && !(flags & WNOWAIT) &&
        (info->si_code == CLD_EXITED || info->si_code == CLD_KILLED || info->si_code == CLD_DUMPED)) {
        record(info->si_pid, info->si_code, info->si_status, &usage);
    }
    return result;
}
