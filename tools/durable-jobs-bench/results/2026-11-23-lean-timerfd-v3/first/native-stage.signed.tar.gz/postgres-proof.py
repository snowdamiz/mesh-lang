"""Run the frozen compiler fixture with its real fenced PostgreSQL sessions."""
from contextlib import ExitStack
import json
import os
from pathlib import Path
import re
import shutil
import signal
import sys
import tempfile
import time

COMBINED_SOURCE = os.environ.get("LEAN_ADMISSION_PROOF_SOURCE")
STOCK_SOURCE = Path(COMBINED_SOURCE or "/var/lib/durable-jobs-bench/native/source-stock-3828f20d")
sys.path.insert(0, str(STOCK_SOURCE / "tools/durable-jobs-bench/native"))
import arm

PROFILE = "lean_proof"


class Cluster(arm.Cluster):
    def configure_tls(self):
        super().configure_tls()
        with (self.data / "postgresql.conf").open("a") as config:
            config.write("log_statement = 'all'\nlog_line_prefix = '%m [%p] %u %x '\n")


def read_pid(path):
    try:
        value = path.read_text()
        return int(value) if value.isdecimal() else None
    except FileNotFoundError:
        return None


def reset_count(cluster):
    return int(cluster.sql("mesh", f"""
      SELECT coalesce(sum(s.calls), 0) FROM pg_stat_statements s
      JOIN pg_roles r ON r.oid = s.userid
      WHERE r.rolname = 'compiled_caller' AND rtrim(s.query, ';') = 'DISCARD ALL'
    """))


def job(cluster, key):
    assert re.fullmatch(r"proof_[0-9]+", key)
    raw = cluster.sql("mesh", f"""
     SELECT row_to_json(t) FROM (
       SELECT id::text, attempt, state, xmin::text AS xid,
              (extract(epoch FROM pg_xact_commit_timestamp(xmin))*1000000)::bigint AS committed_us
       FROM mesh_jobs.jobs WHERE namespace = '{PROFILE}' AND args->>'key' = '{key}'
     ) t
    """)
    return json.loads(raw)


def effects(cluster, identity):
    assert re.fullmatch(r"[0-9a-f-]{36}", identity)
    raw = cluster.sql("mesh", f"""
     SELECT coalesce(json_agg(t ORDER BY t.step), '[]') FROM (
       SELECT 1 AS step, worker_pid, backend, xmin::text AS xid,
              (extract(epoch FROM entered_at)*1000000)::bigint AS entered_us,
              (extract(epoch FROM pg_xact_commit_timestamp(xmin))*1000000)::bigint AS committed_us
       FROM public.mesh_jobs_parity_attempts WHERE job_id = '{identity}'::uuid
       UNION ALL
       SELECT 2, NULL, backend, xmin::text, NULL,
              (extract(epoch FROM pg_xact_commit_timestamp(xmin))*1000000)::bigint
       FROM public.mesh_jobs_parity_effects WHERE job_id = '{identity}'::uuid
     ) t
    """)
    return json.loads(raw)


def pid_facts(pid, owner):
    fields = Path(f"/proc/{pid}/stat").read_text().rsplit(")", 1)[1].split()
    assert int(fields[1]) == owner and int(fields[2]) == pid
    argv = Path(f"/proc/{pid}/cmdline").read_bytes().rstrip(b"\0").split(b"\0")
    assert argv[1:] == [b"--mesh-internal-job-attempt-effect-v1"]
    return {"pid": pid, "ppid": owner, "pgrp": int(fields[2]), "start_ticks": int(fields[19]),
            "argv0": os.fsdecode(argv[0])}


def run(build, reap, out):
    out.mkdir()
    temp = tempfile.TemporaryDirectory(dir=out.parent, prefix="protected-pg-")
    cluster = Cluster(Path(temp.name), out, 8)
    cluster.runners = 1
    cluster.slots = 2
    cluster.lanes = 1
    cluster.hold_ms = 0

    try:
        stage = Path(temp.name) / "candidate"
        stage.mkdir()
        mesh = stage / "mesh"
        companion = stage / "mesh-lean-worker"
        shutil.copy2(build / "mesh-witness-runner", mesh)
        shutil.copy2(build / "mesh-lean-witness", companion)
        cluster.start()
        cluster.prepare_database("mesh")
        env = dict(cluster.env, MESH_SCHEDULER_MIN_WORKERS="2", MESH_SCHEDULER_MAX_WORKERS="2",
                   JOBS_PARITY_MESH_BATCH="1", JOBS_PARITY_MESH_LISTEN="1",
                   MESH_EFFECT_LANES="1", MESH_EFFECT_APP_URL=cluster.url("mesh", "compiled_caller"),
                   MESH_DIAGNOSTIC_JOB_DISABLE_THP="1")
        if COMBINED_SOURCE:
            env["MESH_JOBS_ADMISSION_V3"] = "strict"
        subject = arm.Subject("mesh", [str(mesh)], stage, cluster, env)
        args = subject.environment(PROFILE, 2, 2, "sparse", 30)
        subject.call("migrate", args, out / "migrate.log")
        trace = out / "reaps.tsv"
        trace.touch()
        records = []
        # Check an immutable pinned image and then a fresh runner with a
        # mismatched sidecar that must start an ordinary full worker.
        for phase, group in enumerate(((1, 2, 3), (4,)), 1):
            if phase == 2:
                companion.write_bytes(b"mismatch")
            runner_log = out / f"runner-{phase}.log"
            owner = subject.run(dict(args, LD_PRELOAD=str(reap), MESH_LEAN_REAP_LOG=str(trace)),
                                phase, runner_log)
            try:
                deadline = time.monotonic() + 30

                def wait(check, label):
                    assert owner.poll() is None, runner_log
                    return arm.h.wait_for(check, deadline, label, interval=0.01)

                wait(lambda: "READY" in runner_log.read_text(), "runner admission")
                if phase == 1:
                    # Replace the source pathname after admission. The tried
                    # executable is still the authenticated sealed image.
                    companion.unlink()
                    companion.write_bytes(b"replacement after ready")
                sessions = json.loads(cluster.sql("mesh", """
                    SELECT json_agg(json_build_object('role', a.usename, 'pid', a.pid, 'tls', s.ssl))
                    FROM pg_stat_activity a JOIN pg_stat_ssl s USING (pid)
                    WHERE a.datname = current_database()
                      AND a.usename IN ('parity_subject', 'compiled_caller')
                """))
                assert {row["role"] for row in sessions} == {"parity_subject", "compiled_caller"}
                assert all(row["tls"] for row in sessions)
                arm.h.write_json(out / f"postgres-tls-{phase}.json", sessions)
                resets = reset_count(cluster)

                def enqueue(indices):
                    cases = []
                    for i in indices:
                        parent = stage / f"marks-{i}"
                        marks = parent / "1"
                        marks.mkdir(parents=True)
                        key = f"proof_{i}"
                        cases.append((i, marks, key, dict(key=key, payload="témoin 🌐", hold_ms=30,
                                                        fail_first=False, proof_path=str(parent))))
                    payload = stage / f"controlled-{indices[0]}.json"
                    payload.write_text(json.dumps(dict(jobs=[case[3] for case in cases],
                                                       request_id=payload.stem, rollback=False)))
                    receipt, _ = subject.enqueue_receipt(args, payload, out / (payload.stem + ".log"))
                    return [(i, marks, key, receipt["ids"][key]) for i, marks, key, _ in cases]

                groups = [group[:2], group[2:]] if len(group) == 3 else [group]
                for group_indices in groups:
                    cases = enqueue(group_indices)
                    with ExitStack() as resources:
                        held = []
                        for i, marks, key, identity in cases:
                            pid = wait(lambda: read_pid(marks / "worker"), "exact handler PID")
                            resources.callback(os.close, os.pidfd_open(pid))
                            observed = pid_facts(pid, owner.pid)
                            assert observed["argv0"].startswith("/proc/self/fd/") == (phase == 1)
                            claim = job(cluster, key)
                            assert claim["state"] == "executing" and claim["id"] == identity
                            assert claim["attempt"] == 1 and claim["committed_us"] is not None
                            assert effects(cluster, identity) == []
                            held.append((marks, key, identity, observed, claim))
                        assert len({item[3]["pid"] for item in held}) == len(held)
                        for marks, key, identity, observed, claim in held:
                            (marks / "call").touch()
                            wait((marks / "first").exists, "first committed and acknowledged")
                            first, = effects(cluster, identity)
                            assert first["worker_pid"] == observed["pid"]
                            assert claim["committed_us"] <= first["entered_us"] <= first["committed_us"]
                            assert json.loads((marks / "first").read_text())["outcome"] == "applied"
                            assert reset_count(cluster) == resets + 1
                            (marks / "second-call").touch()
                            wait((marks / "second").exists, "second committed and acknowledged")
                            first_again, second = effects(cluster, identity)
                            assert first == first_again and first["backend"] == second["backend"]
                            assert (marks / "second").read_text() == "applied"
                            assert reset_count(cluster) == resets + 2
                            resets += 2
                            (marks / "finish").touch()

                            def terminal():
                                observed_job = job(cluster, key)
                                return observed_job if observed_job["state"] == "completed" else None

                            done = wait(terminal, "durably completed after reap")
                            matching = [list(map(int, line.split())) for line in trace.read_text().splitlines()
                                        if int(line.split()[1]) == observed["pid"]]
                            reaped, = matching
                            assert reaped[:4] == [owner.pid, observed["pid"], 1, 0]
                            order = [claim["committed_us"], first["committed_us"],
                                     second["committed_us"], reaped[-1], done["committed_us"]]
                            assert order == sorted(order) and len(set(order)) == len(order), order
                            assert len({row["xid"] for row in (claim, first, second, done)}) == 4
                            lines = [line for line in runner_log.read_text().splitlines()
                                     if re.match(fr"LEAN_(?:CTOR_[AB]|THREAD_TLS|HANDLER) {observed['pid']}\b", line)]
                            if phase == 1:
                                assert len(lines) == 4 and all(line.startswith(prefix)
                                    for line, prefix in zip(lines, ("LEAN_CTOR_A", "LEAN_CTOR_B",
                                                                   "LEAN_THREAD_TLS", "LEAN_HANDLER")))
                            else:
                                assert not lines
                            records.append(dict(claim=claim, effects=[first, second], reap=reaped,
                                                settled=done, exec=observed, witness=lines, resets=resets))
                            (out / "joined-evidence.json").write_text(json.dumps(records, indent=2) + "\n")
            finally:
                arm.h.stop_runners([owner], require_clean=sys.exc_info()[0] is None)
        assert len(records) == 4 and len({row["exec"]["pid"] for row in records}) == 4
        if COMBINED_SOURCE:
            counts = json.loads(cluster.sql("mesh", """
                SELECT json_build_object(
                    'admitted_claims', coalesce(sum(calls) FILTER (WHERE query LIKE '%FROM mesh_jobs.claim_admitted_v3(%'), 0),
                    'cohort_completions', coalesce(sum(calls) FILTER (WHERE query LIKE '%FROM mesh_jobs.complete_admitted_v3(%'), 0))
                FROM pg_stat_statements WHERE userid = 'parity_subject'::regrole
            """))
            assert counts["admitted_claims"] > 0 and counts["cohort_completions"] == 0, counts
            arm.h.write_json(out / "strict-admission-proof.json", counts)
        print("Fenced PostgreSQL, compiler handler, sealed exec, constructor/TLS, exact reaps, and fallback passed.")
    finally:
        cluster.stop()
        arm.redact(out, cluster.password)
        temp.cleanup()


if __name__ == "__main__":
    def terminate(signum, frame):
        raise SystemExit(128 + signum)

    signal.signal(signal.SIGTERM, terminate)
    run(*(Path(arg).resolve() for arg in sys.argv[1:]))
