"""Specialize the pinned Jobs fixture. A rejected closure has no lean image."""
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import subprocess

HERE = Path(__file__).resolve().parent
SYMBOL = re.compile(r"@([-.$\w]+)")
FUNCTION = re.compile(r"^define [^\n]+\{\n.*?^}\n", re.M | re.S)
GLOBAL = re.compile(r"^@([-.$\w]+) = ([^\n]+)", re.M)
DECLARATION = re.compile(r"^declare [^\n]+@([-.$\w]+)\(", re.M)
CALL = re.compile(r"^\s+(?:%[-.$\w]+ = )?(?:(?:musttail|tail|notail) )?(?:call|invoke|callbr)\s")
DIRECT_CALL = re.compile(CALL.pattern + r"[^(@]*@([-.$\w]+)\(")
REGISTRATION = re.compile(r"^  (?:tail )?call void @mesh_jobs_register_handler"
                          r"\(ptr (?:nonnull )?@([-.$\w]+), i64 (\d+), ptr (?:nonnull )?@([-.$\w]+)\)")

# Bound to the pinned runtime sources in the input manifest. This is a review
# list for the exact implementation, not an assertion about arbitrary FFI.
RUNTIME = frozenset("""
mesh_env_get_with_default mesh_file_exists mesh_file_write mesh_gc_alloc_actor
mesh_int_to_string mesh_io_eprintln mesh_jobs_effect_v1 mesh_json_as_string
mesh_json_encode mesh_json_from_int mesh_json_from_string mesh_json_object_get
mesh_json_object_new mesh_json_object_put mesh_json_parse mesh_json_value_as_bool
mesh_json_value_as_int mesh_monotonic_now_nanos mesh_panic_at mesh_reduction_check
mesh_string_concat mesh_string_eq mesh_timer_sleep
""".split())
NATIVE = {"mesh_parity_realtime_us", "mesh_parity_worker_pid"}
ALLOWED_MAIN = {
    "mesh_rt_disable_core_dumps", "mesh_rt_init", "mesh_rt_init_actor",
    "mesh_register_function", "mesh_jobs_register_handler", "mesh_jobs_enter_worker",
    "mesh_run_main", "mesh_rt_run_scheduler",
}


class FullWorker(Exception):
    pass


def require(condition, message):
    if not condition:
        raise FullWorker(message)


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def run(command):
    return subprocess.check_output(command, text=True)


def definitions(ir):
    return {SYMBOL.search(match[0]).group(1): match[0] for match in FUNCTION.finditer(ir)}


def instructions(function):
    return [re.sub(r"\s+; preds = .*$", "", line) for line in function.splitlines()[1:]]


def native_check(archive, expected, out):
    require(digest(archive) == expected, "native archive digest mismatch")
    listing = run(["llvm-nm", "--format=posix", archive])
    symbols = [line.split()[:2] for line in listing.splitlines() if len(line.split()) >= 2]
    require({name for name, kind in symbols if kind == "T"} == NATIVE, listing)
    imports = {name for name, kind in symbols if kind in {"U", "w", "v"}}
    require(imports == {"__stack_chk_fail", "clock_gettime", "getpid"}, listing)
    asm = run(["llvm-objdump", "-dr", archive])
    require(not re.search(r"\b(?:callq?|jmpq?)\s+\*|\b(?:syscall|sysenter|int)\b", asm),
            "unclassified native control transfer")
    audit = run(["llvm-readelf", "-rWsS", archive])
    require(".init_array" not in audit and ".preinit_array" not in audit
            and ".fini_array" not in audit and "IFUNC" not in audit and " TLS " not in audit,
            "native archive has unreviewed startup or TLS dependencies")
    (out / "native-archive.txt").write_text(listing + asm + audit)


def classify(ir, permit_local=False):
    require(bool(re.search(r'^target triple = "x86_64-[^"]*linux[^"]*gnu"', ir, re.M))
            or permit_local, "target is not AMD64 Linux GNU")
    require(not re.search(r'^module asm|^@.*\balias\b|^@.*\bifunc\b|@"', ir, re.M),
            "unclassified module asm, aliases, IFUNC, or quoted names")
    functions = definitions(ir)
    globals_ = dict(GLOBAL.findall(ir))
    declarations = set(DECLARATION.findall(ir))
    entry = functions["main"]
    regs = [REGISTRATION.match(line) for line in entry.splitlines()
            if "@mesh_jobs_register_handler(" in line]
    require(len(regs) == 1 and regs[0] is not None, "expected one constant Jobs registration")
    reg = regs[0]
    literal, length, handler = reg.groups()
    value = re.search(r'c"([a-f\d]{16}:Main__handle)\\00"', globals_[literal])
    require(value and int(length) == len(value[1]) and handler == "Main__handle",
            "unrecognized handler fingerprint or ABI")
    calls = [DIRECT_CALL.match(line) for line in entry.splitlines() if CALL.match(line)]
    require(all(call and call[1] in ALLOWED_MAIN for call in calls), "unclassified startup")
    require("@mesh_rt_disable_core_dumps(" in entry and not any(
        name.startswith("llvm.") for name in globals_), "unclassified global initializer")
    require(all(" asm " not in fn and "callbr " not in fn for fn in functions.values()),
            "unclassified inline assembly")
    require(not any(re.search(r"\b(?:dllexport|protected)\b", fn.splitlines()[0])
                    for fn in functions.values()), "unclassified native-visible definition")
    pending = [handler]
    seen = set()
    runtime = set()
    native = set()
    while pending:
        name = pending.pop()
        if name in seen:
            continue
        seen.add(name)
        if name in functions:
            require(name != "main", "closure refers to program entry")
            for line in functions[name].splitlines():
                require(not CALL.match(line) or DIRECT_CALL.match(line),
                        f"indirect call in {name}: {line}")
            pending.extend(SYMBOL.findall(functions[name]))
        elif name in globals_:
            require(" global " not in globals_[name], f"unreviewed mutable global {name}")
            pending.extend(SYMBOL.findall(globals_[name]))
        elif name in declarations and name in RUNTIME:
            runtime.add(name)
        elif name in declarations and name in NATIVE:
            native.add(name)
        elif name.startswith(("llvm.lifetime.", "llvm.memcpy.", "llvm.memset.")):
            continue
        else:
            raise FullWorker(f"unclassified dependency {name}")
    require(native == NATIVE, "unexpected native closure")
    return entry, reg[0], literal, value[1], seen & functions.keys(), runtime, native


def lean_ir(ir, classified):
    entry, registration, _, _, _, _, _ = classified
    require(re.match(r"define (?:noundef )?i32 @main\(i32 %0, ptr %1\)", entry), "unexpected main ABI")
    declaration = "declare void @mesh_jobs_lean_enter_worker(i32, ptr) noreturn"
    main = "\n".join([
        entry.splitlines()[0], "entry:", "  call void @mesh_rt_disable_core_dumps()",
        registration, "  call void @mesh_jobs_lean_enter_worker(i32 %0, ptr %1)",
        "  unreachable", "}", "",
    ])
    return ir.replace(entry, main + "\n" + declaration + "\n", 1)


def runner_ir(ir, classified, worker_hash):
    entry, registration, literal, fingerprint, *_ = classified
    raw = "".join("\\" + part for part in re.findall("..", worker_hash))
    setup = ("  call void @mesh_jobs_pin_lean_worker("
             f"ptr @{literal}, i64 {len(fingerprint)}, ptr @lean_worker_sha256)")
    require(entry.count(registration) == 1, "no unique pin insertion point")
    return (ir.replace(entry, entry.replace(registration, setup + "\n" + registration), 1)
            + '\n@lean_worker_sha256 = private constant [32 x i8] c"' + raw + '"\n'
            + "declare void @mesh_jobs_pin_lean_worker(ptr, i64, ptr)\n")


def optimize(path, target):
    # Copy of the compiler's list read pre-pass before LLVM O2. The old
    # closure replay used the same invocation, with PIC as in CodeGen.
    source = path.read_text()
    source = re.sub(r"(\bcall [^\n]*@mesh_list_(?:get|length))\(", r"\1.inline(", source)
    path.write_text(source + (HERE / "list-prepass.ll").read_text())
    dest = path.with_name("full.opt.ll")
    run(["opt", "-mtriple=" + target, "-passes=default<O2>", "-relocation-model=pic",
         "-S", path, "-o", dest])
    return dest.read_text()


def build(args):
    out = args.output
    out.mkdir(exist_ok=True)
    original = args.ir.read_text()
    entry, _, _, fingerprint, functions, runtime, native = classify(original, args.classify_local)
    if args.classify_local:
        return {"result": "closure-only", "fingerprint": fingerprint, "functions": sorted(functions),
                "runtime": sorted(runtime), "native": sorted(native)}
    native_check(args.native, args.native_sha256, out)
    preopt = out / "full.preopt.ll"
    preopt.write_text(original)
    target = re.search(r'^target triple = "([^"]+)"', original, re.M)[1]
    optimized = optimize(preopt, target)
    checked = classify(optimized)
    require(checked[3] == fingerprint, "optimization changed registration identity")
    compact = out / "worker.pre-dce.ll"
    compact.write_text(lean_ir(optimized, checked))
    worker = out / "worker.ll"
    run(["opt", "-passes=internalize,globaldce,verify", "-internalize-public-api-list=main",
         "-S", compact, "-o", worker])
    after = definitions(worker.read_text())
    before = definitions(optimized)
    require(set(after) == checked[4] | {"main"}, "global DCE produced an unexpected closure")
    require(all(instructions(before[fn]) == instructions(after[fn]) for fn in checked[4]),
            "handler instructions changed")
    worker_image = out / "mesh-lean-worker"
    emit_obj(worker, target, out / "worker.o")
    link(out / "worker.o", worker_image, args, out / "worker.map")
    if args.witness_objects:
        link(out / "worker.o", out / "mesh-lean-witness", args, out / "witness.map",
             ["-pthread", "-Wl,--wrap=mesh_parity_worker_pid", *args.witness_objects])
    runner = out / "runner.ll"
    runner.write_text(runner_ir(optimized, checked, digest(worker_image)))
    emit_obj(runner, target, out / "runner.o")
    link(out / "runner.o", out / "mesh", args, out / "runner.map")
    if args.witness_objects:
        witness_runner = out / "witness-runner.ll"
        witness_runner.write_text(runner_ir(optimized, checked, digest(out / "mesh-lean-witness")))
        emit_obj(witness_runner, target, out / "witness-runner.o")
        link(out / "witness-runner.o", out / "mesh-witness-runner", args, out / "witness-runner.map")
    return {"result": "specialized", "fingerprint": fingerprint, "functions": sorted(checked[4]),
            "runtime": sorted(runtime), "native": sorted(native), "original_sha256": digest(args.ir),
            "native_sha256": digest(args.native), "runtime_sha256": digest(args.runtime),
            "runner_sha256": digest(out / "mesh"), "worker_sha256": digest(worker_image)}


def emit_obj(ir, target, output):
    run(["llc", "-mtriple=" + target, "-mcpu=generic", "-relocation-model=pic", "-O2",
         "-filetype=obj", ir, "-o", output])


def link(obj, output, args, map_path, extra=()):
    # Same ordered input list and GNU default CRT/linker as build_link_command.
    command = [os.environ.get("CC", "cc"), obj, *extra, args.native, args.runtime, "-lm",
               "-o", output, "-Wl,--gc-sections", f"-Wl,-Map,{map_path}"]
    map_path.with_suffix(".command.json").write_text(json.dumps(list(map(str, command))) + "\n")
    run(command)
    (output.with_suffix(".elf.txt")).write_text(run(
        ["llvm-readelf", "-hWlSd", output]))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("ir", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--native", type=Path)
    parser.add_argument("--native-sha256")
    parser.add_argument("--runtime", type=Path)
    parser.add_argument("--classify-local", action="store_true")
    parser.add_argument("--witness-objects", nargs=2, type=Path)
    args = parser.parse_args()
    try:
        result = build(args)
    except (FullWorker, KeyError) as error:
        result = {"result": "full", "reason": str(error)}
    (args.output / "closure.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    raise SystemExit(result["result"] == "full")
