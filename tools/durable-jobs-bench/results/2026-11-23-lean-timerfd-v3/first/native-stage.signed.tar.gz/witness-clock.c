#define _GNU_SOURCE
#include <fcntl.h>
#include <inttypes.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/prctl.h>
#include <sys/timerfd.h>
#include <time.h>
#include <unistd.h>

extern pid_t witness_pid;
extern _Thread_local uint64_t witness_tls;
extern int witness_stage;
extern int64_t __real_mesh_parity_worker_pid(void);

__attribute__((constructor))
static void second_constructor(void) {
    if (witness_stage != 1 || witness_pid != getpid() ||
        witness_tls != (uint64_t)witness_pid) {
        _exit(199);
    }
    witness_stage = 2;
    witness_tls += 4;
    dprintf(STDERR_FILENO, "LEAN_CTOR_B %d %" PRIu64 "\n", witness_pid, witness_tls);
}

static void *native_thread(void *arg) {
    if (arg != NULL || witness_tls != 917 || witness_pid != getpid()) {
        _exit(200);
    }
    dprintf(STDERR_FILENO, "LEAN_THREAD_TLS %d %" PRIu64 "\n", witness_pid, witness_tls);
    return NULL;
}

static int witness_timer(void) {
    int found = 0;
    for (int fd = 3; fd < 64; ++fd) {
        char path[64], name[64];
        snprintf(path, sizeof(path), "/proc/self/fd/%d", fd);
        ssize_t size = readlink(path, name, sizeof(name) - 1);
        if (size < 0) {
            continue;
        }
        name[size] = '\0';
        if (strcmp(name, "anon_inode:[timerfd]") != 0) {
            continue;
        }
        int flags = fcntl(fd, F_GETFD);
        if (flags < 0 || (flags & FD_CLOEXEC) == 0) {
            return 0;
        }
        snprintf(path, sizeof(path), "/proc/self/fdinfo/%d", fd);
        FILE *info = fopen(path, "r");
        if (info == NULL) {
            return 0;
        }
        char line[128];
        int clock = -1;
        unsigned mode = 0;
        while (fgets(line, sizeof(line), info) != NULL) {
            int value;
            unsigned bits;
            if (sscanf(line, "clockid: %d", &value) == 1) {
                clock = value;
            } else if (sscanf(line, "settime flags: %o", &bits) == 1) {
                mode = bits;
            }
        }
        fclose(info);
        if (clock != CLOCK_BOOTTIME || mode != TFD_TIMER_ABSTIME) {
            return 0;
        }
        ++found;
    }
    return found == 1;
}

int64_t __wrap_mesh_parity_worker_pid(void) {
    int64_t pid = __real_mesh_parity_worker_pid();
    pthread_t thread;
    if (pid != witness_pid || witness_stage != 2 ||
        witness_tls != (uint64_t)pid + 4 || !witness_timer() ||
        prctl(PR_GET_DUMPABLE, 0, 0, 0, 0) != 0 ||
        getpgrp() != pid || prctl(PR_GET_THP_DISABLE, 0, 0, 0, 0) != 1 ||
        pthread_create(&thread, NULL, native_thread, NULL) != 0 ||
        pthread_join(thread, NULL) != 0) {
        _exit(201);
    }
    dprintf(STDERR_FILENO, "LEAN_TIMERFD %d BOOTTIME ABSTIME CLOEXEC\n", witness_pid);
    dprintf(STDERR_FILENO, "LEAN_HANDLER %d %" PRIu64 "\n", witness_pid, witness_tls);
    return pid;
}
