from pathlib import Path
import json,sys,tempfile,importlib.util,fcntl,hashlib,os
p=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('component',p.parent/'native-large-payload-storage/screen.py')
c=importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)
pg=c.pg
inline="""CREATE OR REPLACE FUNCTION mesh_jobs.effect_key(j mesh_jobs.jobs) RETURNS text
LANGUAGE sql IMMUTABLE STRICT SECURITY INVOKER RETURN (j.id)::text || '/' || (j.run)::text"""
direct="SELECT j.id::text || '/' || j.run::text FROM mesh_jobs.jobs j ORDER BY j.position"
call="SELECT mesh_jobs.effect_key(j) FROM mesh_jobs.jobs j ORDER BY j.position"
loop="""CREATE FUNCTION mesh_jobs.test_effect_keys() RETURNS SETOF text LANGUAGE plpgsql AS $$
DECLARE job mesh_jobs.jobs%ROWTYPE;
BEGIN
 FOR job IN SELECT j.* FROM mesh_jobs.jobs j ORDER BY j.position LOOP
  RETURN NEXT mesh_jobs.effect_key(job);
 END LOOP;
END $$"""
def main(out):
 out.mkdir()
 jobs,seed=pg.profile_jobs()
 schema=c.schema.read_text()
 orig="CREATE OR REPLACE FUNCTION mesh_jobs.effect_key("+schema.split("CREATE OR REPLACE FUNCTION mesh_jobs.effect_key(")[1].split("$$;")[0]+"$$;"
 with (p.parent/'queue-performance.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX)
  with tempfile.TemporaryDirectory(dir=p.parent,prefix='key-') as tmp:
   cl=pg.Cluster(Path(tmp),out)
   try:
    cl.start()
    with cl.connect('postgres') as db,cl.connect('postgres') as observer:
     db.simple(schema)
     db.simple("ALTER TABLE mesh_jobs.jobs ALTER COLUMN args SET STORAGE EXTERNAL")
     pg.seed(db,'probe',jobs['large'])
     expected=db.params(direct)[1]
     db.simple(loop)
     assert len(expected)==len(set(expected))==64
     result={'seed':seed,'calibration':pg.calibrate_cpu(),'cases':[]}
     for name,ddl in [('stock',orig),('bound',inline),('stock-repeat',orig)]:
      db.simple("SET search_path = pg_catalog,pg_temp")
      db.simple(ddl)
      for kind,q in [('direct',direct),('row',call),('plpgsql','SELECT * FROM mesh_jobs.test_effect_keys()')]:
       explain=pg.scalar(db,"EXPLAIN (VERBOSE, COSTS OFF, FORMAT JSON) "+q)
       db.params(q)
       def action():
        for _ in range(4):
         assert db.params(q)[1]==expected
       _,money=pg.measured(db,observer,action)
       result['cases'].append(dict(arm=name,query=kind,plan=json.loads(explain),cpu_ms=money['backend_cpu_ms'],blocks=money['blocks'],wall_ms=money['wall_ms'],load=os.getloadavg()))
     pg.json_write(out/'result.json',result)
   finally:
    cl.stop()
if __name__=='__main__': main(p/sys.argv[1])
