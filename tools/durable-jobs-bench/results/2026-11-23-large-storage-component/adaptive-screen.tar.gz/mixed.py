import hashlib
import json
from pathlib import Path
import tempfile
import sys

from screen import here, pg


def bodies():
    jobs, _ = pg.profile_jobs()
    original = jobs["large"][0]["payload"]
    size = len(original)
    near = list("q" * size)
    for i in range(8):
        offset = i * (size - 4096) // 7
        lo = max(0, offset - 1024)
        hi = min(size, offset + 4096 + 1024)
        near[lo:hi] = original[lo:hi]
    near[:128] = "A" * 128
    return {
        "frozen": original, "repeated": "q" * size,
        "nonuniform": "".join(near),
        "mostly-frozen": original[:3 * size // 4] + "q" * (size // 4),
        "unicode": "ø\n\"界" * (size // 7),
        "small": "hello",
    }


def run():
    out = here / sys.argv[1]
    out.mkdir()
    with tempfile.TemporaryDirectory(dir=here.parent, prefix="mx-") as tmp:
        cluster = pg.Cluster(Path(tmp), out)
        try:
            cluster.start()
            with cluster.connect("postgres") as session:
                module = (here / "store.so").as_posix().replace("'", "''")
                session.simple(f"CREATE FUNCTION adaptive(jsonb) RETURNS jsonb AS '{module}',"
                               "'mesh_storage_sampled_pglz' LANGUAGE C STRICT VOLATILE")
                results = {}
                for mode in ("pglz", "adaptive", "lz4", "external"):
                    session.simple("CREATE TABLE payload (name text, body jsonb)")
                    if mode in ("external", "adaptive"):
                        session.simple("ALTER TABLE payload ALTER COLUMN body SET STORAGE EXTERNAL")
                    if mode == "lz4":
                        session.simple("ALTER TABLE payload ALTER COLUMN body SET COMPRESSION lz4")
                    expr = "adaptive($2::jsonb)" if mode == "adaptive" else "$2::jsonb"
                    expected = {}
                    for name, body in bodies().items():
                        expected[name] = hashlib.sha256(body.encode()).hexdigest()
                        session.params("INSERT INTO payload VALUES ($1," + expr + ")", name,
                                       json.dumps({"payload": body}, ensure_ascii=False))
                    rows = session.params("""SELECT name,coalesce(pg_column_compression(body),'none'),
                        pg_column_size(body),encode(sha256(convert_to(body->>'payload','UTF8')),'hex')
                        FROM payload ORDER BY name""")[1]
                    assert {key: digest for key, _, _, digest in rows} == expected
                    results[mode] = {key: {"compression": kind, "bytes": int(n), "hash": digest}
                                     for key, kind, n, digest in rows}
                    session.simple("DROP TABLE payload")
                pg.json_write(out/"result.json", results)
        finally:
            cluster.stop()


if __name__ == "__main__":
    run()
