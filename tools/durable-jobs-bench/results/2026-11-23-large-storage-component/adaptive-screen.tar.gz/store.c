#include "postgres.h"
#include "fmgr.h"
#include "access/toast_compression.h"
#include "access/toast_internals.h"
#include "common/pg_lzcompress.h"
#include "varatt.h"

PG_MODULE_MAGIC;
PG_FUNCTION_INFO_V1(mesh_storage_sampled_pglz);

/* The table uses EXTERNAL storage. Precompress selected jsonb values with
 * this server's own PGLZ encoder and otherwise preserve the incoming datum. */
Datum
mesh_storage_sampled_pglz(PG_FUNCTION_ARGS)
{
    const Datum original = PG_GETARG_DATUM(0);
    struct varlena *input = (struct varlena *) DatumGetPointer(original);
    const int sample_size = 4096;
    const int nsamples = 8;
    char trial[PGLZ_MAX_OUTPUT(4096)];
    int32 size;
    Datum compressed;

    if (VARATT_IS_EXTERNAL_ONDISK(input) || VARATT_IS_COMPRESSED(input))
        return original;
    input = PG_DETOAST_DATUM_PACKED(original);
    size = VARSIZE_ANY_EXHDR(input);
    if (size <= 2048)
        return PointerGetDatum(input);

    if (size >= 65536)
    {
        const char *data = VARDATA_ANY(input);
        bool likely = false;
        for (int sample = 0; sample < nsamples; sample++)
        {
            Size offset = ((uint64)(size - sample_size) * sample) / (nsamples - 1);
            if (pglz_compress(data + offset, sample_size, trial, PGLZ_strategy_default) >= 0)
            {
                likely = true;
                break;
            }
        }
        if (!likely)
            return PointerGetDatum(input);
    }

    compressed = toast_compress_datum(PointerGetDatum(input), TOAST_PGLZ_COMPRESSION);
    return DatumGetPointer(compressed) ? compressed : PointerGetDatum(input);
}
