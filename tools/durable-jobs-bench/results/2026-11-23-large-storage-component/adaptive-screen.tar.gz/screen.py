import importlib.util
import fcntl
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile

here=Path(__file__).resolve().parent
loader=importlib.util.spec_from_file_location("storage_probe",here.parent/'native-large-payload-storage/screen.py')
st=importlib.util.module_from_spec(loader);loader.loader.exec_module(st)
pg=st.pg
def overlay():
    sql=st.schema.read_text()
    start="CREATE OR REPLACE FUNCTION mesh_jobs.enqueue("
    end="CREATE OR REPLACE FUNCTION mesh_jobs.claim("
    e=start+sql.split(start)[1].split(end)[0]
    replacements=[
        ("args = CASE WHEN replacements ? 'args' THEN spec -> 'args' ELSE j.args END",
         "args = CASE WHEN replacements ? 'args' THEN mesh_jobs.storage_value(spec -> 'args') ELSE j.args END"),
        ("spec -> 'args', spec -> 'metadata', spec -> 'tags',",
         "mesh_jobs.storage_value(spec -> 'args'), spec -> 'metadata', spec -> 'tags',")
    ]
    for before,after in replacements:
        if e.count(before)!=1: raise ValueError(before)
        e=e.replace(before,after)
    if "--trigger" in sys.argv:
        e="""
        CREATE FUNCTION mesh_jobs.apply_args_storage() RETURNS trigger LANGUAGE plpgsql
        SET search_path = pg_catalog, pg_temp AS $body$
        BEGIN
            NEW.args := mesh_jobs.storage_value(NEW.args);
            RETURN NEW;
        END
        $body$;
        CREATE TRIGGER mesh_storage_policy BEFORE INSERT OR UPDATE OF args ON mesh_jobs.jobs
        FOR EACH ROW EXECUTE FUNCTION mesh_jobs.apply_args_storage();
        """
    library=(here/'store.so').as_posix().replace("'","''")
    return (f"CREATE FUNCTION mesh_jobs.storage_value(jsonb) RETURNS jsonb AS '{library}', 'mesh_storage_sampled_pglz' "
        "LANGUAGE C STRICT VOLATILE PARALLEL SAFE; "
        "ALTER TABLE mesh_jobs.jobs ALTER COLUMN args SET STORAGE EXTERNAL; "+e)

def run(out):
    out.mkdir()
    original,seed=pg.profile_jobs()
    jobs=original['large']
    control=[dict(j,payload='k'*len(j['payload'])) for j in jobs]
    tests={'frozen':jobs,'repeated':control}
    st.policies['adaptive']=overlay()
    orders=[('control_a','external','adaptive','control_b'),('control_b','adaptive','external','control_a'),
            ('adaptive','control_a','control_b','external'),('external','control_b','control_a','adaptive')]
    pg.json_write(out/'manifest.json',dict(input_seed=seed,mach=pg.calibrate_cpu(),orders=orders,load=os.getloadavg(),
        so_sha256=hashlib.sha256((here/'store.so').read_bytes()).hexdigest(),sql_sha256=hashlib.sha256(overlay().encode()).hexdigest()))
    with (here.parent/'queue-performance.lock').open('r') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        with tempfile.TemporaryDirectory(dir=here.parent,prefix='apg-') as d:
            cl=pg.Cluster(Path(d),out)
            try:
                cl.start()
                for i,order in enumerate(orders):
                    for kind,items in tests.items():
                        specs=[st.actual_spec(j) for j in items]
                        for arm in order:
                            db=f'a_{i}_{kind}_{arm}'
                            with cl.connect("postgres") as pgadmin:
                                pgadmin.params(f'CREATE DATABASE {db}')
                            try:
                                with cl.connect(db) as client:
                                    result=st.stage(client,arm,items,specs)
                                pg.json_write(out/f'{i}-{kind}-{arm}.json',dict(result,load=os.getloadavg()))
                            finally:
                                cl.drop(db)
            finally:
                cl.stop()
if __name__=='__main__':run(here/sys.argv[1])
