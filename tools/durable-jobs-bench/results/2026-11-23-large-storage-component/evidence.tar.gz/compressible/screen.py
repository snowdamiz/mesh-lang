"""Screen PostgreSQL column storage on the frozen large Jobs input, on macOS."""
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import statistics
import sys
import tempfile
import time

here = Path(__file__).resolve().parent
root = here.parent.parent
support = here.parent / "large-args-domain" / "replay.py"
loader = importlib.util.spec_from_file_location("storage_support", support)
pg = importlib.util.module_from_spec(loader)
loader.loader.exec_module(pg)
schema = root / "compiler/mesh-rt/src/jobs/schema.sql"
policies = {
    "control_a": "",
    "lz4": "ALTER TABLE mesh_jobs.jobs ALTER COLUMN args SET COMPRESSION lz4",
    "external": "ALTER TABLE mesh_jobs.jobs ALTER COLUMN args SET STORAGE EXTERNAL",
    "control_b": ""
}
orders = [
    ("control_a", "lz4", "external", "control_b"),
    ("control_b", "external", "lz4", "control_a"),
    ("lz4", "control_a", "control_b", "external"),
    ("external", "control_b", "control_a", "lz4"),
]
sql_enqueue = "SELECT mesh_jobs.enqueue($1, $2::jsonb, $3, $4)::text"
sql_admit = """INSERT INTO mesh_jobs.admissions AS a(namespace) VALUES ($1)
               ON CONFLICT(namespace) DO UPDATE SET fence=NOT a.fence"""
namespace = "storage-screen"

def actual_spec(job):
    fields = dict(worker="parity", version=1, args=job, queue="default", metadata={}, tags=[],
                  priority=0, scheduled_at_ms=None, delay_ms=None, max_attempts=3,
                  timeout_ms=60000, backoff_base_ms=1000, backoff_max_ms=1000, suspended=False,
                  unique=None, replace={})
    spec = json.dumps(fields, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return (namespace, spec, job["key"], hashlib.sha256(spec.encode()).hexdigest())

def measure(session, fn):
    pid = session.pq.PQbackendPID(session.conn)
    ns_per_tick = pg.TIMEBASE[0] / pg.TIMEBASE[1]
    before = sum(pg.backend_cpu(pid))
    start = time.monotonic_ns()
    value = fn()
    wall = time.monotonic_ns() - start
    cpu_ns = (sum(pg.backend_cpu(pid)) - before) * ns_per_tick
    return value, {"wall_ms": wall/1e6, "backend_cpu_ms": cpu_ns/1e6}

def stage(actor, policy, jobs, specs):
    actor.simple(schema.read_text())
    if policies[policy]:
        actor.simple(policies[policy])
    pg.set_queue(actor, namespace)
    def enqueue():
        actor.params("BEGIN")
        ids = {}
        for values in specs:
            actor.params("SAVEPOINT mesh_jobs_enqueue")
            actor.params(sql_admit, namespace)
            receipt = json.loads(pg.scalar(actor, sql_enqueue, *values))
            assert receipt["inserted"] and not receipt["conflict"]
            ids[values[2]] = receipt["id"]
            actor.params("RELEASE SAVEPOINT mesh_jobs_enqueue")
        actor.params("COMMIT")
        return ids
    ids, insert = measure(actor, enqueue)
    def claim():
        claims = []
        for _ in range(8):
            actor.params("BEGIN")
            rows = actor.params(pg.CLAIM, namespace, "default", pg.WORKERS, 30000, 8, "", "false")[1]
            assert len(rows) == 8
            assert all(r[0] == "claimed" and int(r[5]) == len(r[3].encode()) for r in rows)
            actor.params("COMMIT")
            claims.extend(rows)
        return claims
    claims, pickup = measure(actor, claim)
    for row, expected in zip(claims, jobs, strict=True):
        ctx = json.loads(row[3])
        assert ctx["args"] == expected and ctx["id"] == ids[expected["key"]] == row[1]
    def settle():
        for row in claims:
            assert pg.settle(actor, namespace, row[1], row[2]) == "completed"
    _, done = measure(actor, settle)
    tally = actor.params("SELECT state,attempt,count(*) FROM mesh_jobs.jobs GROUP BY state,attempt")[1]
    assert tally == (("completed","1","64"),), tally
    storage = actor.params("SELECT coalesce(pg_column_compression(args),'none'), count(*), sum(pg_column_size(args)) FROM mesh_jobs.jobs GROUP BY 1 ORDER BY 1")[1]
    return {"insert":insert,"claims":pickup,"settlements":done,"storage":storage,"terminal":tally}

def main():
    out = here/sys.argv[1]
    out.mkdir()
    jobs, digest = pg.profile_jobs()
    variant = sys.argv[2] if len(sys.argv)>2 else "large"
    if variant not in {"large", "compressible", "mixed"}:
        raise ValueError(variant)
    jobs = jobs["large"]
    if variant != "large":
        jobs = [dict(j, payload=("a"*len(j["payload"]))) if variant=="compressible" or i%2==0 else j
                for i,j in enumerate(jobs)]
    specs = [actual_spec(j) for j in jobs]
    pg.json_write(out/"inputs.json", {"seed_input_sha256":digest,"variant":variant,"payload_set_sha256":hashlib.sha256(b"".join(hashlib.sha256(j["payload"].encode()).digest() for j in jobs)).hexdigest(),"schema_sha256":hashlib.sha256(schema.read_bytes()).hexdigest(),
        "mach":pg.calibrate_cpu(),"stock_sql":sql_enqueue,"orders":orders,"policy_sql":policies,"load":os.getloadavg()})
    with (here.parent/"queue-performance.lock").open("r") as handle:
        fcntl.flock(handle, fcntl.LOCK_EX)
        with tempfile.TemporaryDirectory(dir=here.parent, prefix="storage-pg-") as d:
            cl = pg.Cluster(Path(d), out)
            try:
                cl.start()
                for i,order in enumerate(orders):
                    for arm in order:
                        database = f"storage_{i}_{arm}"
                        with cl.connect("postgres") as admin:
                            admin.params(f"CREATE DATABASE {database}")
                        try:
                            with cl.connect(database) as active:
                                result = stage(active,arm,jobs,specs)
                            pg.json_write(out/f"{i}-{arm}.json",dict(result,load=os.getloadavg()))
                        finally:
                            cl.drop(database)
            finally:
                cl.stop()

if __name__ == "__main__":
    main()
