; ModuleID = 'mesh_module'
source_filename = "mesh_module"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-darwin27.0.0"

@.str = unnamed_addr constant { i64, [11 x i8] } { i64 11, [11 x i8] c"PROBE_WIDTH" }, align 8
@.str.1 = unnamed_addr constant { i64, [11 x i8] } { i64 11, [11 x i8] c"PROBE_TOTAL" }, align 8
@.str.2 = unnamed_addr constant { i64, [10 x i8] } { i64 10, [10 x i8] c"PROBE_PARK" }, align 8
@.str.3 = unnamed_addr constant { i64, [12 x i8] } { i64 12, [12 x i8] c"PROBE_MEMORY" }, align 8
@fn_reg_immediate = private unnamed_addr constant [10 x i8] c"immediate\00", align 1
@fn_sig_immediate = private unnamed_addr constant [1 x i8] c"\01"
@fn_reg_parked = private unnamed_addr constant [7 x i8] c"parked\00", align 1
@fn_sig_parked = private unnamed_addr constant [1 x i8] c"\01"
@fn_reg_Main__start_immediate = private unnamed_addr constant [22 x i8] c"Main__start_immediate\00", align 1
@fn_sig_Main__start_immediate = private unnamed_addr constant [2 x i8] zeroinitializer
@fn_reg_Main__start_parked = private unnamed_addr constant [19 x i8] c"Main__start_parked\00", align 1
@fn_sig_Main__start_parked = private unnamed_addr constant [3 x i8] zeroinitializer
@fn_reg_Main__waves = private unnamed_addr constant [12 x i8] c"Main__waves\00", align 1
@fn_sig_Main__waves = private unnamed_addr constant [5 x i8] zeroinitializer
@fn_reg_mesh_main = private unnamed_addr constant [10 x i8] c"mesh_main\00", align 1

declare void @mesh_rt_init()

declare void @mesh_rt_disable_core_dumps()

declare void @mesh_run_main(ptr)

declare i32 @mesh_library_invoke(ptr, ptr, i64, ptr)

declare ptr @mesh_host_secure_store_put(ptr)

declare ptr @mesh_host_secure_store_get(ptr)

declare ptr @mesh_host_secure_store_delete(ptr)

declare ptr @mesh_host_push_get_token(ptr)

declare ptr @mesh_host_background_schedule(ptr)

declare ptr @mesh_host_network_state(ptr)

declare ptr @mesh_host_monotonic_clock(ptr)

declare ptr @mesh_host_wall_clock(ptr)

declare ptr @mesh_host_log_redacted(ptr)

declare i32 @mesh_register_autonomous_config_json(ptr, i64)

declare ptr @mesh_gc_alloc_actor(i64, i64)

declare ptr @mesh_string_new(ptr, i64)

declare ptr @mesh_string_concat(ptr, ptr)

declare ptr @mesh_int_to_string(i64)

declare ptr @mesh_pid_to_string(i64)

declare ptr @mesh_float_to_string(double)

declare ptr @mesh_bool_to_string(i8)

declare void @mesh_print(ptr)

declare void @mesh_println(ptr)

declare void @mesh_rt_init_actor(i32)

declare i64 @mesh_actor_spawn(ptr, ptr, i64, i8)

declare i64 @mesh_actor_spawn_shaped(ptr, ptr, i64, i8, ptr)

declare i64 @mesh_actor_spawn_grouped(ptr, ptr, i64, ptr, ptr)

declare i64 @mesh_actor_spawn_step(ptr, ptr, i32, ptr, i64, ptr)

declare i64 @mesh_actor_spawn_movable_step(ptr, ptr, i32, ptr, i64, ptr, i64, i8)

declare void @mesh_step_charge()

declare i64 @mesh_actor_send(i64, ptr, i64)

declare i64 @mesh_actor_send_shaped(i64, ptr, i64, ptr)

declare ptr @mesh_actor_receive(i64)

declare ptr @mesh_actor_receive_scalar(i64, i64, ptr)

declare void @mesh_actor_wait_timeout(i64)

declare void @mesh_actor_stop()

declare i64 @mesh_actor_self()

declare void @mesh_actor_link(i64)

declare void @mesh_reduction_check()

declare ptr @mesh_reduction_state_v1()

declare void @mesh_actor_set_terminate(i64, ptr)

declare void @mesh_rt_run_scheduler()

declare i64 @mesh_supervisor_start(ptr, i64)

declare i64 @mesh_supervisor_start_child(i64, ptr, i64)

declare i64 @mesh_supervisor_terminate_child(i64, i64)

declare i64 @mesh_supervisor_count_children(i64)

declare void @mesh_actor_trap_exit()

declare void @mesh_actor_exit(i64, i8)

declare i64 @mesh_string_length(ptr)

declare ptr @mesh_string_slice(ptr, i64, i64)

declare i8 @mesh_string_contains(ptr, ptr)

declare i8 @mesh_string_starts_with(ptr, ptr)

declare i8 @mesh_string_ends_with(ptr, ptr)

declare ptr @mesh_string_trim(ptr)

declare ptr @mesh_string_trim_start(ptr)

declare ptr @mesh_string_trim_end(ptr)

declare ptr @mesh_string_repeat(ptr, i64)

declare ptr @mesh_string_to_upper(ptr)

declare ptr @mesh_string_to_lower(ptr)

declare ptr @mesh_string_replace(ptr, ptr, ptr)

declare i8 @mesh_string_eq(ptr, ptr)

declare i64 @mesh_string_compare(ptr, ptr)

declare ptr @mesh_string_split(ptr, ptr)

declare ptr @mesh_string_join(ptr, ptr)

declare ptr @mesh_string_to_int(ptr)

declare ptr @mesh_string_to_float(ptr)

declare ptr @mesh_file_read(ptr)

declare ptr @mesh_file_read_bytes(ptr, i64, i64)

declare ptr @mesh_file_write_bytes(ptr, i64, ptr, i8)

declare ptr @mesh_file_size(ptr)

declare ptr @mesh_file_write(ptr, ptr)

declare ptr @mesh_file_append(ptr, ptr)

declare i8 @mesh_file_exists(ptr)

declare ptr @mesh_file_delete(ptr)

declare ptr @mesh_file_rename(ptr, ptr)

declare ptr @mesh_file_sync(ptr)

declare ptr @mesh_io_read_line()

declare void @mesh_io_eprintln(ptr)

declare ptr @mesh_env_get(ptr)

declare ptr @mesh_env_args()

declare ptr @mesh_env_get_with_default(ptr, ptr)

declare i64 @mesh_env_get_int(ptr, i64)

declare ptr @mesh_env_get_secret_hex(ptr)

declare ptr @mesh_regex_from_literal(ptr, i64)

declare ptr @mesh_regex_compile(ptr)

declare i8 @mesh_regex_match(ptr, ptr)

declare ptr @mesh_regex_captures(ptr, ptr)

declare ptr @mesh_regex_replace(ptr, ptr, ptr)

declare ptr @mesh_regex_split(ptr, ptr)

declare ptr @mesh_crypto_sha256(ptr)

declare ptr @mesh_crypto_sha512(ptr)

declare ptr @mesh_crypto_sha256_hex(ptr)

declare ptr @mesh_crypto_sha512_hex(ptr)

declare ptr @mesh_crypto_random_bytes(i64)

declare ptr @mesh_crypto_hmac_sha256(ptr, ptr)

declare ptr @mesh_crypto_hmac_sha256_tag(ptr, ptr)

declare ptr @mesh_crypto_hkdf_sha256(ptr, ptr, ptr, i64)

declare ptr @mesh_crypto_argon2id(ptr, ptr, i64, i64, i64, i64)

declare ptr @mesh_crypto_x25519_generate()

declare ptr @mesh_crypto_mlkem_generate()

declare ptr @mesh_crypto_signing_generate()

declare ptr @mesh_crypto_signing_from_seed(ptr)

declare ptr @mesh_crypto_signing_from_secret(ptr)

declare ptr @mesh_crypto_x25519_from_seed(ptr)

declare ptr @mesh_crypto_x25519_from_secret(ptr)

declare ptr @mesh_crypto_mlkem_from_seed(ptr)

declare ptr @mesh_crypto_mlkem_from_secret(ptr)

declare ptr @mesh_crypto_x25519_public(ptr)

declare ptr @mesh_crypto_mlkem_encapsulate(ptr)

declare ptr @mesh_crypto_aead_key(ptr)

declare ptr @mesh_crypto_x25519_shared(ptr, ptr)

declare ptr @mesh_crypto_mlkem_decapsulate(ptr, ptr)

declare ptr @mesh_crypto_sign(ptr, ptr)

declare ptr @mesh_crypto_verify(ptr, ptr, ptr)

declare ptr @mesh_crypto_blind_rsa_generate()

declare ptr @mesh_crypto_blind_rsa_from_secret(ptr)

declare ptr @mesh_crypto_blind_rsa_public(ptr)

declare ptr @mesh_crypto_blind_rsa_public_from_spki(ptr)

declare ptr @mesh_crypto_blind_rsa_blind(ptr, ptr)

declare ptr @mesh_crypto_blind_rsa_sign(ptr, ptr)

declare ptr @mesh_crypto_blind_rsa_verify(ptr, ptr, ptr)

declare ptr @mesh_crypto_blind_rsa_finalize(ptr, ptr, ptr, ptr)

declare ptr @mesh_crypto_aead_seal(ptr, ptr, ptr, ptr)

declare ptr @mesh_crypto_aead_open(ptr, ptr, ptr, ptr)

declare ptr @mesh_crypto_hpke_seal(ptr, ptr, ptr, ptr)

declare ptr @mesh_crypto_hpke_open(ptr, ptr, ptr, ptr)

declare ptr @mesh_crypto_hpke_seal_secret(ptr, ptr, ptr, ptr)

declare ptr @mesh_crypto_hpke_open_secret(ptr, ptr, ptr, ptr)

declare ptr @mesh_crypto_hkdf_aead_seal(ptr, ptr, ptr, ptr)

declare ptr @mesh_crypto_hkdf_aead_open(ptr, ptr, ptr, ptr)

declare ptr @mesh_crypto_hpke_seal_export(ptr, ptr, ptr, ptr, ptr)

declare ptr @mesh_crypto_hpke_open_export(ptr, ptr, ptr, ptr, ptr)

declare ptr @mesh_crypto_hmac_sha512(ptr, ptr)

declare ptr @mesh_crypto_uuid4()

declare ptr @mesh_base64_encode(ptr)

declare ptr @mesh_base64_decode(ptr)

declare ptr @mesh_base64_encode_url(ptr)

declare ptr @mesh_base64_decode_url(ptr)

declare ptr @mesh_hex_encode(ptr)

declare ptr @mesh_hex_decode(ptr)

declare ptr @mesh_bytes_empty()

declare ptr @mesh_bytes_from_list(ptr)

declare ptr @mesh_bytes_to_list(ptr)

declare ptr @mesh_bytes_repeat(i64, i64)

declare i64 @mesh_bytes_length(ptr)

declare ptr @mesh_bytes_get(ptr, i64)

declare ptr @mesh_bytes_slice(ptr, i64, i64)

declare ptr @mesh_bytes_concat(ptr, ptr)

declare i8 @mesh_bytes_secure_equals(ptr, ptr)

declare ptr @mesh_bytes_from_utf8(ptr)

declare ptr @mesh_bytes_from_base64(ptr)

declare ptr @mesh_bytes_from_base58(ptr)

declare ptr @mesh_bytes_from_hex(ptr)

declare ptr @mesh_json_array_length(ptr)

declare i8 @mesh_json_is_null(ptr)

declare i8 @mesh_json_eq(ptr, ptr)

declare ptr @mesh_bytes_to_utf8(ptr)

declare ptr @mesh_bytes_to_base64(ptr)

declare ptr @mesh_bytes_to_base58(ptr)

declare ptr @mesh_bytes_to_hex(ptr)

declare ptr @mesh_bytes_read_uint_le(ptr, i64, i64)

declare ptr @mesh_bytes_write_uint_le(ptr, i64)

declare ptr @mesh_bytes_read_u16_be(ptr, i64)

declare ptr @mesh_bytes_read_u16_le(ptr, i64)

declare ptr @mesh_bytes_read_u32_be(ptr, i64)

declare ptr @mesh_bytes_read_u32_le(ptr, i64)

declare ptr @mesh_bytes_read_u64_be(ptr, i64)

declare ptr @mesh_bytes_read_u64_le(ptr, i64)

declare ptr @mesh_bytes_write_u16_be(i64)

declare ptr @mesh_bytes_write_u32_be(ptr)

declare ptr @mesh_bytes_write_u64_be(ptr)

declare ptr @mesh_bytes_builder_new(i64)

declare ptr @mesh_bytes_builder_write_u8(ptr, i64)

declare ptr @mesh_bytes_builder_write_u16_be(ptr, i64)

declare ptr @mesh_bytes_builder_write_u32_be(ptr, i64)

declare ptr @mesh_bytes_builder_write_bytes(ptr, ptr)

declare ptr @mesh_bytes_builder_finish(ptr)

declare ptr @mesh_secret_random(i64)

declare ptr @mesh_storage_key_ephemeral()

declare ptr @mesh_storage_key_from_secret(ptr, ptr)

declare ptr @mesh_secret_from_bytes(ptr)

declare ptr @mesh_storage_key_platform()

declare ptr @mesh_storage_key_seal_bytes(ptr, ptr, ptr)

declare ptr @mesh_storage_key_unseal_bytes(ptr, ptr, ptr)

declare ptr @mesh_secret_concat(ptr, ptr)

declare void @mesh_secret_destroy(ptr)

declare void @mesh_resource_destroy(ptr)

declare ptr @mesh_secret_map_new(i64)

declare ptr @mesh_secret_map_fork(ptr)

declare ptr @mesh_secret_map_insert(ptr, ptr, ptr)

declare i8 @mesh_secret_map_contains(ptr, ptr)

declare ptr @mesh_secret_map_copy(ptr, ptr)

declare ptr @mesh_secret_map_delete(ptr, ptr)

declare ptr @mesh_secret_map_merge(ptr, ptr)

declare ptr @mesh_secret_seal_for_storage(ptr, ptr, ptr)

declare ptr @mesh_secret_unseal_from_storage(ptr, ptr, ptr)

declare ptr @mesh_secret_map_seal_for_storage(ptr, ptr, ptr)

declare ptr @mesh_secret_map_unseal_from_storage(ptr, ptr, ptr)

declare ptr @mesh_x25519_private_key_seal_for_storage(ptr, ptr, ptr)

declare ptr @mesh_x25519_private_key_unseal_from_storage(ptr, ptr, ptr)

declare ptr @mesh_signing_private_key_seal_for_storage(ptr, ptr, ptr)

declare ptr @mesh_signing_private_key_unseal_from_storage(ptr, ptr, ptr)

declare ptr @mesh_mlkem_private_key_seal_for_storage(ptr, ptr, ptr)

declare ptr @mesh_mlkem_private_key_unseal_from_storage(ptr, ptr, ptr)

declare ptr @mesh_blind_rsa_secret_key_seal_for_storage(ptr, ptr, ptr)

declare ptr @mesh_blind_rsa_secret_key_unseal_from_storage(ptr, ptr, ptr)

declare ptr @mesh_u64_parse(ptr)

declare ptr @mesh_u64_to_int(ptr)

declare ptr @mesh_u64_to_string(ptr)

declare i64 @mesh_u64_compare(ptr, ptr)

declare ptr @mesh_u64_add(ptr, ptr)

declare ptr @mesh_u64_subtract(ptr, ptr)

declare ptr @mesh_u64_multiply(ptr, ptr)

declare ptr @mesh_u64_divide(ptr, ptr)

declare ptr @mesh_u128_parse(ptr)

declare ptr @mesh_u128_to_int(ptr)

declare ptr @mesh_u128_to_string(ptr)

declare i64 @mesh_u128_compare(ptr, ptr)

declare ptr @mesh_u128_add(ptr, ptr)

declare ptr @mesh_u128_subtract(ptr, ptr)

declare ptr @mesh_u128_multiply(ptr, ptr)

declare ptr @mesh_u128_divide(ptr, ptr)

declare ptr @mesh_i128_parse(ptr)

declare ptr @mesh_i128_to_int(ptr)

declare ptr @mesh_i128_to_string(ptr)

declare i64 @mesh_i128_compare(ptr, ptr)

declare ptr @mesh_i128_add(ptr, ptr)

declare ptr @mesh_i128_subtract(ptr, ptr)

declare ptr @mesh_i128_multiply(ptr, ptr)

declare ptr @mesh_i128_divide(ptr, ptr)

declare i64 @mesh_datetime_utc_now()

declare ptr @mesh_datetime_from_iso8601(ptr)

declare ptr @mesh_datetime_to_iso8601(i64)

declare ptr @mesh_datetime_from_unix_ms(i64)

declare i64 @mesh_datetime_to_unix_ms(i64)

declare ptr @mesh_datetime_from_unix_secs(i64)

declare i64 @mesh_datetime_to_unix_secs(i64)

declare i64 @mesh_datetime_add(i64, i64, ptr)

declare double @mesh_datetime_diff(i64, i64, ptr)

declare i8 @mesh_datetime_before(i64, i64)

declare i8 @mesh_datetime_after(i64, i64)

declare ptr @mesh_checked_add(i64, i64)

declare ptr @mesh_checked_sub(i64, i64)

declare ptr @mesh_checked_mul(i64, i64)

declare ptr @mesh_checked_div(i64, i64)

declare ptr @mesh_checked_abs(i64)

declare ptr @mesh_checked_mul_div(i64, i64, i64, ptr)

declare ptr @mesh_checked_rescale(i64, i64, i64, ptr)

declare i64 @mesh_monotonic_now_nanos()

declare ptr @mesh_monotonic_elapsed(i64, i64)

declare ptr @mesh_duration_millis(i64)

declare ptr @mesh_duration_seconds(i64)

declare ptr @mesh_channel_bounded(i64, ptr)

declare ptr @mesh_channel_bounded_bytes(i64, i64, ptr)

declare ptr @mesh_channel_try_send(i64, i64)

declare ptr @mesh_channel_recv(i64, i64)

declare ptr @mesh_channel_try_send_shaped(i64, i64, ptr)

declare i64 @mesh_channel_depth(i64)

declare i64 @mesh_channel_byte_depth(i64)

declare i64 @mesh_channel_dropped(i64)

declare i64 @mesh_random_seed(i64)

declare ptr @mesh_random_next_int(i64, i64, i64)

declare ptr @mesh_random_next_unit_ppm(i64)

declare i64 @mesh_http_build(ptr, ptr)

declare i64 @mesh_http_header(i64, ptr, ptr)

declare i64 @mesh_http_body(i64, ptr)

declare i64 @mesh_http_body_bytes(i64, ptr)

declare i64 @mesh_http_timeout(i64, i64)

declare i64 @mesh_http_stage_timeout(i64, ptr, i64)

declare i64 @mesh_http_max_redirects(i64, i64)

declare i64 @mesh_http_max_response_bytes(i64, i64)

declare i64 @mesh_http_query(i64, ptr, ptr)

declare i64 @mesh_http_json(i64, ptr)

declare ptr @mesh_http_send(i64)

declare i64 @mesh_http_stream(i64, ptr, ptr)

declare i64 @mesh_http_stream_bytes(i64, ptr, ptr)

declare void @mesh_http_cancel(i64)

declare i64 @mesh_http_client()

declare ptr @mesh_http_send_with(i64, i64)

declare void @mesh_http_client_close(i64)

declare ptr @mesh_http_retry_class(ptr, ptr)

declare ptr @mesh_http_metrics()

declare void @mesh_test_begin(ptr)

declare void @mesh_test_pass()

declare void @mesh_test_fail_msg(ptr)

declare void @mesh_test_fail_msg_at(ptr, ptr, i64, i64)

declare void @mesh_test_assert(i8, ptr, ptr, i64, i64)

declare void @mesh_test_assert_eq(ptr, ptr, ptr, ptr, i64, i64)

declare void @mesh_test_assert_ne(ptr, ptr, ptr, ptr, i64, i64)

declare void @mesh_test_assert_raises(ptr, ptr, ptr, i64, i64)

declare void @mesh_test_summary(i64, i64, i64)

declare void @mesh_test_cleanup_actors()

declare void @mesh_test_run_body(ptr, ptr)

declare void @mesh_test_end()

declare i64 @mesh_test_mock_actor(ptr, ptr)

declare i8 @mesh_test_install_in_memory_secure_store()

declare i8 @mesh_test_set_push_token(ptr, ptr)

declare i64 @mesh_test_pass_count()

declare i64 @mesh_test_fail_count()

declare ptr @mesh_list_new()

declare i64 @mesh_list_length(ptr)

declare ptr @mesh_list_append(ptr, i64)

declare i64 @mesh_list_head(ptr)

declare ptr @mesh_list_tail(ptr)

declare i64 @mesh_list_get(ptr, i64)

declare ptr @mesh_list_concat(ptr, ptr)

declare ptr @mesh_list_reverse(ptr)

declare ptr @mesh_list_map(ptr, ptr, ptr)

declare ptr @mesh_list_filter(ptr, ptr, ptr)

declare i64 @mesh_list_reduce(ptr, i64, ptr, ptr)

declare ptr @mesh_list_from_array(ptr, i64)

declare ptr @mesh_list_builder_new(i64)

declare ptr @mesh_list_builder_push(ptr, i64)

declare ptr @mesh_list_sort(ptr, ptr, ptr)

declare ptr @mesh_list_find(ptr, ptr, ptr)

declare ptr @mesh_option_box_scalar(ptr)

declare i8 @mesh_list_any(ptr, ptr, ptr)

declare i8 @mesh_list_all(ptr, ptr, ptr)

declare i8 @mesh_list_contains(ptr, i64)

declare ptr @mesh_map_put_by(ptr, i64, i64, ptr, ptr)

declare i64 @mesh_map_get_by(ptr, i64, ptr, ptr)

declare i64 @mesh_map_fetch_by(ptr, i64, ptr, ptr)

declare i8 @mesh_map_has_key_by(ptr, i64, ptr, ptr)

declare ptr @mesh_map_delete_by(ptr, i64, ptr, ptr)

declare ptr @mesh_map_merge_by(ptr, ptr, ptr, ptr)

declare ptr @mesh_map_from_list_by(ptr, i64, ptr, ptr)

declare ptr @mesh_map_collect_by(ptr, i64, ptr, ptr)

declare i8 @mesh_map_eq_by(ptr, ptr, ptr, ptr, ptr)

declare ptr @mesh_set_add_by(ptr, i64, ptr, ptr)

declare ptr @mesh_set_remove_by(ptr, i64, ptr, ptr)

declare i8 @mesh_set_contains_by(ptr, i64, ptr, ptr)

declare ptr @mesh_set_union_by(ptr, ptr, ptr, ptr)

declare ptr @mesh_set_intersection_by(ptr, ptr, ptr, ptr)

declare ptr @mesh_set_difference_by(ptr, ptr, ptr, ptr)

declare i8 @mesh_set_eq_by(ptr, ptr, ptr, ptr)

declare ptr @mesh_set_from_list_by(ptr, ptr, ptr)

declare ptr @mesh_set_collect_by(ptr, ptr, ptr)

declare i8 @mesh_list_contains_by(ptr, i64, ptr)

declare i64 @mesh_list_hash_by(ptr, ptr)

declare i64 @mesh_set_hash_by(ptr, ptr)

declare i64 @mesh_map_hash_by(ptr, ptr, ptr)

declare i8 @mesh_list_contains_str(ptr, ptr)

declare ptr @mesh_list_zip(ptr, ptr)

declare ptr @mesh_list_flat_map(ptr, ptr, ptr)

declare ptr @mesh_list_flatten(ptr)

declare ptr @mesh_list_enumerate(ptr)

declare ptr @mesh_list_take(ptr, i64)

declare ptr @mesh_list_drop(ptr, i64)

declare i64 @mesh_list_last(ptr)

declare i64 @mesh_list_nth(ptr, i64)

declare ptr @mesh_map_new()

declare ptr @mesh_map_new_typed(i64)

declare ptr @mesh_map_tag_string(ptr)

declare ptr @mesh_map_put(ptr, i64, i64)

declare i64 @mesh_map_fetch(ptr, i64)

declare i64 @mesh_map_get(ptr, i64)

declare i8 @mesh_map_has_key(ptr, i64)

declare ptr @mesh_map_delete(ptr, i64)

declare i64 @mesh_map_size(ptr)

declare ptr @mesh_map_keys(ptr)

declare ptr @mesh_map_values(ptr)

declare ptr @mesh_map_merge(ptr, ptr)

declare ptr @mesh_map_to_list(ptr)

declare ptr @mesh_map_from_list(ptr)

declare i64 @mesh_map_entry_key(ptr, i64)

declare i64 @mesh_map_entry_value(ptr, i64)

declare ptr @mesh_set_new()

declare ptr @mesh_set_add(ptr, i64)

declare ptr @mesh_set_remove(ptr, i64)

declare i8 @mesh_set_contains(ptr, i64)

declare i64 @mesh_set_size(ptr)

declare ptr @mesh_set_union(ptr, ptr)

declare ptr @mesh_set_intersection(ptr, ptr)

declare i64 @mesh_set_element_at(ptr, i64)

declare ptr @mesh_set_difference(ptr, ptr)

declare ptr @mesh_set_to_list(ptr)

declare ptr @mesh_set_from_list(ptr)

declare i64 @mesh_tuple_nth(ptr, i64)

declare i64 @mesh_tuple_first(ptr)

declare i64 @mesh_tuple_second(ptr)

declare i64 @mesh_tuple_size(ptr)

declare ptr @mesh_range_new(i64, i64)

declare ptr @mesh_range_to_list(ptr)

declare ptr @mesh_range_map(ptr, ptr, ptr)

declare ptr @mesh_range_filter(ptr, ptr, ptr)

declare i64 @mesh_range_length(ptr)

declare ptr @mesh_queue_new()

declare ptr @mesh_queue_push(ptr, i64)

declare ptr @mesh_queue_pop(ptr)

declare i64 @mesh_queue_peek(ptr)

declare i64 @mesh_queue_size(ptr)

declare i8 @mesh_queue_is_empty(ptr)

declare ptr @mesh_json_parse(ptr)

declare ptr @mesh_json_encode(ptr)

declare ptr @mesh_json_encode_string(ptr)

declare ptr @mesh_json_encode_int(i64)

declare ptr @mesh_json_encode_bool(i8)

declare ptr @mesh_json_encode_map(ptr)

declare ptr @mesh_json_encode_list(ptr)

declare ptr @mesh_json_from_int(i64)

declare ptr @mesh_json_from_float(double)

declare ptr @mesh_json_from_bool(i8)

declare ptr @mesh_json_from_string(ptr)

declare ptr @mesh_json_get(ptr, ptr)

declare ptr @mesh_json_get_nested(ptr, ptr, ptr)

declare i8 @mesh_json_is_string(ptr, ptr)

declare ptr @mesh_json_object_new()

declare ptr @mesh_json_object_put(ptr, ptr, ptr)

declare ptr @mesh_json_object_get(ptr, ptr)

declare ptr @mesh_json_array_new()

declare ptr @mesh_json_array_push(ptr, ptr)

declare ptr @mesh_json_array_get(ptr, i64)

declare ptr @mesh_json_as_int(ptr)

declare ptr @mesh_json_as_float(ptr)

declare ptr @mesh_json_as_string(ptr)

declare ptr @mesh_json_as_bool(ptr)

declare ptr @mesh_json_value_as_int(ptr)

declare ptr @mesh_json_value_as_float(ptr)

declare ptr @mesh_json_value_as_bool(ptr)

declare ptr @mesh_json_null()

declare ptr @mesh_json_from_list(ptr, ptr)

declare ptr @mesh_json_from_map(ptr, ptr)

declare ptr @mesh_json_to_list(ptr, ptr)

declare ptr @mesh_json_to_map(ptr, ptr)

declare ptr @mesh_json_error_at(ptr, ptr)

declare ptr @mesh_alloc_result(i64, ptr)

declare i64 @mesh_result_is_ok(ptr)

declare ptr @mesh_result_unwrap(ptr)

declare ptr @mesh_http_router()

declare ptr @mesh_http_route(ptr, ptr, ptr, ptr)

declare void @mesh_http_serve(ptr, i64)

declare void @mesh_http_serve_tls(ptr, i64, ptr, ptr)

declare void @mesh_ws_serve(ptr, ptr, ptr, ptr, ptr, ptr, i64)

declare i64 @mesh_ws_send(ptr, ptr)

declare void @mesh_ws_serve_tls(ptr, ptr, ptr, ptr, ptr, ptr, i64, ptr, ptr)

declare i64 @mesh_ws_client_options()

declare i64 @mesh_ws_client_connect_timeout(i64, i64)

declare i64 @mesh_ws_client_heartbeat_timeout(i64, i64)

declare i64 @mesh_ws_client_max_message_bytes(i64, i64)

declare i64 @mesh_ws_client_queue_capacity(i64, i64)

declare ptr @mesh_ws_client_connect(ptr, i64)

declare ptr @mesh_ws_client_send_text(i64, ptr)

declare ptr @mesh_ws_client_send_bytes(i64, ptr)

declare ptr @mesh_ws_client_recv(i64, i64)

declare ptr @mesh_ws_client_close(i64, i64, ptr)

declare ptr @mesh_ws_client_reconnect_delay(i64, i64, i64, i64)

declare i64 @mesh_ws_join(ptr, ptr)

declare i64 @mesh_ws_leave(ptr, ptr)

declare i64 @mesh_ws_broadcast(ptr, ptr)

declare i64 @mesh_ws_broadcast_except(ptr, ptr, ptr)

declare ptr @mesh_http_response_new(i64, ptr)

declare ptr @mesh_http_response_bytes_new(i64, ptr)

declare ptr @mesh_http_response_bytes_with_headers(i64, ptr, ptr)

declare ptr @mesh_http_response_with_headers(i64, ptr, ptr)

declare ptr @mesh_http_request_method(ptr)

declare ptr @mesh_http_request_path(ptr)

declare ptr @mesh_http_request_body(ptr)

declare ptr @mesh_http_request_body_bytes(ptr)

declare ptr @mesh_http_request_header(ptr, ptr)

declare ptr @mesh_http_request_query(ptr, ptr)

declare ptr @mesh_http_request_id(ptr)

declare ptr @mesh_http_idempotency_key(ptr)

declare ptr @mesh_cluster_capacity()

declare ptr @mesh_cluster_pressure()

declare ptr @mesh_cluster_telemetry()

declare ptr @mesh_cluster_role()

declare ptr @mesh_cluster_state()

declare ptr @mesh_http_route_get(ptr, ptr, ptr, ptr)

declare ptr @mesh_http_route_post(ptr, ptr, ptr, ptr)

declare ptr @mesh_http_route_put(ptr, ptr, ptr, ptr)

declare ptr @mesh_http_route_delete(ptr, ptr, ptr, ptr)

declare ptr @mesh_http_request_param(ptr, ptr)

declare ptr @mesh_http_use_middleware(ptr, ptr, ptr)

declare ptr @mesh_sqlite_open(ptr)

declare void @mesh_sqlite_close(i64)

declare ptr @mesh_sqlite_execute(i64, ptr, ptr)

declare ptr @mesh_sqlite_query(i64, ptr, ptr)

declare ptr @mesh_sqlite_execute_values(i64, ptr, ptr)

declare ptr @mesh_sqlite_query_values(i64, ptr, ptr)

declare ptr @mesh_pg_connect(ptr)

declare void @mesh_pg_close(i64)

declare ptr @mesh_pg_execute(i64, ptr, ptr)

declare ptr @mesh_pg_query(i64, ptr, ptr)

declare ptr @mesh_pg_execute_values(i64, ptr, ptr)

declare ptr @mesh_pg_query_values(i64, ptr, ptr)

declare ptr @mesh_pg_begin(i64)

declare ptr @mesh_pg_commit(i64)

declare ptr @mesh_pg_rollback(i64)

declare ptr @mesh_pg_transaction(i64, ptr, ptr)

declare ptr @mesh_pg_cast(ptr, ptr)

declare ptr @mesh_pg_jsonb(ptr)

declare ptr @mesh_pg_int(ptr)

declare ptr @mesh_pg_text(ptr)

declare ptr @mesh_pg_uuid(ptr)

declare ptr @mesh_pg_timestamptz(ptr)

declare ptr @mesh_pg_gen_salt(ptr, i64)

declare ptr @mesh_pg_crypt(ptr, ptr)

declare ptr @mesh_pg_ts_rank(ptr, ptr)

declare ptr @mesh_pg_tsvector_matches(ptr, ptr)

declare ptr @mesh_pg_jsonb_contains(ptr, ptr)

declare ptr @mesh_pg_to_tsvector(ptr, ptr)

declare ptr @mesh_pg_plainto_tsquery(ptr, ptr)

declare ptr @mesh_pg_create_extension(i64, ptr)

declare ptr @mesh_pg_create_range_partitioned_table(i64, ptr, ptr, ptr)

declare ptr @mesh_pg_create_gin_index(i64, ptr, ptr, ptr, ptr)

declare ptr @mesh_pg_create_daily_partitions_ahead(i64, ptr, i64)

declare ptr @mesh_pg_list_daily_partitions_before(i64, ptr, i64)

declare ptr @mesh_pg_drop_partition(i64, ptr)

declare ptr @mesh_sqlite_begin(i64)

declare ptr @mesh_sqlite_commit(i64)

declare ptr @mesh_sqlite_rollback(i64)

declare ptr @mesh_pool_open(ptr, i64, i64, i64)

declare void @mesh_pool_close(i64)

declare ptr @mesh_pool_query(i64, ptr, ptr)

declare ptr @mesh_pool_execute(i64, ptr, ptr)

declare ptr @mesh_pool_execute_values(i64, ptr, ptr)

declare ptr @mesh_pool_query_values(i64, ptr, ptr)

declare ptr @mesh_row_from_row_get(ptr, ptr)

declare ptr @mesh_row_parse_int(ptr)

declare ptr @mesh_row_parse_float(ptr)

declare ptr @mesh_row_parse_bool(ptr)

declare ptr @mesh_pg_query_as(i64, ptr, ptr, ptr, ptr)

declare ptr @mesh_pool_query_as(i64, ptr, ptr, ptr, ptr)

declare i64 @mesh_hash_int(i64)

declare i64 @mesh_hash_float(double)

declare i64 @mesh_hash_bool(i8)

declare i64 @mesh_hash_string(ptr)

declare i64 @mesh_hash_combine(i64, i64)

declare ptr @mesh_list_to_string(ptr, ptr)

declare ptr @mesh_map_to_string(ptr, ptr, ptr)

declare ptr @mesh_set_to_string(ptr, ptr)

declare ptr @mesh_string_inspect(ptr)

declare ptr @mesh_string_to_string(i64)

declare i8 @mesh_map_eq(ptr, ptr, ptr)

declare i8 @mesh_set_eq(ptr, ptr)

declare i8 @mesh_list_eq(ptr, ptr, ptr)

declare i64 @mesh_list_compare(ptr, ptr, ptr)

declare ptr @mesh_service_call(i64, i64, ptr, i64)

declare void @mesh_service_reply(i64, ptr, i64)

declare ptr @mesh_service_call_shaped(i64, i64, ptr, i64, ptr)

declare void @mesh_service_cast_shaped(i64, ptr, i64, ptr)

declare void @mesh_service_reply_shaped(i64, ptr, i64, ptr)

declare ptr @mesh_jobs_migrate(i64)

declare ptr @mesh_jobs_enqueue(i64, ptr, ptr)

declare ptr @mesh_jobs_enqueue_in(i64, ptr, ptr)

declare ptr @mesh_jobs_control(i64, ptr, ptr)

declare ptr @mesh_jobs_start(i64, ptr, ptr, ptr)

declare ptr @mesh_jobs_start_effects_v1(i64, ptr, ptr, ptr, ptr, ptr)

declare ptr @mesh_jobs_effect_v1(ptr, ptr)

declare ptr @mesh_jobs_drain(i64, ptr, ptr, ptr, ptr)

declare ptr @mesh_test_jobs_inspect(i64, ptr, ptr)

declare ptr @mesh_test_jobs_inspect_in(i64, ptr, ptr)

declare ptr @mesh_test_assert_enqueued(i64, ptr, ptr, i64)

declare ptr @mesh_test_refute_enqueued(i64, ptr, ptr, i64)

declare ptr @mesh_test_assert_enqueued_in(i64, ptr, ptr)

declare ptr @mesh_test_refute_enqueued_in(i64, ptr, ptr)

declare ptr @mesh_test_build_job(ptr, i64)

declare ptr @mesh_test_perform_job(ptr, i64, ptr, ptr)

declare ptr @mesh_jobs_stop(i64, i64)

declare ptr @mesh_jobs_join(i64)

declare ptr @mesh_jobs_status(i64)

declare ptr @mesh_jobs_read_events(i64, i64)

declare ptr @mesh_jobs_local_control(i64, ptr)

declare void @mesh_jobs_register_handler(ptr, i64, ptr)

declare void @mesh_jobs_enter_worker(i32, ptr)

declare i64 @mesh_job_async(ptr, ptr)

declare ptr @mesh_job_await(i64)

declare ptr @mesh_job_await_timeout(i64, i64)

declare ptr @mesh_job_map(ptr, ptr, ptr)

declare i64 @mesh_job_async_shaped(ptr, ptr, ptr)

declare ptr @mesh_job_map_shaped(ptr, ptr, ptr, ptr)

declare void @mesh_timer_sleep(i64)

declare void @mesh_timer_send_after(i64, i64, ptr, i64)

declare void @mesh_timer_apply_after(i64, ptr, ptr)

declare void @mesh_timer_send_after_shaped(i64, i64, ptr, i64, ptr)

; Function Attrs: noreturn
declare void @mesh_panic(ptr, i64, ptr, i64, i32) #0

; Function Attrs: noreturn
declare void @mesh_panic_at(ptr, i64, ptr, i64, i32, i32) #0

declare i64 @mesh_node_start(ptr, i64, ptr, i64)

declare i64 @mesh_node_connect(ptr, i64)

declare ptr @mesh_node_self()

declare ptr @mesh_node_list()

declare i64 @mesh_node_monitor(ptr, i64, ptr, i64, ptr)

declare i64 @mesh_node_spawn(ptr, i64, ptr, i64, ptr, i64, ptr, i64, i8)

declare void @mesh_register_function(ptr, i64, ptr, ptr, i64)

declare void @mesh_register_declared_handler(ptr, i64, ptr, i64, i64, ptr)

declare void @mesh_register_startup_work(ptr, i64)

declare void @mesh_trigger_startup_work()

declare i64 @mesh_process_monitor(i64, ptr, i64, ptr)

declare i64 @mesh_process_demonitor(i64)

declare i64 @mesh_process_register(ptr, i64)

declare i64 @mesh_process_whereis(ptr)

declare void @mesh_process_install_shutdown_signals()

declare i8 @mesh_process_shutdown_requested()

declare void @mesh_process_request_shutdown()

declare void @mesh_plaintext_enter()

declare void @mesh_plaintext_leave()

; Function Attrs: noreturn
declare void @mesh_panic_str(ptr) #0

; Function Attrs: noreturn
declare void @mesh_panic_str_at(ptr, ptr, i64, i32, i32) #0

; Function Attrs: noreturn
declare void @mesh_process_exit(i64) #0

declare ptr @mesh_list_iter_new(ptr)

declare ptr @mesh_list_iter_next(ptr)

declare ptr @mesh_map_iter_new(ptr)

declare ptr @mesh_map_iter_next(ptr)

declare ptr @mesh_set_iter_new(ptr)

declare ptr @mesh_set_iter_next(ptr)

declare ptr @mesh_range_iter_new(i64, i64)

declare ptr @mesh_range_iter(ptr)

declare ptr @mesh_range_iter_next(ptr)

declare ptr @mesh_iter_from(ptr)

declare ptr @mesh_iter_map(ptr, ptr, ptr)

declare ptr @mesh_iter_filter(ptr, ptr, ptr)

declare ptr @mesh_iter_take(ptr, i64)

declare ptr @mesh_iter_skip(ptr, i64)

declare ptr @mesh_iter_enumerate(ptr)

declare ptr @mesh_iter_zip(ptr, ptr)

declare i64 @mesh_iter_count(ptr)

declare i64 @mesh_iter_sum(ptr)

declare i8 @mesh_iter_any(ptr, ptr, ptr)

declare i8 @mesh_iter_all(ptr, ptr, ptr)

declare ptr @mesh_iter_find(ptr, ptr, ptr)

declare i64 @mesh_iter_reduce(ptr, i64, ptr, ptr)

declare ptr @mesh_iter_generic_next(ptr)

declare ptr @mesh_iter_map_next(ptr)

declare ptr @mesh_iter_filter_next(ptr)

declare ptr @mesh_iter_take_next(ptr)

declare ptr @mesh_iter_skip_next(ptr)

declare ptr @mesh_iter_enumerate_next(ptr)

declare ptr @mesh_iter_zip_next(ptr)

declare ptr @mesh_list_collect(ptr)

declare ptr @mesh_map_collect(ptr)

declare ptr @mesh_map_collect_string_keys(ptr)

declare ptr @mesh_set_collect(ptr)

declare ptr @mesh_string_collect(ptr)

declare ptr @mesh_orm_build_select(ptr, ptr, ptr, ptr, i64, i64)

declare ptr @mesh_orm_build_insert(ptr, ptr, ptr)

declare ptr @mesh_orm_build_update(ptr, ptr, ptr, ptr)

declare ptr @mesh_orm_build_delete(ptr, ptr, ptr)

declare ptr @mesh_expr_column(ptr)

declare ptr @mesh_expr_value(ptr)

declare ptr @mesh_expr_null()

declare ptr @mesh_expr_call(ptr, ptr)

declare ptr @mesh_expr_add(ptr, ptr)

declare ptr @mesh_expr_sub(ptr, ptr)

declare ptr @mesh_expr_mul(ptr, ptr)

declare ptr @mesh_expr_div(ptr, ptr)

declare ptr @mesh_expr_eq(ptr, ptr)

declare ptr @mesh_expr_neq(ptr, ptr)

declare ptr @mesh_expr_lt(ptr, ptr)

declare ptr @mesh_expr_lte(ptr, ptr)

declare ptr @mesh_expr_gt(ptr, ptr)

declare ptr @mesh_expr_gte(ptr, ptr)

declare ptr @mesh_expr_case(ptr, ptr, ptr)

declare ptr @mesh_expr_coalesce(ptr)

declare ptr @mesh_expr_excluded(ptr)

declare ptr @mesh_expr_alias(ptr, ptr)

declare ptr @mesh_query_from(ptr)

declare ptr @mesh_query_where(ptr, ptr, ptr)

declare ptr @mesh_query_where_op(ptr, ptr, ptr, ptr)

declare ptr @mesh_query_where_in(ptr, ptr, ptr)

declare ptr @mesh_query_where_null(ptr, ptr)

declare ptr @mesh_query_where_not_null(ptr, ptr)

declare ptr @mesh_query_where_not_in(ptr, ptr, ptr)

declare ptr @mesh_query_where_between(ptr, ptr, ptr, ptr)

declare ptr @mesh_query_where_or(ptr, ptr, ptr)

declare ptr @mesh_query_where_expr(ptr, ptr)

declare ptr @mesh_query_select(ptr, ptr)

declare ptr @mesh_query_select_expr(ptr, ptr)

declare ptr @mesh_query_select_exprs(ptr, ptr)

declare ptr @mesh_query_order_by(ptr, ptr, ptr)

declare ptr @mesh_query_limit(ptr, i64)

declare ptr @mesh_query_offset(ptr, i64)

declare ptr @mesh_query_join(ptr, ptr, ptr, ptr)

declare ptr @mesh_query_join_as(ptr, ptr, ptr, ptr, ptr)

declare ptr @mesh_query_group_by(ptr, ptr)

declare ptr @mesh_query_having(ptr, ptr, ptr)

declare ptr @mesh_query_select_count(ptr)

declare ptr @mesh_query_select_count_field(ptr, ptr)

declare ptr @mesh_query_select_sum(ptr, ptr)

declare ptr @mesh_query_select_avg(ptr, ptr)

declare ptr @mesh_query_select_min(ptr, ptr)

declare ptr @mesh_query_select_max(ptr, ptr)

declare ptr @mesh_query_fragment(ptr, ptr, ptr)

declare ptr @mesh_query_select_raw(ptr, ptr)

declare ptr @mesh_query_where_raw(ptr, ptr, ptr)

declare ptr @mesh_query_order_by_raw(ptr, ptr)

declare ptr @mesh_query_group_by_raw(ptr, ptr)

declare ptr @mesh_query_where_sub(ptr, ptr, ptr)

declare ptr @mesh_repo_all(i64, ptr)

declare ptr @mesh_repo_one(i64, ptr)

declare ptr @mesh_repo_get(i64, ptr, ptr)

declare ptr @mesh_repo_get_by(i64, ptr, ptr, ptr)

declare ptr @mesh_repo_count(i64, ptr)

declare ptr @mesh_repo_exists(i64, ptr)

declare ptr @mesh_repo_insert(i64, ptr, ptr)

declare ptr @mesh_repo_insert_expr(i64, ptr, ptr)

declare ptr @mesh_repo_update(i64, ptr, ptr, ptr)

declare ptr @mesh_repo_delete(i64, ptr, ptr)

declare ptr @mesh_repo_transaction(i64, ptr, ptr)

declare ptr @mesh_repo_update_where(i64, ptr, ptr, ptr)

declare ptr @mesh_repo_update_where_expr(i64, ptr, ptr, ptr)

declare ptr @mesh_repo_delete_where(i64, ptr, ptr)

declare ptr @mesh_repo_query_raw(i64, ptr, ptr)

declare ptr @mesh_repo_execute_raw(i64, ptr, ptr)

declare ptr @mesh_repo_insert_or_update(i64, ptr, ptr, ptr, ptr)

declare ptr @mesh_repo_insert_or_update_expr(i64, ptr, ptr, ptr, ptr)

declare ptr @mesh_repo_delete_where_returning(i64, ptr, ptr)

declare ptr @mesh_repo_preload(i64, ptr, ptr, ptr)

declare ptr @mesh_repo_insert_changeset(i64, ptr, ptr)

declare ptr @mesh_repo_update_changeset(i64, ptr, ptr, ptr)

declare ptr @mesh_changeset_cast(ptr, ptr, ptr)

declare ptr @mesh_changeset_cast_with_types(ptr, ptr, ptr, ptr)

declare ptr @mesh_changeset_validate_required(ptr, ptr)

declare ptr @mesh_changeset_validate_length(ptr, ptr, ptr, ptr)

declare ptr @mesh_changeset_validate_format(ptr, ptr, ptr)

declare ptr @mesh_changeset_validate_inclusion(ptr, ptr, ptr)

declare ptr @mesh_changeset_validate_number(ptr, ptr, ptr, ptr, ptr, ptr)

declare ptr @mesh_changeset_valid(ptr)

declare ptr @mesh_changeset_errors(ptr)

declare ptr @mesh_changeset_changes(ptr)

declare ptr @mesh_changeset_get_change(ptr, ptr)

declare ptr @mesh_changeset_get_error(ptr, ptr)

declare ptr @mesh_migration_create_table(i64, ptr, ptr)

declare ptr @mesh_migration_drop_table(i64, ptr)

declare ptr @mesh_migration_add_column(i64, ptr, ptr)

declare ptr @mesh_migration_drop_column(i64, ptr, ptr)

declare ptr @mesh_migration_rename_column(i64, ptr, ptr, ptr)

declare ptr @mesh_migration_create_index(i64, ptr, ptr, ptr)

declare ptr @mesh_migration_drop_index(i64, ptr, ptr)

declare ptr @mesh_migration_execute(i64, ptr)

declare i64 @mesh_global_register(ptr, i64, i64)

declare i64 @mesh_global_whereis(ptr, i64)

declare i64 @mesh_global_unregister(ptr, i64)

declare ptr @mesh_node_start_from_env()

declare ptr @mesh_continuity_submit_with_durability(ptr, ptr, ptr, ptr, ptr, i64, i8, i8)

declare ptr @mesh_continuity_submit_declared_work(ptr, ptr, ptr, i64)

declare ptr @mesh_continuity_submit(ptr, ptr, ptr, ptr, ptr, i8, i8)

declare ptr @mesh_continuity_status(ptr)

declare ptr @mesh_continuity_authority_status()

declare ptr @mesh_continuity_mark_completed(ptr, ptr, ptr)

declare ptr @mesh_continuity_complete_declared_work(ptr, ptr)

declare ptr @mesh_continuity_acknowledge_replica(ptr, ptr)

declare i64 @actor_probe_ready(i64)

declare i64 @actor_probe_finish(i64, i64)

declare i64 @actor_probe_await(i64, i64)

declare i64 @actor_probe_checkpoint(i64)

declare i64 @actor_probe_report(i64, i64)

define {} @__actor_immediate_body(i64 %0) {
entry:
  %ticket = alloca i64, align 8
  store i64 %0, ptr %ticket, align 8
  %ticket1 = load i64, ptr %ticket, align 8
  %ticket2 = load i64, ptr %ticket, align 8
  %call = call i64 @actor_probe_finish(i64 %ticket1, i64 %ticket2)
  call void @mesh_reduction_check()
  ret {} zeroinitializer
}

define {} @immediate(ptr %0) {
entry:
  %__args_ptr = alloca ptr, align 8
  store ptr %0, ptr %__args_ptr, align 8
  %args_ptr_val = load ptr, ptr %__args_ptr, align 8
  %arg_0 = getelementptr i64, ptr %args_ptr_val, i64 0
  %arg_01 = load i64, ptr %arg_0, align 8
  %body_call = call {} @__actor_immediate_body(i64 %arg_01)
  ret {} zeroinitializer
}

define {} @__actor_parked_body(i64 %0) {
entry:
  %1 = alloca i64, align 8
  %2 = alloca i64, align 8
  %3 = alloca i64, align 8
  %4 = alloca i64, align 8
  %5 = alloca i64, align 8
  %ticket = alloca i64, align 8
  store i64 %0, ptr %ticket, align 8
  %ticket1 = load i64, ptr %ticket, align 8
  %call = call i64 @actor_probe_ready(i64 %ticket1)
  call void @mesh_reduction_check()
  %recv_scalar = alloca i64, align 8
  %scalar_ptr = call ptr @mesh_actor_receive_scalar(i64 -1, i64 8, ptr %recv_scalar)
  %receive_empty = icmp eq ptr %scalar_ptr, null
  br i1 %receive_empty, label %receive_stopped, label %receive_message

receive_stopped:                                  ; preds = %entry
  call void @mesh_actor_stop()
  unreachable

receive_message:                                  ; preds = %entry
  %msg_scalar = load i64, ptr %scalar_ptr, align 8
  store i64 %msg_scalar, ptr %1, align 8
  %__recv_msg_1912 = load i64, ptr %1, align 8
  store i64 %__recv_msg_1912, ptr %2, align 8
  %path_val = load i64, ptr %2, align 8
  store i64 %path_val, ptr %4, align 8
  %value3 = load i64, ptr %4, align 8
  store i64 %value3, ptr %3, align 8
  br label %match_merge

match_merge:                                      ; preds = %receive_message
  %match_val = load i64, ptr %3, align 8
  store i64 %match_val, ptr %5, align 8
  %ticket5 = load i64, ptr %ticket, align 8
  %value6 = load i64, ptr %5, align 8
  %call7 = call i64 @actor_probe_finish(i64 %ticket5, i64 %value6)
  call void @mesh_reduction_check()
  ret {} zeroinitializer
}

define {} @parked(ptr %0) {
entry:
  %__args_ptr = alloca ptr, align 8
  store ptr %0, ptr %__args_ptr, align 8
  %args_ptr_val = load ptr, ptr %__args_ptr, align 8
  %arg_0 = getelementptr i64, ptr %args_ptr_val, i64 0
  %arg_01 = load i64, ptr %arg_0, align 8
  %body_call = call {} @__actor_parked_body(i64 %arg_01)
  ret {} zeroinitializer
}

define i64 @Main__start_immediate(i64 %0, i64 %1) {
entry:
  %2 = alloca i64, align 8
  %3 = alloca i64, align 8
  %first = alloca i64, align 8
  store i64 %0, ptr %first, align 8
  %end_id = alloca i64, align 8
  store i64 %1, ptr %end_id, align 8
  %reduction_state = call ptr @mesh_reduction_state_v1()
  br label %tce_loop

tce_loop:                                         ; preds = %reduction_slow, %reduction_debit, %else, %entry
  %first1 = load i64, ptr %first, align 8
  %end_id2 = load i64, ptr %end_id, align 8
  %cmp = icmp eq i64 %first1, %end_id2
  br i1 %cmp, label %then, label %else

then:                                             ; preds = %tce_loop
  store i64 0, ptr %2, align 8
  br label %if_merge

else:                                             ; preds = %tce_loop
  %first3 = load i64, ptr %first, align 8
  %spawn_args = call ptr @mesh_gc_alloc_actor(i64 8, i64 8)
  %word = getelementptr i64, ptr %spawn_args, i64 0
  store i64 %first3, ptr %word, align 8
  %pid = call i64 @mesh_actor_spawn(ptr @immediate, ptr %spawn_args, i64 8, i8 1)
  store i64 %pid, ptr %3, align 8
  %first4 = load i64, ptr %first, align 8
  %add = add i64 %first4, 1
  %end_id5 = load i64, ptr %end_id, align 8
  store i64 %add, ptr %first, align 8
  store i64 %end_id5, ptr %end_id, align 8
  %reduction_remaining = load i32, ptr %reduction_state, align 4
  switch i32 %reduction_remaining, label %reduction_debit [
    i32 0, label %reduction_slow
    i32 -1, label %tce_loop
  ]

if_merge:                                         ; preds = %then
  %if_val = load i64, ptr %2, align 8
  ret i64 %if_val

reduction_slow:                                   ; preds = %else
  call void @mesh_reduction_check()
  br label %tce_loop

reduction_debit:                                  ; preds = %else
  %reduction_next = sub i32 %reduction_remaining, 1
  store i32 %reduction_next, ptr %reduction_state, align 4
  br label %tce_loop
}

define i64 @Main__start_parked(i64 %0, i64 %1, i64 %2) {
entry:
  %3 = alloca i64, align 8
  %4 = alloca i64, align 8
  %5 = alloca i64, align 8
  %6 = alloca i64, align 8
  %first = alloca i64, align 8
  store i64 %0, ptr %first, align 8
  %end_id = alloca i64, align 8
  store i64 %1, ptr %end_id, align 8
  %sample = alloca i64, align 8
  store i64 %2, ptr %sample, align 8
  %first1 = load i64, ptr %first, align 8
  %end_id2 = load i64, ptr %end_id, align 8
  %cmp = icmp eq i64 %first1, %end_id2
  %if_result = alloca i64, align 8
  br i1 %cmp, label %then, label %else

then:                                             ; preds = %entry
  %end_id3 = load i64, ptr %end_id, align 8
  %call = call i64 @actor_probe_await(i64 %end_id3, i64 0)
  call void @mesh_reduction_check()
  %sample4 = load i64, ptr %sample, align 8
  %cmp5 = icmp sgt i64 %sample4, 0
  br i1 %cmp5, label %then7, label %else8

else:                                             ; preds = %entry
  %first12 = load i64, ptr %first, align 8
  %spawn_args = call ptr @mesh_gc_alloc_actor(i64 8, i64 8)
  %word = getelementptr i64, ptr %spawn_args, i64 0
  store i64 %first12, ptr %word, align 8
  %pid = call i64 @mesh_actor_spawn(ptr @parked, ptr %spawn_args, i64 8, i8 1)
  store i64 %pid, ptr %4, align 8
  %first13 = load i64, ptr %first, align 8
  %add = add i64 %first13, 1
  %end_id14 = load i64, ptr %end_id, align 8
  %sample15 = load i64, ptr %sample, align 8
  %call16 = call i64 @Main__start_parked(i64 %add, i64 %end_id14, i64 %sample15)
  call void @mesh_reduction_check()
  store i64 %call16, ptr %5, align 8
  %child17 = load i64, ptr %4, align 8
  %first18 = load i64, ptr %first, align 8
  store i64 %first18, ptr %6, align 8
  %send_status = call i64 @mesh_actor_send(i64 %child17, ptr %6, i64 8)
  store i64 0, ptr %if_result, align 8
  br label %if_merge

if_merge:                                         ; preds = %else, %if_merge9
  %if_val19 = load i64, ptr %if_result, align 8
  ret i64 %if_val19

then7:                                            ; preds = %then
  %sample10 = load i64, ptr %sample, align 8
  %call11 = call i64 @actor_probe_checkpoint(i64 %sample10)
  call void @mesh_reduction_check()
  store i64 %call11, ptr %3, align 8
  br label %if_merge9

else8:                                            ; preds = %then
  store i64 0, ptr %3, align 8
  br label %if_merge9

if_merge9:                                        ; preds = %else8, %then7
  %if_val = load i64, ptr %3, align 8
  store i64 %if_val, ptr %if_result, align 8
  br label %if_merge
}

define i64 @Main__waves(i64 %0, i64 %1, i64 %2, i64 %3, i64 %4) {
entry:
  %5 = alloca i64, align 8
  %6 = alloca i64, align 8
  %7 = alloca i64, align 8
  %8 = alloca i64, align 8
  %9 = alloca i64, align 8
  %10 = alloca i64, align 8
  %11 = alloca i64, align 8
  %12 = alloca i64, align 8
  %13 = alloca i64, align 8
  %14 = alloca i64, align 8
  %first = alloca i64, align 8
  store i64 %0, ptr %first, align 8
  %total = alloca i64, align 8
  store i64 %1, ptr %total, align 8
  %width = alloca i64, align 8
  store i64 %2, ptr %width, align 8
  %hold = alloca i64, align 8
  store i64 %3, ptr %hold, align 8
  %memory = alloca i64, align 8
  store i64 %4, ptr %memory, align 8
  %reduction_state = call ptr @mesh_reduction_state_v1()
  br label %tce_loop

tce_loop:                                         ; preds = %reduction_slow, %reduction_debit, %if_merge52, %entry
  %first1 = load i64, ptr %first, align 8
  %total2 = load i64, ptr %total, align 8
  %cmp = icmp eq i64 %first1, %total2
  br i1 %cmp, label %then, label %else

then:                                             ; preds = %tce_loop
  store i64 0, ptr %5, align 8
  br label %if_merge

else:                                             ; preds = %tce_loop
  %first3 = load i64, ptr %first, align 8
  %width4 = load i64, ptr %width, align 8
  %add = add i64 %first3, %width4
  store i64 %add, ptr %6, align 8
  %hold5 = load i64, ptr %hold, align 8
  %cmp6 = icmp eq i64 %hold5, 1
  br i1 %cmp6, label %then8, label %else9

if_merge:                                         ; preds = %then
  %if_val61 = load i64, ptr %5, align 8
  ret i64 %if_val61

then8:                                            ; preds = %else
  %memory11 = load i64, ptr %memory, align 8
  %cmp12 = icmp eq i64 %memory11, 1
  br i1 %cmp12, label %and_rhs, label %and_merge

else9:                                            ; preds = %else
  %first35 = load i64, ptr %first, align 8
  %end_id36 = load i64, ptr %6, align 8
  %call37 = call i64 @Main__start_immediate(i64 %first35, i64 %end_id36)
  call void @mesh_reduction_check()
  store i64 %call37, ptr %7, align 8
  br label %if_merge10

if_merge10:                                       ; preds = %else9, %if_merge18
  %if_val38 = load i64, ptr %7, align 8
  store i64 %if_val38, ptr %8, align 8
  %end_id39 = load i64, ptr %6, align 8
  %call40 = call i64 @actor_probe_await(i64 %end_id39, i64 1)
  call void @mesh_reduction_check()
  store i64 %call40, ptr %9, align 8
  %memory42 = load i64, ptr %memory, align 8
  %cmp43 = icmp eq i64 %memory42, 1
  br i1 %cmp43, label %and_rhs44, label %and_merge45

and_rhs:                                          ; preds = %then8
  %first13 = load i64, ptr %first, align 8
  %cmp14 = icmp eq i64 %first13, 0
  br label %and_merge

and_merge:                                        ; preds = %and_rhs, %then8
  %and_result = phi i1 [ false, %then8 ], [ %cmp14, %and_rhs ]
  br i1 %and_result, label %then16, label %else17

then16:                                           ; preds = %and_merge
  store i64 1, ptr %10, align 8
  br label %if_merge18

else17:                                           ; preds = %and_merge
  %memory19 = load i64, ptr %memory, align 8
  %cmp20 = icmp eq i64 %memory19, 1
  br i1 %cmp20, label %and_rhs21, label %and_merge22

if_merge18:                                       ; preds = %if_merge30, %then16
  %if_val31 = load i64, ptr %10, align 8
  store i64 %if_val31, ptr %11, align 8
  %first32 = load i64, ptr %first, align 8
  %end_id33 = load i64, ptr %6, align 8
  %sample34 = load i64, ptr %11, align 8
  %call = call i64 @Main__start_parked(i64 %first32, i64 %end_id33, i64 %sample34)
  call void @mesh_reduction_check()
  store i64 %call, ptr %7, align 8
  br label %if_merge10

and_rhs21:                                        ; preds = %else17
  %end_id23 = load i64, ptr %6, align 8
  %total24 = load i64, ptr %total, align 8
  %cmp25 = icmp eq i64 %end_id23, %total24
  br label %and_merge22

and_merge22:                                      ; preds = %and_rhs21, %else17
  %and_result26 = phi i1 [ false, %else17 ], [ %cmp25, %and_rhs21 ]
  br i1 %and_result26, label %then28, label %else29

then28:                                           ; preds = %and_merge22
  store i64 3, ptr %12, align 8
  br label %if_merge30

else29:                                           ; preds = %and_merge22
  store i64 0, ptr %12, align 8
  br label %if_merge30

if_merge30:                                       ; preds = %else29, %then28
  %if_val = load i64, ptr %12, align 8
  store i64 %if_val, ptr %10, align 8
  br label %if_merge18

and_rhs44:                                        ; preds = %if_merge10
  %first46 = load i64, ptr %first, align 8
  %cmp47 = icmp eq i64 %first46, 0
  br label %and_merge45

and_merge45:                                      ; preds = %and_rhs44, %if_merge10
  %and_result48 = phi i1 [ false, %if_merge10 ], [ %cmp47, %and_rhs44 ]
  br i1 %and_result48, label %then50, label %else51

then50:                                           ; preds = %and_merge45
  %call53 = call i64 @actor_probe_checkpoint(i64 2)
  call void @mesh_reduction_check()
  store i64 %call53, ptr %13, align 8
  br label %if_merge52

else51:                                           ; preds = %and_merge45
  store i64 0, ptr %13, align 8
  br label %if_merge52

if_merge52:                                       ; preds = %else51, %then50
  %if_val54 = load i64, ptr %13, align 8
  store i64 %if_val54, ptr %14, align 8
  %end_id56 = load i64, ptr %6, align 8
  %total57 = load i64, ptr %total, align 8
  %width58 = load i64, ptr %width, align 8
  %hold59 = load i64, ptr %hold, align 8
  %memory60 = load i64, ptr %memory, align 8
  store i64 %end_id56, ptr %first, align 8
  store i64 %total57, ptr %total, align 8
  store i64 %width58, ptr %width, align 8
  store i64 %hold59, ptr %hold, align 8
  store i64 %memory60, ptr %memory, align 8
  %reduction_remaining = load i32, ptr %reduction_state, align 4
  switch i32 %reduction_remaining, label %reduction_debit [
    i32 0, label %reduction_slow
    i32 -1, label %tce_loop
  ]

reduction_slow:                                   ; preds = %if_merge52
  call void @mesh_reduction_check()
  br label %tce_loop

reduction_debit:                                  ; preds = %if_merge52
  %reduction_next = sub i32 %reduction_remaining, 1
  store i32 %reduction_next, ptr %reduction_state, align 4
  br label %tce_loop
}

define i64 @mesh_main() {
entry:
  %0 = alloca i64, align 8
  %call = call i64 @mesh_env_get_int(ptr @.str, i64 1)
  %width = alloca i64, align 8
  store i64 %call, ptr %width, align 8
  %call1 = call i64 @mesh_env_get_int(ptr @.str.1, i64 16384)
  %total = alloca i64, align 8
  store i64 %call1, ptr %total, align 8
  %call2 = call i64 @mesh_env_get_int(ptr @.str.2, i64 1)
  %hold = alloca i64, align 8
  store i64 %call2, ptr %hold, align 8
  %call3 = call i64 @mesh_env_get_int(ptr @.str.3, i64 0)
  %memory = alloca i64, align 8
  store i64 %call3, ptr %memory, align 8
  %call4 = call i64 @actor_probe_checkpoint(i64 0)
  call void @mesh_reduction_check()
  %_ = alloca i64, align 8
  store i64 %call4, ptr %_, align 8
  %total5 = load i64, ptr %total, align 8
  %width6 = load i64, ptr %width, align 8
  %hold7 = load i64, ptr %hold, align 8
  %memory8 = load i64, ptr %memory, align 8
  %call9 = call i64 @Main__waves(i64 0, i64 %total5, i64 %width6, i64 %hold7, i64 %memory8)
  call void @mesh_reduction_check()
  %_10 = alloca i64, align 8
  store i64 %call9, ptr %_10, align 8
  %memory11 = load i64, ptr %memory, align 8
  %cmp = icmp eq i64 %memory11, 1
  %if_result = alloca i64, align 8
  br i1 %cmp, label %then, label %else

then:                                             ; preds = %entry
  %call12 = call i64 @actor_probe_checkpoint(i64 4)
  call void @mesh_reduction_check()
  store i64 %call12, ptr %if_result, align 8
  br label %if_merge

else:                                             ; preds = %entry
  store i64 0, ptr %if_result, align 8
  br label %if_merge

if_merge:                                         ; preds = %else, %then
  %if_val = load i64, ptr %if_result, align 8
  store i64 %if_val, ptr %0, align 8
  %total14 = load i64, ptr %total, align 8
  %hold15 = load i64, ptr %hold, align 8
  %call16 = call i64 @actor_probe_report(i64 %total14, i64 %hold15)
  call void @mesh_reduction_check()
  ret i64 %call16
}

define i32 @main(i32 %0, ptr %1) {
entry:
  call void @mesh_rt_disable_core_dumps()
  call void @mesh_rt_init()
  call void @mesh_rt_init_actor(i32 0)
  call void @mesh_register_function(ptr @fn_reg_immediate, i64 9, ptr @immediate, ptr @fn_sig_immediate, i64 1)
  call void @mesh_register_function(ptr @fn_reg_parked, i64 6, ptr @parked, ptr @fn_sig_parked, i64 1)
  call void @mesh_register_function(ptr @fn_reg_Main__start_immediate, i64 21, ptr @Main__start_immediate, ptr @fn_sig_Main__start_immediate, i64 2)
  call void @mesh_register_function(ptr @fn_reg_Main__start_parked, i64 18, ptr @Main__start_parked, ptr @fn_sig_Main__start_parked, i64 3)
  call void @mesh_register_function(ptr @fn_reg_Main__waves, i64 11, ptr @Main__waves, ptr @fn_sig_Main__waves, i64 5)
  call void @mesh_register_function(ptr @fn_reg_mesh_main, i64 9, ptr @mesh_main, ptr null, i64 0)
  call void @mesh_jobs_enter_worker(i32 %0, ptr %1)
  call void @mesh_run_main(ptr @mesh_main)
  call void @mesh_rt_run_scheduler()
  ret i32 0
}

attributes #0 = { noreturn }
