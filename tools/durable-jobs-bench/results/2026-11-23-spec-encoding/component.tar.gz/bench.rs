mod stock { include!("production.rs"); include!("route.rs"); }
mod owned { include!("owned.rs"); include!("route.rs"); }
use std::env;
use std::hint::black_box;
use std::time::Instant;
fn main() {
    let args: Vec<String>=env::args().collect();
    let inputs=std::fs::read_to_string(&args[1]).unwrap();
    let mut count=0; let mut bytes=0;
    let clock=Instant::now();
    for _ in 0..args[3].parse::<usize>().unwrap() {
        for batch in inputs.lines() {
            let values=match &*args[2] {
                "stock"|"duplicate"=>stock::batch(black_box(batch),false),
                "direct"=>stock::batch(black_box(batch),true),
                "owned"=>owned::batch(black_box(batch),false),
                "both"=>owned::batch(black_box(batch),true),
                _=>panic!("bad mode")
            }.unwrap();
            if args.len()>4 { println!("{}",serde_json::to_string(&values).unwrap()); }
            for (s,k,f) in &values { count+=1;bytes+=s.len()+k.len()+f.len(); }
            black_box(&values);
        }
    }
    eprintln!("{} {} {}",count,bytes,clock.elapsed().as_nanos());
}
