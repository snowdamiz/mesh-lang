from pathlib import Path
import hashlib,json,runpy,subprocess,resource,time,sys,os
from statistics import median
D=Path(__file__).resolve().parent
root=D.parent.parent
parity=runpy.run_path(str(root/'scripts/jobs-parity.py'))
profiles=json.loads((root/'scripts/jobs-parity-profiles.json').read_text())
encode=lambda d:json.dumps(d,ensure_ascii=False,separators=(',',':'))
def chunks(jobs):
    specs=[]; size=2
    for job in jobs:
        spec=encode(dict(worker="parity",args=job,request_key=job['key'],max_attempts=3,backoff_base_ms=1000,backoff_max_ms=1000))
        n=len(spec.encode())
        if specs and (size+n+1>1048576 or len(specs)==128):
            yield '['+','.join(specs)+']'
            specs=[];size=2
        size+=n+bool(specs); specs.append(spec)
    if specs: yield '['+','.join(specs)+']'
def signature(binary,path,mode):
    # Compare every normalized byte, request key, and full SHA-256 fingerprint.
    with subprocess.Popen([binary,path,mode,'1','print'],stdout=subprocess.PIPE,stderr=subprocess.PIPE) as proc:
        digest=hashlib.file_digest(proc.stdout,'sha256').hexdigest()
        stats=proc.stderr.read().decode()
        assert proc.wait()==0,stats
    return digest
def cpu():
    r=resource.getrusage(resource.RUSAGE_CHILDREN)
    return r.ru_utime+r.ru_stime
def main():
    out=D/sys.argv[1]
    out.mkdir()
    bin=D/'bench'
    trials=['stock','direct','owned','both','duplicate']
    files={}
    jobs_per={}
    for kind,slots in [('noop',64),('short',16),('large',64),('sparse',1)]:
        batches=parity['inputs'](profiles['workloads'][kind],slots,profiles['seed'])
        strings=[c for b in batches for c in chunks(b['jobs'])]
        path=out/(kind+'.jsonl')
        path.write_text('\n'.join(strings)+'\n')
        files[kind]=path
        jobs_per[kind]=sum(len(b['jobs']) for b in batches)
    metadata={}
    for kind,path in files.items():
        checks={k:signature(bin,path,k) for k in trials}
        assert len(set(checks.values()))==1,checks
        metadata[kind]=dict(input_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                            output_sha256=checks['stock'],jobs=jobs_per[kind])
    (out/'inputs.json').write_text(json.dumps(metadata,indent=2)+'\n')
    with (out/'timings.jsonl').open('x',buffering=1) as handle:
        for g in range(5):
            for kind,path in files.items():
                n={'noop':10,'short':30,'large':3,'sparse':40}[kind]
                for i in (0,1,4,2,3):
                    mode=trials[(g+i)%5]
                    before=cpu()
                    proc=subprocess.run([bin,path,mode,str(n)],capture_output=True,text=True,check=True)
                    after=cpu()
                    count,bytes_sum,ns=map(int,proc.stderr.split())
                    assert count==n*jobs_per[kind]
                    item=dict(group=g+1,profile=kind,mode=mode,subject_cpu_ms=(after-before)*1000/n,
                              kernel_elapsed_ms=ns/1e6/n,bytes=bytes_sum//n,jobs=count//n,load=os.getloadavg())
                    print(json.dumps(item),file=handle)
    print('verified',metadata)
if __name__=='__main__':main()
