from pathlib import Path
import subprocess
p=Path(__file__).resolve().parent
root=p.parent.parent
src=(root/'compiler/mesh-rt/src/jobs/store.rs').read_text()
core=(src[:src.index('use crate::')] +
      src[src.index('const MAX_INPUT:'):src.index('pub(super) fn response(')] +
      src[src.index('#[derive(Clone, Copy, Debug, Deserialize, Serialize, PartialEq, Eq, PartialOrd, Ord)]'):src.index('pub(super) fn test_context(')])
# The benchmark uses production defaults, rules, ordering and normalization.
(p/'production.rs').write_text(core)
a=core.index('        let mut spec = serde_json::to_value(self)')
b=core.index('        let fingerprint =',a)
new=core[:a]+'''        let args = std::mem::take(&mut self.args);
        let metadata = std::mem::take(&mut self.metadata);
        let mut spec = serde_json::to_value(&*self).map_err(|error| error.to_string())?;
        spec["args"] = args;
        spec["metadata"] = metadata;
        spec["unique"] = unique.unwrap_or(Value::Null);
        spec["replace"] = json!(replace);
        let encoded = spec.to_string();
        self.args = spec["args"].take();
        self.metadata = spec["metadata"].take();
        let spec = encoded;
'''+core[b:]
(p/'owned.rs').write_text(new)
deps=root/'target/native-bulk-enqueue-integration/build/release/deps'
rust=Path.home()/'.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin/rustc'
args=[str(rust),'--edition=2021','-C','opt-level=3','-A','dead_code','-L','dependency='+str(deps)]
for crate in ['serde','serde_json','sha2']:
 (lib,)=deps.glob('lib'+crate+'-*.rlib')
 args.extend(['--extern',crate+'='+str(lib)])
subprocess.run([*args,str(p/'bench.rs'),'-o',str(p/'bench')],check=True)
