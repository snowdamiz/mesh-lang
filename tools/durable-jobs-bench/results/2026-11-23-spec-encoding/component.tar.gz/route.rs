pub(super) fn batch(input: &str, direct: bool) -> Result<Vec<(String,String,String)>,String> {
    let parsed = if direct {
        match input.trim_start_matches([' ', '\t', '\n', '\r']).as_bytes().first() {
            Some(b'[') => decode::<Vec<JobSpec>>(input).map(Enqueue::Batch),
            Some(b'{') => decode::<JobSpec>(input).map(|s| Enqueue::Single(Box::new(s))),
            _ => decode(input),
        }
    } else {
        decode(input)
    }?;
    let jobs = match parsed { Enqueue::Single(s) => vec![*s], Enqueue::Batch(v) => v };
    if jobs.is_empty() || jobs.len() > MAX_BATCH { return Err("mesh jobs enqueue requires 1 to 128 specs".into()); }
    jobs.into_iter().map(|mut j| {
        let a=j.prepare()?;
        Ok((a.spec,a.request_key,a.fingerprint))
    }).collect()
}
