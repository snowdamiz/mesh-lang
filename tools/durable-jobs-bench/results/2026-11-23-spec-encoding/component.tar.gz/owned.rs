use serde::{de::DeserializeOwned, Deserialize, Serialize};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::collections::BTreeMap;

const MAX_INPUT: usize = 1024 * 1024;
const MAX_BATCH: usize = 128;
const MAX_DURATION_MS: u64 = 365 * 24 * 60 * 60 * 1000;
pub(super) const MAX_TIMESTAMP_MS: u64 = 253_402_300_799_999;
const MAX_CONCURRENCY: u32 = 1024;
const MAX_PAGE: u32 = 1000;

pub(super) fn decode<T: DeserializeOwned>(input: &str) -> Result<T, String> {
    if input.len() > MAX_INPUT {
        return Err("mesh jobs JSON exceeds 1 MiB".into());
    }
    serde_json::from_str(input).map_err(|error| error.to_string())
}

pub(super) fn name(value: &str, field: &str) -> Result<(), String> {
    if value.trim().is_empty() || value.len() > 255 || value.contains('\0') {
        return Err(format!(
            "mesh jobs {field} must be nonblank text of at most 255 bytes"
        ));
    }
    Ok(())
}

fn duration(value: u64, field: &str) -> Result<(), String> {
    if value > MAX_DURATION_MS {
        return Err(format!("mesh jobs {field} exceeds 365 days"));
    }
    Ok(())
}

fn lease_duration(value: u64) -> Result<(), String> {
    if value == 0 {
        return Err("mesh jobs lease_ms must be positive".into());
    }
    duration(value, "lease_ms")
}

fn scheduling(scheduled_at_ms: Option<u64>, delay_ms: Option<u64>) -> Result<(), String> {
    if let Some(timestamp) = scheduled_at_ms {
        if delay_ms.is_some() || timestamp > MAX_TIMESTAMP_MS {
            return Err("mesh jobs scheduled_at_ms must be a UTC timestamp through year 9999 and cannot be combined with delay_ms".into());
        }
    }
    duration(delay_ms.unwrap_or_default(), "delay_ms")
}

#[derive(Clone, Copy, Debug, Deserialize, Serialize, PartialEq, Eq, PartialOrd, Ord)]
#[serde(rename_all = "snake_case")]
pub(super) enum State {
    Available,
    Scheduled,
    Retryable,
    Suspended,
    Executing,
    Completed,
    Cancelled,
    Discarded,
}

const INCOMPLETE: &[State] = &[
    State::Available,
    State::Scheduled,
    State::Retryable,
    State::Suspended,
    State::Executing,
];

#[derive(Clone, Copy, Deserialize, Serialize, PartialEq, Eq, PartialOrd, Ord)]
#[serde(rename_all = "snake_case")]
enum UniqueField {
    Worker,
    Version,
    Queue,
    Args,
    #[serde(alias = "meta")]
    Metadata,
}

#[derive(Deserialize)]
#[serde(rename_all = "snake_case")]
enum StateGroup {
    All,
    Incomplete,
    Scheduled,
    Successful,
}

#[derive(Deserialize)]
#[serde(untagged)]
enum States {
    Group(StateGroup),
    List(Vec<State>),
}

#[derive(Deserialize)]
#[serde(untagged)]
enum Period {
    Milliseconds(u64),
    Infinity(Infinity),
}

#[derive(Deserialize)]
#[serde(rename_all = "snake_case")]
enum Infinity {
    Infinity,
}

#[derive(Default, Deserialize, Serialize)]
#[serde(rename_all = "snake_case")]
enum UniqueTimestamp {
    #[default]
    InsertedAt,
    ScheduledAt,
}

#[derive(Default, Deserialize)]
#[serde(deny_unknown_fields)]
struct UniqueOptions {
    key: Option<String>,
    fields: Option<Vec<UniqueField>>,
    #[serde(default)]
    keys: Vec<String>,
    states: Option<States>,
    period_ms: Option<Period>,
    #[serde(default)]
    timestamp: UniqueTimestamp,
}

#[derive(Deserialize)]
#[serde(untagged)]
enum UniqueInput {
    Enabled(bool),
    Key(String),
    Options(UniqueOptions),
}

impl UniqueInput {
    fn policy(self) -> Result<Value, String> {
        let mut options = match self {
            Self::Enabled(false) => return Ok(Value::Null),
            Self::Enabled(true) => UniqueOptions {
                states: Some(States::Group(StateGroup::All)),
                period_ms: Some(Period::Infinity(Infinity::Infinity)),
                ..UniqueOptions::default()
            },
            Self::Key(key) => UniqueOptions {
                key: Some(key),
                states: Some(States::Group(StateGroup::All)),
                period_ms: Some(Period::Infinity(Infinity::Infinity)),
                ..UniqueOptions::default()
            },
            Self::Options(options) => options,
        };
        if let Some(key) = &options.key {
            name(key, "unique key")?;
        }
        let mut fields = options.fields.unwrap_or_else(|| {
            let mut fields = vec![UniqueField::Worker, UniqueField::Queue];
            if options.key.is_none() {
                fields.push(UniqueField::Args);
            }
            fields
        });
        if fields.is_empty() && options.key.is_none() {
            return Err("mesh jobs unique fields cannot be empty without a unique key".into());
        }
        fields.sort_unstable();
        fields.dedup();

        let mut states = match options
            .states
            .unwrap_or(States::Group(StateGroup::Successful))
        {
            States::List(states) => states,
            States::Group(StateGroup::Incomplete) => INCOMPLETE.to_vec(),
            States::Group(StateGroup::Scheduled) => vec![State::Scheduled],
            States::Group(StateGroup::Successful) => [INCOMPLETE, &[State::Completed]].concat(),
            States::Group(StateGroup::All) => [
                INCOMPLETE,
                &[State::Completed, State::Cancelled, State::Discarded],
            ]
            .concat(),
        };
        if states.is_empty() {
            return Err("mesh jobs unique states cannot be empty".into());
        }
        states.sort_unstable();
        states.dedup();

        if options.keys.len() > 128 {
            return Err("mesh jobs accepts at most 128 uniqueness keys".into());
        }
        for key in &options.keys {
            name(key, "unique projection key")?;
        }
        options.keys.sort_unstable();
        options.keys.dedup();
        let period_ms = match options.period_ms.unwrap_or(Period::Milliseconds(60_000)) {
            Period::Milliseconds(0) => {
                return Err("mesh jobs unique period_ms must be positive".into())
            }
            Period::Milliseconds(value) => {
                duration(value, "unique period_ms")?;
                Some(value)
            }
            Period::Infinity(_) => None,
        };
        Ok(json!({
            "key": options.key, "fields": fields, "keys": options.keys, "states": states,
            "period_ms": period_ms, "timestamp": options.timestamp,
        }))
    }
}

#[derive(Clone, Copy, Deserialize, Serialize, PartialEq, Eq, PartialOrd, Ord)]
#[serde(rename_all = "snake_case")]
enum ReplaceField {
    Args,
    MaxAttempts,
    #[serde(alias = "meta")]
    Metadata,
    Priority,
    Queue,
    #[serde(alias = "scheduled_at")]
    ScheduledAtMs,
    Tags,
    Worker,
}

#[derive(Deserialize)]
#[serde(untagged)]
enum Replace {
    All(Vec<ReplaceField>),
    ByState(BTreeMap<State, Vec<ReplaceField>>),
}

impl Replace {
    fn by_state(self) -> BTreeMap<State, Vec<ReplaceField>> {
        let mut rules = match self {
            Self::All(fields) => INCOMPLETE
                .iter()
                .copied()
                .chain([State::Completed, State::Cancelled, State::Discarded])
                .map(|state| (state, fields.clone()))
                .collect(),
            Self::ByState(rules) => rules,
        };
        for fields in rules.values_mut() {
            fields.sort_unstable();
            fields.dedup();
        }
        rules
    }
}

#[derive(Deserialize, Serialize)]
#[serde(default, deny_unknown_fields)]
struct JobSpec {
    worker: String,
    version: u32,
    args: Value,
    queue: String,
    #[serde(alias = "meta")]
    metadata: Value,
    priority: u8,
    tags: Vec<String>,
    scheduled_at_ms: Option<u64>,
    delay_ms: Option<u64>,
    max_attempts: u32,
    timeout_ms: u64,
    backoff_base_ms: u64,
    backoff_max_ms: u64,
    suspended: bool,
    #[serde(skip_serializing)]
    request_key: Option<String>,
    #[serde(skip_serializing)]
    unique: Option<UniqueInput>,
    #[serde(skip_serializing)]
    replace: Option<Replace>,
}

impl Default for JobSpec {
    fn default() -> Self {
        Self {
            worker: String::new(),
            version: 1,
            args: json!({}),
            queue: "default".into(),
            metadata: json!({}),
            priority: 0,
            tags: Vec::new(),
            scheduled_at_ms: None,
            delay_ms: None,
            max_attempts: 20,
            timeout_ms: 60_000,
            backoff_base_ms: 1_000,
            backoff_max_ms: 3_600_000,
            suspended: false,
            request_key: None,
            unique: None,
            replace: None,
        }
    }
}

impl JobSpec {
    fn prepare(&mut self) -> Result<Admission, String> {
        name(&self.worker, "worker")?;
        name(&self.queue, "queue")?;
        if self.version == 0 || !(1..=100).contains(&self.max_attempts) || self.priority > 9 {
            return Err(
                "mesh jobs requires version > 0, max_attempts 1..=100 and priority 0..=9".into(),
            );
        }
        if !self.args.is_object() || !self.metadata.is_object() {
            return Err("mesh jobs args and metadata must be JSON objects".into());
        }
        if self.tags.len() > 128 {
            return Err("mesh jobs accepts at most 128 tags".into());
        }
        for tag in &self.tags {
            name(tag, "tag")?;
        }
        if self.timeout_ms == 0 || self.backoff_base_ms > self.backoff_max_ms {
            return Err(
                "mesh jobs requires timeout_ms > 0 and backoff_base_ms <= backoff_max_ms".into(),
            );
        }
        duration(self.timeout_ms, "timeout_ms")?;
        duration(self.backoff_max_ms, "backoff_max_ms")?;
        scheduling(self.scheduled_at_ms, self.delay_ms)?;

        let request_key = match self.request_key.take() {
            Some(key) => {
                name(&key, "request_key")?;
                key
            }
            None => String::new(),
        };
        let unique = self.unique.take().map(UniqueInput::policy).transpose()?;
        let replace = self
            .replace
            .take()
            .map(Replace::by_state)
            .unwrap_or_default();
        if unique.as_ref().is_none_or(Value::is_null) && !replace.is_empty() {
            return Err("mesh jobs replace requires a unique policy".into());
        }
        let args = std::mem::take(&mut self.args);
        let metadata = std::mem::take(&mut self.metadata);
        let mut spec = serde_json::to_value(&*self).map_err(|error| error.to_string())?;
        spec["args"] = args;
        spec["metadata"] = metadata;
        spec["unique"] = unique.unwrap_or(Value::Null);
        spec["replace"] = json!(replace);
        let encoded = spec.to_string();
        self.args = spec["args"].take();
        self.metadata = spec["metadata"].take();
        let spec = encoded;
        let fingerprint = format!("{:x}", Sha256::digest(spec.as_bytes()));
        Ok(Admission {
            spec,
            request_key,
            fingerprint,
        })
    }
}

struct Admission {
    spec: String,
    request_key: String,
    fingerprint: String,
}

#[derive(Deserialize)]
#[serde(untagged)]
enum Enqueue {
    Batch(Vec<JobSpec>),
    Single(Box<JobSpec>),
}

