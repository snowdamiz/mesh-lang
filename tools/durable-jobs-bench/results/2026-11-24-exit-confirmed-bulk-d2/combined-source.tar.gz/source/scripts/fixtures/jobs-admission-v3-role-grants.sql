-- Apply as the Jobs object owner after migrating to the v3 candidate and
-- applying jobs-role-grants.sql. Set worker to the existing scoped Jobs role.
REVOKE EXECUTE ON FUNCTION mesh_jobs.claim_admitted_v3(text,text,jsonb,bigint,integer,bigint),
    mesh_jobs.complete_admitted_v3(text,uuid[],uuid[]) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION mesh_jobs.claim_admitted_v3(text,text,jsonb,bigint,integer,bigint),
    mesh_jobs.complete_admitted_v3(text,uuid[],uuid[]) TO :"worker";
