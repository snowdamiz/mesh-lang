use std::thread::{self, JoinHandle};

use super::*;

struct Member {
    id: String,
    token: String,
    ready_at: Instant,
}

type ResultForMember = Option<Result<Settlement, JobsAckError>>;

struct Request {
    session: JobSession,
    members: Vec<Member>,
    dispatched_at: Instant,
}

struct Response {
    session: JobSession,
    results: Vec<ResultForMember>,
}

pub(super) struct CompletionWriter {
    requests: Option<SyncSender<Request>>,
    results: Receiver<Response>,
    thread: Option<JoinHandle<()>>,
    hold: Duration,
    in_flight: Vec<String>,
}

impl CompletionWriter {
    pub(super) fn start(runner: &Runner, hold: Duration) -> std::io::Result<Self> {
        let (requests, receive) = mpsc::sync_channel::<Request>(1);
        let (send, results) = mpsc::sync_channel(1);
        let namespace = runner.config.namespace.clone();
        let dispatcher = thread::current();
        let trace = std::env::var_os("MESH_JOBS_COMPLETION_TRACE").is_some();
        let start = Instant::now();
        let thread = thread::Builder::new()
            .name(format!("mesh-jobs-complete-{}", runner.id))
            .spawn(move || {
                let micros = |at: Instant| at.saturating_duration_since(start).as_micros();
                while let Ok(mut request) = receive.recv() {
                    let writing_at = Instant::now();
                    let results = write(&mut request.session, &namespace, &request.members);
                    let returned_at = Instant::now();
                    if trace {
                        eprintln!(
                            "completion_writer {}",
                            serde_json::json!({
                                "handoff_us": micros(request.dispatched_at),
                                "write_us": micros(writing_at),
                                "response_us": micros(returned_at),
                                "members": request.members.iter().zip(&results)
                                    .map(|(member, result)| serde_json::json!({
                                        "id": member.id,
                                        "ready_us": micros(member.ready_at),
                                        "result": match result {
                                            Some(Ok(Settlement::Completed)) => "completed",
                                            Some(Ok(_)) => "scalar_other",
                                            Some(Err(JobsAckError::Unconfirmed(_))) => "uncertain",
                                            Some(Err(JobsAckError::Rejected(_))) => "rejected",
                                            None => "scalar_fallback",
                                        },
                                    })).collect::<Vec<_>>(),
                            })
                        );
                    }
                    if send
                        .send(Response {
                            session: request.session,
                            results,
                        })
                        .is_err()
                    {
                        break;
                    }
                    dispatcher.unpark();
                }
            })?;
        Ok(Self {
            requests: Some(requests),
            results,
            thread: Some(thread),
            hold,
            in_flight: Vec::new(),
        })
    }

    pub(super) fn busy(&self) -> bool {
        !self.in_flight.is_empty()
    }

    pub(super) fn collects(&self, runner: &Runner, attempt: &Attempt) -> bool {
        self.requests.is_some()
            && attempt.submissions == 0
            && success_ready(&runner.state.lock(), attempt).is_some()
    }

    pub(super) fn flush(
        &mut self,
        runner: &Runner,
        io: &mut LifecycleIo,
        attempts: &mut [Attempt],
    ) -> Option<Instant> {
        let requests = self.requests.as_ref()?;
        let now = Instant::now();
        let mut members = Vec::new();
        let mut deadline = now + self.hold;
        let mut active = false;
        let mut scalar_due = false;
        {
            let state = runner.state.lock();
            if !matches!(state.phase, Phase::Running) {
                deadline = now;
            }
            for attempt in attempts.iter() {
                let Some(lease) = attempt.lease else { continue };
                let job = &state.jobs[&attempt.token];
                if matches!(state.queues[&job.queue].phase, QueuePhase::Stopping(_)) {
                    deadline = now;
                }
                match &job.execution {
                    Execution::Running(worker) if worker.stop.is_none() => {
                        active = true;
                        deadline = deadline.min(lease.renew_at.unwrap_or(now));
                    }
                    Execution::Acknowledging {
                        reply,
                        retry_at: None,
                        ready_at,
                        ..
                    } if attempt.submissions == 0
                        && matches!(reply.outcome().0, Outcome::Complete) =>
                    {
                        deadline = deadline.min(*ready_at + self.hold).min(lease.expires_at);
                        if members.len() < MAX_COMPLETE_COHORT {
                            members.push(Member {
                                id: attempt.id.clone(),
                                token: attempt.token.clone(),
                                ready_at: *ready_at,
                            });
                        }
                    }
                    Execution::Acknowledging { retry_at, .. } => {
                        let retry_at = retry_at.unwrap_or(now);
                        deadline = deadline.min(retry_at);
                        scalar_due |= retry_at <= now;
                    }
                    _ => {}
                }
            }
        }
        // Drain ready scalar outcomes before submitting another success group.
        // When collecting, the dispatcher waits without starting scalar I/O.
        if scalar_due {
            return Some(now);
        }
        if members.is_empty() {
            return None;
        }
        if members.len() < MAX_COMPLETE_COHORT && active && Instant::now() < deadline {
            return Some(deadline);
        }

        for member in &members {
            self.in_flight.push(member.token.clone());
        }
        let request = Request {
            session: io.session.take().expect("available lifecycle session"),
            members,
            dispatched_at: Instant::now(),
        };
        if let Err(error) = requests.try_send(request) {
            // No request reached the worker. Keep the original session and
            // fall back to the dispatcher for subsequent scalar settlements.
            let request = match error {
                mpsc::TrySendError::Disconnected(request) | mpsc::TrySendError::Full(request) => request,
            };
            io.session = Some(request.session);
            self.in_flight.clear();
            self.requests.take();
            runner.storage_failure(
                Operation::Acknowledge,
                "Jobs completion writer unavailable".into(),
                None,
            );
        }
        None
    }

    pub(super) fn receive(
        &mut self,
        runner: &Runner,
        io: &mut LifecycleIo,
        attempts: &mut Vec<Attempt>,
        freed: &mut HashSet<String>,
    ) {
        if self.in_flight.is_empty() {
            return;
        }
        let results = match self.results.try_recv() {
            Ok(response) => {
                io.session = Some(response.session);
                response.results
            }
            Err(TryRecvError::Empty) => return,
            Err(TryRecvError::Disconnected) => {
                self.requests.take();
                // The receiver owns and drops the old checkout on thread exit.
                io.session = unsafe { JobSession::from_pool(io.pool) }.ok();
                runner.request_stop(Duration::ZERO);
                self.in_flight
                    .iter()
                    .map(|_| {
                        Some(Err(JobsAckError::Unconfirmed(
                            "Jobs completion writer disconnected during settlement".into(),
                        )))
                    })
                    .collect()
            }
        };
        let mut confirmed = HashSet::new();
        for (token, result) in self.in_flight.drain(..).zip(results) {
            let attempt = attempts
                .iter_mut()
                .find(|attempt| attempt.token == token)
                .expect("submitted attempt retains its slot");
            attempt.submissions = 1;
            let Some(result) = result else { continue };
            let (handler_duration_ms, identity) = {
                let state = runner.state.lock();
                let job = &state.jobs[&token];
                let Execution::Acknowledging {
                    handler_duration_ms,
                    ..
                } = &job.execution
                else {
                    unreachable!("writer only accepts returned successes");
                };
                (*handler_duration_ms, job.identity.clone())
            };
            let ack = Acknowledgement {
                submission: 1,
                handler_duration_ms,
                failure_kind: None,
            };
            if !attempt.ack_result(runner, ack, identity.as_ref(), result) {
                confirmed.insert(token);
            }
        }
        if !confirmed.is_empty() {
            let mut state = runner.state.lock();
            attempts.retain(|attempt| {
                if !confirmed.contains(&attempt.token) {
                    return true;
                }
                state.jobs.remove(&attempt.token);
                if runner.wakeups.is_some() {
                    freed.insert(attempt.queue.clone());
                }
                false
            });
        }
    }
}

impl Drop for CompletionWriter {
    fn drop(&mut self) {
        self.requests.take();
        if let Some(thread) = self.thread.take() {
            let _ = thread.join();
        }
    }
}

fn success_ready(state: &State, attempt: &Attempt) -> Option<Instant> {
    match &state.jobs[&attempt.token].execution {
        Execution::Acknowledging {
            reply,
            retry_at: None,
            ready_at,
            ..
        } if attempt.lease.is_some() && matches!(reply.outcome().0, Outcome::Complete) => {
            Some(*ready_at)
        }
        _ => None,
    }
}

fn write(session: &mut JobSession, namespace: &str, members: &[Member]) -> Vec<ResultForMember> {
    if let [member] = members {
        return vec![Some(
            session
                .with(|db| {
                    Ok(finish(
                        db,
                        namespace,
                        &member.id,
                        &member.token,
                        Outcome::Complete,
                    ))
                })
                .map_err(JobsAckError::Rejected)
                .and_then(|result| result),
        )];
    }
    let keys: Vec<_> = members
        .iter()
        .map(|member| (member.id.as_str(), member.token.as_str()))
        .collect();
    match session.with(|db| Ok(complete_admitted(db, namespace, &keys))) {
        Ok(Ok(completed)) => completed
            .into_iter()
            .take(members.len())
            .map(|committed| committed.then_some(Ok(Settlement::Completed)))
            .collect(),
        Ok(Err(JobsAckError::Unconfirmed(error))) => members
            .iter()
            .map(|_| Some(Err(JobsAckError::Unconfirmed(error.clone()))))
            .collect(),
        // A confirmed rejection, skipped row or failed checkout leaves the
        // original reply intact for the scalar path.
        _ => members.iter().map(|_| None).collect(),
    }
}
