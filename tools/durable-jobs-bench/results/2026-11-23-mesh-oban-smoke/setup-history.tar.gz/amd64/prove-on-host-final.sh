#!/usr/bin/env bash
set -euo pipefail
umask 077
export LC_ALL=C.UTF-8
base=/var/lib/durable-jobs-bench/native
work="$base/amd64-port-3f69b150"
source="$work/source"
log="$work/logs"
baseline=dbcb6dbc1de3a6887fc3757c2b91f7974d74ed17
candidate=3f69b150820fd01ba716d533be4f2eedea25ed27
rust="$base/toolchain/rust-1.99.0"
llvm="$base/toolchain/llvm-21.1.8"
pg="$work/pgsql-17.11-compat"
test "$(uname -sm)" = 'Linux x86_64'
test "$("$rust/bin/rustc" --version | cut -d' ' -f2)" = 1.99.0
test "$("$llvm/bin/llvm-config" --version)" = 21.1.8
test "$("$pg/bin/postgres" --version)" = 'postgres (PostgreSQL) 17.11'
exec 8<>/var/tmp/mesh-durable-jobs-matrix/active-arm.lock
flock -w 600 8
exec 9<>"$base/native.lock"
flock -w 600 9
install -d -o nobody -g nogroup -m 0700 "$work/home" "$work/tmp" "$log" "$work/trace"

as_proof_user() {
  runuser -u nobody -- env -i \
    HOME="$work/home" CARGO_HOME="$work/home/cargo" TMPDIR="$work/tmp" \
    PATH="$rust/bin:$llvm/bin:$pg/bin:/usr/bin:/bin" LC_ALL=C.UTF-8 \
    PG_BIN_DIR="$pg/bin" LLVM_SYS_211_PREFIX="$llvm" \
    CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_LINKER="$work/proof-gnu-linker" \
    CARGO_TARGET_DIR="$work/cargo" CARGO_BUILD_JOBS=4 \
    "$@" 8>&- 9>&-
}
cd "$source"
run() {
  local name=$1 result=0
  shift
  as_proof_user "$@" >"$log/$name.log" 2>&1 || result=$?
  printf '%s %s\n' "$name" "$result"
  printf '%s\n' "$result" >"$log/$name.result"
  return "$result"
}
probe=9b66c7f6c143d0813ca1ca4617bf1cb143690f18
runtime="$work/cargo/debug/libmesh_rt.a"
as_proof_user git checkout --quiet --detach "$baseline"
as_proof_user sh -c 'git show "$1:scripts/verify-postgres-jobs.sh" > scripts/verify-amd64-historical-jobs.sh' sh "$probe"
run baseline-exact-build cargo build --locked -p meshc -p mesh-rt
sha256sum "$work/cargo/debug/meshc" "$runtime" > "$log/baseline-artifacts.log"
result=0
run baseline-exact-refusal env MESH_RT_LIB_PATH="$runtime" \
  bash scripts/verify-amd64-historical-jobs.sh --effect-compiled || result=$?
test "$result" -eq 1
grep -Fx 'compiled effect proof: Jobs effects require a compiled Linux GNU ARM64 Mesh program' \
  "$log/baseline-exact-refusal.log"
as_proof_user rm -- scripts/verify-amd64-historical-jobs.sh

as_proof_user git checkout --quiet --detach "$probe"
as_proof_user git diff --exit-code "$candidate" -- compiler Cargo.toml Cargo.lock .cargo
run compiled-poll-fresh bash scripts/verify-postgres-jobs.sh --effect-compiled
sha256sum "$work/cargo/debug/meshc" "$runtime" > "$log/current-artifacts.log"
test "$(awk 'NR==2 {print $1}' "$log/baseline-artifacts.log")" != "$(awk 'NR==2 {print $1}' "$log/current-artifacts.log")"
run compiled-listen-thp-fresh env MESH_EFFECT_LISTEN=1 MESH_DIAGNOSTIC_JOB_DISABLE_THP=1 \
  bash scripts/verify-postgres-jobs.sh --effect-compiled
run pg-17.11-compat env MESH_RT_LIB_PATH="$runtime" \
  bash scripts/verify-postgres-jobs.sh --compatibility 17.11 --parity-driver-check --j6-roles
