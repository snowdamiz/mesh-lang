#!/usr/bin/env bash
set -euo pipefail
umask 077
export LC_ALL=C.UTF-8
base=/var/lib/durable-jobs-bench/native
work="$base/amd64-port-3f69b150"
source="$work/source"
log="$work/logs"
baseline=dbcb6dbc1de3a6887fc3757c2b91f7974d74ed17
candidate=3f69b150820fd01ba716d533be4f2eedea25ed27
rust="$base/toolchain/rust-1.99.0"
llvm="$base/toolchain/llvm-21.1.8"
pg="$base/toolchain/pgsql-17.11"
test "$(uname -sm)" = 'Linux x86_64'
test "$("$rust/bin/rustc" --version | cut -d' ' -f2)" = 1.99.0
test "$("$llvm/bin/llvm-config" --version)" = 21.1.8
test "$("$pg/bin/postgres" --version)" = 'postgres (PostgreSQL) 17.11'
exec 9<>"$base/native.lock"
flock -w 1200 9
install -d -o nobody -g nogroup -m 0700 "$work/home" "$work/tmp" "$log" "$work/trace"

if [[ -f "$log/native-build.log" && -f "$log/native-build.result" ]]; then
  mv -- "$log/native-build.log" "$log/native-build-bfd-rejection.log"
  mv -- "$log/native-build.result" "$log/native-build-bfd-rejection.result"
fi
cat > "$work/proof-gnu-linker" <<'LINKER'
#!/bin/sh
set -eu
llvm="${LLVM_SYS_211_PREFIX:?}"
exec "$llvm/bin/clang" -fuse-ld=lld --ld-path="$llvm/bin/ld.lld" "$@" \
  -Wl,--lto-O0 -Wl,--strip-debug \
  -Wl,--thinlto-cache-dir=/var/lib/durable-jobs-bench/native/amd64-port-3f69b150/thinlto
LINKER
chmod 0755 "$work/proof-gnu-linker"

as_proof_user() {
  runuser -u nobody -- env -i \
    HOME="$work/home" CARGO_HOME="$work/home/cargo" TMPDIR="$work/tmp" \
    PATH="$rust/bin:$llvm/bin:$pg/bin:/usr/bin:/bin" LC_ALL=C.UTF-8 \
    PG_BIN_DIR="$pg/bin" LLVM_SYS_211_PREFIX="$llvm" \
    CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_LINKER="$work/proof-gnu-linker" \
    CARGO_TARGET_DIR="$work/cargo" CARGO_BUILD_JOBS=4 \
    "$@" 9>&-
}
cd "$source"
test "$(as_proof_user git rev-parse HEAD)" = "$candidate"
run() {
  local name=$1 result=0
  shift
  as_proof_user "$@" >"$log/$name.log" 2>&1 || result=$?
  printf '%s %s\n' "$name" "$result"
  printf '%s\n' "$result" >"$log/$name.result"
  return "$result"
}
{
  printf 'checkout %s\n' "$candidate"
  uname -smr
  getconf GNU_LIBC_VERSION
  "$rust/bin/rustc" -Vv
  "$llvm/bin/llvm-config" --version
  "$pg/bin/postgres" --version
} >"$log/platform.log"

run native-build cargo build --locked -p meshc -p mesh-rt
run effects-poll strace -ff -e trace=wait4,waitid,exit_group -o "$work/trace/native" \
  bash scripts/verify-postgres-jobs.sh --effect-compiled || true
run effects-listen-thp env MESH_EFFECT_LISTEN=1 MESH_DIAGNOSTIC_JOB_DISABLE_THP=1 \
  bash scripts/verify-postgres-jobs.sh --effect-compiled || true
run bounded-json cargo test --locked -p mesh-rt --lib json::tests::bounded_object_encoding_checks_nested_depth_and_bytes || true
run session-reset cargo test --locked -p mesh-rt --lib db::pg::jobs_effect_session::tests || true
run effect-fence bash scripts/verify-postgres-jobs.sh --effect-fence || true
run pg-17.11 bash scripts/verify-postgres-jobs.sh --compatibility 17.11 --parity-driver-check --j6-roles || true

as_proof_user git checkout --quiet --detach "$baseline"
result=0
run baseline-host-gate bash scripts/verify-postgres-jobs.sh --effect-compiled || result=$?
test "$result" -eq 2
as_proof_user sh -c 'git show "$1:scripts/verify-postgres-jobs.sh" > scripts/verify-amd64-historical-jobs.sh' sh "$candidate"
result=0
run baseline-compiled-refusal bash scripts/verify-amd64-historical-jobs.sh --effect-compiled || result=$?
test "$result" -eq 1
grep -Fx 'compiled effect proof: Jobs effects require a compiled Linux GNU ARM64 Mesh program' \
  "$log/baseline-compiled-refusal.log"
as_proof_user rm -- scripts/verify-amd64-historical-jobs.sh
as_proof_user git checkout --quiet --detach "$candidate"
for name in effects-poll effects-listen-thp bounded-json session-reset effect-fence pg-17.11; do
  test "$(cat "$log/$name.result")" -eq 0
done
