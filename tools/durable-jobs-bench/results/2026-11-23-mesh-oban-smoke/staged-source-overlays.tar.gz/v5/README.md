# Native Mesh and Oban Jobs adapters

## Matrix handoff

SSH succeeded on November 23 at 10:53 ET after the initial port 22
timeouts. The Linode reports Ubuntu 24.04.5, GNU x86-64, and four online
EPYC vCPUs (0–3). The controller owns the shared two-CPU mask and all
timed runs. Setup uses `/var/lib/durable-jobs-bench/native` on the Linode.
The first build attempt (`oban-v1`) stopped while unpacking PostgreSQL.
The retry (`oban-v2`) built from the checksum-verified `source-v2`
bundle during SETUP.

**Frozen Mesh is blocked on x86-64.** The unchanged `dbcb6dbc` runtime
gates `Jobs.start_effects`, the effect sessions, and the compiled worker
dispatch to Linux GNU ARM64. A native x86-64 build selects the rejection
stub. The frozen fixture linked against the pinned runtime locally and
stopped at this guard before enqueue. Keep the Mesh lane out of scored
pairs until an x86-64 runtime revision supports the frozen fixture.

## Setup and entry point

From the checkout, `linode check` probes the authorized host using the
dedicated identity and persistent TOFU host file. `linode bundle SOURCE_ID`
packs only the allowlisted benchmark and pinned compiler inputs.
`linode upload SOURCE_ID` verifies that bundle on the host before
unpacking it. Use a fresh ID for each attempt.

In SETUP, run `bootstrap BUILD_ID oban` under the staged adapter path.
It installs the benchmark's toolchain in the lane directory and builds
the ordinary Oban Basic fixture, Erlang/OTP 29.1.1, Elixir 1.20.4, and
PostgreSQL 17.11 with OpenSSL and pg_stat_statements. The shared PostgreSQL
tools are at `/var/lib/durable-jobs-bench/native/toolchain/pgsql-17.11/bin`.
The manifest captures the launcher, pinned dependencies and compiled
BEAM modules. `bootstrap BUILD_ID mesh` compiles only the pinned runtime
and frozen Mesh fixture for a build diagnostic.

Run one arm as root via the common executable. The wrapper hands the
empty evidence directory to the unprivileged database and runner user.
The controller pins the entire invocation to the same two CPUs.

```sh
base=/var/lib/durable-jobs-bench/native
adapter="$base/source-v4/tools/durable-jobs-bench/native"
NATIVE_JOBS_ARTIFACTS="$base/builds/oban-v2" \
    "$adapter/run" oban PROFILE ABSOLUTE_EMPTY_EVIDENCE_DIRECTORY
```

The fixed argv prefix for the matrix inventory is
`["/usr/bin/env", "NATIVE_JOBS_ARTIFACTS=/var/lib/durable-jobs-bench/native/builds/oban-v2", "/var/lib/durable-jobs-bench/native/source-v4/tools/durable-jobs-bench/native/run", "oban"]`.
Set `postgres_storage` to `/var/lib/durable-jobs-bench/native/scratch`
and evidence globs to `["*.json", "*.log"]`. The version is `2.24.2` and
the artifact digest is the SHA-256 of `builds/oban-v2/oban.json`. The
wrapper accepts the `mesh` lane through the same interface using a Mesh
build directory, subject to the platform blocker above.

## Profiles and reconciliation

| Profile | Runners | Slots | PostgreSQL cap | Jobs | Payload bytes | Hold ms | Enqueue transactions |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| dense (diagnostic) | 8 | 64 | 96 | 1,024 | 1,024 | 0 | 1 |
| noop | 8 | 64 | 96 | 1,024 | 1,024 | 0 | 1 |
| slow | 1 | 64 | 68 | 512 | 16,384 | 100 | 1 |
| sparse | 1 | 1 | 5 | 24 | 1,024 | 1 | 24 |
| short | 1 | 16 | 20 | 128 | 1,024 | 1 | 1 |
| large | 8 | 64 | 96 | 64 | 524,288 | 1 | 1 |

A successful arm emits the matrix `ledger.json` and a `row.json` summary
with reconciled jobs, committed work records, enqueue transactions,
and the frozen input digest. `raw.json` retains samples and the frozen
proof's counters. `application-records.json` retains all attempt and effect
identities and transaction IDs. The producer and observer share one
verified-TLS PostgreSQL connection. Application and runner sessions
also use loopback TLS with certificate verification and durable settings.
The observer validates the product XID in the submit-to-acknowledgment
window and checks two separate, ordered application commits per completed
attempt. Cluster data and credentials stay in owned scratch and are
removed after shutdown. Keep dense and all functional smoke outputs in
the diagnostic series.

Local macOS functional smoke passed Oban for each profile in the table
against PostgreSQL 17.11. The matrix verifier rejected four negative
controls involving missing work, shared work XIDs, an out-of-window
commit and a payload change. Native status is tracked here separately.

The parent task is preparing the GNU x86-64 runtime port. Stage its
committed revision with `linode bundle SOURCE_ID MESH_REVISION` once
available. This uses the selected compiler and runtime tree with the
same pinned fixture, verifier, and database scripts. Use a fresh
`bootstrap BUILD_ID mesh` and keep the port's commit and manifest digest
in the Matrix inventory. Native functional evidence is required before
the controller uses that build for timing.

PostgreSQL 17.11 has built and passed the executable version check.
The parent port is available at `3f69b150`. SETUP plan for Mesh is to
stage `source-v3` from that exact commit, prefetch the pinned Rust/LLVM
archives, then build `mesh-v1` after the Oban bootstrap releases the
lane lock. Both lanes use the same PostgreSQL installation.

The pinned Rust and LLVM release archives are on the Linode and their
checksums passed. Their installation and Cargo dependency fetch are
SETUP preparation. The Mesh release compile will wait for the Oban
bootstrap to finish.

Native Oban short passed on CPUs 0 and 1 with all 128 jobs and 256
committed work records. `oban-v2/oban.json` hashes to
`b0cd27902077fe83e0b93606fe24ae541c39351c9df3c92f3f1be363ae67d37f`.
Use `source-v4` in the launcher path. It starts in a directory the
unprivileged broker can traverse. The first short attempt, which hit
the Erlang boot error from the SSH working directory, is retained.
The remaining Oban profiles run serially in SETUP before `mesh-v1`
builds from `source-v4` at parent commit `3f69b150`.

The parent AMD64 runtime proof currently holds the shared native setup
lock under `amd64-port-3f69b150`. The first Oban dense invocation
returned before startup while that lock was held and is archived
separately. The rest of the Oban smokes and the Mesh release build will
run serially after the parent proof's setup window.

Matched submit timing is on HOLD. The original River READY is SETUP-only
because that binary decodes its batches before the submit clock.
The River replacement has a separate bounded SETUP slot after the original
adapter commit. Coordinate that slot with the native builder lock at
`/var/lib/durable-jobs-bench/native/native.lock` and the controller's arm
lock at `/var/tmp/mesh-durable-jobs-matrix/active-arm.lock`. Neither adapter's
smoke lifts the River timing hold.
