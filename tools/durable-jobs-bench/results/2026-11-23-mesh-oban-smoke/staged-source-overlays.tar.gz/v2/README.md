# Native durable Jobs benchmark

Handoff to the matrix owner. The single-arm command on the benchmark host will be
`tools/durable-jobs-bench/native/run mesh PROFILE NEW_ABSOLUTE_OUTPUT_DIR`
or the same command with `oban`. Run arms serially. The output is a fresh
attempt directory containing raw evidence and `row.json` for a successful arm.
The six profile names are `dense`, `noop`, `slow`, `sparse`, `short`, and
`large`. Dense is a diagnostic of the frozen no-op shape and must be excluded
from scored pairs. The five real profiles use the frozen replay inputs.

Initial host status at 10:41 ET on November 23. SSH to `172.234.135.126:22`
timed out before authentication. No files were transferred. Offline preparation
is underway. Wait for readiness here before scheduling timed runs.

## Matrix status

**Blocked for native timing.** SSH has repeatedly timed out before authentication.
There is also a Mesh architecture gate. The frozen fixture calls
`Jobs.start_effects`. At `dbcb6dbc` the compiled effects runner and worker
dispatch are gated to GNU Linux ARM64. An unmodified x86-64 build compiles
the stub that rejects this path. The local macOS Mesh arm stopped at that
guard before enqueue. The controller must treat the frozen x86-64 Mesh
lane as unsupported until a GNU x86-64 port is authorized and validated.

### Host update

At 10:53 ET, SSH succeeded. The Linode reports Ubuntu 24.04.5, x86-64,
four online EPYC vCPUs (0–3), and zero reported starting load. SETUP
plan: stage the allowlisted source at
`/var/lib/durable-jobs-bench/native/source-v1`, use build ID `oban-v1`,
and build PostgreSQL 17.11 with OpenSSL and pg_stat_statements, OTP
29.1.1 and Oban Basic 2.24.2. The shared PostgreSQL installation will be
`/var/lib/durable-jobs-bench/native/toolchain/pgsql-17.11/bin`.
Keep this build and the native smoke in SETUP. The frozen Mesh lane
remains blocked by its architecture gate.
