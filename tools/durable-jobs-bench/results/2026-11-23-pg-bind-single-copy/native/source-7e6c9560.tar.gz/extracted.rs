pub(crate) const MAX_DB_VALUE_BYTES: usize = 16 * 1024 * 1024;
const MAX_PG_MESSAGE_BYTES: usize = 64 * 1024 * 1024;
const MAX_PG_VALUES: usize = i16::MAX as usize;
fn write_parse(buf: &mut Vec<u8>, query: &str) {
    let mut body = Vec::new();
    body.push(0); // unnamed statement
    body.extend_from_slice(query.as_bytes());
    body.push(0); // null-terminate query
    body.extend_from_slice(&0_i16.to_be_bytes()); // 0 parameter type OIDs

    buf.push(b'P');
    let len = (body.len() + 4) as i32;
    buf.extend_from_slice(&len.to_be_bytes());
    buf.extend_from_slice(&body);
}

#[derive(Clone, Copy)]
pub(crate) enum BindValue<'a> {
    Text(&'a [u8]),
    Binary(&'a [u8]),
    Null,
}


fn write_describe_portal(buf: &mut Vec<u8>) {
    buf.push(b'D');
    let len: i32 = 4 + 1 + 1; // length_field + 'P' + null byte
    buf.extend_from_slice(&len.to_be_bytes());
    buf.push(b'P'); // Portal variant
    buf.push(0); // unnamed portal
}

/// Write Describe (Statement) for the unnamed prepared statement.
fn write_describe_statement(buf: &mut Vec<u8>) {
    buf.push(b'D');
    buf.extend_from_slice(&6_i32.to_be_bytes());
    buf.push(b'S');
    buf.push(0);
}

/// Write Execute message: Byte1('E') Int32(len) String("") Int32(0)
fn write_execute(buf: &mut Vec<u8>) {
    buf.push(b'E');
    let body_len = 1 + 4; // empty string (1 null byte) + max_rows (4 bytes)
    let len: i32 = body_len + 4;
    buf.extend_from_slice(&len.to_be_bytes());
    buf.push(0); // unnamed portal
    buf.extend_from_slice(&0_i32.to_be_bytes()); // 0 = no limit
}

/// Write Sync message: Byte1('S') Int32(4)
fn write_sync(buf: &mut Vec<u8>) {
    buf.push(b'S');
    buf.extend_from_slice(&4_i32.to_be_bytes());
}


impl PgConn {
    fn write_wire_all(&mut self, bytes: &[u8]) -> std::io::Result<()> {
        if self.broken {
            return Err(std::io::Error::new(
                std::io::ErrorKind::NotConnected,
                "PostgreSQL connection is unusable",
            ));
        }
        // Flushed: TLS may hold what it was given, and report failing to
        // send it only on the next read.
        let result = self
            .stream
            .write_all(bytes)
            .and_then(|()| self.stream.flush());
        if result.is_err() {
            self.broken = true;
        }
        result
    }

}
const EXECUTE_SYNC_BYTES: usize = 10 + 5;
const DESCRIBE_EXECUTE_SYNC_BYTES: usize = 7 + EXECUTE_SYNC_BYTES;

fn stock_bind(
    buf: &mut Vec<u8>,
    params: &[BindValue<'_>],
    result_formats: &[i16],
) -> Result<(), String> {
    if params.len() > MAX_PG_VALUES {
        return Err(format!(
            "too many PostgreSQL parameters: {} (maximum {MAX_PG_VALUES})",
            params.len()
        ));
    }
    // Sized in full before any value is copied: values each within their
    // limit can still make a message past the protocol's. At most
    // MAX_PG_VALUES values of MAX_DB_VALUE_BYTES each, the sum cannot
    // overflow a 64-bit usize.
    let mut body_len = 8 + 2 * params.len() + 2 * result_formats.len();
    for (index, param) in params.iter().enumerate() {
        let value_len = match param {
            BindValue::Text(bytes) | BindValue::Binary(bytes) => bytes.len(),
            BindValue::Null => 0,
        };
        if value_len > MAX_DB_VALUE_BYTES {
            return Err(format!(
                "PostgreSQL parameter at index {index} exceeds {MAX_DB_VALUE_BYTES} byte limit"
            ));
        }
        body_len += 4 + value_len;
    }
    let message_len = body_len + 4;
    if message_len > MAX_PG_MESSAGE_BYTES {
        return Err(format!(
            "PostgreSQL Bind message exceeds {MAX_PG_MESSAGE_BYTES} byte limit"
        ));
    }

    let mut body = Vec::with_capacity(body_len);
    body.push(0); // unnamed portal
    body.push(0); // unnamed statement
    body.extend_from_slice(&(params.len() as i16).to_be_bytes());
    for param in params {
        body.extend_from_slice(
            &match param {
                BindValue::Binary(_) => 1_i16,
                BindValue::Text(_) | BindValue::Null => 0_i16,
            }
            .to_be_bytes(),
        );
    }

    body.extend_from_slice(&(params.len() as i16).to_be_bytes());
    for param in params {
        match param {
            BindValue::Text(bytes) | BindValue::Binary(bytes) => {
                body.extend_from_slice(&(bytes.len() as i32).to_be_bytes());
                body.extend_from_slice(bytes);
            }
            BindValue::Null => body.extend_from_slice(&(-1_i32).to_be_bytes()),
        }
    }

    body.extend_from_slice(&(result_formats.len() as i16).to_be_bytes());
    for format in result_formats {
        body.extend_from_slice(&format.to_be_bytes());
    }
    debug_assert_eq!(body.len(), body_len);

    buf.push(b'B');
    buf.extend_from_slice(&(message_len as i32).to_be_bytes());
    buf.extend_from_slice(&body);
    Ok(())
}

fn optimized_bind(
    buf: &mut Vec<u8>,
    params: &[BindValue<'_>],
    result_formats: &[i16],
    suffix_bytes: usize,
) -> Result<(), String> {
    if params.len() > MAX_PG_VALUES {
        return Err(format!(
            "too many PostgreSQL parameters: {} (maximum {MAX_PG_VALUES})",
            params.len()
        ));
    }
    // Sized in full before any value is copied: values each within their
    // limit can still make a message past the protocol's. Use a wider
    // total on 32-bit targets and check every value before the frame limit.
    let mut body_len = 8 + 2 * params.len() as u64 + 2 * result_formats.len() as u64;
    for (index, param) in params.iter().enumerate() {
        let value_len = match param {
            BindValue::Text(bytes) | BindValue::Binary(bytes) => bytes.len(),
            BindValue::Null => 0,
        };
        if value_len > MAX_DB_VALUE_BYTES {
            return Err(format!(
                "PostgreSQL parameter at index {index} exceeds {MAX_DB_VALUE_BYTES} byte limit"
            ));
        }
        body_len += 4 + value_len as u64;
    }
    let message_len = body_len + 4;
    if message_len > MAX_PG_MESSAGE_BYTES as u64 {
        return Err(format!(
            "PostgreSQL Bind message exceeds {MAX_PG_MESSAGE_BYTES} byte limit"
        ));
    }

    let frame_bytes = 1 + message_len as usize;
    let start = buf.len();
    buf.reserve(frame_bytes + suffix_bytes);
    buf.push(b'B');
    buf.extend_from_slice(&(message_len as i32).to_be_bytes());
    buf.push(0); // unnamed portal
    buf.push(0); // unnamed statement
    buf.extend_from_slice(&(params.len() as i16).to_be_bytes());
    for param in params {
        buf.extend_from_slice(
            &match param {
                BindValue::Binary(_) => 1_i16,
                BindValue::Text(_) | BindValue::Null => 0_i16,
            }
            .to_be_bytes(),
        );
    }

    buf.extend_from_slice(&(params.len() as i16).to_be_bytes());
    for param in params {
        match param {
            BindValue::Text(bytes) | BindValue::Binary(bytes) => {
                buf.extend_from_slice(&(bytes.len() as i32).to_be_bytes());
                buf.extend_from_slice(bytes);
            }
            BindValue::Null => buf.extend_from_slice(&(-1_i32).to_be_bytes()),
        }
    }

    buf.extend_from_slice(&(result_formats.len() as i16).to_be_bytes());
    for format in result_formats {
        buf.extend_from_slice(&format.to_be_bytes());
    }
    debug_assert_eq!(buf.len() - start, frame_bytes);
    Ok(())
}

