#include "postgres.h"

#include "access/heapam.h"
#include "access/htup_details.h"
#include "access/sysattr.h"
#include "access/table.h"
#include "access/tableam.h"
#include "access/xact.h"
#include "catalog/namespace.h"
#include "catalog/pg_am_d.h"
#include "catalog/pg_collation_d.h"
#include "catalog/pg_type_d.h"
#include "executor/tuptable.h"
#include "fmgr.h"
#include "miscadmin.h"
#include "nodes/makefuncs.h"
#include "storage/bufmgr.h"
#include "utils/acl.h"
#include "utils/builtins.h"
#include "utils/lsyscache.h"
#include "utils/rel.h"
#include "utils/rls.h"
#include "utils/snapmgr.h"
#include "utils/uuid.h"

#if PG_VERSION_NUM / 10000 != 17
#error "The Jobs exact-tuple diagnostic is built and qualified for PostgreSQL 17"
#endif

PG_MODULE_MAGIC;
PG_FUNCTION_INFO_V1(mesh_jobs_lock_exact);

Datum
mesh_jobs_lock_exact(PG_FUNCTION_ARGS)
{
    text *namespace = PG_GETARG_TEXT_PP(0);
    pg_uuid_t *job_id = PG_GETARG_UUID_P(1);
    TransactionId version = PG_GETARG_TRANSACTIONID(2);
    ItemPointer location = (ItemPointer) DatumGetPointer(PG_GETARG_DATUM(3));
    ItemPointerData target = *location;
    Oid role = GetUserId();
    Oid oid;
    Relation relation;
    TupleTableSlot *slot;
    AttrNumber ns_column;
    AttrNumber id_column;
    AttrNumber state_column;
    Snapshot snapshot = GetActiveSnapshot();
    TM_FailureData failure;
    const char *status = "stale";
    bool is_null;
    Datum row_ns;
    Datum row_id;
    Datum row_xmin;

    oid = RangeVarGetRelid(makeRangeVar("mesh_jobs", "jobs", -1), RowShareLock, false);
    relation = table_open(oid, NoLock);
    ns_column = get_attnum(oid, "namespace");
    id_column = get_attnum(oid, "id");
    state_column = get_attnum(oid, "state");
    if (relation->rd_rel->relkind != RELKIND_RELATION ||
        relation->rd_rel->relam != HEAP_TABLE_AM_OID ||
        ns_column <= 0 || id_column <= 0 || state_column <= 0 ||
        get_atttype(oid, ns_column) != TEXTOID || get_atttype(oid, id_column) != UUIDOID ||
        XactIsoLevel != XACT_READ_COMMITTED)
        ereport(ERROR, (errcode(ERRCODE_FEATURE_NOT_SUPPORTED),
                        errmsg("mesh jobs exact lock requires the PostgreSQL 17 heap Jobs schema and READ COMMITTED")));
    if (pg_class_aclcheck(oid, role, ACL_SELECT) != ACLCHECK_OK ||
        (pg_class_aclcheck(oid, role, ACL_UPDATE) != ACLCHECK_OK &&
         pg_attribute_aclcheck(oid, state_column, role, ACL_UPDATE) != ACLCHECK_OK) ||
        check_enable_rls(oid, InvalidOid, true) == RLS_ENABLED)
        ereport(ERROR, (errcode(ERRCODE_INSUFFICIENT_PRIVILEGE),
                        errmsg("mesh jobs exact lock requires updating Jobs access without row security")));

    if (!ItemPointerIsValid(location) ||
        ItemPointerGetOffsetNumber(location) > MaxHeapTuplesPerPage ||
        ItemPointerGetBlockNumber(location) >= RelationGetNumberOfBlocks(relation))
    {
        table_close(relation, NoLock);
        PG_RETURN_TEXT_P(cstring_to_text("stale"));
    }

    slot = table_slot_create(relation, NULL);
    /*
     * A fixed physical tuple must be visible and match the supplied logical
     * identity. The preparation cursor pins its prior MVCC snapshot too.
     */
    if (table_tuple_fetch_row_version(relation, &target, snapshot, slot))
    {
        row_xmin = slot_getsysattr(slot, MinTransactionIdAttributeNumber, &is_null);
        if (!is_null && DatumGetTransactionId(row_xmin) == version)
        {
            row_ns = slot_getattr(slot, ns_column, &is_null);
            if (!is_null && DatumGetBool(DirectFunctionCall2Coll(texteq, DEFAULT_COLLATION_OID,
                                           row_ns, PointerGetDatum(namespace))))
            {
                row_id = slot_getattr(slot, id_column, &is_null);
                if (!is_null && memcmp(DatumGetUUIDP(row_id)->data, job_id->data, UUID_LEN) == 0)
                {
                    ExecClearTuple(slot);
                    /* Neither flag is set. Never lock a descendant of target. */
                    TM_Result locked = table_tuple_lock(relation, &target, snapshot, slot,
                        GetCurrentCommandId(false), LockTupleNoKeyExclusive, LockWaitSkip,
                        0, &failure);
                    Assert(ItemPointerEquals(&target, location));
                    if (locked == TM_Ok)
                        status = "locked";
                    else if (locked == TM_WouldBlock)
                        status = "busy";
                }
            }
        }
    }

    ExecDropSingleTupleTableSlot(slot);
    table_close(relation, NoLock);
    PG_RETURN_TEXT_P(cstring_to_text(status));
}
