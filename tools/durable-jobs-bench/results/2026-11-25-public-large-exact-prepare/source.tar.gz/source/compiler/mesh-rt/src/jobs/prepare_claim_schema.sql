-- Optional, invoker-rights protocol. Install after the ordinary Jobs schema.
-- Only activation takes the queue admission lock and makes a durable attempt.
CREATE OR REPLACE FUNCTION mesh_jobs.prepare_batch_v1(
    ns text, queue_name text, workers jsonb, slots integer
) RETURNS TABLE(status text, id text, token text, context text, timeout_ms text, context_bytes text,
                row_version text, row_location text, transaction_id text)
LANGUAGE plpgsql VOLATILE SET search_path = pg_catalog, pg_temp AS $$
DECLARE
    q mesh_jobs.queues%ROWTYPE;
    job mesh_jobs.jobs%ROWTYPE;
    candidate record;
    lock_result text;
    due_at bigint;
    remaining integer;
    oversized_count integer := 0;
    value_bytes integer;
    row_bytes integer;
    -- All additional manifest fields fit in the per-batch framing reserve.
    reply_bytes integer := 32 * 1024 * 1024 - 1024;
    wire_encoding name := current_setting('client_encoding');
    same_encoding boolean := wire_encoding = current_setting('server_encoding');
    candidates NO SCROLL CURSOR FOR
        SELECT j.id AS job_id, j.xmin AS tuple_xmin, j.ctid AS tuple_ctid FROM mesh_jobs.jobs j
        WHERE j.namespace = ns AND j.queue = queue_name
            AND j.state IN ('available', 'scheduled', 'retryable') AND j.scheduled_at_ms <= due_at
            AND j.attempt < j.max_attempts
            AND EXISTS (
                SELECT FROM jsonb_to_recordset(workers) AS w(worker text, version bigint)
                WHERE w.worker = j.worker AND w.version = j.version
            )
            AND NOT EXISTS (
                SELECT FROM mesh_jobs.batch_context_blocks b
                WHERE b.namespace = j.namespace AND b.id = j.id
                    AND b.row_version = j.xmin AND b.row_location = j.ctid
                    AND b.encoding = wire_encoding
            )
        ORDER BY j.priority, j.scheduled_at_ms, j.position;
BEGIN
    IF current_setting('transaction_isolation') <> 'read committed' THEN
        RAISE EXCEPTION 'mesh jobs batch preparation requires READ COMMITTED';
    END IF;

    -- This snapshot bounds speculation. Activation alone spends capacity.
    SELECT * INTO q FROM mesh_jobs.queues WHERE namespace = ns AND name = queue_name;
    IF NOT FOUND OR q.state <> 'active' OR q.concurrency = 0 THEN RETURN; END IF;
    IF EXISTS (SELECT FROM mesh_jobs.queues WHERE namespace = ns AND name = '' AND state = 'paused')
    THEN RETURN; END IF;
    remaining := least(coalesce(slots, 0), 16, q.concurrency - (SELECT count(*) FROM mesh_jobs.jobs j
        WHERE j.namespace = ns AND j.queue = queue_name AND j.state = 'executing'));
    IF remaining <= 0 THEN RETURN; END IF;

    due_at := mesh_jobs.now_ms();
    FOR candidate IN candidates LOOP
        EXIT WHEN remaining <= 0;
        lock_result := mesh_jobs.lock_exact_v1(ns, candidate.job_id,
            candidate.tuple_xmin, candidate.tuple_ctid);
        IF lock_result = 'busy' THEN CONTINUE; END IF;
        IF lock_result = 'stale' THEN
            -- A version edit may leave the earlier job eligible. Return only
            -- the proven prefix and let the next scan use its new ordering.
            EXIT WHEN EXISTS (
                SELECT FROM mesh_jobs.jobs j
                WHERE j.namespace = ns AND j.id = candidate.job_id AND j.queue = queue_name
                    AND j.state IN ('available', 'scheduled', 'retryable') AND j.scheduled_at_ms <= due_at
                    AND j.attempt < j.max_attempts
                    AND EXISTS (
                        SELECT FROM jsonb_to_recordset(workers) AS w(worker text, version bigint)
                        WHERE w.worker = j.worker AND w.version = j.version
                    )
            );
            CONTINUE;
        END IF;

        -- A legacy turn could have posted an oversized marker while this
        -- snapshot was open. Its marker is authoritative under our row lock.
        IF EXISTS (SELECT FROM mesh_jobs.batch_context_blocks b
            WHERE b.namespace = ns AND b.id = candidate.job_id
                AND b.row_version = candidate.tuple_xmin AND b.row_location = candidate.tuple_ctid
                AND b.encoding = wire_encoding)
        THEN CONTINUE; END IF;

        SELECT j.* INTO STRICT job FROM mesh_jobs.jobs j
        WHERE j.namespace = ns AND j.id = candidate.job_id
            AND j.xmin = candidate.tuple_xmin AND j.ctid = candidate.tuple_ctid;
        id := job.id::text;
        row_version := candidate.tuple_xmin::text;
        row_location := candidate.tuple_ctid::text;
        transaction_id := pg_current_xact_id()::text;
        context := jsonb_build_object(
            'id', job.id, 'effect_key', mesh_jobs.effect_key(job), 'worker', job.worker,
            'version', job.version, 'args', job.args, 'attempt', job.attempt + 1,
            'max_attempts', job.max_attempts, 'queue', job.queue, 'metadata', job.metadata,
            'tags', job.tags, 'scheduled_at_ms', job.scheduled_at_ms
        )::text;
        value_bytes := CASE WHEN same_encoding THEN octet_length(context)
            ELSE octet_length(convert_to(context, wire_encoding)) END;
        context_bytes := value_bytes::text;

        -- DataRow adds a 5-byte frame, a 2-byte count, and six 4-byte field lengths.
        -- Preserve the stock logical prefix budget. Extra wire fields are
        -- included in the 1 KiB per-batch reserve (47 bytes per row and one 20-byte transaction XID).
        row_bytes := 31 + octet_length(id) + octet_length(context_bytes);
        IF value_bytes > 16 * 1024 * 1024 THEN
            status := 'oversized';
            row_bytes := row_bytes + octet_length(status);
            EXIT WHEN row_bytes > reply_bytes;
            token := NULL;
            context := NULL;
            timeout_ms := NULL;
            RETURN NEXT;
            reply_bytes := reply_bytes - row_bytes;
            oversized_count := oversized_count + 1;
            EXIT WHEN oversized_count >= 4;
            CONTINUE;
        END IF;

        status := 'prepared';
        token := gen_random_uuid()::text;
        timeout_ms := job.timeout_ms::text;
        row_bytes := row_bytes + octet_length('claimed') + octet_length(token) +
            value_bytes + octet_length(timeout_ms);
        -- Keep the ordered prefix of claimable jobs when the next one cannot fit.
        EXIT WHEN row_bytes > reply_bytes;

        RETURN NEXT;
        reply_bytes := reply_bytes - row_bytes;
        remaining := remaining - 1;
    END LOOP;
END
$$;

-- The scoped worker already owns attempt/lease DML. The trusted runner
-- carries the validated reservation manifest on the same transaction.
CREATE OR REPLACE FUNCTION mesh_jobs.activate_batch_v1(
    ns text, queue_name text, workers jsonb, lease_ms bigint, reservation_xid xid8,
    manifest jsonb, observe boolean
) RETURNS TABLE(status text, id text, observed_at_ms text)
LANGUAGE plpgsql VOLATILE SET search_path = pg_catalog, pg_temp AS $$
DECLARE
    q mesh_jobs.queues%ROWTYPE;
    entry record;
    job record;
    due_at bigint;
    started_at bigint;
    remaining integer;
    oversized_count integer := 0;
    wire_encoding name := current_setting('client_encoding');
BEGIN
    IF current_setting('transaction_isolation') <> 'read committed'
        OR reservation_xid IS NULL OR reservation_xid IS DISTINCT FROM pg_current_xact_id_if_assigned()
        OR lease_ms IS NULL OR lease_ms NOT BETWEEN 1 AND 31536000000
        OR manifest IS NULL OR jsonb_array_length(manifest) NOT BETWEEN 1 AND 20
    THEN RAISE EXCEPTION 'invalid mesh jobs batch preparation manifest'; END IF;

    IF NOT pg_try_advisory_xact_lock_shared(hashtextextended(ns, 1782495106)) THEN RETURN; END IF;
    IF EXISTS (SELECT FROM mesh_jobs.queues WHERE namespace = ns AND name = '' AND state = 'paused')
    THEN RETURN; END IF;

    -- Legacy claimants skip reserved rows while holding this lock. Waiting
    -- here for a short admission turn therefore cannot wait on their job locks.
    BEGIN
        SELECT * INTO q FROM mesh_jobs.queues
        WHERE namespace = ns AND name = queue_name FOR NO KEY UPDATE;
        IF NOT FOUND OR q.state <> 'active' OR q.concurrency = 0 THEN RETURN; END IF;
    EXCEPTION WHEN lock_not_available THEN
        RETURN;
    END;

    -- A fresh READ COMMITTED statement after queue lock acquisition sees
    -- attempts committed by the previous admission turn.
    remaining := least(16, q.concurrency - (SELECT count(*) FROM mesh_jobs.jobs j
        WHERE j.namespace = ns AND j.queue = queue_name AND j.state = 'executing'));
    due_at := mesh_jobs.now_ms();
    FOR entry IN
        SELECT * FROM ROWS FROM (jsonb_to_recordset(manifest)
            AS (id uuid, token uuid, row_version xid, row_location tid, context_bytes integer))
            WITH ORDINALITY ORDER BY ordinality
    LOOP
        EXIT WHEN remaining <= 0;
        SELECT j.xmin AS row_version, j.ctid AS row_location INTO job FROM mesh_jobs.jobs j
        WHERE j.namespace = ns AND j.queue = queue_name AND j.id = entry.id
            AND j.xmin = entry.row_version AND j.ctid = entry.row_location
            AND j.state IN ('available', 'scheduled', 'retryable') AND j.scheduled_at_ms <= due_at
            AND j.attempt < j.max_attempts
            AND EXISTS (
                SELECT FROM jsonb_to_recordset(workers) AS w(worker text, version bigint)
                WHERE w.worker = j.worker AND w.version = j.version
            )
        FOR NO KEY UPDATE OF j SKIP LOCKED;
        EXIT WHEN NOT FOUND;

        id := entry.id::text;
        IF entry.token IS NULL AND entry.context_bytes > 16 * 1024 * 1024 THEN
            INSERT INTO mesh_jobs.batch_context_blocks (namespace, id, row_version, row_location, encoding, context_bytes)
            VALUES (ns, entry.id, job.row_version, job.row_location, wire_encoding, entry.context_bytes)
            ON CONFLICT ON CONSTRAINT batch_context_blocks_pkey DO UPDATE
            SET row_version = excluded.row_version, row_location = excluded.row_location,
                encoding = excluded.encoding, context_bytes = excluded.context_bytes;
            oversized_count := oversized_count + 1;
            status := 'oversized';
            observed_at_ms := NULL;
        ELSIF entry.token IS NOT NULL AND entry.context_bytes BETWEEN 1 AND 16 * 1024 * 1024 THEN
            started_at := mesh_jobs.now_ms();
            UPDATE mesh_jobs.jobs j SET state = 'executing', attempt = j.attempt + 1,
                attempted_at_ms = started_at, lease_token = entry.token,
                lease_expires_at_ms = started_at + lease_ms
            WHERE j.namespace = ns AND j.id = entry.id;
            remaining := remaining - 1;
            status := 'claimed';
            observed_at_ms := CASE WHEN observe THEN mesh_jobs.now_ms()::text END;
        ELSE
            RAISE EXCEPTION 'invalid mesh jobs batch preparation entry';
        END IF;
        RETURN NEXT;
        EXIT WHEN oversized_count >= 4;
    END LOOP;
END
$$;

REVOKE EXECUTE ON FUNCTION mesh_jobs.prepare_batch_v1(text,text,jsonb,integer),
    mesh_jobs.activate_batch_v1(text,text,jsonb,bigint,xid8,jsonb,boolean) FROM PUBLIC;
