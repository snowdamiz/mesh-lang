-- Execute with psql as a database administrator after Jobs.migrate.
-- Set module_path to the verified PostgreSQL 17 module and worker to the exact role.
\set ON_ERROR_STOP 1
BEGIN;
SELECT pg_catalog.pg_advisory_xact_lock(1782495102, 1);

CREATE OR REPLACE FUNCTION mesh_jobs.lock_exact_v1(text, uuid, xid, tid)
RETURNS text
AS :'module_path', 'mesh_jobs_lock_exact'
LANGUAGE c STRICT VOLATILE PARALLEL UNSAFE SET search_path = pg_catalog, pg_temp;

\ir prepare_claim_schema.sql

REVOKE EXECUTE ON FUNCTION mesh_jobs.lock_exact_v1(text,uuid,xid,tid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION mesh_jobs.lock_exact_v1(text,uuid,xid,tid),
    mesh_jobs.prepare_batch_v1(text,text,jsonb,integer),
    mesh_jobs.activate_batch_v1(text,text,jsonb,bigint,xid8,jsonb,boolean) TO :"worker";
-- A named default ACL can grant execution even after PUBLIC is revoked.
SELECT pg_catalog.set_config('mesh_jobs.prepare_worker_role', :'worker', true);
DO $$
BEGIN
    IF EXISTS (
        SELECT
        FROM pg_catalog.pg_proc p
        CROSS JOIN LATERAL pg_catalog.aclexplode(p.proacl) a
        WHERE p.oid = ANY (ARRAY[
            'mesh_jobs.lock_exact_v1(text,uuid,xid,tid)'::regprocedure,
            'mesh_jobs.prepare_batch_v1(text,text,jsonb,integer)'::regprocedure,
            'mesh_jobs.activate_batch_v1(text,text,jsonb,bigint,xid8,jsonb,boolean)'::regprocedure
        ])
        AND a.privilege_type = 'EXECUTE' AND a.grantee <> p.proowner
        AND a.grantee <> pg_catalog.to_regrole(pg_catalog.quote_ident(
            pg_catalog.current_setting('mesh_jobs.prepare_worker_role')))
    ) THEN
        RAISE EXCEPTION 'mesh jobs exact tuple protocol has an unexpected named EXECUTE grant';
    END IF;
END
$$;
COMMIT;
