use super::{
    decode_checked_batch, rollback_error, ClaimBatch, MAX_CLAIM_BATCH, MAX_OVERSIZED_PER_BATCH,
    MAX_TIMESTAMP_MS,
};
use crate::db::jobs_connection::PgJobDb;
use crate::db::pg::{JobsClaimCommand, JobsClaimRow};
use serde::Serialize;
use std::collections::HashMap;

pub(in crate::jobs) const PROTOCOL: &str = "locked_prepare_pg17_v1";

pub(in crate::jobs) fn enabled() -> bool {
    std::env::var("MESH_JOBS_BATCH_PROTOCOL").is_ok_and(|mode| mode == PROTOCOL)
}

#[derive(Serialize)]
struct Entry {
    id: String,
    token: Option<String>,
    row_version: String,
    row_location: String,
    context_bytes: usize,
}

const PREPARE: &str = "
    SELECT status, id, token, context, timeout_ms, context_bytes, ordinality::text AS ordinality,
           row_version, row_location, CASE WHEN ordinality = 1 THEN transaction_id END AS transaction_id
    FROM mesh_jobs.prepare_batch_v1($1, $2, $3::jsonb, $4::integer) WITH ORDINALITY";

const ACTIVATE: &str = "
    WITH admitted AS MATERIALIZED (
        SELECT status, id, observed_at_ms, ordinality
        FROM mesh_jobs.activate_batch_v1($1, $2, $3::jsonb, $4::bigint, $5::xid8,
                                         $6::jsonb, $7::boolean) WITH ORDINALITY
    )
    SELECT status, id, observed_at_ms
    FROM (
        SELECT 'count' AS status, count(*)::text AS id, NULL::text AS observed_at_ms, 0 AS ordinality
        FROM admitted
        UNION ALL
        SELECT status, id, observed_at_ms, ordinality FROM admitted
    ) AS confirmed
    ORDER BY ordinality";

const PREPARE_COLUMNS: [&str; 10] = [
    "status",
    "id",
    "token",
    "context",
    "timeout_ms",
    "context_bytes",
    "ordinality",
    "row_version",
    "row_location",
    "transaction_id",
];

const TIMEOUTS: &str = "
    SELECT pg_catalog.set_config(name, least(coalesce(nullif(setting::integer, 0),
        bound), bound)::text, true)
    FROM pg_catalog.pg_settings JOIN (VALUES ('transaction_timeout', 10000),
        ('lock_timeout', 250)) AS limits(name, bound) USING (name)";

pub(in crate::jobs) fn claim<L>(
    db: &mut PgJobDb<'_>,
    namespace: &str,
    queue: &str,
    workers: &str,
    lease_ms: u64,
    slots: usize,
    observe: bool,
    begin_lease: impl FnOnce() -> Result<L, String>,
) -> Result<(L, ClaimBatch), String> {
    // Namespace, queue, workers, lease and local slots come from a validated runner.
    if !db.is_idle() {
        return Err("Jobs prepared claim requires an idle PostgreSQL connection".into());
    }
    let slots = slots.min(MAX_CLAIM_BATCH);
    db.claim_command(JobsClaimCommand::Begin)?;
    let result = (|| {
        db.simple(TIMEOUTS)?;
        let rows = db
            .claim_rows_named(
                PREPARE,
                &[namespace, queue, workers, &slots.to_string()],
                PREPARE_COLUMNS,
                slots + MAX_OVERSIZED_PER_BATCH,
            )?
            .ok_or_else(invalid)?;
        let (transaction_id, manifest, rows) = prepare_manifest(rows)?;
        let mut batch = decode_checked_batch(rows, slots, false, queue, workers, true)?;
        let lease = begin_lease()?;
        if manifest.is_empty() {
            batch.contention_hint =
                super::prepared_claim_contention(db, namespace, queue, workers)?;
        } else {
            let manifest_json = serde_json::to_string(&manifest).map_err(|err| err.to_string())?;
            let confirmed = db
                .claim_rows_named(
                    ACTIVATE,
                    &[
                        namespace,
                        queue,
                        workers,
                        &lease_ms.to_string(),
                        &transaction_id,
                        &manifest_json,
                        if observe { "true" } else { "false" },
                    ],
                    ["status", "id", "observed_at_ms"],
                    manifest.len() + 1,
                )?
                .ok_or_else(invalid)?;
            retain_confirmed(&mut batch, &manifest, confirmed, observe)?;
            batch.contention_hint = batch.claims.is_empty() && batch.oversized.is_empty();
        }
        Ok((lease, batch))
    })();
    match result {
        Ok(batch) => {
            db.claim_command(JobsClaimCommand::Commit)?;
            Ok(batch)
        }
        Err(error) => Err(rollback_error(
            error,
            db.claim_command(JobsClaimCommand::Rollback),
        )),
    }
}

fn invalid() -> String {
    "mesh jobs invalid prepared batch result from PostgreSQL".into()
}

fn prepare_manifest(
    rows: Vec<[Option<String>; 10]>,
) -> Result<(String, Vec<Entry>, Vec<JobsClaimRow>), String> {
    let mut transaction_id = String::new();
    let mut manifest = Vec::with_capacity(rows.len());
    let mut claims = Vec::with_capacity(rows.len());
    for [status, id, token, context, timeout, bytes, ordinal, version, location, xid] in rows {
        let index = ordinal
            .as_deref()
            .and_then(|value| value.parse::<usize>().ok())
            .ok_or_else(invalid)?;
        if index == 1 {
            transaction_id = xid
                .filter(|value| value.parse::<u64>().is_ok_and(|id| id > 0))
                .ok_or_else(invalid)?;
        } else if xid.is_some() {
            return Err(invalid());
        }
        let status = match status.as_deref() {
            Some("prepared") if token.is_some() => Some("claimed".into()),
            Some("oversized") if token.is_none() => status,
            _ => return Err(invalid()),
        };
        manifest.push((
            index,
            Entry {
                id: id.clone().ok_or_else(invalid)?,
                token: token.clone(),
                context_bytes: bytes
                    .as_deref()
                    .and_then(|value| value.parse().ok())
                    .ok_or_else(invalid)?,
                row_version: version.ok_or_else(invalid)?,
                row_location: location.ok_or_else(invalid)?,
            },
        ));
        claims.push([status, id, token, context, timeout, bytes, None, ordinal]);
    }
    manifest.sort_unstable_by_key(|(ordinal, _)| *ordinal);
    Ok((
        transaction_id,
        manifest.into_iter().map(|(_, entry)| entry).collect(),
        claims,
    ))
}

fn retain_confirmed(
    batch: &mut ClaimBatch,
    manifest: &[Entry],
    rows: Vec<[Option<String>; 3]>,
    observe: bool,
) -> Result<(), String> {
    let mut rows = rows.into_iter();
    let [status, total, unused] = rows.next().ok_or_else(invalid)?;
    if status.as_deref() != Some("count")
        || unused.is_some()
        || total.and_then(|value| value.parse::<usize>().ok()) != Some(rows.len())
        || rows.len() > manifest.len()
    {
        return Err(invalid());
    }
    let mut claimed = HashMap::new();
    let mut oversized = 0;
    for (entry, [status, id, observed]) in manifest.iter().zip(rows) {
        let id = id.filter(|id| *id == entry.id).ok_or_else(invalid)?;
        match (entry.token.is_some(), status.as_deref()) {
            (true, Some("claimed")) if observe || observed.is_none() => {
                let timestamp = if observe {
                    Some(
                        observed
                            .and_then(|value| value.parse::<u64>().ok())
                            .filter(|&ms| ms > 0 && ms <= MAX_TIMESTAMP_MS)
                            .ok_or_else(invalid)?,
                    )
                } else {
                    None
                };
                if claimed.insert(id, timestamp).is_some() {
                    return Err(invalid());
                }
            }
            (false, Some("oversized")) if observed.is_none() => oversized += 1,
            _ => return Err(invalid()),
        }
    }
    batch.claims.retain_mut(|job| {
        let Some(observed_at_ms) = claimed.remove(&job.id) else {
            return false;
        };
        job.observed_at_ms = observed_at_ms;
        true
    });
    batch.oversized.truncate(oversized);
    if !claimed.is_empty() {
        return Err(invalid());
    }
    Ok(())
}
