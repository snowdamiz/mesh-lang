-- Stop all runners using locked_prepare_pg17_v1 before running this script.
-- Apply as the installing administrator before a PostgreSQL major upgrade.
\set ON_ERROR_STOP 1
BEGIN;
SELECT pg_catalog.pg_advisory_xact_lock(1782495102, 1);
DROP FUNCTION IF EXISTS mesh_jobs.activate_batch_v1(text,text,jsonb,bigint,xid8,jsonb,boolean);
DROP FUNCTION IF EXISTS mesh_jobs.prepare_batch_v1(text,text,jsonb,integer);
DROP FUNCTION IF EXISTS mesh_jobs.lock_exact_v1(text,uuid,xid,tid);
COMMIT;
