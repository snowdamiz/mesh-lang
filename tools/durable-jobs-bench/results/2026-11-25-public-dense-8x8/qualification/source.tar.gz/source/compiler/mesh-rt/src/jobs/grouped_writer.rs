use std::thread::{self, JoinHandle};

use super::super::store::{complete_batch, MAX_COMPLETE_COHORT};
use super::{
    finish, mpsc, Acknowledgement, Attempt, Duration, Execution, HashSet, Instant, JobSession,
    JobsAckError, LifecycleIo, Operation, Outcome, Phase, QueuePhase, Receiver, Runner, Settlement,
    State, SyncSender, TryRecvError,
};

const COLLECTION_WINDOW: Duration = Duration::from_millis(8);

struct Member {
    id: String,
    token: String,
    ready_at: Instant,
}

type Disposition = Option<Result<Settlement, JobsAckError>>;

struct Write {
    session: JobSession,
    members: Vec<Member>,
}

struct Receipt {
    session: JobSession,
    dispositions: Vec<Disposition>,
}

pub(super) struct GroupedWriter {
    requests: Option<SyncSender<Write>>,
    receipts: Receiver<Receipt>,
    thread: Option<JoinHandle<()>>,
    in_flight: Vec<String>,
    log_runner: Option<u64>,
    claims: usize,
    claim_slots: usize,
    claims_while_writing: usize,
    widths: [usize; MAX_COMPLETE_COHORT],
    max_collection_us: u128,
}

impl GroupedWriter {
    pub(super) fn start(runner: &Runner) -> std::io::Result<Self> {
        let (requests, writes) = mpsc::sync_channel::<Write>(1);
        let (send, receipts) = mpsc::sync_channel(1);
        let namespace = runner.config.namespace.clone();
        let dispatcher = thread::current();
        let thread = thread::Builder::new()
            .name(format!("mesh-jobs-grouped-{}", runner.id))
            .spawn(move || {
                while let Ok(mut write) = writes.recv() {
                    let dispositions = settle(&namespace, &mut write.session, &write.members);
                    if send
                        .send(Receipt {
                            session: write.session,
                            dispositions,
                        })
                        .is_err()
                    {
                        break;
                    }
                    dispatcher.unpark();
                }
            })?;
        Ok(Self {
            requests: Some(requests),
            receipts,
            thread: Some(thread),
            in_flight: Vec::new(),
            log_runner: runner.config.event_log.then_some(runner.id),
            claims: 0,
            claim_slots: 0,
            claims_while_writing: 0,
            widths: [0; MAX_COMPLETE_COHORT],
            max_collection_us: 0,
        })
    }

    pub(super) fn busy(&self) -> bool {
        !self.in_flight.is_empty()
    }

    pub(super) fn claim_dispatched(&mut self, slots: usize) {
        self.claims += usize::from(slots != 0);
        self.claim_slots += slots;
        self.claims_while_writing += usize::from(slots != 0 && self.busy());
    }

    pub(super) fn enabled(&self) -> bool {
        self.requests.is_some()
    }

    pub(super) fn flush(
        &mut self,
        runner: &Runner,
        io: &mut LifecycleIo,
        attempts: &[Attempt],
    ) -> Option<Instant> {
        let requests = self.requests.as_ref()?;
        if self.busy() {
            return None;
        }
        let now = Instant::now();
        let mut deadline = now + COLLECTION_WINDOW;
        let mut eligible = {
            let state = runner.state.lock();
            if !matches!(state.phase, Phase::Running)
                || state
                    .queues
                    .values()
                    .any(|queue| !matches!(queue.phase, QueuePhase::Running))
            {
                deadline = now;
            }
            attempts
                .iter()
                .filter_map(|attempt| {
                    let ready = ready_at(&state, attempt)?;
                    let lease = attempt.lease.as_ref()?;
                    deadline = deadline
                        .min(ready + COLLECTION_WINDOW)
                        .min(lease.expires_at);
                    if let Some(renewal) = lease.renew_at {
                        deadline = deadline.min(renewal);
                    }
                    Some((ready, attempt))
                })
                .collect::<Vec<_>>()
        };
        if eligible.is_empty() {
            return None;
        }
        if eligible.len() < MAX_COMPLETE_COHORT && now < deadline {
            return Some(deadline);
        }
        eligible.sort_unstable_by_key(|(ready, _)| *ready);
        let members: Vec<_> = eligible
            .iter()
            .take(MAX_COMPLETE_COHORT)
            .map(|(ready_at, attempt)| Member {
                id: attempt.id.clone(),
                token: attempt.token.clone(),
                ready_at: *ready_at,
            })
            .collect();
        let session = io
            .session
            .take()
            .expect("idle grouped writer owns lifecycle session");
        // The dispatcher keeps its own attempt records until an idle commit or
        // token-fenced scalar response. Only the socket moves to the writer.
        self.in_flight = members.iter().map(|member| member.token.clone()).collect();
        let oldest = members[0].ready_at;
        if let Err(error) = requests.try_send(Write { session, members }) {
            let write = match error {
                mpsc::TrySendError::Disconnected(write) | mpsc::TrySendError::Full(write) => write,
            };
            io.session = Some(write.session);
            self.in_flight.clear();
            self.requests.take();
            runner.storage_failure(
                Operation::Acknowledge,
                "Jobs grouped writer unavailable".into(),
                None,
            );
            return Some(now);
        }
        self.widths[self.in_flight.len() - 1] += 1;
        self.max_collection_us = self
            .max_collection_us
            .max(now.saturating_duration_since(oldest).as_micros());
        None
    }

    pub(super) fn receive(
        &mut self,
        runner: &Runner,
        io: &mut LifecycleIo,
        attempts: &mut Vec<Attempt>,
        freed: &mut HashSet<String>,
    ) {
        if !self.busy() {
            return;
        }
        let dispositions = match self.receipts.try_recv() {
            Ok(receipt) => {
                io.session = Some(receipt.session);
                receipt.dispositions
            }
            Err(TryRecvError::Empty) => return,
            Err(TryRecvError::Disconnected) => {
                self.requests.take();
                (0..self.in_flight.len())
                    .map(|_| {
                        Some(Err(JobsAckError::Unconfirmed(
                            "Jobs grouped writer disconnected during settlement".into(),
                        )))
                    })
                    .collect()
            }
        };
        let mut confirmed = HashSet::new();
        for (token, disposition) in self.in_flight.drain(..).zip(dispositions) {
            let attempt = attempts
                .iter_mut()
                .find(|attempt| attempt.token == token)
                .expect("in-flight settlement still owns its slot");
            attempt.submissions = 1;
            let Some(disposition) = disposition else {
                continue;
            };
            let (duration, identity) = {
                let state = runner.state.lock();
                let job = &state.jobs[&token];
                let Execution::Acknowledging {
                    handler_duration_ms,
                    ..
                } = &job.execution
                else {
                    unreachable!("grouped writer received a reaped success");
                };
                (*handler_duration_ms, job.identity.clone())
            };
            let acknowledgement = Acknowledgement {
                submission: 1,
                handler_duration_ms: duration,
                failure_kind: None,
            };
            if !attempt.ack_result(runner, acknowledgement, identity.as_ref(), disposition) {
                confirmed.insert(token);
            }
        }
        if !confirmed.is_empty() {
            let mut state = runner.state.lock();
            attempts.retain(|attempt| {
                if !confirmed.contains(&attempt.token) {
                    return true;
                }
                state.jobs.remove(&attempt.token);
                freed.insert(attempt.queue.clone());
                false
            });
        }
    }
}

impl Drop for GroupedWriter {
    fn drop(&mut self) {
        self.requests.take();
        if let Some(thread) = self.thread.take() {
            let _ = thread.join();
        }
        if let Some(runner) = self.log_runner {
            eprintln!(
                "jobs_grouped_writer {}",
                serde_json::json!({
                    "runner": runner,
                    "mode": "fixed8ms",
                    "confirmed_free_claims": self.claims,
                    "requested_slots": self.claim_slots,
                    "claims_while_writing": self.claims_while_writing,
                    "cohort_submissions_by_width": self.widths,
                    "max_collection_us": self.max_collection_us,
                })
            );
        }
    }
}

fn ready_at(state: &State, attempt: &Attempt) -> Option<Instant> {
    match &state.jobs[&attempt.token].execution {
        Execution::Acknowledging {
            reply,
            retry_at: None,
            ready_at,
            ..
        } if attempt.submissions == 0
            && attempt.lease.is_some()
            && matches!(reply.outcome().0, Outcome::Complete) =>
        {
            Some(*ready_at)
        }
        _ => None,
    }
}

fn settle(namespace: &str, session: &mut JobSession, members: &[Member]) -> Vec<Disposition> {
    if let [member] = members {
        return vec![Some(
            session
                .with(|db| {
                    Ok(finish(
                        db,
                        namespace,
                        &member.id,
                        &member.token,
                        Outcome::Complete,
                    ))
                })
                .map_err(JobsAckError::Rejected)
                .and_then(|result| result),
        )];
    }
    let keys: Vec<_> = members
        .iter()
        .map(|member| (member.id.as_str(), member.token.as_str()))
        .collect();
    match session.with(|db| Ok(complete_batch(db, namespace, &keys))) {
        Ok(Ok(completed)) => completed
            .into_iter()
            .take(members.len())
            .map(|completed| completed.then_some(Ok(Settlement::Completed)))
            .collect(),
        Ok(Err(JobsAckError::Unconfirmed(error))) => members
            .iter()
            .map(|_| Some(Err(JobsAckError::Unconfirmed(error.clone()))))
            .collect(),
        // A failed checkout or a rejected statement can use the scalar path.
        _ => members.iter().map(|_| None).collect(),
    }
}
