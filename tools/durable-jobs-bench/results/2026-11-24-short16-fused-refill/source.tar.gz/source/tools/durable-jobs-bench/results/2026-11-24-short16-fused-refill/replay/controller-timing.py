#!/usr/bin/env python3
"""Controller entry point for granted Linode short16 completion/refill timing only."""

import argparse
from datetime import datetime, timezone
from importlib import import_module
from pathlib import Path
import re
import sys

from intake import RESULTS, compare, read, sha

ID = "2026-11-24-short16-fused-refill"
PUBLIC = "2026-11-24-trusted-jobs-product-composition"
sys.path.insert(0, str(RESULTS / "2026-11-23-bulk-enqueue-v2-short/replay"))
matrix = import_module("interleave-v2")
matrix.ATTEMPT_ERRORS += (AssertionError,)


def assignment(requests):
    entries = re.findall(r"^(SETUP|TIMING|RELEASED|HOLD) (\S+) (\S+)(?: (\S+))?",
                         (requests / "STATUS.md").read_text(), re.MULTILINE)
    kind, key, start, end = entries[-1]
    assert (kind, key) == ("TIMING", ID), f"missing controller TIMING grant for {ID}"
    assert datetime.fromisoformat(start) <= datetime.now(timezone.utc) < datetime.fromisoformat(end)
    setup = read(requests / f"{ID}.released.json")
    assert setup["id"] == ID and setup["exit_status"] == 0
    public = read(requests / f"{ID}.public-control.json")
    assert public["dependency"] == PUBLIC and public["receipts"]
    for path, digest in public["receipts"].items():
        assert sha(Path(path)) == digest
    return public


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("requests", type=Path)
    parser.add_argument("qualified", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("groups", type=int, nargs="+", choices=range(1, 6))
    args = parser.parse_args()
    public = assignment(args.requests)
    qualification = read(args.qualified)
    config = qualification["configuration"]
    recipe = qualification["recipe"]
    request = read(args.requests / f"{ID}.json")
    assert qualification["artifacts"]["candidate"]["source_sha256"] == request["source_archive_sha256"]
    assert qualification["manifest_sha256"]["public"] == public["manifest_sha256"]
    assert config["description"].startswith("Short16 completion/refill.")

    def replay(path, _, block):
        return dict(scores=compare(qualification, path, block["group"]))

    matrix.replay = replay
    matrix.plan = lambda *_: iter(recipe["blocks"])
    if any(group > 2 for group in args.groups):
        for block in recipe["blocks"][:2]:
            assert matrix.select_attempt(args.output, config, block, {}), "reconcile groups 1 and 2 first"

    original = matrix.dispatch_block

    def dispatch_block(*params):
        assignment(args.requests)
        return original(*params)

    matrix.dispatch_block = dispatch_block
    return matrix.dispatch(args.output, config, args.groups)


if __name__ == "__main__":
    sys.exit(main())
