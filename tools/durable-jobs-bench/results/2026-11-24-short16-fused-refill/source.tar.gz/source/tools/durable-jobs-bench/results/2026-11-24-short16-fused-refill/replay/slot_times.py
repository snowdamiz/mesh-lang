"""Verbatim stage_times and short_slot_times from tools/durable-jobs-bench/results/2026-11-23-iteration-comparison/application-intervals.py (SHA-256 4898d7c0861d250ebb2b6f9516176f802fcd1b8bf3dd1a55549d27b937cf050e)."""

from bisect import bisect_right


def stage_times(ledger, score):
    jobs = ledger["jobs"]
    tx, = ledger["transactions"]
    n = len(jobs)
    if n != score["completed"] or n not in (128, 1024):
        raise ValueError("unexpected job count")
    fields = ("entered_us", "attempt_committed_us", "effect_committed_us", "settled_us")
    for job in jobs:
        times = [tx["committed_us"], *(job[key] for key in fields)]
        if times != sorted(times):
            raise ValueError("unordered stage timestamps")
    if len({job[key] for job in jobs for key in ("attempt_xid", "effect_xid")}) != 2 * n:
        raise ValueError("application XIDs are not independent")

    last = [max(job[key] for job in jobs) for key in fields]
    for key, start in (("submit_jobs_per_s", tx["submitted_us"]), ("commit_jobs_per_s", tx["committed_us"])):
        if abs(n * 1_000_000 / score[key] - (last[-1] - start)) > 0.5:
            raise ValueError("recorded end-to-end clock differs")

    effects = sorted(job["effect_committed_us"] for job in jobs)
    trim = n // 10
    lo, hi = effects[trim], effects[n - 1 - trim]
    if hi <= lo:
        raise ValueError("empty middle interval")

    def mean_outstanding(start, end):
        return sum(max(0, min(hi, job[end]) - max(lo, job[start])) for job in jobs) / (hi - lo)

    return dict(enqueue=(tx["committed_us"] - tx["submitted_us"]) / 1000,
                entry=(last[0] - tx["committed_us"]) / 1000,
                write=(last[2] - tx["committed_us"]) / 1000,
                sixteenth_write=(effects[15] - tx["committed_us"]) / 1000,
                tail=(last[3] - last[2]) / 1000,
                submit=(last[3] - tx["submitted_us"]) / 1000,
                waiting_first=mean_outstanding(fields[0], fields[1]),
                between_writes=mean_outstanding(fields[1], fields[2]),
                waiting_terminal=mean_outstanding(fields[2], fields[3]))



def short_slot_times(ledger):
    slots = ledger["slots"]
    jobs = ledger["jobs"]
    if slots != 16 or len(jobs) != 128 or ledger["runners"] != 1:
        raise ValueError("unexpected short workload dimensions")
    effects = sorted(j["effect_committed_us"] for j in jobs)
    lo, hi = effects[slots - 1], effects[-1]
    entries = sorted(j["entered_us"] for j in jobs)
    if hi <= lo or any(bisect_right(entries, t) - bisect_right(effects, t) > slots for t in entries):
        raise ValueError("invalid handler occupancy or empty short write interval")

    def area(begin, end):
        return sum(max(0, min(hi, j[end]) - max(lo, j[begin])) for j in jobs)

    scale = 1000 * slots
    first = area("entered_us", "attempt_committed_us") / scale
    second = area("attempt_committed_us", "effect_committed_us") / scale
    result = dict(first=first, second=second, other=(hi - lo) / 1000 - first - second)
    if ledger["engine"] != "mesh":
        return result

    if any(j["claimed_us"] % 1000 or j["claimed_us"] > j["entered_us"] for j in jobs):
        raise ValueError("unexpected Mesh claim stamp or entry time")
    ends = sorted(j["settled_us"] for j in jobs)

    def available_before_admission(rounding_us):
        claims = sorted(min(j["entered_us"], j["claimed_us"] + rounding_us) for j in jobs)
        edges = sorted({lo, hi, *(t for t in claims + ends if lo < t < hi)})
        total = 0
        for start, stop in zip(edges, edges[1:]):
            claimed = bisect_right(claims, start)
            settled = bisect_right(ends, start)
            unclaimed = len(jobs) - claimed
            seats = max(0, slots - (claimed - settled))
            total += min(seats, unclaimed) * (stop - start)
        return total / scale

    result["available"] = (available_before_admission(0), available_before_admission(999))
    result["after_write"] = area("effect_committed_us", "settled_us") / scale
    return result
