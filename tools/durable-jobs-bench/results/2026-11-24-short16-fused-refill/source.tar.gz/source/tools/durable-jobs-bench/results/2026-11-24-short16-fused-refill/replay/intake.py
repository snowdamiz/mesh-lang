#!/usr/bin/env python3
"""Bind the short16 completion/refill comparison to controller-built ELFs."""

import argparse
from collections import Counter
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import re
from statistics import median
import sys
import tarfile

HERE = Path(__file__).resolve().parent
PACKET = HERE.parent
RESULTS = PACKET.parent
SUITE = RESULTS.parent
ROOT = SUITE.parents[1]
FROZEN = RESULTS / "2026-11-24-bulk-d2-short-peers/short.json"
PUBLIC = RESULTS / "2026-11-24-trusted-jobs-product-composition"
PEERS = ("river", "oban", "apalis")
NATIVE = Path("/var/lib/durable-jobs-bench/native")
ARM_FILES = ("native-run", "product_arm.py", "backend.py", "identity.py")
COMPILER = "e023d5944764878969ca40b7edb59c779498a435b44d308776076f4c7f2e8c19"
PUBLIC_REVISION = "b3557273d72be3802bf189b284e7caaf5f3caa0f"
# Product lanes: (attempt kind, PRODUCT_COMPOSITION).
PRODUCT = {
    "public-group": ("public", "product-group"),
    "group-a": ("candidate", "product-group"),
    "group-b": ("candidate", "product-group"),
    "fused-a": ("candidate", "product-fused"),
    "fused-b": ("candidate", "product-fused"),
}
LANES = (*PRODUCT, *PEERS)
FIRST = ("group-a", "fused-a", "river", "public-group", "oban", "fused-b", "apalis", "group-b")
THIRD = ("fused-a", "oban", "group-b", "apalis", "public-group", "river", "group-a", "fused-b")
FIFTH = ("river", "group-b", "fused-b", "public-group", "apalis", "fused-a", "oban", "group-a")
ORDERS = (FIRST, FIRST[::-1], THIRD, THIRD[::-1], FIFTH)
METRICS = ("submit_jobs_per_s", "commit_jobs_per_s", "submit_to_settlement_p99_ms",
           "commit_to_settlement_p99_ms", "peak_executing", "peak_connections")
sys.path.insert(0, str(SUITE))
import run
import verify

import slot_times as intervals


def read(path):
    return json.loads(path.read_text())


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def plan():
    stock_runners, slots, cap, input_sha, warm = verify.PROFILES["short"]
    assert (stock_runners, slots, warm) == (1, 16, False)
    return dict(profile="short", topology="stock", storage="default", input_sha256=input_sha,
                product_runners=1, peer_runners=1, slots=slots, cap=cap, app_sessions=8,
                blocks=[dict(group=i, profile="short", phases=["measured"], order=list(order))
                        for i, order in enumerate(ORDERS, 1)])


def build_manifest(path, pattern, attempt):
    assert re.fullmatch(pattern, attempt), attempt
    build = read(path)
    assert (build["system"], build["architecture"]) == ("Linux", "x86_64")
    assert build["compiler_sha256"] == COMPILER
    assert build["execution_contract"] == "ordinary-trusted-shared-process-v2"
    assert attempt.endswith(build["source_sha256"][:12])
    return build


def product_lane(frozen, packet, attempt, manifest_path, build, mode):
    remote = NATIVE / f"source-{attempt}/source" / packet.relative_to(ROOT) / "replay"
    artifact = NATIVE / f"builds/{attempt}"
    manifest_sha = sha(manifest_path)
    pins = {str(remote / name): sha(packet / "replay" / name) for name in ARM_FILES}
    pins.update({str(artifact / name): digest for name, digest in build["files"].items()})
    pins[str(artifact / "mesh.json")] = manifest_sha
    entry = deepcopy(frozen["lanes"]["bulk"])
    spec = entry["inventory"]["engines"]["mesh"]
    harness = {path: value for path, value in spec["verified_files"].items()
               if "/source-bulk-enqueue-3b09dc3d0e23/ordinary-v2/" in path}
    spec.update(argv=["/usr/bin/env", f"PRODUCT_ARTIFACT={artifact}",
                      f"PRODUCT_COMPOSITION={mode}", "PRODUCT_TOPOLOGY=stock",
                      "PRODUCT_STORAGE=default", f"PRODUCT_ELF_SHA256={build['files']['mesh']}",
                      f"PRODUCT_MANIFEST_SHA256={manifest_sha}", str(remote / "native-run"), "mesh"],
                artifact_sha256=manifest_sha, version=build["version"], verified_files=harness | pins)
    entry["queue_policy"] = "success_cohort"
    entry["product_mode"] = mode
    return entry


def inventory(attempt, manifest, public_attempt, public_manifest, public_packet=PUBLIC):
    candidate = build_manifest(manifest, r"short16-fused-refill-[0-9a-f]{12}", attempt)
    public = build_manifest(public_manifest, r"trusted-jobs-product-[0-9a-f]{12}", public_attempt)
    assert public["version"] == PUBLIC_REVISION
    assert candidate["files"]["mesh"] != public["files"]["mesh"]
    frozen = read(FROZEN)
    cfg = {key: frozen[key] for key in ("host", "cpus", "clock_ticks", "contract")}
    recipe = plan()
    lanes = {label: frozen["lanes"][label] for label in PEERS}
    for label, (kind, mode) in PRODUCT.items():
        lanes[label] = (product_lane(frozen, PACKET, attempt, manifest, candidate, mode)
                        if kind == "candidate" else
                        product_lane(frozen, public_packet, public_attempt, public_manifest, public, mode))
    cfg.update(description="Short16 completion/refill. Each arm uses a fresh PostgreSQL cluster.",
               profiles=["short"], lanes=lanes)
    for lane in lanes.values():
        run.check_inventory(lane["inventory"])
    assert all(sorted(block["order"]) == sorted(LANES) for block in recipe["blocks"])
    return {"configuration": cfg, "recipe": recipe,
            "artifacts": {"candidate": candidate, "public": public},
            "manifest_sha256": {"candidate": sha(manifest), "public": sha(public_manifest)}}


def compare(qualified, block_root, group):
    cfg = qualified["configuration"]
    recipe = qualified["recipe"]
    block = recipe["blocks"][group - 1]
    assert read(block_root / "order.json") == block
    result = {}
    for label in block["order"]:
        lane = cfg["lanes"][label]
        engine = lane["engine"]
        folder = block_root / f"measured-{label}" / f"measured-{engine}"
        score = run.score_arm(folder, block, "measured", engine, lane["inventory"])
        assert [score["host_boot_id"], score["host_kernel"], score["pg_mount"]["maj:min"]] == cfg["host"]
        archive_path = folder / "raw.tar.gz"
        with tarfile.open(archive_path) as archive:
            get = lambda name: run.file_json(archive, f"adapter/{name}.json")
            ledger = get("ledger")
            score["stages"] = intervals.stage_times(ledger, score)
            score["slots"] = intervals.short_slot_times(ledger)
            score["sixteenth_to_last_write_ms"] = (score["stages"]["write"]
                                                   - score["stages"]["sixteenth_write"])
            if engine == "mesh":
                kind, mode = PRODUCT[label]
                assert get("build") == qualified["artifacts"][kind]
                q = get("queue-policy")
                assert q["queue_policy"] == ledger["queue_policy"] == "success_cohort"
                assert q["admitted_queries"] > 0
                assert len(get("process-identity")) == 2
                assert get("postgres-settings")["max_connections"] == recipe["cap"]
                storage = get("storage-topology")
                assert (storage["topology"], storage["storage"]) == ("stock", "default")
                writes = get("trusted-application-statements")
                for suffix in ("attempts", "effects"):
                    (statement,) = [s for s in writes
                                   if s["query"].startswith("INSERT INTO public.mesh_jobs_parity_" + suffix)]
                    assert statement["rows"] == statement["calls"] == score["completed"]
                probes = sum(row["calls"] for row in writes if row["query"] == "SELECT $1")
                assert probes == 256, "the checked pool must keep two probes per job (D2 off)"
                cohorts = Counter(row["settled_xid"] for row in ledger["jobs"])
                assert max(cohorts.values()) <= 8
                writer = get("producer-writer")
                assert (writer["bulk"], writer["scalar"]) == (1, 0)
                fused = None
                if kind == "candidate":
                    refill = get("refill-ledger")
                    assert refill["fused"] == (mode == "product-fused")
                    fused = refill["counts"]
                score.update(checkout_probes=probes, terminal_xids=len(cohorts),
                             largest_terminal_cohort=max(cohorts.values()), completion_refill=fused)
        result[label] = dict(score, raw_sha256=sha(archive_path))
    return result


def summarize(groups):
    keys = METRICS + ("sixteenth_to_last_write_ms",)
    medians = {lane: {key: median(group[lane][key] for group in groups) for key in keys}
               for lane in groups[0]}
    paired = {}
    for fused, group in (("fused-a", "group-a"), ("fused-b", "group-b"),
                         ("fused-a", "public-group"), ("fused-b", "public-group")):
        paired[f"{fused}/{group}"] = [
            {key: g[fused][key] / g[group][key] - 1 for key in METRICS[:2]}
            | {"sixteenth_to_last_write_ms": g[fused]["sixteenth_to_last_write_ms"]
               - g[group]["sixteenth_to_last_write_ms"]}
            for g in groups]
    aa = {f"{a}/{b}": [{key: g[a][key] / g[b][key] - 1 for key in METRICS[:2]} for g in groups]
          for a, b in (("group-a", "group-b"), ("fused-a", "fused-b"), ("group-a", "public-group"))}
    return dict(groups=groups, medians=medians, paired=paired, same_image_aa=aa)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="action", required=True)
    sub.add_parser("plan")
    bind = sub.add_parser("bind")
    bind.add_argument("attempt")
    bind.add_argument("manifest", type=Path)
    bind.add_argument("public_attempt")
    bind.add_argument("public_manifest", type=Path)
    check = sub.add_parser("replay")
    check.add_argument("qualified", type=Path)
    check.add_argument("blocks", nargs="+", type=Path)
    args = parser.parse_args()
    if args.action == "plan":
        data = plan()
    elif args.action == "bind":
        data = inventory(args.attempt, args.manifest, args.public_attempt, args.public_manifest)
    else:
        qualified = read(args.qualified)
        assert len(args.blocks) <= 5
        data = summarize([compare(qualified, path, group)
                          for group, path in enumerate(args.blocks, 1)])
    print(json.dumps(data, sort_keys=True, indent=2))


if __name__ == "__main__":
    main()
