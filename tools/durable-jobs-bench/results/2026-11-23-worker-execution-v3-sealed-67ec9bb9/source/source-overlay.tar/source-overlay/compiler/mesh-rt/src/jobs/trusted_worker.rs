use std::collections::HashSet;
use std::net::Shutdown;
use std::os::fd::{AsRawFd, FromRawFd, OwnedFd};
use std::os::unix::process::CommandExt;
use std::sync::atomic::AtomicBool;
use std::thread::{self, JoinHandle};

use crate::actor::{global_scheduler, stack};
use crate::db::pg::jobs_effect_session::{EffectAuthority, IO_TIMEOUT};

use super::super::effects::{self, Identity, Shared};
use super::super::runner::{JobProcess, Worker};
use super::super::store::Outcome;
use super::*;

#[path = "trusted_control.rs"]
mod control;

#[derive(Deserialize, Serialize)]
struct TurnRequest {
    handler: String,
}

pub(in crate::jobs) const WORKER_ARG: &str = "--mesh-internal-job-trusted-worker-v1";
pub(in crate::jobs) const EFFECT: u8 = 1;
const RETURN: u8 = 2;
const UNSUPPORTED_OPERATION: i32 = 175;
static TRUSTED_CHILD: AtomicBool = AtomicBool::new(false);

pub(in crate::jobs) fn reject_spawn() {
    if TRUSTED_CHILD.load(Ordering::Relaxed) {
        exit_worker(UNSUPPORTED_OPERATION);
    }
}

#[derive(Clone)]
pub(in crate::jobs) struct LanePool(Arc<Mutex<PoolState>>);

#[derive(Default)]
struct PoolState {
    idle: Vec<Lane>,
    unsupported: HashSet<Worker>,
}

impl LanePool {
    pub(in crate::jobs) fn new() -> Self {
        Self(Arc::new(Mutex::new(PoolState::default())))
    }

    pub(in crate::jobs) fn sweep_idle(&self, remove_all: bool) {
        self.0
            .lock()
            .idle
            .retain_mut(|lane| !remove_all && matches!(lane.child.try_wait(), Ok(None)));
    }

    pub(in crate::jobs) fn discard_idle(&self) {
        let idle = self.0.lock().idle.pop();
        drop(idle);
    }

    pub(in crate::jobs) fn supports(&self, workload: &Worker) -> bool {
        !self.0.lock().unsupported.contains(workload)
    }

    fn acquire(&self) -> Result<Lane, String> {
        while let Some(mut lane) = self.0.lock().idle.pop() {
            if lane
                .child
                .try_wait()
                .map_err(|error| error.to_string())?
                .is_none()
            {
                return Ok(lane);
            }
        }
        Lane::spawn().map_err(|error| format!("could not start trusted Jobs worker: {error}"))
    }

    #[allow(clippy::too_many_arguments)]
    pub(in crate::jobs) fn start(
        &self,
        handler: &str,
        workload: Worker,
        context: String,
        deadline: Instant,
        lease: Instant,
        worker_lease: u64,
        identity: Identity,
        authority: Arc<EffectAuthority>,
        shared: Arc<Shared>,
        reply_wake: Sender<()>,
    ) -> Result<Box<dyn JobProcess>, String> {
        let request = TurnRequest {
            handler: handler.to_owned(),
        };
        let hard_deadline = host_deadline(deadline)?;
        let (relay, child) = UnixStream::pair().map_err(|error| error.to_string())?;
        let shutdown = relay.try_clone().map_err(|error| error.to_string())?;
        let (result, finished) = crossbeam_channel::bounded(1);
        let mut lane = self.acquire()?;
        lane.generation = lane
            .generation
            .checked_add(1)
            .ok_or("trusted Jobs worker generation exhausted")?;
        let generation = lane.generation;
        Ok(Box::new(Process {
            lane: Some(lane),
            pool: self.clone(),
            workload,
            generation,
            activation: Some(Activation {
                child: child.into(),
                hard_deadline,
                worker_lease,
                turn: Turn {
                    request,
                    context,
                    identity,
                    deadline,
                    authority: authority.clone(),
                    shared: shared.clone(),
                    relay,
                    result,
                    reply_wake,
                },
            }),
            shutdown,
            authority,
            shared,
            finished,
            deadline,
            lease,
            completion: None,
            retiring: false,
            crashed: false,
            reusable: false,
        }))
    }
}

struct Lane {
    child: Child,
    control: OwnedFd,
    generation: u64,
    turns: Option<Sender<Turn>>,
    relay: Option<JoinHandle<()>>,
}

impl Lane {
    fn spawn() -> io::Result<Self> {
        let (peer, child) = control::pair()?;
        let mut command = Command::new(executable().map_err(io::Error::other)?);
        configure_effect_worker_env(&mut command, std::env::var_os(DISABLE_THP_ENV).as_deref());
        command
            .arg(WORKER_ARG)
            .env("MESH_SCHEDULER_MIN_WORKERS", "1")
            .env("MESH_SCHEDULER_MAX_WORKERS", "1")
            .process_group(0)
            .stdin(Stdio::from(child))
            .stdout(Stdio::inherit())
            .stderr(Stdio::inherit());
        let parent = unsafe { libc::getpid() };
        // Leave Rust's exec-error pipe available until exec. The worker and
        // its native constructors receive only the three positional streams.
        unsafe {
            command.pre_exec(move || {
                if libc::prctl(libc::PR_SET_PDEATHSIG, libc::SIGKILL, 0, 0, 0) == -1
                    || libc::dup2(libc::STDERR_FILENO, libc::STDOUT_FILENO) == -1
                    || libc::syscall(
                        libc::SYS_close_range,
                        3u32,
                        u32::MAX,
                        libc::CLOSE_RANGE_CLOEXEC,
                    ) == -1
                {
                    return Err(io::Error::last_os_error());
                }
                if libc::getppid() != parent {
                    return Err(io::ErrorKind::BrokenPipe.into());
                }
                Ok(())
            });
        }
        let mut lane = Self {
            child: command.spawn()?,
            control: peer,
            generation: 0,
            turns: None,
            relay: None,
        };
        drop(command);
        let (turns, input) = crossbeam_channel::bounded::<Turn>(1);
        lane.turns = Some(turns);
        lane.relay = Some(
            thread::Builder::new()
                .name("mesh-job-trusted-relay".into())
                .spawn(move || {
                    while let Ok(turn) = input.recv() {
                        turn.run();
                    }
                })?,
        );
        Ok(lane)
    }
}

impl Drop for Lane {
    fn drop(&mut self) {
        self.turns.take();
        let _ = self.child.kill();
        let _ = self.child.wait();
        if let Some(relay) = self.relay.take() {
            let _ = relay.join();
        }
    }
}

struct Activation {
    child: OwnedFd,
    hard_deadline: u64,
    worker_lease: u64,
    turn: Turn,
}

struct Turn {
    request: TurnRequest,
    context: String,
    identity: Identity,
    deadline: Instant,
    authority: Arc<EffectAuthority>,
    shared: Arc<Shared>,
    relay: UnixStream,
    result: Sender<Result<Reply, String>>,
    reply_wake: Sender<()>,
}

impl Turn {
    fn fail(self, error: io::Error) {
        let _ = self.result.send(Err(format!(
            "could not send trusted Jobs assignment: {error}"
        )));
        let _ = self.reply_wake.try_send(());
    }

    fn run(self) {
        let Self {
            request,
            context,
            identity,
            deadline,
            authority,
            shared,
            mut relay,
            result,
            reply_wake,
        } = self;
        let completion = relay
            .set_write_timeout(Some(IO_TIMEOUT))
            .and_then(|()| write_frame(&mut relay, &request, MAX_REQUEST_HEADER))
            .and_then(|()| write_bytes(&mut relay, context.as_bytes(), MAX_DB_VALUE_BYTES))
            .map_err(|error| format!("could not send trusted Jobs attempt: {error}"));
        drop(context);
        let completion = completion
            .and_then(|()| read_turn(&mut relay, deadline, &identity, &authority, &shared));
        let interrupted = authority.revoke();
        let _ = relay.shutdown(Shutdown::Both);
        drop(relay);
        let completion = if interrupted {
            Err(effects::UNKNOWN.into())
        } else {
            completion
        };
        let _ = result.send(completion);
        let _ = reply_wake.try_send(());
    }
}

fn read_turn(
    relay: &mut UnixStream,
    deadline: Instant,
    identity: &Identity,
    authority: &EffectAuthority,
    shared: &Shared,
) -> Result<Reply, String> {
    loop {
        let mut opcode = [0];
        relay
            .set_read_timeout(None)
            .map_err(|error| error.to_string())?;
        relay
            .read_exact(&mut opcode)
            .map_err(|error| format!("trusted Jobs worker lost: {error}"))?;
        match opcode[0] {
            EFFECT => {
                if !effects::serve_tagged_call(relay, deadline, identity, authority, shared) {
                    return Err(effects::UNKNOWN.into());
                }
            }
            RETURN => {
                relay
                    .set_read_timeout(Some(IO_TIMEOUT))
                    .map_err(|error| error.to_string())?;
                let reply = read_frame(relay, MAX_REPLY_FRAME)
                    .map_err(|error| format!("invalid trusted Jobs reply: {error}"))?;
                // Only a closed attempt stream can be followed by another
                // assignment. Extra bytes would be an out-of-turn request.
                if relay.read(&mut opcode).ok() != Some(0) || !authority.live() {
                    return Err("trusted Jobs attempt did not close cleanly".into());
                }
                return Ok(reply);
            }
            _ => return Err("invalid trusted Jobs message".into()),
        }
    }
}

struct Process {
    lane: Option<Lane>,
    pool: LanePool,
    workload: Worker,
    generation: u64,
    activation: Option<Activation>,
    shutdown: UnixStream,
    authority: Arc<EffectAuthority>,
    shared: Arc<Shared>,
    finished: Receiver<Result<Reply, String>>,
    deadline: Instant,
    lease: Instant,
    completion: Option<Result<Reply, String>>,
    retiring: bool,
    crashed: bool,
    reusable: bool,
}

impl Process {
    fn revoke(&self) {
        self.authority.revoke();
        let _ = self.shutdown.shutdown(Shutdown::Both);
        effects::interrupt_waiters(&self.shared);
    }

    fn retire(&mut self) -> Result<(), String> {
        self.retiring = true;
        self.reusable = false;
        self.revoke();
        self.activation.take();
        self.lane
            .as_mut()
            .unwrap()
            .child
            .kill()
            .map_err(|error| error.to_string())
    }
}

impl JobProcess for Process {
    fn activate_effects(&mut self) {
        if let Some(Activation {
            child,
            hard_deadline,
            worker_lease,
            turn,
        }) = self.activation.take()
        {
            let lane = self.lane.as_ref().unwrap();
            // Registration precedes BEGIN. The single seqpacket carries both
            // initial bounds and the fresh endpoint before any renewal can run.
            match control::begin(
                lane.control.as_raw_fd(),
                self.generation,
                hard_deadline,
                worker_lease,
                child,
            ) {
                Ok(()) => {
                    let _ = lane.turns.as_ref().unwrap().try_send(turn);
                }
                Err(error) => turn.fail(error),
            }
        }
    }

    fn confirm_effect_lease(&mut self, expires: Instant) {
        self.lease = expires;
        self.authority.renew(expires);
    }

    fn limit_effect_deadline(&mut self, deadline: Instant) {
        if deadline >= self.deadline {
            return;
        }
        self.deadline = deadline;
        self.authority.limit_deadline(deadline);
        effects::interrupt_waiters(&self.shared);
        let fd = self.lane.as_ref().unwrap().control.as_raw_fd();
        if !self.retiring
            && host_deadline(deadline)
                .and_then(|limit| {
                    control::limit(fd, self.generation, limit).map_err(|error| error.to_string())
                })
                .is_err()
        {
            let _ = self.retire();
        }
    }

    fn renew(&mut self, lease: u64) -> Result<(), String> {
        if self.retiring {
            return Ok(());
        }
        let fd = self.lane.as_ref().unwrap().control.as_raw_fd();
        control::renew(fd, self.generation, lease).map_err(|error| error.to_string())
    }

    fn reply_pending(&self) -> bool {
        !self.finished.is_empty()
    }

    fn poll(&mut self, now: Instant) -> Result<WorkerPoll, String> {
        if !self.retiring && now >= self.deadline.min(self.lease) {
            // Let the runner record the timeout, lease loss, or shutdown reason
            // and revoke the attempt before consuming any buffered result.
            return Ok(WorkerPoll::Running);
        }
        let status = self
            .lane
            .as_mut()
            .unwrap()
            .child
            .try_wait()
            .map_err(|error| error.to_string())?;
        if status.is_some() && !self.retiring {
            self.retiring = true;
            self.crashed = true;
            self.revoke();
        }
        if self.completion.is_none() {
            self.completion = match self.finished.try_recv() {
                Ok(result) => Some(result),
                Err(TryRecvError::Empty) => return Ok(WorkerPoll::Running),
                Err(TryRecvError::Disconnected) => Some(Err("trusted Jobs relay exited".into())),
            };
        }
        if !self.retiring {
            self.reusable = matches!(
                self.completion.as_ref(),
                Some(Ok(Ok(output))) if matches!(serde_json::from_str(output), Ok(Outcome::Complete))
            );
            if !self.reusable {
                self.retire()?;
                return Ok(WorkerPoll::Running);
            }
        } else if status.is_none() {
            // Settlement is downstream of both relay completion and consuming wait.
            return Ok(WorkerPoll::Running);
        }
        let completion = self.completion.take().unwrap();
        if status.and_then(|status| status.code()) == Some(UNSUPPORTED_OPERATION) {
            self.pool.0.lock().unsupported.insert(self.workload.clone());
            return Ok(WorkerPoll::Exited(Err(
                "trusted Jobs handler tried to spawn an actor; subsequent attempts use strict execution".into(),
            )));
        }
        if self.crashed {
            let status = status.unwrap();
            return Ok(match status.code() {
                Some(TIMEOUT) => WorkerPoll::TimedOut,
                Some(LEASE_LOST) => WorkerPoll::LeaseExpired,
                _ => WorkerPoll::Exited(Err(completion
                    .err()
                    .unwrap_or_else(|| format!("trusted Jobs worker exited: {status}")))),
            });
        }
        Ok(WorkerPoll::Exited(completion.unwrap_or_else(Err)))
    }

    fn kill(&mut self) -> Result<(), String> {
        self.retire()
    }
}

impl Drop for Process {
    fn drop(&mut self) {
        if self.reusable {
            self.pool.0.lock().idle.push(self.lane.take().unwrap());
        } else {
            self.revoke();
        }
    }
}

pub(super) fn enter() -> ! {
    TRUSTED_CHILD.store(true, Ordering::Relaxed);
    crate::panic::ignore_sigpipe();
    if let Err(error) = run_child() {
        if error.kind() == io::ErrorKind::UnexpectedEof {
            exit_worker(PARENT_GONE);
        }
        eprintln!("Mesh trusted Jobs worker failed: {error}");
    }
    exit_worker(BOOTSTRAP_ERROR);
}

fn run_child() -> io::Result<()> {
    let fd = unsafe { libc::fcntl(libc::STDIN_FILENO, libc::F_DUPFD_CLOEXEC, 3) };
    if fd == -1 {
        return Err(io::Error::last_os_error());
    }
    let control = unsafe { OwnedFd::from_raw_fd(fd) };
    let null = File::open("/dev/null")?;
    if unsafe { libc::dup2(null.as_raw_fd(), libc::STDIN_FILENO) } == -1 {
        return Err(io::Error::last_os_error());
    }
    drop(null);
    let descriptors = open_descriptors()?;
    let watchdog = control::Watchdog::start(control)?;
    let scheduler = global_scheduler();
    let initial =
        stack::get_current_pid().ok_or_else(|| io::Error::other("missing Jobs runtime"))?;
    let stack_base = scheduler.get_process(initial).unwrap().lock().stack_base;
    scheduler.finalize_host_process(initial);
    stack::clear_current_pid();
    loop {
        let control::Assignment {
            generation,
            mut socket,
        } = watchdog.next()?;
        socket.set_read_timeout(Some(IO_TIMEOUT))?;
        let request: TurnRequest = read_frame(&mut socket, MAX_REQUEST_HEADER)?;
        let context = String::from_utf8(read_bytes(&mut socket, MAX_DB_VALUE_BYTES)?)
            .map_err(io::Error::other)?;
        let handler = HANDLERS
            .lock()
            .get(&request.handler)
            .copied()
            .ok_or_else(|| io::Error::other("job handler is missing from this executable"))?;
        watchdog.check(generation);
        let pid = scheduler.create_main_process();
        {
            let process = scheduler.get_process(pid).unwrap();
            let mut process = process.lock();
            process.stack_base = stack_base;
            process.collects_at_safepoints = !stack_base.is_null();
        }
        stack::set_current_pid(pid);
        let mut expected = descriptors.clone();
        expected.insert(socket.as_raw_fd(), descriptor(socket.as_raw_fd())?);
        let reply = effects::in_trusted_attempt(socket.try_clone()?, || {
            invoke(context, |input| {
                watchdog.check(generation);
                unsafe { handler(input) }
            })
        });
        // The Rust outcome owns its bytes. Retire the attempt's managed heap,
        // mailbox and actor-owned resources before publishing any result.
        scheduler.finalize_host_process(pid);
        stack::clear_current_pid();
        socket.set_write_timeout(Some(IO_TIMEOUT))?;
        if open_descriptors()? != expected {
            return Err(io::Error::other(
                "trusted Jobs handler changed open descriptors",
            ));
        }
        watchdog.check(generation);
        socket.write_all(&[RETURN])?;
        write_frame(&mut socket, &reply, MAX_REPLY_FRAME)?;
        watchdog.finish(generation);
        socket.shutdown(Shutdown::Both)?;
    }
}

fn descriptor(fd: i32) -> io::Result<PathBuf> {
    std::fs::read_link(format!("/proc/self/fd/{fd}"))
}

fn open_descriptors() -> io::Result<BTreeMap<i32, PathBuf>> {
    struct Dir(std::ptr::NonNull<libc::DIR>);
    impl Drop for Dir {
        fn drop(&mut self) {
            unsafe { libc::closedir(self.0.as_ptr()) };
        }
    }

    let directory =
        Dir(
            std::ptr::NonNull::new(unsafe { libc::opendir(c"/proc/self/fd".as_ptr()) })
                .ok_or_else(io::Error::last_os_error)?,
        );
    let directory_fd = unsafe { libc::dirfd(directory.0.as_ptr()) };
    let mut descriptors = BTreeMap::new();
    loop {
        let entry = unsafe {
            *libc::__errno_location() = 0;
            libc::readdir(directory.0.as_ptr())
        };
        if entry.is_null() {
            let errno = unsafe { *libc::__errno_location() };
            return if errno == 0 {
                Ok(descriptors)
            } else {
                Err(io::Error::from_raw_os_error(errno))
            };
        }
        let name = unsafe { CStr::from_ptr((*entry).d_name.as_ptr()) };
        if let Some(fd) = name.to_str().ok().and_then(|name| name.parse::<i32>().ok()) {
            if fd != directory_fd {
                descriptors.insert(fd, descriptor(fd)?);
            }
        }
    }
}
