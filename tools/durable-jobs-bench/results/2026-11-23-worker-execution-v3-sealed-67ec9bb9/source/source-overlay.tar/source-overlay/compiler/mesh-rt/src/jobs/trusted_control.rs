use std::io;
use std::os::fd::{AsRawFd, FromRawFd, OwnedFd, RawFd};
use std::os::unix::net::UnixStream;
use std::sync::Arc;
use std::time::Duration;

use crossbeam_channel::{Receiver, Sender};
use parking_lot::Mutex;

use super::super::effect_endpoint;
use super::super::{exit_worker, remaining, BOOTSTRAP_ERROR, PARENT_GONE};

pub(super) fn pair() -> io::Result<(OwnedFd, OwnedFd)> {
    let mut fds = [-1; 2];
    if unsafe {
        libc::socketpair(
            libc::AF_UNIX,
            libc::SOCK_SEQPACKET | libc::SOCK_CLOEXEC,
            0,
            fds.as_mut_ptr(),
        )
    } == -1
    {
        return Err(io::Error::last_os_error());
    }
    Ok(unsafe { (OwnedFd::from_raw_fd(fds[0]), OwnedFd::from_raw_fd(fds[1])) })
}

const BEGIN: u8 = 1;
const RENEW: u8 = 2;
const LIMIT: u8 = 3;
const FRAME_BYTES: usize = 25;

pub(super) fn begin(
    control: RawFd,
    generation: u64,
    deadline: u64,
    lease: u64,
    attempt: OwnedFd,
) -> io::Result<()> {
    send(
        control,
        BEGIN,
        generation,
        deadline,
        lease,
        &[attempt.as_raw_fd()],
    )
}

pub(super) fn renew(control: RawFd, generation: u64, lease: u64) -> io::Result<()> {
    send(control, RENEW, generation, lease, 0, &[])
}

pub(super) fn limit(control: RawFd, generation: u64, deadline: u64) -> io::Result<()> {
    send(control, LIMIT, generation, deadline, 0, &[])
}

fn send(
    control: RawFd,
    command: u8,
    generation: u64,
    value: u64,
    lease: u64,
    fds: &[RawFd],
) -> io::Result<()> {
    let mut packet = [0; FRAME_BYTES];
    packet[0] = command;
    packet[1..9].copy_from_slice(&generation.to_le_bytes());
    packet[9..17].copy_from_slice(&value.to_le_bytes());
    packet[17..25].copy_from_slice(&lease.to_le_bytes());
    effect_endpoint::send_packet(control, &packet, fds)
}

pub(super) struct Assignment {
    pub(super) generation: u64,
    pub(super) socket: UnixStream,
}

struct Active {
    generation: u64,
    deadline: u64,
    lease: u64,
}

impl Active {
    fn remaining(&self) -> Duration {
        remaining(self.deadline, self.lease)
    }
}

#[derive(Default)]
struct Fence {
    last_generation: u64,
    active: Option<Active>,
}

impl Fence {
    fn begin(&mut self, generation: u64, deadline: u64, lease: u64) -> io::Result<()> {
        if self.active.is_some() || self.last_generation.checked_add(1) != Some(generation) {
            return Err(io::ErrorKind::InvalidData.into());
        }
        remaining(deadline, lease);
        self.last_generation = generation;
        self.active = Some(Active {
            generation,
            deadline,
            lease,
        });
        Ok(())
    }

    fn update(&mut self, command: u8, generation: u64, value: u64) {
        if let Some(active) = self
            .active
            .as_mut()
            .filter(|active| active.generation == generation)
        {
            if command == RENEW {
                active.lease = active.lease.max(value);
            } else {
                active.deadline = active.deadline.min(value);
            }
        }
    }

    fn require(&self, generation: u64) {
        if let Some(active) = self
            .active
            .as_ref()
            .filter(|active| active.generation == generation)
        {
            active.remaining();
        } else {
            exit_worker(BOOTSTRAP_ERROR);
        }
    }
}

pub(super) struct Watchdog {
    fence: Arc<Mutex<Fence>>,
    input: Receiver<Assignment>,
}

impl Watchdog {
    pub(super) fn start(control: OwnedFd) -> io::Result<Self> {
        let fence = Arc::new(Mutex::new(Fence::default()));
        let watcher = fence.clone();
        let (send, input) = crossbeam_channel::bounded(1);
        std::thread::Builder::new()
            .name("mesh-job-watchdog".into())
            .spawn(move || match watch(&control, &watcher, &send) {
                Err(error) if error.kind() == io::ErrorKind::UnexpectedEof => {
                    exit_worker(PARENT_GONE)
                }
                _ => exit_worker(BOOTSTRAP_ERROR),
            })?;
        Ok(Self { fence, input })
    }

    pub(super) fn next(&self) -> io::Result<Assignment> {
        self.input
            .recv()
            .map_err(|_| io::ErrorKind::BrokenPipe.into())
    }

    pub(super) fn check(&self, generation: u64) {
        self.fence.lock().require(generation);
    }

    pub(super) fn finish(&self, generation: u64) {
        let mut fence = self.fence.lock();
        fence.require(generation);
        fence.active = None;
    }
}

fn watch(
    control: &OwnedFd,
    fence: &Mutex<Fence>,
    assignments: &Sender<Assignment>,
) -> io::Result<()> {
    loop {
        let wait = fence
            .lock()
            .active
            .as_ref()
            .map(|active| active.remaining().min(Duration::from_millis(20)));
        let mut packet = [0; FRAME_BYTES];
        let socket = match effect_endpoint::receive_packet(control.as_raw_fd(), wait, &mut packet) {
            Ok(socket) => socket,
            Err(error)
                if matches!(
                    error.kind(),
                    io::ErrorKind::TimedOut | io::ErrorKind::Interrupted
                ) =>
            {
                continue
            }
            Err(error) => return Err(error),
        };
        let generation = u64::from_le_bytes(packet[1..9].try_into().unwrap());
        let value = u64::from_le_bytes(packet[9..17].try_into().unwrap());
        let lease = u64::from_le_bytes(packet[17..25].try_into().unwrap());
        let mut fence = fence.lock();
        if let Some(active) = &fence.active {
            // A timely send cannot resurrect authority after the current deadline.
            active.remaining();
        }
        match (packet[0], socket) {
            (BEGIN, Some(socket)) => {
                fence.begin(generation, value, lease)?;
                assignments
                    .try_send(Assignment { generation, socket })
                    .map_err(|_| io::ErrorKind::InvalidData)?;
            }
            (command @ (RENEW | LIMIT), None) => fence.update(command, generation, value),
            _ => return Err(io::ErrorKind::InvalidData.into()),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::super::super::boot_millis;
    use super::*;

    #[test]
    fn lease_and_deadline_updates_are_scoped_to_the_active_generation() {
        let now = boot_millis().unwrap();
        let mut fence = Fence::default();
        fence.begin(1, now + 5000, now + 1000).unwrap();
        assert!(fence.begin(2, now + 5000, now + 1000).is_err());
        fence.update(RENEW, 1, now + 2000);
        assert_eq!(fence.active.as_ref().unwrap().lease, now + 2000);

        fence.active = None;
        fence.begin(2, now + 5000, now + 1000).unwrap();
        fence.update(RENEW, 1, now + 4000);
        fence.update(LIMIT, 1, now + 1);
        fence.update(RENEW, 3, now + 4000);
        assert_eq!(fence.active.as_ref().unwrap().lease, now + 1000);
        assert_eq!(fence.active.as_ref().unwrap().deadline, now + 5000);
        fence.update(RENEW, 2, now + 3000);
        fence.update(RENEW, 2, now + 1000);
        assert_eq!(fence.active.as_ref().unwrap().lease, now + 3000);
    }
}
