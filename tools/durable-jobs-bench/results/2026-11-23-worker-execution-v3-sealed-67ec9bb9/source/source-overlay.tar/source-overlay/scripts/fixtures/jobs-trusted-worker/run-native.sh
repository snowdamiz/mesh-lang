#!/bin/bash
# Run as the same unprivileged account used by the native matrix.
set -euo pipefail
src="${1:?source checkout}"
out="${2:?proof directory}"
export PATH="${PG_BIN_DIR:?pinned PostgreSQL bin}:/usr/bin:/bin"
export LC_ALL=C.UTF-8
umask 077
test "$(id -u)" != 0
db="$(mktemp -d "$out/private.XXXXXX")"
PORT=55431
cleanup() {
    pg_ctl -D "$db/data" -w -t 10 -m fast stop >/dev/null 2>&1 || :
    rm -rf -- "$db"
}
trap cleanup EXIT
mkdir -p "$out/results" "$db/pgsocket"
openssl req -x509 -newkey rsa:2048 -nodes -days 1 -subj /CN=mesh-worker-execution-proof \
    -keyout "$db/ca.key" -out "$out/results/ca.crt" > "$db/openssl.log" 2>&1
openssl req -newkey rsa:2048 -nodes -subj /CN=127.0.0.1 \
    -keyout "$db/server.key" -out "$db/server.csr" >> "$db/openssl.log" 2>&1
printf '%s\n' 'subjectAltName=IP:127.0.0.1' > "$db/server.ext"
openssl x509 -req -in "$db/server.csr" -CA "$out/results/ca.crt" -CAkey "$db/ca.key" \
    -CAserial "$db/ca.srl" -CAcreateserial -days 1 -extfile "$db/server.ext" \
    -out "$db/server.crt" >> "$db/openssl.log" 2>&1
initdb -D "$db/data" -A trust --locale=C --encoding=UTF8 -U postgres
printf '%s\n' 'local all postgres trust' 'hostssl all all 127.0.0.1/32 scram-sha-256' > "$db/data/pg_hba.conf"
pg_ctl -D "$db/data" -w -t 15 -l "$db/postgres.log" -o \
    "-p $PORT -h 127.0.0.1 -k $db/pgsocket -c ssl=on -c ssl_cert_file=$db/server.crt -c ssl_key_file=$db/server.key -c fsync=on -c synchronous_commit=on -c track_commit_timestamp=on" start
test "$(psql -XqAtw -h "$db/pgsocket" -p "$PORT" -U postgres -c 'SHOW server_version_num')" = 170011
secret="$(openssl rand -hex 24)"
printf "ALTER ROLE postgres PASSWORD '%s';\nCREATE DATABASE mesh_jobs_proof;\n" "$secret" |
    psql -XqAtw -h "$db/pgsocket" -p "$PORT" -U postgres -v ON_ERROR_STOP=1 >/dev/null
export MESH_TEST_DATABASE_URL="postgresql://postgres:$secret@127.0.0.1:$PORT/mesh_jobs_proof?sslmode=verify-full&sslrootcert=$out/results/ca.crt"
python3 -Bu "$src/scripts/fixtures/jobs-trusted-worker/prove.py" \
    "$out/results" "$out/trusted-effects" "$out/drop-receipt.so"
