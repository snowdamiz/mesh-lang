#!/usr/bin/env python3
"""Compiled persistent Jobs proof using a private TLS PostgreSQL instance."""

import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "jobs-effect-compiled"))
from prove import Proof, Producer, equal, literal, wait_for

TRUSTED_ARG = b"--mesh-internal-job-trusted-worker-v1"
STRICT_ARG = b"--mesh-internal-job-attempt-effect-v1"


class TrustedProof(Proof):
    def __init__(self, scratch, binary, drop_receipt):
        super().__init__(scratch)
        self.binary = binary
        self.drop_receipt = drop_receipt

    def build(self):
        assert self.binary.is_file()

    def runner_log(self, check):
        return f"{check.__name__}.log"

    def prepare(self):
        super().prepare()
        # Keep the exact compiled application functions as the control, with
        # one label that waits on a proof-owned transaction lock in stage two.
        self.sql("""
            DO $$
            DECLARE definition text;
            BEGIN
                definition := pg_get_functiondef(
                    'compiled_demo.second(text,uuid,bigint,integer,uuid,text)'::regprocedure);
                definition := replace(definition, '    INSERT INTO compiled_demo.effects',
                          $patch$    IF label = 'stop in flight' THEN
        PERFORM pg_advisory_xact_lock(1782495102, 423);
    END IF;
    INSERT INTO compiled_demo.effects$patch$);
                EXECUTE definition;
            END $$;
        """)

    def run(self):
        self.prepare()
        role = "compiled_producer"
        command = ["psql", "-XqAtw", "-v", "ON_ERROR_STOP=1", self.connection(role)]
        env = dict(os.environ, PGPASSWORD=self.passwords[role], PGCONNECT_TIMEOUT="4",
                   PGOPTIONS="-c statement_timeout=4000")
        with subprocess.Popen(command, env=env, stdin=subprocess.PIPE,
                              stdout=subprocess.PIPE, bufsize=0) as producer:
            self.producer_session = Producer(producer)
            try:
                for test in (self.reuse, self.timeout, self.stop_held, self.stop_in_flight,
                             self.stale, self.cancelled, self.crash, self.fail_and_retry,
                             self.unsupported):
                    self.run_compiled(test)
                self.run_compiled(self.frozen_hard_deadline)
                self.env.update(LD_PRELOAD=str(self.drop_receipt),
                                MESH_PROOF_CONTROL_FAULT="stale-generation", MESH_EFFECT_LEASE_MS="1800")
                self.run_compiled(self.frozen_confirmed_lease)
                self.env.update(MESH_PROOF_CONTROL_FAULT="hold-context", MESH_EFFECT_LEASE_MS="60000")
                self.run_compiled(self.expired_before_entry)
                self.env.pop("MESH_PROOF_CONTROL_FAULT")
                self.env.pop("MESH_EFFECT_LEASE_MS")
                self.env["MESH_PROOF_DROP_RECEIPT"] = "1"
                self.run_compiled(self.unknown)
                self.env.pop("MESH_PROOF_DROP_RECEIPT")
                self.env.pop("LD_PRELOAD")
                self.run_compiled(self.recover_unknown)
                self.run_compiled(self.parent_disconnect, expected_exit=-signal.SIGKILL)
            finally:
                producer.terminate()

    def ready(self, owner):
        wait_for((self.path / "ready").exists, "compiled runner ready", owner)
        return wait_for(self.warm_idle, "verified TLS backend under cap five", owner)

    def markdir(self, name):
        directory = self.path / name
        directory.mkdir()
        return directory

    def start(self, owner, name, label="positive", **options):
        directory = self.markdir(name)
        job = self.enqueue(owner, directory, label, **options)
        wait_for((directory / "committed-1").exists, f"{name} first committed receipt", owner)
        return job, directory, self.active_pid(owner)

    def active_pid(self, owner, kind=TRUSTED_ARG):
        workers = [
            pid for pid in self.children(owner)
            if (Path(f"/proc/{pid}/cmdline").read_bytes().split(b"\0")[1:2] == [kind])
        ]
        pid, = workers
        return pid

    def second(self, owner, job, marks, backend):
        self.release(marks, 1)
        wait_for((marks / "committed-2").exists, "second committed receipt", owner)
        rows = self.effects(job)
        equal([row["stage"] for row in rows], [1, 2], "two durable writes")
        equal(len({row["xid"] for row in rows}), 2, "independent XIDs")
        equal({row["backend"] for row in rows}, {backend}, "same genuine TLS session")
        equal(self.warm_idle(), backend, "session reset to idle")
        equal(self.producer(f"SELECT count(*) FROM pg_locks WHERE pid={backend} AND locktype='advisory'"),
              "0", "full reset removed session locks")
        assert self.state(job).startswith("executing:")
        return rows

    @staticmethod
    def release(marks, stage):
        (marks / f"release-{stage}").touch()

    def assert_reaped(self, pid):
        wait_for(lambda: not Path(f"/proc/{pid}").exists(), f"consuming wait for {pid}")

    def completed(self, owner, job, marks, attempt=1):
        self.release(marks, 2)
        wait_for(lambda: self.state(job) == f"completed:{attempt}", "terminal commit", owner)

    def followup(self, owner, name, previous):
        job, marks, pid = self.start(owner, name)
        assert pid != previous
        self.second(owner, job, marks, self.warm_idle())
        self.completed(owner, job, marks)
        return pid

    def reuse(self, owner):
        backend = self.ready(owner)
        equal(self.children(owner), set(), "cold idle has no child")
        job, marks, pid = self.start(owner, "first")
        env = Path(f"/proc/{pid}/environ").read_bytes().split(b"\0")
        allowed = {b"MESH_SCHEDULER_MIN_WORKERS=1", b"MESH_SCHEDULER_MAX_WORKERS=1", b""}
        if self.env.get("MESH_DIAGNOSTIC_JOB_DISABLE_THP") == "1":
            allowed.add(b"MESH_DIAGNOSTIC_JOB_DISABLE_THP=1")
        equal(set(env), allowed, "credential-free executable")
        self.second(owner, job, marks, backend)
        self.completed(owner, job, marks)
        equal(self.children(owner), {pid}, "exact PID retained on success")
        fd_count = len(list(Path(f"/proc/{pid}/fd").iterdir()))
        for sample in range(3):
            job, marks, next_pid = self.start(owner, f"reuse-{sample}")
            equal(next_pid, pid, "same child on sequential claims")
            self.second(owner, job, marks, backend)
            self.completed(owner, job, marks)
            equal(len(list(Path(f"/proc/{pid}/fd").iterdir())), fd_count, "idle has no attempt descriptors")
        marks = self.markdir("unlisted")
        job = self.enqueue(owner, marks, "strict version", version=2)
        wait_for((marks / "committed-1").exists, "strict fallback entered", owner)
        strict_pid = self.active_pid(owner, STRICT_ARG)
        self.second(owner, job, marks, backend)
        self.completed(owner, job, marks)
        self.assert_reaped(strict_pid)
        self.assert_reaped(pid)
        equal(self.children(owner), set(), "strict fallback used the same physical slot cap")
        pid = self.followup(owner, "warm-before-stop", strict_pid)
        (self.path / "stop").touch()
        owner.wait(timeout=5)
        self.assert_reaped(pid)
        print("reuse/idle/fallback: four claims used one PID, two commits each, unlisted version used a fresh child", flush=True)

    def timeout(self, owner):
        self.ready(owner)
        job, marks, pid = self.start(owner, "timeout", timeout_ms=600)
        wait_for(lambda: self.state(job) == "discarded:1", "timed-out terminal commit", owner)
        self.assert_reaped(pid)
        equal([row["stage"] for row in self.effects(job)], [1], "timeout fenced second effect")
        self.followup(owner, "after-timeout", pid)
        print("timeout: blocked handler killed and reaped, replacement completed", flush=True)

    def stop_held(self, owner):
        self.ready(owner)
        job, _, pid = self.start(owner, "stop-held")
        (self.path / "stop").touch()
        owner.wait(timeout=5)
        self.assert_reaped(pid)
        equal(self.state(job), "discarded:1", "held attempt settled after stop")
        equal([row["stage"] for row in self.effects(job)], [1], "held stop allowed only first commit")
        print("stop during hold: child consumed, no second effect", flush=True)

    def stop_in_flight(self, owner):
        backend = self.ready(owner)
        self.producer("SELECT pg_advisory_lock(1782495102, 423)")
        try:
            job, marks, pid = self.start(owner, "stop-in-flight", "stop in flight")
            self.release(marks, 1)
            wait_for(lambda: self.producer(f"""
                SELECT pid FROM pg_locks WHERE pid={backend} AND locktype='advisory'
                AND NOT granted AND objid=423
                """), "second write inside PostgreSQL", owner)
            (self.path / "stop").touch()
            self.assert_reaped(pid)
            owner.wait(timeout=5)
            wait_for(lambda: self.producer(f"SELECT count(*) FROM pg_stat_activity WHERE pid={backend}") == "0",
                     "blocked TLS backend exited before release")
        finally:
            self.producer("SELECT pg_advisory_unlock(1782495102, 423)")
        owner.wait(timeout=5)
        equal(self.state(job), "discarded:1", "stopped in-flight attempt settled")
        equal([row["stage"] for row in self.effects(job)], [1], "in-flight effect rolled back")
        print("stop during in-flight TLS write: child reaped while PostgreSQL lock was held", flush=True)

    def stale(self, owner):
        self.ready(owner)
        job, marks, pid = self.start(owner, "stale")
        self.producer(f"""
            UPDATE mesh_jobs.jobs SET lease_expires_at_ms=0, lease_token=gen_random_uuid()
            WHERE id={literal(job)}::uuid
        """)
        self.release(marks, 1)
        self.assert_reaped(pid)
        equal([row["stage"] for row in self.effects(job)], [1], "old token cannot write stage two")
        report = wait_for(lambda: (status if (status := self.status()).get("stale_acks") == 1 else None),
                          "old token settlement rejected", owner)
        equal(report["finished"], 0, "old attempt had no terminal authority")
        self.followup(owner, "after-stale", pid)
        print("stale/lost lease: prior token could neither write nor settle, replacement completed", flush=True)

    def cancelled(self, owner):
        self.ready(owner)
        job, marks, pid = self.start(owner, "cancelled")
        self.producer(f"UPDATE mesh_jobs.jobs SET cancel_requested_at_ms=mesh_jobs.now_ms() WHERE id={literal(job)}::uuid")
        self.release(marks, 1)
        wait_for(lambda: self.state(job) == "cancelled:1", "durable cancellation", owner)
        self.assert_reaped(pid)
        equal([row["stage"] for row in self.effects(job)], [1], "cancelled claim denied stage two")
        print("cancel: revoked token's next SQL and settled cancellation", flush=True)

    def crash(self, owner):
        self.ready(owner)
        job, _, pid = self.start(owner, "crash")
        os.kill(pid, signal.SIGKILL)
        wait_for(lambda: self.state(job) == "discarded:1", "crash terminal commit", owner)
        self.assert_reaped(pid)
        equal([row["stage"] for row in self.effects(job)], [1], "crashed handler cannot write")
        self.followup(owner, "after-crash", pid)
        print("crash: exact PID reaped before replacement", flush=True)

    def fail_and_retry(self, owner):
        backend = self.ready(owner)
        marks = self.markdir("explicit-fail")
        failed = self.enqueue(owner, marks, "explicit failure")
        wait_for(lambda: self.state(failed) == "discarded:1", "explicit failure", owner)
        equal(self.effects(failed), [], "failure issued no calls")
        equal(self.children(owner), set(), "business failure retired its child")
        marks = self.markdir("explicit-retry")
        # Pre-release two holds so both attempts can reach the ordinary return.
        self.release(marks, 1)
        self.release(marks, 2)
        job = self.enqueue(owner, marks, "explicit retry", max_attempts=2)
        wait_for(lambda: self.state(job) == "completed:2", "business retry completion", owner)
        rows = self.effects(job)
        equal([(r["stage"], r["job_attempt"]) for r in rows], [(1, 1), (2, 1)], "retry kept the original commits")
        equal({r["backend"] for r in rows}, {backend}, "retry retained reset TLS session")
        print("fail/retry: ordinary Mesh outcome and idempotent durable attempts", flush=True)

    def unsupported(self, owner):
        backend = self.ready(owner)
        marks = self.markdir("unsupported")
        job = self.enqueue(owner, marks, "unsupported actor", max_attempts=2)
        wait_for((marks / "committed-1").exists, "strict retry admitted after unsupported spawn", owner)
        equal(self.state(job), "executing:2", "no transparent replay of the first attempt")
        pid = self.active_pid(owner, STRICT_ARG)
        self.second(owner, job, marks, backend)
        self.completed(owner, job, marks, 2)
        self.assert_reaped(pid)
        print("unsupported actor: worker version fell back on next durable attempt", flush=True)

    @staticmethod
    def proc_state(pid):
        try:
            return Path(f"/proc/{pid}/stat").read_text().rsplit(")", 1)[1].split()[0]
        except FileNotFoundError:
            return None

    def spin(self, owner, directory, label, timeout_ms):
        job = self.enqueue(owner, directory, label, timeout_ms=timeout_ms)
        wait_for((directory / "spinning").exists, "CPU-bound handler entered", owner)
        return job, self.active_pid(owner)

    def frozen_hard_deadline(self, owner):
        self.ready(owner)
        marks = self.markdir("hard-deadline")
        job, pid = self.spin(owner, marks, "frozen hard deadline", 1100)
        owner.send_signal(signal.SIGSTOP)
        try:
            wait_for(lambda: self.proc_state(owner.pid) == "T", "supervisor stopped")
            wait_for(lambda: self.proc_state(pid) == "Z", "child watchdog expired hard deadline")
            equal(self.state(job), "executing:1", "frozen supervisor did not settle")
            equal([r["stage"] for r in self.effects(job)], [1], "hard expiry after first effect")
        finally:
            owner.send_signal(signal.SIGCONT)
        self.assert_reaped(pid)
        wait_for(lambda: self.state(job) == "discarded:1", "timeout settled after restart", owner)
        reason = self.producer(f"SELECT errors->0->>'reason' FROM mesh_jobs.jobs WHERE id={literal(job)}::uuid")
        equal(reason, "job handler timed out", "hard watchdog exit classification")
        print("frozen supervisor: CPU-bound child independently expired its hard deadline", flush=True)

    def frozen_confirmed_lease(self, owner):
        backend = self.ready(owner)
        first_job, marks, reused = self.start(owner, "warm-for-lease")
        self.second(owner, first_job, marks, backend)
        self.completed(owner, first_job, marks)
        time.sleep(1.9)
        equal(self.proc_state(reused), "S", "previous generation expired while healthy worker was idle")

        marks = self.markdir("confirmed-lease")
        job, pid = self.spin(owner, marks, "frozen confirmed lease", 20_000)
        equal(pid, reused, "short-lease proof actually reused the worker")
        scope = f"WHERE id={literal(job)}::uuid"
        def expiry():
            return int(self.producer(f"SELECT lease_expires_at_ms FROM mesh_jobs.jobs {scope}"))
        initial = expiry()
        wait_for(lambda: expiry() >= initial + 1000, "durably confirmed renewal", owner)
        # Let the dispatcher deliver the confirmed lease, then freeze all its threads.
        time.sleep(0.12)
        owner.send_signal(signal.SIGSTOP)
        try:
            wait_for(lambda: self.proc_state(owner.pid) == "T", "lease supervisor stopped")
            confirmed = expiry()
            assert confirmed >= initial + 1000
            wait_for(lambda: int(self.producer("SELECT mesh_jobs.now_ms()")) > initial + 50,
                     "prior confirmed lease expired")
            assert self.proc_state(pid) in {"R", "S"}, "renewal did not extend the live current generation"
            wait_for(lambda: self.proc_state(pid) == "Z", "latest confirmed lease independently expired")
            equal(self.state(job), "executing:1", "frozen supervisor did not settle expired lease")
            equal([r["stage"] for r in self.effects(job)], [1], "expired child issued no second write")
        finally:
            owner.send_signal(signal.SIGCONT)
        self.assert_reaped(pid)
        self.followup(owner, "after-confirmed-lease", pid)
        print("frozen supervisor: reused PID ignored stale LIMIT/RENEW, honored current confirmed lease", flush=True)

    def expired_before_entry(self, owner):
        self.ready(owner)
        marks = self.markdir("pre-entry")
        job = self.enqueue(owner, marks, "did not enter", timeout_ms=450)
        pid = wait_for(lambda: next(iter(self.children(owner)), None), "worker received assignment", owner)
        wait_for(lambda: self.proc_state(pid) == "Z", "deadline elapsed before context transmission")
        self.assert_reaped(pid)
        wait_for(lambda: self.state(job) == "discarded:1", "pre-entry deadline settled", owner)
        equal(list(marks.iterdir()), [], "handler never entered")
        equal(self.effects(job), [], "no effect before entry")
        print("pre-entry expiry: child watchdog armed on receipt before context read", flush=True)

    def unknown(self, owner):
        self.ready(owner)
        job, marks, pid = self.start(owner, "unknown", max_attempts=2)
        self.release(marks, 1)
        wait_for(lambda: self.state(job) == "retryable:1", "unknown receipt settlement", owner)
        self.assert_reaped(pid)
        self.unknown_rows = self.effects(job)
        self.unknown_job = job
        equal([row["stage"] for row in self.unknown_rows], [1, 2], "both PG commits survived lost receipt")
        equal((marks / "committed-2").exists(), False, "worker received no second receipt")
        equal(len({row["xid"] for row in self.unknown_rows}), 2, "independent uncertain commit")
        (marks / "committed-1").unlink()
        print("unknown: second receipt dropped after its SQL commit and reset, child reaped", flush=True)

    def recover_unknown(self, owner):
        backend = self.ready(owner)
        marks = self.path / "unknown"
        wait_for((marks / "committed-2").exists, "replacement handled prior committed write", owner)
        equal(self.effects(self.unknown_job), self.unknown_rows, "replacement did not duplicate writes")
        equal(self.warm_idle(), backend, "replacement session clean")
        self.completed(owner, self.unknown_job, marks, 2)
        print("unknown retry: prior commits kept their exact XIDs", flush=True)


if __name__ == "__main__":
    scratch, binary, fault = map(lambda raw: Path(raw).resolve(), sys.argv[1:])
    TrustedProof(scratch, binary, fault).run()
