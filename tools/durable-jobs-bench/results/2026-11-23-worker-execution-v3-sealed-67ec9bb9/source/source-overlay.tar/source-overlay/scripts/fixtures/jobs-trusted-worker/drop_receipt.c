/* Proof-only: drop the second confirmed Unix receipt after PostgreSQL reset. */
#define _GNU_SOURCE
#include <dlfcn.h>
#include <errno.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/socket.h>

ssize_t send(int fd, const void *data, size_t size, int flags) {
    static _Atomic unsigned confirmed;
    if (getenv("MESH_PROOF_DROP_RECEIPT") &&
        flags == (MSG_DONTWAIT | MSG_NOSIGNAL) && size == 1 &&
        *(const unsigned char *)data == 1) {
        struct sockaddr_storage address;
        socklen_t length = sizeof address;
        if (getsockname(fd, (struct sockaddr *)&address, &length) == 0 &&
            address.ss_family == AF_UNIX && atomic_fetch_add(&confirmed, 1) == 1) {
            errno = EPIPE;
            return -1;
        }
    }
    ssize_t (*original)(int, const void *, size_t, int) = dlsym(RTLD_NEXT, "send");
    return original(fd, data, size, flags);
}

ssize_t sendmsg(int fd, const struct msghdr *message, int flags) {
    ssize_t (*original)(int, const struct msghdr *, int) = dlsym(RTLD_NEXT, "sendmsg");
    ssize_t sent = original(fd, message, flags);
    const char *fault = getenv("MESH_PROOF_CONTROL_FAULT");
    if (!fault || sent != 25 || message->msg_iovlen != 1 ||
        message->msg_iov[0].iov_len != 25 || !message->msg_control)
        return sent;
    const unsigned char *body = message->msg_iov[0].iov_base;
    if (body[0] != 1) return sent;
    if (body[1] == 1 && strcmp(fault, "hold-context") == 0) {
        const struct timespec wait = { .tv_sec = 2, .tv_nsec = 0 };
        nanosleep(&wait, NULL);
    }
    if (body[1] == 2 && strcmp(fault, "stale-generation") == 0) {
        unsigned char stale[25] = { 3, 1 }; /* LIMIT generation 1 at boot time 0 */
        struct iovec data = { stale, sizeof stale };
        struct msghdr update = { .msg_iov = &data, .msg_iovlen = 1 };
        if (original(fd, &update, flags) != 25) abort();
        stale[0] = 2;
        memset(stale + 9, 255, 8); /* RENEW generation 1 forever */
        if (original(fd, &update, flags) != 25) abort();
    }
    return sent;
}
