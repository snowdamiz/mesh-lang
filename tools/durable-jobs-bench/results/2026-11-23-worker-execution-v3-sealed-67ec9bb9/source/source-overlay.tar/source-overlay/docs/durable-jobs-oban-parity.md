# Durable Jobs and Oban parity plan

Bring Mesh Jobs up to Oban 2.24.2 Core for PostgreSQL-backed applications. Preserve transactional enqueue, retries within the attempt budget, renewable claim fencing, isolated worker termination, and database-wide admission limits.

PRs #37 and #38 are the starting implementation on main. J1 through J7 compare Mesh Jobs with pinned main and Oban Basic. Track other database engines and Oban Pro features as separate targets.

Commands, implemented behavior, and recorded qualification results are in the [PostgreSQL Jobs evidence guide](durable-jobs-parity-evidence.md).
The [compiled lane receipts](durable-jobs-parity-evidence.md#compiled-lane-receipts)
give the tested platform, PostgreSQL version, and assertion for the checked macOS lanes.

## How to read this

One box is one unit of work. Each box names the evidence that checks it. Check a box only when its evidence exists. Use `playbooks/orchestrate.md` if the program is assigned across several PRs, or execute the graph one PR at a time. Future implementation PRs follow the merge instructions authorized for that run.

Tests alone are not sufficient verification. A PR is verified only when its unit, live, and perf boxes are all checked.

### First release scope

Qualify PostgreSQL 17, 18, and 19 on Linux and macOS. Record the tested patch versions. Add Windows to the matrix only after the compiled timeout, parent-death, and recovery suite passes there. Publish functional parity only after J7. Publish throughput claims per measured workload.

| Oban PostgreSQL workflow | Mesh contract and expected difference | Phase and required proof |
| --- | --- | --- |
| Transactional single and bulk enqueue | Keep `Jobs.enqueue_in` on the caller's connection and preserve request-key receipts. | J1 and J7. Commit and rollback a batch with a business write. Verify replay with the same request identity. |
| Uniqueness and replacement | Preserve field, key, state, window, and replacement policy. An active attempt keeps its claimed context, token, worker, queue, and schedule. Allowed field edits affect stored state and later attempts, including settlement decisions that consult the row. | J6 and J7. Race a duplicate insert and an allowed replace against an active attempt. |
| Scheduled and recurring work | Preserve due times, cron cursor commits, and missed-occurrence policies. | J3 and J6. Prove pickup after a missed wakeup and takeover after the cron owner dies. |
| Snooze, retry, and exhaustion | Automatic retry keeps the effect key. Snooze preserves the attempt budget. An operator retry of terminal work starts a new run with a new effect key. | J5 through J7. Assert due times, observed attempts, terminal states, and the old and new effect keys. |
| Cancellation and crash recovery | Committed cancellation takes precedence over settlement. Renewable tokens fence old attempts and scheduled recovery preserves the retry budget. | J2 and J7. Lose a worker or an acknowledgement, race cancellation, and inspect both durable state and effects. |
| Queue controls and concurrency | Keep namespace-wide limits on active claims and add per-runner controls. | J2 and J6. Race multiple workers and verify both scopes during queue shutdown and node loss. |
| Testing and bounded drain | Provide manual assertions, test-only direct invocation, and real PostgreSQL drain with an explicit budget and cutoff. | J5. Prove transactional visibility, namespace isolation, cutoff, exhaustion, and error policy. |
| Telemetry and maintenance | Report confirmed lifecycle outcomes and bounded maintenance work without exposing job payloads by default. | J4 and J6. Verify commit ordering, subscriber backpressure, receipt replay after pruning, and index maintenance under traffic. |

The workflow matrix follows the pinned Oban API and uniqueness guide. Execution models and effect-idempotency rules remain specific to each engine. [Oban 2.24.2 API](https://oban.hexdocs.pm/Oban.html) · [Oban uniqueness](https://oban.hexdocs.pm/2.24.2/unique_jobs.html)

## Program checklist

### Arm the program

- [ ] Read the plan, the documented Jobs API, and the current comparison links with `cat <plugin root>/skills/poteto-mode/playbooks/orchestrate.md` available for a coordinated run.
- [ ] Record the current main SHA, the owner for each active PR, and the actual PostgreSQL server versions. If the operator requests an automated audit, use an hourly schedule_task and post a status message only for a changed verdict, check, or blocker.

### Spawn owners

- [ ] Start J1 first. J2, J4, and J5 may follow independently. Start J3 and J6 after J2. Start J7 once J2 through J6 pass.
- [ ] Keep changes to shared Jobs dispatch, store, and runtime files in separate commits. Coordinate integration if independent PRs touch the same paths.

### PR mechanics

- [ ] Base each implementation PR on current main or its explicit dependency. Verify the diff before asking for review.
- [ ] Run the smallest behavior test while iterating. Before presenting the PR, run the applicable workspace and proof gates from `AGENTS.md`.
- [ ] Record each benchmark configuration before measuring and attach the raw samples to the PR evidence.

### Verdict and merge

- [ ] Obtain an independent verdict for the exact reviewed head. Exercise the compiled API and PostgreSQL transaction boundaries where the PR changes runtime behavior.
- [ ] Merge in dependency order after the current checks and reviews pass. Re-run verification where a rebase or a change of base alters behavior.

### Boot recipe

- [ ] Check out the pinned head in its own worktree. Run `bash scripts/verify-postgres-jobs.sh` for the standard proof. Use `--compatibility 18.7` or `--compatibility 19.0` for the versioned matrix.
- [ ] For load and fault scenarios, have the workload driver start its own disposable database and run both compiled fixtures. Require a freshly created database and a driver-owned nonce before kill, disconnect, or failover injection. Use a second connection for independent observation.
- [ ] Save each lane's command output and database evidence under `target/jobs-parity/<head>/<lane>/`. Shut down PostgreSQL and remove its temporary state.

Run the current proof with the matching PostgreSQL binaries on `PATH` or in `PG_BIN_DIR`. Replace the example installation paths with local paths. These commands clear connection overrides so the script creates a disposable cluster. The local fixture's bootstrap role can create that cluster. The role verification runs workers under separately scoped grants. [Authoritative verification workflow](../.github/workflows/authoritative-verification.yml)

```sh
env -u MESH_TEST_DATABASE_URL -u MESH_JOBS_TEST_PG_URL \
  PG_BIN_DIR=/path/to/postgresql-18.7/bin \
  bash scripts/verify-postgres-jobs.sh --compatibility 18.7
env -u MESH_TEST_DATABASE_URL -u MESH_JOBS_TEST_PG_URL \
  PG_BIN_DIR=/path/to/postgresql-19.0/bin \
  bash scripts/verify-postgres-jobs.sh --compatibility 19.0
```

## Measure the current queue against Oban (J1)

**Depends on.** The hard-timeout and runner-reliability stack in PRs #37 and #38.

**Files.**

- [x] Extend `scripts/verify-postgres-jobs.sh` and add a separate load and fault driver under `scripts/`.
- [x] Reuse `compiler/meshc/tests/e2e_durable_jobs.rs` and `tests/e2e/durable_jobs/main.mpl` for compiled scenarios. Keep the Oban comparison fixture pinned to `2.24.2` with its lockfile.

**Build.**

- [x] Each manifest pins the Mesh source, Oban, Erlang, PostgreSQL, runner settings, host, and seed. The historical `db606548` and `59f6a7b3` replays use isolated databases on the same host and cover the one-runner, 16-slot short and sparse profiles. [Reference receipts](../proof/jobs-parity/qualification-v1.json)
- [x] Both engines use the same slot allocations, inputs, transaction boundaries, and fault barriers. Pickup includes Mesh's per-attempt process startup. [Fixture interface](../tests/e2e/durable_jobs/parity-interface.md) · [Load receipt](../proof/jobs-parity/j7-lane-10.log)
- [x] The release comparison covers all 35 frozen profiles with a warmup and five alternating pairs per profile. It includes short, 100 ms, and sparse workloads and separate no-op and 512 KiB stress cases. [Load receipt](../proof/jobs-parity/j7-lane-10.log)
- [x] The frozen profiles fix slot allocation, pool, notifier, and maintenance settings and the absolute sparse pickup budget. The driver measures pickup from the enqueue transaction's durable commit to first handler entry. It records claim and settlement timestamps separately and rejects samples outside the clock tolerance. [Profiles](../scripts/jobs-parity-profiles.json) · [Measurement guide](durable-jobs-parity-evidence.md)
- [x] The same frozen connection, process, and thread budgets apply to both engines. The driver counts Mesh worker processes and the Oban VM and reports idle and busy samples. The relative CPU and peak RSS limits are 1.25 and 1.5 times Oban. [Profiles](../scripts/jobs-parity-profiles.json)
- [ ] Keep raw executions separate from deduplicated effects. Capture fault placement and reconcile each engine under its configured recovery rules. Install a barrier to kill or disconnect on an observed claim, write, or acknowledgement. Run the compiled commit, rollback, clean exit, and crash-recovery baseline on Linux and macOS before optimizing. Add native-call timeout on both and executable replacement on macOS.
  The paired Linux and macOS recovery receipts use the same pinned
  pre-optimization Mesh runtime. The hosted Linux run came after
  optimization work began. [Paired recovery evidence](../proof/jobs-parity/j1-paired-linux-recovery-v1.json)

**You see.**

- [x] A repeatable command produces a manifest and machine-readable evidence for both engines, with test failure distinguished from a queue defect.

**Verify, unit.** Tests alone are not sufficient verification. A PR is verified only when its unit, live, and perf boxes are all checked.

- [x] Test fixture data equality, monotonic latency accounting, percentiles, and rejection of missing or mismatched samples. Run the driver self-check and `bash scripts/verify-postgres-jobs.sh`.

**Verify, live.** Tests alone are not sufficient verification. A PR is verified only when its unit, live, and perf boxes are all checked. Ten lanes on `gpt-6.2-sol high` at the PR head using the compiled fixtures and the PostgreSQL boot recipe.

- [x] Lane 1. Regression lane against main. Run the existing transaction and recovery proof on main and head. Save `j1-lane-1.log`. Pass when the added driver reports the same persisted effects.
- [x] Lane 2. PostgreSQL 17.11 passed the compiled transaction, claims, settlements, and recovery suites on Linux arm64 and macOS arm64 over verified TLS with SCRAM. [Receipt](../proof/jobs-parity/j1-postgres-matrix.log)
- [x] Lane 3. PostgreSQL 18.7 passed the same suites and authentication checks on both platforms. [Receipt](../proof/jobs-parity/j1-postgres-matrix.log)
- [x] Lane 4. PostgreSQL 19.0 passed the same suites and authentication checks on both platforms. [Receipt](../proof/jobs-parity/j1-postgres-matrix.log)
- [x] Lane 5. Run the Oban Basic fixture twice with the same seed. Save `j1-lane-5.log`. Pass when the derived inputs and total job counts match.
- [x] Lane 6. The seven sparse profiles reconciled all 840 jobs per engine after runner shutdown. The receipt records the resource and pickup misses separately. [Sparse receipt](../proof/jobs-parity/j1-lane-6.log)
- [x] Lane 7. Run the matched dense workload. Save `j1-lane-7.log`. Pass when the run records occupancy and all completed jobs.
- [x] Lane 8. Kill a worker after its claim and before settlement. Save `j1-lane-8.log`. Pass when the same job identity is recovered and the old token cannot settle it.
- [x] Lane 9. Lose an acknowledgement on both sides of commit. Save `j1-lane-9.log`. Pass when the final persisted state accounts for each attempt.
- [x] Lane 10. Run a rolled-back enqueue and a duplicate effect. Save `j1-lane-10.log`. Pass when the rollback produces zero effects and the effect key deduplicates the retry.

**Verify, perf.** Tests alone are not sufficient verification. A PR is verified only when its unit, live, and perf boxes are all checked.

- [x] Metric. Each profile reports throughput, pickup p99, SQL calls per job, and idle queries per minute. [Load receipt](../proof/jobs-parity/j7-lane-10.log)
- [x] Probe. Main and candidate each completed five paired trials per frozen profile with identical input files. The archive contains the saved rows and samples. [Main comparison](../proof/jobs-parity/j7-lane-1.log) · [Raw archive](../proof/jobs-parity/matched-workload-samples-v1.tar.xz)
- [x] Baseline. The main comparison and the separate Oban comparison used the same host, PostgreSQL patch, and frozen settings. The receipts pin the harness used by each arm. [Main comparison](../proof/jobs-parity/j7-lane-1.log) · [Oban comparison](../proof/jobs-parity/j7-lane-10.log)
- [x] Rule. The load driver requires five valid pairs with complete metrics. The current harness rejects statement-counter eviction. The original main comparison recorded positive SQL counts before that check was added. [Measurement guide](durable-jobs-parity-evidence.md)

**Review gate.** None. This phase has no graphical interaction. Independent review uses the CLI receipts and database proof.

**Merge.**

- [ ] Land J1 after its dependencies and exact-head checks pass. Record the SHA and evidence in the program receipt.

## Batch claims and protect lease progress (J2)

**Depends on.** J1.

**Files.**

- [x] Edit `compiler/mesh-rt/src/jobs/schema.sql`, `compiler/mesh-rt/src/jobs/store.rs`, and `compiler/mesh-rt/src/jobs/runner.rs`.
- [x] Extend `compiler/mesh-rt/src/jobs/store_tests.rs` and `compiler/mesh-rt/src/jobs/runner_tests.rs` with batch and failure tests.

**Build.**

- [x] Add a versioned `claim_batch` entry point. Under one `READ COMMITTED` transaction, take the queue admission lock once, measure global headroom, and select the ordered `SKIP LOCKED` candidates by priority, schedule, and position. Limit the result by local reserved slots, global headroom, and an initial quantum of 16, then rotate queues. Document that continuous higher-priority arrivals can delay lower-priority work in the same queue.
- [x] Return one PostgreSQL row per attempt. Enforce per-context and total reply byte budgets before creating claims, because JSONB can expand a small enqueue into a large context. Start with the existing 16 MiB per-column ceiling and a 32 MiB total reply budget under the driver's 64 MiB result cap. Expose an oversized-context error that does not block valid work behind it.
- [x] Dispatch only after confirmed commit. Recover ambiguous claims by lease and refund only confirmed unstarted claims. Preserve attempt accounting, effect keys, cancellation priority, and stale-token fencing. Keep the original SQL entry points, bodies, and role grants available during upgrades. [Claim faults and owner replay](../proof/jobs-parity/rolling-upgrade-v2.json)
- [x] Give renewal and settlement bounded database access independent of claim traffic. Reserve capacity or use bounded independent I/O so that a slow claim or a locked row does not stop another queue's renewals. Retain the per-attempt process until measurements justify a different lifetime design.

**You see.**

- [x] A ready backlog fills available slots in bounded batches. A sparse eligible queue gets service on its next turn when it has available capacity.

**Verify, unit.** Tests alone are not sufficient verification. A PR is verified only when its unit, live, and perf boxes are all checked.

- [x] Cover capacity, SQL result size, ordered prefixes, queue rotation, unstarted refunds, and same-token retries. Run `bash scripts/verify-postgres-jobs.sh`.

**Verify, live.** Tests alone are not sufficient verification. A PR is verified only when its unit, live, and perf boxes are all checked. Ten lanes on `gpt-6.2-sol high` at the PR head using the compiled fixtures and the PostgreSQL boot recipe.

- [x] Lane 1. Five paired trials per short-job profile reconciled all 20,480 job IDs, attempts, and effects across main and candidate. The receipt records each profile's claim-call budget separately. [Receipt index](../proof/jobs-parity/qualification-v1.json)
- [x] Lane 2. Race four compiled runners on a queue at capacity. Save `j2-lane-2.log`. Pass when claims never exceed the configured global cap.
- [x] Lane 3. Pause and scale during a batch. Save `j2-lane-3.log`. Pass when no new claims bypass the committed queue control.
- [x] Lane 4. Hold one row through renewals and acknowledgements. Save `j2-lane-4.log`. Pass when an unrelated attempt completes on its first lease.
- [x] Lane 5. Inject a blocked claim transport with separate renewal capacity. Save `j2-lane-5.log`. Pass when the active peer keeps its lease.
- [x] Lane 6. Inject lost claim responses before and after commit. Save `j2-lane-6.log`. Pass when the runner launches only confirmed claims and recovery handles ambiguous rows.
- [x] Lane 7. Fail a child launch partway through a batch, then kill the runner during a separate startup whose result is uncertain. Save `j2-lane-7.log`. Pass when only proven unstarted rows get refunds, held slots return, uncertain rows recover under a new token, and the runner never launches twice or settles stale with the old token.
- [x] Lane 8. Mix large and small contexts in a backlog. Save `j2-lane-8.log`. Pass when every successful reply stays within the byte budget and oversized input does not block the queue.
- [x] Lane 9. Both binaries processed eligible jobs under scoped grants on all three macOS PostgreSQL versions. Owner replay preserved the catalog, original function definitions and grants, and namespace pause. [Receipt](../proof/jobs-parity/rolling-upgrade-v2.json)
- [x] Lane 10. Burden a busy queue while a sparse queue becomes due. Save `j2-lane-10.log`. Pass when the sparse queue claims on its next available rotation.

Run lane 7 on macOS after checking out the proof commit. Set `PG_BIN_DIR`
to the chosen PostgreSQL installation if it is outside the shell's path.

```bash
python3 scripts/jobs-parity.py --j2-lane-7 --mesh-batch --mesh-ref "$(git rev-parse HEAD)"
```

The driver prints its evidence directory and writes `j2-lane-7.log` after
both cases pass. The lane build enables a fixture-only gate at the second
OS spawn call and a gate at the existing native worker-start marker.

**Verify, perf.** Tests alone are not sufficient verification. A PR is verified only when its unit, live, and perf boxes are all checked.

- [x] Metric. The paired trials record claim round trips, throughput, and pickup p99. The compiled mixed-size case records a 25,166,688-byte peak of queued contexts. [Lane receipts](durable-jobs-parity-evidence.md#compiled-lane-receipts)
- [x] Probe. The main and candidate matrix interleaves dense and sparse profiles. Batching is enabled on the candidate. [Matrix receipt](../proof/jobs-parity/j7-lane-1.log)
- [x] Baseline. Main uses one-row claims with identical concurrency. Batch dispatch is opt-in on the candidate. [Matrix receipt](../proof/jobs-parity/j7-lane-1.log)
- [x] Rule. Release `9bd80627` used 73.8% fewer claim calls per job on the dense reference. All seven sparse profiles met the 1.10× pickup p99 limit against pinned main. The compiled mixed-size proof observed 25,166,688 queued context bytes against the 32 MiB reply limit. Earlier misses remain in the evidence. [Reruns and limits](durable-jobs-parity-evidence.md#batch-comparison-against-pinned-main) · [Raw trials](../proof/jobs-parity/j2-batch-qualification-9bd80627.tar.xz)

**Review gate.** None. This phase has no graphical interaction. Independent review uses the CLI receipts and database proof.

**Merge.**

- [ ] Land J2 after its dependencies and exact-head checks pass. Record the SHA and evidence in the program receipt.

## Wake workers after database commits (J3)

**Depends on.** J1 and J2.

**Files.**

- [x] Edit `compiler/mesh-rt/src/db/pg.rs`, `compiler/mesh-rt/src/db/jobs_connection.rs` and `compiler/mesh-rt/src/jobs/runner.rs`.
- [x] Extend `compiler/mesh-rt/src/jobs/schema.sql` and the compiled PostgreSQL fixtures.

**Build.**

- [x] Decode PostgreSQL asynchronous notification frames on a dedicated, interruptible session. Reuse the existing TLS and SCRAM transport. Keep partial reads framed across wakeups and prevent the listener from occupying a lease or settlement pool slot.
- [x] Commit `LISTEN` before the initial catch-up scan. Repeat that order on reconnect and after failover. Coalesce namespace and queue hints without including payloads or claim tokens. Treat hints as a reason to read authoritative rows.
- [x] Wake on committed enqueue and queue resume, and use due-time timers for scheduled or retryable jobs. Keep jittered fallback polling for outages, missed hints, and transaction poolers. Make transactional publishing opt-in until commit coupling and resource use pass the gate. Document that PostgreSQL can reject a commit if its notification queue is full.
- [x] Make the subscription and shutdown path release its session within the runner's shutdown budget. Define a poll-only setting and document connection cost.

**You see.**

- [x] A remote runner picks up newly committed work without waiting for the configured fallback poll. With notifications disabled, the same job still completes through polling.

**Verify, unit.** Tests alone are not sufficient verification. A PR is verified only when its unit, live, and perf boxes are all checked.

- [x] Cover partial and coalesced wire frames, reconnect order, subscription fallback, and bounded wake queues. Run the PostgreSQL driver tests and `bash scripts/verify-postgres-jobs.sh`.

**Verify, live.** Tests alone are not sufficient verification. A PR is verified only when its unit, live, and perf boxes are all checked. Ten lanes on `gpt-6.2-sol high` at the PR head using the compiled fixtures and the PostgreSQL boot recipe.

- [x] Lane 1. Regression lane against main. Run the sparse queue workload on main and head. Save `j3-lane-1.log`. Pass when both run the committed job and head also records its wake source.
- [x] Lane 2. Enqueue in a transaction and delay commit. Save `j3-lane-2.log`. Pass when the worker sees no job until commit.
- [x] Lane 3. Roll back a transaction with enqueue. Save `j3-lane-3.log`. Pass when there is no execution or committed notification.
- [x] Lane 4. Resume a paused queue from a second process. Save `j3-lane-4.log`. Pass when the eligible work wakes the configured worker.
- [x] Lane 5. Schedule work with no fresh enqueue. Save `j3-lane-5.log`. Pass when the due-time path claims it on schedule.
- [x] Lane 6. Interrupt the listener before an enqueue. Save `j3-lane-6.log`. Pass when fallback polling picks up the job.
- [x] Lane 7. Commit during listener reconnect. Save `j3-lane-7.log`. Pass when the resubscribe scan sees the job.
- [x] Lane 8. Split and interleave notification frames over the test transport. Save `j3-lane-8.log`. Pass when the listener sees valid hints and handles invalid frames without corrupting query state.
- [x] Lane 9. Use a transaction pooler or poll-only mode. Save `j3-lane-9.log`. Pass when jobs process without a held listener session.
- [x] Lane 10. Stop an idle runner with an active listener. Save `j3-lane-10.log`. Pass when its session is released and the process exits within its shutdown budget.

**Verify, perf.** Tests alone are not sufficient verification. A PR is verified only when its unit, live, and perf boxes are all checked.

- [x] Metric. Commit-to-claim p99 and idle SQL queries per minute.
- [x] Probe. Five pairs of the frozen sparse profile ran with a 1 s fallback poll. The worst disconnected pickup was 872 ms and the worst healthy trial commit-to-claim p99 was 13.3 ms. [Listener outage receipt](durable-jobs-parity-evidence.md#measure-fallback-with-the-listener-disconnected)
- [x] Baseline. Five paired trials against pinned main at each cadence, 250 ms and 1 s. [Receipt index](../proof/jobs-parity/qualification-v1.json)
- [x] Rule. The listener met the 100 ms healthy p99 and 2-second fallback limits. It used 62.3% fewer idle queries than main at the 250 ms default. [Receipt index](../proof/jobs-parity/qualification-v1.json)

**Review gate.** None. This phase has no graphical interaction. Independent review uses the CLI receipts and database proof.

**Merge.**

- [ ] Land J3 after its dependencies and exact-head checks pass. Record the SHA and evidence in the program receipt.

## Publish job lifecycle events (J4)

**Depends on.** J1. This can run in parallel with dispatch work.

**Files.**

- [x] Edit `compiler/mesh-rt/src/jobs/runner.rs`, `compiler/mesh-rt/src/jobs/store.rs`, and `compiler/mesh-rt/src/jobs/mod.rs`.
- [x] Add the event reader or subscriber API through the Jobs compiler and REPL bindings. Update `website/docs/docs/concurrency/index.md`.

**Build.**

- [x] Add a versioned event envelope for runner start and stop, attempt start, committed settlement, lost lease, stale or uncertain acknowledgement, storage failures, and maintenance. Include job and attempt identities in events. Keep them out of metric labels.
- [x] Report queue wait, handler duration, and bounded failure kinds. Reuse the database-confirmed settlement enum so a retry at exhaustion appears as discarded and a concurrent operator cancellation wins. Keep existing `outcomes` and `stale_acks` counts.
- [x] Isolate event delivery with a bounded buffer and dropped-event counter. A slow, failing, or absent consumer must leave leases and shutdown responsive. Provide an opt-in JSON logger and a programmatic reader or subscriber. Omit args, metadata, credentials, and lease tokens by default.
- [x] Document which events reflect an observed commit. An ambiguous network response produces an uncertainty event and cannot fabricate a committed result.

**You see.**

- [x] An application can trace why a job retried or stopped from structured events and can detect a saturated event consumer.

**Verify, unit.** Tests alone are not sufficient verification. A PR is verified only when its unit, live, and perf boxes are all checked.

- [x] Test event schemas, privacy, same-token retries, and subscriber overflow. Run Jobs tests plus compiler, REPL, and compiled API coverage for the public binding.

**Verify, live.** Tests alone are not sufficient verification. A PR is verified only when its unit, live, and perf boxes are all checked. Ten lanes on `gpt-6.2-sol high` at the PR head using the compiled fixtures and the PostgreSQL boot recipe.

- [x] Lane 1. Regression lane against main. Compare default behavior on main and head under the same job stream. Save `j4-lane-1.log`. Pass when with telemetry off, both leave the same durable results.
- [x] Lane 2. Complete a healthy attempt. Save `j4-lane-2.log`. Pass when the terminal event follows the durable completion.
- [x] Lane 3. Request a retry on the last attempt. Save `j4-lane-3.log`. Pass when the event reports discard.
- [x] Lane 4. Race operator cancellation and handler success. Save `j4-lane-4.log`. Pass when the terminal event reports cancellation.
- [x] Lane 5. Inject a stale token. Save `j4-lane-5.log`. Pass when only the stale acknowledgement indicator changes.
- [x] Lane 6. Drop a commit reply. Save `j4-lane-6.log`. Pass when an uncertainty event appears without a duplicate terminal disposition.
- [x] Lane 7. Run a cron tick and expired claim recovery. Save `j4-lane-7.log`. Pass when both maintenance events identify the action and their counts.
- [x] Lane 8. Use an intentionally blocked subscriber. Save `j4-lane-8.log`. Pass when the drop count advances while lease renewal and other queues continue.
- [x] Lane 9. Enqueue synthetic sensitive arguments and metadata. Save `j4-lane-9.log`. Pass when default output contains none of those values.
- [x] Lane 10. Stop a runner with subscribers attached. Save `j4-lane-10.log`. Pass when subscribers terminate cleanly and shutdown progress is observable.

**Verify, perf.** Tests alone are not sufficient verification. A PR is verified only when its unit, live, and perf boxes are all checked.

- [x] Metric. The dense telemetry trials record throughput, pickup p99, dropped events, sampled peak bytes, and the fixed bound. The unread reader reached the bound and reported drops in every measured trial. [Telemetry measurement](durable-jobs-parity-evidence.md#measure-runner-telemetry)
- [x] Probe. Interleaved five pairs on the dense one-runner, 16-slot profile in each of the disabled, logged, and unread-reader modes. [Telemetry measurement](durable-jobs-parity-evidence.md#measure-runner-telemetry)
- [x] Baseline. Each of the three comparisons uses the same inputs on main `7c162056`. [Telemetry receipts](../proof/jobs-parity/qualification-v1.json)
- [x] Rule. The measured disabled throughput and p99 meet the 5% limits. Both enabled modes meet the 10% throughput limit on the dense reference profile, and queued events stay within the configured bound. [Telemetry receipts](../proof/jobs-parity/qualification-v1.json)

**Review gate.** None. This phase has no graphical interaction. Independent review uses the CLI receipts and database proof.

**Merge.**

- [ ] Land J4 after its dependencies and exact-head checks pass. Record the SHA and evidence in the program receipt.

## Make queue behavior easy to test from Mesh (J5)

**Depends on.** J1. Build on the existing compiled drain and settlement counts.

**Files.**

- [x] Edit `compiler/mesh-test-rt/src/lib.rs` and the compiler's Jobs type, codegen, and REPL bindings where test APIs need them.
- [x] Add compiled examples and tests under `tests/e2e/durable_jobs/` and `compiler/meshc/tests/`. Update the concurrency and test docs.

**Build.**

- [x] Provide scoped manual inspection and assert or refute helpers with namespace, queue, worker, version, argument subset, state, and bounded waits. Let assertions inside a transaction read through the caller's borrowed connection. Keep namespace ownership explicit so parallel tests cannot see one another's rows.
- [x] Provide test-only job construction and direct handler execution with the production validation and outcome decoder. Inline mode uses a fresh test scope and system clock or injected test clock as appropriate. It must not acknowledge a production row or trigger unexpected work on a rollback. Keep production execution on the existing isolated path.
- [x] Add a synchronous drain helper that uses the normal claim and settlement path with a maximum job count, an optional scheduled cutoff, explicit recursion and error policy. Return committed outcome counts and indicate remaining work when a budget is hit.
- [x] Show testing patterns for enqueue-only assertions, handler outcomes without a database, and physical multi-process recovery backed by PostgreSQL.

**You see.**

- [x] A service test can assert its jobs on the same transaction, run a worker directly, or drain a bounded namespace and assert its persisted results.

**Verify, unit.** Tests alone are not sufficient verification. A PR is verified only when its unit, live, and perf boxes are all checked.

- [x] Test the payload matcher, scopes, outcome decoding, drain cutoff and budget, and rejection of test-only hooks in ordinary builds. Run the compiler and meshc test suites.

**Verify, live.** Tests alone are not sufficient verification. A PR is verified only when its unit, live, and perf boxes are all checked. Ten lanes on `gpt-6.2-sol high` at the PR head using the compiled fixtures and the PostgreSQL boot recipe.

- [x] Lane 1. Regression lane against main. Run an enqueue-and-inspect fixture on main and head. Save `j5-lane-1.log`. Pass when both persist the same job and the head assertion verifies it.
- [x] Lane 2. Assert a job inside a borrowed transaction. Save `j5-lane-2.log`. Pass when the borrowed connection sees the row before commit.
- [x] Lane 3. Rollback an asserted enqueue. Save `j5-lane-3.log`. Pass when a second connection never sees the job.
- [x] Lane 4. Run parallel manual tests in separate namespaces. Save `j5-lane-4.log`. Pass when each test sees only its rows.
- [x] Lane 5. Call a test helper from a production build. Save `j5-lane-5.log`. Pass when the compiler rejects the test-only capability.
- [x] Lane 6. Perform an inline job with invalid input. Save `j5-lane-6.log`. Pass when validation and outcome match the documented worker API.
- [x] Lane 7. Drain a known future cutoff. Save `j5-lane-7.log`. Pass when jobs on the allowed side execute and later jobs remain scheduled.
- [x] Lane 8. Enqueue recursively during a bounded drain. Save `j5-lane-8.log`. Pass when the documented budget stops further claims.
- [x] Lane 9. Drain with one failing and one healthy job. Save `j5-lane-9.log`. Pass when the error policy and both dispositions match durable state.
- [x] Lane 10. Kill a compiled test runner in the middle of a real drain. Save `j5-lane-10.log`. Pass when the next runner recovers eligible work without a stale write.

**Verify, perf.** Tests alone are not sufficient verification. A PR is verified only when its unit, live, and perf boxes are all checked.

- [x] Metric. Direct-handler and committed drain duration per job, and default runtime throughput.
- [x] Probe. Seven interleaved release pairs used equivalent due work and one slot. Separate compiled probes timed direct execution.
- [x] Baseline. Pinned main ran the due-only drain and called the same handler with a prebuilt context.
- [x] Rule. The median paired drain duration was 0.760 times main. The sampled default workload had equal enqueue SQL counts and equal median claim SQL counts. [Receipt index](../proof/jobs-parity/qualification-v1.json)

**Review gate.** None. This phase has no graphical interaction. Independent review uses the CLI receipts and database proof.

**Merge.**

- [ ] Land J5 after its dependencies and exact-head checks pass. Record the SHA and evidence in the program receipt.

## Close queue control and maintenance gaps (J6)

**Depends on.** J1 and J2. Keep notification and event integrations optional until J3 and J4 land.

**Files.**

- [x] Edit `compiler/mesh-rt/src/jobs/store.rs`, `compiler/mesh-rt/src/jobs/schema.sql`, `compiler/mesh-rt/src/jobs/runner.rs`, and `compiler/mesh-rt/src/jobs/cron.rs`.
- [x] Extend store and cron tests and the compiled runner proof. Add an operations runbook next to the Jobs docs.

**Build.**

- [x] Add stable runner and queue inspection, targeted local start, pause, resume and scale, and queue-only graceful stop. Retain namespace-wide defaults and database-wide admission. Make the behavior during restart and node loss explicit. Add optional namespace-wide pause and resume.
- [x] Add bounded job search, filtered bulk delete, validated edits, and an explicit run-now action for scheduled or retryable work. Preserve global limits, the current run's effect key, and the attempt budget. Reject edits to an actively claimed attempt unless the action specifically supports cancellation.
- [x] Expose cadence and page sizes for recovery, cron, and pruning. Preserve transactional cron cursors, current missed-occurrence policies, and receipt replay after pruning or delete. Put opt-in concurrent index maintenance on a separate, bounded administrative path with an index allowlist and one owner at a time.
- [x] Document missed wakeups, database outage triage, bounded maintenance, and the operator view of a job after failover. Derive the role grants from invoker SQL and test the matrix in Appendix C on a fresh and an upgraded database with default `PUBLIC EXECUTE` revoked.

**You see.**

- [x] Operators can inspect and control one runner or the namespace, safely advance due work, and maintain a busy database while jobs continue to settle.

**Verify, unit.** Tests alone are not sufficient verification. A PR is verified only when its unit, live, and perf boxes are all checked.

- [x] Cover command scope, edits racing claims, terminal-only deletes, receipt replay, and cron takeover. Run `bash scripts/verify-postgres-jobs.sh` plus store and cron tests.

**Verify, live.** Tests alone are not sufficient verification. A PR is verified only when its unit, live, and perf boxes are all checked. Ten lanes on `gpt-6.2-sol high` at the PR head using the compiled fixtures and the PostgreSQL boot recipe.

- [x] Lane 1. Regression lane against main. Run namespace pause and resume on main and head. Save `j6-lane-1.log`. Pass when both retain the documented persisted effect.
- [x] Lane 2. Pause one of two runners. Save `j6-lane-2.log`. Pass when the other process continues to claim within the namespace cap.
- [x] Lane 3. Scale both local and global limits. Save `j6-lane-3.log`. Pass when the lower available headroom determines new admissions.
- [x] Lane 4. Stop one queue with an active handler. Save `j6-lane-4.log`. Pass when stopping that queue leaves another queue able to make progress.
- [x] Lane 5. Run-now a retryable job. Save `j6-lane-5.log`. Pass when the scheduled time moves and the existing effect key survives.
- [x] Lane 6. Race bulk edit or delete with claim, then separately enqueue a duplicate with allowed replacement fields while a compiled handler is active. Save `j6-lane-6.log`. Pass when bulk actions change only eligible rows, the replacement persists, the active context and token stay unchanged, and settlement and the next attempt use the documented stored values.
- [x] Lane 7. Kill the cron owner across cursor advancement. Save `j6-lane-7.log`. Pass when a new owner neither loses nor duplicates the committed occurrence.
- [x] Lane 8. Prune terminal jobs and replay an existing request key. Save `j6-lane-8.log`. Pass when the receipt replay still resolves to the same identity.
- [x] Lane 9. Reindex under concurrent enqueue and dispatch. Save `j6-lane-9.log`. Pass when normal application work keeps moving and a second reindex owner is refused.
- [x] Lane 10. Restart each role with default function execution revoked. Save `j6-lane-10.log`. Pass when supported commands succeed and workers cannot change roles, apply schema DDL, or reindex as administrators.

**Verify, perf.** Tests alone are not sufficient verification. A PR is verified only when its unit, live, and perf boxes are all checked.

- [x] Metric. The five-round release receipt includes dispatch p99, backlog catch-up, and administration statement and wall times. [Maintenance measurement](durable-jobs-parity-evidence.md#compare-maintenance-under-load)
- [x] Probe. The three arms alternate order and use equal 16-row prune, recovery, and staging pages under the same J1 traffic. [Maintenance receipt](../proof/jobs-parity/qualification-v1.json)
- [x] Baseline. Pinned main and the candidate each run native PostgreSQL concurrent reindex as a control for the scripted candidate arm. [Maintenance receipt](../proof/jobs-parity/qualification-v1.json)
- [x] Rule. In five quiet release rounds, dispatch p99 was at most 0.938 times main. Pages stayed within their bounds, and the largest bracketing claim gap was 115 ms against 500 ms. [Maintenance receipt](../proof/jobs-parity/qualification-v1.json)

**Review gate.** None. This phase has no graphical interaction. Independent review uses the CLI receipts and database proof.

**Merge.**

- [ ] Land J6 after its dependencies and exact-head checks pass. Record the SHA and evidence in the program receipt.

## Qualify the PostgreSQL queue and publish the results (J7)

**Depends on.** J2, J3, J4, J5, and J6.

**Files.**

- [x] Extend `.github/workflows/authoritative-verification.yml`, `scripts/verify-postgres-jobs.sh`, and `compiler/meshc/tests/e2e_durable_jobs.rs`.
- [x] Publish the shared API, guarantees, upgrade and support matrix, workload manifest, and comparison results in the Jobs documentation.

**Build.**

- [x] The compiled timeout, child-death, join, and recovery suites passed on PostgreSQL 17.11, 18.7, and 19.0 on Linux x64 and macOS arm64. The Linux arm64 container proof also passed the three PostgreSQL versions. [Platform scope and exact revisions](durable-jobs-parity-evidence.md#postgresql-and-platform-matrix)
- [x] The proofs cover worker and runner death, row locks, connection loss, primary failover, and pool exhaustion. The Jobs reference describes process termination, host suspension, and the need for downstream idempotency when an accepted request can finish after the attempt exits. [Compiled proofs](durable-jobs-parity-evidence.md#compiled-lane-receipts) · [Jobs reference](../website/docs/docs/concurrency/index.md#durable-jobs)
- [x] Replay the upgrade with preexisting scheduled and retryable jobs, old and new worker binaries, scoped grants, and default function execution revoked. Demonstrate rollback to the old runner without dropping rows or removing additive SQL.
- [x] The feature matrix and workload measurements record tested behavior, platform scope, and performance misses. The broad PostgreSQL Core claim awaits the remaining gates. [Evidence guide](durable-jobs-parity-evidence.md)

**You see.**

- [x] The qualification receipt links the workflow proofs, measurements, and remaining gates. [Qualification receipt](../proof/jobs-parity/qualification-v1.json)

**Verify, unit.** Tests alone are not sufficient verification. A PR is verified only when its unit, live, and perf boxes are all checked.

- [x] Run the authoritative workspace build, format, runtime tests, proof gates, and the versioned PostgreSQL matrix. Keep the full compiler-to-worker entry point in the compiled proof.

**Verify, live.** Tests alone are not sufficient verification. A PR is verified only when its unit, live, and perf boxes are all checked. Ten lanes on `gpt-6.2-sol high` at the PR head using the compiled fixtures and the PostgreSQL boot recipe.

- [x] Lane 1. On macOS arm64 and PostgreSQL 17.11, all 35 frozen profiles reconciled 43,080 jobs per runtime against the same input manifests. The receipt records three performance budget misses. [Receipt](../proof/jobs-parity/j7-lane-1.log)
- [x] Lane 2. The compiled Linux arm64 proof observed both attempt processes exit after native timeout and parent death. Replacement attempts completed the original jobs. [Receipt](../proof/jobs-parity/j7-lane-2.log)
- [x] Lane 3. Run the macOS executable replacement and shutdown proof. Save `j7-lane-3.log`. Pass when an unstarted claim keeps its attempt budget.
- Lane 4 applies when a Windows configuration is advertised. The first release scope covers Linux and macOS. Enable this lane when the compiled Windows timeout, parent-death, and recovery proof is ready.
- [x] Lane 5. The rolling upgrade preserved existing attempts and schedules on macOS arm64 with PostgreSQL 17.11, 18.7, and 19.0. [Receipt](../proof/jobs-parity/j7-rolling-and-promotion.log)
- [x] Lane 6. The previous runner settled its existing claim under its original grants on the updated schema. A fresh legacy runner completed the pending retry. [Receipt](../proof/jobs-parity/j7-rolling-and-promotion.log)
- [x] Lane 7. Primary promotion fenced the old primary and reconciled all job and effect identities. Eligible work resumed within 1.23 seconds in all three macOS PostgreSQL runs against a 2-second budget. [Receipt](../proof/jobs-parity/j7-rolling-and-promotion.log)
- [x] Lane 8. On macOS arm64 with PostgreSQL 17.11, 18.7, and 19.0, the compiled proof exhausted the pool and interrupted notifications and maintenance. Stop and join met their bounds. The peer proved fallback polling, expired-lease recovery, and cron cursor advancement. [Receipt](../proof/jobs-parity/j7-lane-8.log)
- [x] Lane 9. The guides reproduced enqueue, retry, drain, and lease recovery from a fresh application on macOS arm64 with PostgreSQL 17.11. [Receipt](../proof/jobs-parity/j7-lane-9.log) · [Rerun the guide proof](durable-jobs-parity-evidence.md#replay-the-fresh-application-guides)
- [x] Lane 10. The 35-profile release comparison reconciled 43,080 jobs per engine. The receipt reports each profile's metrics, and the archive contains the original trial and summary files. [Oban comparison](../proof/jobs-parity/j7-lane-10.log) · [Raw archive](../proof/jobs-parity/matched-workload-samples-v1.tar.xz)

**Verify, perf.** Tests alone are not sufficient verification. A PR is verified only when its unit, live, and perf boxes are all checked.

- [x] Metric. The release receipt records medians and resource budgets by profile. [Oban comparison](../proof/jobs-parity/j7-lane-10.log)
- [x] Probe. The five measured pairs per profile alternate engine order. The group manifests record the harness pins and one-minute host load. [Evidence guide](durable-jobs-parity-evidence.md#matched-oban-release-comparison)
- [x] Baseline. The candidate has separate paired comparisons with pinned main and Oban Basic on the same host and PostgreSQL 17.11. [Main comparison](../proof/jobs-parity/j7-lane-1.log) · [Oban comparison](../proof/jobs-parity/j7-lane-10.log)
- [ ] Rule. Require Mesh median throughput to exceed Oban in all 35 frozen PostgreSQL workload profiles. Require pickup p99 no greater than 1.25 times Oban, within J1's frozen absolute latency and resource budgets. Historical receipts retain the original 90% throughput floor. [Current manifest](../scripts/jobs-parity-profiles.json)

**Review gate.** None. This phase has no graphical interaction. Independent review uses the CLI receipts and database proof.

**Merge.**

- [ ] Land J7 after its dependencies and exact-head checks pass. Record the SHA and evidence in the program receipt.

### Fence application writes with the current Jobs attempt

The fence is a one-time, opt-in SQL migration. After the normal Jobs migration, connect as the Jobs object owner and run the file in a standalone `psql` invocation. The file owns its `BEGIN` and `COMMIT`, so run it outside any enclosing transaction. [Fence migration](../compiler/mesh-rt/src/jobs/effect_fence_schema.sql)

```sh
psql -X -v ON_ERROR_STOP=1 -f compiler/mesh-rt/src/jobs/effect_fence_schema.sql "$DATABASE_URL"
```

`mesh_jobs_effects.fence_v1(text, uuid, bigint, integer, uuid)` takes the namespace, job ID, run, attempt, and lease token. It returns void on success. SQLSTATE `55000` means the fence denied the attempt, `55P03` means the row was locked, and `25000` means the transaction ran outside `READ COMMITTED`. The separate schema lets the application opt in without granting access to `mesh_jobs`.

Grant the application routine owner `USAGE` on `mesh_jobs_effects` and `EXECUTE` on `fence_v1`. Grant that owner the required application table permissions separately. Give the caller `USAGE` on the application schema and `EXECUTE` on the named application routines only. Use dedicated roles with no inherited access to the queue tables or application tables for the caller. Each application routine calls the fence for its own namespace before it touches application data. [Fixture grants and routines](../scripts/fixtures/jobs-effect-fence/application.sql)

Use one short, autocommit `READ COMMITTED` call per application effect. The fence takes the same `FOR NO KEY UPDATE` lock as Jobs lifecycle operations on the exact job row. It checks the database clock after acquiring the lock, so a lease can expire while the call waits for a relation lock. Once the fence admits the write, the row lock lasts through commit or rollback. A write can still commit after expiry, and recovery skips the expired row while the write holds the lock. An operator cancellation waits for the lock, and a committed cancellation denies the next write.

Set `statement_timeout` and `lock_timeout` before submitting a routine call. If a client deadline passes or the local socket closes before the reply, the commit outcome is unknown. Reconcile it against the durable effect record. Key the record by the stable Jobs effect key (`id/run`) and the operation name within the application namespace. A replacement attempt uses the same key and its own live lease to replay the operation idempotently.

Run the SQL proof on a disposable PostgreSQL installation with both `dbc55bb1` and `7c162056` available in Git. The proof checks the scoped roles and rolls back an allowed call with the original live token after each owner replay. It also checks distinct autocommit transactions on one session, operator cancellation order, expiry during a relation lock wait, and recovery after an admitted write rolls back.

```sh
env -u MESH_TEST_DATABASE_URL PG_BIN_DIR=/path/to/postgresql/bin \
  bash scripts/verify-postgres-jobs.sh --effect-fence
```

### Exercise the compiled effect candidate

Use `Jobs.start_effects` to opt in on compiled GNU/Linux ARM64 or x86-64. Omit
`effect_sessions` to prewarm one application session. Set `"listen":true`
to exercise LISTEN on a non-drain runner.

Run `bash scripts/verify-postgres-jobs.sh --effect-compiled` on a disposable
PostgreSQL installation. The one-slot fixture checks two independent commits
on the same warm backend under a five-connection cap. Use the recipe to
capture exact child reaps before settlement and to stage the separate
64-slot occupancy proof. The frozen `slow-1r-64s` comparison remains pending.
[Compiled effect recipe](../scripts/fixtures/jobs-effect-compiled/README.md)

## Close the program

- [x] The evidence guide records the tested PostgreSQL and OS matrix, scope boundaries, and benchmark results by workload. [Evidence guide](durable-jobs-parity-evidence.md)
- [x] The compiled proofs exercise positive and failure cases for the documented Jobs guarantees, including producer commit loss, notification rejection, queue-local stop, bounded drain, and inspection and assertion limits. [Commit-loss proofs](durable-jobs-parity-evidence.md#producer-commit-and-final-claim-faults) · [Notification rejection](durable-jobs-parity-evidence.md#reproduce-producer-notify-failures) · [Drain and queue-local proofs](durable-jobs-parity-evidence.md#compiled-drain-and-queue-local-failures)
- [x] Track other database engines and Oban Pro in the [backlog beyond PostgreSQL Core](#backlog-beyond-postgresql-core).

## Appendix A. Prototype evidence

- [Hard timeouts](https://github.com/snowdamiz/mesh-lang/pull/37) merged at `db606548`. [Runner reliability](https://github.com/snowdamiz/mesh-lang/pull/38) merged at `59f6a7b3` with the same tree as its verified head `afd48895`. PostgreSQL 18.7 and 19.0 each passed 38 hosted Linux checks. The local macOS run on that reliability head also reported 38 passes per version. The compiled cases include application commit and rollback, worker death, native timeout, stale acknowledgements, retry and exhaustion, row contention, and shutdown. [Hosted verification](https://github.com/snowdamiz/mesh-lang/actions/runs/44667929654)
- The reliability head demonstrated that a large PostgreSQL JSONB context can exceed 8 MiB despite a much smaller input. J2 must preserve the one-row-per-context representation and the actual size boundary when claiming multiple jobs.
- Dedicated PostgreSQL listener transport, the steady-state cost of one OS process per attempt, and throughput relative to Oban are unmeasured. J1 records a baseline and J2 and J3 retain a switchable fallback before their new defaults are considered.

## Appendix B. Alternatives rejected

- Keep PostgreSQL as the first parity target. The distributed runtime and a separate embedded file cannot replace enqueue on the same connection as a PostgreSQL business transaction.
- Keep notification messages advisory. A listener can disconnect or miss a hint while rows remain durable. A committed row, queue control, and claim token remain the source of authority.
- Keep one process per attempt through the first comparison. A reusable worker adds state leakage and recycling concerns. Evaluate it only if J1 and J2 isolate process startup or resource usage as the reason a measured target fails.
- Reuse lease expiry and fencing for recovery. Oban Core's optional Lifeline uses an age threshold and documents possible duplicate execution. Match the recoverability workflow without adopting the weaker ownership test. [Oban Lifeline](https://oban.hexdocs.pm/Oban.Lifeline.html)

## Appendix C. Risks and later scope

Derive and verify exact grants before releasing the operational changes. The matrix names intended capabilities. PostgreSQL functions run with invoker privileges, so their grants must cover the tables and any sequences used by the SQL. Use namespaces within a trusted database. Use separate databases for applications that require isolation from one another.

| Database role | Required authority | Verification |
| --- | --- | --- |
| Migrator | Own the Jobs schema, tables, sequences, and functions. Apply DDL and record role grants. | Fresh install and rolling upgrade with default execution revoked. |
| Producer | Execute enqueue functions and use only the business and queue objects needed for enqueue. Check `admissions`, `queues`, `jobs`, `receipts`, and any required sequences. | Commit a business write with enqueue, roll it back, and reject worker and administrative operations. |
| Worker | Read schema metadata and execute claim, renew, settlement, and recovery. Grant only the underlying queue and job operations plus any maintenance explicitly enabled for that worker. | Claim and settle, including through bounded drain, then prove the role cannot apply DDL, change roles, or reindex. |
| Operator | Execute the selected state changes and inspect their underlying records. Put index maintenance behind a separately granted administrative capability. | Exercise pause and retry with scoped grants. Require distinct authority to reindex. |
| Inspector | Read approved summary data with no mutation or raw payload granted by default. | Read queue statistics and reject enqueue, settlement, and job edits. |

- J2 can increase response size, resource peaks, or later-queue latency. Cap total bytes and per-queue dispatch quantum, hold reserved slots only through confirmed claims, and test the same fault cases at small and large payloads.
- J3 consumes a session and can couple successful commits to PostgreSQL notification availability. Keep polling, expose its own resource budget, and qualify a session pool or explicit poll-only configuration.
- J4 event subscribers can accumulate work or disclose job data. Bound buffers, label outcomes with fixed categories, and omit payloads and credentials from default output.
- J5 inline execution can mask physical durability or start real application effects. Keep it in a test-only scope and preserve the PostgreSQL drain and process proofs.
- J6 maintenance can block shared work or destroy replay evidence. Keep bounded terminal-row pruning, separate receipts, and a scoped administrative reindex path.
- J7 verifies redelivery while attempts remain under declared database and platform assumptions. An uncertain committed claim can spend an attempt before handler entry. A forced worker suspension or a service that has already accepted a request can still lead to repeated effects. Use the stable effect key and state the storage and primary fencing assumptions.

### Backlog beyond PostgreSQL Core

- For backend-wide Core parity, follow J7 with one separate plan each for SQLite and MySQL. Each must prove same-transaction enqueue, competing claims, migration continuity, crash recovery and durable schedules, and publish its supported platform and concurrency limits.
- Pro parity is a distinct goal. Evaluate partitioned concurrency, rate limits, batch settlement, richer uniqueness and lifecycle hooks, dynamic queue policy, workflow dependencies and archival after PostgreSQL Core is qualified. Mesh already has database-wide queue limits and durable editable schedules. [Oban Pro Engine](https://oban.pro/docs/pro/Oban.Pro.Engine.html) · [Oban Pro composition](https://oban.pro/docs/pro/composition.html)

## Appendix D. Links and reading list

- [Oban 2.24.2 API](https://oban.hexdocs.pm/Oban.html) · [Basic engine source](https://hex.pm/packages/oban/2.24.2/files/lib/oban/engines/basic.ex) · [Database notifications and scaling](https://oban.hexdocs.pm/scaling.html)
- [Oban testing](https://oban.hexdocs.pm/Oban.Testing.html) · [Oban telemetry](https://oban.hexdocs.pm/2.24.2/Oban.Telemetry.html) · [Oban maintenance](https://oban.hexdocs.pm/operational_maintenance.html)
- [PostgreSQL LISTEN](https://www.postgresql.org/docs/19/sql-listen.html) · [PostgreSQL NOTIFY](https://www.postgresql.org/docs/19/sql-notify.html) · [Asynchronous messages](https://www.postgresql.org/docs/19/protocol-flow.html#PROTOCOL-ASYNC-OPERATIONS)
- [Mesh Jobs APIs](../website/docs/docs/concurrency/index.md#durable-jobs) · [Runtime state and schema](../compiler/mesh-rt/src/jobs/schema.sql) · [Compiled proof](../compiler/meshc/tests/e2e_durable_jobs.rs) · [PostgreSQL test entry point](../scripts/verify-postgres-jobs.sh)

### Experimental trusted persistent workers

On GNU/Linux with Linux 5.11 or later, `Jobs.start_effects` accepts an optional
`trusted_persistent_workers` array of configured `{"worker":"name","version":1}`
pairs. Only those exact claimed versions use persistent workers. Omit the
array to give every attempt a fresh process. Use the default for any handler
whose code or transitive dependencies have not been audited for reuse.

Trusted handlers run synchronously on the worker's main thread. They may use
ordinary Mesh values, synchronous operations, and the registered
`Jobs.effect` calls. They must keep all attempt state in that invocation and
release any opened resources before returning. They cannot spawn actors,
start background jobs or callbacks, retain Mesh references, or rely on
process globals, thread-local state, or native constructors being initialized
again. The runtime terminates a trusted child that tries to spawn an actor. Later
claims of that worker version use strict execution on that runner.
FFI and other process-wide or asynchronous facilities require application
review. Code that uses unmanaged threads, child processes, signal callbacks,
persistent handles, or external side effects outside the named registry
belongs on the strict path. The file descriptor inventory catches ordinary
descriptor leaks. This opt-in is a trusted application contract, with the
same OS user and filesystem permissions as the runner.

Each occupied slot uses one child executable and one relay thread. On a clean
`complete` return their PID and thread can serve another attempt. The child
receives a fresh private socket and managed process context for each attempt.
Its environment omits database URLs, and the launch closes inherited
descriptors above standard I/O. Every call uses the current claim's durable
token, cancellation and lease fence, the admitted application login over TLS,
and its own commit receipt after full session reset. The relay drops the
attempt socket and authority before the runner can settle. Retry, failure,
invalid replies, timeouts, stops, or a lost authority retire the child before
another assignment. An unknown application result is never replayed within
that attempt. Existing durable retry and recovery rules still apply.

A reusable child watchdog enforces the hard deadline and latest confirmed
lease even if the runner is suspended. Each assignment has a new generation,
and a renewal or shutdown deadline can affect only that generation. Linux
sends SIGKILL on parent death. Use the strict path when a workload requires
fresh initialization of process-wide state for each attempt.
