"""Change only runner admission in the frozen compiled fixture."""
from pathlib import Path
import sys

path = Path(sys.argv[1])
source = path.read_text()
anchor = '  let registry = Json.parse('
assert source.count(anchor) == 1
source = source.replace(
    '  let effects_config = ',
    '  let effects_base_config = ',
)
assert source.count('  let effects_base_config = ') == 1
source = source.replace(anchor, r'''  let effects_config = if Env.get("JOBS_PARITY_MESH_EXECUTION", "strict") == "trusted-persistent" do
    String.slice(effects_base_config, 0, String.length(effects_base_config) - 1) <>
      ""","trusted_persistent_workers":[{"worker":"parity","version":1}]}"""
  else
    effects_base_config
  end
''' + anchor)
path.write_text(source)
