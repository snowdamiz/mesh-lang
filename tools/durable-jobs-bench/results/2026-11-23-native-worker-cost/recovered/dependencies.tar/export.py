"""Export only diagnostic evidence, using the pinned official text sanitizer."""

import io
import os
from pathlib import Path
import sys
import tarfile

from worker import safe_bytes, PRIVATE_NAME, SAFE_EXTENSIONS

root = Path(sys.argv[1])
with tarfile.open(fileobj=sys.stdout.buffer, mode="w|gz") as archive:
    for current, dirs, names in os.walk(root):
        dirs[:] = sorted(name for name in dirs if name != "state" and not PRIVATE_NAME.search(name))
        for name in sorted(names):
            path = Path(current) / name
            if path.is_symlink() or not path.is_file() or PRIVATE_NAME.search(name):
                continue
            if path.suffix in SAFE_EXTENSIONS:
                try:
                    data = safe_bytes(path)
                except UnicodeError:
                    data = b"[non-UTF-8 text withheld by the evidence sanitizer]\n"
            elif (name.endswith(".perf.data") or name == "reap.so"
                  or name.startswith("wait-") and path.suffix == ".bin"):
                data = path.read_bytes()
            else:
                continue
            member = tarfile.TarInfo(path.relative_to(root).as_posix())
            member.mode = 0o600
            member.size = len(data)
            archive.addfile(member, io.BytesIO(data))
