"""Run the byte-verified native arm with a runner-only optional wait observer."""

import os
from pathlib import Path
import sys

SOURCE = Path("/var/lib/durable-jobs-bench/native/source-v5/tools/durable-jobs-bench/native")
sys.path.insert(0, str(SOURCE))
import arm  # noqa: E402

if shim := os.environ.pop("DENSE_REAP_SHIM", None):
    class ObservedSubject(arm.Subject):
        def run(self, env, index, log):
            trace = log.with_name(f"wait-{index}.bin")
            return super().run(dict(env, LD_PRELOAD=shim, DENSE_NATIVE_WAIT=str(trace)), index, log)

    arm.Subject = ObservedSubject

arm.main()
