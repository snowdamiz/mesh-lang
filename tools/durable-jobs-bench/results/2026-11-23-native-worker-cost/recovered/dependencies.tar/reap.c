#define _GNU_SOURCE
#include <dlfcn.h>
#include <errno.h>
#include <fcntl.h>
#include <spawn.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

enum { CAPACITY = 4096, SPAWN = 1, CONSUME = 2, UNEXPECTED = 3 };
struct row {
    uint64_t mono;
    int64_t kind, pid, requested, status, flags, user_us, system_us;
    int64_t end_ns, minflt, majflt, nvcsw, nivcsw;
};
static struct row rows[CAPACITY];
static _Atomic unsigned used;
static int output = -1;
static pid_t owner;
static int (*spawnp_real)(pid_t *, const char *, const posix_spawn_file_actions_t *,
                          const posix_spawnattr_t *, char *const [], char *const []);
static int (*spawn_real)(pid_t *, const char *, const posix_spawn_file_actions_t *,
                         const posix_spawnattr_t *, char *const [], char *const []);
static int (*waitid_real)(idtype_t, id_t, siginfo_t *, int);
static pid_t (*wait4_real)(pid_t, int *, int, struct rusage *);

static uint64_t stamp(void) {
    struct timespec now;
    if (clock_gettime(CLOCK_MONOTONIC, &now)) _exit(91);
    return (uint64_t)now.tv_sec * 1000000000 + now.tv_nsec;
}

static void record(struct row row) {
    unsigned slot = atomic_fetch_add_explicit(&used, 1, memory_order_relaxed);
    if (slot < CAPACITY) rows[slot] = row;
}

__attribute__((constructor)) static void prepare(void) {
    spawnp_real = dlsym(RTLD_NEXT, "posix_spawnp");
    spawn_real = dlsym(RTLD_NEXT, "posix_spawn");
    waitid_real = dlsym(RTLD_NEXT, "waitid");
    wait4_real = dlsym(RTLD_NEXT, "wait4");
    const char *path = getenv("DENSE_NATIVE_WAIT");
    if (!path || !spawnp_real || !spawn_real || !waitid_real || !wait4_real) _exit(92);
    owner = getpid();
    output = open(path, O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC, 0600);
    if (output < 0) _exit(93);
    for (size_t i = 0; i < sizeof rows; i += 4096)
        ((volatile char *)rows)[i] = 0;
}

static void write_all(const void *buffer, size_t remaining) {
    const char *bytes = buffer;
    while (remaining) {
        ssize_t result = write(output, bytes, remaining);
        if (result < 0 && errno == EINTR) continue;
        if (result <= 0) _exit(94);
        remaining -= result;
        bytes += result;
    }
}

__attribute__((destructor)) static void flush(void) {
    if (getpid() != owner || output < 0) _exit(95);
    uint64_t count = atomic_load_explicit(&used, memory_order_relaxed);
    struct rusage self;
    if (getrusage(RUSAGE_SELF, &self)) _exit(97);
    uint64_t header[] = {3, (uint64_t)owner, count, count > CAPACITY ? count - CAPACITY : 0,
                         (uint64_t)self.ru_utime.tv_sec * UINT64_C(1000000) + self.ru_utime.tv_usec,
                         (uint64_t)self.ru_stime.tv_sec * UINT64_C(1000000) + self.ru_stime.tv_usec};
    write_all(header, sizeof header);
    write_all(rows, (count > CAPACITY ? CAPACITY : count) * sizeof rows[0]);
    if (close(output)) _exit(96);
}

typedef int (*spawn_fn)(pid_t *, const char *, const posix_spawn_file_actions_t *,
                        const posix_spawnattr_t *, char *const [], char *const []);
static int observe_spawn(spawn_fn next, pid_t *pid, const char *path,
                         const posix_spawn_file_actions_t *actions, const posix_spawnattr_t *attr,
                         char *const argv[], char *const env[]) {
    int pinned = !strcmp(path, "/proc/self/exe") && argv[1] &&
                 !strcmp(argv[1], "--mesh-internal-job-attempt-effect-v1");
    for (char *const *item = env; *item; ++item) {
        if (!strncmp(*item, "LD_PRELOAD=", 11) || !strncmp(*item, "DENSE_NATIVE_WAIT=", sizeof "DENSE_NATIVE_WAIT=" - 1)) {
            // A child must never receive the observer, even on a rejected arm.
            record((struct row){.mono = stamp(), .kind = UNEXPECTED, .status = 1});
            return EINVAL;
        }
    }
    uint64_t before = stamp();
    int result = next(pid, path, actions, attr, argv, env);
    int saved = errno;
    record((struct row){.mono = before, .kind = pinned ? SPAWN : UNEXPECTED,
                        .pid = result ? 0 : *pid, .status = result, .end_ns = stamp()});
    errno = saved;
    return result;
}

int posix_spawnp(pid_t *pid, const char *path, const posix_spawn_file_actions_t *actions,
                 const posix_spawnattr_t *attr, char *const argv[], char *const env[]) {
    return observe_spawn(spawnp_real, pid, path, actions, attr, argv, env);
}

int posix_spawn(pid_t *pid, const char *path, const posix_spawn_file_actions_t *actions,
                const posix_spawnattr_t *attr, char *const argv[], char *const env[]) {
    return observe_spawn(spawn_real, pid, path, actions, attr, argv, env);
}

pid_t waitpid(pid_t pid, int *status, int flags) {
    struct rusage usage;
    int result_status;
    pid_t result = wait4_real(pid, &result_status, flags, &usage);
    int saved = errno;
    if (result > 0) {
        uint64_t after = stamp();
        if (status) *status = result_status;
        int terminal = (WIFEXITED(result_status) || WIFSIGNALED(result_status));
        record((struct row){after, terminal && pid == result ? CONSUME : UNEXPECTED,
            result, pid, result_status, flags,
            usage.ru_utime.tv_sec * INT64_C(1000000) + usage.ru_utime.tv_usec,
            usage.ru_stime.tv_sec * INT64_C(1000000) + usage.ru_stime.tv_usec,
            0, usage.ru_minflt, usage.ru_majflt, usage.ru_nvcsw, usage.ru_nivcsw});
    } else if (pid <= 0 || (flags != 0 && flags != WNOHANG) ||
               (result < 0 && saved != EINTR)) {
        record((struct row){.mono = stamp(), .kind = UNEXPECTED, .pid = result,
                            .requested = pid, .status = saved, .flags = flags});
    }
    errno = saved;
    return result;
}

pid_t wait4(pid_t pid, int *status, int flags, struct rusage *usage) {
    pid_t result = wait4_real(pid, status, flags, usage);
    int saved = errno;
    record((struct row){.mono = stamp(), .kind = UNEXPECTED, .pid = result,
                        .requested = pid, .status = 4, .flags = flags});
    errno = saved;
    return result;
}

int waitid(idtype_t type, id_t id, siginfo_t *info, int flags) {
    int result = waitid_real(type, id, info, flags);
    int saved = errno;
    record((struct row){.mono = stamp(), .kind = UNEXPECTED,
                        .pid = !result && info ? info->si_pid : 0,
                        .requested = id, .status = 5, .flags = flags});
    errno = saved;
    return result;
}
