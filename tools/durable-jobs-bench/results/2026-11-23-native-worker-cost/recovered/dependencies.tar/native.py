"""Run a bounded diagnostic on the already-authorized and locked Linode."""

from contextlib import ExitStack
import ctypes
from itertools import islice
import hashlib
import json
import os
from pathlib import Path
import platform
import pwd
import select
import shutil
import signal
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
TOOL = Path("/var/lib/durable-jobs-bench/native/toolchain")
ORDER = (("mesh", "off"), ("oban", "off"), ("mesh", "on"),
         ("oban", "on"), ("oban", "off"), ("mesh", "off"))
PERF_CPU = "cpu-clock"
PERF_LIFECYCLE = ("sched:sched_process_fork", "sched:sched_process_exec", "sched:sched_process_exit")


def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def terminate(process, sig=signal.SIGTERM, grace=10):
    if process.poll() is None:
        os.killpg(process.pid, sig)
        try:
            return process.wait(timeout=grace)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
    return process.wait(timeout=5)


def choose_perf(output):
    perf = shutil.which("perf")
    if not perf:
        (output / "perf-preflight.log").write_text("perf executable unavailable\n")
        return None, False, False
    available = []
    with (output / "perf-preflight.log").open("wb") as log:
        for command in ([perf, "--version"], ["uname", "-srvmo"], ["getconf", "CLK_TCK"]):
            subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=5)
        for setting in ("/proc/sys/kernel/perf_event_paranoid", "/proc/sys/kernel/kptr_restrict",
                        "/proc/sys/kernel/yama/ptrace_scope", "/sys/kernel/security/lockdown",
                        "/proc/sys/kernel/sched_schedstats"):
            try:
                status = Path(setting).read_text().strip()
            except OSError as error:
                status = str(error)
            log.write(f"{setting}: {status}\n".encode())
        try:
            with Path("/proc/kallsyms").open() as symbols:
                addresses = [line.split(maxsplit=1)[0] for line in islice(symbols, 32)]
            log.write(f"nonzero kallsyms addresses in first 32 entries: {sum(bool(int(a, 16)) for a in addresses)}\n".encode())
        except (OSError, ValueError) as error:
            log.write(f"kallsyms availability: {error}\n".encode())
        for events, options in (([PERF_CPU], ["-F", "199", "--call-graph", "fp"]),
                                (PERF_LIFECYCLE, ["-c", "1"])):
            path = output / f"preflight-{len(available)}.perf.data"
            command = perf_record(perf, path, events, options, "0.25")
            log.write((repr(command) + "\n").encode())
            log.flush()
            result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=8)
            available.append(result.returncode == 0 and path.exists() and path.stat().st_size > 0)
    return perf, *available


def perf_record(perf, path, events, options, duration):
    return [perf, "record", "-a", "-C", "0,1", "--clockid", "mono", "--no-buildid-cache",
            "-o", str(path), *options, *[arg for event in events for arg in ("-e", event)],
            "--", "/usr/bin/sleep", duration]


def start_perf(arm_dir, perf, events, options, label, stack):
    sink = stack.enter_context((arm_dir / f"{label}.record.log").open("wb"))
    data = arm_dir / f"{label}.perf.data"
    process = subprocess.Popen(perf_record(perf, data, events, options, "95"),
                               stdin=subprocess.DEVNULL, stdout=sink, stderr=subprocess.STDOUT,
                               start_new_session=True)
    stack.callback(finish_perf, process, perf, data, arm_dir, label)


def finish_perf(process, perf, data, arm_dir, label):
    code = terminate(process, signal.SIGINT, 8)
    if not data.exists():
        write(arm_dir / f"{label}.status.json", {"record": code, "script": None})
        return
    args = ["--ns", "--show-lost-events"]
    if label == "cpu":
        args += ["-F", "comm,pid,tid,cpu,time,event,ip,sym,dso,period"]
    else:
        args += ["-F", "comm,pid,tid,cpu,time,event,trace"]
    with (arm_dir / f"{label}.perf.txt").open("wb") as out, \
            (arm_dir / f"{label}.script.log").open("wb") as log:
        status = subprocess.run([perf, "script", "-i", str(data), *args],
                                stdout=out, stderr=log, timeout=20).returncode
    write(arm_dir / f"{label}.status.json", {"record": code, "script": status})


def runner_cpu_clock():
    # Linux x86_64 glibc uses signed int for pid_t and clockid_t.
    resolve = ctypes.CDLL(None).clock_getcpuclockid
    resolve.argtypes = (ctypes.c_int, ctypes.POINTER(ctypes.c_int))
    resolve.restype = ctypes.c_int

    def read(pid):
        clock_id = ctypes.c_int()
        error = resolve(pid, ctypes.byref(clock_id))
        if error:
            raise OSError(error, os.strerror(error), pid)
        return time.clock_gettime_ns(clock_id.value)

    return read


def bind_runner_pids(capture, stack):
    watches = {}
    for pid, role in capture.items():
        if role != "engine_runner_root":
            continue
        try:
            fd = os.pidfd_open(pid)
        except OSError:
            # No identity witness. Keep this PID missing throughout the arm.
            continue
        stack.callback(os.close, fd)
        watch = select.poll()
        watch.register(fd, select.POLLIN)
        watches[pid] = watch
    return watches


def runner_cpu_for_live_pid(pid, runner_cpu_ns, watches):
    watch = watches.get(pid)
    if watch is None or watch.poll(0):
        raise ProcessLookupError(f"runner {pid} is unavailable")
    absolute = runner_cpu_ns(pid)
    if watch.poll(0):
        raise ProcessLookupError(f"runner {pid} exited while reading its CPU clock")
    return absolute


def cpu_frame(capture, runner_cpu_ns, watches):
    # Record absolute counters, with collection timestamps bracketing all reads.
    begin = time.monotonic_ns()
    epoch_before = time.time_ns()
    cpu = {}
    for line in Path("/proc/stat").read_text().splitlines():
        key, *values = line.split()
        if key in {"cpu", "cpu0", "cpu1", "cpu2", "cpu3"}:
            cpu[key] = [int(tick) for tick in values[:8]]
    diskstats = Path("/proc/diskstats").read_text().splitlines()
    backends = {}
    for pid, role in capture.items():
        base = Path(f"/proc/{pid}")
        try:
            fields = process_stat(pid)
            if role == "engine_runner_root":
                absolute = runner_cpu_for_live_pid(pid, runner_cpu_ns, watches)
            else:
                absolute = int((base / "schedstat").read_text().split()[0])
            backends[pid] = [int(fields[19]), absolute, int(fields[11]), int(fields[12])]
        except OSError as error:
            backends[pid] = error.__class__.__name__
    return {"mono_before_ns": begin, "real_before_ns": epoch_before,
            "real_after_ns": time.time_ns(), "mono_after_ns": time.monotonic_ns(),
            "cpu": cpu, "diskstats": diskstats, "backends": backends,
            "loadavg": os.getloadavg()}


def process_stat(pid):
    return Path(f"/proc/{pid}/stat").read_text().rsplit(")", 1)[1].split()


def capture_roles(evidence):
    try:
        sessions = json.loads((evidence / "postgres-tls-sessions.json").read_text())
        affinity = json.loads((evidence / "process-affinity.json").read_text())
    except (FileNotFoundError, json.JSONDecodeError):
        return {}
    roles = {row["backend"]: row["role"] for row in sessions if row["tls"]}
    postmasters = set()
    for pid in roles:
        try:
            postmasters.add(int(process_stat(pid)[1]))
        except OSError:
            continue
    if len(postmasters) == 1 and str(next(iter(postmasters))) in affinity:
        roles.update({int(pid): "engine_runner_root" for pid in affinity if int(pid) not in postmasters})
    return roles


def run_one(output, engine, mode, spec, probe, shim, deadline, runner_cpu_ns):
    output.mkdir()
    output.chmod(0o711)
    account = pwd.getpwnam("nobody")
    evidence = output / "adapter"
    scratch = output / "state"
    for folder in (evidence, scratch):
        folder.mkdir(mode=0o700)
        os.chown(folder, account.pw_uid, account.pw_gid)
    artifacts = spec["argv"][1].split("=", 1)[1]
    env = [f"PATH={TOOL}/otp-29.1.1/bin:{TOOL}/elixir-1.20.4/bin:/usr/bin:/bin",
           "LC_ALL=C.UTF-8", f"PG_BIN_DIR={TOOL}/pgsql-17.11/bin", "ERL_CRASH_DUMP=/dev/null",
           "DURABLE_JOBS_PHASE=diagnostic", f"NATIVE_JOBS_STATE={scratch}",
           f"NATIVE_JOBS_ARTIFACTS={artifacts}"]
    if mode == "on" and engine == "mesh" and shim:
        env += [f"DENSE_REAP_SHIM={shim}"]
    command = ["/usr/bin/taskset", "-c", "0,1", "/usr/sbin/runuser", "-u", "nobody", "--",
               "/usr/bin/env", "-i", *env, "/usr/bin/python3", "-B",
               str(HERE / "adapter.py"), engine, "noop", str(evidence)]
    write(output / "invocation.json", {"argv": command, "engine": engine, "mode": mode,
                                        "reap_shim": bool(mode == "on" and engine == "mesh" and shim)})
    perf, cpu, lifecycle = probe
    roles = {}
    watches = {}
    with ExitStack() as stack:
        if mode == "on":
            if cpu:
                start_perf(output, perf, [PERF_CPU], ["-F", "199", "--call-graph", "fp"], "cpu", stack)
            if lifecycle:
                start_perf(output, perf, PERF_LIFECYCLE, ["-c", "1"], "lifecycle", stack)
            time.sleep(.15)  # before adapter startup, gives event opens time to fail
        log = stack.enter_context((output / "adapter.log").open("wb"))
        frames = stack.enter_context((output / "frames.jsonl").open("x", buffering=1))
        frames.write(json.dumps(cpu_frame({}, runner_cpu_ns, {})) + "\n")
        process = subprocess.Popen(command, cwd=spec["argv"][2].rsplit("/", 1)[0],
                                   stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                                   start_new_session=True)
        try:
            limit = min(deadline, time.monotonic() + 80)
            while True:
                if mode == "on" and not roles:
                    roles = capture_roles(evidence)
                    watches = bind_runner_pids(roles, stack)
                frames.write(json.dumps(cpu_frame(roles, runner_cpu_ns, watches)) + "\n")
                if (code := process.poll()) is not None:
                    break
                if time.monotonic() >= limit:
                    raise TimeoutError("diagnostic arm exceeded its budget")
                time.sleep(.025 if mode == "on" else .20)
        finally:
            code = terminate(process)
            write(output / "status.json", {"adapter_exit": code, "backend_roles": roles})
    return code == 0


def main(output, expires):
    if platform.system() != "Linux" or platform.machine() != "x86_64" or os.geteuid():
        raise RuntimeError("expected the existing native x86-64 Linux SSH operator")
    allowed = os.sched_getaffinity(0)
    if allowed != {0, 1, 2, 3}:
        raise RuntimeError(f"unexpected Linode CPU mask: {allowed}")
    os.sched_setaffinity(0, {2})
    deadline = time.monotonic() + max(0, expires - time.time() - 65)
    if deadline - time.monotonic() < 120:
        raise RuntimeError("grant has less than two minutes of usable diagnostic time")
    main_disk = Path("/var/lib/durable-jobs-bench/native/scratch")
    if output.stat().st_dev != main_disk.stat().st_dev:
        raise RuntimeError("diagnostic scratch is not on the original PostgreSQL filesystem")
    mount = subprocess.check_output(["findmnt", "-n", "-o", "SOURCE,FSTYPE,MAJ:MIN", "-T", str(output)],
                                   text=True, timeout=5).strip()
    pin = json.loads((HERE / "pinned.json").read_text())
    if digest(TOOL / "pgsql-17.11/bin/postgres") != pin["postgres_sha256"]:
        raise RuntimeError("PostgreSQL executable differs from the frozen shared artifact")
    verified = {}
    for engine, spec in pin["engines"].items():
        manifests = Path(spec["argv"][1].split("=", 1)[1]) / f"{engine}.json"
        for filename, checksum in {str(manifests): spec["artifact_sha256"], **spec["verified_files"]}.items():
            if digest(filename) != checksum:
                raise RuntimeError(f"native artifact differs: {filename}")
            verified[filename] = checksum
    write(output / "host.json", {"boot_id": Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
                                 "platform": platform.uname()._asdict(), "trial_cpus": [0, 1], "pg_mount": mount,
                                 "observer_cpu": 2, "clk_tck": os.sysconf("SC_CLK_TCK"),
                                 "page_size": os.sysconf("SC_PAGESIZE"), "verified": verified})
    runner_cpu_ns = runner_cpu_clock()
    with ExitStack() as preflight:
        pid = os.getpid()
        watch = bind_runner_pids({pid: "engine_runner_root"}, preflight)
        runner_cpu_for_live_pid(pid, runner_cpu_ns, watch)
    probe = choose_perf(output)
    shim = HERE / "reap.so"
    compiler = shutil.which("cc")
    with (output / "reap-build.log").open("wb") as log:
        if not compiler:
            log.write(b"existing C compiler unavailable; exact child capture skipped\n")
        else:
            subprocess.run([compiler, "--version"], stdout=log, stderr=subprocess.STDOUT, timeout=5)
            result = subprocess.run([compiler, "-std=gnu11", "-Wall", "-Wextra", "-Werror",
                                     "-O2", "-fPIC", "-shared", str(HERE / "reap.c"), "-ldl",
                                     "-o", str(shim)], stdout=log, stderr=subprocess.STDOUT, timeout=15)
            if result.returncode == 0:
                shim.chmod(0o755)
                shutil.copyfile(shim, output / "reap.so")
    for index, (engine, mode) in enumerate(ORDER, 1):
        if time.monotonic() >= deadline - 30:
            raise TimeoutError("time budget expired before next arm")
        arm = output / f"{index:02d}-{engine}-{mode}"
        if not run_one(arm, engine, mode, pin["engines"][engine], probe,
                       shim if shim.exists() else None, deadline, runner_cpu_ns):
            raise RuntimeError(f"arm failed: {arm.name}")


if __name__ == "__main__":
    main(Path(sys.argv[1]), int(sys.argv[2]))
